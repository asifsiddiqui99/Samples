Imports Microsoft.VisualBasic

Public Class RemittanceClaimDtlDB
#Region "Fields"

    Private mRemittanceId As String = ""
    Private mReassociationTraceNumber As String = ""
    Private mRemittanceClaimId As String = ""
    Private mPatientFirstName As String = ""
    Private mPatientLastName As String = ""
    Private mPatientMiddleName As String = ""
    Private mInsuredFirstName As String = ""
    Private mInsuredLastName As String = ""
    Private mInsuredMiddleName As String = ""
    Private mClaimStatus As String = ""
    Private mClaimForwardTo As String = ""
    Private mClaimPaymentAmount As String = "0"
    Private mClaimAdjustmentAmount As String = "0"
    Private mClaimAdjustmentCodes As String = ""
    Private mClaimRemarkCodes As String = ""
    Private mHicNumber As String = ""
    Private mRenderingProviderFirstName As String = ""
    Private mRenderingProviderLastName As String = ""
    Private mRenderingProviderMiddleName As String = ""
    Private mRenderingProviderNpi As String = ""
    Private mPayerClaimControlOrIcnNumber As String = ""
    Private mPatientResponsibility As String = ""
    Private mPatientGroupNumber As String = ""
    Private mClaimContactName As String = ""
    Private mClaimCommunicationNumberQualifier As String = ""
    Private mClaimCommunicationNumber As String = ""
#End Region

#Region "Property"
    
    Public Property RemittanceId() As String
        Get
            Return mRemittanceId
        End Get
        Set(ByVal value As String)
            mRemittanceId = value
        End Set
    End Property
    Public Property ReassociationTraceNumber() As String
        Get
            Return mReassociationTraceNumber
        End Get
        Set(ByVal value As String)
            mReassociationTraceNumber = value
        End Set
    End Property
    Public Property RemittanceClaimId() As String
        Get
            Return mRemittanceClaimId
        End Get
        Set(ByVal value As String)
            mRemittanceClaimId = value
        End Set
    End Property
    Public Property PatientFirstName() As String
        Get
            Return mPatientFirstName
        End Get
        Set(ByVal value As String)
            mPatientFirstName = value
        End Set
    End Property
    Public Property PatientLastName() As String
        Get
            Return mPatientLastName
        End Get
        Set(ByVal value As String)
            mPatientLastName = value
        End Set
    End Property
    Public Property PatientMiddleName() As String
        Get
            Return mPatientMiddleName
        End Get
        Set(ByVal value As String)
            mPatientMiddleName = value
        End Set
    End Property
    Public Property InsuredFirstName() As String
        Get
            Return mInsuredFirstName
        End Get
        Set(ByVal value As String)
            mInsuredFirstName = value
        End Set
    End Property
    Public Property InsuredLastName() As String
        Get
            Return mInsuredLastName
        End Get
        Set(ByVal value As String)
            mInsuredLastName = value
        End Set
    End Property
    Public Property InsuredMiddleName() As String
        Get
            Return mInsuredMiddleName
        End Get
        Set(ByVal value As String)
            mInsuredMiddleName = value
        End Set
    End Property
    Public Property ClaimStatus() As String
        Get
            Return mClaimStatus
        End Get
        Set(ByVal value As String)
            mClaimStatus = value
        End Set
    End Property
    Public Property ClaimForwardTo() As String
        Get
            Return mClaimForwardTo
        End Get
        Set(ByVal value As String)
            mClaimForwardTo = value
        End Set
    End Property
    Public Property ClaimPaymentAmount() As String
        Get
            Return mClaimPaymentAmount
        End Get
        Set(ByVal value As String)
            mClaimPaymentAmount = value
        End Set
    End Property
    Public Property ClaimAdjustmentAmount() As String
        Get
            Return mClaimAdjustmentAmount
        End Get
        Set(ByVal value As String)
            mClaimAdjustmentAmount = value
        End Set
    End Property
    Public Property ClaimAdjustmentCodes() As String
        Get
            Return mClaimAdjustmentCodes
        End Get
        Set(ByVal value As String)
            mClaimAdjustmentCodes = value
        End Set
    End Property
    Public Property ClaimRemarkCodes() As String
        Get
            Return mClaimRemarkCodes
        End Get
        Set(ByVal value As String)
            mClaimRemarkCodes = value
        End Set
    End Property
    Public Property HicNumber() As String
        Get
            Return mHicNumber
        End Get
        Set(ByVal value As String)
            mHicNumber = value
        End Set
    End Property
    Public Property RenderingProviderFirstName() As String
        Get
            Return mRenderingProviderFirstName
        End Get
        Set(ByVal value As String)
            mRenderingProviderFirstName = value
        End Set
    End Property
    Public Property RenderingProviderLastName() As String
        Get
            Return mRenderingProviderLastName
        End Get
        Set(ByVal value As String)
            mRenderingProviderLastName = value
        End Set
    End Property
    Public Property RenderingProviderMiddleName() As String
        Get
            Return mRenderingProviderMiddleName
        End Get
        Set(ByVal value As String)
            mRenderingProviderMiddleName = value
        End Set
    End Property
    Public Property RenderingProviderNpi() As String
        Get
            Return mRenderingProviderNpi
        End Get
        Set(ByVal value As String)
            mRenderingProviderNpi = value
        End Set
    End Property
    Public Property PayerClaimControlOrIcnNumber() As String
        Get
            Return mPayerClaimControlOrIcnNumber
        End Get
        Set(ByVal value As String)
            mPayerClaimControlOrIcnNumber = value
        End Set
    End Property
    Public Property PatientResponsibility() As String
        Get
            Return mPatientResponsibility
        End Get
        Set(ByVal value As String)
            mPatientResponsibility = value
        End Set
    End Property
    Public Property PatientGroupNumber() As String
        Get
            Return mPatientGroupNumber
        End Get
        Set(ByVal value As String)
            mPatientGroupNumber = value
        End Set
    End Property
    Public Property ClaimContactName() As String
        Get
            Return mClaimContactName
        End Get
        Set(ByVal value As String)
            mClaimContactName = value
        End Set
    End Property
    Public Property ClaimCommunicationNumberQualifier() As String
        Get
            Return mClaimCommunicationNumberQualifier
        End Get
        Set(ByVal value As String)
            mClaimCommunicationNumberQualifier = value
        End Set
    End Property
    Public Property ClaimCommunicationNumber() As String
        Get
            Return mClaimCommunicationNumber
        End Get
        Set(ByVal value As String)
            mClaimCommunicationNumber = value
        End Set
    End Property
#End Region
End Class
Public Class RemittanceClaimDtl
    Implements IDetail
#Region "Fields"
    Private mConnection As Connection
    Private mConnectionString As String
    Private mRemittanceClaimDtlDB As New RemittanceClaimDtlDB
#End Region

#Region "Property"

    Public Property RemittanceClaimDtl() As RemittanceClaimDtlDB
        Get
            Return mRemittanceClaimDtlDB
        End Get
        Set(ByVal value As RemittanceClaimDtlDB)
            mRemittanceClaimDtlDB = value
        End Set
    End Property

    Public ReadOnly Property Connection() As ElixirLibrary.Connection Implements IDetail.Connection
        Get
            Return mConnection
        End Get
    End Property

    Public ReadOnly Property ConnectionString() As String Implements IDetail.ConnectionString
        Get
            Return mConnectionString
        End Get
    End Property
#End Region

#Region "Constructor"

    Public Sub New(ByVal pConnectionString As String)
        If pConnectionString = "" Then
            Throw New ArgumentException("ConnectionString can not be empty")
        End If
        mConnectionString = pConnectionString
        mConnection = New Connection(mConnectionString)

    End Sub


    Public Sub New(ByVal pConnection As Connection)
        If pConnection Is Nothing Then
            Throw New ArgumentException("Connection can not be empty")
        End If
        mConnection = pConnection
    End Sub
#End Region

#Region "Methods"
    Public Sub InsertRecord() Implements IDetail.InsertRecord
        Dim lXmlDocument As New XmlDocument
        Dim lXmlElement As XmlElement

        lXmlDocument.LoadXml("<RemittanceClaimDtls></RemittanceClaimDtls>")
        lXmlElement = lXmlDocument.CreateElement("RemittanceClaimDtl")

        With lXmlElement

            .SetAttribute("RemittanceId", RemittanceClaimDtl.RemittanceId)
            .SetAttribute("ReassociationTraceNumber", RemittanceClaimDtl.ReassociationTraceNumber)
            .SetAttribute("RemittanceClaimId", RemittanceClaimDtl.RemittanceClaimId)
            .SetAttribute("PatientFirstName", RemittanceClaimDtl.PatientFirstName)
            .SetAttribute("PatientLastName", RemittanceClaimDtl.PatientLastName)
            .SetAttribute("PatientMiddleName", RemittanceClaimDtl.PatientMiddleName)
            .SetAttribute("InsuredFirstName", RemittanceClaimDtl.InsuredFirstName)
            .SetAttribute("InsuredLastName", RemittanceClaimDtl.InsuredLastName)
            .SetAttribute("InsuredMiddleName", RemittanceClaimDtl.InsuredMiddleName)
            .SetAttribute("ClaimStatus", RemittanceClaimDtl.ClaimStatus)
            .SetAttribute("ClaimForwardTo", RemittanceClaimDtl.ClaimForwardTo)
            .SetAttribute("ClaimPaymentAmount", RemittanceClaimDtl.ClaimPaymentAmount)
            .SetAttribute("ClaimAdjustmentAmount", RemittanceClaimDtl.ClaimAdjustmentAmount)
            .SetAttribute(("ClaimAdjustmentCodes"), RemittanceClaimDtl.ClaimAdjustmentCodes)
            .SetAttribute(("ClaimRemarkCodes"), RemittanceClaimDtl.ClaimRemarkCodes)
            .SetAttribute(("HicNumber"), RemittanceClaimDtl.HicNumber)
            .SetAttribute(("RenderingProviderFirstName"), RemittanceClaimDtl.RenderingProviderFirstName)
            .SetAttribute(("RenderingProviderLastName"), RemittanceClaimDtl.RenderingProviderLastName)
            .SetAttribute(("RenderingProviderMiddleName"), RemittanceClaimDtl.RenderingProviderMiddleName)
            .SetAttribute(("RenderingProviderNpi"), RemittanceClaimDtl.RenderingProviderNpi)
            .SetAttribute(("PayerClaimControlOrIcnNumber"), RemittanceClaimDtl.PayerClaimControlOrIcnNumber)
            .SetAttribute(("PatientResponsibility"), RemittanceClaimDtl.PatientResponsibility)
            .SetAttribute(("PatientGroupNumber"), RemittanceClaimDtl.PatientGroupNumber)
            .SetAttribute(("ClaimContactName"), RemittanceClaimDtl.ClaimContactName)
            .SetAttribute(("ClaimCommunicationNumberQualifier"), RemittanceClaimDtl.ClaimCommunicationNumberQualifier)
            .SetAttribute(("ClaimCommunicationNumber"), RemittanceClaimDtl.ClaimCommunicationNumber)


        End With

        lXmlDocument.DocumentElement.AppendChild(lXmlElement.CloneNode(True))

        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand("InsertRemittanceClaimDtl", lXmlDocument.InnerXml.ToString)
        Else
            Connection.ExecuteCommand("InsertRemittanceClaimDtl", lXmlDocument.InnerXml.ToString)
        End If
    End Sub
    Public Sub InsertRecord(ByVal pXML As String)
        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand("InsertRemittanceClaimDtl", pXML)
        Else
            Connection.ExecuteCommand("InsertRemittanceClaimDtl", pXML)
        End If
    End Sub
    Public Function GetRecordByID() As Boolean Implements IDetail.GetRecordByID
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "RemittanceClaimDtl"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = "And RemittanceId = " & Me.RemittanceClaimDtl.RemittanceId

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("SelectAllRecords", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
        End If


        With lDs.Tables(0)
            If .Rows.Count > 0 Then

                Me.RemittanceClaimDtl.RemittanceId = .Rows(0)("RemittanceId")
                Me.RemittanceClaimDtl.ReassociationTraceNumber = .Rows(0)("ReassociationTraceNumber")
                Me.RemittanceClaimDtl.RemittanceClaimId = .Rows(0)("RemittanceClaimId")
                Me.RemittanceClaimDtl.PatientFirstName = .Rows(0)("PatientFirstName")
                Me.RemittanceClaimDtl.PatientLastName = .Rows(0)("PatientLastName")
                Me.RemittanceClaimDtl.PatientMiddleName = .Rows(0)("PatientMiddleName")
                Me.RemittanceClaimDtl.InsuredFirstName = .Rows(0)("InsuredFirstName")
                Me.RemittanceClaimDtl.InsuredLastName = .Rows(0)("InsuredLastName")
                Me.RemittanceClaimDtl.InsuredMiddleName = .Rows(0)("InsuredMiddleName")
                Me.RemittanceClaimDtl.ClaimStatus = .Rows(0)("ClaimStatus")
                Me.RemittanceClaimDtl.ClaimForwardTo = .Rows(0)("ClaimForwardTo")
                Me.RemittanceClaimDtl.ClaimPaymentAmount = .Rows(0)("ClaimPaymentAmount")
                Me.RemittanceClaimDtl.ClaimAdjustmentAmount = .Rows(0)("ClaimAdjustmentAmount")
                Me.RemittanceClaimDtl.ClaimAdjustmentCodes = .Rows(0)("ClaimAdjustmentCodes")
                Me.RemittanceClaimDtl.ClaimRemarkCodes = .Rows(0)("ClaimRemarkCodes")
                Me.RemittanceClaimDtl.HicNumber = .Rows(0)("HicNumber")
                Me.RemittanceClaimDtl.RenderingProviderFirstName = .Rows(0)("RenderingProviderFirstName")
                Me.RemittanceClaimDtl.RenderingProviderLastName = .Rows(0)("RenderingProviderLastName")
                Me.RemittanceClaimDtl.RenderingProviderMiddleName = .Rows(0)("RenderingProviderMiddleName")
                Me.RemittanceClaimDtl.RenderingProviderNpi = .Rows(0)("RenderingProviderNpi")
                Me.RemittanceClaimDtl.PayerClaimControlOrIcnNumber = .Rows(0)("PayerClaimControlOrIcnNumber")
                Me.RemittanceClaimDtl.PatientResponsibility = .Rows(0)("PatientResponsibility")
                Me.RemittanceClaimDtl.PatientGroupNumber = .Rows(0)("PatientGroupNumber")
                Me.RemittanceClaimDtl.ClaimContactName = .Rows(0)("ClaimContactName")
                Me.RemittanceClaimDtl.ClaimCommunicationNumberQualifier = .Rows(0)("ClaimCommunicationNumberQualifier")
                Me.RemittanceClaimDtl.ClaimCommunicationNumber = .Rows(0)("ClaimCommunicationNumber")

                Return True
            End If
        End With

        Return False
    End Function
    Public Sub DeleteRecord(ByVal lCondition As String) Implements IDetail.DeleteRecord
    End Sub
    Public Sub DeleteRecordByID() Implements IDetail.DeleteRecordByID
    End Sub
    Public Function GetAllRecords() As System.Data.DataSet Implements IDetail.GetAllRecords
        Dim lDs As New DataSet()
        Dim lSpParameter(1) As SpParameter

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "RemittanceClaimDtl"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = "And RemittanceId = " & Me.RemittanceClaimDtl.RemittanceId

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("SelectAllRecords", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
        End If

        Return lDs
    End Function

    Public Function GetRemitanceDetailForGrid() As System.Data.DataSet
        Dim lDs As New DataSet()
        Dim lQuery As String = "Select PatientFirstName + ', ' + PatientLastName as PatientName,* from RemittanceClaimDtl where RemittanceId =" & Me.RemittanceClaimDtl.RemittanceId

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery(lQuery)
        Else
            lDs = Connection.ExecuteQuery(lQuery)
        End If

        Return lDs
    End Function

    Public Function GetAllRecords(ByVal lCondition As String) As System.Data.DataSet Implements IDetail.GetAllRecords
        Dim lDs As New DataSet()

        Return lDs
    End Function
    Public Sub UpdateRecord() Implements IDetail.UpdateRecord
    End Sub
    Public Sub UpdateRecord(ByVal lCondition As String) Implements IDetail.UpdateRecord
    End Sub
    Public Function GetRecordByIDExtended() As Boolean
        Return True
    End Function
    Public Function GetUniqueId() As Boolean
        Return True
    End Function
    Public Sub LogicalDelete()
    End Sub

#End Region
End Class
