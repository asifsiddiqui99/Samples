Imports Microsoft.VisualBasic
Imports System.xml

Public Class PatientLedgerDB


    Private mReferenceID As String
    Private mReference As String
    Private mPatientID As String
    Private mReferenceDate As String
    Private mDate As String
    Private mDescription As String
    Private mDebit As String
    Private mCredit As String
    Private mAdjustment As String

    Private mTransactionType As String
    Private mReferenceID2 As String
    Private mReferenceDate2 As String
    Private mPaymentMethod As String
    Private mPayerName As String
    Private mPayerType As String
    Private mReferenceDisplayID As String
    Private mReferenceDisplayID2 As String
    Private mReferenceDisplayDate As String
    Private mChequeNumber As String
    Private mChequeDate As String








    Public Sub New()

        mReferenceID = ""
        mReference = ""
        mPatientID = ""
        mReferenceDate = ""
        mDate = ""
        mDescription = ""
        mDebit = "0"
        mCredit = "0"
        mAdjustment = "0"

        mTransactionType = ""
        mReferenceID2 = ""
        mReferenceDate2 = ""
        mPaymentMethod = ""
        mPayerName = ""
        mPayerType = ""
        mReferenceDisplayID = ""
        mReferenceDisplayID2 = ""
        mReferenceDisplayDate = ""

    End Sub


#Region "Properties"

    Public Property ReferenceDisplayDate() As String
        Get
            Return mReferenceDisplayDate
        End Get
        Set(ByVal value As String)
            mReferenceDisplayDate = value
        End Set
    End Property

    Public Property ReferenceDisplayID2() As String
        Get
            Return mReferenceDisplayID2
        End Get
        Set(ByVal value As String)
            mReferenceDisplayID2 = value
        End Set
    End Property

    Public Property ReferenceDisplayID() As String
        Get
            Return mReferenceDisplayID
        End Get
        Set(ByVal value As String)
            mReferenceDisplayID = value
        End Set
    End Property

    Public Property PayerType() As String
        Get
            Return mPayerType
        End Get
        Set(ByVal value As String)
            mPayerType = value
        End Set
    End Property

    Public Property PayerName() As String
        Get
            Return mPayerName
        End Get
        Set(ByVal value As String)
            mPayerName = value
        End Set
    End Property

    Public Property PaymentMethod() As String
        Get
            Return mPaymentMethod
        End Get
        Set(ByVal value As String)
            mPaymentMethod = value
        End Set
    End Property

    Public Property ReferenceDate2() As String
        Get
            Return mReferenceDate2
        End Get
        Set(ByVal value As String)
            mReferenceDate2 = value
        End Set
    End Property
    Public Property ReferenceID2() As String
        Get
            Return mReferenceID2
        End Get
        Set(ByVal value As String)
            mReferenceID2 = value
        End Set
    End Property

    Public Property TransactionType() As String
        Get
            Return mTransactionType
        End Get
        Set(ByVal value As String)
            mTransactionType = value
        End Set
    End Property


    Public Property Reference() As String
        Get
            Return mReference
        End Get
        Set(ByVal value As String)
            mReference = value
        End Set
    End Property

    Public Property ReferenceID() As String
        Get
            Return mReferenceID
        End Get
        Set(ByVal value As String)
            mReferenceID = value
        End Set
    End Property

    Public Property PatientID() As String
        Get
            Return mPatientID
        End Get
        Set(ByVal value As String)
            mPatientID = value
        End Set
    End Property

    Public Property ReferenceDate() As String
        Get
            Return mReferenceDate
        End Get
        Set(ByVal value As String)
            mReferenceDate = value
        End Set
    End Property
    Public Property Date1() As String
        Get
            Return mDate
        End Get
        Set(ByVal value As String)
            mDate = value
        End Set
    End Property

    Public Property Description() As String
        Get
            Return mDescription
        End Get
        Set(ByVal value As String)
            mDescription = value
        End Set
    End Property

    Public Property Debit() As String
        Get
            Return mDebit
        End Get
        Set(ByVal value As String)
            mDebit = value
        End Set
    End Property

    Public Property Credit() As String
        Get
            Return mCredit
        End Get
        Set(ByVal value As String)
            mCredit = value
        End Set
    End Property

    Public Property Adjustment() As String
        Get
            Return mAdjustment
        End Get
        Set(ByVal value As String)
            mAdjustment = value
        End Set
    End Property


    Public Property ChequeNumber() As String
        Get
            Return mChequeNumber
        End Get
        Set(ByVal value As String)
            mChequeNumber = value
        End Set
    End Property

   Public Property ChequeDate() As String
        Get
            Return mChequeDate
        End Get
        Set(ByVal value As String)
            mChequeDate = value
        End Set
    End Property


#End Region
End Class

Public Class PatientLedger

#Region "Fields"
    Private mConnection As Connection
    Private mConnectionString
    Private mPatientLedger As New PatientLedgerDB
#End Region

    
#Region "Property"
    Public ReadOnly Property Connection() As ElixirLibrary.Connection
        Get
            Return mConnection
        End Get
    End Property

    Public ReadOnly Property ConnectionString() As String
        Get
            Return mConnectionString
        End Get
    End Property
    Public Property PatientLedger() As PatientLedgerDB
            Get
            Return mPatientLedger
        End Get
        Set(ByVal value As PatientLedgerDB)
            mPatientLedger = value
        End Set
    End Property
#End Region

#Region "Constructor"
    ''' <summary>
    ''' Creates new Conection Object based on Given Connection String 
    ''' </summary>
    ''' <param name="pConnectionString">
    ''' Contains Connection String 
    ''' </param>
    ''' <remarks>
    ''' Use when not using transaction
    ''' Must Specify Connection String other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnectionString As String)
        If pConnectionString = "" Then
            Throw New ArgumentException("ConnectionString can not be empty")
        End If

        mConnectionString = pConnectionString
        mConnection = New Connection(mConnectionString)

    End Sub

    ''' <summary>
    ''' Assign given connection to the current Object
    ''' </summary>
    ''' <param name="pConnection">
    ''' Contains refrence to the connection object
    ''' </param>
    ''' <remarks>
    ''' Use when  using Transaction
    ''' Must Specify Connection other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnection As Connection)
        If pConnection Is Nothing Then
            Throw New ArgumentException("Connection can not be empty")
        End If

        mConnection = pConnection
    End Sub
#End Region


    Public Function InsertPatientLedger(ByVal pReferenceDate As String) As String

        Dim lXmlDocument As New XmlDocument
        Dim lXmlElement As XmlElement

        lXmlDocument.LoadXml("<PatientLedgers></PatientLedgers>")
        lXmlElement = lXmlDocument.CreateElement("PatientLedger")

        With lXmlElement
            .SetAttribute("ReferenceID", PatientLedger.ReferenceID)
            .SetAttribute("PatientID", PatientLedger.PatientID)
            .SetAttribute("ReferenceDate", PatientLedger.ReferenceDate)
            .SetAttribute("Reference", PatientLedger.Reference)
            .SetAttribute("Date", PatientLedger.Date1)
            .SetAttribute("Description", PatientLedger.Description)
            .SetAttribute("Debit", PatientLedger.Debit)
            .SetAttribute("Credit", PatientLedger.Credit)
            .SetAttribute("Adjustment", PatientLedger.Adjustment)

        End With

        lXmlDocument.DocumentElement.AppendChild(lXmlElement.CloneNode(True))


        Connection.ExecuteCommand("InsertPatientLedger", lXmlDocument.DocumentElement.OuterXml.ToString)
        Return "Patient Ledger Added Successfully"

    End Function

     Public Function InsertPatientLedger() As String

        Dim lXmlDocument As New XmlDocument
        Dim lXmlElement As XmlElement
        Try
            lXmlDocument.LoadXml("<PatientLedgers></PatientLedgers>")
            lXmlElement = lXmlDocument.CreateElement("PatientLedger")

            With lXmlElement
                .SetAttribute("ReferenceID", PatientLedger.ReferenceID)
                .SetAttribute("Reference", PatientLedger.Reference)
                .SetAttribute("PatientID", PatientLedger.PatientID)
                .SetAttribute("ReferenceDate", PatientLedger.ReferenceDate)
                .SetAttribute("Date", PatientLedger.Date1)
                .SetAttribute("Description", PatientLedger.Description)
                .SetAttribute("Debit", PatientLedger.Debit)
                .SetAttribute("Credit", PatientLedger.Credit)
                .SetAttribute("Adjustment", PatientLedger.Adjustment)
                .SetAttribute("TransactionType", PatientLedger.TransactionType)
                .SetAttribute("ReferenceDate2", PatientLedger.ReferenceDate2)
                .SetAttribute("PaymentMethod", PatientLedger.PaymentMethod)
                .SetAttribute("PayerName", PatientLedger.PayerName)
                .SetAttribute("PayerType", PatientLedger.PayerType)
                .SetAttribute("ReferenceDisplayID", PatientLedger.ReferenceDisplayID)
                .SetAttribute("ReferenceDisplayID2", PatientLedger.ReferenceDisplayID2)
                .SetAttribute("ReferenceDisplayDate", PatientLedger.ReferenceDisplayDate)
                .SetAttribute("ReferenceID2", PatientLedger.ReferenceID2)
                ''
                .SetAttribute("ChequeNumber", PatientLedger.ChequeNumber)
                .SetAttribute("ChequeDate", PatientLedger.ChequeDate)
            End With

            lXmlDocument.DocumentElement.AppendChild(lXmlElement.CloneNode(True))


            ''The condition posted to avoid inserting record in database if debit and credit values are 0 ........


            If ((PatientLedger.Debit <> 0) Or (PatientLedger.Credit <> 0)) Then
                If Connection.IsTransactionAlive() Then
                    Connection.ExecuteTransactionCommand("InsertPatientLedger", lXmlDocument.DocumentElement.OuterXml.ToString)
                Else
                    Connection.ExecuteCommand("InsertPatientLedger", lXmlDocument.DocumentElement.OuterXml.ToString)
                End If

                Return "Patient Ledger Added Successfully"
            Else
                Return ""
            End If

        Catch ex As Exception
            Throw
        End Try

    End Function

    Public Sub InsertPatientLedgerXml(ByVal pPatientLedgerXml As String)

        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand("InsertPatientLedger", pPatientLedgerXml)
        Else
            Connection.ExecuteCommand("InsertPatientLedger", pPatientLedgerXml)
        End If

    End Sub

    Public Function GetPreviousAdjustmenstSum(ByVal pVisitID As String) As Double
        Dim lQuery As String
        Dim lDs As New DataSet
        Dim lAdjustmentSum As Double = 0.0

        lQuery = "select isNull(sum(Adjustment),0) as AdjSum from patientLedger where ReferenceID2 =" & pVisitID

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery(lQuery)
        Else
            lDs = Connection.ExecuteQuery(lQuery)
        End If

        If (lDs.Tables(0).Rows.Count > 0) Then
            lAdjustmentSum = Convert.ToDouble(lDs.Tables(0).Rows(0).Item("AdjSum").ToString)
        End If

        Return lAdjustmentSum

    End Function
    Public Function GetPreviousPaymentSum(ByVal pVisitID As String, ByVal pPaymentID As String) As Double
        Dim lQuery As String
        Dim lDs As New DataSet
        Dim lPaymentSum As Double = 0.0

        lQuery = "select PaymentSum = (isNull(sum(credit),0) - isNull(sum(debit),0))from patientLedger where ReferenceID=" & pPaymentID & " and ReferenceID2=" & pVisitID

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery(lQuery)
        Else
            lDs = Connection.ExecuteQuery(lQuery)
        End If

        If (lDs.Tables(0).Rows.Count > 0) Then
            lPaymentSum = Convert.ToDouble(lDs.Tables(0).Rows(0).Item("PaymentSum").ToString)
        End If

        Return lPaymentSum

    End Function

    Public Function GetPatientLedger(ByVal pPatientID As String, ByVal pDateFrom As Date, ByVal pDateTo As Date) As DataSet
        Dim lQuery As String
        Dim lDs As New DataSet
        Try
            'If (pPatientID <> "") Then
            'lQuery = "SELECT LineID='',ReferenceID='',ReferenceDate='" & pDateFrom.Date.AddDays(-1) & "',ReferenceID2='',ReferenceDate2='',ReferenceDisplayID=''," _
            '                 & "ReferenceDisplayDate='',ReferenceDisplayID2='',TransactionType='',PatientID='',Reference='',[Date]='" & pDateFrom.Date.AddDays(-1) & "'," _
            '                 & "[Description]='Opening Balance',PaymentMethod='',PayerName='',PayerType='',Debit=IsNull(sum(Debit),0),Credit=IsNull(sum(Credit),0),Adjustment=0" _
            '                 & ",ChequeNumber='',ChequeDate='',PID='',CurrentBalance=IsNull((SELECT Balance=sum(Debit) - sum(Credit) FROM PatientLedger where PatientID='" & pPatientID & "' and ReferenceDate <= '" & Date.Now.Date & "'),0) FROM PatientLedger where ReferenceDate < '" & pDateFrom.Date & "' and PatientID='" & pPatientID & "' union all " _
            '                 & "SELECT * ,Case TransactionType when 'V' then ReferenceID else ReferenceID2 end as PID,CurrentBalance=IsNull((SELECT Balance=sum(Debit) - sum(Credit) FROM PatientLedger where PatientID='" & pPatientID & "' and ReferenceDate <= '" & Date.Now.Date & "'),0) FROM PatientLedger where PatientID='" & pPatientID & "' and ReferenceDate Between '" & pDateFrom.Date & "' " _
            '                 & "And '" & pDateTo.Date & "' order by ReferenceDate"


            lQuery = "SELECT LineID='',ReferenceID='',ReferenceDate='" & pDateFrom.Date & "',ReferenceID2='',ReferenceDate2='',ReferenceDisplayID=''," _
            & "ReferenceDisplayDate='',ReferenceDisplayID2='',TransactionType='',PatientID='',Reference='',[Date]='" & pDateFrom.Date & "'," _
            & "[Description]='Opening Balance',PaymentMethod='',PayerName='',PayerType='',Debit=IsNull(sum(Debit),0),Credit=IsNull(sum(Credit),0),Adjustment=0" _
            & ",ChequeNumber='', ChequeDate='',PID='',CurrentBalance=IsNull((SELECT Balance=sum(Debit) - sum(Credit) FROM PatientLedger where PatientID='" & pPatientID & "' and [Date] <= '" & Date.Now.Date & "'),0),DOS='' FROM PatientLedger where [Date] < '" & pDateFrom.Date & "' and PatientID='" & pPatientID & "' union all " _
            & "SELECT * ,Case TransactionType when 'V' then ReferenceID else ReferenceID2 end as PID,CurrentBalance=IsNull ((SELECT Balance=sum(Debit) - sum(Credit) FROM PatientLedger where PatientID='" & pPatientID & "' and [Date] <= '" & Date.Now.Date & "'),0)," _
           & " CASE " _
           & " WHEN TransactionType = 'V' THEN Convert(varchar, ReferenceDate,101) " _
           & " WHEN TransactionType = 'P' THEN Convert(varchar, ReferenceDate2,101) " _
           & " WHEN TransactionType = 'A' and ReferenceDate2 = '1900-01-01 00:00:00'  THEN Convert(varchar, ReferenceDate,101) " _
          & "	else Convert(varchar, ReferenceDate2,101) " _
          & "	END as DOS" _
          & " FROM PatientLedger where PatientID='" & pPatientID & "' and [Date] Between '" & pDateFrom.Date & "' And '" & pDateTo.Date & "' order by [Date]"










            'Else
            'lQuery = "SELECT LineID='',ReferenceID='',ReferenceDate='" & pDateFrom.Date.AddDays(-1) & "',ReferenceID2='',ReferenceDate2='',ReferenceDisplayID=''," _
            '                 & "ReferenceDisplayDate='',ReferenceDisplayID2='',TransactionType='',PatientID='',Reference='',[Date]=''," _
            '                 & "[Description]='Opening Balance',PaymentMethod='',PayerName='',PayerType='',Debit=IsNull(sum(Debit),0),Credit=IsNull(sum(Credit),0),Adjustment=IsNull(sum(Adjustment),0)" _
            '                 & ",ChequeNumber='',ChequeDate='' FROM PatientLedger where Date < '" & pDateFrom.Date & "' union all " _
            '                 & "SELECT *  FROM PatientLedger where Date Between '" & pDateFrom.Date & "' " _
            '                 & "And '" & pDateTo.Date & "' order by ReferenceDate "
            'End If


            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If
            Return lDs
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Public Function GetVisitReversalChargesSum(ByVal pLineIDs As String) As ArrayList
        Dim lQuery As String
        Dim lDs As New DataSet
        Dim lPaymentSum As Double = 0.0
        Dim lCPTs As String = ""
        Dim lResult As New ArrayList

        lQuery = "SELECT Code,TotalCharges=isNull(Fees,0)*(days) FROM PatientCPT where LineId in (" & pLineIDs & ")"

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery(lQuery)
        Else
            lDs = Connection.ExecuteQuery(lQuery)
        End If

        If (lDs.Tables(0).Rows.Count > 0) Then
            For Each lrow As DataRow In lDs.Tables(0).Rows
                lPaymentSum = lPaymentSum + Convert.ToDouble(lDs.Tables(0).Rows(0).Item("TotalCharges").ToString)
                lCPTs = lCPTs & "," & Convert.ToDouble(lDs.Tables(0).Rows(0).Item("Code").ToString)
            Next
        End If

        lResult.Add(lPaymentSum)
        lResult.Add(lCPTs)

        Return lResult

    End Function

    Public Function CptLogicalDelete(ByVal pLineIds As String) As Boolean
        Try
            Dim lQuery As String

            lQuery = "Update PatientCPT set IsDeleted = 'Y' where LineId in (" & pLineIds & ") "

            If Connection.IsTransactionAlive() Then
                Connection.ExecuteTransactionCommand(lQuery)
            Else
                Connection.ExecuteCommand(lQuery)
            End If
            Return True
        Catch ex As Exception

        End Try
    End Function
End Class



