Imports Microsoft.VisualBasic

Public Class SuperBillDB

#Region "Fields"
    Private mSuperBillId As String
    Private mSuperBillName As String
    Private mICDSortBy As String
    Private mICDSortOrder As String
    Private mCPTSortBy As String
    Private mCPTSortOrder As String
#End Region

#Region "Properties"
    Public Property SuperBillId() As String
        Get
            Return mSuperBillId
        End Get
        Set(ByVal value As String)
            mSuperBillId = value
        End Set
    End Property

    Public Property SuperBillName() As String
        Get
            Return mSuperBillName
        End Get
        Set(ByVal value As String)
            mSuperBillName = value
        End Set
    End Property

    Public Property ICDSortBy() As String
        Get
            Return mICDSortBy
        End Get
        Set(ByVal value As String)
            mICDSortBy = value
        End Set
    End Property

    Public Property ICDSortOrder() As String
        Get
            Return mICDSortOrder
        End Get
        Set(ByVal value As String)
            mICDSortOrder = value
        End Set
    End Property

    Public Property CPTSortBy() As String
        Get
            Return mCPTSortBy
        End Get
        Set(ByVal value As String)
            mCPTSortBy = value
        End Set
    End Property

    Public Property CPTSortOrder() As String
        Get
            Return mCPTSortOrder
        End Get
        Set(ByVal value As String)
            mCPTSortOrder = value
        End Set
    End Property
#End Region
End Class


Public Class SuperBill

#Region "Fields"
    Private mConnection As Connection
    Private mConnectionString
    Private mSuperBill As New SuperBillDB
#End Region

#Region "Property"
    Public ReadOnly Property Connection() As ElixirLibrary.Connection
        Get
            Return mConnection
        End Get
    End Property

    Public ReadOnly Property ConnectionString() As String
        Get
            Return mConnectionString
        End Get
    End Property
    Public Property SuperBill() As SuperBillDB
        Get
            Return mSuperBill
        End Get
        Set(ByVal value As SuperBillDB)
            mSuperBill = value
        End Set
    End Property
#End Region

#Region "Constructor"
    ''' <summary>
    ''' Creates new Conection Object based on Given Connection String 
    ''' </summary>
    ''' <param name="pConnectionString">
    ''' Contains Connection String 
    ''' </param>
    ''' <remarks>
    ''' Use when not using transaction
    ''' Must Specify Connection String other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnectionString As String)
        If pConnectionString = "" Then
            Throw New ArgumentException("ConnectionString can not be empty")
        End If

        mConnectionString = pConnectionString
        mConnection = New Connection(mConnectionString)

    End Sub

    ''' <summary>
    ''' Assign given connection to the current Object
    ''' </summary>
    ''' <param name="pConnection">
    ''' Contains refrence to the connection object
    ''' </param>
    ''' <remarks>
    ''' Use when  using Transaction
    ''' Must Specify Connection other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnection As Connection)
        If pConnection Is Nothing Then
            Throw New ArgumentException("Connection can not be empty")
        End If

        mConnection = pConnection
    End Sub
#End Region



#Region "Method"
    ''' <summary>
    ''' Delete Record Acoording to Given Condition
    ''' </summary>
    ''' <param name="lCondition"></param>
    ''' <remarks></remarks>
    Public Sub DeleteRecord(ByVal lCondition As String)

        Dim lSpParameter(1) As SpParameter

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "SuperBill"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = lCondition

        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand("DeleteRecords", lSpParameter)
        Else
            Connection.ExecuteCommand("DeleteRecords", lSpParameter)
        End If

    End Sub


    Public Sub LogicalDelete(ByVal pCondition As String)
        Dim lQuery As String = String.Empty

        lQuery = "Update SuperBill set IsDeleted = 'Y' where 1=1 " & pCondition

        
        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionQuery(lQuery)
        Else
            Connection.ExecuteQuery(lQuery)
        End If
    End Sub

    ''' <summary>
    ''' Delete Record on Primary Key
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub DeleteRecordByID()
        Dim lCondition As String

        lCondition = "AND SuperBillId= " & SuperBill.SuperBillId
        LogicalDelete(lCondition)

    End Sub
    ''' <summary>
    ''' Get All Records unconditional
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetAllRecords() As System.Data.DataSet
        Dim lCondition As String = " And IsDeleted = 'N'"
        Dim lDs As New DataSet()

        lDs = GetAllRecords(lCondition)

        Return lDs
    End Function
    ''' <summary>
    ''' Get  Records on specified Condition
    ''' </summary>
    ''' <param name="lCondition"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    ''' 
    Public Function GetAllRecords(ByVal lCondition As String) As System.Data.DataSet
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "SuperBill"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = lCondition

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("SelectAllRecords", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
        End If

        Return lDs

    End Function
    ''' <summary>
    ''' Insert record
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub InsertRecord()
        Dim lXmlDocument As New XmlDocument
        Dim lXmlElement As XmlElement

        lXmlDocument.LoadXml("<SuperBills></SuperBills>")
        lXmlElement = lXmlDocument.CreateElement("SuperBill")


        With lXmlElement
            .SetAttribute("SuperBillId", SuperBill.SuperBillId)
            .SetAttribute("SuperBillName", SuperBill.SuperBillName)
            .SetAttribute("ICDSortBy", SuperBill.ICDSortBy)
            .SetAttribute("ICDSortOrder", SuperBill.ICDSortOrder)
            .SetAttribute("CPTSortBy", SuperBill.CPTSortBy)
            .SetAttribute("CPTSortOrder", SuperBill.CPTSortOrder)
            .SetAttribute("CPTSortOrder", SuperBill.CPTSortOrder)
            .SetAttribute("IsDeleted", "N")
        End With

        lXmlDocument.DocumentElement.AppendChild(lXmlElement.CloneNode(True))

        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand("InsertSuperBill", lXmlDocument.InnerXml.ToString)
        Else
            Connection.ExecuteCommand("InsertSuperBill", lXmlDocument.InnerXml.ToString)
        End If

    End Sub
    ''' <summary>
    ''' Update Record unconditional
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub UpdateRecord()
        Dim lCondition As String

        lCondition = "And SuperBillID = " & Me.SuperBill.SuperBillId
        UpdateRecord(lCondition)

    End Sub
    Public Sub UpdateRecord(ByVal lCondition As String)

        Dim lQuery As String

        With Me.SuperBill
            lQuery = "Update SuperBill Set " _
                    & "SuperBillName ='" & .SuperBillName & "', " _
                    & "ICDSortBy ='" & .ICDSortBy & "', " _
                    & "ICDSortOrder ='" & .ICDSortOrder & "', " _
                    & "CPTSortBy ='" & .CPTSortBy & "', " _
                    & "CPTSortOrder ='" & .CPTSortOrder & "' " _
                    & "Where 1 = 1 " _
                    & lCondition

        End With

        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand(lQuery)
        Else
            Connection.ExecuteCommand(lQuery)
        End If
    End Sub
    ''' <summary>
    ''' Get Single Record By Primary Key
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetRecordByID() As Boolean
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "SuperBill"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = "And SuperBillID = " & SuperBill.SuperBillId

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("SelectAllRecords", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
        End If


        With lDs.Tables(0)
            If .Rows.Count > 0 Then
                Me.SuperBill.SuperBillId = .Rows(0)("SuperBillId")
                Me.SuperBill.SuperBillName = .Rows(0)("SuperBillName")
                Me.SuperBill.ICDSortBy = .Rows(0)("ICDSortBy")
                Me.SuperBill.ICDSortOrder = .Rows(0)("ICDSortOrder")
                Me.SuperBill.CPTSortBy = .Rows(0)("CPTSortBy")
                Me.SuperBill.CPTSortOrder = .Rows(0)("CPTSortOrder")

                Return True
            End If
        End With

        Return False

    End Function

    Public Function GetUniqueId(ByVal lCondition As String) As Integer
        Dim lSpParameter(2) As SpParameter
        Dim lDs As New DataSet()
        Dim lID As Integer

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "SuperBill"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = lCondition

        lSpParameter(2).ParameterName = "@Id"
        lSpParameter(2).ParameterType = ParameterType.Varchar
        lSpParameter(2).ParameterValue = "SuperBillId"

        If Connection.IsTransactionAlive() Then
            lID = Connection.ExecuteTransactionScalarCommand("GetUniqueId", lSpParameter)
        Else
            lID = Connection.ExecuteScalarQuery("GetUniqueId", lSpParameter)
        End If

        Return lID

    End Function


    Public Function GetSuperBillHeader(ByVal lCondition As String, ByVal pTableName As String) As System.Data.DataSet
        Dim lQuery As String
        Dim lDs As New DataSet()


        'lQuery = "Select SB.*,cInfo.ClinicName, (cInfo.AddressLine1 + ' ' +  cInfo.AddressLine2)  As ClinicAddress, " _
        '       & "cInfo.City As ClinicCity, State.Abbr As ClinicState, cInfo.ZipCode As ClinicZipCode, 'Prescriber Name' As PrescriberName " _
        '       & "From ClinicInfo cInfo, State, SuperBill SB " _
        '       & "Where cInfo.StateId = State.StateId " _
        '       & "And SB.SuperBillId = " & SuperBill.SuperBillId & " " _
        '       & lCondition

        lQuery = "Select SB.*,cInfo.ClinicName, (cInfo.AddressLine1 + ' ' +  cInfo.AddressLine2)  As ClinicAddress," _
                & "cInfo.City As ClinicCity, State.Abbr As ClinicState, " _
                & "ClinicZipCode=case  LEN(cInfo.ZipCode) when 9 then SUBSTRING(cInfo.ZipCode,1,5) + '-' + SUBSTRING(cInfo.ZipCode,6,9) else SUBSTRING(cInfo.ZipCode,1,5) end," _
                & "PSB.PatientName As PrescriberName," _
                & "PSB.CopayAmount,PSB.PaymentMethod,PSB.ChequeNumber,PSB.ChequeDate,Test=(select LastVisitDate=convert(varchar,max(DateofService),101) from patientsuperbill where patientid=PSB.PatientId and patientsuperbillid < PSB.PatientSuperBillID group by PSB.PatientId)  " _
                & "From ClinicInfo cInfo, State,SuperBill SB " _
                & "inner join PatientSuperBill PSB on  SB.SuperBillId = PSB.SuperBillTemplateID " _
                & "Where cInfo.StateId = State.StateId " _
                & "And SB.SuperBillId = " & SuperBill.SuperBillId & " " & lCondition

        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''CHANGE LOG''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        'NAME: FARAZ AHMED
        'DATE: 28TH SEPT 2008
        'DESCRIPTION: REMOVED THE PATIENTSUPERBILLID CONDITION FROM WHERE CLAUSE BECAUSE THIS METHOD WAS BEING CALLED FROM SBTEMPLATEPRINT.ASPX

        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''



        lDs = Connection.ExecuteReportQuery(lQuery, pTableName)

        Return lDs

    End Function

    Public Function GetSuperBillHeaderForTemplate(ByVal lCondition As String, ByVal pTableName As String) As System.Data.DataSet
        Dim lQuery As String
        Dim lDs As New DataSet()


        lQuery = "Select SB.*,cInfo.ClinicName, (cInfo.AddressLine1 + ' ' +  cInfo.AddressLine2)  As ClinicAddress, " _
               & "cInfo.City As ClinicCity, State.Abbr As ClinicState, SUBSTRING(cInfo.ZipCode,1,5) + '-' + SUBSTRING(cInfo.ZipCode,6,9) As ClinicZipCode, 'Prescriber Name' As PrescriberName " _
               & "From ClinicInfo cInfo, State, SuperBill SB " _
               & "Where cInfo.StateId = State.StateId " _
               & "And SB.SuperBillId = " & SuperBill.SuperBillId & " " _
               & lCondition





        lDs = Connection.ExecuteReportQuery(lQuery, pTableName)

        Return lDs

    End Function

    Public Function GetModifiers() As System.Data.DataSet
        Dim lQuery As String = String.Empty
        Dim lds As DataSet
        lQuery = "Select ModifierID,ModifierName from Modifier"


        If Connection.IsTransactionAlive() Then
            lds = Connection.ExecuteTransactionQuery(lQuery)
        Else
            lds = Connection.ExecuteQuery(lQuery)
        End If

        Return lds
    End Function

    Public Function GetFeesForCPT(ByVal pFavInsuranceId As String, ByVal pCPTCode As String) As DataSet
        Dim lQuery As String = ""
        Dim lds As New DataSet
        Try
            lQuery = "SELECT top 1 Fees=isNull(Fee,0),FeeSchedulehdr.ID,CompanyName,FavInsuranceId,CreateDate,ModifiedDate,hdrID,CPTCode,Description," _
                    & " Locality,Modifiers FROM FeeScheduledtl,FeeSchedulehdr where FeeSchedulehdr.ID = FeeScheduledtl.hdrID and " _
                    & "FavInsuranceId=" & pFavInsuranceId & " and CPTCode='" & pCPTCode & "' and Modifiers=''"
            If Connection.IsTransactionAlive() Then
                lds = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lds = Connection.ExecuteQuery(lQuery)
            End If
            Return lds
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

#End Region

End Class