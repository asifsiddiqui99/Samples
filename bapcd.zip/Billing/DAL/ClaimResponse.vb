Imports Microsoft.VisualBasic
Public Class ResponsePaymentDetail
    Private mItemDate As String = ""
    Private mItem As String = ""
    Private mAmount As String = ""

    Public Property ItemDate() As String
        Get
            Return mItemDate
        End Get
        Set(ByVal value As String)
            mItemDate = value
        End Set
    End Property

    Public Property Item() As String
        Get
            Return mItem
        End Get
        Set(ByVal value As String)
            mItem = value
        End Set
    End Property

    Public Property Amount() As String
        Get
            Return mAmount
        End Get
        Set(ByVal value As String)
            mAmount = value
        End Set
    End Property
End Class

Public Class ResponsePaymentDetailColl
    Inherits CollectionBase

    Public Function Add(ByVal pResponsePaymentDetail As ResponsePaymentDetail) As Integer
        Return List.Add(pResponsePaymentDetail)
    End Function

    Public Sub Remove(ByVal pResponsePaymentDetail As ResponsePaymentDetail)
        Dim lIndex As Integer

        lIndex = IndexOf(pResponsePaymentDetail)

        If lIndex > -1 Then
            List.RemoveAt(lIndex)
        End If

    End Sub

    Default Public Property Item(ByVal Index As Integer) As ResponsePaymentDetail
        Get
            Return CType(List.Item(Index), ResponsePaymentDetail)
        End Get
        Set(ByVal Value As ResponsePaymentDetail)
            List.Item(Index) = Value
        End Set
    End Property

    Public Shadows Function Count() As Integer
        Return List.Count
    End Function

    Public Function IndexOf(ByVal obj As Object) As Integer
        Dim lIndex As Integer = 0
        Dim lFound As Integer = 0

        For Each lObj As Object In List
            lFound = CType(lObj, ResponsePaymentDetail).ItemDate.CompareTo(CType(obj, ResponsePaymentDetail).ItemDate)
            If lFound = 0 Then
                Return lIndex
            End If
            lIndex += 1
        Next
        Return -1

    End Function



End Class


Public Class ClaimResponseDB

#Region "Fields"
    Private mClaimDate As String = ""
    Private mPayerName As String = ""
    Private mPayerAddress As String = ""
    Private mPayerCityStateZip As String = ""
    Private mPayTo As String = ""
    Private mPaymentAmount As String = ""
    Private mPayeeName As String = ""
    Private mPayeeAddress As String = ""
    Private mPayeeCityStateZip As String = ""
    Private mPatientControlNumber As String = ""
    Private mTransmissionDate As String = ""
    Private mPayerControlNumber As String = ""
#End Region

    Public Property ClaimDate() As String
        Get
            Return mClaimDate
        End Get
        Set(ByVal value As String)
            mClaimDate = value
        End Set
    End Property

    Public Property PayerName() As String
        Get
            Return mPayerName
        End Get
        Set(ByVal value As String)
            mPayerName = value
        End Set
    End Property

    Public Property PayerAddress() As String
        Get
            Return mPayerAddress
        End Get
        Set(ByVal value As String)
            mPayerAddress = value
        End Set
    End Property

    Public Property PayerCityStateZip() As String
        Get
            Return mPayerCityStateZip
        End Get
        Set(ByVal value As String)
            mPayerCityStateZip = value
        End Set
    End Property

    Public Property PayTo() As String
        Get
            Return mPayTo
        End Get
        Set(ByVal value As String)
            mPayTo = value
        End Set
    End Property

    Public Property PaymentAmount() As String
        Get
            Return mPaymentAmount
        End Get
        Set(ByVal value As String)
            mPaymentAmount = value
        End Set
    End Property

    Public Property PayeeName() As String
        Get
            Return mPayeeName
        End Get
        Set(ByVal value As String)
            mPayeeName = value
        End Set
    End Property

    Public Property PayeeAddress() As String
        Get
            Return mPayeeAddress
        End Get
        Set(ByVal value As String)
            mPayeeAddress = value
        End Set
    End Property

    Public Property PayeeCityStateZip() As String
        Get
            Return mPayeeCityStateZip
        End Get
        Set(ByVal value As String)
            mPayeeCityStateZip = value
        End Set
    End Property
    Public Property PatientControlNumber() As String
        Get
            Return mPatientControlNumber
        End Get
        Set(ByVal value As String)
            mPatientControlNumber = value
        End Set
    End Property
    Public Property TransmissionDate() As String
        Get
            Return mTransmissionDate
        End Get
        Set(ByVal value As String)
            mTransmissionDate = value
        End Set
    End Property
    Public Property PayerControlNumber() As String
        Get
            Return mPayerControlNumber
        End Get
        Set(ByVal value As String)
            mPayerControlNumber = value
        End Set
    End Property
    
End Class
