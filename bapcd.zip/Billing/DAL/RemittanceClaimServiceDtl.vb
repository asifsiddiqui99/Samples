Imports Microsoft.VisualBasic
Public Class RemittanceClaimServiceDtlDB

#Region "Fields"

    Private mRemittanceClaimId As String = ""
    Private mDateOfServiceFrom As String = ""
    Private mDateOfServiceTo As String = ""
    Private mUnit As String = "1"
    Private mCptCode As String = ""
    Private mChargedAmount As String = "0"
    Private mAllowedAmount As String = "0"
    Private mDeductibleAmount As String = "0"
    Private mCoInsuranceAmount As String = "0"
    Private mCoPayAmount As String = "0"
    Private mLateFillingRedAmount As String = "0"
    Private mOtherAdjustmentAmount As String = "0"
    Private mServiceAdjustmentCodes As String = ""
    Private mProviderPaidAmount As String = "0"
    Private mRemarkCodes As String = ""
    Private mModifierA As String = ""
    Private mModifierB As String = ""
    Private mModifierC As String = ""
    Private mModifierD As String = ""
    Private mRemittanceId As Integer = 0
#End Region

#Region "Properties"
    
    Public Property RemittanceClaimId() As String
        Get
            Return mRemittanceClaimId
        End Get
        Set(ByVal value As String)
            mRemittanceClaimId = value
        End Set
    End Property
    Public Property DateOfServiceFrom() As String
        Get
            Return mDateOfServiceFrom
        End Get
        Set(ByVal value As String)
            mDateOfServiceFrom = value
        End Set
    End Property
    Public Property DateOfServiceTo() As String
        Get
            Return mDateOfServiceTo
        End Get
        Set(ByVal value As String)
            mDateOfServiceTo = value
        End Set
    End Property
    Public Property Unit() As String
        Get
            Return mUnit
        End Get
        Set(ByVal value As String)
            mUnit = value
        End Set
    End Property
    Public Property CptCode() As String
        Get
            Return mCptCode
        End Get
        Set(ByVal value As String)
            mCptCode = value
        End Set
    End Property
    Public Property ChargedAmount() As String
        Get
            Return mChargedAmount
        End Get
        Set(ByVal value As String)
            mChargedAmount = value
        End Set
    End Property
    Public Property AllowedAmount() As String
        Get
            Return mAllowedAmount
        End Get
        Set(ByVal value As String)
            mAllowedAmount = value
        End Set
    End Property
    Public Property DeductibleAmount() As String
        Get
            Return mDeductibleAmount
        End Get
        Set(ByVal value As String)
            mDeductibleAmount = value
        End Set
    End Property
    Public Property CoInsuranceAmount() As String
        Get
            Return mCoInsuranceAmount
        End Get
        Set(ByVal value As String)
            mCoInsuranceAmount = value
        End Set
    End Property
    Public Property CoPayAmount() As String
        Get
            Return mCoPayAmount
        End Get
        Set(ByVal value As String)
            mCoPayAmount = value
        End Set
    End Property
    Public Property LateFillingRedAmount() As String
        Get
            Return mLateFillingRedAmount
        End Get
        Set(ByVal value As String)
            mLateFillingRedAmount = value
        End Set
    End Property
    Public Property OtherAdjustmentAmount() As String
        Get
            Return mOtherAdjustmentAmount
        End Get
        Set(ByVal value As String)
            mOtherAdjustmentAmount = value
        End Set
    End Property
    Public Property ServiceAdjustmentCodes() As String
        Get
            Return mServiceAdjustmentCodes
        End Get
        Set(ByVal value As String)
            mServiceAdjustmentCodes = value
        End Set
    End Property
    Public Property ProviderPaidAmount() As String
        Get
            Return mProviderPaidAmount
        End Get
        Set(ByVal value As String)
            mProviderPaidAmount = value
        End Set
    End Property
    Public Property RemarkCodes() As String
        Get
            Return mRemarkCodes
        End Get
        Set(ByVal value As String)
            mRemarkCodes = value
        End Set
    End Property
    Public Property ModifierA() As String
        Get
            Return mModifierA
        End Get
        Set(ByVal value As String)
            mModifierA = value
        End Set
    End Property
    Public Property ModifierB() As String
        Get
            Return mModifierB
        End Get
        Set(ByVal value As String)
            mModifierB = value
        End Set
    End Property
    Public Property ModifierC() As String
        Get
            Return mModifierC
        End Get
        Set(ByVal value As String)
            mModifierC = value
        End Set
    End Property
    Public Property ModifierD() As String
        Get
            Return mModifierD
        End Get
        Set(ByVal value As String)
            mModifierD = value
        End Set
    End Property
    Public Property RemittanceId() As Integer
        Get
            Return mRemittanceId
        End Get
        Set(ByVal value As Integer)
            mRemittanceId = value
        End Set
    End Property
#End Region

End Class
Public Class RemittanceClaimServiceDtl
    Implements IDetail
#Region "Fields"
    Private mConnection As Connection
    Private mConnectionString As String
    Private mRemittanceClaimServiceDtlDB As New RemittanceClaimServiceDtlDB
#End Region

#Region "Property"

    Public Property RemittanceClaimServiceDtl() As RemittanceClaimServiceDtlDB
        Get
            Return mRemittanceClaimServiceDtlDB
        End Get
        Set(ByVal value As RemittanceClaimServiceDtlDB)
            mRemittanceClaimServiceDtlDB = value
        End Set
    End Property
    Public ReadOnly Property Connection() As ElixirLibrary.Connection Implements IDetail.Connection
        Get
            Return mConnection
        End Get
    End Property

    Public ReadOnly Property ConnectionString() As String Implements IDetail.ConnectionString
        Get
            Return mConnectionString
        End Get
    End Property

#End Region

#Region "Constructor"

    Public Sub New(ByVal pConnectionString As String)
        If pConnectionString = "" Then
            Throw New ArgumentException("ConnectionString can not be empty")
        End If
        mConnectionString = pConnectionString
        mConnection = New Connection(mConnectionString)

    End Sub


    Public Sub New(ByVal pConnection As Connection)
        If pConnection Is Nothing Then
            Throw New ArgumentException("Connection can not be empty")
        End If
        mConnection = pConnection
    End Sub
#End Region

#Region "Methods"
    Public Sub InsertRecord() Implements IDetail.InsertRecord
        Dim lXmlDocument As New XmlDocument
        Dim lXmlElement As XmlElement

        lXmlDocument.LoadXml("<RemittanceClaimServiceDtls></RemittanceClaimServiceDtls>")
        lXmlElement = lXmlDocument.CreateElement("RemittanceClaimServiceDtl")

        With lXmlElement

            .SetAttribute("RemittanceClaimId", RemittanceClaimServiceDtl.RemittanceClaimId)
            .SetAttribute("DateOfServiceFrom", RemittanceClaimServiceDtl.DateOfServiceFrom)
            .SetAttribute("DateOfServiceTo", RemittanceClaimServiceDtl.DateOfServiceTo)
            .SetAttribute("Unit", RemittanceClaimServiceDtl.Unit)
            .SetAttribute("CptCode", RemittanceClaimServiceDtl.CptCode)
            .SetAttribute("ChargedAmount", RemittanceClaimServiceDtl.ChargedAmount)
            .SetAttribute("AllowedAmount", RemittanceClaimServiceDtl.AllowedAmount)
            .SetAttribute("DeductibleAmount", RemittanceClaimServiceDtl.DeductibleAmount)
            .SetAttribute("CoInsuranceAmount", RemittanceClaimServiceDtl.CoInsuranceAmount)
            .SetAttribute("CoPayAmount", RemittanceClaimServiceDtl.CoPayAmount)
            .SetAttribute("LateFillingRedAmount", RemittanceClaimServiceDtl.LateFillingRedAmount)
            .SetAttribute("OtherAdjustmentAmount", RemittanceClaimServiceDtl.OtherAdjustmentAmount)
            .SetAttribute("ServiceAdjustmentCodes", RemittanceClaimServiceDtl.ServiceAdjustmentCodes)
            .SetAttribute(("ProviderPaidAmount"), RemittanceClaimServiceDtl.ProviderPaidAmount)
            .SetAttribute(("RemarkCodes"), RemittanceClaimServiceDtl.RemarkCodes)
            .SetAttribute(("ModifierA"), RemittanceClaimServiceDtl.ModifierA)
            .SetAttribute(("ModifierB"), RemittanceClaimServiceDtl.ModifierB)
            .SetAttribute(("ModifierC"), RemittanceClaimServiceDtl.ModifierC)
            .SetAttribute(("ModifierD"), RemittanceClaimServiceDtl.ModifierD)
            .SetAttribute(("RemittanceId"), RemittanceClaimServiceDtl.RemittanceId)
        End With

        lXmlDocument.DocumentElement.AppendChild(lXmlElement.CloneNode(True))

        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand("InsertRemittanceClaimServiceDtl", lXmlDocument.InnerXml.ToString)
        Else
            Connection.ExecuteCommand("InsertRemittanceClaimServiceDtl", lXmlDocument.InnerXml.ToString)
        End If
    End Sub
    Public Sub InsertRecord(ByVal pXML As String)
        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand("InsertRemittanceClaimServiceDtl", pXML)
        Else
            Connection.ExecuteCommand("InsertRemittanceClaimServiceDtl", pXML)
        End If
    End Sub
    Public Function GetRecordByID() As Boolean Implements IDetail.GetRecordByID
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "RemittanceClaimServiceDtl"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = "And RemittanceClaimId = " & Me.RemittanceClaimServiceDtl.RemittanceClaimId

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("SelectAllRecords", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
        End If


        With lDs.Tables(0)
            If .Rows.Count > 0 Then

                Me.RemittanceClaimServiceDtl.RemittanceClaimId = .Rows(0)("RemittanceClaimId")
                Me.RemittanceClaimServiceDtl.DateOfServiceFrom = .Rows(0)("DateOfServiceFrom")
                Me.RemittanceClaimServiceDtl.DateOfServiceTo = .Rows(0)("DateOfServiceTo")
                Me.RemittanceClaimServiceDtl.Unit = .Rows(0)("Unit")
                Me.RemittanceClaimServiceDtl.CptCode = .Rows(0)("CptCode")
                Me.RemittanceClaimServiceDtl.ChargedAmount = .Rows(0)("ChargedAmount")
                Me.RemittanceClaimServiceDtl.AllowedAmount = .Rows(0)("AllowedAmount")
                Me.RemittanceClaimServiceDtl.DeductibleAmount = .Rows(0)("DeductibleAmount")
                Me.RemittanceClaimServiceDtl.CoInsuranceAmount = .Rows(0)("CoInsuranceAmount")
                Me.RemittanceClaimServiceDtl.CoPayAmount = .Rows(0)("CoPayAmount")
                Me.RemittanceClaimServiceDtl.LateFillingRedAmount = .Rows(0)("LateFillingRedAmount")
                Me.RemittanceClaimServiceDtl.OtherAdjustmentAmount = .Rows(0)("OtherAdjustmentAmount")
                Me.RemittanceClaimServiceDtl.ServiceAdjustmentCodes = .Rows(0)("ServiceAdjustmentCodes")
                Me.RemittanceClaimServiceDtl.ProviderPaidAmount = .Rows(0)("ProviderPaidAmount")
                Me.RemittanceClaimServiceDtl.RemarkCodes = .Rows(0)("RemarkCodes")
                Me.RemittanceClaimServiceDtl.ModifierA = .Rows(0)("ModifierA")
                Me.RemittanceClaimServiceDtl.ModifierB = .Rows(0)("ModifierB")
                Me.RemittanceClaimServiceDtl.ModifierC = .Rows(0)("ModifierC")
                Me.RemittanceClaimServiceDtl.ModifierD = .Rows(0)("ModifierD")
                Me.RemittanceClaimServiceDtl.RemittanceId = .Rows(0)("RemittanceId")

                Return True
            End If
        End With

        Return False
    End Function

    Public Sub DeleteRecord(ByVal lCondition As String) Implements IDetail.DeleteRecord
    End Sub
    Public Sub DeleteRecordByID() Implements IDetail.DeleteRecordByID  
    End Sub
    Public Function GetAllRecords() As System.Data.DataSet Implements IDetail.GetAllRecords
        Dim lDs As New DataSet()
        Return lDs
    End Function
    Public Function GetAllRecords(ByVal lCondition As String) As System.Data.DataSet Implements IDetail.GetAllRecords
        Dim lDs As New DataSet()
        Return lDs
    End Function
    Public Sub UpdateRecord() Implements IDetail.UpdateRecord
    End Sub
    Public Sub UpdateRecord(ByVal lCondition As String) Implements IDetail.UpdateRecord
    End Sub
    Public Function GetRecordByIDExtended() As Boolean
        Return True
    End Function
    Public Function GetUniqueId() As Boolean
        Return True
    End Function
    Public Sub LogicalDelete()
    End Sub

#End Region
End Class
