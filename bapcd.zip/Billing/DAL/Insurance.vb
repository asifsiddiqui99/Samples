Imports Microsoft.VisualBasic
Imports System.xml

Public Class InsuranceDB

    Private mPayerName As String = ""
    Private mPayerID As String = ""
    Private mState As String = ""
    Private mEnrollment As String = ""
    Private mPayerStatus As String = ""
    Private mType As String = ""
    Private mFavouriteInsuranceID As Integer = 0
    ''
    Private mInsuranceID As Integer = 0
    Private mCompanyName As String = ""
    Private mAddressLine1 As String = ""
    Private mAddressLine2 As String = ""
    Private mCity As String = ""
    Private mZipCode As String = ""
    Private mContactName As String = ""
    Private mInsuranceType As String = ""
    Private mWorkPhone As String = ""
    Private mFax As String = ""
    Private mEmail As String = ""
    Private mBillType As String = ""
    Private mServingState As String = ""
    Private mPriorAuthorizationNumber As String = ""


    Public Sub New()
        mPayerName = String.Empty
        mPayerID = String.Empty
        mState = String.Empty
        mEnrollment = String.Empty
        mPayerStatus = String.Empty
        mType = String.Empty
        mFavouriteInsuranceID = 0

        mCompanyName = String.Empty
        mAddressLine1 = String.Empty
        mAddressLine2 = String.Empty
        mCity = String.Empty
        mZipCode = String.Empty
        mContactName = String.Empty
        mInsuranceType = String.Empty
        mWorkPhone = String.Empty
        mFax = String.Empty
        mEmail = String.Empty
        mBillType = String.Empty
        mServingState = String.Empty
        mPriorAuthorizationNumber = String.Empty
    End Sub
   

#Region "Properties"

    Public Property PayerName() As String
        Get
            Return mPayerName
        End Get
        Set(ByVal value As String)
            mPayerName = value
        End Set
    End Property

    Public Property PayerID() As String
        Get
            Return mPayerID
        End Get
        Set(ByVal value As String)
            mPayerID = value
        End Set
    End Property
    Public Property State() As String
        Get
            Return mState
        End Get
        Set(ByVal value As String)
            mState = value
        End Set
    End Property

    Public Property Enrollment() As String
        Get
            Return mEnrollment
        End Get
        Set(ByVal value As String)
            mEnrollment = value
        End Set
    End Property

    Public Property PayerStatus() As String
        Get
            Return mPayerStatus
        End Get
        Set(ByVal value As String)
            mPayerStatus = value
        End Set
    End Property

    Public Property Type() As String
        Get
            Return mType
        End Get
        Set(ByVal value As String)
            mType = value
        End Set
    End Property


    Public Property FavouriteInsuranceID() As Integer
        Get
            Return mFavouriteInsuranceID
        End Get
        Set(ByVal value As Integer)
            mFavouriteInsuranceID = value
        End Set
    End Property

    Public Property InsuranceID() As Integer
        Get
            Return mInsuranceID
        End Get
        Set(ByVal value As Integer)
            mInsuranceID = value
        End Set
    End Property

    Public Property CompanyName() As String
        Get
            Return mCompanyName
        End Get
        Set(ByVal value As String)
            mCompanyName = value
        End Set
    End Property

    Public Property AddressLine1() As String
        Get
            Return mAddressLine1
        End Get
        Set(ByVal value As String)
            mAddressLine1 = value
        End Set
    End Property


    Public Property AddressLine2() As String
        Get
            Return mAddressLine2
        End Get
        Set(ByVal value As String)
            mAddressLine2 = value
        End Set
    End Property


    Public Property City() As String
        Get
            Return mCity
        End Get
        Set(ByVal value As String)
            mCity = value
        End Set
    End Property


    Public Property ZipCode() As String
        Get
            Return mZipCode
        End Get
        Set(ByVal value As String)
            mZipCode = value
        End Set
    End Property

    Public Property ContactName() As String
        Get
            Return mContactName
        End Get
        Set(ByVal value As String)
            mContactName = value
        End Set
    End Property


    Public Property InsuranceType() As String
        Get
            Return mInsuranceType
        End Get
        Set(ByVal value As String)
            mInsuranceType = value
        End Set
    End Property


    Public Property WorkPhone() As String
        Get
            Return mWorkPhone
        End Get
        Set(ByVal value As String)
            mWorkPhone = value
        End Set
    End Property

    Public Property Fax() As String
        Get
            Return mFax
        End Get
        Set(ByVal value As String)
            mFax = value
        End Set
    End Property

    Public Property Email() As String
        Get
            Return mEmail
        End Get
        Set(ByVal value As String)
            mEmail = value
        End Set
    End Property

    Public Property BillType() As String
        Get
            Return mBillType
        End Get
        Set(ByVal value As String)
            mBillType = value
        End Set
    End Property

    Public Property ServingState() As String
        Get
            Return mServingState
        End Get
        Set(ByVal value As String)
            mServingState = value
        End Set
    End Property

    Public Property PriorAuthorizationNumber() As String
        Get
            Return mPriorAuthorizationNumber
        End Get
        Set(ByVal value As String)
            mPriorAuthorizationNumber = value
        End Set
    End Property


#End Region

End Class

Public Class Insurance

    Private mInsuranceDB As InsuranceDB
    Private mConnection As Connection

#Region "Constructors"

    Public Sub New()
        mInsuranceDB = New InsuranceDB
        mConnection = New Connection
    End Sub

    Public Sub New(ByVal pConnectionString As String)
        mInsuranceDB = New InsuranceDB
        mConnection = New Connection(pConnectionString)
    End Sub
    Public Sub New(ByVal pConnection As Connection)
        If pConnection Is Nothing Then
            Throw New ArgumentException("Connection can not be empty")
        End If

        mConnection = pConnection
    End Sub
#End Region

#Region "Properties"

    Public Property InsuranceDB() As InsuranceDB
        Get
            Return mInsuranceDB
        End Get
        Set(ByVal value As InsuranceDB)
            mInsuranceDB = value
        End Set
    End Property

    Public Property Connection() As Connection
        Get
            Return mConnection
        End Get
        Set(ByVal value As Connection)
            mConnection = value
        End Set
    End Property

#End Region


    Public Function GetAllRecords(ByVal pCondition As String) As DataSet
        Dim lSpParameter(1) As SpParameter
        Dim lDataSet As DataSet = Nothing

        Try

            lSpParameter(0) = New SpParameter
            With lSpParameter(0)
                .ParameterName = "@Table"
                .ParameterType = ParameterType.Varchar
                .ParameterValue = "FavouriteInsurance"
            End With

            lSpParameter(1) = New SpParameter
            With lSpParameter(1)
                .ParameterName = "@Cond"
                .ParameterType = ParameterType.Varchar
                .ParameterValue = pCondition
            End With

            lDataSet = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
            Return lDataSet

        Catch ex As Exception
            Return Nothing
        End Try
    End Function


    
    '' By Fareed to bind records for Patient Insurace Combo 
    Public Function SelectTopTenRecords() As DataSet
        Dim lQuery As String = ""
        Dim lDs As DataSet = Nothing

        Try
            lQuery = "SELECT TOP(10) FavouriteInsuranceID, cast(FavouriteInsuranceID as varchar) + '|' + cast(PayerID as varchar) + '|' + cast(WorkPhone as varchar) as Hidden, InsuranceID, CompanyName, PayerID, rtrim(ltrim(AddressLine1))+' '+rtrim(ltrim(AddressLine2))+' '+City +' '+ State  as Address,ZipCode,City,State, ContactName, InsuranceType, WorkPhone, Fax, Email, BillType, PriorAuthorizationNumber " _
               & "FROM FavouriteInsurance where IsDelete='N' AND CompanyName like '" + mInsuranceDB.CompanyName + "%' Order by CompanyName"


            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If

        Catch ex As Exception
            Throw New Exception(ex.Message & " : Billing\DAL\Insurance.SelectTopTenRecords() ")
        End Try

        Return lDs
    End Function

    Public Function InsertInsurance() As String

        Dim lQuery As String = String.Empty

        Try
            Dim lDs As New DataSet()
            Dim lInsuranceID As String

            'lQuery = "Select * from FavouriteInsurance where InsuranceID = " & InsuranceDB.InsuranceID & " And IsDelete='N'"

            'If Connection.IsTransactionAlive() Then
            'lDs = Connection.ExecuteTransactionQuery(lQuery)
            'Else
            'lDs = Connection.ExecuteQuery(lQuery)
            'End If

            'If (lDs.Tables(0).Rows.Count = 0) Then

            Dim lXmlDocument As New XmlDocument
            Dim lXmlElement As XmlElement

            lXmlDocument.LoadXml("<Insurances></Insurances>")
            lXmlElement = lXmlDocument.CreateElement("Insurance")

            With lXmlElement
                .SetAttribute("InsuranceID", InsuranceDB.InsuranceID)
                .SetAttribute("CompanyName", InsuranceDB.CompanyName)
                .SetAttribute("PayerID", InsuranceDB.PayerID)
                .SetAttribute("AddressLine1", InsuranceDB.AddressLine1)
                .SetAttribute("AddressLine2", InsuranceDB.AddressLine2)
                .SetAttribute("City", InsuranceDB.City)
                .SetAttribute("State", InsuranceDB.State)
                .SetAttribute("ZipCode", InsuranceDB.ZipCode)
                .SetAttribute("ContactName", InsuranceDB.ContactName)
                .SetAttribute("InsuranceType", InsuranceDB.InsuranceType)
                .SetAttribute("WorkPhone", InsuranceDB.WorkPhone)
                .SetAttribute("Fax", InsuranceDB.Fax)
                .SetAttribute("Email", InsuranceDB.Email)
                .SetAttribute("BillType", InsuranceDB.BillType)
                .SetAttribute("IsDelete", "N")
                .SetAttribute("PriorAuthorizationNumber", InsuranceDB.PriorAuthorizationNumber)
            End With

            lXmlDocument.DocumentElement.AppendChild(lXmlElement.CloneNode(True))

            'lQuery = "Insert into FavouriteInsurance " & _
            '"values (" & _
            '" " & InsuranceDB.InsuranceID & ", " & _
            '" '" & InsuranceDB.CompanyName & "', " & _
            '" '" & InsuranceDB.PayerID & "', " & _
            '" '" & InsuranceDB.AddressLine1 & "', " & _
            '" '" & InsuranceDB.AddressLine2 & "', " & _
            '" '" & InsuranceDB.City & "', " & _
            '" '" & InsuranceDB.State & "', " & _
            '" '" & InsuranceDB.ZipCode & "', " & _
            '" '" & InsuranceDB.ContactName & "', " & _
            '" '" & InsuranceDB.InsuranceType & "', " & _
            '" '" & InsuranceDB.WorkPhone & "', " & _
            '" '" & InsuranceDB.Fax & "', " & _
            '" '" & InsuranceDB.Email & "', " & _
            '" '" & InsuranceDB.BillType & "', " & _
            '" 'N' " & _
            '")"

            'Connection.ExecuteCommand(lQuery)

            lInsuranceID = Connection.ExecuteScalarCommand("InsertInsurance", lXmlDocument.DocumentElement.OuterXml.ToString)
            Return lInsuranceID

            'Else
            'Return "Insurance Already Exists"
            'End If

        Catch ex As Exception
            Return String.Empty
        End Try

    End Function


    Public Function GetCompanyName(ByVal pCondition As String) As DataSet

        Dim lQuery As String = String.Empty


        Dim lDs As New DataSet()

        lQuery = "Select distinct TOP(10) CompanyName from FavouriteInsurance where 1=1 And IsDelete='N'" & pCondition

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery(lQuery)
        Else
            lDs = Connection.ExecuteQuery(lQuery)
        End If

        Return lDs

    End Function


    Public Function GetInsuranceRecords(ByVal pwhere As String) As DataSet

        Dim lQuery As String = String.Empty


        Dim lDs As New DataSet()

        lQuery = "Select * from FavouriteInsurance where 1=1 And IsDelete = 'N' " & pwhere

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery(lQuery)
        Else
            lDs = Connection.ExecuteQuery(lQuery)
        End If

        Return lDs

    End Function

    Public Function DeleteInsurance() As Boolean

        Dim lQuery As String = String.Empty

        Try
            lQuery = "Update FavouriteInsurance Set IsDelete='Y' where FavouriteInsuranceID=" & InsuranceDB.FavouriteInsuranceID
            Connection.ExecuteCommand(lQuery)
            Return True

        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Function UpdateInsurance() As Boolean

        Dim lQuery As String = String.Empty

        Try
            lQuery = "Update FavouriteInsurance " & _
            "set " & _
            "CompanyName = '" & InsuranceDB.CompanyName & "', " & _
            "PayerID = '" & InsuranceDB.PayerID & "', " & _
            "AddressLine1 = '" & InsuranceDB.AddressLine1 & "', " & _
            "AddressLine2 = '" & InsuranceDB.AddressLine2 & "', " & _
            "City = '" & InsuranceDB.City & "', " & _
            "ContactName = '" & InsuranceDB.ContactName & "', " & _
            "State = '" & InsuranceDB.State & "', " & _
            "ZipCode = '" & InsuranceDB.ZipCode & "', " & _
            "WorkPhone = '" & InsuranceDB.WorkPhone & "', " & _
            "Fax = '" & InsuranceDB.Fax & "', " & _
            "Email = '" & InsuranceDB.Email & "', " & _
            "InsuranceType = '" & InsuranceDB.InsuranceType & "', " & _
            "BillType = '" & InsuranceDB.BillType & "', " & _
            "PriorAuthorizationNumber = '" & InsuranceDB.PriorAuthorizationNumber & "' " & _
            " where " & _
            "FavouriteInsuranceID = " & InsuranceDB.FavouriteInsuranceID


            Connection.ExecuteCommand(lQuery)
            Return True

        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Function GetInsuranceList(ByVal pCondition As String) As DataSet
        Dim lSpParameter(1) As SpParameter
        Dim lDataSet As DataSet = Nothing

        Try

            lSpParameter(0) = New SpParameter
            With lSpParameter(0)
                .ParameterName = "@Table"
                .ParameterType = ParameterType.Varchar
                .ParameterValue = "InsuranceCompany"
            End With

            lSpParameter(1) = New SpParameter
            With lSpParameter(1)
                .ParameterName = "@Cond"
                .ParameterType = ParameterType.Varchar
                .ParameterValue = pCondition
            End With

            lDataSet = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
            Return lDataSet

        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Public Function GetInsuranceListNew(ByVal pCondition As String) As DataSet
        Dim lQuery As String
        Dim lDs As DataSet = Nothing

        Try
            lQuery = "SELECT InsuranceID,PayerName,ServingState,State=isNull(State,''),AddressLine1,AddressLine2,City,ZipCode,PayerID,Enrollment,PayerStatus,[Type] FROM [RxCureMaster].[dbo].[InsuranceCompany] where 1=1 " & pCondition & ""
            
            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If

            Return lDs

        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    'Created By : Talha
    'Purpose : This is used to get all patients Last name for the autocomplte combobox
    Public Function GetCompanyListForCombo(ByVal pSearchString As String) As DataSet
        Dim lQuery As String = ""
        Dim lDS As DataSet = Nothing

        Try
            lQuery = "select CompanyName FROM FavouriteInsurance where CompanyName like '" + pSearchString + "%'"


            If Connection.IsTransactionAlive() Then
                lDS = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDS = Connection.ExecuteQuery(lQuery)
            End If

        Catch ex As Exception

        End Try

        Return lDS
    End Function
    Public Function GetRecordById() As Boolean
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "FavouriteInsurance"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = "And FavouriteInsuranceID = " & Me.InsuranceDB.FavouriteInsuranceID

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("SelectAllRecords", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
        End If


        With lDs.Tables(0)
            If .Rows.Count > 0 Then
                If (Not IsDBNull(.Rows(0)("AddressLine1"))) Then
                    Me.InsuranceDB.AddressLine1 = .Rows(0)("AddressLine1")
                Else
                    Me.InsuranceDB.AddressLine1 = ""
                End If

                If (Not IsDBNull(.Rows(0)("AddressLine2"))) Then
                    Me.InsuranceDB.AddressLine2 = .Rows(0)("AddressLine2")
                Else
                    Me.InsuranceDB.AddressLine2 = ""
                End If

                If (Not IsDBNull(.Rows(0)("BillType"))) Then
                    Me.InsuranceDB.BillType = .Rows(0)("BillType")
                Else
                    Me.InsuranceDB.BillType = ""
                End If

                If (Not IsDBNull(.Rows(0)("City"))) Then
                    Me.InsuranceDB.City = .Rows(0)("City")
                Else
                    Me.InsuranceDB.City = ""
                End If

                If (Not IsDBNull(.Rows(0)("CompanyName"))) Then
                    Me.InsuranceDB.CompanyName = .Rows(0)("CompanyName")
                Else
                    Me.InsuranceDB.CompanyName = ""
                End If

                If (Not IsDBNull(.Rows(0)("ContactName"))) Then
                    Me.InsuranceDB.ContactName = .Rows(0)("ContactName")
                Else
                    Me.InsuranceDB.ContactName = ""
                End If

                If (Not IsDBNull(.Rows(0)("Email"))) Then
                    Me.InsuranceDB.Email = .Rows(0)("Email")
                Else
                    Me.InsuranceDB.Email = ""
                End If


                If (Not IsDBNull(.Rows(0)("FavouriteInsuranceID"))) Then
                    Me.InsuranceDB.FavouriteInsuranceID = .Rows(0)("FavouriteInsuranceID")
                Else
                    Me.InsuranceDB.FavouriteInsuranceID = ""
                End If

                If (Not IsDBNull(.Rows(0)("Fax"))) Then
                    Me.InsuranceDB.Fax = .Rows(0)("Fax")
                Else
                    Me.InsuranceDB.Fax = ""
                End If

                If (Not IsDBNull(.Rows(0)("InsuranceID"))) Then
                    Me.InsuranceDB.InsuranceID = .Rows(0)("InsuranceID")
                Else
                    Me.InsuranceDB.InsuranceID = ""
                End If

                If (Not IsDBNull(.Rows(0)("InsuranceType"))) Then
                    Me.InsuranceDB.InsuranceType = .Rows(0)("InsuranceType")
                Else
                    Me.InsuranceDB.InsuranceType = ""
                End If

                If (Not IsDBNull(.Rows(0)("PayerID"))) Then
                    Me.InsuranceDB.PayerID = .Rows(0)("PayerID")
                Else
                    Me.InsuranceDB.PayerID = ""
                End If


                If (Not IsDBNull(.Rows(0)("State"))) Then
                    Me.InsuranceDB.State = .Rows(0)("State")
                Else
                    Me.InsuranceDB.State = ""
                End If


                If (Not IsDBNull(.Rows(0)("WorkPhone"))) Then
                    Me.InsuranceDB.WorkPhone = .Rows(0)("WorkPhone")
                Else
                    Me.InsuranceDB.WorkPhone = ""
                End If

                If (Not IsDBNull(.Rows(0)("ZipCode"))) Then
                    Me.InsuranceDB.ZipCode = .Rows(0)("ZipCode")
                Else
                    Me.InsuranceDB.ZipCode = ""
                End If

                If (Not IsDBNull(.Rows(0)("PriorAuthorizationNumber"))) Then
                    Me.InsuranceDB.PriorAuthorizationNumber = .Rows(0)("PriorAuthorizationNumber")
                Else
                    Me.InsuranceDB.PriorAuthorizationNumber = ""
                End If


                Return True
            End If
        End With

        Return False
    End Function

    Public Function GetRecordById(ByVal lDT As DataTable) As Boolean

        With lDT
            If .Rows.Count > 0 Then
                If (Not IsDBNull(.Rows(0)("AddressLine1"))) Then
                    Me.InsuranceDB.AddressLine1 = .Rows(0)("AddressLine1")
                Else
                    Me.InsuranceDB.AddressLine1 = ""
                End If

                If (Not IsDBNull(.Rows(0)("AddressLine2"))) Then
                    Me.InsuranceDB.AddressLine2 = .Rows(0)("AddressLine2")
                Else
                    Me.InsuranceDB.AddressLine2 = ""
                End If

                If (Not IsDBNull(.Rows(0)("BillType"))) Then
                    Me.InsuranceDB.BillType = .Rows(0)("BillType")
                Else
                    Me.InsuranceDB.BillType = ""
                End If

                If (Not IsDBNull(.Rows(0)("City"))) Then
                    Me.InsuranceDB.City = .Rows(0)("City")
                Else
                    Me.InsuranceDB.City = ""
                End If

                If (Not IsDBNull(.Rows(0)("CompanyName"))) Then
                    Me.InsuranceDB.CompanyName = .Rows(0)("CompanyName")
                Else
                    Me.InsuranceDB.CompanyName = ""
                End If

                If (Not IsDBNull(.Rows(0)("ContactName"))) Then
                    Me.InsuranceDB.ContactName = .Rows(0)("ContactName")
                Else
                    Me.InsuranceDB.ContactName = ""
                End If

                If (Not IsDBNull(.Rows(0)("Email"))) Then
                    Me.InsuranceDB.Email = .Rows(0)("Email")
                Else
                    Me.InsuranceDB.Email = ""
                End If


                If (Not IsDBNull(.Rows(0)("FavouriteInsuranceID"))) Then
                    Me.InsuranceDB.FavouriteInsuranceID = .Rows(0)("FavouriteInsuranceID")
                Else
                    Me.InsuranceDB.FavouriteInsuranceID = ""
                End If

                If (Not IsDBNull(.Rows(0)("Fax"))) Then
                    Me.InsuranceDB.Fax = .Rows(0)("Fax")
                Else
                    Me.InsuranceDB.Fax = ""
                End If

                If (Not IsDBNull(.Rows(0)("InsuranceID"))) Then
                    Me.InsuranceDB.InsuranceID = .Rows(0)("InsuranceID")
                Else
                    Me.InsuranceDB.InsuranceID = ""
                End If

                If (Not IsDBNull(.Rows(0)("InsuranceType"))) Then
                    Me.InsuranceDB.InsuranceType = .Rows(0)("InsuranceType")
                Else
                    Me.InsuranceDB.InsuranceType = ""
                End If

                If (Not IsDBNull(.Rows(0)("PayerID"))) Then
                    Me.InsuranceDB.PayerID = .Rows(0)("PayerID")
                Else
                    Me.InsuranceDB.PayerID = ""
                End If


                If (Not IsDBNull(.Rows(0)("State"))) Then
                    Me.InsuranceDB.State = .Rows(0)("State")
                Else
                    Me.InsuranceDB.State = ""
                End If


                If (Not IsDBNull(.Rows(0)("WorkPhone"))) Then
                    Me.InsuranceDB.WorkPhone = .Rows(0)("WorkPhone")
                Else
                    Me.InsuranceDB.WorkPhone = ""
                End If

                If (Not IsDBNull(.Rows(0)("ZipCode"))) Then
                    Me.InsuranceDB.ZipCode = .Rows(0)("ZipCode")
                Else
                    Me.InsuranceDB.ZipCode = ""
                End If

                If (Not IsDBNull(.Rows(0)("PriorAuthorizationNumber"))) Then
                    Me.InsuranceDB.ZipCode = .Rows(0)("PriorAuthorizationNumber")
                Else
                    Me.InsuranceDB.ZipCode = ""
                End If

                Return True
            End If
        End With

        Return False
    End Function
    Public Function GetInsuranceRecordsForPaymentSearch(ByVal pSearchString As String) As DataSet

        Dim lQuery As String = String.Empty



        Dim lDs As New DataSet()

        lQuery = "Select CompanyName As Name,PayerID,AddressLine1 + ',' + AddressLine2 as Address from FavouriteInsurance " _
        & " where IsDelete = 'N' And CompanyName like '" + pSearchString + "%'"



        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery(lQuery)
        Else
            lDs = Connection.ExecuteQuery(lQuery)
        End If

        Return lDs

    End Function
    Public Function GetPatientRecordsForPaymentSearch(ByVal pSearchString As String) As DataSet

        Dim lQuery As String = String.Empty



        Dim lDs As New DataSet()


        lQuery = "Select LastName + ',' + FirstName As Name,PatientID as PayerID,AddressLine1 + ',' + AddressLine2 as Address from Patient " _
        & " where  LastName like '" + pSearchString + "%'"



        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery(lQuery)
        Else
            lDs = Connection.ExecuteQuery(lQuery)
        End If

        Return lDs

    End Function
    Public Function GetAllRecordsForPaymentSearch(ByVal pSearchString As String) As DataSet

        Dim lQuery As String = String.Empty



        Dim lDs As New DataSet()

        lQuery = "Select CompanyName As Name,PayerID,AddressLine1 + ',' + AddressLine2 As Address from FavouriteInsurance where IsDelete = 'N' " _
        & "union " _
        & " Select LastName As Name,CAST(PatientID AS varchar(100)) As PayerID,AddressLine1 + ',' + AddressLine2 As Address from Patient "


        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery(lQuery)
        Else
            lDs = Connection.ExecuteQuery(lQuery)
        End If

        Return lDs

    End Function
    Public Function SelectTopTenRecordsByType(ByVal pType As String) As DataSet
        Dim lQuery As String = ""
        Dim lDs As DataSet = Nothing

        Try
            lQuery = "SELECT TOP(10) FavouriteInsuranceID, cast(FavouriteInsuranceID as varchar) + '|' + cast(PayerID as varchar) + '|' + cast(WorkPhone as varchar) as Hidden, InsuranceID, CompanyName, PayerID, rtrim(ltrim(AddressLine1))+' '+rtrim(ltrim(AddressLine2)) as Address, City, State, ZipCode, ContactName, InsuranceType, WorkPhone, Fax, Email, BillType, PriorAuthorizationNumber " _
               & "FROM FavouriteInsurance where InsuranceType ='" & pType & "' and IsDelete='N' AND CompanyName like '" + mInsuranceDB.CompanyName + "%' Order by CompanyName"


            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If

        Catch ex As Exception
            Throw New Exception(ex.Message & " : Billing\DAL\Insurance.SelectTopTenRecords() ")
        End Try

        Return lDs
    End Function



End Class
