Imports Microsoft.VisualBasic
Imports System.xml

'Public Class PaymentHdrDB

'#Region "Fields"
'    Private mPaymentID As String
'    Private mPaymentDate As String
'    Private mPaymentDispId As String
'    Private mPaymentDispDate As String
'    Private mPayerType As String
'    Private mPaymentMode As String
'    Private mChequeNumber As String
'    Private mChequeDate As String
'    Private mAmount As String
'    Private mNumberOfPatients As String
'    Private mDescription As String
'    Private mUserId As String
'    Private mIsDeleted As String
'    Private mPayerName As String
'    Private mPatientID As String
'    Private mPayerID As String
'#End Region

'#Region "Properties"


'    Public Property PayerName() As String
'        Get
'            Return mPayerName
'        End Get
'        Set(ByVal value As String)
'            mPayerName = value
'        End Set
'    End Property

'    Public Property PaymentID() As String
'        Get
'            Return mPaymentID
'        End Get
'        Set(ByVal value As String)
'            mPaymentID = value
'        End Set
'    End Property

'    Public Property PaymentDate() As String
'        Get
'            Return mPaymentDate
'        End Get
'        Set(ByVal value As String)
'            mPaymentDate = value
'        End Set
'    End Property

'    Public Property PaymentDispId() As String
'        Get
'            Return mPaymentDispId
'        End Get
'        Set(ByVal value As String)
'            mPaymentDispId = value
'        End Set
'    End Property
'    Public Property PaymentDispDate() As String
'        Get
'            Return mPaymentDispDate
'        End Get
'        Set(ByVal value As String)
'            mPaymentDispDate = value
'        End Set
'    End Property
'    Public Property PayerType() As String
'        Get
'            Return mPayerType
'        End Get
'        Set(ByVal value As String)
'            mPayerType = value
'        End Set
'    End Property

'    Public Property PaymentMode() As String
'        Get
'            Return mPaymentMode
'        End Get
'        Set(ByVal value As String)
'            mPaymentMode = value
'        End Set
'    End Property

'    Public Property ChequeNumber() As String
'        Get
'            Return mChequeNumber
'        End Get
'        Set(ByVal value As String)
'            mChequeNumber = value
'        End Set
'    End Property

'    Public Property ChequeDate() As String
'        Get
'            Return mChequeDate
'        End Get
'        Set(ByVal value As String)
'            mChequeDate = value
'        End Set
'    End Property

'    Public Property Amount() As String
'        Get
'            Return mAmount
'        End Get
'        Set(ByVal value As String)
'            mAmount = value
'        End Set
'    End Property
'    Public Property NumberOfPatients() As String
'        Get
'            Return mNumberOfPatients
'        End Get
'        Set(ByVal value As String)
'            mNumberOfPatients = value
'        End Set
'    End Property

'    Public Property Description() As String
'        Get
'            Return mDescription
'        End Get
'        Set(ByVal value As String)
'            mDescription = value
'        End Set
'    End Property

'    Public Property UserID() As String
'        Get
'            Return mUserId
'        End Get
'        Set(ByVal value As String)
'            mUserId = value
'        End Set
'    End Property
'    Public Property IsDeleted() As String
'        Get
'            Return mIsDeleted
'        End Get
'        Set(ByVal value As String)
'            mIsDeleted = value
'        End Set
'    End Property

'    Public Property PatientID() As String
'        Get
'            Return mPatientID
'        End Get
'        Set(ByVal value As String)
'            mPatientID = value
'        End Set
'    End Property

'    Public Property PayerID() As String
'        Get
'            Return mPayerID
'        End Get
'        Set(ByVal value As String)
'            mPayerID = value
'        End Set
'    End Property

'#End Region

'End Class
Public Class PaymentHdrDB

#Region "Fields"
    Private mPaymentID As String
    Private mPaymentDate As String
    Private mPaymentDispId As String
    Private mPaymentDispDate As String
    Private mPayerType As String
    Private mPaymentMode As String
    Private mChequeNumber As String
    Private mChequeDate As String
    Private mAmount As String
    Private mDescription As String
    Private mUserId As String
    Private mIsDeleted As String
    Private mPayerName As String
    Private mPatientID As String
    Private mPayerID As String
    Private mEntryDate As String

    Private mNotes As String

#End Region

#Region "Properties"


    Public Property Notes() As String
        Get
            Return mNotes
        End Get
        Set(ByVal value As String)
            mNotes = value
        End Set
    End Property

    Public Property PaymentDispId() As String
        Get
            Return mPaymentDispId
        End Get
        Set(ByVal value As String)
            mPaymentDispId = value
        End Set
    End Property

    Public Property PayerName() As String
        Get
            Return mPayerName
        End Get
        Set(ByVal value As String)
            mPayerName = value
        End Set
    End Property

    Public Property PaymentID() As String
        Get
            Return mPaymentID
        End Get
        Set(ByVal value As String)
            mPaymentID = value
        End Set
    End Property

    Public Property PaymentDate() As String
        Get
            Return mPaymentDate
        End Get
        Set(ByVal value As String)
            mPaymentDate = value
        End Set
    End Property

    Public Property DisplayID() As String
        Get
            Return mPaymentDispId
        End Get
        Set(ByVal value As String)
            mPaymentDispId = value
        End Set
    End Property
    Public Property PaymentDispDate() As String
        Get
            Return mPaymentDispDate
        End Get
        Set(ByVal value As String)
            mPaymentDispDate = value
        End Set
    End Property
    Public Property PayerType() As String
        Get
            Return mPayerType
        End Get
        Set(ByVal value As String)
            mPayerType = value
        End Set
    End Property

    Public Property PaymentMode() As String
        Get
            Return mPaymentMode
        End Get
        Set(ByVal value As String)
            mPaymentMode = value
        End Set
    End Property

    Public Property CheckNumber() As String
        Get
            Return mChequeNumber
        End Get
        Set(ByVal value As String)
            mChequeNumber = value
        End Set
    End Property

    Public Property CheckDate() As String
        Get
            Return mChequeDate
        End Get
        Set(ByVal value As String)
            mChequeDate = value
        End Set
    End Property

    Public Property Amount() As String
        Get
            Return mAmount
        End Get
        Set(ByVal value As String)
            mAmount = value
        End Set
    End Property

    Public Property Description() As String
        Get
            Return mDescription
        End Get
        Set(ByVal value As String)
            mDescription = value
        End Set
    End Property

    Public Property UserID() As String
        Get
            Return mUserId
        End Get
        Set(ByVal value As String)
            mUserId = value
        End Set
    End Property
    Public Property EntryDate() As String
        Get
            Return mEntryDate
        End Get
        Set(ByVal value As String)
            mEntryDate = value
        End Set
    End Property


    Public Property PayerID() As String
        Get
            Return mPayerID
        End Get
        Set(ByVal value As String)
            mPayerID = value
        End Set
    End Property

#End Region

End Class
Public Class PaymentHdr
    Implements IDetail


#Region "Fields"
    Private mConnection As Connection
    Private mConnectionString As String
    Private mPaymentHdr As New PaymentHdrDB
    Private mPaymentHdrNew As New PaymentHdrDB
#End Region

#Region "Property"
    Public ReadOnly Property Connection() As ElixirLibrary.Connection Implements IDetail.Connection
        Get
            Return mConnection
        End Get
    End Property

    Public ReadOnly Property ConnectionString() As String Implements IDetail.ConnectionString
        Get
            Return mConnectionString
        End Get
    End Property
    Public Property PaymentHdr() As PaymentHdrDB
        Get
            Return mPaymentHdr
        End Get
        Set(ByVal value As PaymentHdrDB)
            mPaymentHdr = value
        End Set
    End Property
    
#End Region

#Region "Constructor"
    ''' <summary>
    ''' Creates new Conection Object based on Given Connection String 
    ''' </summary>
    ''' <param name="pConnectionString">
    ''' Contains Connection String 
    ''' </param>
    ''' <remarks>
    ''' Use when not using transaction
    ''' Must Specify Connection String other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnectionString As String)
        If pConnectionString = "" Then
            Throw New ArgumentException("ConnectionString can not be empty")
        End If

        mConnectionString = pConnectionString
        mConnection = New Connection(mConnectionString)

    End Sub

    ''' <summary>
    ''' Assign given connection to the current Object
    ''' </summary>
    ''' <param name="pConnection">
    ''' Contains refrence to the connection object
    ''' </param>
    ''' <remarks>
    ''' Use when  using Transaction
    ''' Must Specify Connection other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnection As Connection)
        If pConnection Is Nothing Then
            Throw New ArgumentException("Connection can not be empty")
        End If

        mConnection = pConnection
    End Sub
#End Region


#Region "Method"
    ''' <summary>
    ''' Delete Record Acoording to Given Condition
    ''' </summary>
    ''' <param name="lCondition"></param>
    ''' <remarks></remarks>
    Public Sub DeleteRecord(ByVal lCondition As String) Implements IDetail.DeleteRecord

        Dim lSpParameter(1) As SpParameter

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "PaymentHdr"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = lCondition

        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand("DeleteRecords", lSpParameter)
        Else
            Connection.ExecuteCommand("DeleteRecords", lSpParameter)
        End If

    End Sub
    ''' <summary>
    ''' Delete Record on Primary Key
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub DeleteRecordByID() Implements IDetail.DeleteRecordByID
        Dim lCondition As String

        lCondition = "AND PaymentID= " & PaymentHdr.PaymentID
        DeleteRecord(lCondition)

    End Sub
    ''' <summary>
    ''' Get All Records unconditional
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetAllRecords() As System.Data.DataSet Implements IDetail.GetAllRecords
        Dim lCondition As String = ""
        Dim lDs As New DataSet()

        lDs = GetAllRecords(lCondition)

        Return lDs
    End Function
    ''' <summary>
    ''' Get  Records on specified Condition
    ''' </summary>
    ''' <param name="lCondition"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetAllRecords(ByVal lCondition As String) As System.Data.DataSet Implements IDetail.GetAllRecords
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "PaymentHdr"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = lCondition

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("SelectAllRecords", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
        End If

        Return lDs

    End Function

    Public Sub InsertPayment()
        Dim lXmlDocument As New XmlDocument
        Dim lXmlElement As XmlElement


        Try

            lXmlDocument.LoadXml("<PaymentHdrs></PaymentHdrs>")
            lXmlElement = lXmlDocument.CreateElement("PaymentHdr")

            With lXmlElement

                '.SetAttribute("PaymentID", PaymentHdr.PaymentID)
                .SetAttribute("PaymentDate", PaymentHdr.PaymentDate)
                .SetAttribute("DisplayID", PaymentHdr.DisplayID)
                .SetAttribute("EntryDate", PaymentHdr.EntryDate)
                .SetAttribute("PayerType", PaymentHdr.PayerType)
                .SetAttribute("PayerID", PaymentHdr.PayerID)
                .SetAttribute("PayerName", PaymentHdr.PayerName)
                .SetAttribute("PaymentMode", PaymentHdr.PaymentMode)
                .SetAttribute("CheckNumber", PaymentHdr.CheckNumber)
                .SetAttribute("CheckDate", PaymentHdr.CheckDate)
                .SetAttribute("Amount", PaymentHdr.Amount)
                .SetAttribute("Description", PaymentHdr.Description)
                .SetAttribute("UserID", PaymentHdr.UserID)


            End With

            lXmlDocument.DocumentElement.AppendChild(lXmlElement.CloneNode(True))

            If Connection.IsTransactionAlive() Then
                PaymentHdr.PaymentID = Connection.ExecuteTransactionScalarCommand("InsertPaymentHdr", lXmlDocument.InnerXml.ToString)
            Else
                PaymentHdr.PaymentID = Connection.ExecuteScalarCommand("InsertPaymentHdr", lXmlDocument.InnerXml.ToString)
            End If

        Catch ex As Exception
            Throw New Exception(ex.Message + " : DAL\PaymentHdr.InsertPayment() ")
        End Try



    End Sub
    ''' <summary>
    ''' Insert record
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub InsertRecord() Implements IDetail.InsertRecord
        Dim lXmlDocument As New XmlDocument
        Dim lXmlElement As XmlElement

        lXmlDocument.LoadXml("<PaymentHdrs></PaymentHdrs>")
        lXmlElement = lXmlDocument.CreateElement("PaymentHdr")

        With lXmlElement

            .SetAttribute("PaymentID", PaymentHdr.PaymentID)
            .SetAttribute("PaymentDate", PaymentHdr.PaymentDate)
            .SetAttribute("DisplayID", PaymentHdr.DisplayID)
            .SetAttribute("EntryDate", PaymentHdr.EntryDate)
            .SetAttribute("PayerType", PaymentHdr.PayerType)
            .SetAttribute("PayerID", PaymentHdr.PayerID)
            .SetAttribute("PayerName", PaymentHdr.PayerName)
            .SetAttribute("PaymentMode", PaymentHdr.PaymentMode)
            .SetAttribute("CheckNumber", PaymentHdr.CheckNumber)
            .SetAttribute("CheckDate", PaymentHdr.CheckDate)
            .SetAttribute("Amount", PaymentHdr.Amount)
            .SetAttribute("Description", PaymentHdr.Description)
            .SetAttribute("UserID", PaymentHdr.UserID)


        End With

        lXmlDocument.DocumentElement.AppendChild(lXmlElement.CloneNode(True))

        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand("InsertPaymentHdr", lXmlDocument.InnerXml.ToString)
        Else
            Connection.ExecuteCommand("InsertPaymentHdr", lXmlDocument.InnerXml.ToString)
        End If

    End Sub
    ''' <summary>
    ''' Update Record unconditional
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub UpdateRecord() Implements IDetail.UpdateRecord
        Dim lCondition As String

        lCondition = "And PaymentID = " & Me.PaymentHdr.PaymentID
        UpdateRecord(lCondition)

    End Sub



    Public Sub UpdateNotes(ByVal pNotes As String, ByVal pPaymentID As Integer)

        Dim lQuery As String

        lQuery = "Update PaymentHdr Set " _
                & "Notes ='" & pNotes & "' where PaymentID = " & pPaymentID


        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand(lQuery)
        Else
            Connection.ExecuteCommand(lQuery)
        End If
    End Sub

    Public Sub UpdateRecord(ByVal lCondition As String) Implements IDetail.UpdateRecord

        Dim lQuery As String

        With Me.PaymentHdr

            lQuery = "Update PaymentHdr Set " _
                    & "PaymentDate ='" & .PaymentDate & "', " _
                    & "PayerType ='" & .PayerType & "', " _
                    & "PaymentMode ='" & .PaymentMode & "', " _
                    & "CheckNumber ='" & .CheckNumber & "', " _
                    & "CheckDate ='" & .CheckDate & "', " _
                    & "Amount =" & .Amount & ", " _
                    & "PayerID =" & .PayerID & ", " _
                    & "Description ='" & .Description & "', " _
                    & "PayerName = '" & .PayerName & "' " _
                    & "Where 1 = 1 " _
                    & lCondition


        End With

        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand(lQuery)
        Else
            Connection.ExecuteCommand(lQuery)
        End If
    End Sub
    ''' <summary>
    ''' Get Single Record By Primary Key
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetRecordByIDExtended() As Boolean
        Dim lSpParameter(0) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@PaymentId"
        lSpParameter(0).ParameterType = ParameterType.BigInt
        lSpParameter(0).ParameterValue = Me.PaymentHdr.PaymentID

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("GetPaymentHdr", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("GetPaymentHdr", lSpParameter)
        End If


        With lDs.Tables(0)
            If .Rows.Count > 0 Then


                Me.PaymentHdr.PaymentID = .Rows(0)("PaymentID")
                Me.PaymentHdr.PaymentDate = .Rows(0)("PaymentDate")
                Me.PaymentHdr.DisplayID = .Rows(0)("DisplayID")
                Me.PaymentHdr.EntryDate = .Rows(0)("EntryDate")
                Me.PaymentHdr.PayerType = .Rows(0)("PayerType")
                Me.PaymentHdr.PaymentMode = .Rows(0)("PaymentMode")
                Me.PaymentHdr.CheckNumber = .Rows(0)("CheckNumber")
                Me.PaymentHdr.CheckDate = .Rows(0)("CheckDate")
                Me.PaymentHdr.Amount = .Rows(0)("Amount")
                Me.PaymentHdr.Description = .Rows(0)("Description")
                Me.PaymentHdr.UserID = .Rows(0)("UserID")
                Me.PaymentHdr.PayerName = .Rows(0)("PayerName")
                Me.PaymentHdr.PayerID = .Rows(0)("PayerID")


                Return True
            End If
        End With

        Return False

    End Function

    ''' <summary>
    ''' Get  Employee Id 
    ''' </summary>
    ''' <param name="lCondition"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetUniqueId() As Boolean
        Dim lDs As New DataSet()

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("Exec GetPaymentUniqueId")
        Else
            lDs = Connection.ExecuteQuery("Exec GetPaymentUniqueId")
        End If

        If lDs.Tables(0).Rows.Count > 0 Then
            Me.PaymentHdr.PaymentID = lDs.Tables(0).Rows(0)("PaymentID")
            Me.PaymentHdr.DisplayID = lDs.Tables(0).Rows(0)("DisplayID")
            Return True
        Else
            Return False
        End If

    End Function


   
    Public Sub LogicalDelete()
        Dim lQuery As String

        lQuery = "Update PaymentHdr Set IsDeleted = 'Y' " _
               & "Where PaymentId = " & Me.PaymentHdr.PaymentID & " "


        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand(lQuery)
        Else
            Connection.ExecuteCommand(lQuery)
        End If

    End Sub



    Public Function GetRecordByID() As Boolean Implements IDetail.GetRecordByID
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "PaymentHdr"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = "And PaymentID = " & Me.PaymentHdr.PaymentID

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("SelectAllRecords", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
        End If


        With lDs.Tables(0)
            If .Rows.Count > 0 Then

                Me.PaymentHdr.PaymentID = .Rows(0)("PaymentID").ToString
                Me.PaymentHdr.PaymentDate = .Rows(0)("PaymentDate").ToString
                Me.PaymentHdr.DisplayID = .Rows(0)("DisplayID").ToString
                Me.PaymentHdr.EntryDate = .Rows(0)("EntryDate").ToString
                Me.PaymentHdr.PayerType = .Rows(0)("PayerType").ToString
                Me.PaymentHdr.PaymentMode = .Rows(0)("PaymentMode").ToString
                Me.PaymentHdr.CheckNumber = .Rows(0)("CheckNumber").ToString
                Me.PaymentHdr.CheckDate = .Rows(0)("CheckDate").ToString
                Me.PaymentHdr.Amount = .Rows(0)("Amount").ToString
                Me.PaymentHdr.Description = .Rows(0)("Description").ToString
                Me.PaymentHdr.UserID = .Rows(0)("UserID").ToString
                Me.PaymentHdr.PayerName = .Rows(0)("PayerName").ToString
                Me.PaymentHdr.PayerID = .Rows(0)("PayerID").ToString
                Me.PaymentHdr.Notes = .Rows(0)("Notes").ToString
                


                Return True
            End If
        End With

        Return False
    End Function


    'This Function gets the Get User from combo
    Public Shared Function GetAdjustmentCode(ByVal pConnection As String) As DataSet
        Dim lobjConnection As Connection

        Dim lQuery As String
        Dim lDs As DataSet

        lQuery = "Select * from AdjustmentCode"

        lobjConnection = New Connection(pConnection)
        lDs = lobjConnection.ExecuteQuery(lQuery)

        Return lDs

    End Function

    'This Function gets the Get User from combo
    Public Shared Function GetReasonCode(ByVal pConnection As String) As DataSet
        Dim lobjConnection As Connection

        Dim lQuery As String
        Dim lDs As DataSet

        lQuery = "Select * from ReasonCode"

        lobjConnection = New Connection(pConnection)
        lDs = lobjConnection.ExecuteQuery(lQuery)

        Return lDs

    End Function
    Public Shared Function GetPayerType(ByVal pConnection As String) As DataSet
        Dim lobjConnection As Connection

        Dim lQuery As String
        Dim lDs As DataSet

        lQuery = "Select Distinct PayerType from PaymentHdr"

        lobjConnection = New Connection(pConnection)
        lDs = lobjConnection.ExecuteQuery(lQuery)

        Return lDs

    End Function
    Public Shared Function GetPayerNameForInsurance(ByVal pConnection As String, ByVal pType As String) As DataSet
        Dim lobjConnection As Connection

        Dim lQuery As String
        Dim lDs As DataSet
        If pType = "Insurance" Then
            lQuery = "Select *, FavouriteInsuranceID as PairID , CompanyName,AddressLine1+AddressLine2 as Address from FavouriteInsurance"
        Else
            lQuery = "Select FirstName,LastName, PatientID as  PairID , LastName + ',' + FirstName as CompanyName from Patient"
        End If


        lobjConnection = New Connection(pConnection)
        lDs = lobjConnection.ExecuteQuery(lQuery)

        Return lDs

    End Function
    Public Shared Function GetMaxDispID(ByVal pConnection As String) As Object
        Dim lobjConnection As Connection

        Dim lQuery As String
        Dim lDs As Object

        lQuery = "Select IsNull(max(cast(DisplayID as int)),1) from PaymentHdr"

        lobjConnection = New Connection(pConnection)
        lDs = lobjConnection.ExecuteScalarCommand(lQuery)

        Return lDs

    End Function
    Public Shared Function GetPaymentMode(ByVal pConnection As String) As DataSet
        Dim lobjConnection As Connection

        Dim lQuery As String
        Dim lDs As DataSet

        lQuery = "Select Distinct PaymentMode from PaymentHdr"

        lobjConnection = New Connection(pConnection)
        lDs = lobjConnection.ExecuteQuery(lQuery)

        Return lDs

    End Function
    Public Function InsertRecordPayHdrNew() As Integer

        Dim lXmlDocument As New XmlDocument
        Dim lXmlElement As XmlElement
        Dim lPaymentID As Integer = 0

        lXmlDocument.LoadXml("<PaymentHdrs></PaymentHdrs>")
        lXmlElement = lXmlDocument.CreateElement("PaymentHdr")

        With lXmlElement

            .SetAttribute("PaymentID", PaymentHdr.PaymentID)
            .SetAttribute("PaymentDate", PaymentHdr.PaymentDate)
            .SetAttribute("DisplayID", PaymentHdr.DisplayID)
            .SetAttribute("PaymentDispDate", PaymentHdr.PaymentDispDate)
            .SetAttribute("PayerType", PaymentHdr.PayerType)
            .SetAttribute("PaymentMode", PaymentHdr.PaymentMode)
            .SetAttribute("CheckNumber", PaymentHdr.CheckNumber)
            .SetAttribute("CheckDate", PaymentHdr.CheckDate)
            .SetAttribute("Amount", PaymentHdr.Amount)
            .SetAttribute("Description", PaymentHdr.Description)
            .SetAttribute("UserID", PaymentHdr.UserID)
            .SetAttribute("PayerName", PaymentHdr.PayerName)
            .SetAttribute("PayerID", PaymentHdr.PayerID)
            .SetAttribute("EntryDate", PaymentHdr.EntryDate)
        End With


        lXmlDocument.DocumentElement.AppendChild(lXmlElement.CloneNode(True))

        Try
            If Connection.IsTransactionAlive() Then
                'Connection.ExecuteTransactionCommand("InsertPaymentHdr", lXmlDocument.InnerXml.ToString)
                lPaymentID = Connection.ExecuteTransactionScalarCommand("InsertPaymentHdr", lXmlDocument.InnerXml.ToString)
            Else
                lPaymentID = Connection.ExecuteScalarCommand("InsertPaymentHdr", lXmlDocument.InnerXml.ToString)
                'Connection.ExecuteCommand("InsertPaymentHdr", lXmlDocument.InnerXml.ToString)
            End If

            Return lPaymentID

        Catch ex As Exception
            Return 0
        End Try

    End Function
    Public Function GetTypeCode() As DataSet
        Dim lQuery As String
        Dim lDs As New DataSet()
        Try
            lQuery = "select AdjustmentTypeID,[Description]+ '-' + [Type]+'-'+ DrCrAdjustment as AdjustmentType from AdjustmentType"
            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If
            Return lDs
        Catch ex As Exception
            Return lDs
        End Try
    End Function
    Public Function GetAdjReasonCode() As DataSet
        Dim lQuery As String
        Dim lDs As New DataSet()
        Try
            lQuery = "Select * from AdjustmentReason"
            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If
            Return lDs
        Catch ex As Exception
            Return lDs
        End Try
    End Function
    Public Function GetListRecord() As DataSet
        Dim lQuery As String
        Dim lDs As New DataSet()
        Try
            lQuery = "select * from adjustment"
            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If
            Return lDs
        Catch ex As Exception
            Return lDs
        End Try
    End Function

    Public Function InsertListRecord(ByRef pVisitID As Integer, ByVal pCPTCode As String, ByVal ApdjustmentDescription As String, ByVal pReasonCode As String, ByVal pAdjustmentTypeID As Integer, ByVal pAmount As Integer, ByVal pUserID As Integer, ByVal pPaymentDtlID As Integer, ByVal pPaymentID As Integer)
        Dim lQuery As String
        Dim lDs As New DataSet()
        Try
            lQuery = "insert into Adjustment (AdjustmentDate,VisitID,CPTCode,AdjustmentDescription,ReasonCode,AdjustmentTypeID,Amount,UserID,PaymentDtlID,PaymentID)values('" & System.DateTime.Today & "'," & pVisitID & ",'" & pCPTCode & "','" & ApdjustmentDescription & "','" & pReasonCode & "'," & pAdjustmentTypeID & "," & pAmount & "," & pUserID & "," & pPaymentDtlID & "," & pPaymentID & ")"
            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If
            Return lDs
        Catch ex As Exception
            Return lDs
        End Try
    End Function
    Public Function GetLastEnteredDate() As Object
        Dim lQuery As String
        Dim lobj As New Object
        Try
            lQuery = "Select top 1 EntryDate from PaymentHdr order by paymentid desc "
            If Connection.IsTransactionAlive() Then
                lobj = Connection.ExecuteTransactionScalarCommand(lQuery)
            Else
                lobj = Connection.ExecuteScalarCommand(lQuery)
            End If
            Return lobj
        Catch ex As Exception
            Return lobj
        End Try
    End Function
    Public Function GetPaymentList(ByVal pconnection As String, ByVal pCondition As String) As DataSet
        Dim lobjConnection As Connection

        Dim lQuery As String
        Dim lDs As DataSet

        Try

        
            lQuery = "Select PHN.PaymentID,PaymentDate,PayerType,PayerName, PHN.Amount as Amount, PHN.CheckNumber as CheckNumber, Sum(TotalAmount) As AppliedAmount " _
                    & "from PaymentHdr PHN left outer join  PaymentDtl PDN " _
                    & "on PHN.PaymentID=PDN.PaymentID where 1=1 " & pCondition _
                    & " group by PHN.PaymentID,PaymentDate,PayerType,PayerName,PHN.Amount , PHN.CheckNumber"


            lobjConnection = New Connection(pconnection)
            lDs = lobjConnection.ExecuteQuery(lQuery)

            Return lDs

        Catch ex As Exception

        End Try

    End Function
    Public Sub DeletePaymentNew(ByVal pPaymentID As String)
        Dim lQuery As String = String.Empty

        ''Deleting from PaymentDtl.....
        lQuery = "Delete from PaymentDtl Where PaymentID='" & pPaymentID & "'"

        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand(lQuery)
        Else
            Connection.ExecuteCommand(lQuery)
        End If

        ''Deleting from PaymentHdr.....
        lQuery = "Delete from PaymentHdr Where PaymentID='" & pPaymentID & "'"

        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand(lQuery)
        Else
            Connection.ExecuteCommand(lQuery)
        End If

    End Sub

    Public Function GetForDetailApplyPaymentGrid(ByVal pPatientSuperBillID As String) As DataSet
        Dim lUser As User = CType(HttpContext.Current.Session("User"), User)
        Try
            Dim lPaymentHdr As New PaymentHdr(lUser.ConnectionString)
            Dim lds As DataSet
            ' lds = lPaymentHdr.GetForDetailApplyPaymentGrid(lUser.ConnectionString, pPatientSuperBillID)
            Return lds
        Catch ex As Exception
            Return Nothing
        End Try
    End Function
    Public Function AlreadyPosted() As Boolean
        Dim lDS As DataSet
        Dim lQuery As String
        Try
            lQuery = "SELECT  * FROM PaymentHdr Where CheckNumber='" & PaymentHdr.CheckNumber & "' and PayerId='" & PaymentHdr.PayerID & "' "
            lDS = Connection.ExecuteQuery(lQuery)
            If (lDS.Tables(0).Rows.Count > 0) Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            Return True
        End Try
    End Function

    Public Function GetForDetailApplyPaymentGrid(ByVal pconnection As String, ByVal pPatientSuperBillID As String) As DataSet
        Dim lSpParameter(0) As SpParameter

        Try
            Dim lDs As New DataSet()

            lSpParameter(0).ParameterName = "@SuperBillID"
            lSpParameter(0).ParameterValue = pPatientSuperBillID


            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery("GetForDetailApplyPaymentGrid", lSpParameter)
            Else
                lDs = Connection.ExecuteQuery("GetForDetailApplyPaymentGrid", lSpParameter)
            End If

            Return lDs



        Catch ex As Exception
            Return Nothing
        End Try
    End Function



    Public Function GetPaymentForMasterGrid(ByVal pconnection As String, ByVal pPatientSuperBillID As String) As DataSet

        Dim lSpParameter(0) As SpParameter

        Try
            Dim lDs As New DataSet()

            lSpParameter(0).ParameterName = "@SuperBillID"
            lSpParameter(0).ParameterValue = pPatientSuperBillID


            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery("GetForMasterApplyPaymentGrid", lSpParameter)
            Else
                lDs = Connection.ExecuteQuery("GetForMasterApplyPaymentGrid", lSpParameter)
            End If

            Return lDs



        Catch ex As Exception
            Return Nothing
        End Try

    End Function

    Public Function GetPaymentId(ByVal pVisitId As String) As Integer
        Dim lDS As DataSet
        Dim lQuery As String
        Try
            lQuery = "Select * From PaymentHdr Hdr, PaymentDtl Dtl " _
                   & "Where Hdr.PaymentId = Dtl.PaymentId " _
                   & "And Hdr.PayerId='" & PaymentHdr.PayerID & "' " _
                   & "And Dtl.VisitId = " & pVisitId & " " _
                   & "And Hdr.PayerType ='I' "

            lDS = Connection.ExecuteQuery(lQuery)
            If (lDS.Tables(0).Rows.Count > 0) Then
                Return lDS.Tables(0).Rows(0)("PaymentId")
            Else
                Return 0
            End If
        Catch ex As Exception
            Return 0
        End Try
    End Function


    Public Function CalculateAppliedAmount(ByVal pPaymentID As String) As String
        Dim lQuery As String = String.Empty
        Dim lDs As DataSet = Nothing

        Try
            lQuery = "select sum(Amount) " _
                & "+" _
                & "isNull((select Sum(paymentcptdetail.amount) from paymentcptdetail inner join paymentdtl " _
                & "on paymentcptdetail.paymentdtlid=paymentdtl.paymentdtlid where paymentdtl.paymentid=" & pPaymentID & "),0) as x " _
                & "from paymentdtl where paymentid=" & pPaymentID & ""

            lDs = Connection.ExecuteQuery(lQuery)

            If (lDs.Tables(0).Rows.Count > 0) Then
                Return lDs.Tables(0).Rows(0).Item(0).ToString
            End If

        Catch ex As Exception
            Return ""
        End Try



    End Function

#End Region

End Class



