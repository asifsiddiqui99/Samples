Imports Microsoft.VisualBasic

Public Class Claim

    Private mConnection As Connection


    Public Sub New(ByVal pConnectionString As String)
        mConnection = New Connection(pConnectionString)
    End Sub


    Public Property Connection() As Connection
        Get
            Return mConnection
        End Get
        Set(ByVal value As Connection)
            mConnection = value
        End Set
    End Property

    Public Function GetClaim(ByVal lCondition As String) As System.Data.DataSet
        Dim lDs As DataSet = Nothing
        Dim lQuery As String = String.Empty

        Try

            'lQuery = "select PatientSuperBillId, convert(varchar , DateOfService, 101) as DateOfService, PatientName, convert(varchar , DOB, 101) as DOB , '' as Form, Status , cast(PatientSuperBillId as varchar) + '|' + cast(PatientId as varchar) + '|' + cast(SuperBillTemplateID as varchar) + '|' + Cast(IsNull((Select Top 1 HcfaID From HCFA Where HCFA.PatientSuperBillId = PatientSuperBill.PatientSuperBillID),0) As Varchar)  as ID , 'Accepted' As ENSStatus, ClaimCount = (select count(LineId) from PatientCPT where patientSuperBillId = PatientSuperBill.PatientSuperBillId)  " & _
            '         " From PatientSuperBill " & _
            '         " Where IsDeleted = 'N' " & _
            '         lCondition & " Order By PatientSuperBillId Desc,convert(datetime , DateOfService)  Desc "

            lQuery = "select PatientSuperBill.Comments as Comments,PatientSuperBill.PrimaryInsuranceCompanyName as PriIns,PatientSuperBill.SecondryInsuranceCompanyName as SecIns,convert(varchar,VisitDisplayDate,101) as [VisitDisplayDate],PatientSuperBill.PatientSuperBillId, " & _
                      "convert(varchar , DateOfService, 101) as DateOfService, " & _
                      "Patient.Lastname + ', ' + Patient.Firstname as PatientName, convert(varchar , PatientSuperBill.DOB, 101) as DOB , " & _
                      "'' as Form, " & _
                      "[Status] , " & _
                      "cast(PatientSuperBill.PatientSuperBillId as varchar) + '|' + cast(PatientSuperBill.PatientId as varchar) + '|' + cast(SuperBillTemplateID as varchar) + '|' + Cast(IsNull((Select Top 1 HcfaID From HCFAUpdated Where HCFAUpdated.PatientSuperBillId = PatientSuperBill.PatientSuperBillID),0) As Varchar) + '|' +  SUBSTRING(Status, 1, 1)  as ID , " & _
                     " ClaimCount = (select count(LineId) from PatientCPT where patientSuperBillId = PatientSuperBill.PatientSuperBillId)," & _
                      "'SB-' + Cast(Year(EntryDate) as Varchar) + '-' +  case Len(Cast(Month(EntryDate) as Varchar)) when 1 then '0' + Cast(Month(EntryDate) as Varchar)  when 2 then Cast(Month(EntryDate) as Varchar) End + '-' + Right(REPLICATE('0', 5) + Cast(VisitDisplayID As Varchar),5) As VisitDisplayID, VisitStatus, " & _
                   "HCFACOUNT=(Select Count(*) from HCFAUpdated where HCFAUpdated.PatientSuperBillID=PatientSuperBill.PatientSuperBillID and HCFAType='P' and IsActive='Y')," & _
                      "SecHCFACount=(Select Count(*) from HCFAUpdated where HCFAUpdated.PatientSuperBillID=PatientSuperBill.PatientSuperBillID and  HCFAType='S' and IsActive='Y')," & _
  " PAvb=case when Pins.PriIns<>'' then 'Y' else 'N' end," & _
   "SAvb=case when Pins.SecIns<>'' then 'Y' else 'N' end," & _
   "TAvb=case when Pins.TerIns<>'' then 'Y' else 'N' end," & _
   "IsActive=(Select IsNull(Max(IsNull(HCFAUpdated.IsActive,'Y')),'Y') from HCFAUpdated where HCFAUpdated.PatientSuperBillID=PatientSuperBill.PatientSuperBillID)  " & _
                      "From PatientSuperBill,Patient ," & _
"(select patientid as patientid, max(PriIns) as PriIns, max(SecIns) as SecIns,max(TerIns) as TerIns" & _
     " from (select P.patientid," & _
      "PriIns = case When [type]='P'  Then [type] Else '' End," & _
      "SecIns = case When [type]='S' Then [type] Else '' End," & _
                        "TerIns = case When [type]='T' Then [type] Else '' End " & _
      " from PatientInsurance,Patient P where P.Patientid*=PatientInsurance.PatientID and PatientInsurance.active='Y'" & _
   ") PatientInsAll " & _
"group by patientid)PIns " & _
                     "Where PatientSuperBill.IsDeleted = 'N' and Patient.PatientID*=PatientSuperBill.PatientID and PatientSuperBill.PatientID=PIns.PatientID " & _
                      lCondition & " Order By PatientSuperBill.PatientSuperBillId  Desc"





            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If

            Return lDs

        Catch ex As Exception
            Return Nothing
        End Try


    End Function

    Public Function GetVisitByDate(ByVal lCondition As String) As System.Data.DataSet
        Dim lDs As DataSet = Nothing
        Dim lQuery As String = String.Empty

        Try

            'lQuery = "select PatientSuperBillId, convert(varchar , DateOfService, 101) as DateOfService, PatientName, convert(varchar , DOB, 101) as DOB , '' as Form, Status , cast(PatientSuperBillId as varchar) + '|' + cast(PatientId as varchar) + '|' + cast(SuperBillTemplateID as varchar) + '|' + Cast(IsNull((Select Top 1 HcfaID From HCFA Where HCFA.PatientSuperBillId = PatientSuperBill.PatientSuperBillID),0) As Varchar)  as ID , 'Accepted' As ENSStatus, ClaimCount = (select count(LineId) from PatientCPT where patientSuperBillId = PatientSuperBill.PatientSuperBillId)  " & _
            '         " From PatientSuperBill " & _
            '         " Where IsDeleted = 'N' " & _
            '         lCondition & " Order By PatientSuperBillId Desc,convert(datetime , DateOfService)  Desc "

            lQuery = "select  Emp.LastName + ', ' + Emp.FirstName as DoctorName,Pat.LastName + ', ' + Pat.FirstName as PatientName ,CONVERT(VARCHAR(10),Psb.VisitDisplayDate ,101)as DateOfService," & _
            "Case When Len(Pat.HousePhone) =10 Then " & _
            "'(' + Left(Pat.HousePhone,3) + ')' + Substring(Pat.HousePhone,4,3) + '-' + Right(Pat.HousePhone,4) Else Pat.HousePhone End as HomePhone   , " & _
            "Case When Len(Pat.WorkPhone) =10 Then " & _
            "'(' + Left(Pat.WorkPhone,3) + ')' + Substring(Pat.WorkPhone,4,3) + '-' + Right(Pat.WorkPhone,4) Else Pat.WorkPhone  End   as WorkPhone, " & _
            " 'SB-' + Cast(Year(Psb.EntryDate) as Varchar) " & _
   " + '-'+ case Len(Cast(Month(Psb.EntryDate) as Varchar)) " & _
    " when 1 then '0'+ Cast(Month(Psb.EntryDate) as Varchar) " & _
     "when 2 then Cast(Month(Psb.EntryDate) as Varchar) End " & _
   " + '-'+ Right(REPLICATE('0', 5) + Cast(Psb.VisitDisplayID As Varchar),5) As VisitID  ," & _
   "Cl.ClinicName as ClinicName,Cl.AddressLine1 + ' ' + Cl.AddressLine2 + ' ' + Cl.City + ' ' + (Select Abbr from [State] where StateID = Cl.[Stateid]) + ' ' + Substring( Cl.zipCode,1,5) + '-' + Substring( Cl.zipCode,6,len(cl.zipCode)) as ClinicAddress" & _
" From Employee as Emp , PatientSuperBill as Psb ,Patient as Pat,ClinicInfo as Cl" & _
           " Where(Emp.EmployeeID = Psb.PrescriberID)" & _
"and Pat.PatientID = Psb.PatientID and psb.IsDeleted = 'N' and " & lCondition & "  order by Psb.VisitDisplayDate asc"





            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If

            Return lDs

        Catch ex As Exception
            Return Nothing
        End Try


    End Function

    Public Function GetClaimNew(ByVal lCondition As String) As System.Data.DataSet
        Dim lDs As DataSet = Nothing
        Dim lQuery As String = String.Empty

        Try

            lQuery = "select S.PatientSuperBillId, convert(varchar,S.VisitDisplayDate,101) as [VisitDisplayDate], " & _
                     " H.IsBatch as IsBatch,H.Hcfaid as ClaimID, " & _
                     " convert(varchar,H.HCFAPreparedDate,101) as ClaimDate, " & _
                     " 'SB-' + Cast(Year(S.EntryDate) as Varchar) + '-'+ case Len(Cast(Month(S.EntryDate) as Varchar)) when 1 then '0'+ Cast(Month(S.EntryDate) as Varchar) when 2 then Cast(Month(S.EntryDate) as Varchar) End + '-'+ Right(REPLICATE('0', 5) + Cast(S.VisitDisplayID As Varchar),5) As VisitID , " & _
                     " convert(varchar , S.DateofService, 101) as VisitDate," & _
                     " H.PatientLastName + ', ' + H.PatientFirstName as Patientname, " & _
                     " 'Accepted' as ENSStatus, " & _
                     " cast(H.PatientSuperBillId as varchar) + '|' + cast(S.PatientId as varchar) + '|' + cast(S.SuperBillTemplateID as varchar) + '|' + Cast(IsNull(H.HcfaID,0) As Varchar)  as ID , " & _
     " ClaimType= case " & _
   "when H.[HCFAType] = 'S' or H.[HCFAType]= 's' then 'Secondary' " & _
    "when H.[HCFAType] = 'P' or H.[HCFAType]= 'p' then 'Primary' " & _
    "when H.[HCFAType] = 'T' or H.[HCFAType]= 't' then 'Tertiary' " & _
    "end,'Open' as ClaimStatus, " & _
                        " ClaimCount = (select count(LineId) from HCFADetailUpdated where hcfaid=H.hcfaid) , " & _
                     " 'CL-' + Cast(Year(H.HCFAPreparedDate) as Varchar) + '-'+ case Len(Cast(Month(H.HCFAPreparedDate) as Varchar)) when 1 then '0'+ Cast(Month(H.HCFAPreparedDate) as Varchar) when 2 then Cast(Month(H.HCFAPreparedDate) as Varchar) End + '-'+ Right(REPLICATE('0', 5) + Cast(H.HCFADisplayID As Varchar),5) As HCFADisplayID,S.PatientSuperBillID as VisitIDUnique,H.MainICCompanyName as InsuranceCompany  " & _
                     ", H.HCFANotes as Comments from HCFAUpdated H,PatientSuperBill S " & _
                     " Where H.PatientSuperBillId=S.PatientSuperBillId  " & _
                     lCondition & " Order By H.HCFAPreparedDate desc,ClaimID desc"


            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If

            Return lDs

        Catch ex As Exception
            Return Nothing
        End Try


    End Function

    Public Function GetOutstandingClaim(ByVal lCondition As String) As System.Data.DataSet
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@Cond"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = lCondition


        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("OutstandingClaims", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("OutstandingClaims", lSpParameter)
        End If

        Return lDs

    End Function
    Public Function DeleteClaim(ByVal pPatientSuperBillID As String) As Boolean

        Dim lQuery As String = String.Empty
        Try
            lQuery = "Update PatientSuperBill Set IsDeleted='Y' where PatientSuperBillId=" & pPatientSuperBillID
            Connection.ExecuteCommand(lQuery)
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function
    Public Function UpdateComment(ByVal HCFAID As String, ByVal pComment As String) As Boolean

        Dim lQuery As String = String.Empty
        Try
            lQuery = "Update HCFAUpdated Set HcfaNotes='" & pComment & "' where HCFAID=" & HCFAID
            Connection.ExecuteCommand(lQuery)
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function



    Public Function GetClaimNotes(ByVal pHCFAID As String) As String
        Dim lDs As DataSet = Nothing
        Dim lQuery As String = String.Empty

        Try

            lQuery = "select HCFANotes from HCFAUpdated where HCFAID = " & pHCFAID

            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If

            Return lDs.Tables(0).Rows(0)("HCFANotes").ToString

        Catch ex As Exception
            Return Nothing
        End Try


    End Function
End Class
