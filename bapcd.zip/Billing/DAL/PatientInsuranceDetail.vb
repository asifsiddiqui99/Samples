Imports Microsoft.VisualBasic
Public Class PatientInsuranceDetailDB
    Dim mConStr As String = ConfigurationManager.ConnectionStrings("ClinicConnectionString").ConnectionString()
#Region "Fields"
    Private mPInsurance As New PatientInsuranceDB
    Private mIInsurance As New PatientInsuranceDB
    Private mInsuranceCompany As New InsuranceDB
    Private mInsurer As New PatientDBExtended
#End Region

#Region "Properties"
    Public Property PInsurance() As PatientInsuranceDB
        Get
            Return mPInsurance
        End Get
        Set(ByVal value As PatientInsuranceDB)
            mPInsurance = value
        End Set
    End Property

    Public Property IInsurance() As PatientInsuranceDB
        Get
            Return mIInsurance
        End Get
        Set(ByVal value As PatientInsuranceDB)
            mIInsurance = value
        End Set
    End Property

    Public Property InsuranceCompany() As InsuranceDB
        Get
            Return mInsuranceCompany
        End Get
        Set(ByVal value As InsuranceDB)
            mInsuranceCompany = value
        End Set
    End Property

    Public Property Insurer() As PatientDBExtended
        Get
            Return mInsurer
        End Get
        Set(ByVal value As PatientDBExtended)
            mInsurer = value
        End Set
    End Property
#End Region

End Class
Public Class PatientInsuranceDetail

#Region "Fields"
    Private mConnection As Connection
    Private mConnectionString As String
    Private mPatientInsuranceDetail As New PatientInsuranceDetailDB
#End Region

#Region "Properties"
    Public ReadOnly Property Connection() As ElixirLibrary.Connection
        Get
            Return mConnection
        End Get
    End Property

    Public ReadOnly Property ConnectionString() As String
        Get
            Return mConnectionString
        End Get
    End Property
    Public Property PatientInsuranceDetail() As PatientInsuranceDetailDB
        Get
            Return mPatientInsuranceDetail
        End Get
        Set(ByVal value As PatientInsuranceDetailDB)
            mPatientInsuranceDetail = value
        End Set
    End Property
#End Region

#Region "Constructor"
    Public Sub New(ByVal pConnectionString As String)
        If pConnectionString = "" Then
            Throw New ArgumentException("ConnectionString can not be empty")
        End If

        mConnectionString = pConnectionString
        mConnection = New Connection(mConnectionString)

    End Sub
    Public Sub New(ByVal pConnection As Connection)
        If pConnection Is Nothing Then
            Throw New ArgumentException("Connection can not be empty")
        End If

        mConnection = pConnection
    End Sub
#End Region

#Region "Methods"
    Public Function GetRecordByID(ByVal pPatientID As String, ByVal pType As String) As Boolean

        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()

        Try
            lSpParameter(0).ParameterName = "@PatientID"
            lSpParameter(0).ParameterType = ParameterType.Varchar
            lSpParameter(0).ParameterValue = pPatientID

            lSpParameter(1).ParameterName = "@Type"
            lSpParameter(1).ParameterType = ParameterType.Varchar
            lSpParameter(1).ParameterValue = pType

            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery("GetPatientInsuranceDetails", lSpParameter)
            Else
                lDs = Connection.ExecuteQuery("GetPatientInsuranceDetails", lSpParameter)
            End If

            With lDs.Tables(0)
                If .Rows.Count > 0 Then

                    'For Patient Insurance
                    Me.PatientInsuranceDetail.PInsurance.PatientInsID = .Rows(0)("PPatientInsID")
                    Me.PatientInsuranceDetail.PInsurance.PatientID = .Rows(0)("PPatientID")
                    Me.PatientInsuranceDetail.PInsurance.Type = .Rows(0)("PType")
                    Me.PatientInsuranceDetail.PInsurance.Active = .Rows(0)("PActive")
                    Me.PatientInsuranceDetail.PInsurance.Deductable = .Rows(0)("PDeductable")
                    Me.PatientInsuranceDetail.PInsurance.GroupNo = .Rows(0)("PGroupNo")
                    Me.PatientInsuranceDetail.PInsurance.InsuranceCompanyName = .Rows(0)("PInsuranceCompany")
                    Me.PatientInsuranceDetail.PInsurance.InsuranceCompanyID = .Rows(0)("PInsuranceCompanyID")
                    Me.PatientInsuranceDetail.PInsurance.InsurerId = .Rows(0)("PInsurerId")
                    Me.PatientInsuranceDetail.PInsurance.PayerId = .Rows(0)("PPayerId")
                    Me.PatientInsuranceDetail.PInsurance.InsuredAuthorization = .Rows(0)("PInsuredAuthorization")
                    Me.PatientInsuranceDetail.PInsurance.PlanName = .Rows(0)("PPlanName")
                    Me.PatientInsuranceDetail.PInsurance.RelationshipToPrimaryInsurer = .Rows(0)("PRelationshipToPrimaryInsurer")
                    Me.PatientInsuranceDetail.PInsurance.SignatureDate = .Rows(0)("PSignatureDate")
                    Me.PatientInsuranceDetail.PInsurance.SignatureOfFile = .Rows(0)("PSignatureOfFile")
                    Me.PatientInsuranceDetail.PInsurance.SubscriberID = .Rows(0)("PSubscriberID")
                    Me.PatientInsuranceDetail.PInsurance.VisitCopayment = .Rows(0)("PVisitCopayment")
                    Me.PatientInsuranceDetail.PInsurance.EffectiveDateFrom = IIf(IsDBNull(.Rows(0)("PEffectiveDateFrom")), "1/1/1900", .Rows(0)("PEffectiveDateFrom"))
                    Me.PatientInsuranceDetail.PInsurance.EffectiveDateTo = IIf(IsDBNull(.Rows(0)("PEffectiveDateTo")), "1/1/1900", .Rows(0)("PEffectiveDateTo"))
                    Me.PatientInsuranceDetail.PInsurance.AuthorizationNumber = .Rows(0)("PAuthorizationNumber")
                    Me.PatientInsuranceDetail.PInsurance.CoInsurance = .Rows(0)("PCoInsurance")
                    Me.PatientInsuranceDetail.PInsurance.InsuranceCompanyPhoneNumber = .Rows(0)("PInsuranceCompanyPhoneNumber")

                    'For Insurer Insurance
                    Me.PatientInsuranceDetail.IInsurance.PatientInsID = .Rows(0)("IPatientInsID")
                    Me.PatientInsuranceDetail.IInsurance.PatientID = .Rows(0)("IPatientID")
                    Me.PatientInsuranceDetail.IInsurance.Type = .Rows(0)("IType")
                    Me.PatientInsuranceDetail.IInsurance.Active = .Rows(0)("IActive")
                    Me.PatientInsuranceDetail.IInsurance.Deductable = .Rows(0)("IDeductable")
                    Me.PatientInsuranceDetail.IInsurance.GroupNo = .Rows(0)("IGroupNo")
                    Me.PatientInsuranceDetail.IInsurance.InsuranceCompanyName = .Rows(0)("IInsuranceCompany")
                    Me.PatientInsuranceDetail.IInsurance.InsuranceCompanyID = .Rows(0)("IInsuranceCompanyID")
                    Me.PatientInsuranceDetail.IInsurance.InsurerId = .Rows(0)("IInsurerId")
                    Me.PatientInsuranceDetail.IInsurance.PayerId = .Rows(0)("IPayerId")
                    Me.PatientInsuranceDetail.IInsurance.InsuredAuthorization = .Rows(0)("IInsuredAuthorization")
                    Me.PatientInsuranceDetail.IInsurance.PlanName = .Rows(0)("IPlanName")
                    Me.PatientInsuranceDetail.IInsurance.RelationshipToPrimaryInsurer = .Rows(0)("IRelationshipToPrimaryInsurer")
                    Me.PatientInsuranceDetail.IInsurance.SignatureDate = .Rows(0)("ISignatureDate")
                    Me.PatientInsuranceDetail.IInsurance.SignatureOfFile = .Rows(0)("ISignatureOfFile")
                    Me.PatientInsuranceDetail.IInsurance.SubscriberID = .Rows(0)("ISubscriberID")
                    Me.PatientInsuranceDetail.IInsurance.VisitCopayment = .Rows(0)("IVisitCopayment")
                    Me.PatientInsuranceDetail.IInsurance.EffectiveDateFrom = IIf(IsDBNull(.Rows(0)("IEffectiveDateFrom")), "1/1/1900", .Rows(0)("IEffectiveDateFrom"))
                    Me.PatientInsuranceDetail.IInsurance.EffectiveDateTo = IIf(IsDBNull(.Rows(0)("IEffectiveDateTo")), "1/1/1900", .Rows(0)("IEffectiveDateTo"))
                    Me.PatientInsuranceDetail.IInsurance.AuthorizationNumber = .Rows(0)("IAuthorizationNumber")
                    Me.PatientInsuranceDetail.IInsurance.CoInsurance = .Rows(0)("ICoInsurance")
                    Me.PatientInsuranceDetail.IInsurance.InsuranceCompanyPhoneNumber = .Rows(0)("IInsuranceCompanyPhoneNumber")

                    'For Insurance Company
                    Me.PatientInsuranceDetail.InsuranceCompany.InsuranceID = .Rows(0)("InsuranceID")
                    Me.PatientInsuranceDetail.InsuranceCompany.CompanyName = .Rows(0)("CompanyName")
                    Me.PatientInsuranceDetail.InsuranceCompany.PayerID = .Rows(0)("PayerID")
                    Me.PatientInsuranceDetail.InsuranceCompany.AddressLine1 = .Rows(0)("AddressLine1")
                    Me.PatientInsuranceDetail.InsuranceCompany.AddressLine2 = .Rows(0)("AddressLine2")
                    Me.PatientInsuranceDetail.InsuranceCompany.BillType = .Rows(0)("BillType")
                    Me.PatientInsuranceDetail.InsuranceCompany.City = .Rows(0)("City")
                    Me.PatientInsuranceDetail.InsuranceCompany.ContactName = .Rows(0)("ContactName")
                    Me.PatientInsuranceDetail.InsuranceCompany.Email = .Rows(0)("Email")
                    Me.PatientInsuranceDetail.InsuranceCompany.FavouriteInsuranceID = .Rows(0)("FavouriteInsuranceID")
                    Me.PatientInsuranceDetail.InsuranceCompany.Fax = .Rows(0)("Fax")
                    Me.PatientInsuranceDetail.InsuranceCompany.InsuranceType = .Rows(0)("InsuranceType")
                    Me.PatientInsuranceDetail.InsuranceCompany.State = .Rows(0)("State")
                    Me.PatientInsuranceDetail.InsuranceCompany.WorkPhone = .Rows(0)("WorkPhone")
                    Me.PatientInsuranceDetail.InsuranceCompany.ZipCode = .Rows(0)("ZipCode")
                    Me.PatientInsuranceDetail.InsuranceCompany.Enrollment = ""
                    Me.PatientInsuranceDetail.InsuranceCompany.PayerName = ""
                    Me.PatientInsuranceDetail.InsuranceCompany.PayerStatus = ""
                    Me.PatientInsuranceDetail.InsuranceCompany.ServingState = ""
                    Me.PatientInsuranceDetail.InsuranceCompany.Type = ""
                    Me.PatientInsuranceDetail.InsuranceCompany.PriorAuthorizationNumber = .Rows(0)("PriorAuthorizationNumber")

                    'For Insurer
                    Me.PatientInsuranceDetail.Insurer.PatientID = .Rows(0)("InsurerPatientID")
                    Me.PatientInsuranceDetail.Insurer.Title = .Rows(0)("InsurerTitle")
                    Me.PatientInsuranceDetail.Insurer.Occupation = .Rows(0)("InsurerOccupation")
                    Me.PatientInsuranceDetail.Insurer.MartialStatus = .Rows(0)("InsurerMartialStatus")
                    Me.PatientInsuranceDetail.Insurer.FirstName = .Rows(0)("InsurerFirstName")
                    Me.PatientInsuranceDetail.Insurer.MiddleName = .Rows(0)("InsurerMiddleName")
                    Me.PatientInsuranceDetail.Insurer.LastName = .Rows(0)("InsurerLastName")
                    Me.PatientInsuranceDetail.Insurer.AddressLine1 = .Rows(0)("InsurerAddressLine1")
                    Me.PatientInsuranceDetail.Insurer.AddressLine2 = .Rows(0)("InsurerAddressLine2")
                    Me.PatientInsuranceDetail.Insurer.City = .Rows(0)("InsurerCity")
                    Me.PatientInsuranceDetail.Insurer.StateID = .Rows(0)("InsurerState")
                    Me.PatientInsuranceDetail.Insurer.ZipCode = .Rows(0)("InsurerZipCode")
                    Me.PatientInsuranceDetail.Insurer.HomePhone = .Rows(0)("InsurerHousePhone")
                    Me.PatientInsuranceDetail.Insurer.WorkPhone = .Rows(0)("InsurerWorkPhone")
                    Me.PatientInsuranceDetail.Insurer.WorkPhoneExtension = .Rows(0)("InsurerWorkPhoneExtension")
                    Me.PatientInsuranceDetail.Insurer.Fax = .Rows(0)("InsurerFax")
                    Me.PatientInsuranceDetail.Insurer.Email = .Rows(0)("InsurerEmail")
                    Me.PatientInsuranceDetail.Insurer.Occupation = .Rows(0)("InsurerOccupation")
                    Me.PatientInsuranceDetail.Insurer.DOB = .Rows(0)("InsurerDOB")
                    Me.PatientInsuranceDetail.Insurer.Gender = .Rows(0)("InsurerGender")
                    Me.PatientInsuranceDetail.Insurer.NCPDPID = .Rows(0)("InsurerNCPDPID")
                    Me.PatientInsuranceDetail.Insurer.NCPDPID2 = .Rows(0)("InsurerNCPDPID2")
                    Me.PatientInsuranceDetail.Insurer.PharmacyName = .Rows(0)("InsurerPharmacyName")
                    Me.PatientInsuranceDetail.Insurer.PharmacyName2 = .Rows(0)("InsurerPharmacyName2")
                    Me.PatientInsuranceDetail.Insurer.PharmacyProvider = .Rows(0)("InsurerPharmacyProvider")
                    Me.PatientInsuranceDetail.Insurer.PharmacyProvider2 = .Rows(0)("InsurerPharmacyProvider2")
                    Me.PatientInsuranceDetail.Insurer.SSN = .Rows(0)("InsurerSSN")
                    Me.PatientInsuranceDetail.Insurer.IsDeleted = .Rows(0)("InsurerIsDeleted")
                    Me.PatientInsuranceDetail.Insurer.PictureFilePath = .Rows(0)("InsurerPictureFilePath")
                    Me.PatientInsuranceDetail.Insurer.CellPhoneNumber = .Rows(0)("InsurerCellPhoneNumber")
                    Me.PatientInsuranceDetail.Insurer.EmergencyContactName = .Rows(0)("InsurerEmergencyContactName")
                    Me.PatientInsuranceDetail.Insurer.EmergencyContactRelationship = .Rows(0)("InsurerEmergencyContactRelationship")
                    Me.PatientInsuranceDetail.Insurer.EmergencyContactPhone = .Rows(0)("InsurerEmergencyContactPhone")
                    Me.PatientInsuranceDetail.Insurer.EmergencyContactAddress = .Rows(0)("InsurerEmergencyContactAddress")
                    Me.PatientInsuranceDetail.Insurer.EmergencyContactCity = .Rows(0)("InsurerEmergencyContactCity")
                    Me.PatientInsuranceDetail.Insurer.EmergencyContactZip = .Rows(0)("InsurerEmergencyContactZip")
                    Me.PatientInsuranceDetail.Insurer.EmergencyContactState = .Rows(0)("InsurerEmergencyContactState")
                    Me.PatientInsuranceDetail.Insurer.EmployerName = .Rows(0)("InsurerEmployerName")
                    Me.PatientInsuranceDetail.Insurer.EmploymentStatus = .Rows(0)("InsurerEmploymentStatus")
                    Me.PatientInsuranceDetail.Insurer.EmployerAddressLine1 = .Rows(0)("InsurerEmployerAddressLine1")
                    Me.PatientInsuranceDetail.Insurer.EmployerAddressLine2 = .Rows(0)("InsurerEmployerAddressLine2")
                    Me.PatientInsuranceDetail.Insurer.EmployerPhoneNumber = .Rows(0)("InsurerEmployerPhoneNumber")
                    Me.PatientInsuranceDetail.Insurer.EmployerCity = .Rows(0)("InsurerEmployerCity")
                    Me.PatientInsuranceDetail.Insurer.EmployerZip = .Rows(0)("InsurerEmployerZip")
                    Me.PatientInsuranceDetail.Insurer.EmployerState = .Rows(0)("InsurerEmployerState")
                    Me.PatientInsuranceDetail.Insurer.ResponsibleName = .Rows(0)("InsurerResponsibleName")
                    Me.PatientInsuranceDetail.Insurer.ResponsibleRelationship = .Rows(0)("InsurerResponsibleRelationship")
                    Me.PatientInsuranceDetail.Insurer.ResponsibleHomePhone = .Rows(0)("InsurerResponsibleHomePhone")
                    Me.PatientInsuranceDetail.Insurer.ResponsibleWorkPhone = .Rows(0)("InsurerResponsibleWorkPhone")
                    Me.PatientInsuranceDetail.Insurer.ResponsibleAddress = .Rows(0)("InsurerResponsibleAddress")
                    Me.PatientInsuranceDetail.Insurer.ResponsibleSSN = .Rows(0)("InsurerResponsibleSSN")
                    Me.PatientInsuranceDetail.Insurer.ResponsibleCity = .Rows(0)("InsurerResponsibleCity")
                    Me.PatientInsuranceDetail.Insurer.ResponsibleState = .Rows(0)("InsurerResponsibleState")
                    Me.PatientInsuranceDetail.Insurer.ResponsibleZip = .Rows(0)("InsurerResponsibleZip")
                    Me.PatientInsuranceDetail.Insurer.EmergencyContactName2 = .Rows(0)("InsurerEmergencyContactName2")
                    Me.PatientInsuranceDetail.Insurer.EmergencyContactRelationship2 = .Rows(0)("InsurerEmergencyContactRelationship2")
                    Me.PatientInsuranceDetail.Insurer.EmergencyContactPhone2 = .Rows(0)("InsurerEmergencyContactPhone2")
                    Me.PatientInsuranceDetail.Insurer.PreferredHomePh = .Rows(0)("InsurerPreferredHomePh")
                    Me.PatientInsuranceDetail.Insurer.PreferredWorkPh = .Rows(0)("InsurerPreferredWorkPh")
                    Me.PatientInsuranceDetail.Insurer.PreferredCellPh = .Rows(0)("InsurerPreferredCellPh")
                    Me.PatientInsuranceDetail.Insurer.EmployeeDesignation = .Rows(0)("InsurerEmployeeDesignation")

                    Return True
                Else
                    Return False
                End If
            End With

        Catch ex As Exception
            Throw New Exception(ex.Message + " : DAL\PatientInsuranceDetail.GetRecordByID(ByVal pPatientID As String, ByVal pType As String) As DataSet ")
        End Try



    End Function

    Public Function GetRecordForEDI(ByVal pPatientInsID As String) As Boolean

        Dim lSpParameter(0) As SpParameter
        Dim lDs As New DataSet()

        Try
            lSpParameter(0).ParameterName = "@PatientInsuranceID"
            lSpParameter(0).ParameterType = ParameterType.Varchar
            lSpParameter(0).ParameterValue = pPatientInsID


            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery("GetPatientInsuranceDetailsEDI", lSpParameter)
            Else
                lDs = Connection.ExecuteQuery("GetPatientInsuranceDetailsEDI", lSpParameter)
            End If

            With lDs.Tables(0)
                If .Rows.Count > 0 Then

                    'For Patient Insurance
                    Me.PatientInsuranceDetail.PInsurance.PatientInsID = .Rows(0)("PPatientInsID")
                    Me.PatientInsuranceDetail.PInsurance.PatientID = .Rows(0)("PPatientID")
                    Me.PatientInsuranceDetail.PInsurance.Type = .Rows(0)("PType")
                    Me.PatientInsuranceDetail.PInsurance.Active = .Rows(0)("PActive")
                    Me.PatientInsuranceDetail.PInsurance.Deductable = .Rows(0)("PDeductable")
                    Me.PatientInsuranceDetail.PInsurance.GroupNo = .Rows(0)("PGroupNo")
                    Me.PatientInsuranceDetail.PInsurance.InsuranceCompanyName = .Rows(0)("PInsuranceCompany")
                    Me.PatientInsuranceDetail.PInsurance.InsuranceCompanyID = .Rows(0)("PInsuranceCompanyID")
                    Me.PatientInsuranceDetail.PInsurance.InsurerId = .Rows(0)("PInsurerId")
                    Me.PatientInsuranceDetail.PInsurance.PayerId = .Rows(0)("PPayerId")
                    Me.PatientInsuranceDetail.PInsurance.InsuredAuthorization = .Rows(0)("PInsuredAuthorization")
                    Me.PatientInsuranceDetail.PInsurance.PlanName = .Rows(0)("PPlanName")
                    Me.PatientInsuranceDetail.PInsurance.RelationshipToPrimaryInsurer = .Rows(0)("PRelationshipToPrimaryInsurer")
                    Me.PatientInsuranceDetail.PInsurance.SignatureDate = .Rows(0)("PSignatureDate")
                    Me.PatientInsuranceDetail.PInsurance.SignatureOfFile = .Rows(0)("PSignatureOfFile")
                    Me.PatientInsuranceDetail.PInsurance.SubscriberID = .Rows(0)("PSubscriberID")
                    Me.PatientInsuranceDetail.PInsurance.VisitCopayment = .Rows(0)("PVisitCopayment")
                    Me.PatientInsuranceDetail.PInsurance.EffectiveDateFrom = IIf(IsDBNull(.Rows(0)("PEffectiveDateFrom")), "1/1/1900", .Rows(0)("PEffectiveDateFrom"))
                    Me.PatientInsuranceDetail.PInsurance.EffectiveDateTo = IIf(IsDBNull(.Rows(0)("PEffectiveDateTo")), "1/1/1900", .Rows(0)("PEffectiveDateTo"))
                    Me.PatientInsuranceDetail.PInsurance.AuthorizationNumber = .Rows(0)("PAuthorizationNumber")
                    Me.PatientInsuranceDetail.PInsurance.CoInsurance = .Rows(0)("PCoInsurance")
                    Me.PatientInsuranceDetail.PInsurance.InsuranceCompanyPhoneNumber = .Rows(0)("PInsuranceCompanyPhoneNumber")

                    'For Insurer Insurance
                    Me.PatientInsuranceDetail.IInsurance.PatientInsID = .Rows(0)("IPatientInsID")
                    Me.PatientInsuranceDetail.IInsurance.PatientID = .Rows(0)("IPatientID")
                    Me.PatientInsuranceDetail.IInsurance.Type = .Rows(0)("IType")
                    Me.PatientInsuranceDetail.IInsurance.Active = .Rows(0)("IActive")
                    Me.PatientInsuranceDetail.IInsurance.Deductable = .Rows(0)("IDeductable")
                    Me.PatientInsuranceDetail.IInsurance.GroupNo = .Rows(0)("IGroupNo")
                    Me.PatientInsuranceDetail.IInsurance.InsuranceCompanyName = .Rows(0)("IInsuranceCompany")
                    Me.PatientInsuranceDetail.IInsurance.InsuranceCompanyID = .Rows(0)("IInsuranceCompanyID")
                    Me.PatientInsuranceDetail.IInsurance.InsurerId = .Rows(0)("IInsurerId")
                    Me.PatientInsuranceDetail.IInsurance.PayerId = .Rows(0)("IPayerId")
                    Me.PatientInsuranceDetail.IInsurance.InsuredAuthorization = .Rows(0)("IInsuredAuthorization")
                    Me.PatientInsuranceDetail.IInsurance.PlanName = .Rows(0)("IPlanName")
                    Me.PatientInsuranceDetail.IInsurance.RelationshipToPrimaryInsurer = .Rows(0)("IRelationshipToPrimaryInsurer")
                    Me.PatientInsuranceDetail.IInsurance.SignatureDate = .Rows(0)("ISignatureDate")
                    Me.PatientInsuranceDetail.IInsurance.SignatureOfFile = .Rows(0)("ISignatureOfFile")
                    Me.PatientInsuranceDetail.IInsurance.SubscriberID = .Rows(0)("ISubscriberID")
                    Me.PatientInsuranceDetail.IInsurance.VisitCopayment = .Rows(0)("IVisitCopayment")
                    Me.PatientInsuranceDetail.IInsurance.EffectiveDateFrom = IIf(IsDBNull(.Rows(0)("IEffectiveDateFrom")), "1/1/1900", .Rows(0)("IEffectiveDateFrom"))
                    Me.PatientInsuranceDetail.IInsurance.EffectiveDateTo = IIf(IsDBNull(.Rows(0)("IEffectiveDateTo")), "1/1/1900", .Rows(0)("IEffectiveDateTo"))
                    Me.PatientInsuranceDetail.IInsurance.AuthorizationNumber = .Rows(0)("IAuthorizationNumber")
                    Me.PatientInsuranceDetail.IInsurance.CoInsurance = .Rows(0)("ICoInsurance")
                    Me.PatientInsuranceDetail.IInsurance.InsuranceCompanyPhoneNumber = .Rows(0)("IInsuranceCompanyPhoneNumber")

                    'For Insurance Company
                    Me.PatientInsuranceDetail.InsuranceCompany.InsuranceID = .Rows(0)("InsuranceID")
                    Me.PatientInsuranceDetail.InsuranceCompany.CompanyName = .Rows(0)("CompanyName")
                    Me.PatientInsuranceDetail.InsuranceCompany.PayerID = .Rows(0)("PayerID")
                    Me.PatientInsuranceDetail.InsuranceCompany.AddressLine1 = .Rows(0)("AddressLine1")
                    Me.PatientInsuranceDetail.InsuranceCompany.AddressLine2 = .Rows(0)("AddressLine2")
                    Me.PatientInsuranceDetail.InsuranceCompany.BillType = .Rows(0)("BillType")
                    Me.PatientInsuranceDetail.InsuranceCompany.City = .Rows(0)("City")
                    Me.PatientInsuranceDetail.InsuranceCompany.ContactName = .Rows(0)("ContactName")
                    Me.PatientInsuranceDetail.InsuranceCompany.Email = .Rows(0)("Email")
                    Me.PatientInsuranceDetail.InsuranceCompany.FavouriteInsuranceID = .Rows(0)("FavouriteInsuranceID")
                    Me.PatientInsuranceDetail.InsuranceCompany.Fax = .Rows(0)("Fax")
                    Me.PatientInsuranceDetail.InsuranceCompany.InsuranceType = .Rows(0)("InsuranceType")
                    Me.PatientInsuranceDetail.InsuranceCompany.State = .Rows(0)("State")
                    Me.PatientInsuranceDetail.InsuranceCompany.WorkPhone = .Rows(0)("WorkPhone")
                    Me.PatientInsuranceDetail.InsuranceCompany.ZipCode = .Rows(0)("ZipCode")
                    Me.PatientInsuranceDetail.InsuranceCompany.Enrollment = ""
                    Me.PatientInsuranceDetail.InsuranceCompany.PayerName = ""
                    Me.PatientInsuranceDetail.InsuranceCompany.PayerStatus = ""
                    Me.PatientInsuranceDetail.InsuranceCompany.ServingState = ""
                    Me.PatientInsuranceDetail.InsuranceCompany.Type = ""
                    Me.PatientInsuranceDetail.InsuranceCompany.PriorAuthorizationNumber = .Rows(0)("PriorAuthorizationNumber")

                    'For Insurer
                    Me.PatientInsuranceDetail.Insurer.PatientID = .Rows(0)("InsurerPatientID")
                    Me.PatientInsuranceDetail.Insurer.Title = .Rows(0)("InsurerTitle")
                    Me.PatientInsuranceDetail.Insurer.Occupation = .Rows(0)("InsurerOccupation")
                    Me.PatientInsuranceDetail.Insurer.MartialStatus = .Rows(0)("InsurerMartialStatus")
                    Me.PatientInsuranceDetail.Insurer.FirstName = .Rows(0)("InsurerFirstName")
                    Me.PatientInsuranceDetail.Insurer.MiddleName = .Rows(0)("InsurerMiddleName")
                    Me.PatientInsuranceDetail.Insurer.LastName = .Rows(0)("InsurerLastName")
                    Me.PatientInsuranceDetail.Insurer.AddressLine1 = .Rows(0)("InsurerAddressLine1")
                    Me.PatientInsuranceDetail.Insurer.AddressLine2 = .Rows(0)("InsurerAddressLine2")
                    Me.PatientInsuranceDetail.Insurer.City = .Rows(0)("InsurerCity")
                    Me.PatientInsuranceDetail.Insurer.StateID = .Rows(0)("InsurerState")
                    Me.PatientInsuranceDetail.Insurer.ZipCode = .Rows(0)("InsurerZipCode")
                    Me.PatientInsuranceDetail.Insurer.HomePhone = .Rows(0)("InsurerHousePhone")
                    Me.PatientInsuranceDetail.Insurer.WorkPhone = .Rows(0)("InsurerWorkPhone")
                    Me.PatientInsuranceDetail.Insurer.WorkPhoneExtension = .Rows(0)("InsurerWorkPhoneExtension")
                    Me.PatientInsuranceDetail.Insurer.Fax = .Rows(0)("InsurerFax")
                    Me.PatientInsuranceDetail.Insurer.Email = .Rows(0)("InsurerEmail")
                    Me.PatientInsuranceDetail.Insurer.Occupation = .Rows(0)("InsurerOccupation")
                    Me.PatientInsuranceDetail.Insurer.DOB = .Rows(0)("InsurerDOB")
                    Me.PatientInsuranceDetail.Insurer.Gender = .Rows(0)("InsurerGender")
                    Me.PatientInsuranceDetail.Insurer.NCPDPID = .Rows(0)("InsurerNCPDPID")
                    Me.PatientInsuranceDetail.Insurer.NCPDPID2 = .Rows(0)("InsurerNCPDPID2")
                    Me.PatientInsuranceDetail.Insurer.PharmacyName = .Rows(0)("InsurerPharmacyName")
                    Me.PatientInsuranceDetail.Insurer.PharmacyName2 = .Rows(0)("InsurerPharmacyName2")
                    Me.PatientInsuranceDetail.Insurer.PharmacyProvider = .Rows(0)("InsurerPharmacyProvider")
                    Me.PatientInsuranceDetail.Insurer.PharmacyProvider2 = .Rows(0)("InsurerPharmacyProvider2")
                    Me.PatientInsuranceDetail.Insurer.SSN = .Rows(0)("InsurerSSN")
                    Me.PatientInsuranceDetail.Insurer.IsDeleted = .Rows(0)("InsurerIsDeleted")
                    Me.PatientInsuranceDetail.Insurer.PictureFilePath = .Rows(0)("InsurerPictureFilePath")
                    Me.PatientInsuranceDetail.Insurer.CellPhoneNumber = .Rows(0)("InsurerCellPhoneNumber")
                    Me.PatientInsuranceDetail.Insurer.EmergencyContactName = .Rows(0)("InsurerEmergencyContactName")
                    Me.PatientInsuranceDetail.Insurer.EmergencyContactRelationship = .Rows(0)("InsurerEmergencyContactRelationship")
                    Me.PatientInsuranceDetail.Insurer.EmergencyContactPhone = .Rows(0)("InsurerEmergencyContactPhone")
                    Me.PatientInsuranceDetail.Insurer.EmergencyContactAddress = .Rows(0)("InsurerEmergencyContactAddress")
                    Me.PatientInsuranceDetail.Insurer.EmergencyContactCity = .Rows(0)("InsurerEmergencyContactCity")
                    Me.PatientInsuranceDetail.Insurer.EmergencyContactZip = .Rows(0)("InsurerEmergencyContactZip")
                    Me.PatientInsuranceDetail.Insurer.EmergencyContactState = .Rows(0)("InsurerEmergencyContactState")
                    Me.PatientInsuranceDetail.Insurer.EmployerName = .Rows(0)("InsurerEmployerName")
                    Me.PatientInsuranceDetail.Insurer.EmploymentStatus = .Rows(0)("InsurerEmploymentStatus")
                    Me.PatientInsuranceDetail.Insurer.EmployerAddressLine1 = .Rows(0)("InsurerEmployerAddressLine1")
                    Me.PatientInsuranceDetail.Insurer.EmployerAddressLine2 = .Rows(0)("InsurerEmployerAddressLine2")
                    Me.PatientInsuranceDetail.Insurer.EmployerPhoneNumber = .Rows(0)("InsurerEmployerPhoneNumber")
                    Me.PatientInsuranceDetail.Insurer.EmployerCity = .Rows(0)("InsurerEmployerCity")
                    Me.PatientInsuranceDetail.Insurer.EmployerZip = .Rows(0)("InsurerEmployerZip")
                    Me.PatientInsuranceDetail.Insurer.EmployerState = .Rows(0)("InsurerEmployerState")
                    Me.PatientInsuranceDetail.Insurer.ResponsibleName = .Rows(0)("InsurerResponsibleName")
                    Me.PatientInsuranceDetail.Insurer.ResponsibleRelationship = .Rows(0)("InsurerResponsibleRelationship")
                    Me.PatientInsuranceDetail.Insurer.ResponsibleHomePhone = .Rows(0)("InsurerResponsibleHomePhone")
                    Me.PatientInsuranceDetail.Insurer.ResponsibleWorkPhone = .Rows(0)("InsurerResponsibleWorkPhone")
                    Me.PatientInsuranceDetail.Insurer.ResponsibleAddress = .Rows(0)("InsurerResponsibleAddress")
                    Me.PatientInsuranceDetail.Insurer.ResponsibleSSN = .Rows(0)("InsurerResponsibleSSN")
                    Me.PatientInsuranceDetail.Insurer.ResponsibleCity = .Rows(0)("InsurerResponsibleCity")
                    Me.PatientInsuranceDetail.Insurer.ResponsibleState = .Rows(0)("InsurerResponsibleState")
                    Me.PatientInsuranceDetail.Insurer.ResponsibleZip = .Rows(0)("InsurerResponsibleZip")
                    Me.PatientInsuranceDetail.Insurer.EmergencyContactName2 = .Rows(0)("InsurerEmergencyContactName2")
                    Me.PatientInsuranceDetail.Insurer.EmergencyContactRelationship2 = .Rows(0)("InsurerEmergencyContactRelationship2")
                    Me.PatientInsuranceDetail.Insurer.EmergencyContactPhone2 = .Rows(0)("InsurerEmergencyContactPhone2")
                    Me.PatientInsuranceDetail.Insurer.PreferredHomePh = .Rows(0)("InsurerPreferredHomePh")
                    Me.PatientInsuranceDetail.Insurer.PreferredWorkPh = .Rows(0)("InsurerPreferredWorkPh")
                    Me.PatientInsuranceDetail.Insurer.PreferredCellPh = .Rows(0)("InsurerPreferredCellPh")
                    Me.PatientInsuranceDetail.Insurer.EmployeeDesignation = .Rows(0)("InsurerEmployeeDesignation")

                    Return True
                Else
                    Return False
                End If
            End With

        Catch ex As Exception
            Throw New Exception(ex.Message + " : DAL\PatientInsuranceDetail.GetRecordByID(ByVal pPatientID As String, ByVal pType As String) As DataSet ")
        End Try



    End Function

#End Region

End Class

