Imports Microsoft.VisualBasic

Public Class PatientSuperBillDB
#Region "Fields"
    Private mPatientSuperBillID As String = ""
    Private mDateOfService As String = ""
    Private mSuperBillTemplateID As String = ""
    Private mPatientId As String = ""
    Private mPatientName As String = ""
    Private mDOB As String = ""
    Private mAddress As String = ""
    Private mCity As String = ""
    Private mState As String = ""
    Private mZipCode As String = ""
    Private mPrimaryInsuranceCompanyId As String = ""
    Private mPrimaryInsuranceCompanyName As String = ""
    Private mSecondryInsuranceCompanyId As String = ""
    Private mSecondryInsuranceCompanyName As String = ""
    Private mGuarantorName As String = ""
    Private mGuarantorID As String = ""
    Private mBalance As String = ""
    Private mCopayAmount As String = ""
    Private mPaymentMethod As String = "Cash"
    Private mChequeNumber As String = ""
    Private mChequeDate As String = ""
    Private mPrescriberID As String
    Private mStatus As String = ""
    Private mIsDeleted As String = ""
    Private mPatientSuperBillDisplayID As String = ""
    '' added by Fareed 28 jan 2009 to use it in selecting referring provider from combo on editpatientsuperbill.aspx
    Private mReferringProviderNPI As String = ""
    Private mVisitDisplayDATE As String = Date.Now.Date

    Private mFacilityID As String = ""
    Private mBillingProviderId As String = ""
    Private mComments As String = ""

    Private mEntryDate As String = ""
#End Region


#Region "Properties"
    Public Property FacilityID() As String
        Get
            Return mFacilityID
        End Get
        Set(ByVal value As String)
            mFacilityID = value
        End Set
    End Property
    Public Property BillingProviderId() As String
        Get
            Return mBillingProviderId
        End Get
        Set(ByVal value As String)
            mBillingProviderId = value
        End Set
    End Property
    Public Property VisitDisplayDATE() As String
        Get
            Return mVisitDisplayDATE
        End Get
        Set(ByVal value As String)
            mVisitDisplayDATE = value
        End Set
    End Property

    Public Property ReferringProviderNPI() As String
        Get
            Return mReferringProviderNPI
        End Get
        Set(ByVal value As String)
            mReferringProviderNPI = value
        End Set
    End Property

    Public Property PatientSuperBillDisplayID() As String
        Get
            Return mPatientSuperBillDisplayID
        End Get
        Set(ByVal value As String)
            mPatientSuperBillDisplayID = value
        End Set
    End Property

    Public Property PatientSuperBillID() As String
        Get
            Return mPatientSuperBillID
        End Get
        Set(ByVal value As String)
            mPatientSuperBillID = value
        End Set
    End Property

    Public Property DateOfService() As String
        Get
            Return mDateOfService
        End Get
        Set(ByVal value As String)
            mDateOfService = value
        End Set
    End Property

    Public Property SuperBillTemplateID() As String
        Get
            Return mSuperBillTemplateID
        End Get
        Set(ByVal value As String)
            mSuperBillTemplateID = value
        End Set
    End Property

    Public Property PatientId() As String
        Get
            Return mPatientId
        End Get
        Set(ByVal value As String)
            mPatientId = value
        End Set
    End Property

    Public Property PatientName() As String
        Get
            Return mPatientName
        End Get
        Set(ByVal value As String)
            mPatientName = value
        End Set
    End Property

    Public Property DOB() As String
        Get
            Return mDOB
        End Get
        Set(ByVal value As String)
            mDOB = value
        End Set
    End Property

    Public Property Address() As String
        Get
            Return mAddress
        End Get
        Set(ByVal value As String)
            mAddress = value
        End Set
    End Property

    Public Property City() As String
        Get
            Return mCity
        End Get
        Set(ByVal value As String)
            mCity = value
        End Set
    End Property

    Public Property State() As String
        Get
            Return mState
        End Get
        Set(ByVal value As String)
            mState = value
        End Set
    End Property

    Public Property ZipCode() As String
        Get
            Return mZipCode
        End Get
        Set(ByVal value As String)
            mZipCode = value
        End Set
    End Property

    Public Property PrimaryInsuranceCompanyId() As String
        Get
            Return mPrimaryInsuranceCompanyId
        End Get
        Set(ByVal value As String)
            mPrimaryInsuranceCompanyId = value
        End Set
    End Property

    Public Property PrimaryInsuranceCompanyName() As String
        Get
            Return mPrimaryInsuranceCompanyName
        End Get
        Set(ByVal value As String)
            mPrimaryInsuranceCompanyName = value
        End Set
    End Property

    Public Property SecondryInsuranceCompanyId() As String
        Get
            Return mSecondryInsuranceCompanyId
        End Get
        Set(ByVal value As String)
            mSecondryInsuranceCompanyId = value
        End Set
    End Property

    Public Property SecondryInsuranceCompanyName() As String
        Get
            Return mSecondryInsuranceCompanyName
        End Get
        Set(ByVal value As String)
            mSecondryInsuranceCompanyName = value
        End Set
    End Property

    Public Property GuarantorName() As String
        Get
            Return mGuarantorName
        End Get
        Set(ByVal value As String)
            mGuarantorName = value
        End Set
    End Property

    Public Property GuarantorID() As String
        Get
            Return mGuarantorID
        End Get
        Set(ByVal value As String)
            mGuarantorID = value
        End Set
    End Property

    Public Property Balance() As String
        Get
            Return mBalance
        End Get
        Set(ByVal value As String)
            mBalance = value
        End Set
    End Property
    Public Property CopayAmount() As String
        Get
            Return mCopayAmount
        End Get
        Set(ByVal value As String)
            mCopayAmount = value
        End Set
    End Property
    Public Property PaymentMethod() As String
        Get
            Return mPaymentMethod
        End Get
        Set(ByVal value As String)
            mPaymentMethod = value
        End Set
    End Property
    Public Property ChequeNumber() As String
        Get
            Return mChequeNumber
        End Get
        Set(ByVal value As String)
            mChequeNumber = value
        End Set
    End Property
    Public Property ChequeDate() As String
        Get
            Return mChequeDate
        End Get
        Set(ByVal value As String)
            mChequeDate = value
        End Set
    End Property
    Public Property PrescriberID() As String
        Get
            Return mPrescriberID
        End Get
        Set(ByVal value As String)
            mPrescriberID = value
        End Set
    End Property

    Public Property Status() As String
        Get
            Return mStatus
        End Get
        Set(ByVal value As String)
            mStatus = value
        End Set
    End Property

    Public Property IsDeleted() As String
        Get
            Return mIsDeleted
        End Get
        Set(ByVal value As String)
            mIsDeleted = value
        End Set
    End Property

    Public Property Comments() As String
        Get
            Return mComments
        End Get
        Set(ByVal value As String)
            mComments = value
        End Set
    End Property
    Public Property EntryDate() As String
        Get
            Return mEntryDate
        End Get
        Set(ByVal value As String)
            mEntryDate = value
        End Set
    End Property

#End Region

End Class

Public Class PatientSuperBill
#Region "Fields"
    Private mConnection As Connection
    Private mConnectionString
    Private mPatientSuperBill As New PatientSuperBillDB
#End Region

#Region "Property"
    Public ReadOnly Property Connection() As ElixirLibrary.Connection
        Get
            Return mConnection
        End Get
    End Property

    Public ReadOnly Property ConnectionString() As String
        Get
            Return mConnectionString
        End Get
    End Property
    Public Property PatientSuperBill() As PatientSuperBillDB
        Get
            Return mPatientSuperBill
        End Get
        Set(ByVal value As PatientSuperBillDB)
            mPatientSuperBill = value
        End Set
    End Property
#End Region

#Region "Constructor"
    ''' <summary>
    ''' Creates new Conection Object based on Given Connection String 
    ''' </summary>
    ''' <param name="pConnectionString">
    ''' Contains Connection String 
    ''' </param>
    ''' <remarks>
    ''' Use when not using transaction
    ''' Must Specify Connection String other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnectionString As String)
        If pConnectionString = "" Then
            Throw New ArgumentException("ConnectionString can not be empty")
        End If

        mConnectionString = pConnectionString
        mConnection = New Connection(mConnectionString)

    End Sub

    ''' <summary>
    ''' Assign given connection to the current Object
    ''' </summary>
    ''' <param name="pConnection">
    ''' Contains refrence to the connection object
    ''' </param>
    ''' <remarks>
    ''' Use when  using Transaction
    ''' Must Specify Connection other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnection As Connection)
        If pConnection Is Nothing Then
            Throw New ArgumentException("Connection can not be empty")
        End If

        mConnection = pConnection
    End Sub
#End Region

#Region "Method"
    ''' <summary>
    ''' Delete Record Acoording to Given Condition
    ''' </summary>
    ''' <param name="lCondition"></param>
    ''' <remarks></remarks>
    Public Sub DeleteRecord(ByVal lCondition As String)

        Dim lSpParameter(1) As SpParameter

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "PatientSuperBill"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = lCondition

        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand("DeleteRecords", lSpParameter)
        Else
            Connection.ExecuteCommand("DeleteRecords", lSpParameter)
        End If

    End Sub
    ''' <summary>
    ''' Delete Record on Primary Key
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub DeleteRecordByID()
        Dim lCondition As String

        lCondition = "AND PatientSuperBillId= " & PatientSuperBill.PatientSuperBillID
        DeleteRecord(lCondition)

    End Sub
    ''' <summary>
    ''' Get All Records unconditional
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetAllRecords() As System.Data.DataSet
        Dim lCondition As String = ""
        Dim lDs As New DataSet()

        lDs = GetAllRecords(lCondition)

        Return lDs
    End Function
    ''' <summary>
    ''' Get  Records on specified Condition
    ''' </summary>
    ''' <param name="lCondition"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    ''' 
    Public Function GetAllRecords(ByVal lCondition As String) As System.Data.DataSet
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "PatientSuperBill"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = lCondition

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("SelectAllRecords", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
        End If

        Return lDs

    End Function
    Public Function GetAllRecordsReport(ByVal lCondition As String) As System.Data.DataSet
        Dim lSpParameter(0) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@Cond"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = lCondition

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("GetPatientHeaderSuperBill", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("GetPatientHeaderSuperBill", lSpParameter)
        End If

        Return lDs

    End Function
    ''' <summary>
    ''' Insert record
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub InsertRecord()
        Dim lXmlDocument As New XmlDocument
        Dim lXmlElement As XmlElement
        Dim lVisitID As String = String.Empty
        Dim lQuery As String = String.Empty



        lXmlDocument.LoadXml("<PatientSuperBills></PatientSuperBills>")
        lXmlElement = lXmlDocument.CreateElement("PatientSuperBill")


        With lXmlElement
            .SetAttribute("PatientSuperBillID", PatientSuperBill.PatientSuperBillID)
            .SetAttribute("DateOfService", PatientSuperBill.DateOfService)
            .SetAttribute("SuperBillTemplateID", PatientSuperBill.SuperBillTemplateID)
            .SetAttribute("PatientId", PatientSuperBill.PatientId)
            .SetAttribute("PatientName", PatientSuperBill.PatientName)
            .SetAttribute("DOB", PatientSuperBill.DOB)
            .SetAttribute("Address", PatientSuperBill.Address)
            .SetAttribute("City", PatientSuperBill.City)
            .SetAttribute("State", PatientSuperBill.State)
            .SetAttribute("ZipCode", PatientSuperBill.ZipCode)
            .SetAttribute("PrimaryInsuranceCompanyId", PatientSuperBill.PrimaryInsuranceCompanyId)
            .SetAttribute("PrimaryInsuranceCompanyName", PatientSuperBill.PrimaryInsuranceCompanyName)
            .SetAttribute("SecondryInsuranceCompanyId", PatientSuperBill.SecondryInsuranceCompanyId)
            .SetAttribute("SecondryInsuranceCompanyName", PatientSuperBill.SecondryInsuranceCompanyName)
            .SetAttribute("GuarantorName", PatientSuperBill.GuarantorName)
            .SetAttribute("GuarantorID", PatientSuperBill.GuarantorID)
            .SetAttribute("Balance", PatientSuperBill.Balance)
            .SetAttribute("CopayAmount", PatientSuperBill.CopayAmount)
            .SetAttribute("PaymentMethod", PatientSuperBill.PaymentMethod)
            .SetAttribute("ChequeNumber", PatientSuperBill.ChequeNumber)
            .SetAttribute("ChequeDate", PatientSuperBill.ChequeDate)
            .SetAttribute("PrescriberID", PatientSuperBill.PrescriberID)
            .SetAttribute("Status", PatientSuperBill.Status)
            .SetAttribute("IsDeleted", PatientSuperBill.IsDeleted)
            .SetAttribute("VisitDisplayID", lVisitID)
            .SetAttribute("VisitStatus", "Open")
            .SetAttribute("ReferringProviderNPI", PatientSuperBill.ReferringProviderNPI)
            .SetAttribute("VisitDisplayDate", PatientSuperBill.VisitDisplayDATE)

            .SetAttribute("FacilityID", PatientSuperBill.FacilityID)
            .SetAttribute("BillingProviderId", PatientSuperBill.BillingProviderId)

            .SetAttribute("EntryDate", PatientSuperBill.EntryDate)
        End With

        lXmlDocument.DocumentElement.AppendChild(lXmlElement.CloneNode(True))

        If Connection.IsTransactionAlive() Then
            mPatientSuperBill.PatientSuperBillDisplayID = Connection.ExecuteTransactionScalarCommand("InsertPatientSuperBill", lXmlDocument.InnerXml.ToString)
        Else
            mPatientSuperBill.PatientSuperBillDisplayID = Connection.ExecuteScalarCommand("InsertPatientSuperBill", lXmlDocument.InnerXml.ToString)
        End If

    End Sub
    ''' <summary>
    ''' Update Record unconditional
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub UpdateRecord()
        Dim lCondition As String

        lCondition = "And PatientSuperBillID = " & Me.PatientSuperBill.PatientSuperBillID
        UpdateRecord(lCondition)

    End Sub
    Public Sub UpdateRecord(ByVal lCondition As String)

        Dim lQuery As String

        With Me.PatientSuperBill

            lQuery = "Update PatientSuperBill Set " _
                        & "DateOfService ='" & .DateOfService & "', " _
                        & "SuperBillTemplateID =" & .SuperBillTemplateID & ", " _
                        & "PatientId =" & .PatientId & ", " _
                        & "PatientName ='" & .PatientName & "', " _
                        & "DOB ='" & .DOB & "', " _
                        & "Address ='" & .Address & "', " _
                        & "City ='" & .City & "', " _
                        & "State='" & .State & "', " _
                        & "ZipCode='" & .ZipCode & "', " _
                        & "PrimaryInsuranceCompanyId ='" & .PrimaryInsuranceCompanyId & "', " _
                        & "PrimaryInsuranceCompanyName ='" & .PrimaryInsuranceCompanyName & "', " _
                        & "SecondryInsuranceCompanyId ='" & .SecondryInsuranceCompanyId & "', " _
                        & "SecondryInsuranceCompanyName ='" & .SecondryInsuranceCompanyName & "', " _
                        & "GuarantorName ='" & .GuarantorName & "', " _
                        & "GuarantorID =" & .GuarantorID & ", " _
                        & "Balance =" & .Balance & ", " _
                        & "CopayAmount =" & .CopayAmount & ", " _
                        & "PaymentMethod ='" & .PaymentMethod & "', " _
                        & "ChequeNumber ='" & .ChequeNumber & "', " _
                        & "ChequeDate ='" & .ChequeDate & "', " _
                        & "ReferringProviderNPI ='" & .ReferringProviderNPI & "', " _
                        & "PrescriberID =" & .PrescriberID & ",  " _
                        & "VisitDisplayDate ='" & .VisitDisplayDATE & "',  " _
                        & "FacilityID ='" & .FacilityID & "',  " _
                        & "BillingProviderId ='" & .BillingProviderId & "'  " _
                        & "Where 1 = 1 " _
                        & lCondition

        End With

        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand(lQuery)
        Else
            Connection.ExecuteCommand(lQuery)
        End If
    End Sub
    Public Function UpdateStatus(ByVal pIsPreviouslyApproved As Boolean) As Boolean

        Try

            Dim lQuery As String

            With Me.PatientSuperBill
                If (.Status = "Approved" And pIsPreviouslyApproved = True) Then
                    lQuery = "Update PatientSuperBill Set " _
                                     & "CopayAmount =" & .CopayAmount & ", " _
                                     & "PaymentMethod ='" & .PaymentMethod & "', " _
                                     & "ChequeNumber ='" & .ChequeNumber & "', " _
                                     & "ChequeDate ='" & .ChequeDate & "', " _
                                     & "ReferringProviderNPI ='" & .ReferringProviderNPI & "', " _
                                     & " Status = '" & .Status & "', " _
                                     & " FacilityID ='" & .FacilityID & "', " _
                                     & " BillingProviderId ='" & .BillingProviderId & "', " _
                                     & " Comments = '" & .Comments & "', " _
                                     & " PrescriberID='" & .PrescriberID & "' " _
                                     & " Where 1 = 1 " _
                                     & " And PatientSuperBillID = " & .PatientSuperBillID
                ElseIf (pIsPreviouslyApproved = False) Then
                    lQuery = "Update PatientSuperBill Set " _
                                     & "CopayAmount =" & .CopayAmount & ", " _
                                     & "PaymentMethod ='" & .PaymentMethod & "', " _
                                     & "ChequeNumber ='" & .ChequeNumber & "', " _
                                     & "ChequeDate ='" & .ChequeDate & "', " _
                                     & "ReferringProviderNPI ='" & .ReferringProviderNPI & "', " _
                                     & " Status = '" & .Status & "', " _
                                     & " VisitDisplayDate ='" & .VisitDisplayDATE & "', " _
                                     & " FacilityID ='" & .FacilityID & "', " _
                                     & " BillingProviderId ='" & .BillingProviderId & "', " _
                                     & " DateOfService ='" & .DateOfService.Split("|")(0) & "'," _
                                     & " Comments = '" & .Comments & "', " _
                                     & " PrescriberID='" & .PrescriberID & "' " _
                                     & " Where 1 = 1 " _
                                     & " And PatientSuperBillID = " & .PatientSuperBillID
                End If
                'If (.Comments = "") Then
                '    lQuery = "Update PatientSuperBill Set " _
                '      & "CopayAmount =" & .CopayAmount & ", " _
                '      & "PaymentMethod ='" & .PaymentMethod & "', " _
                '      & "ChequeNumber ='" & .ChequeNumber & "', " _
                '      & "ChequeDate ='" & .ChequeDate & "', " _
                '      & "ReferringProviderNPI ='" & .ReferringProviderNPI & "', " _
                '      & " Status = '" & .Status & "', " _
                '      & " VisitDisplayDate ='" & .VisitDisplayDATE & "', " _
                '      & " FacilityID ='" & .FacilityID & "', " _
                '      & " BillingProviderId ='" & .BillingProviderId & "', " _
                '      & " DateOfService ='" & .DateOfService & "'," _
                '      & " PrescriberID='" & .PrescriberID & "' " _
                '      & " Where 1 = 1 " _
                '      & " And PatientSuperBillID = " & .PatientSuperBillID
                'Else

                'End If

            End With

            If Connection.IsTransactionAlive() Then
                Connection.ExecuteTransactionCommand(lQuery)
            Else
                Connection.ExecuteCommand(lQuery)
            End If


            lQuery = "select " & _
            "Cast(Year(EntryDate) as Varchar) + '-' + " & _
            "case Len(Cast(Month(EntryDate) as Varchar)) when 1 then '0' + " & _
            "Cast(Month(EntryDate) as Varchar)  when 2 then Cast(Month(EntryDate) as Varchar) End + '-' + " & _
            "Right(REPLICATE('0', 5) + Cast(VisitDisplayID As Varchar),5) As VisitDisplayID " & _
            "from PatientSuperBill where PatientSuperBillID = " & Me.PatientSuperBill.PatientSuperBillID

            If Connection.IsTransactionAlive() Then
                Me.PatientSuperBill.PatientSuperBillDisplayID = Connection.ExecuteTransactionScalarCommand(lQuery)
            Else
                Me.PatientSuperBill.PatientSuperBillDisplayID = Connection.ExecuteScalarCommand(lQuery)
            End If

            Return True

        Catch ex As Exception
            Return False
        End Try

    End Function
    ''' <summary>
    ''' Get Single Record By Primary Key
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetRecordByID() As Boolean
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "PatientSuperBill"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = "And PatientSuperBillID = " & PatientSuperBill.PatientSuperBillID

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("SelectAllRecords", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
        End If


        With lDs.Tables(0)
            If .Rows.Count > 0 Then

                Me.PatientSuperBill.PatientSuperBillID = .Rows(0)("PatientSuperBillID")
                Me.PatientSuperBill.DateOfService = .Rows(0)("DateOfService")
                Me.PatientSuperBill.SuperBillTemplateID = .Rows(0)("SuperBillTemplateID")
                Me.PatientSuperBill.PatientId = .Rows(0)("PatientId")
                Me.PatientSuperBill.PatientName = .Rows(0)("PatientName")
                Me.PatientSuperBill.DOB = .Rows(0)("DOB")
                Me.PatientSuperBill.Address = .Rows(0)("Address")
                Me.PatientSuperBill.City = .Rows(0)("City")
                Me.PatientSuperBill.State = .Rows(0)("State")
                Me.PatientSuperBill.ZipCode = .Rows(0)("ZipCode")
                Me.PatientSuperBill.PrimaryInsuranceCompanyId = .Rows(0)("PrimaryInsuranceCompanyId")
                Me.PatientSuperBill.PrimaryInsuranceCompanyName = .Rows(0)("PrimaryInsuranceCompanyName")
                Me.PatientSuperBill.SecondryInsuranceCompanyId = .Rows(0)("SecondryInsuranceCompanyId")
                Me.PatientSuperBill.SecondryInsuranceCompanyName = .Rows(0)("SecondryInsuranceCompanyName")
                Me.PatientSuperBill.GuarantorName = .Rows(0)("GuarantorName")
                Me.PatientSuperBill.GuarantorID = .Rows(0)("GuarantorID")
                Me.PatientSuperBill.Balance = .Rows(0)("Balance")
                Me.PatientSuperBill.CopayAmount = .Rows(0)("CopayAmount")
                Me.PatientSuperBill.PaymentMethod = .Rows(0)("PaymentMethod")
                Me.PatientSuperBill.ChequeNumber = .Rows(0)("ChequeNumber")
                Me.PatientSuperBill.ChequeDate = .Rows(0)("ChequeDate")
                Me.PatientSuperBill.PrescriberID = .Rows(0)("PrescriberID")
                Me.PatientSuperBill.PatientSuperBillDisplayID = .Rows(0)("VisitDisplayID")
                Me.PatientSuperBill.ReferringProviderNPI = .Rows(0)("ReferringProviderNPI")
                Me.PatientSuperBill.VisitDisplayDATE = .Rows(0)("VisitDisplayDate")

                Me.PatientSuperBill.FacilityID = IIf(.Rows(0)("FacilityID") Is DBNull.Value, "", .Rows(0)("FacilityID"))
                Me.PatientSuperBill.BillingProviderId = IIf(.Rows(0)("BillingProviderId") Is DBNull.Value, "", .Rows(0)("BillingProviderId"))

                Me.PatientSuperBill.EntryDate = .Rows(0)("EntryDate")
                Return True
            End If
        End With

        Return False

    End Function
    Public Function GetUniqueId(ByVal lCondition As String) As Integer
        Dim lSpParameter(2) As SpParameter
        Dim lDs As New DataSet()
        Dim lID As Integer

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "PatientSuperBill"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = lCondition

        lSpParameter(2).ParameterName = "@Id"
        lSpParameter(2).ParameterType = ParameterType.Varchar
        lSpParameter(2).ParameterValue = "PatientSuperBillId"

        If Connection.IsTransactionAlive() Then
            lID = Connection.ExecuteTransactionScalarCommand("GetUniqueId", lSpParameter)
        Else
            lID = Connection.ExecuteScalarQuery("GetUniqueId", lSpParameter)
        End If

        Return lID

    End Function
    Public Function GetLastVisitDate(ByVal pPatientId As String) As String
        Dim lQuery As String
        Dim lDs As New DataSet()
        Dim lLastVisitDate As String = ""

        lQuery = "Select Max(DateOfService) As LastVisitDate " _
               & "From PatientSuperBill " _
               & "Where PatientId = " & pPatientId & " "

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery(lQuery)
        Else
            lDs = Connection.ExecuteQuery(lQuery)
        End If


        With lDs.Tables(0)
            If .Rows.Count > 0 Then
                lLastVisitDate = .Rows(0)("LastVisitDate")
            End If
        End With

        Return lLastVisitDate

    End Function
    Public Function GetVisitSummary(ByVal lCondition As String) As System.Data.DataSet
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@PatientSuperBillId"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = lCondition


        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("GetVisitSummary", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("GetVisitSummary", lSpParameter)
        End If

        Return lDs

    End Function
    Public Function GetVisitDetail(ByVal pPatientId As String, ByVal pDosFrom As String, ByVal pDOSTo As String) As System.Data.DataSet
        Dim lSpParameter(3) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@PatientId"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = pPatientId

        lSpParameter(1).ParameterName = "@DOSFrom"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = pDosFrom

        lSpParameter(2).ParameterName = "@DOSTo"
        lSpParameter(2).ParameterType = ParameterType.Varchar
        lSpParameter(2).ParameterValue = pDOSTo


        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("GetVisitDetail", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("GetVisitDetail", lSpParameter)
        End If

        Return lDs

    End Function
    'Added by: KanwalJeet
    Public Function UpdateComments() As Boolean
        Dim lCondition As String
        Dim lQuery As String

        With Me.PatientSuperBill

            lCondition = "And PatientSuperBillID = " & .PatientSuperBillID

            lQuery = "Update PatientSuperBill Set " _
                        & "Comments ='" & .Comments & "' " _
                        & "Where 1 = 1 " _
                        & lCondition
        End With

        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand(lQuery)
        Else
            Connection.ExecuteCommand(lQuery)
        End If


    End Function
    Public Function LoadComments(ByVal pPatientSuperBillDB As PatientSuperBillDB, ByVal pPSBID As Integer) As System.Data.DataSet

        Dim lQuery As String
        Dim lDs As New DataSet()

        lQuery = "Select Comments from PatientSuperBill " _
                & "Where PatientSuperBillID='" & pPSBID & "'"
        'If Connection.IsTransactionAlive() Then

        'Else
        lDs = (Connection.ExecuteQuery(lQuery))

        'End If
        Return lDs
    End Function
    Public Function InsertComments() As Boolean

        Dim lCondition As String
        Dim lQuery As String

        With Me.PatientSuperBill

            lCondition = "And PatientSuperBillID = " & .PatientSuperBillID

            lQuery = "Update PatientSuperBill Set " _
                        & "Comments ='" & .Comments & "' " _
                        & "Where 1 = 1 " _
                        & lCondition
        End With

        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand(lQuery)
        Else
            Connection.ExecuteCommand(lQuery)
        End If

    End Function
    Public Function GetVisitSummarySearchDS(ByVal pDateFrom As String, ByVal pDateTo As String, ByVal pPatientID As String, ByVal pFavInsID As String, ByVal pPvdID As String, ByVal pVisitStatus As String) As DataSet
        Dim lCondition As String = ""
        Dim lCond2 As String = ""
        Dim lQuery As String = ""
        Dim lds As New DataSet
        Try


            If pDateFrom <> "" AndAlso pDateTo <> "" Then
                lCondition = lCondition & " And VisitDisplayDate between '" & pDateFrom & "' and '" & pDateTo & "' "
            End If
            If pPatientID <> "" Then
                lCondition = lCondition & " And PatientId='" & pPatientID & "' "
            End If

            If pFavInsID <> "" Then
                lCondition = lCondition & " And PrimaryInsuranceCompanyId='" & pFavInsID & "' "
            End If

            If pPvdID <> "" Then
                lCondition = lCondition & " And PrescriberID='" & pPvdID & "' "
            End If


            If pVisitStatus = "U" Then
                lCondition = lCondition & " And Balance>0 "
            End If
            If pVisitStatus = "P" Then
                lCondition = lCondition & " And (Balance=0 Or Balance<0) "
            End If


            lQuery = "select * from (SELECT  PatientSuperBill.PatientSuperBillId,PatientSuperBill.PatientId,PatientSuperBill.PrescriberID,PatientSuperBill.PrimaryInsuranceCompanyId,DateOfService,PatientName,DOB," _
                        & "VisitID=substring(Cast(Year(EntryDate) as Varchar),1,4) + '-' + Right(REPLICATE('0', 2)  + Cast(Month(EntryDate) as Varchar),2) + '-' + Right(REPLICATE('0', 5) + Cast(VisitDisplayID As Varchar),5)," _
                        & "VisitStatus, VisitDisplayDate,TotalCharges=sum(charges*days),PatientSuperBill.Status as PSBStatus," _
                        & "InsurancePayment=IsNull(dbo.GetVisitPayment('I',PatientSuperBill.PatientSuperbillID),0)," _
                        & "PatientPayment=IsNull(dbo.GetVisitPayment('P',PatientSuperBill.PatientSuperbillID),0), " _
                        & "Adjustment=IsNull(dbo.GetTotalAdjustment(PatientSuperBill.PatientSuperbillID),0) ," _
                        & "Balance=sum(charges*days)-IsNull(dbo.GetVisitPayment('I',PatientSuperBill.PatientSuperbillID),0)-IsNull(dbo.GetVisitPayment('P',PatientSuperBill.PatientSuperbillID),0)+IsNull(dbo.GetTotalAdjustment(PatientSuperBill.PatientSuperbillID),0)," _
                        & "Provider=IsNull(dbo.GetProviderName(PatientSuperBill.PrescriberID),'') " _
                        & "FROM PatientSuperBill,PatientCPT where PatientSuperBill.PatientSuperBillId = PatientCPT.PatientSuperBillId  " _
                        & "And [Status] = 'Approved' " _
                        & "group by PatientSuperBill.PatientSuperBillId,PatientSuperBill.PatientId,PatientSuperBill.PrimaryInsuranceCompanyId,DateOfService,PatientName,DOB,VisitDisplayID,VisitStatus,VisitDisplayDate,PatientSuperBill.Status,PatientSuperBill.PrescriberID,PatientSuperBill.EntryDate) FT where 1=1 " _
                        & lCondition _
                        & "order by VisitDisplayDate desc"

         

            'If (pPatientID = "") Then
            '    lQuery = "SELECT  PatientSuperBill.PatientSuperBillId,DateOfService,PatientName,DOB," _
            '    & "VisitID=substring(Cast(Year(VisitDisplayDate) as Varchar),1,4) + '-' + Right(REPLICATE('0', 2)  + Cast(Month(VisitDisplayDate) as Varchar),2) + '-' + Right(REPLICATE('0', 5) + Cast(VisitDisplayID As Varchar),5)," _
            '    & "VisitStatus, VisitDisplayDate,TotalCharges=sum(charges*days),PatientSuperBill.Status as PSBStatus," _
            '    & "InsurancePayment=IsNull(dbo.GetVisitPayment('I',PatientSuperBill.PatientSuperbillID),0)," _
            '    & "PatientPayment=IsNull(dbo.GetVisitPayment('P',PatientSuperBill.PatientSuperbillID),0), " _
            '    & "Adjustment=IsNull(dbo.GetTotalAdjustment(PatientSuperBill.PatientSuperbillID),0) ," _
            '    & "Balance='0.0'" _
            '    & "FROM PatientSuperBill,PatientCPT where PatientSuperBill.PatientSuperBillId = PatientCPT.PatientSuperBillId  " _
            '    & "And [Status] = 'Approved' and DateOfService between '" & pDateFrom & "' and '" & pDateTo & "'" _
            '    & "group by PatientSuperBill.PatientSuperBillId,DateOfService,PatientName,DOB,VisitDisplayID,VisitStatus,VisitDisplayDate,PatientSuperBill.Status " _
            '    & "order by DateOfService desc"
            'Else
            '    lQuery = "SELECT  PatientSuperBill.PatientSuperBillId,DateOfService,PatientName,DOB," _
            '    & "VisitID=substring(Cast(Year(VisitDisplayDate) as Varchar),1,4) + '-' + Right(REPLICATE('0', 2)  + Cast(Month(VisitDisplayDate) as Varchar),2) + '-' + Right(REPLICATE('0', 5) + Cast(VisitDisplayID As Varchar),5)," _
            '    & "VisitStatus, VisitDisplayDate,TotalCharges=sum(charges*days),PatientSuperBill.Status as PSBStatus," _
            '    & "InsurancePayment=IsNull(dbo.GetVisitPayment('I',PatientSuperBill.PatientSuperbillID),0)," _
            '    & "PatientPayment=IsNull(dbo.GetVisitPayment('P',PatientSuperBill.PatientSuperbillID),0), " _
            '    & "Adjustment=IsNull(dbo.GetTotalAdjustment(PatientSuperBill.PatientSuperbillID),0) ," _
            '    & "Balance='0.0'" _
            '    & "FROM PatientSuperBill,PatientCPT where" _
            '    & "PatientSuperBill.PatientSuperBillId = PatientCPT.PatientSuperBillId  " _
            '    & "And [Status] = 'Approved' " _
            '    & "And DateOfService between '" & pDateFrom & "' and '" & pDateTo & "'" _
            '    & "and PatientSuperBill.PatientId='" & pPatientID & "' " _
            '    & "group by PatientSuperBill.PatientSuperBillId,DateOfService,PatientName,DOB,VisitDisplayID,VisitStatus,VisitDisplayDate,PatientSuperBill.Status " _
            '    & "order by DateOfService desc"
            'End If




            If Connection.IsTransactionAlive() Then
                lds = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lds = Connection.ExecuteQuery(lQuery)
            End If
            Return lds
        Catch ex As Exception
            Return Nothing
        End Try
    End Function
    Public Sub UpdatePsbFromHcfa(ByVal pHcfaDB As HCFADBUpdated)

        Dim lQuery As String
        Dim lCondition As String

        lCondition = "And PatientSuperBillID = " & Me.PatientSuperBill.PatientSuperBillID

        With pHcfaDB
            lQuery = "Update PatientSuperBill Set " _
                        & "PatientId ='" & .Patient.PatientID & "', " _
                        & "PatientName ='" & Trim(.Patient.LastName & ", " & .Patient.FirstName & " " & .Patient.MiddleName) & "', " _
                        & "DOB ='" & .Patient.DOB & "', " _
                        & "Address ='" & Trim(.Patient.AddressLine1 & " " & .Patient.AddressLine2) & "', " _
                        & "City ='" & .Patient.City & "', " _
                        & "State='" & .Patient.StateID & "', " _
                        & "ZipCode='" & .Patient.ZipCode & "', " _
                        & "PrimaryInsuranceCompanyId ='" & .MainInsuranceCompany.FavouriteInsuranceID & "', " _
                        & "PrimaryInsuranceCompanyName ='" & .MainInsuranceCompany.CompanyName & "', " _
                        & "SecondryInsuranceCompanyId ='" & .OtherInsuranceCompany.FavouriteInsuranceID & "', " _
                        & "SecondryInsuranceCompanyName ='" & .OtherInsuranceCompany.CompanyName & "', " _
                        & "GuarantorName ='" & IIf(.MainPatientInsurance.RelationshipToPrimaryInsurer.ToUpper = "SELF", "Self", Trim(.InsurerPatient.LastName & ", " & .InsurerPatient.FirstName & " " & .InsurerPatient.MiddleName)) & "', " _
                        & "ReferringProviderNPI ='" & .ReferencePvd.NPI & "', " _
                        & "FacilityID ='" & .ServiceFacility.FacilityID & "',  " _
                        & "BillingProviderId ='" & .BillingPvd.BillingProviderId & "'  " _
                        & "Where 1 = 1 " _
                        & lCondition

        End With


        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand(lQuery)
        Else
            Connection.ExecuteCommand(lQuery)
        End If
    End Sub
    Public Function GetPatientSuperBillForApplyPayment(ByVal lCondition As String) As System.Data.DataSet
        Dim lSpParameter(0) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@Cond"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = lCondition

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("GetPatientSuperBillNew", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("GetPatientSuperBillNew", lSpParameter)
        End If

        Return lDs

    End Function
    Public Function InsertAdjustmentForVisit(ByRef pAdjustment As Adjustment, ByVal pUserID As String, ByVal pVisitID As String, ByVal lCptsAndCharges As String) As String
        Dim lAdjId As String = ""
        Dim lAdjDB As AdjustmentDB
        Dim lReversedRows() As String
        Try
            If (lCptsAndCharges.Contains("|")) Then
                lReversedRows = lCptsAndCharges.Split("|")
                For Each lRow As String In lReversedRows
                    If (lRow.Contains(",") AndAlso lRow.Contains(":")) Then
                        lAdjDB = New AdjustmentDB
                        lAdjDB.AdjustmentDate = Date.Now
                        lAdjDB.VisitID = pVisitID
                        lAdjDB.AdjustmentDescription = "Contractual adjustment-CA-Dr"
                        lAdjDB.ReasonCode = "TMA80"
                        lAdjDB.AdjustmentType = "CR"
                        lAdjDB.PaymentDtlID = ""
                        lAdjDB.PaymentID = ""
                        lAdjDB.CPTCode = lRow.Split(",")(0).ToString.Split(":")(1)
                        lAdjDB.Amount = lRow.Split(",")(1).ToString.Split(":")(1)
                        lAdjDB.UserID = pUserID
                        pAdjustment.Adjustment = lAdjDB
                        lAdjId = pAdjustment.InsertAdjustmentOnly()
                    End If
                Next
            End If
            Return lAdjId
        Catch ex As Exception

        End Try
    End Function
    Public Function GetCPTFromDateRange(ByVal pCPTCode As String, ByVal pFrom As DateTime, ByVal pTo As DateTime) As DataSet

        Dim lQuery As String
        Dim lCondition As String
        Dim lDs As New DataSet
        Try


            lQuery = "Select *,Flag='CPT : ' + Code,LastName + ', '  + FirstName as DoctorName From PatientSuperBill PSB, PatientCPT CPT,Employee Emp" & _
           " Where(PSB.PatientSuperBillId = CPT.PatientSuperBillId) and Emp.EmployeeID=PSB.PrescriberID" & _
    " And PSB.IsDeleted = 'N'" & _
    " And CPT.Code = '" & pCPTCode + "'" & _
    " And PSB.DateOfService Between '" + pFrom + "'  And '" + pTo + "'"



            If Not Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteQuery(lQuery)
            Else
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            End If

            Return lDs

        Catch ex As NullReferenceException
            Return Nothing
        End Try

    End Function
    Public Function GetICDFromDateRange(ByVal pICDCode As String, ByVal pFrom As DateTime, ByVal pTo As DateTime) As DataSet

        Dim lQuery As String
        Dim lCondition As String
        Dim lDs As New DataSet
        Try


            lQuery = "Select *,Flag='ICD : ' + Code,LastName + ', '  + FirstName as DoctorName  From PatientSuperBill PSB, PatientICD ICD ,Employee Emp" & _
           " Where(PSB.PatientSuperBillId = ICD.PatientSuperBillId)" & _
" and Emp.employeeID = PSB.PrescriberID" & _
" And PSB.IsDeleted = 'N'" & _
" And ICD.Code = '" + pICDCode + "'" & _
" And PSB.DateOfService Between '" + pFrom + "'  And '" + pTo + "'"



            If Not Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteQuery(lQuery)
            Else
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            End If

            Return lDs

        Catch ex As Exception
            Return Nothing
        End Try

    End Function
#End Region
End Class