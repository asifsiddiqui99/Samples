Imports Microsoft.VisualBasic
Public Class HCFADBUpdated

#Region "Fields"



    Private mHCFAID As String = ""
    Private mHCFADisplayID As String = "1"
    Private mPatientSuperBillID As String = ""
    Private mHCFAPreparedDate As String = ""
    Private mCreateByUserID As String = ""
    Private mUpdateByUserID As String = ""
    Private mIsSend As String = ""
    Private mIsBatch As String = ""
    Private mHCFAType As String = ""
    Private mHCFANotes As String = ""
    Private mHCFAGenerationSeqNo As String = ""

    Private mMainInsuranceCompany As New InsuranceDB
    Private mOtherInsuranceCompany As New InsuranceDB

    Private mMainPatientInsurance As New PatientInsuranceDB
    Private mOtherPatientInsurance As New PatientInsuranceDB

    Private mPatient As New PatientDBExtended
    Private mInsurerPatient As New PatientDBExtended
    Private mOtherInsurerPatient As New PatientDBExtended

    Private mPatientConditionEmployment As String = ""
    Private mPatientConditionAutoAccident As String = ""
    Private mPatientConditionAutoAccPlace As String = ""
    Private mPatientConditionOtherAccident As String = ""

    Private mSignOnFile As String = ""
    Private mSignDate As String = ""
    Private mAuthorizedPersonSign As String = ""
    Private mDateOfOccurance As String = ""
    Private mPreviousOccuranceDate As String = ""
    Private mPatUnableToWorkFrom As String = ""
    Private mPatUnableToWorkTo As String = ""

    Private mReferencePvd As New ReferringProviderDB

    Private mHospitalizationDateFrom As String = ""
    Private mHospitalizationDateTo As String = ""
    Private mField19 As String = ""
    Private mIsOutsideLab As String = ""
    Private mOutSideLabCharges As Double = 0.0

    Private mICD1 As String = ""
    Private mICD2 As String = ""
    Private mICD3 As String = ""
    Private mICD4 As String = ""
    Private mICD5 As String = ""
    Private mICD6 As String = ""
    Private mICD7 As String = ""
    Private mICD8 As String = ""
    Private mICD9 As String = ""
    Private mICD10 As String = ""
    Private mICD11 As String = ""
    Private mICD12 As String = ""

    Private mMedicadReSubCode As String = ""
    Private mMedicadReSubNo As String = ""
    Private mFederalTaxNo As String = ""
    Private mFederalTaxType As String = ""
    Private mPatientACNo As String = ""
    Private mAcceptAssignment As String = ""
    Private mAmountPaid As Double = 0.0
    Private mBalanceDue As Double = 0.0
    Private mTotalCharges As Double = 0.0

    Private mRenderingProvider As New EmployeeDB
    Private mServiceFacility As New FacilityDB
    Private mBillingPvd As New BillingProviderDB

    Private mIsActive As String = "Y"

    Private mServFacSecIdQualifier As String = ""
    Private mServFacSecIdValue As String = ""
    Private mBPvdSecIdQualifier As String = ""
    Private mBPvdSecIdValue As String = ""
    Private mReservedField10d As String = ""

    Private mDateOfCurrentIllnessQual As String = ""

    Private mOtherDateQual1 As String = ""
    Private mOtherDateQual2 As String = ""

    Private mNameOfRefProviderQual As String = ""

    Private mRFNU8 As String = ""
    Private mRFNU9B As String = ""
#End Region

#Region "Properties"
    Public Property HCFAID() As String
        Get
            Return mHCFAID
        End Get
        Set(ByVal value As String)
            mHCFAID = value
        End Set
    End Property
    Public Property HCFADisplayID() As String
        Get
            Return mHCFADisplayID
        End Get
        Set(ByVal value As String)
            mHCFADisplayID = value
        End Set
    End Property
    Public Property PatientSuperBillID() As String
        Get
            Return mPatientSuperBillID
        End Get
        Set(ByVal value As String)
            mPatientSuperBillID = value
        End Set
    End Property
    Public Property HCFAPreparedDate() As String
        Get
            Return mHCFAPreparedDate
        End Get
        Set(ByVal value As String)
            mHCFAPreparedDate = value
        End Set
    End Property
    Public Property CreateByUserID() As String
        Get
            Return mCreateByUserID
        End Get
        Set(ByVal value As String)
            mCreateByUserID = value
        End Set
    End Property
    Public Property UpdateByUserID() As String
        Get
            Return mUpdateByUserID
        End Get
        Set(ByVal value As String)
            mUpdateByUserID = value
        End Set
    End Property
    Public Property IsSend() As String
        Get
            Return mIsSend
        End Get
        Set(ByVal value As String)
            mIsSend = value
        End Set
    End Property
    Public Property IsBatch() As String
        Get
            Return mIsBatch
        End Get
        Set(ByVal value As String)
            mIsBatch = value
        End Set
    End Property
    Public Property HCFAType() As String
        Get
            Return mHCFAType
        End Get
        Set(ByVal value As String)
            mHCFAType = value
        End Set
    End Property
    Public Property HCFANotes() As String
        Get
            Return mHCFANotes
        End Get
        Set(ByVal value As String)
            mHCFANotes = value
        End Set
    End Property
    Public Property HCFAGenerationSeqNo() As String
        Get
            Return mHCFAGenerationSeqNo
        End Get
        Set(ByVal value As String)
            mHCFAGenerationSeqNo = value
        End Set
    End Property

    Public Property MainInsuranceCompany() As InsuranceDB
        Get
            Return mMainInsuranceCompany
        End Get
        Set(ByVal value As InsuranceDB)
            mMainInsuranceCompany = value
        End Set
    End Property
    Public Property OtherInsuranceCompany() As InsuranceDB
        Get
            Return mOtherInsuranceCompany
        End Get
        Set(ByVal value As InsuranceDB)
            mOtherInsuranceCompany = value
        End Set
    End Property


    Public Property MainPatientInsurance() As PatientInsuranceDB
        Get
            Return mMainPatientInsurance
        End Get
        Set(ByVal value As PatientInsuranceDB)
            mMainPatientInsurance = value
        End Set
    End Property
    Public Property OtherPatientInsurance() As PatientInsuranceDB
        Get
            Return mOtherPatientInsurance
        End Get
        Set(ByVal value As PatientInsuranceDB)
            mOtherPatientInsurance = value
        End Set
    End Property

    Public Property Patient() As PatientDBExtended
        Get
            Return mPatient
        End Get
        Set(ByVal value As PatientDBExtended)
            mPatient = value
        End Set
    End Property
    Public Property InsurerPatient() As PatientDBExtended
        Get
            Return mInsurerPatient
        End Get
        Set(ByVal value As PatientDBExtended)
            mInsurerPatient = value
        End Set
    End Property
    Public Property OtherInsurerPatient() As PatientDBExtended
        Get
            Return mOtherInsurerPatient
        End Get
        Set(ByVal value As PatientDBExtended)
            mOtherInsurerPatient = value
        End Set
    End Property

    Public Property PatientConditionEmployment() As String
        Get
            Return mPatientConditionEmployment
        End Get
        Set(ByVal value As String)
            mPatientConditionEmployment = value
        End Set
    End Property
    Public Property PatientConditionAutoAccident() As String
        Get
            Return mPatientConditionAutoAccident
        End Get
        Set(ByVal value As String)
            mPatientConditionAutoAccident = value
        End Set
    End Property
    Public Property PatientConditionAutoAccPlace() As String
        Get
            Return mPatientConditionAutoAccPlace
        End Get
        Set(ByVal value As String)
            mPatientConditionAutoAccPlace = value
        End Set
    End Property
    Public Property PatientConditionOtherAccident() As String
        Get
            Return mPatientConditionOtherAccident
        End Get
        Set(ByVal value As String)
            mPatientConditionOtherAccident = value
        End Set
    End Property

    Public Property SignOnFile() As String
        Get
            Return mSignOnFile
        End Get
        Set(ByVal value As String)
            mSignOnFile = value
        End Set
    End Property
    Public Property SignDate() As String
        Get
            Return mSignDate
        End Get
        Set(ByVal value As String)
            mSignDate = value
        End Set
    End Property
    Public Property AuthorizedPersonSign() As String
        Get
            Return mAuthorizedPersonSign
        End Get
        Set(ByVal value As String)
            mAuthorizedPersonSign = value
        End Set
    End Property
    Public Property DateOfOccurance() As String
        Get
            Return mDateOfOccurance
        End Get
        Set(ByVal value As String)
            mDateOfOccurance = value
        End Set
    End Property
    Public Property PreviousOccuranceDate() As String
        Get
            Return mPreviousOccuranceDate
        End Get
        Set(ByVal value As String)
            mPreviousOccuranceDate = value
        End Set
    End Property
    Public Property PatUnableToWorkFrom() As String
        Get
            Return mPatUnableToWorkFrom
        End Get
        Set(ByVal value As String)
            mPatUnableToWorkFrom = value
        End Set
    End Property
    Public Property PatUnableToWorkTo() As String
        Get
            Return mPatUnableToWorkTo
        End Get
        Set(ByVal value As String)
            mPatUnableToWorkTo = value
        End Set
    End Property


    Public Property ReferencePvd() As ReferringProviderDB
        Get
            Return mReferencePvd
        End Get
        Set(ByVal value As ReferringProviderDB)
            mReferencePvd = value
        End Set
    End Property


    Public Property HospitalizationDateFrom() As String
        Get
            Return mHospitalizationDateFrom
        End Get
        Set(ByVal value As String)
            mHospitalizationDateFrom = value
        End Set
    End Property
    Public Property HospitalizationDateTo() As String
        Get
            Return mHospitalizationDateTo
        End Get
        Set(ByVal value As String)
            mHospitalizationDateTo = value
        End Set
    End Property
    Public Property Field19() As String
        Get
            Return mField19
        End Get
        Set(ByVal value As String)
            mField19 = value
        End Set
    End Property

    Public Property IsOutsideLab() As String
        Get
            Return mIsOutsideLab
        End Get
        Set(ByVal value As String)
            mIsOutsideLab = value
        End Set
    End Property
    Public Property OutsideLabCharges() As Double
        Get
            Return mOutSideLabCharges
        End Get
        Set(ByVal value As Double)
            mOutSideLabCharges = value
        End Set
    End Property
    Public Property ICD1() As String
        Get
            Return mICD1
        End Get
        Set(ByVal value As String)
            mICD1 = value
        End Set
    End Property
    Public Property ICD2() As String
        Get
            Return mICD2
        End Get
        Set(ByVal value As String)
            mICD2 = value
        End Set
    End Property
    Public Property ICD3() As String
        Get
            Return mICD3
        End Get
        Set(ByVal value As String)
            mICD3 = value
        End Set
    End Property
    Public Property ICD4() As String
        Get
            Return mICD4
        End Get
        Set(ByVal value As String)
            mICD4 = value
        End Set
    End Property
    Public Property ICD5() As String
        Get
            Return mICD5
        End Get
        Set(ByVal value As String)
            mICD5 = value
        End Set
    End Property
    Public Property ICD6() As String
        Get
            Return mICD6
        End Get
        Set(ByVal value As String)
            mICD6 = value
        End Set
    End Property
    Public Property ICD7() As String
        Get
            Return mICD7
        End Get
        Set(ByVal value As String)
            mICD7 = value
        End Set
    End Property
    Public Property ICD8() As String
        Get
            Return mICD8
        End Get
        Set(ByVal value As String)
            mICD8 = value
        End Set
    End Property
    Public Property ICD9() As String
        Get
            Return mICD9
        End Get
        Set(ByVal value As String)
            mICD9 = value
        End Set
    End Property
    Public Property ICD10() As String
        Get
            Return mICD10
        End Get
        Set(ByVal value As String)
            mICD10 = value
        End Set
    End Property
    Public Property ICD11() As String
        Get
            Return mICD11
        End Get
        Set(ByVal value As String)
            mICD11 = value
        End Set
    End Property
    Public Property ICD12() As String
        Get
            Return mICD12
        End Get
        Set(ByVal value As String)
            mICD12 = value
        End Set
    End Property

    Public Property MedicadReSubCode() As String
        Get
            Return mMedicadReSubCode
        End Get
        Set(ByVal value As String)
            mMedicadReSubCode = value
        End Set
    End Property
    Public Property MedicadReSubNo() As String
        Get
            Return mMedicadReSubNo
        End Get
        Set(ByVal value As String)
            mMedicadReSubNo = value
        End Set
    End Property
    Public Property FederalTaxNo() As String
        Get
            Return mFederalTaxNo
        End Get
        Set(ByVal value As String)
            mFederalTaxNo = value
        End Set
    End Property
    Public Property FederalTaxType() As String
        Get
            Return mFederalTaxType
        End Get
        Set(ByVal value As String)
            mFederalTaxType = value
        End Set
    End Property


    Public Property PatientACNo() As String
        Get
            Return mPatientACNo
        End Get
        Set(ByVal value As String)
            mPatientACNo = value
        End Set
    End Property
    Public Property AcceptAssignment() As String
        Get
            Return mAcceptAssignment
        End Get
        Set(ByVal value As String)
            mAcceptAssignment = value
        End Set
    End Property

    Public Property TotalCharges() As Double
        Get
            Return mTotalCharges
        End Get
        Set(ByVal value As Double)
            mTotalCharges = value
        End Set
    End Property
    Public Property AmountPaid() As Double
        Get
            Return mAmountPaid
        End Get
        Set(ByVal value As Double)
            mAmountPaid = value
        End Set
    End Property
    Public Property BalanceDue() As Double
        Get
            Return mBalanceDue
        End Get
        Set(ByVal value As Double)
            mBalanceDue = value
        End Set
    End Property


    Public Property RenderingProvider() As EmployeeDB
        Get
            Return mRenderingProvider
        End Get
        Set(ByVal value As EmployeeDB)
            mRenderingProvider = value
        End Set
    End Property
    Public Property ServiceFacility() As FacilityDB
        Get
            Return mServiceFacility
        End Get
        Set(ByVal value As FacilityDB)
            mServiceFacility = value
        End Set
    End Property
    Public Property BillingPvd() As BillingProviderDB
        Get
            Return mBillingPvd
        End Get
        Set(ByVal value As BillingProviderDB)
            mBillingPvd = value
        End Set
    End Property
    Public Property IsActive() As String
        Get
            Return mIsActive
        End Get
        Set(ByVal value As String)
            mIsActive = value
        End Set
    End Property

    Public Property ServFacSecIdQualifier() As String
        Get
            Return mServFacSecIdQualifier
        End Get
        Set(ByVal value As String)
            mServFacSecIdQualifier = value
        End Set
    End Property

    Public Property ServFacSecIdValue() As String
        Get
            Return mServFacSecIdValue
        End Get
        Set(ByVal value As String)
            mServFacSecIdValue = value
        End Set
    End Property

    Public Property BPvdSecIdQualifier() As String
        Get
            Return mBPvdSecIdQualifier
        End Get
        Set(ByVal value As String)
            mBPvdSecIdQualifier = value
        End Set
    End Property

    Public Property BPvdSecIdValue() As String
        Get
            Return mBPvdSecIdValue
        End Get
        Set(ByVal value As String)
            mBPvdSecIdValue = value
        End Set
    End Property

    Public Property ReservedField10d() As String
        Get
            Return mReservedField10d
        End Get
        Set(ByVal value As String)
            mReservedField10d = value
        End Set
    End Property

    Public Property DateOfCurrentIllnessQual() As String
        Get
            Return mDateOfCurrentIllnessQual
        End Get
        Set(ByVal value As String)
            mDateOfCurrentIllnessQual = value
        End Set
    End Property

    Public Property OtherDateQual1() As String
        Get
            Return mOtherDateQual1
        End Get
        Set(ByVal value As String)
            mOtherDateQual1 = value
        End Set
    End Property

    Public Property OtherDateQual2() As String
        Get
            Return mOtherDateQual2
        End Get
        Set(ByVal value As String)
            mOtherDateQual2 = value
        End Set
    End Property

    Public Property NameOfRefProviderQual() As String
        Get
            Return mNameOfRefProviderQual
        End Get
        Set(ByVal value As String)
            mNameOfRefProviderQual = value
        End Set
    End Property

    Public Property RFNU8() As String
        Get
            Return mRFNU8
        End Get
        Set(ByVal value As String)
            mRFNU8 = value
        End Set
    End Property

    Public Property RFNU9B() As String
        Get
            Return mRFNU9B
        End Get
        Set(ByVal value As String)
            mRFNU9B = value
        End Set
    End Property
#End Region

End Class

Public Class HCFAUpdated
#Region "Fields"

    Private mConnection As Connection
    Private mConnectionString
    Private mHCFAUpdated As New HCFADBUpdated
#End Region

#Region "Property"
    Public ReadOnly Property Connection() As ElixirLibrary.Connection
        Get
            Return mConnection
        End Get
    End Property

    Public ReadOnly Property ConnectionString() As String
        Get
            Return mConnectionString
        End Get
    End Property

  
    Public Property HCFAUpdated() As HCFADBUpdated
        Get
            Return mHCFAUpdated
        End Get
        Set(ByVal value As HCFADBUpdated)
            mHCFAUpdated = value
        End Set
    End Property
#End Region

#Region "Constructor"
    ''' <summary>
    ''' Creates new Conection Object based on Given Connection String 
    ''' </summary>
    ''' <param name="pConnectionString">
    ''' Contains Connection String 
    ''' </param>
    ''' <remarks>
    ''' Use when not using transaction
    ''' Must Specify Connection String other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnectionString As String)
        If pConnectionString = "" Then
            Throw New ArgumentException("ConnectionString can not be empty")
        End If

        mConnectionString = pConnectionString
        mConnection = New Connection(mConnectionString)

    End Sub
    ''' <summary>
    ''' Assign given connection to the current Object
    ''' </summary>
    ''' <param name="pConnection">
    ''' Contains refrence to the connection object
    ''' </param>
    ''' <remarks>
    ''' Use when  using Transaction
    ''' Must Specify Connection other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnection As Connection)
        If pConnection Is Nothing Then
            Throw New ArgumentException("Connection can not be empty")
        End If

        mConnection = pConnection
    End Sub
#End Region

#Region "Method"
    Public Function GetRecordByPatientSuperBillID() As Boolean
        Dim lSpParameter(0) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@PatientSuperBillID"
        lSpParameter(0).ParameterType = ParameterType.BigInt
        lSpParameter(0).ParameterValue = Me.mHCFAUpdated.PatientSuperBillID

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("GetHCFAICDByPatientSuperBillID", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("GetHCFAICDByPatientSuperBillID", lSpParameter)
        End If


        With lDs.Tables(0)
            If .Rows.Count > 0 Then

                Me.mHCFAUpdated.PatientSuperBillID = .Rows(0)("PatientSuperBillID")
                'Me.mHCFAUpdated.DateOfService = .Rows(0)("DateOfService")
                'Me.mHCFAUpdated.SuperBillTemplateID = .Rows(0)("SuperBillTemplateID")
                'Me.mHCFAUpdated.PatientId = .Rows(0)("PatientId")
             
                'Me.mHCFAUpdated.PrimaryInsuranceCompanyId = .Rows(0)("PrimaryInsuranceCompanyId")
                'Me.mHCFAUpdated.PatientPrimaryInsuranceCompanyName = .Rows(0)("PrimaryInsuranceCompanyName")
                'Me.mHCFAUpdated.SecondryInsuranceCompanyId = .Rows(0)("SecondryInsuranceCompanyId")
                'Me.mHCFAUpdated.SecondryInsuranceCompanyName = .Rows(0)("SecondryInsuranceCompanyName")
                'Me.mHCFAUpdated.GuarantorName = .Rows(0)("GuarantorName")
                'Me.mHCFAUpdated.GuarantorID = .Rows(0)("GuarantorID")
                Me.mHCFAUpdated.BalanceDue = .Rows(0)("Balance")
                'Me.mHCFAUpdated.PrescriberID = .Rows(0)("PrescriberID")

                If (Not IsDBNull(.Rows(0)("ICD1"))) Then
                    Me.mHCFAUpdated.ICD1 = .Rows(0)("ICD1")
                Else
                    Me.mHCFAUpdated.ICD1 = ""
                End If

                If (Not IsDBNull(.Rows(0)("ICD2"))) Then
                    Me.mHCFAUpdated.ICD2 = .Rows(0)("ICD2")
                Else
                    Me.mHCFAUpdated.ICD2 = ""
                End If

                If (Not IsDBNull(.Rows(0)("ICD3"))) Then
                    Me.mHCFAUpdated.ICD3 = .Rows(0)("ICD3")
                Else
                    Me.mHCFAUpdated.ICD3 = ""
                End If

                If (Not IsDBNull(.Rows(0)("ICD4"))) Then
                    Me.mHCFAUpdated.ICD4 = .Rows(0)("ICD4")
                Else
                    Me.mHCFAUpdated.ICD4 = ""
                End If


                Return True
            End If
        End With

        Return False

    End Function


    Public Function GetAllRecords() As System.Data.DataSet
        Dim lCondition As String = ""
        Dim lDs As New DataSet()

        lDs = GetAllRecords(lCondition)

        Return lDs
    End Function

    Public Function GetAllRecords(ByVal lCondition As String) As System.Data.DataSet
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "HCFAUpdated"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = lCondition

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("SelectAllRecords", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
        End If

        Return lDs

    End Function



    Public Function GetPendingClaims(ByVal lCondition As String) As System.Data.DataSet
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@Cond"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = lCondition

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("GetPendingClaims", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("GetPendingClaims", lSpParameter)
        End If

        Return lDs

    End Function

    Public Function GetPendingClaimDetails(ByVal lCondition As String) As System.Data.DataSet
        Dim lSpParameter(0) As SpParameter
        Dim lDs As New DataSet()


        lSpParameter(0).ParameterName = "@Cond"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = lCondition


        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("GetPendingPaymentDetails", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("GetPendingPaymentDetails", lSpParameter)
        End If

        Return lDs

    End Function
    Public Function GetPendingClaimDetailsEdit(ByVal pPaymentId As Int32) As System.Data.DataSet
        Dim lSpParameter(0) As SpParameter
        Dim lDs As New DataSet()


        lSpParameter(0).ParameterName = "@PaymentId"
        lSpParameter(0).ParameterType = ParameterType.BigInt
        lSpParameter(0).ParameterValue = pPaymentId


        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("GetPendingPaymentDetailsEdit", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("GetPendingPaymentDetailsEdit", lSpParameter)
        End If

        Return lDs

    End Function

    'HCFA Updated Records Loading
    '***
    'Created by Faiza Mumtaz
    '***
    Public Function GetRecordByID() As Boolean



        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "HCFAUpdated"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = "And HCFAID = " & HCFAUpdated.HCFAID

        Try

            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery("SelectAllRecords", lSpParameter)
            Else
                lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
            End If


            With lDs.Tables(0)
                If .Rows.Count > 0 Then


                    Me.HCFAUpdated.HCFAID = .Rows(0)("HCFAID")
                    Me.HCFAUpdated.HCFADisplayID = .Rows(0)("HCFADisplayID")
                    Me.HCFAUpdated.PatientSuperBillID = .Rows(0)("PatientSuperBillID")
                    Me.HCFAUpdated.HCFAPreparedDate = .Rows(0)("HCFAPreparedDate")
                    Me.HCFAUpdated.CreateByUserID = .Rows(0)("CreateByUserID")
                    Me.HCFAUpdated.UpdateByUserID = .Rows(0)("UpdateByUserID")
                    Me.HCFAUpdated.IsSend = .Rows(0)("IsSend")
                    Me.HCFAUpdated.IsBatch = .Rows(0)("IsBatch")
                    Me.HCFAUpdated.HCFAType = .Rows(0)("HCFAType")
                    Me.HCFAUpdated.HCFANotes = .Rows(0)("HCFANotes")
                    Me.HCFAUpdated.HCFAGenerationSeqNo = .Rows(0)("HCFAGenerationSeqNo")


                    Me.HCFAUpdated.MainInsuranceCompany.FavouriteInsuranceID = .Rows(0)("MainICFavouriteInsuranceID")
                    Me.HCFAUpdated.MainInsuranceCompany.InsuranceID = .Rows(0)("MainICInsuranceID")
                    Me.HCFAUpdated.MainInsuranceCompany.CompanyName = .Rows(0)("MainICCompanyName")
                    Me.HCFAUpdated.MainInsuranceCompany.PayerID = .Rows(0)("MainICPayerID")
                    Me.HCFAUpdated.MainInsuranceCompany.AddressLine1 = .Rows(0)("MainICAddressLine1")
                    Me.HCFAUpdated.MainInsuranceCompany.AddressLine2 = .Rows(0)("MainICAddressLine2")
                    Me.HCFAUpdated.MainInsuranceCompany.City = .Rows(0)("MainICCity")
                    Me.HCFAUpdated.MainInsuranceCompany.State = .Rows(0)("MainICState")
                    Me.HCFAUpdated.MainInsuranceCompany.ZipCode = .Rows(0)("MainICZipCode")
                    Me.HCFAUpdated.MainInsuranceCompany.ContactName = .Rows(0)("MainICContactName")
                    Me.HCFAUpdated.MainInsuranceCompany.InsuranceType = .Rows(0)("MainICInsuranceType")
                    Me.HCFAUpdated.MainInsuranceCompany.WorkPhone = .Rows(0)("MainICWorkPhone")
                    Me.HCFAUpdated.MainInsuranceCompany.Fax = .Rows(0)("MainICFax")
                    Me.HCFAUpdated.MainInsuranceCompany.Email = .Rows(0)("MainICEmail")
                    Me.HCFAUpdated.MainInsuranceCompany.BillType = .Rows(0)("MainICBillType")
                    '  Me.HCFAUpdated.MainInsuranceCompany.IsDeleted = .Rows(0)("MainICIsDelete")

                    Me.HCFAUpdated.OtherInsuranceCompany.FavouriteInsuranceID = .Rows(0)("OtherICFavouriteInsuranceID")
                    Me.HCFAUpdated.OtherInsuranceCompany.InsuranceID = .Rows(0)("OtherICInsuranceID")
                    Me.HCFAUpdated.OtherInsuranceCompany.CompanyName = .Rows(0)("OtherICCompanyName")
                    Me.HCFAUpdated.OtherInsuranceCompany.PayerID = .Rows(0)("OtherICFavInsPayerID")
                    Me.HCFAUpdated.OtherInsuranceCompany.AddressLine1 = .Rows(0)("OtherICAddressLine1")
                    Me.HCFAUpdated.OtherInsuranceCompany.AddressLine2 = .Rows(0)("OtherICAddressLine2")
                    Me.HCFAUpdated.OtherInsuranceCompany.City = .Rows(0)("OtherICCity")
                    Me.HCFAUpdated.OtherInsuranceCompany.State = .Rows(0)("OtherICState")
                    Me.HCFAUpdated.OtherInsuranceCompany.ZipCode = .Rows(0)("OtherICZipCode")
                    Me.HCFAUpdated.OtherInsuranceCompany.ContactName = .Rows(0)("OtherICContactName")
                    Me.HCFAUpdated.OtherInsuranceCompany.InsuranceType = .Rows(0)("OtherICInsuranceType")
                    Me.HCFAUpdated.OtherInsuranceCompany.WorkPhone = .Rows(0)("OtherICWorkPhone")
                    Me.HCFAUpdated.OtherInsuranceCompany.Fax = .Rows(0)("OtherICFax")
                    Me.HCFAUpdated.OtherInsuranceCompany.Email = .Rows(0)("OtherICEmail")
                    Me.HCFAUpdated.OtherInsuranceCompany.BillType = .Rows(0)("OtherICBillType")
                    'Me.HCFAUpdated.OtherInsuranceCompany.IsDelete = .Rows(0)("")

                    Me.HCFAUpdated.MainPatientInsurance.PatientInsID = .Rows(0)("MainPIPatientInsID")
                    Me.HCFAUpdated.MainPatientInsurance.PatientID = .Rows(0)("MainPIPatientID")
                    Me.HCFAUpdated.MainPatientInsurance.Type = .Rows(0)("MainPIType")
                    Me.HCFAUpdated.MainPatientInsurance.RelationshipToPrimaryInsurer = .Rows(0)("MainPIRelationshipToPrimaryInsurer")
                    Me.HCFAUpdated.MainPatientInsurance.InsuranceCompanyID = .Rows(0)("MainPIInsuranceCompanyID")
                    Me.HCFAUpdated.MainPatientInsurance.InsuranceCompanyName = .Rows(0)("MainPIInsuranceCompany")
                    Me.HCFAUpdated.MainPatientInsurance.PayerId = .Rows(0)("MainPIPatientPayerId")
                    Me.HCFAUpdated.MainPatientInsurance.SubscriberID = .Rows(0)("MainPISubscriberID")
                    Me.HCFAUpdated.MainPatientInsurance.GroupNo = .Rows(0)("MainPIGroupNo")
                    Me.HCFAUpdated.MainPatientInsurance.PlanName = .Rows(0)("MainPIPlanName")
                    Me.HCFAUpdated.MainPatientInsurance.InsuredAuthorization = .Rows(0)("MainPIInsuredAuthorization")
                    Me.HCFAUpdated.MainPatientInsurance.Deductable = .Rows(0)("MainPIDeductable")
                    Me.HCFAUpdated.MainPatientInsurance.VisitCopayment = .Rows(0)("MainPIVisitCopayment")
                    Me.HCFAUpdated.MainPatientInsurance.SignatureOfFile = .Rows(0)("MainPISignatureOfFile")
                    Me.HCFAUpdated.MainPatientInsurance.SignatureDate = .Rows(0)("MainPISignatureDate")
                    Me.HCFAUpdated.MainPatientInsurance.Active = .Rows(0)("MainPIActive")
                    Me.HCFAUpdated.MainPatientInsurance.InsurerId = .Rows(0)("MainPIInsurerId")
                    Me.HCFAUpdated.MainPatientInsurance.EffectiveDateFrom = .Rows(0)("MainPIEffectiveDateFrom")
                    Me.HCFAUpdated.MainPatientInsurance.EffectiveDateTo = .Rows(0)("MainPIEffectiveDateTo")
                    Me.HCFAUpdated.MainPatientInsurance.AuthorizationNumber = .Rows(0)("MainPIAuthorizationNumber")
                    Me.HCFAUpdated.MainPatientInsurance.CoInsurance = .Rows(0)("MainPICoInsurance")
                    Me.HCFAUpdated.MainPatientInsurance.InsuranceCompanyPhoneNumber = .Rows(0)("MainPIInsuranceCompanyPhoneNumber")
                    Me.HCFAUpdated.MainPatientInsurance.InsurerInsuranceType = .Rows(0)("MainPIInsurerInsuranceType")
                    Me.HCFAUpdated.MainPatientInsurance.InsurerInsuranceId = .Rows(0)("MainPIInsurerInsuranceId")

                    Me.HCFAUpdated.OtherPatientInsurance.PatientInsID = .Rows(0)("OtherPIPatientInsID")
                    Me.HCFAUpdated.OtherPatientInsurance.PatientID = .Rows(0)("OtherPIPatientID")
                    Me.HCFAUpdated.OtherPatientInsurance.Type = .Rows(0)("OtherPIType")
                    Me.HCFAUpdated.OtherPatientInsurance.RelationshipToPrimaryInsurer = .Rows(0)("OtherPIRelationshipToPrimaryInsurer")
                    Me.HCFAUpdated.OtherPatientInsurance.InsuranceCompanyID = .Rows(0)("OtherPIInsuranceCompanyID")
                    Me.HCFAUpdated.OtherPatientInsurance.InsuranceCompanyName = .Rows(0)("OtherPIInsuranceCompany")
                    Me.HCFAUpdated.OtherPatientInsurance.PayerId = .Rows(0)("OtherPIPatientPayerId")
                    Me.HCFAUpdated.OtherPatientInsurance.SubscriberID = .Rows(0)("OtherPISubscriberID")
                    Me.HCFAUpdated.OtherPatientInsurance.GroupNo = .Rows(0)("OtherPIGroupNo")
                    Me.HCFAUpdated.OtherPatientInsurance.PlanName = .Rows(0)("OtherPIPlanName")
                    Me.HCFAUpdated.OtherPatientInsurance.InsuredAuthorization = .Rows(0)("OtherPIInsuredAuthorization")
                    Me.HCFAUpdated.OtherPatientInsurance.Deductable = .Rows(0)("OtherPIDeductable")
                    Me.HCFAUpdated.OtherPatientInsurance.VisitCopayment = .Rows(0)("OtherPIVisitCopayment")
                    Me.HCFAUpdated.OtherPatientInsurance.SignatureOfFile = .Rows(0)("OtherPISignatureOfFile")
                    Me.HCFAUpdated.OtherPatientInsurance.SignatureDate = .Rows(0)("OtherPISignatureDate")
                    Me.HCFAUpdated.OtherPatientInsurance.Active = .Rows(0)("OtherPIActive")
                    Me.HCFAUpdated.OtherPatientInsurance.InsurerId = .Rows(0)("OtherPIInsurerId")
                    Me.HCFAUpdated.OtherPatientInsurance.EffectiveDateFrom = .Rows(0)("OtherPIEffectiveDateFrom")
                    Me.HCFAUpdated.OtherPatientInsurance.EffectiveDateTo = .Rows(0)("OtherPIEffectiveDateTo")
                    Me.HCFAUpdated.OtherPatientInsurance.AuthorizationNumber = .Rows(0)("OtherPIAuthorizationNumber")
                    Me.HCFAUpdated.OtherPatientInsurance.CoInsurance = .Rows(0)("OtherPICoInsurance")
                    Me.HCFAUpdated.OtherPatientInsurance.InsuranceCompanyPhoneNumber = .Rows(0)("OtherPIInsuranceCompanyPhoneNumber")
                    Me.HCFAUpdated.OtherPatientInsurance.InsurerInsuranceType = .Rows(0)("OtherPIInsurerInsuranceType")
                    Me.HCFAUpdated.OtherPatientInsurance.InsurerInsuranceId = .Rows(0)("OtherPIInsurerInsuranceId")

                    Me.HCFAUpdated.Patient.PatientID = .Rows(0)("PatientPatientID")
                    Me.HCFAUpdated.Patient.PatientCode = .Rows(0)("PatientPatientCode")
                    Me.HCFAUpdated.Patient.Title = .Rows(0)("PatientTitle")
                    Me.HCFAUpdated.Patient.FirstName = .Rows(0)("PatientFirstName")
                    Me.HCFAUpdated.Patient.MiddleName = .Rows(0)("PatientMiddleName")
                    Me.HCFAUpdated.Patient.LastName = .Rows(0)("PatientLastName")
                    Me.HCFAUpdated.Patient.AddressLine1 = .Rows(0)("PatientAddressLine1")
                    Me.HCFAUpdated.Patient.AddressLine2 = .Rows(0)("PatientAddressLine2")
                    Me.HCFAUpdated.Patient.City = .Rows(0)("PatientCity")
                    Me.HCFAUpdated.Patient.StateID = .Rows(0)("PatientStateID")
                    Me.HCFAUpdated.Patient.ZipCode = .Rows(0)("PatientZipCode")
                    Me.HCFAUpdated.Patient.HomePhone = .Rows(0)("PatientHousePhone")
                    Me.HCFAUpdated.Patient.WorkPhone = .Rows(0)("PatientWorkPhone")
                    Me.HCFAUpdated.Patient.WorkPhoneExtension = .Rows(0)("PatientWorkPhoneExtension")
                    Me.HCFAUpdated.Patient.Fax = .Rows(0)("PatientFax")
                    Me.HCFAUpdated.Patient.Email = .Rows(0)("PatientEmail")
                    Me.HCFAUpdated.Patient.Occupation = .Rows(0)("PatientOccupation")
                    Me.HCFAUpdated.Patient.DOB = .Rows(0)("PatientDOB")
                    Me.HCFAUpdated.Patient.Gender = .Rows(0)("PatientGender")
                    Me.HCFAUpdated.Patient.InsuranceID = .Rows(0)("PatientInsuranceID")
                    Me.HCFAUpdated.Patient.InsuranceName = .Rows(0)("PatientInsuranceName")
                    Me.HCFAUpdated.Patient.NCPDPID = .Rows(0)("PatientNcpdpID")
                    Me.HCFAUpdated.Patient.PharmacyName = .Rows(0)("PatientPharmacyName")
                    Me.HCFAUpdated.Patient.IsDeleted = .Rows(0)("PatientIsDeleted")
                    Me.HCFAUpdated.Patient.PictureFilePath = .Rows(0)("PatientPictureFilePath")
                    Me.HCFAUpdated.Patient.SSN = .Rows(0)("PatientSSN")
                    Me.HCFAUpdated.Patient.PharmacyProvider = .Rows(0)("PatientPharmacyProvider")
                    Me.HCFAUpdated.Patient.MartialStatus = .Rows(0)("PatientMartialStatus")
                    Me.HCFAUpdated.Patient.CellPhoneNumber = .Rows(0)("PatientCellPhoneNumber")
                    Me.HCFAUpdated.Patient.EmergencyContactName = .Rows(0)("PatientEmergencyContactName")
                    Me.HCFAUpdated.Patient.EmergencyContactRelationship = .Rows(0)("PatientEmergencyContactRelationship")
                    Me.HCFAUpdated.Patient.EmergencyContactPhone = .Rows(0)("PatientEmergencyContactPhone")
                    Me.HCFAUpdated.Patient.EmergencyContactAddress = .Rows(0)("PatientEmergencyContactAddress")
                    Me.HCFAUpdated.Patient.EmergencyContactCity = .Rows(0)("PatientEmergencyContactCity")
                    Me.HCFAUpdated.Patient.EmergencyContactZip = .Rows(0)("PatientEmergencyContactZip")
                    Me.HCFAUpdated.Patient.EmergencyContactState = .Rows(0)("PatientEmergencyContactState")
                    Me.HCFAUpdated.Patient.EmployerName = .Rows(0)("PatientEmployerName")
                    Me.HCFAUpdated.Patient.EmploymentStatus = .Rows(0)("PatientEmploymentStatus")
                    Me.HCFAUpdated.Patient.EmployerAddressLine1 = .Rows(0)("PatientEmployerAddressLine1")
                    Me.HCFAUpdated.Patient.EmployerAddressLine2 = .Rows(0)("PatientEmployerAddressLine2")
                    Me.HCFAUpdated.Patient.EmployerPhoneNumber = .Rows(0)("PatientEmployerPhoneNumber")
                    Me.HCFAUpdated.Patient.EmployerCity = .Rows(0)("PatientEmployerCity")
                    Me.HCFAUpdated.Patient.EmployerZip = .Rows(0)("PatientEmployerZip")
                    Me.HCFAUpdated.Patient.EmployerState = .Rows(0)("PatientEmployerState")
                    Me.HCFAUpdated.Patient.ResponsibleName = .Rows(0)("PatientResponsibleName")
                    Me.HCFAUpdated.Patient.ResponsibleRelationship = .Rows(0)("PatientResponsibleRelationship")
                    Me.HCFAUpdated.Patient.ResponsibleHomePhone = .Rows(0)("PatientResponsibleHomePhone")
                    Me.HCFAUpdated.Patient.ResponsibleWorkPhone = .Rows(0)("PatientResponsibleWorkPhone")
                    Me.HCFAUpdated.Patient.ResponsibleAddress = .Rows(0)("PatientResponsibleAddress")
                    Me.HCFAUpdated.Patient.ResponsibleSSN = .Rows(0)("PatientResponsibleSSN")
                    Me.HCFAUpdated.Patient.ResponsibleCity = .Rows(0)("PatientResponsibleCity")
                    Me.HCFAUpdated.Patient.ResponsibleState = .Rows(0)("PatientResponsibleState")
                    Me.HCFAUpdated.Patient.ResponsibleZip = .Rows(0)("PatientResponsibleZip")
                    Me.HCFAUpdated.Patient.NCPDPID2 = .Rows(0)("PatientNCPDPID2")
                    Me.HCFAUpdated.Patient.PharmacyName2 = .Rows(0)("PatientPharmacyName2")
                    Me.HCFAUpdated.Patient.PharmacyProvider2 = .Rows(0)("PatientPharmacyProvider2")
                    Me.HCFAUpdated.Patient.EmergencyContactName2 = .Rows(0)("PatientEmergencyContactName2")
                    Me.HCFAUpdated.Patient.EmergencyContactRelationship2 = .Rows(0)("PatientEmergencyContactRelationship2")
                    Me.HCFAUpdated.Patient.EmergencyContactPhone2 = .Rows(0)("PatientEmergencyContactPhone2")
                    Me.HCFAUpdated.Patient.PreferredHomePh = .Rows(0)("PatientPreferredHomePh")
                    Me.HCFAUpdated.Patient.PreferredWorkPh = .Rows(0)("PatientPreferredWorkPh")
                    Me.HCFAUpdated.Patient.PreferredCellPh = .Rows(0)("PatientPreferredCellPh")
                    Me.HCFAUpdated.Patient.EmployeeDesignation = .Rows(0)("PatientEmployeeDesignation")



                    Me.HCFAUpdated.InsurerPatient.PatientID = .Rows(0)("iPatientPatientID")
                    Me.HCFAUpdated.InsurerPatient.PatientCode = .Rows(0)("iPatientPatientCode")
                    Me.HCFAUpdated.InsurerPatient.Title = .Rows(0)("iPatientTitle")
                    Me.HCFAUpdated.InsurerPatient.FirstName = .Rows(0)("iPatientFirstName")
                    Me.HCFAUpdated.InsurerPatient.MiddleName = .Rows(0)("iPatientMiddleName")
                    Me.HCFAUpdated.InsurerPatient.LastName = .Rows(0)("iPatientLastName")
                    Me.HCFAUpdated.InsurerPatient.AddressLine1 = .Rows(0)("iPatientAddressLine1")
                    Me.HCFAUpdated.InsurerPatient.AddressLine2 = .Rows(0)("iPatientAddressLine2")
                    Me.HCFAUpdated.InsurerPatient.City = .Rows(0)("iPatientCity")
                    Me.HCFAUpdated.InsurerPatient.StateID = .Rows(0)("iPatientStateID")
                    Me.HCFAUpdated.InsurerPatient.ZipCode = .Rows(0)("iPatientZipCode")
                    Me.HCFAUpdated.InsurerPatient.HomePhone = .Rows(0)("iPatientHousePhone")
                    Me.HCFAUpdated.InsurerPatient.WorkPhone = .Rows(0)("iPatientWorkPhone")
                    Me.HCFAUpdated.InsurerPatient.WorkPhoneExtension = .Rows(0)("iPatientWorkPhoneExtension")
                    Me.HCFAUpdated.InsurerPatient.Fax = .Rows(0)("iPatientFax")
                    Me.HCFAUpdated.InsurerPatient.Email = .Rows(0)("iPatientEmail")
                    Me.HCFAUpdated.InsurerPatient.Occupation = .Rows(0)("iPatientOccupation")
                    Me.HCFAUpdated.InsurerPatient.DOB = .Rows(0)("iPatientDOB")
                    Me.HCFAUpdated.InsurerPatient.Gender = .Rows(0)("iPatientGender")
                    Me.HCFAUpdated.InsurerPatient.InsuranceID = .Rows(0)("iPatientInsuranceID")
                    Me.HCFAUpdated.InsurerPatient.InsuranceName = .Rows(0)("iPatientInsuranceName")
                    Me.HCFAUpdated.InsurerPatient.NCPDPID = .Rows(0)("iPatientNcpdpID")
                    Me.HCFAUpdated.InsurerPatient.PharmacyName = .Rows(0)("iPatientPharmacyName")
                    Me.HCFAUpdated.InsurerPatient.IsDeleted = .Rows(0)("iPatientIsDeleted")
                    Me.HCFAUpdated.InsurerPatient.PictureFilePath = .Rows(0)("iPatientPictureFilePath")
                    Me.HCFAUpdated.InsurerPatient.SSN = .Rows(0)("iPatientSSN")
                    Me.HCFAUpdated.InsurerPatient.PharmacyProvider = .Rows(0)("iPatientPharmacyProvider")
                    Me.HCFAUpdated.InsurerPatient.MartialStatus = .Rows(0)("iPatientMartialStatus")
                    Me.HCFAUpdated.InsurerPatient.CellPhoneNumber = .Rows(0)("iPatientCellPhoneNumber")
                    Me.HCFAUpdated.InsurerPatient.EmergencyContactName = .Rows(0)("iPatientEmergencyContactName")
                    Me.HCFAUpdated.InsurerPatient.EmergencyContactRelationship = .Rows(0)("iPatientEmergencyContactRelationship")
                    Me.HCFAUpdated.InsurerPatient.EmergencyContactPhone = .Rows(0)("iPatientEmergencyContactPhone")
                    Me.HCFAUpdated.InsurerPatient.EmergencyContactAddress = .Rows(0)("iPatientEmergencyContactAddress")
                    Me.HCFAUpdated.InsurerPatient.EmergencyContactCity = .Rows(0)("iPatientEmergencyContactCity")
                    Me.HCFAUpdated.InsurerPatient.EmergencyContactZip = .Rows(0)("iPatientEmergencyContactZip")
                    Me.HCFAUpdated.InsurerPatient.EmergencyContactState = .Rows(0)("iPatientEmergencyContactState")
                    Me.HCFAUpdated.InsurerPatient.EmployerName = .Rows(0)("iPatientEmployerName")
                    Me.HCFAUpdated.InsurerPatient.EmploymentStatus = .Rows(0)("iPatientEmploymentStatus")
                    Me.HCFAUpdated.InsurerPatient.EmployerAddressLine1 = .Rows(0)("iPatientEmployerAddressLine1")
                    Me.HCFAUpdated.InsurerPatient.EmployerAddressLine2 = .Rows(0)("iPatientEmployerAddressLine2")
                    Me.HCFAUpdated.InsurerPatient.EmployerPhoneNumber = .Rows(0)("iPatientEmployerPhoneNumber")
                    Me.HCFAUpdated.InsurerPatient.EmployerCity = .Rows(0)("iPatientEmployerCity")
                    Me.HCFAUpdated.InsurerPatient.EmployerZip = .Rows(0)("iPatientEmployerZip")
                    Me.HCFAUpdated.InsurerPatient.EmployerState = .Rows(0)("iPatientEmployerState")
                    Me.HCFAUpdated.InsurerPatient.ResponsibleName = .Rows(0)("iPatientResponsibleName")
                    Me.HCFAUpdated.InsurerPatient.ResponsibleRelationship = .Rows(0)("iPatientResponsibleRelationship")
                    Me.HCFAUpdated.InsurerPatient.ResponsibleHomePhone = .Rows(0)("iPatientResponsibleHomePhone")
                    Me.HCFAUpdated.InsurerPatient.ResponsibleWorkPhone = .Rows(0)("iPatientResponsibleWorkPhone")
                    Me.HCFAUpdated.InsurerPatient.ResponsibleAddress = .Rows(0)("iPatientResponsibleAddress")
                    Me.HCFAUpdated.InsurerPatient.ResponsibleSSN = .Rows(0)("iPatientResponsibleSSN")
                    Me.HCFAUpdated.InsurerPatient.ResponsibleCity = .Rows(0)("iPatientResponsibleCity")
                    Me.HCFAUpdated.InsurerPatient.ResponsibleState = .Rows(0)("iPatientResponsibleState")
                    Me.HCFAUpdated.InsurerPatient.ResponsibleZip = .Rows(0)("iPatientResponsibleZip")
                    Me.HCFAUpdated.InsurerPatient.NCPDPID2 = .Rows(0)("iPatientNCPDPID2")
                    Me.HCFAUpdated.InsurerPatient.PharmacyName2 = .Rows(0)("iPatientPharmacyName2")
                    Me.HCFAUpdated.InsurerPatient.PharmacyProvider2 = .Rows(0)("iPatientPharmacyProvider2")
                    Me.HCFAUpdated.InsurerPatient.EmergencyContactName2 = .Rows(0)("iPatientEmergencyContactName2")
                    Me.HCFAUpdated.InsurerPatient.EmergencyContactRelationship2 = .Rows(0)("iPatientEmergencyContactRelationship2")
                    Me.HCFAUpdated.InsurerPatient.EmergencyContactPhone2 = .Rows(0)("iPatientEmergencyContactPhone2")
                    Me.HCFAUpdated.InsurerPatient.PreferredHomePh = .Rows(0)("iPatientPreferredHomePh")
                    Me.HCFAUpdated.InsurerPatient.PreferredWorkPh = .Rows(0)("iPatientPreferredWorkPh")
                    Me.HCFAUpdated.InsurerPatient.PreferredCellPh = .Rows(0)("iPatientPreferredCellPh")
                    Me.HCFAUpdated.InsurerPatient.EmployeeDesignation = .Rows(0)("iPatientEmployeeDesignation")



                    Me.HCFAUpdated.OtherInsurerPatient.PatientID = .Rows(0)("OtherIPPatientID")
                    Me.HCFAUpdated.OtherInsurerPatient.PatientCode = .Rows(0)("OtherIPPatientCode")
                    Me.HCFAUpdated.OtherInsurerPatient.Title = .Rows(0)("OtherIPTitle")
                    Me.HCFAUpdated.OtherInsurerPatient.FirstName = .Rows(0)("OtherIPFirstName")
                    Me.HCFAUpdated.OtherInsurerPatient.MiddleName = .Rows(0)("OtherIPMiddleName")
                    Me.HCFAUpdated.OtherInsurerPatient.LastName = .Rows(0)("OtherIPLastName")
                    Me.HCFAUpdated.OtherInsurerPatient.AddressLine1 = .Rows(0)("OtherIPAddressLine1")
                    Me.HCFAUpdated.OtherInsurerPatient.AddressLine2 = .Rows(0)("OtherIPAddressLine2")
                    Me.HCFAUpdated.OtherInsurerPatient.City = .Rows(0)("OtherIPCity")
                    Me.HCFAUpdated.OtherInsurerPatient.StateID = .Rows(0)("OtherIPStateID")
                    Me.HCFAUpdated.OtherInsurerPatient.ZipCode = .Rows(0)("OtherIPZipCode")
                    Me.HCFAUpdated.OtherInsurerPatient.HomePhone = .Rows(0)("OtherIPHousePhone")
                    Me.HCFAUpdated.OtherInsurerPatient.WorkPhone = .Rows(0)("OtherIPWorkPhone")
                    Me.HCFAUpdated.OtherInsurerPatient.WorkPhoneExtension = .Rows(0)("OtherIPWorkPhoneExtension")
                    Me.HCFAUpdated.OtherInsurerPatient.Fax = .Rows(0)("OtherIPFax")
                    Me.HCFAUpdated.OtherInsurerPatient.Email = .Rows(0)("OtherIPEmail")
                    Me.HCFAUpdated.OtherInsurerPatient.Occupation = .Rows(0)("OtherIPOccupation")
                    Me.HCFAUpdated.OtherInsurerPatient.DOB = .Rows(0)("OtherIPDOB")
                    Me.HCFAUpdated.OtherInsurerPatient.Gender = .Rows(0)("OtherIPGender")
                    Me.HCFAUpdated.OtherInsurerPatient.InsuranceID = .Rows(0)("OtherIPInsuranceID")
                    Me.HCFAUpdated.OtherInsurerPatient.InsuranceName = .Rows(0)("OtherIPInsuranceName")
                    Me.HCFAUpdated.OtherInsurerPatient.NCPDPID = .Rows(0)("OtherIPNcpdpID")
                    Me.HCFAUpdated.OtherInsurerPatient.PharmacyName = .Rows(0)("OtherIPPharmacyName")
                    Me.HCFAUpdated.OtherInsurerPatient.IsDeleted = .Rows(0)("OtherIPIsDeleted")
                    Me.HCFAUpdated.OtherInsurerPatient.PictureFilePath = .Rows(0)("OtherIPPictureFilePath")
                    Me.HCFAUpdated.OtherInsurerPatient.SSN = .Rows(0)("OtherIPSSN")
                    Me.HCFAUpdated.OtherInsurerPatient.PharmacyProvider = .Rows(0)("OtherIPPharmacyProvider")
                    Me.HCFAUpdated.OtherInsurerPatient.MartialStatus = .Rows(0)("OtherIPMartialStatus")
                    Me.HCFAUpdated.OtherInsurerPatient.CellPhoneNumber = .Rows(0)("OtherIPCellPhoneNumber")
                    Me.HCFAUpdated.OtherInsurerPatient.EmergencyContactName = .Rows(0)("OtherIPEmergencyContactName")
                    Me.HCFAUpdated.OtherInsurerPatient.EmergencyContactRelationship = .Rows(0)("OtherIPEmergencyContactRelationship")
                    Me.HCFAUpdated.OtherInsurerPatient.EmergencyContactPhone = .Rows(0)("OtherIPEmergencyContactPhone")
                    Me.HCFAUpdated.OtherInsurerPatient.EmergencyContactAddress = .Rows(0)("OtherIPEmergencyContactAddress")
                    Me.HCFAUpdated.OtherInsurerPatient.EmergencyContactCity = .Rows(0)("OtherIPEmergencyContactCity")
                    Me.HCFAUpdated.OtherInsurerPatient.EmergencyContactZip = .Rows(0)("OtherIPEmergencyContactZip")
                    Me.HCFAUpdated.OtherInsurerPatient.EmergencyContactState = .Rows(0)("OtherIPEmergencyContactState")
                    Me.HCFAUpdated.OtherInsurerPatient.EmployerName = .Rows(0)("OtherIPEmployerName")
                    Me.HCFAUpdated.OtherInsurerPatient.EmploymentStatus = .Rows(0)("OtherIPEmploymentStatus")
                    Me.HCFAUpdated.OtherInsurerPatient.EmployerAddressLine1 = .Rows(0)("OtherIPEmployerAddressLine1")
                    Me.HCFAUpdated.OtherInsurerPatient.EmployerAddressLine2 = .Rows(0)("OtherIPEmployerAddressLine2")
                    Me.HCFAUpdated.OtherInsurerPatient.EmployerPhoneNumber = .Rows(0)("OtherIPEmployerPhoneNumber")
                    Me.HCFAUpdated.OtherInsurerPatient.EmployerCity = .Rows(0)("OtherIPEmployerCity")
                    Me.HCFAUpdated.OtherInsurerPatient.EmployerZip = .Rows(0)("OtherIPEmployerZip")
                    Me.HCFAUpdated.OtherInsurerPatient.EmployerState = .Rows(0)("OtherIPEmployerState")
                    Me.HCFAUpdated.OtherInsurerPatient.ResponsibleName = .Rows(0)("OtherIPResponsibleName")
                    Me.HCFAUpdated.OtherInsurerPatient.ResponsibleRelationship = .Rows(0)("OtherIPResponsibleRelationship")
                    Me.HCFAUpdated.OtherInsurerPatient.ResponsibleHomePhone = .Rows(0)("OtherIPResponsibleHomePhone")
                    Me.HCFAUpdated.OtherInsurerPatient.ResponsibleWorkPhone = .Rows(0)("OtherIPResponsibleWorkPhone")
                    Me.HCFAUpdated.OtherInsurerPatient.ResponsibleAddress = .Rows(0)("OtherIPResponsibleAddress")
                    Me.HCFAUpdated.OtherInsurerPatient.ResponsibleSSN = .Rows(0)("OtherIPResponsibleSSN")
                    Me.HCFAUpdated.OtherInsurerPatient.ResponsibleCity = .Rows(0)("OtherIPResponsibleCity")
                    Me.HCFAUpdated.OtherInsurerPatient.ResponsibleState = .Rows(0)("OtherIPResponsibleState")
                    Me.HCFAUpdated.OtherInsurerPatient.ResponsibleZip = .Rows(0)("OtherIPResponsibleZip")
                    Me.HCFAUpdated.OtherInsurerPatient.NCPDPID2 = .Rows(0)("OtherIPNCPDPID2")
                    Me.HCFAUpdated.OtherInsurerPatient.PharmacyName2 = .Rows(0)("OtherIPPharmacyName2")
                    Me.HCFAUpdated.OtherInsurerPatient.PharmacyProvider2 = .Rows(0)("OtherIPPharmacyProvider2")
                    Me.HCFAUpdated.OtherInsurerPatient.EmergencyContactName2 = .Rows(0)("OtherIPEmergencyContactName2")
                    Me.HCFAUpdated.OtherInsurerPatient.EmergencyContactRelationship2 = .Rows(0)("OtherIPEmergencyContactRelationship2")
                    Me.HCFAUpdated.OtherInsurerPatient.EmergencyContactPhone2 = .Rows(0)("OtherIPEmergencyContactPhone2")
                    Me.HCFAUpdated.OtherInsurerPatient.PreferredHomePh = .Rows(0)("OtherIPPreferredHomePh")
                    Me.HCFAUpdated.OtherInsurerPatient.PreferredWorkPh = .Rows(0)("OtherIPPreferredWorkPh")
                    Me.HCFAUpdated.OtherInsurerPatient.PreferredCellPh = .Rows(0)("OtherIPPreferredCellPh")
                    Me.HCFAUpdated.OtherInsurerPatient.EmployeeDesignation = .Rows(0)("OtherIPEmployeeDesignation")



                    Me.HCFAUpdated.PatientConditionEmployment = .Rows(0)("PatientConditionEmployment")
                    Me.HCFAUpdated.PatientConditionAutoAccident = .Rows(0)("PatientConditionAutoAccident")
                    Me.HCFAUpdated.PatientConditionAutoAccPlace = .Rows(0)("PatientConditionAutoAccPlace")
                    Me.HCFAUpdated.PatientConditionOtherAccident = .Rows(0)("PatientConditionOtherAccident")

                    Me.HCFAUpdated.SignOnFile = .Rows(0)("SignOnFile")
                    Me.HCFAUpdated.SignDate = .Rows(0)("SignDate")
                    Me.HCFAUpdated.AuthorizedPersonSign = .Rows(0)("AuthorizedPersonSign")
                    Me.HCFAUpdated.DateOfOccurance = .Rows(0)("DateOfOccurance")

                    ''NEW CHANGES
                    Me.HCFAUpdated.DateOfCurrentIllnessQual = .Rows(0)("DateOfCurrentIllnessQual").ToString()
                    Me.HCFAUpdated.PreviousOccuranceDate = .Rows(0)("PreviousOccuranceDate").ToString()
                    ''NEW CHANGES
                    Me.HCFAUpdated.OtherDateQual1 = .Rows(0)("OtherDateQual1").ToString()
                    Me.HCFAUpdated.OtherDateQual2 = .Rows(0)("OtherDateQual2").ToString()

                    Me.HCFAUpdated.PatUnableToWorkFrom = .Rows(0)("PatUnableToWorkFrom")
                    Me.HCFAUpdated.PatUnableToWorkTo = .Rows(0)("PatUnableToWorkTo")

                    ''NEW CHANGES
                    Me.HCFAUpdated.NameOfRefProviderQual = .Rows(0)("NameOfRefProviderQual").ToString()


                    Me.HCFAUpdated.ReferencePvd.ProviderID = .Rows(0)("RefPvdProviderID")
                    Me.HCFAUpdated.ReferencePvd.FirstName = .Rows(0)("RefPvdFirstName")
                    Me.HCFAUpdated.ReferencePvd.MiddleName = .Rows(0)("RefPvdMiddleName")
                    Me.HCFAUpdated.ReferencePvd.LastName = .Rows(0)("RefPvdLastName")
                    Me.HCFAUpdated.ReferencePvd.Title = .Rows(0)("RefPvdTitle")
                    Me.HCFAUpdated.ReferencePvd.AddressLine1 = .Rows(0)("RefPvdAddressLine1")
                    Me.HCFAUpdated.ReferencePvd.AddressLine2 = .Rows(0)("RefPvdAddressLine2")
                    Me.HCFAUpdated.ReferencePvd.City = .Rows(0)("RefPvdCity")
                    Me.HCFAUpdated.ReferencePvd.State = .Rows(0)("RefPVDState")
                    Me.HCFAUpdated.ReferencePvd.ZipCode = .Rows(0)("RefPvdZipCode")
                    Me.HCFAUpdated.ReferencePvd.WorkPhone = .Rows(0)("RefPvdWorkPhone")
                    Me.HCFAUpdated.ReferencePvd.Ext = .Rows(0)("RefPvdExt")
                    Me.HCFAUpdated.ReferencePvd.Fax = .Rows(0)("RefPvdFax")
                    Me.HCFAUpdated.ReferencePvd.Email = .Rows(0)("RefPvdEmail")
                    Me.HCFAUpdated.ReferencePvd.NPI = .Rows(0)("RefPvdNPI")
                    Me.HCFAUpdated.ReferencePvd.Speciality = .Rows(0)("RefPvdSpeciality")
                    Me.HCFAUpdated.ReferencePvd.Facility = .Rows(0)("RefPvdFacilityID")
                    'Me.HCFAUpdated.ReferencePvd.IsDelete = .Rows(0)("RefPvdIsDelete")
                    Me.HCFAUpdated.ReferencePvd.Degree = .Rows(0)("RefPvdDegree")

                    Me.HCFAUpdated.HospitalizationDateFrom = .Rows(0)("HospitalizationDateFrom")
                    Me.HCFAUpdated.HospitalizationDateTo = .Rows(0)("HospitalizationDateTo")
                    Me.HCFAUpdated.Field19 = .Rows(0)("Field19")
                    Me.HCFAUpdated.IsOutsideLab = .Rows(0)("IsOutsideLab")
                    Me.HCFAUpdated.OutsideLabCharges = .Rows(0)("OutSideLabCharges")
                    Me.HCFAUpdated.ICD1 = .Rows(0)("ICD1")
                    Me.HCFAUpdated.ICD2 = .Rows(0)("ICD2")
                    Me.HCFAUpdated.ICD3 = .Rows(0)("ICD3")
                    Me.HCFAUpdated.ICD4 = .Rows(0)("ICD4")
                    ''NEW CHANGES
                    Me.HCFAUpdated.ICD5 = .Rows(0)("ICD5").ToString()
                    Me.HCFAUpdated.ICD6 = .Rows(0)("ICD6").ToString()
                    Me.HCFAUpdated.ICD7 = .Rows(0)("ICD7").ToString()
                    Me.HCFAUpdated.ICD8 = .Rows(0)("ICD8").ToString()
                    Me.HCFAUpdated.ICD9 = .Rows(0)("ICD9").ToString()
                    Me.HCFAUpdated.ICD10 = .Rows(0)("ICD10").ToString()
                    Me.HCFAUpdated.ICD11 = .Rows(0)("ICD11").ToString()
                    Me.HCFAUpdated.ICD12 = .Rows(0)("ICD12").ToString()

                    Me.HCFAUpdated.MedicadReSubCode = .Rows(0)("MedicadReSubCode")
                    Me.HCFAUpdated.MedicadReSubNo = .Rows(0)("MedicadReSubNo")
                    Me.HCFAUpdated.FederalTaxNo = .Rows(0)("FederalTaxNo")
                    Me.HCFAUpdated.FederalTaxType = .Rows(0)("FederalTaxType")
                    Me.HCFAUpdated.PatientACNo = .Rows(0)("PatientACNo")
                    Me.HCFAUpdated.AcceptAssignment = .Rows(0)("AcceptAssignment")
                    Me.HCFAUpdated.AmountPaid = .Rows(0)("AmountPaid")
                    Me.HCFAUpdated.BalanceDue = .Rows(0)("BalanceDue")
                    Me.HCFAUpdated.TotalCharges = .Rows(0)("TotalCharges")



                    Me.HCFAUpdated.RenderingProvider.EmployeeID = .Rows(0)("RenPvdEmployeeID")
                    Me.HCFAUpdated.RenderingProvider.ClinicCode = .Rows(0)("RenPvdClinicCode")
                    Me.HCFAUpdated.RenderingProvider.Designation = .Rows(0)("RenPvdDesignation")
                    Me.HCFAUpdated.RenderingProvider.LoginID = .Rows(0)("RenPvdDesignation")
                    Me.HCFAUpdated.RenderingProvider.Password = .Rows(0)("RenPvdPassword")
                    Me.HCFAUpdated.RenderingProvider.Title = .Rows(0)("RenPvdTitle")
                    Me.HCFAUpdated.RenderingProvider.FirstName = .Rows(0)("RenPvdFirstName")
                    Me.HCFAUpdated.RenderingProvider.MiddleName = .Rows(0)("RenPvdMiddleName")
                    Me.HCFAUpdated.RenderingProvider.LastName = .Rows(0)("RenPvdLastName")
                    Me.HCFAUpdated.RenderingProvider.Gender = .Rows(0)("RenPvdGender")
                    Me.HCFAUpdated.RenderingProvider.DOB = .Rows(0)("RenPvdDOB")
                    Me.HCFAUpdated.RenderingProvider.SSN = .Rows(0)("RenPvdSSN")
                    Me.HCFAUpdated.RenderingProvider.AddressLine1 = .Rows(0)("RenPvdAddressLine1")
                    Me.HCFAUpdated.RenderingProvider.AddressLine2 = .Rows(0)("RenPvdAddressLine2")
                    Me.HCFAUpdated.RenderingProvider.City = .Rows(0)("RenPvdCity")
                    Me.HCFAUpdated.RenderingProvider.StateId = .Rows(0)("RenPvdStateId")
                    Me.HCFAUpdated.RenderingProvider.ZipCode = .Rows(0)("RenPvdZipCode")
                    Me.HCFAUpdated.RenderingProvider.HomePhone = .Rows(0)("RenPvdHomePhone")
                    Me.HCFAUpdated.RenderingProvider.WorkPhone = .Rows(0)("RenPvdWorkPhone")
                    Me.HCFAUpdated.RenderingProvider.WorkPhoneExtension = .Rows(0)("RenPvdWorkPhoneExtension")
                    Me.HCFAUpdated.RenderingProvider.Fax = .Rows(0)("RenPvdFax")
                    Me.HCFAUpdated.RenderingProvider.Email = .Rows(0)("RenPvdEmail")
                    Me.HCFAUpdated.RenderingProvider.LoginStatus = .Rows(0)("RenPvdLoginStatus")
                    Me.HCFAUpdated.RenderingProvider.SPI = .Rows(0)("RenPvdSPI")
                    Me.HCFAUpdated.RenderingProvider.DEA = .Rows(0)("RenPvdDEA")
                    Me.HCFAUpdated.RenderingProvider.Licence = .Rows(0)("RenPvdLicence")
                    Me.HCFAUpdated.RenderingProvider.ServiceLevel = .Rows(0)("RenPvdServiceLevel")
                    Me.HCFAUpdated.RenderingProvider.StartDate = .Rows(0)("RenPvdStartDate")
                    Me.HCFAUpdated.RenderingProvider.EndDate = .Rows(0)("RenPvdEndDate")
                    Me.HCFAUpdated.RenderingProvider.SigPath = .Rows(0)("RenPvdSigPath")
                    Me.HCFAUpdated.RenderingProvider.IsDeleted = .Rows(0)("RenPvdIsDeleted")
                    Me.HCFAUpdated.RenderingProvider.Theme = .Rows(0)("RenPvdTheme")
                    Me.HCFAUpdated.RenderingProvider.ScreeningEnabled = .Rows(0)("RenPvdScreeningEnabled")
                    Me.HCFAUpdated.RenderingProvider.DEA = .Rows(0)("RenPvdDAW")
                    Me.HCFAUpdated.RenderingProvider.SetupID = .Rows(0)("RenPvdSetup_ID")
                    Me.HCFAUpdated.RenderingProvider.NPI = .Rows(0)("RenPvdNPI")
                    Me.HCFAUpdated.RenderingProvider.TaxID = .Rows(0)("RenPvdTaxID")
                    Me.HCFAUpdated.RenderingProvider.StateLicenseID = .Rows(0)("RenPvdStateLicenseID")
                    Me.HCFAUpdated.RenderingProvider.DEA2 = .Rows(0)("RenPvdDEA2")
                    Me.HCFAUpdated.RenderingProvider.SpecialityCode = .Rows(0)("RenPvdSpecialityCode")
                    Me.HCFAUpdated.RenderingProvider.IsPrintRx = .Rows(0)("RenPvdIsPrintRx")
                    Me.HCFAUpdated.RenderingProvider.Degree = .Rows(0)("RenPvdDegree")
                    Me.HCFAUpdated.RenderingProvider.IsActive = .Rows(0)("RenPvdIsActive")
                    Me.HCFAUpdated.RenderingProvider.IsLocked = .Rows(0)("RenPvdIsLocked")
                    Me.HCFAUpdated.RenderingProvider.IsReseted = .Rows(0)("RenPvdIsReseted")
                    Me.HCFAUpdated.RenderingProvider.IsSuperAdmin = .Rows(0)("RenPvdIsSuperAdmin")
                    Me.HCFAUpdated.RenderingProvider.LoginCount = .Rows(0)("RenPvdLoginCount")
                    Me.HCFAUpdated.RenderingProvider.CptNo = .Rows(0)("RenPvdCptNo")
                    Me.HCFAUpdated.RenderingProvider.DEASuffix = .Rows(0)("RenPvdDEASuffix")


                    Me.HCFAUpdated.ServiceFacility.FacilityID = .Rows(0)("ServFacFacilityID")
                    Me.HCFAUpdated.ServiceFacility.FacilityName = .Rows(0)("ServFacFacilityName")
                    Me.HCFAUpdated.ServiceFacility.NPI = .Rows(0)("ServFacNPI")
                    Me.HCFAUpdated.ServiceFacility.AddressLine1 = .Rows(0)("ServFacAddressLine1")
                    Me.HCFAUpdated.ServiceFacility.AddressLine2 = .Rows(0)("ServFacAddressLine2")
                    Me.HCFAUpdated.ServiceFacility.City = .Rows(0)("ServFacCity")
                    Me.HCFAUpdated.ServiceFacility.State = .Rows(0)("ServFacState")
                    Me.HCFAUpdated.ServiceFacility.ZipCode = .Rows(0)("ServFacZipCode")
                    Me.HCFAUpdated.ServiceFacility.Phone = .Rows(0)("ServFacPhone")
                    Me.HCFAUpdated.ServiceFacility.Fax = .Rows(0)("ServFacFax")
                    'Me.HCFAUpdated.ServiceFacility.IsDelete = .Rows(0)("ServFacIsDelete")
                    Me.HCFAUpdated.ServiceFacility.FacilityCode = .Rows(0)("ServFacFacilityCode")

                    Me.HCFAUpdated.BillingPvd.BillingProviderId = .Rows(0)("BPvdBillingProviderId")
                    Me.HCFAUpdated.BillingPvd.FirstName = .Rows(0)("BPvdFirstName")
                    Me.HCFAUpdated.BillingPvd.MiddleName = .Rows(0)("BPvdMiddleName")
                    Me.HCFAUpdated.BillingPvd.LastName = .Rows(0)("BPvdLastName")
                    Me.HCFAUpdated.BillingPvd.AddressLine1 = .Rows(0)("BPvdAddressLine1")
                    Me.HCFAUpdated.BillingPvd.AddressLine2 = .Rows(0)("BPvdAddressLine2")
                    Me.HCFAUpdated.BillingPvd.City = .Rows(0)("BPvdCity")
                    Me.HCFAUpdated.BillingPvd.State = .Rows(0)("BPvdState")
                    Me.HCFAUpdated.BillingPvd.ZipCode = .Rows(0)("BPvdZipCode")
                    Me.HCFAUpdated.BillingPvd.Phone1 = .Rows(0)("BPvdPhone1")
                    Me.HCFAUpdated.BillingPvd.Phone2 = .Rows(0)("BPvdPhone2")
                    Me.HCFAUpdated.BillingPvd.Fax = .Rows(0)("BPvdFax")
                    Me.HCFAUpdated.BillingPvd.Email = .Rows(0)("BPvdEmail")
                    Me.HCFAUpdated.BillingPvd.NPI = .Rows(0)("BPvdNPI")
                    Me.HCFAUpdated.BillingPvd.TaxID = .Rows(0)("BPvdTaxID")
                    Me.HCFAUpdated.BillingPvd.SSN = .Rows(0)("BPvdSSN")
                    Me.HCFAUpdated.BillingPvd.ProviderID = .Rows(0)("BPvdProviderID")
                    Me.HCFAUpdated.BillingPvd.ProviderNPI = .Rows(0)("BPvdProviderNPI")
                    Me.HCFAUpdated.BillingPvd.EntryType = .Rows(0)("BPvdEntryType")
                    Me.HCFAUpdated.BillingPvd.EntryInsuranceTypeCode = .Rows(0)("BPvdEntryInsuranceTypeCode")
                    Me.HCFAUpdated.BillingPvd.EntryInsuranceTypeValue = .Rows(0)("BPvdEntryInsuranceTypeValue")


                    Me.HCFAUpdated.IsActive = .Rows(0)("IsActive")
                    Me.HCFAUpdated.ServFacSecIdQualifier = .Rows(0)("ServFacSecIdQualifier")
                    Me.HCFAUpdated.ServFacSecIdValue = .Rows(0)("ServFacSecIdValue")
                    Me.HCFAUpdated.BPvdSecIdQualifier = .Rows(0)("BPvdSecIdQualifier")
                    Me.HCFAUpdated.BPvdSecIdValue = .Rows(0)("BPvdSecIdValue")
                    Me.HCFAUpdated.ReservedField10d = .Rows(0)("ReservedField10d").ToString()

                    Me.HCFAUpdated.RFNU8 = .Rows(0)("RFNU8").ToString()
                    Me.HCFAUpdated.RFNU9B = .Rows(0)("RFNU9B").ToString()

                    Return True
                End If
            End With
        Catch ex As Exception
            Return False
        End Try
        Return False
    End Function
    Public Function GetRecordByCondition(ByVal pCond As String) As Boolean
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "HCFAUpdated"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = pCond

        Try

            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery("SelectAllRecords", lSpParameter)
            Else
                lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
            End If


            With lDs.Tables(0)
                If .Rows.Count > 0 Then

                    Me.HCFAUpdated.HCFADisplayID = .Rows(0)("HCFADisplayID")
                    Me.HCFAUpdated.PatientSuperBillID = .Rows(0)("PatientSuperBillID")
                    '' case for Company type
                    'Me.HCFAUpdated.Type1 = .Rows(0)("Type1")
                    'Me.HCFAUpdated.Type2 = .Rows(0)("Type2")
                    ' '' case for Company type
                    'Me.HCFAUpdated.InsuredIDNumber = .Rows(0)("InsuredIDNumber")
                    'Me.HCFAUpdated.GroupNumber = .Rows(0)("GroupNumber")
                    'Me.HCFAUpdated.PatientName = .Rows(0)("PatientName")
                    'Me.HCFAUpdated.PatientDOB = .Rows(0)("PatientDOB")
                    'Me.HCFAUpdated.PatientGender = .Rows(0)("PatientGender")
                    'Me.HCFAUpdated.InsuredName = .Rows(0)("InsuredName")
                    'Me.HCFAUpdated.PatientAddress = .Rows(0)("PatientAddress")
                    'Me.HCFAUpdated.PatientCity = .Rows(0)("PatientCity")
                    'Me.HCFAUpdated.PatientZipCode = .Rows(0)("PatientZipCode")
                    'Me.HCFAUpdated.PatientState = .Rows(0)("PatientState")
                    'Me.HCFAUpdated.PatientTelephone = .Rows(0)("PatientTelephone")
                    'Me.HCFAUpdated.PatientRelationshipToInsured = .Rows(0)("PatientRelationshipToInsured")
                    'Me.HCFAUpdated.InsuredAddress = .Rows(0)("InsuredAddress")
                    'Me.HCFAUpdated.InsuredCity = .Rows(0)("InsuredCity")
                    'Me.HCFAUpdated.InsuredState = .Rows(0)("InsuredState")
                    'Me.HCFAUpdated.InsuredZipCode = .Rows(0)("InsuredZipCode")
                    'Me.HCFAUpdated.InsuredTelephone = .Rows(0)("InsuredTelephone")
                    'Me.HCFAUpdated.PatientMaritalStatus = .Rows(0)("PatientMaritalStatus")
                    'Me.HCFAUpdated.PatientEmploymentInfo = .Rows(0)("PatientEmploymentInfo")
                    'Me.HCFAUpdated.OtherInsuredName = .Rows(0)("OtherInsuredName")
                    'Me.HCFAUpdated.OtherInsuredPolicy = .Rows(0)("OtherInsuredPolicy")
                    'Me.HCFAUpdated.OtherInsuredDOB = .Rows(0)("OtherInsuredDOB")
                    'Me.HCFAUpdated.OtherInsuredGender = .Rows(0)("OtherInsuredGender")
                    'Me.HCFAUpdated.OtherInsuredEmployer = .Rows(0)("OtherInsuredEmployer")
                    'Me.HCFAUpdated.SecondaryInsurancePlan = .Rows(0)("SecondaryInsurancePlan")
                    'Me.HCFAUpdated.IsEmploymentRelated = .Rows(0)("IsEmploymentRelated")
                    'Me.HCFAUpdated.IsAutoAccidentRelated = .Rows(0)("IsAutoAccidentRelated")
                    'Me.HCFAUpdated.IsOtherAccidentRelated = .Rows(0)("IsOtherAccidentRelated")
                    'Me.HCFAUpdated.ReservedBlock10D = .Rows(0)("ReservedBlock10D")
                    'Me.HCFAUpdated.AnotherInsuredPolicy = .Rows(0)("AnotherInsuredPolicy")
                    'Me.HCFAUpdated.AnotherInsuredDOB = .Rows(0)("AnotherInsuredDOB")
                    'Me.HCFAUpdated.AnotherInsuredGender = .Rows(0)("AnotherInsuredGender")
                    'Me.HCFAUpdated.AnotherInsuredEmployerName = .Rows(0)("AnotherInsuredEmployerName")
                    'Me.HCFAUpdated.AnotherInsuredInsurancePlan = .Rows(0)("AnotherInsuredInsurancePlan")
                    'Me.HCFAUpdated.IsAnotherPlan = .Rows(0)("IsAnotherPlan")
                    'Me.HCFAUpdated.ReleaseInfoSignature = .Rows(0)("ReleaseInfoSignature")
                    'Me.HCFAUpdated.ReleaseInfoDate = .Rows(0)("ReleaseInfoDate")
                    'Me.HCFAUpdated.PaymentSignature = .Rows(0)("PaymentSignature")
                    'Me.HCFAUpdated.DateOfOccurance = .Rows(0)("DateOfOccurance")
                    'Me.HCFAUpdated.PreviousOccuranceDate = .Rows(0)("PreviousOccuranceDate")
                    'Me.HCFAUpdated.UnableToWorkFrom = .Rows(0)("UnableToWorkFrom")
                    'Me.HCFAUpdated.UnableToWorkTo = .Rows(0)("UnableToWorkTo")
                    'Me.HCFAUpdated.RefferingProviderName = .Rows(0)("RefferingProviderName")
                    'Me.HCFAUpdated.RefferingProviderID = .Rows(0)("RefferingProviderID")
                    'Me.HCFAUpdated.RefferingProviderNPI = .Rows(0)("RefferingProviderNPI")
                    'Me.HCFAUpdated.HospitalizationDateFrom = .Rows(0)("HospitalizationDateFrom")
                    'Me.HCFAUpdated.HospitalizationDateTo = .Rows(0)("HospitalizationDateTo")
                    'Me.HCFAUpdated.ReservedBlock19 = .Rows(0)("ReservedBlock19")
                    Me.HCFAUpdated.IsOutsideLab = .Rows(0)("IsOutsideLab")
                    Me.HCFAUpdated.OutsideLabCharges = .Rows(0)("OutsideLabCharges")
                    Me.HCFAUpdated.ICD1 = .Rows(0)("ICD1")
                    Me.HCFAUpdated.ICD2 = .Rows(0)("ICD2")
                    Me.HCFAUpdated.ICD3 = .Rows(0)("ICD3")
                    Me.HCFAUpdated.ICD4 = .Rows(0)("ICD4")
                    'Me.HCFAUpdated.MedicaidCode = .Rows(0)("MedicaidCode")
                    'Me.HCFAUpdated.OriginalRefrenceNumber = .Rows(0)("OriginalRefrenceNumber")
                    'Me.HCFAUpdated.PriorAuthorizationNumber = .Rows(0)("PriorAuthorizationNumber")
                    'Me.HCFAUpdated.FederalTaxID = .Rows(0)("FederalTaxID")
                    'Me.HCFAUpdated.IsSSN = .Rows(0)("IsSSN")
                    'Me.HCFAUpdated.PatientAccountNumber = .Rows(0)("PatientAccountNumber")
                    'Me.HCFAUpdated.IsAcceptAssignment = .Rows(0)("IsAcceptAssignment")
                    'Me.HCFAUpdated.TotalCharge = .Rows(0)("TotalCharge")
                    'Me.HCFAUpdated.AmountPaid = .Rows(0)("AmountPaid")
                    'Me.HCFAUpdated.BalanceDue = .Rows(0)("BalanceDue")
                    'Me.HCFAUpdated.ProviderName = .Rows(0)("ProviderName")
                    'Me.HCFAUpdated.HCFAPreparedDate = .Rows(0)("HCFAPreparedDate")
                    'Me.HCFAUpdated.FacilityId = .Rows(0)("FacilityId")
                    'Me.HCFAUpdated.FacilityName = .Rows(0)("FacilityName")
                    'Me.HCFAUpdated.FacilityAddress = .Rows(0)("FacilityAddress")
                    'Me.HCFAUpdated.FacilityProvider = .Rows(0)("FacilityProvider")
                    'Me.HCFAUpdated.FacilityCode = .Rows(0)("FacilityCode")
                    'Me.HCFAUpdated.ClinicName = .Rows(0)("ClinicName")
                    'Me.HCFAUpdated.ClinicAddress = .Rows(0)("ClinicAddress")
                    'Me.HCFAUpdated.ClinicCity = .Rows(0)("ClinicCity")
                    'Me.HCFAUpdated.ClinicState = .Rows(0)("ClinicState")
                    'Me.HCFAUpdated.ClinicZip = .Rows(0)("ClinicZip")
                    'Me.HCFAUpdated.ClinicPhoneNumber = .Rows(0)("ClinicPhoneNumber")
                    'Me.HCFAUpdated.ClinicPinNumber = .Rows(0)("ClinicPinNumber")
                    'Me.HCFAUpdated.ClinicGroupNumber = .Rows(0)("ClinicGroupNumber")
                    'Me.HCFAUpdated.DoctorUserID = .Rows(0)("DoctorUserID")
                    'Me.HCFAUpdated.CreateByUserID = .Rows(0)("CreateByUserID")
                    'Me.HCFAUpdated.InsuranceNameHdr = .Rows(0)("InsuranceNameHdr")
                    'Me.HCFAUpdated.InsuranceAddressHdr = .Rows(0)("InsuranceAddressHdr")
                    'Me.HCFAUpdated.FacilitySecondaryIdentificationQualifier = .Rows(0)("FacilitySecondaryIdentificationQualifier")
                    'Me.HCFAUpdated.ClinicSecondaryIdentificationQualifier = .Rows(0)("ClinicSecondaryIdentificationQualifier")
                    'Me.HCFAUpdated.InsuranceAddressLine1 = .Rows(0)("InsuranceAddressLine1")
                    'Me.HCFAUpdated.InsuranceAddressLine2 = .Rows(0)("InsuranceAddressLine2")
                    'Me.HCFAUpdated.RefferingProviderIDQualifier = .Rows(0)("RefferingProviderIDQualifier")
                    'Me.HCFAUpdated.IsSend = .Rows(0)("IsSend")
                    'Me.HCFAUpdated.FacilityCity = .Rows(0)("FacilityCity")
                    'Me.HCFAUpdated.FacilityState = .Rows(0)("FacilityState")
                    'Me.HCFAUpdated.FacilityZipCode = .Rows(0)("FacilityZipCode")

                    'Me.HCFAUpdated.HCFAType = .Rows(0)("HCFAType")

                    'Me.HCFAUpdated.MainInsID = .Rows(0)("MainInsID")
                    'Me.HCFAUpdated.OtherInsID = .Rows(0)("OtherInsID")

                    Return True
                End If
            End With
        Catch ex As Exception
            Return False
        End Try
        Return False
    End Function

 
    Public Function InsertRecord() As String
        Dim lXmlDocument As New XmlDocument
        Dim lXmlElement As XmlElement


        lXmlDocument.LoadXml("<HCFAUpdatedS></HCFAUpdatedS>")
        lXmlElement = lXmlDocument.CreateElement("HCFAUpdated")


        With lXmlElement
            'HcFa Fields
            .SetAttribute("HCFAID", HCFAUpdated.HCFAID)
            .SetAttribute("HCFADisplayID", HCFAUpdated.HCFADisplayID)
            .SetAttribute("PatientSuperBillID", HCFAUpdated.PatientSuperBillID)
            .SetAttribute("HCFAPreparedDate", HCFAUpdated.HCFAPreparedDate)
            .SetAttribute("CreateByUserID", HCFAUpdated.CreateByUserID)
            .SetAttribute("UpdateByUserID", HCFAUpdated.UpdateByUserID)
            .SetAttribute("IsSend", HCFAUpdated.IsSend)
            .SetAttribute("IsBatch", HCFAUpdated.IsBatch)
            .SetAttribute("HCFAType", HCFAUpdated.HCFAType)
            .SetAttribute("HCFANotes", HCFAUpdated.HCFANotes)
            .SetAttribute("HCFAGenerationSeqNo", HCFAUpdated.HCFAGenerationSeqNo)


            'Main Insurance Company
            .SetAttribute("MainICFavouriteInsuranceID", HCFAUpdated.MainInsuranceCompany.FavouriteInsuranceID)
            .SetAttribute("MainICInsuranceID", HCFAUpdated.MainInsuranceCompany.InsuranceID)
            .SetAttribute("MainICCompanyName", HCFAUpdated.MainInsuranceCompany.CompanyName)
            .SetAttribute("MainICPayerID", HCFAUpdated.MainInsuranceCompany.PayerID)
            .SetAttribute("MainICAddressLine1", HCFAUpdated.MainInsuranceCompany.AddressLine1)
            .SetAttribute("MainICAddressLine2", HCFAUpdated.MainInsuranceCompany.AddressLine2)
            .SetAttribute("MainICCity", HCFAUpdated.MainInsuranceCompany.City)
            .SetAttribute("MainICState", HCFAUpdated.MainInsuranceCompany.State)
            .SetAttribute("MainICZipCode", HCFAUpdated.MainInsuranceCompany.ZipCode)
            .SetAttribute("MainICContactName", HCFAUpdated.MainInsuranceCompany.ContactName)
            .SetAttribute("MainICInsuranceType", HCFAUpdated.MainInsuranceCompany.InsuranceType)
            .SetAttribute("MainICWorkPhone", HCFAUpdated.MainInsuranceCompany.WorkPhone)
            .SetAttribute("MainICFax", HCFAUpdated.MainInsuranceCompany.Fax)
            .SetAttribute("MainICEmail", HCFAUpdated.MainInsuranceCompany.Email)
            .SetAttribute("MainICBillType", HCFAUpdated.MainInsuranceCompany.BillType)
            .SetAttribute("MainICIsDelete", "N")

            ' Other Insurance Company
            .SetAttribute("OtherICFavouriteInsuranceID", HCFAUpdated.OtherInsuranceCompany.FavouriteInsuranceID)
            .SetAttribute("OtherICInsuranceID", HCFAUpdated.OtherInsuranceCompany.InsuranceID)
            .SetAttribute("OtherICCompanyName", HCFAUpdated.OtherInsuranceCompany.CompanyName)
            .SetAttribute("OtherICFavInsPayerID", HCFAUpdated.OtherInsuranceCompany.PayerID)
            .SetAttribute("OtherICAddressLine1", HCFAUpdated.OtherInsuranceCompany.AddressLine1)
            .SetAttribute("OtherICAddressLine2", HCFAUpdated.OtherInsuranceCompany.AddressLine2)
            .SetAttribute("OtherICCity", HCFAUpdated.OtherInsuranceCompany.City)
            .SetAttribute("OtherICState", HCFAUpdated.OtherInsuranceCompany.State)
            .SetAttribute("OtherICZipCode", HCFAUpdated.OtherInsuranceCompany.ZipCode)
            .SetAttribute("OtherICContactName", HCFAUpdated.OtherInsuranceCompany.ContactName)
            .SetAttribute("OtherICInsuranceType", HCFAUpdated.OtherInsuranceCompany.InsuranceType)
            .SetAttribute("OtherICWorkPhone", HCFAUpdated.OtherInsuranceCompany.WorkPhone)
            .SetAttribute("OtherICFax", HCFAUpdated.OtherInsuranceCompany.Fax)
            .SetAttribute("OtherICEmail", HCFAUpdated.OtherInsuranceCompany.Email)
            .SetAttribute("OtherICBillType", HCFAUpdated.OtherInsuranceCompany.BillType)
            .SetAttribute("OtherICIsDelete", "N")


            'Patient Insurance


            .SetAttribute("MainPIPatientInsID", HCFAUpdated.MainPatientInsurance.PatientInsID)
            .SetAttribute("MainPIPatientID", HCFAUpdated.MainPatientInsurance.PatientID)
            .SetAttribute("MainPIType", HCFAUpdated.MainPatientInsurance.Type)
            .SetAttribute("MainPIRelationshipToPrimaryInsurer", HCFAUpdated.MainPatientInsurance.RelationshipToPrimaryInsurer)
            .SetAttribute("MainPIInsuranceCompanyID", HCFAUpdated.MainPatientInsurance.InsuranceCompanyID)
            .SetAttribute("MainPIInsuranceCompany", HCFAUpdated.MainPatientInsurance.InsuranceCompanyName)
            .SetAttribute("MainPIPatientPayerId", HCFAUpdated.MainPatientInsurance.PayerId)
            .SetAttribute("MainPISubscriberID", HCFAUpdated.MainPatientInsurance.SubscriberID)
            .SetAttribute("MainPIGroupNo", HCFAUpdated.MainPatientInsurance.GroupNo)
            .SetAttribute("MainPIPlanName", HCFAUpdated.MainPatientInsurance.PlanName)
            .SetAttribute("MainPIInsuredAuthorization", HCFAUpdated.MainPatientInsurance.InsuredAuthorization)
            .SetAttribute("MainPIDeductable", HCFAUpdated.MainPatientInsurance.Deductable)
            .SetAttribute("MainPIVisitCopayment", HCFAUpdated.MainPatientInsurance.VisitCopayment)
            .SetAttribute("MainPISignatureOfFile", HCFAUpdated.MainPatientInsurance.SignatureOfFile)
            .SetAttribute("MainPISignatureDate", HCFAUpdated.MainPatientInsurance.SignatureDate)
            .SetAttribute("MainPIActive", HCFAUpdated.MainPatientInsurance.Active)
            .SetAttribute("MainPIInsurerId", HCFAUpdated.MainPatientInsurance.InsurerId)
            .SetAttribute("MainPIEffectiveDateFrom", HCFAUpdated.MainPatientInsurance.EffectiveDateFrom)
            .SetAttribute("MainPIEffectiveDateTo", HCFAUpdated.MainPatientInsurance.EffectiveDateTo)
            .SetAttribute("MainPIAuthorizationNumber", HCFAUpdated.MainPatientInsurance.AuthorizationNumber)
            .SetAttribute("MainPICoInsurance", HCFAUpdated.MainPatientInsurance.CoInsurance)
            .SetAttribute("MainPIInsuranceCompanyPhoneNumber", HCFAUpdated.MainPatientInsurance.InsuranceCompanyPhoneNumber)
            .SetAttribute("MainPIInsurerInsuranceType", HCFAUpdated.MainPatientInsurance.InsurerInsuranceType)
            .SetAttribute("MainPIInsurerInsuranceId", HCFAUpdated.MainPatientInsurance.InsurerInsuranceId)

            'Other Patient Insurance''
            .SetAttribute("OtherPIPatientInsID", HCFAUpdated.OtherPatientInsurance.PatientInsID)
            .SetAttribute("OtherPIPatientID", HCFAUpdated.OtherPatientInsurance.PatientID)
            .SetAttribute("OtherPIType", HCFAUpdated.OtherPatientInsurance.Type)
            .SetAttribute("OtherPIRelationshipToPrimaryInsurer", HCFAUpdated.OtherPatientInsurance.RelationshipToPrimaryInsurer)
            .SetAttribute("OtherPIInsuranceCompanyID", HCFAUpdated.OtherPatientInsurance.InsuranceCompanyID)
            .SetAttribute("OtherPIInsuranceCompany", HCFAUpdated.OtherPatientInsurance.InsuranceCompanyName)
            .SetAttribute("OtherPIPatientPayerId", HCFAUpdated.OtherPatientInsurance.PayerId)
            .SetAttribute("OtherPISubscriberID", HCFAUpdated.OtherPatientInsurance.SubscriberID)
            .SetAttribute("OtherPIGroupNo", HCFAUpdated.OtherPatientInsurance.GroupNo)
            .SetAttribute("OtherPIPlanName", HCFAUpdated.OtherPatientInsurance.PlanName)
            .SetAttribute("OtherPIInsuredAuthorization", HCFAUpdated.OtherPatientInsurance.InsuredAuthorization)
            .SetAttribute("OtherPIDeductable", HCFAUpdated.OtherPatientInsurance.Deductable)
            .SetAttribute("OtherPIVisitCopayment", HCFAUpdated.OtherPatientInsurance.VisitCopayment)
            .SetAttribute("OtherPISignatureOfFile", HCFAUpdated.OtherPatientInsurance.SignatureOfFile)
            .SetAttribute("OtherPISignatureDate", HCFAUpdated.OtherPatientInsurance.SignatureDate)
            .SetAttribute("OtherPIActive", HCFAUpdated.OtherPatientInsurance.Active)
            .SetAttribute("OtherPIInsurerId", HCFAUpdated.OtherPatientInsurance.InsurerId)
            .SetAttribute("OtherPIEffectiveDateFrom", HCFAUpdated.OtherPatientInsurance.EffectiveDateFrom)
            .SetAttribute("OtherPIEffectiveDateTo", HCFAUpdated.OtherPatientInsurance.EffectiveDateTo)
            .SetAttribute("OtherPIAuthorizationNumber", HCFAUpdated.OtherPatientInsurance.AuthorizationNumber)
            .SetAttribute("OtherPICoInsurance", HCFAUpdated.OtherPatientInsurance.CoInsurance)
            .SetAttribute("OtherPIInsuranceCompanyPhoneNumber", HCFAUpdated.OtherPatientInsurance.InsuranceCompanyPhoneNumber)
            .SetAttribute("OtherPIInsurerInsuranceType", HCFAUpdated.OtherPatientInsurance.InsurerInsuranceType)
            .SetAttribute("OtherPIInsurerInsuranceId", HCFAUpdated.OtherPatientInsurance.InsurerInsuranceId)

            'Patient Extended
            .SetAttribute("PatientPatientID", HCFAUpdated.Patient.PatientID)
            .SetAttribute("PatientPatientCode", HCFAUpdated.Patient.PatientCode)
            .SetAttribute("PatientTitle", HCFAUpdated.Patient.Title)
            .SetAttribute("PatientOccupation", HCFAUpdated.Patient.Occupation)
            .SetAttribute("PatientFirstName", HCFAUpdated.Patient.FirstName)
            .SetAttribute("PatientMiddleName", HCFAUpdated.Patient.MiddleName)
            .SetAttribute("PatientLastName", HCFAUpdated.Patient.LastName)
            .SetAttribute("PatientMartialStatus", HCFAUpdated.Patient.MartialStatus)
            .SetAttribute("PatientAddressLine1", HCFAUpdated.Patient.AddressLine1)
            .SetAttribute("PatientAddressLine2", HCFAUpdated.Patient.AddressLine2)
            .SetAttribute("PatientCity", HCFAUpdated.Patient.City)
            .SetAttribute("PatientStateID", HCFAUpdated.Patient.StateID)
            .SetAttribute("PatientZipCode", HCFAUpdated.Patient.ZipCode)
            .SetAttribute("PatientHousePhone", HCFAUpdated.Patient.HomePhone)
            .SetAttribute("PatientWorkPhone", HCFAUpdated.Patient.WorkPhone)
            .SetAttribute("PatientWorkPhoneExtension", HCFAUpdated.Patient.WorkPhoneExtension)
            .SetAttribute("PatientFax", HCFAUpdated.Patient.Fax)
            .SetAttribute("PatientEmail", HCFAUpdated.Patient.Email)
            .SetAttribute("PatientOccupation", HCFAUpdated.Patient.Occupation)
            .SetAttribute("PatientDOB", HCFAUpdated.Patient.DOB)
            .SetAttribute("PatientGender", HCFAUpdated.Patient.Gender)
            .SetAttribute("PatientInsuranceID", HCFAUpdated.Patient.InsuranceID)
            .SetAttribute("PatientInsuranceName", HCFAUpdated.Patient.InsuranceName)
            .SetAttribute("PatientNcpdpID", HCFAUpdated.Patient.NCPDPID)
            .SetAttribute("PatientPharmacyName", HCFAUpdated.Patient.PharmacyName)
            .SetAttribute("PatientPharmacyProvider", HCFAUpdated.Patient.PharmacyProvider)
            .SetAttribute("PatientSSN", HCFAUpdated.Patient.SSN)
            .SetAttribute("PatientIsDeleted", HCFAUpdated.Patient.IsDeleted)
            .SetAttribute("PatientPictureFilePath", HCFAUpdated.Patient.PictureFilePath)
            .SetAttribute("PatientCellPhoneNumber", HCFAUpdated.Patient.CellPhoneNumber)

            .SetAttribute("PatientEmergencyContactName", HCFAUpdated.Patient.EmergencyContactName)
            .SetAttribute("PatientEmergencyContactRelationship", HCFAUpdated.Patient.EmergencyContactRelationship)
            .SetAttribute("PatientEmergencyContactPhone", HCFAUpdated.Patient.EmergencyContactPhone)
            .SetAttribute("PatientEmergencyContactAddress", HCFAUpdated.Patient.EmergencyContactAddress)
            .SetAttribute("PatientEmergencyContactCity", HCFAUpdated.Patient.EmergencyContactCity)
            .SetAttribute("PatientEmergencyContactZip", HCFAUpdated.Patient.EmergencyContactZip)
            .SetAttribute("PatientEmergencyContactState", HCFAUpdated.Patient.EmergencyContactState)

            .SetAttribute("PatientEmployerName", HCFAUpdated.Patient.EmployerName)
            If HCFAUpdated.Patient.EmploymentStatus = "Select" Then
                .SetAttribute("PatientEmploymentStatus", "")
            Else
                .SetAttribute("PatientEmploymentStatus", HCFAUpdated.Patient.EmploymentStatus)
            End If

            .SetAttribute("PatientEmployerAddressLine1", HCFAUpdated.Patient.EmployerAddressLine1)
            .SetAttribute("PatientEmployerAddressLine2", HCFAUpdated.Patient.EmployerAddressLine2)
            .SetAttribute("PatientEmployerPhoneNumber", HCFAUpdated.Patient.EmployerPhoneNumber)
            .SetAttribute("PatientEmployerCity", HCFAUpdated.Patient.EmployerCity)
            .SetAttribute("PatientEmployerZip", HCFAUpdated.Patient.EmployerZip)
            .SetAttribute("PatientEmployerState", HCFAUpdated.Patient.EmployerState)

            .SetAttribute("PatientResponsibleName", HCFAUpdated.Patient.ResponsibleName)
            .SetAttribute("PatientResponsibleRelationship", HCFAUpdated.Patient.ResponsibleRelationship)
            .SetAttribute("PatientResponsibleHomePhone", HCFAUpdated.Patient.ResponsibleHomePhone)
            .SetAttribute("PatientResponsibleWorkPhone", HCFAUpdated.Patient.ResponsibleWorkPhone)
            .SetAttribute("PatientResponsibleAddress", HCFAUpdated.Patient.ResponsibleAddress)
            .SetAttribute("PatientResponsibleSSN", HCFAUpdated.Patient.ResponsibleSSN)
            .SetAttribute("PatientResponsibleCity", HCFAUpdated.Patient.ResponsibleCity)
            .SetAttribute("PatientResponsibleState", HCFAUpdated.Patient.ResponsibleState)
            .SetAttribute("PatientResponsibleZip", HCFAUpdated.Patient.ResponsibleZip)

            .SetAttribute("PatientNCPDPID2", HCFAUpdated.Patient.NCPDPID2)
            .SetAttribute("PatientPharmacyName2", HCFAUpdated.Patient.PharmacyName2)
            .SetAttribute("PatientPharmacyProvider2", HCFAUpdated.Patient.PharmacyProvider2)

            '' New fields start in billing development cycle
            .SetAttribute("PatientEmergencyContactName2", HCFAUpdated.Patient.EmergencyContactName2)
            .SetAttribute("PatientEmergencyContactRelationship2", HCFAUpdated.Patient.EmergencyContactRelationship2)
            .SetAttribute("PatientEmergencyContactPhone2", HCFAUpdated.Patient.EmergencyContactPhone2)
            .SetAttribute("PatientPreferredHomePh", HCFAUpdated.Patient.PreferredHomePh)
            .SetAttribute("PatientPreferredWorkPh", HCFAUpdated.Patient.PreferredWorkPh)
            .SetAttribute("PatientPreferredCellPh", HCFAUpdated.Patient.PreferredCellPh)
            '' New fields End in billing development cycle
            'field added by madiha on 20/12/2009
            .SetAttribute("PatientEmployeeDesignation", HCFAUpdated.Patient.EmployeeDesignation)

            'Insurer Patient
            .SetAttribute("iPatientPatientID", HCFAUpdated.InsurerPatient.PatientID)
            .SetAttribute("iPatientPatientCode", HCFAUpdated.InsurerPatient.PatientCode)
            .SetAttribute("iPatientTitle", HCFAUpdated.InsurerPatient.Title)
            .SetAttribute("iPatientOccupation", HCFAUpdated.InsurerPatient.Occupation)
            .SetAttribute("iPatientFirstName", HCFAUpdated.InsurerPatient.FirstName)
            .SetAttribute("iPatientMiddleName", HCFAUpdated.InsurerPatient.MiddleName)
            .SetAttribute("iPatientLastName", HCFAUpdated.InsurerPatient.LastName)
            .SetAttribute("iPatientMartialStatus", HCFAUpdated.InsurerPatient.MartialStatus)
            .SetAttribute("iPatientAddressLine1", HCFAUpdated.InsurerPatient.AddressLine1)
            .SetAttribute("iPatientAddressLine2", HCFAUpdated.InsurerPatient.AddressLine2)
            .SetAttribute("iPatientCity", HCFAUpdated.InsurerPatient.City)
            .SetAttribute("iPatientStateID", HCFAUpdated.InsurerPatient.StateID)
            .SetAttribute("iPatientZipCode", HCFAUpdated.InsurerPatient.ZipCode)
            .SetAttribute("iPatientHousePhone", HCFAUpdated.InsurerPatient.HomePhone)
            .SetAttribute("iPatientWorkPhone", HCFAUpdated.InsurerPatient.WorkPhone)
            .SetAttribute("iPatientWorkPhoneExtension", HCFAUpdated.InsurerPatient.WorkPhoneExtension)
            .SetAttribute("iPatientFax", HCFAUpdated.InsurerPatient.Fax)
            .SetAttribute("iPatientEmail", HCFAUpdated.InsurerPatient.Email)
            .SetAttribute("iPatientOccupation", HCFAUpdated.InsurerPatient.Occupation)
            .SetAttribute("iPatientDOB", HCFAUpdated.InsurerPatient.DOB)
            .SetAttribute("iPatientGender", HCFAUpdated.InsurerPatient.Gender)
            .SetAttribute("iPatientInsuranceID", HCFAUpdated.InsurerPatient.InsuranceID)
            .SetAttribute("iPatientInsuranceName", HCFAUpdated.InsurerPatient.InsuranceName)
            .SetAttribute("iPatientNcpdpID", HCFAUpdated.InsurerPatient.NCPDPID)
            .SetAttribute("iPatientPharmacyName", HCFAUpdated.InsurerPatient.PharmacyName)
            .SetAttribute("iPatientPharmacyProvider", HCFAUpdated.InsurerPatient.PharmacyProvider)
            .SetAttribute("iPatientSSN", HCFAUpdated.InsurerPatient.SSN)
            .SetAttribute("iPatientIsDeleted", HCFAUpdated.InsurerPatient.IsDeleted)
            .SetAttribute("iPatientPictureFilePath", HCFAUpdated.InsurerPatient.PictureFilePath)
            .SetAttribute("iPatientCellPhoneNumber", HCFAUpdated.InsurerPatient.CellPhoneNumber)

            .SetAttribute("iPatientEmergencyContactName", HCFAUpdated.InsurerPatient.EmergencyContactName)
            .SetAttribute("iPatientEmergencyContactRelationship", HCFAUpdated.InsurerPatient.EmergencyContactRelationship)
            .SetAttribute("iPatientEmergencyContactPhone", HCFAUpdated.InsurerPatient.EmergencyContactPhone)
            .SetAttribute("iPatientEmergencyContactAddress", HCFAUpdated.InsurerPatient.EmergencyContactAddress)
            .SetAttribute("iPatientEmergencyContactCity", HCFAUpdated.InsurerPatient.EmergencyContactCity)
            .SetAttribute("iPatientEmergencyContactZip", HCFAUpdated.InsurerPatient.EmergencyContactZip)
            .SetAttribute("iPatientEmergencyContactState", HCFAUpdated.InsurerPatient.EmergencyContactState)

            .SetAttribute("iPatientEmployerName", HCFAUpdated.InsurerPatient.EmployerName)
            If HCFAUpdated.InsurerPatient.EmploymentStatus = "Select" Then
                .SetAttribute("iPatientEmploymentStatus", "")
            Else
                .SetAttribute("iPatientEmploymentStatus", HCFAUpdated.InsurerPatient.EmploymentStatus)
            End If

            .SetAttribute("iPatientEmployerAddressLine1", HCFAUpdated.InsurerPatient.EmployerAddressLine1)
            .SetAttribute("iPatientEmployerAddressLine2", HCFAUpdated.InsurerPatient.EmployerAddressLine2)
            .SetAttribute("iPatientEmployerPhoneNumber", HCFAUpdated.InsurerPatient.EmployerPhoneNumber)
            .SetAttribute("iPatientEmployerCity", HCFAUpdated.InsurerPatient.EmployerCity)
            .SetAttribute("iPatientEmployerZip", HCFAUpdated.InsurerPatient.EmployerZip)
            .SetAttribute("iPatientEmployerState", HCFAUpdated.InsurerPatient.EmployerState)

            .SetAttribute("iPatientResponsibleName", HCFAUpdated.InsurerPatient.ResponsibleName)
            .SetAttribute("iPatientResponsibleRelationship", HCFAUpdated.InsurerPatient.ResponsibleRelationship)
            .SetAttribute("iPatientResponsibleHomePhone", HCFAUpdated.InsurerPatient.ResponsibleHomePhone)
            .SetAttribute("iPatientResponsibleWorkPhone", HCFAUpdated.InsurerPatient.ResponsibleWorkPhone)
            .SetAttribute("iPatientResponsibleAddress", HCFAUpdated.InsurerPatient.ResponsibleAddress)
            .SetAttribute("iPatientResponsibleSSN", HCFAUpdated.InsurerPatient.ResponsibleSSN)
            .SetAttribute("iPatientResponsibleCity", HCFAUpdated.InsurerPatient.ResponsibleCity)
            .SetAttribute("iPatientResponsibleState", HCFAUpdated.InsurerPatient.ResponsibleState)
            .SetAttribute("iPatientResponsibleZip", HCFAUpdated.InsurerPatient.ResponsibleZip)

            .SetAttribute("iPatientNCPDPID2", HCFAUpdated.InsurerPatient.NCPDPID2)
            .SetAttribute("iPatientPharmacyName2", HCFAUpdated.InsurerPatient.PharmacyName2)
            .SetAttribute("iPatientPharmacyProvider2", HCFAUpdated.InsurerPatient.PharmacyProvider2)

            '' New fields start in billing development cycle
            .SetAttribute("iPatientEmergencyContactName2", HCFAUpdated.InsurerPatient.EmergencyContactName2)
            .SetAttribute("iPatientEmergencyContactRelationship2", HCFAUpdated.InsurerPatient.EmergencyContactRelationship2)
            .SetAttribute("iPatientEmergencyContactPhone2", HCFAUpdated.InsurerPatient.EmergencyContactPhone2)
            .SetAttribute("iPatientPreferredHomePh", HCFAUpdated.InsurerPatient.PreferredHomePh)
            .SetAttribute("iPatientPreferredWorkPh", HCFAUpdated.InsurerPatient.PreferredWorkPh)
            .SetAttribute("iPatientPreferredCellPh", HCFAUpdated.InsurerPatient.PreferredCellPh)
            '' New fields End in billing development cycle
            'field added by madiha on 20/12/2009
            .SetAttribute("iPatientEmployeeDesignation", HCFAUpdated.InsurerPatient.EmployeeDesignation)



            'Other Insurer Patient
            .SetAttribute("OtherIPPatientID", HCFAUpdated.OtherInsurerPatient.PatientID)
            .SetAttribute("OtherIPPatientCode", HCFAUpdated.OtherInsurerPatient.PatientCode)
            .SetAttribute("OtherIPTitle", HCFAUpdated.OtherInsurerPatient.Title)
            .SetAttribute("OtherIPOccupation", HCFAUpdated.OtherInsurerPatient.Occupation)
            .SetAttribute("OtherIPFirstName", HCFAUpdated.OtherInsurerPatient.FirstName)
            .SetAttribute("OtherIPMiddleName", HCFAUpdated.OtherInsurerPatient.MiddleName)
            .SetAttribute("OtherIPLastName", HCFAUpdated.OtherInsurerPatient.LastName)
            .SetAttribute("OtherIPMartialStatus", HCFAUpdated.OtherInsurerPatient.MartialStatus)
            .SetAttribute("OtherIPAddressLine1", HCFAUpdated.OtherInsurerPatient.AddressLine1)
            .SetAttribute("OtherIPAddressLine2", HCFAUpdated.OtherInsurerPatient.AddressLine2)
            .SetAttribute("OtherIPCity", HCFAUpdated.OtherInsurerPatient.City)
            .SetAttribute("OtherIPStateID", HCFAUpdated.OtherInsurerPatient.StateID)
            .SetAttribute("OtherIPZipCode", HCFAUpdated.OtherInsurerPatient.ZipCode)
            .SetAttribute("OtherIPHousePhone", HCFAUpdated.OtherInsurerPatient.HomePhone)
            .SetAttribute("OtherIPWorkPhone", HCFAUpdated.OtherInsurerPatient.WorkPhone)
            .SetAttribute("OtherIPWorkPhoneExtension", HCFAUpdated.OtherInsurerPatient.WorkPhoneExtension)
            .SetAttribute("OtherIPFax", HCFAUpdated.OtherInsurerPatient.Fax)
            .SetAttribute("OtherIPEmail", HCFAUpdated.OtherInsurerPatient.Email)
            .SetAttribute("OtherIPOccupation", HCFAUpdated.OtherInsurerPatient.Occupation)
            .SetAttribute("OtherIPDOB", HCFAUpdated.OtherInsurerPatient.DOB)
            .SetAttribute("OtherIPGender", HCFAUpdated.OtherInsurerPatient.Gender)
            .SetAttribute("OtherIPInsuranceID", HCFAUpdated.OtherInsurerPatient.InsuranceID)
            .SetAttribute("OtherIPInsuranceName", HCFAUpdated.OtherInsurerPatient.InsuranceName)
            .SetAttribute("OtherIPNcpdpID", HCFAUpdated.OtherInsurerPatient.NCPDPID)
            .SetAttribute("OtherIPPharmacyName", HCFAUpdated.OtherInsurerPatient.PharmacyName)
            .SetAttribute("OtherIPPharmacyProvider", HCFAUpdated.OtherInsurerPatient.PharmacyProvider)
            .SetAttribute("OtherIPSSN", HCFAUpdated.OtherInsurerPatient.SSN)
            .SetAttribute("OtherIPIsDeleted", HCFAUpdated.OtherInsurerPatient.IsDeleted)
            .SetAttribute("OtherIPPictureFilePath", HCFAUpdated.OtherInsurerPatient.PictureFilePath)
            .SetAttribute("OtherIPCellPhoneNumber", HCFAUpdated.OtherInsurerPatient.CellPhoneNumber)

            .SetAttribute("OtherIPEmergencyContactName", HCFAUpdated.OtherInsurerPatient.EmergencyContactName)
            .SetAttribute("OtherIPEmergencyContactRelationship", HCFAUpdated.OtherInsurerPatient.EmergencyContactRelationship)
            .SetAttribute("OtherIPEmergencyContactPhone", HCFAUpdated.OtherInsurerPatient.EmergencyContactPhone)
            .SetAttribute("OtherIPEmergencyContactAddress", HCFAUpdated.OtherInsurerPatient.EmergencyContactAddress)
            .SetAttribute("OtherIPEmergencyContactCity", HCFAUpdated.OtherInsurerPatient.EmergencyContactCity)
            .SetAttribute("OtherIPEmergencyContactZip", HCFAUpdated.OtherInsurerPatient.EmergencyContactZip)
            .SetAttribute("OtherIPEmergencyContactState", HCFAUpdated.OtherInsurerPatient.EmergencyContactState)

            .SetAttribute("OtherIPEmployerName", HCFAUpdated.OtherInsurerPatient.EmployerName)
            If HCFAUpdated.OtherInsurerPatient.EmploymentStatus = "Select" Then
                .SetAttribute("OtherIPEmploymentStatus", "")
            Else
                .SetAttribute("OtherIPEmploymentStatus", HCFAUpdated.OtherInsurerPatient.EmploymentStatus)
            End If

            .SetAttribute("OtherIPEmployerAddressLine1", HCFAUpdated.OtherInsurerPatient.EmployerAddressLine1)
            .SetAttribute("OtherIPEmployerAddressLine2", HCFAUpdated.OtherInsurerPatient.EmployerAddressLine2)
            .SetAttribute("OtherIPEmployerPhoneNumber", HCFAUpdated.OtherInsurerPatient.EmployerPhoneNumber)
            .SetAttribute("OtherIPEmployerCity", HCFAUpdated.OtherInsurerPatient.EmployerCity)
            .SetAttribute("OtherIPEmployerZip", HCFAUpdated.OtherInsurerPatient.EmployerZip)
            .SetAttribute("OtherIPEmployerState", HCFAUpdated.OtherInsurerPatient.EmployerState)

            .SetAttribute("OtherIPResponsibleName", HCFAUpdated.OtherInsurerPatient.ResponsibleName)
            .SetAttribute("OtherIPResponsibleRelationship", HCFAUpdated.OtherInsurerPatient.ResponsibleRelationship)
            .SetAttribute("OtherIPResponsibleHomePhone", HCFAUpdated.OtherInsurerPatient.ResponsibleHomePhone)
            .SetAttribute("OtherIPResponsibleWorkPhone", HCFAUpdated.OtherInsurerPatient.ResponsibleWorkPhone)
            .SetAttribute("OtherIPResponsibleAddress", HCFAUpdated.OtherInsurerPatient.ResponsibleAddress)
            .SetAttribute("OtherIPResponsibleSSN", HCFAUpdated.OtherInsurerPatient.ResponsibleSSN)
            .SetAttribute("OtherIPResponsibleCity", HCFAUpdated.OtherInsurerPatient.ResponsibleCity)
            .SetAttribute("OtherIPResponsibleState", HCFAUpdated.OtherInsurerPatient.ResponsibleState)
            .SetAttribute("OtherIPResponsibleZip", HCFAUpdated.OtherInsurerPatient.ResponsibleZip)

            .SetAttribute("OtherIPNCPDPID2", HCFAUpdated.OtherInsurerPatient.NCPDPID2)
            .SetAttribute("OtherIPPharmacyName2", HCFAUpdated.OtherInsurerPatient.PharmacyName2)
            .SetAttribute("OtherIPPharmacyProvider2", HCFAUpdated.OtherInsurerPatient.PharmacyProvider2)

            '' New fields start in billing development cycle
            .SetAttribute("OtherIPEmergencyContactName2", HCFAUpdated.OtherInsurerPatient.EmergencyContactName2)
            .SetAttribute("OtherIPEmergencyContactRelationship2", HCFAUpdated.OtherInsurerPatient.EmergencyContactRelationship2)
            .SetAttribute("OtherIPEmergencyContactPhone2", HCFAUpdated.OtherInsurerPatient.EmergencyContactPhone2)
            .SetAttribute("OtherIPPreferredHomePh", HCFAUpdated.OtherInsurerPatient.PreferredHomePh)
            .SetAttribute("OtherIPPreferredWorkPh", HCFAUpdated.OtherInsurerPatient.PreferredWorkPh)
            .SetAttribute("OtherIPPreferredCellPh", HCFAUpdated.OtherInsurerPatient.PreferredCellPh)
            .SetAttribute("OtherIPEmployeeDesignation", HCFAUpdated.OtherInsurerPatient.EmployeeDesignation)



            .SetAttribute("PatientConditionEmployment", HCFAUpdated.PatientConditionEmployment)
            .SetAttribute("PatientConditionAutoAccident", HCFAUpdated.PatientConditionAutoAccident)
            .SetAttribute("PatientConditionAutoAccPlace", HCFAUpdated.PatientConditionAutoAccPlace)
            .SetAttribute("PatientConditionOtherAccident", HCFAUpdated.PatientConditionOtherAccident)

            ' HCFA Fields
            .SetAttribute("SignOnFile", HCFAUpdated.SignOnFile)
            .SetAttribute("SignDate", HCFAUpdated.SignDate)
            .SetAttribute("AuthorizedPersonSign", HCFAUpdated.AuthorizedPersonSign)
            .SetAttribute("DateOfOccurance", HCFAUpdated.DateOfOccurance)
            .SetAttribute("PreviousOccuranceDate", HCFAUpdated.PreviousOccuranceDate)
            .SetAttribute("PatUnableToWorkFrom", HCFAUpdated.PatUnableToWorkFrom)
            .SetAttribute("PatUnableToWorkTo", HCFAUpdated.PatUnableToWorkTo)


            'Referring Provider
            .SetAttribute("RefPvdProviderID", HCFAUpdated.ReferencePvd.ProviderID)
            .SetAttribute("RefPVDFirstName", HCFAUpdated.ReferencePvd.FirstName)
            .SetAttribute("RefPVDMiddleName", HCFAUpdated.ReferencePvd.MiddleName)
            .SetAttribute("RefPVDLastName", HCFAUpdated.ReferencePvd.LastName)
            .SetAttribute("RefPVDTitle", HCFAUpdated.ReferencePvd.Title)
            .SetAttribute("RefPVDAddressLine1", HCFAUpdated.ReferencePvd.AddressLine1)
            .SetAttribute("RefPVDAddressLine2", HCFAUpdated.ReferencePvd.AddressLine2)
            .SetAttribute("RefPVDCity", HCFAUpdated.ReferencePvd.City)
            .SetAttribute("RefPVDState", HCFAUpdated.ReferencePvd.State)
            .SetAttribute("RefPVDZipCode", HCFAUpdated.ReferencePvd.ZipCode)
            .SetAttribute("RefPVDWorkPhone", HCFAUpdated.ReferencePvd.WorkPhone)
            .SetAttribute("RefPVDFax", HCFAUpdated.ReferencePvd.Fax)
            .SetAttribute("RefPVDEmail", HCFAUpdated.ReferencePvd.Email)
            .SetAttribute("RefPVDNPI", HCFAUpdated.ReferencePvd.NPI)
            .SetAttribute("RefPVDExt", HCFAUpdated.ReferencePvd.Ext)
            .SetAttribute("RefPVDSpeciality", HCFAUpdated.ReferencePvd.Speciality)
            .SetAttribute("RefPVDFacilityID", HCFAUpdated.ReferencePvd.Facility)
            .SetAttribute("RefPVDIsDelete", "N")
            .SetAttribute("RefPVDDegree", HCFAUpdated.ReferencePvd.Degree)


            'HCFA Fields
            .SetAttribute("HospitalizationDateFrom", HCFAUpdated.HospitalizationDateFrom)
            .SetAttribute("HospitalizationDateTo", HCFAUpdated.HospitalizationDateTo)
            .SetAttribute("Field19", HCFAUpdated.Field19)
            .SetAttribute("IsOutsideLab", HCFAUpdated.IsOutsideLab)
            .SetAttribute("OutSideLabCharges", HCFAUpdated.OutsideLabCharges)

            .SetAttribute("ICD1", HCFAUpdated.ICD1)
            .SetAttribute("ICD2", HCFAUpdated.ICD2)
            .SetAttribute("ICD3", HCFAUpdated.ICD3)
            .SetAttribute("ICD4", HCFAUpdated.ICD4)
            .SetAttribute("ICD5", HCFAUpdated.ICD5)
            .SetAttribute("ICD6", HCFAUpdated.ICD6)                          
            .SetAttribute("ICD7", HCFAUpdated.ICD7)
            .SetAttribute("ICD8", HCFAUpdated.ICD8)
            .SetAttribute("ICD9", HCFAUpdated.ICD9)
            .SetAttribute("ICD10", HCFAUpdated.ICD10)
            .SetAttribute("ICD11", HCFAUpdated.ICD11)
            .SetAttribute("ICD12", HCFAUpdated.ICD12)

            .SetAttribute("MedicadReSubCode", HCFAUpdated.MedicadReSubCode)
            .SetAttribute("MedicadReSubNo", HCFAUpdated.MedicadReSubNo)


            .SetAttribute("FederalTaxNo", HCFAUpdated.FederalTaxNo)
            .SetAttribute("FederalTaxType", HCFAUpdated.FederalTaxType)
            .SetAttribute("PatientACNo", HCFAUpdated.PatientACNo)
            .SetAttribute("AcceptAssignment", HCFAUpdated.AcceptAssignment)
            .SetAttribute("TotalCharges", HCFAUpdated.TotalCharges)
            .SetAttribute("AmountPaid", HCFAUpdated.AmountPaid)
            .SetAttribute("BalanceDue", HCFAUpdated.BalanceDue)


            Dim lSetupID As String = "0"

            'If Not Employee.DEA.Equals("") Then
            Dim lQuery As String = "select min(id) from Setup"

            If Connection.IsTransactionAlive() Then
                lSetupID = Connection.ExecuteTransactionScalarCommand(lQuery)
            Else
                lSetupID = Connection.ExecuteScalarCommand(lQuery)
            End If


            'Rendering Provider

            .SetAttribute("RenPvdEmployeeID", HCFAUpdated.RenderingProvider.EmployeeID)
            .SetAttribute("RenPvdClinicCode", HCFAUpdated.RenderingProvider.ClinicCode)
            .SetAttribute("RenPvdDesignation", HCFAUpdated.RenderingProvider.Designation)
            .SetAttribute("RenPvdLoginID", HCFAUpdated.RenderingProvider.LoginID)
            .SetAttribute("RenPvdPassword", HCFAUpdated.RenderingProvider.Password)
            .SetAttribute("RenPvdTitle", HCFAUpdated.RenderingProvider.Title)
            .SetAttribute("RenPvdFirstName", HCFAUpdated.RenderingProvider.FirstName)
            .SetAttribute("RenPvdMiddleName", HCFAUpdated.RenderingProvider.MiddleName)
            .SetAttribute("RenPvdLastName", HCFAUpdated.RenderingProvider.LastName)
            .SetAttribute("RenPvdGender", HCFAUpdated.RenderingProvider.Gender)
            .SetAttribute("RenPvdDOB", HCFAUpdated.RenderingProvider.DOB)
            .SetAttribute("RenPvdSSN", HCFAUpdated.RenderingProvider.SSN)
            .SetAttribute("RenPvdAddressLine1", HCFAUpdated.RenderingProvider.AddressLine1)
            .SetAttribute("RenPvdAddressLine2", HCFAUpdated.RenderingProvider.AddressLine2)
            .SetAttribute("RenPvdCity", HCFAUpdated.RenderingProvider.City)
            .SetAttribute("RenPvdStateId", HCFAUpdated.RenderingProvider.StateId)
            .SetAttribute("RenPvdZipCode", HCFAUpdated.RenderingProvider.ZipCode)
            .SetAttribute("RenPvdHomePhone", HCFAUpdated.RenderingProvider.HomePhone)
            .SetAttribute("RenPvdWorkPhone", HCFAUpdated.RenderingProvider.WorkPhone)
            .SetAttribute("RenPvdWorkPhoneExtension", HCFAUpdated.RenderingProvider.WorkPhoneExtension)
            .SetAttribute("RenPvdFax", HCFAUpdated.RenderingProvider.Fax)
            .SetAttribute("RenPvdEmail", HCFAUpdated.RenderingProvider.Email)
            .SetAttribute("RenPvdLoginStatus", HCFAUpdated.RenderingProvider.LoginStatus)
            .SetAttribute("RenPvdSPI", HCFAUpdated.RenderingProvider.SPI)
            .SetAttribute("RenPvdDEA", HCFAUpdated.RenderingProvider.DEA)
            .SetAttribute("RenPvdLicence", HCFAUpdated.RenderingProvider.Licence)
            .SetAttribute("RenPvdServiceLevel", HCFAUpdated.RenderingProvider.ServiceLevel)
            .SetAttribute("RenPvdStartDate", HCFAUpdated.RenderingProvider.StartDate)
            .SetAttribute("RenPvdEndDate", HCFAUpdated.RenderingProvider.EndDate)
            .SetAttribute("RenPvdSigPath", HCFAUpdated.RenderingProvider.SigPath)
            .SetAttribute("RenPvdIsDeleted", HCFAUpdated.RenderingProvider.IsDeleted)
            .SetAttribute("RenPvdTheme", HCFAUpdated.RenderingProvider.Theme)
            .SetAttribute("RenPvdScreeningEnabled", HCFAUpdated.RenderingProvider.ScreeningEnabled)
            .SetAttribute("RenPvdDAW", "N")
            .SetAttribute("RenPvdNPI", HCFAUpdated.RenderingProvider.NPI)


            .SetAttribute("RenPvdTaxID", HCFAUpdated.RenderingProvider.TaxID)
            .SetAttribute("RenPvdStateLicenseID", HCFAUpdated.RenderingProvider.StateLicenseID)
            .SetAttribute("RenPvdDEA2", HCFAUpdated.RenderingProvider.DEA2)
            .SetAttribute("RenPvdSpecialityCode", HCFAUpdated.RenderingProvider.SpecialityCode)

            'If Not HCFAUpdated.RenderingProvider.DEA.Equals("RenPvd") Then
            .SetAttribute("RenPvdSetup_ID", lSetupID)
            'End If
            .SetAttribute("RenPvdIsPrintRx", HCFAUpdated.RenderingProvider.IsPrintRx)
            .SetAttribute("RenPvdDegree", HCFAUpdated.RenderingProvider.Degree)

            .SetAttribute("RenPvdIsActive", HCFAUpdated.RenderingProvider.IsActive)
            .SetAttribute("RenPvdIsLocked", HCFAUpdated.RenderingProvider.IsLocked)
            .SetAttribute("RenPvdIsReseted", HCFAUpdated.RenderingProvider.IsReseted)
            .SetAttribute("RenPvdIsSuperAdmin", HCFAUpdated.RenderingProvider.IsSuperAdmin)

            'If Not HCFAUpdated.RenderingProvider.LoginCount.Equals("RenPvd") Then
            .SetAttribute("RenPvdLoginCount", HCFAUpdated.RenderingProvider.LoginCount)
            'Else
            .SetAttribute("RenPvdLoginCount", 0)
            .SetAttribute("RenPvdDEASuffix", HCFAUpdated.RenderingProvider.DEASuffix)
            .SetAttribute("RenPvdCptNo", HCFAUpdated.RenderingProvider.CptNo)


            ' Service Facility
            .SetAttribute("ServFacFacilityID", HCFAUpdated.ServiceFacility.FacilityID)
            .SetAttribute("ServFacFacilityName", HCFAUpdated.ServiceFacility.FacilityName)
            .SetAttribute("ServFacNPI", HCFAUpdated.ServiceFacility.NPI)
            .SetAttribute("ServFacAddressLine1", HCFAUpdated.ServiceFacility.AddressLine1)
            .SetAttribute("ServFacAddressLine2", HCFAUpdated.ServiceFacility.AddressLine2)
            .SetAttribute("ServFacCity", HCFAUpdated.ServiceFacility.City)
            .SetAttribute("ServFacState", HCFAUpdated.ServiceFacility.State)
            .SetAttribute("ServFacPhone", HCFAUpdated.ServiceFacility.Phone)
            .SetAttribute("ServFacFax", HCFAUpdated.ServiceFacility.Fax)
            .SetAttribute("ServFacZipCode", HCFAUpdated.ServiceFacility.ZipCode)
            .SetAttribute("ServFacIsDelete", "N")
            .SetAttribute("ServFacFacilityCode", HCFAUpdated.ServiceFacility.FacilityCode)



            ' Billing Provider
            .SetAttribute("BPvdBillingProviderId", HCFAUpdated.BillingPvd.BillingProviderId)
            .SetAttribute("BPvdFirstName", HCFAUpdated.BillingPvd.FirstName)
            .SetAttribute("BPvdMiddleName", HCFAUpdated.BillingPvd.MiddleName)
            .SetAttribute("BPvdLastName", HCFAUpdated.BillingPvd.LastName)
            .SetAttribute("BPvdAddressLine1", HCFAUpdated.BillingPvd.AddressLine1)
            .SetAttribute("BPvdAddressLine2", HCFAUpdated.BillingPvd.AddressLine2)
            .SetAttribute("BPvdCity", HCFAUpdated.BillingPvd.City)
            .SetAttribute("BPvdState", HCFAUpdated.BillingPvd.State)
            .SetAttribute("BPvdZipCode", HCFAUpdated.BillingPvd.ZipCode)
            .SetAttribute("BPvdPhone1", HCFAUpdated.BillingPvd.Phone1)
            .SetAttribute("BPvdPhone2", HCFAUpdated.BillingPvd.Phone2)
            .SetAttribute("BPvdFax", HCFAUpdated.BillingPvd.Fax)
            .SetAttribute("BPvdEmail", HCFAUpdated.BillingPvd.Email)
            .SetAttribute("BPvdNPI", HCFAUpdated.BillingPvd.NPI)
            .SetAttribute("BPvdTaxID", HCFAUpdated.BillingPvd.TaxID)
            .SetAttribute("BPvdSSN", HCFAUpdated.BillingPvd.SSN)
            .SetAttribute("BPvdProviderID", HCFAUpdated.BillingPvd.ProviderID)
            .SetAttribute("BPvdProviderNPI", HCFAUpdated.BillingPvd.ProviderNPI)
            .SetAttribute("BPvdEntryType", HCFAUpdated.BillingPvd.EntryType)
            .SetAttribute("BPvdEntryInsuranceTypeCode", HCFAUpdated.BillingPvd.EntryInsuranceTypeCode)
            .SetAttribute("BPvdEntryInsuranceTypeValue", HCFAUpdated.BillingPvd.EntryInsuranceTypeValue)

            .SetAttribute("IsActive", HCFAUpdated.IsActive)
            .SetAttribute("ServFacSecIdQualifier", HCFAUpdated.ServFacSecIdQualifier)
            .SetAttribute("ServFacSecIdValue", HCFAUpdated.ServFacSecIdValue)
            .SetAttribute("BPvdSecIdQualifier", HCFAUpdated.BPvdSecIdQualifier)
            .SetAttribute("BPvdSecIdValue", HCFAUpdated.BPvdSecIdValue)
            .SetAttribute("ReservedField10d", HCFAUpdated.ReservedField10d)


        End With

        lXmlDocument.DocumentElement.AppendChild(lXmlElement.CloneNode(True))


        If Connection.IsTransactionAlive() Then
            InsertRecord = Connection.ExecuteTransactionScalarCommand("InsertHCFAUpdated", lXmlDocument.InnerXml.ToString)
        Else
            InsertRecord = Connection.ExecuteScalarCommand("InsertHCFAUpdated", lXmlDocument.InnerXml.ToString)
        End If

    End Function
    Public Function GetUniqueIdHCFA() As String
        Dim lDs As New DataSet()
        Dim lID As String = ""

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("Exec GetUniqueIdHCFA")
        Else
            lDs = Connection.ExecuteQuery("Exec GetUniqueIdHCFA")
        End If

        If (lDs.Tables(0).Rows.Count > 0) Then
            lID = lDs.Tables(0).Rows(0)("HCFAID") & "|" & lDs.Tables(0).Rows(0)("HCFADisplayID")
        Else
            lID = ""
        End If

        Return lID

    End Function

    Public Function GetUniqueIdHCFAUpdated() As String
        Dim lDs As New DataSet()
        Dim lID As String = ""

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("Exec GetUniqueIdHCFAUpdated")
        Else
            lDs = Connection.ExecuteQuery("Exec GetUniqueIdHCFAUpdated")
        End If

        If (lDs.Tables(0).Rows.Count > 0) Then
            lID = lDs.Tables(0).Rows(0)("HCFAID") & "|" & lDs.Tables(0).Rows(0)("HCFADisplayID")
        Else
            lID = ""
        End If

        Return lID

    End Function

    Public Function EditHCFADetailUpdated(ByVal pQuery2 As String) As Boolean

        Dim lDs As New DataSet()
        Dim lID As String = ""
        Try

            If Connection.IsTransactionAlive() Then
                Connection.ExecuteTransactionCommand(pQuery2)

            Else
                Connection.ExecuteCommand(pQuery2)

            End If
            Return True
        Catch ex As Exception
            Return False
        End Try



    End Function

    'Public Function EditHCFAUpdated(ByVal pQuery1 As String) As Boolean

    '    Dim lDs As New DataSet()

    '    Try

    '        If Connection.IsTransactionAlive() Then
    '            Connection.ExecuteTransactionCommand(pQuery1)

    '        Else
    '            Connection.ExecuteCommand(pQuery1)

    '        End If
    '        Return True

    '    Catch ex As Exception
    '        Return False
    '    End Try


    'End Function

    'Added by: Kanwal jeet
    Public Function UpdateNotes() As Boolean
        Dim lCondition As String
        Dim lQuery As String

        With Me.HCFAUpdated

            lCondition = "And HCFAID = " & .HCFAID
            lQuery = "Update HCFAUpdated Set " _
                        & "HCFANotes ='" & .HCFANotes & "' " _
                        & "Where 1 = 1 " _
                        & lCondition
        End With

        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand(lQuery)
        Else
            Connection.ExecuteCommand(lQuery)
        End If


    End Function

    Public Function LoadNotes(ByVal pHCFAUpdatedDB As HCFADBUpdated, ByVal pHCFAID As Integer) As System.Data.DataSet

        Dim lQuery As String
        Dim lDs As New DataSet()

        lQuery = "Select HCFANotes from HCFAUpdated " _
                & "Where HCFAID='" & pHCFAID & "'"
        'If Connection.IsTransactionAlive() Then

        'Else
        lDs = (Connection.ExecuteQuery(lQuery))

        'End If
        Return lDs
    End Function

    Public Function InsertNotes() As Boolean
        Dim lCondition As String
        Dim lQuery As String

        With Me.HCFAUpdated

            lCondition = "And HCFAID = " & .HCFAID
            lQuery = "Update HCFAUpdated Set " _
                        & "HCFANotes ='" & .HCFANotes & "' " _
                        & "Where 1 = 1 " _
                        & lCondition
        End With

        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand(lQuery)
        Else
            Connection.ExecuteCommand(lQuery)
        End If

    End Function

    Public Function UpdateHCFAUpdated(ByVal pHCFADBUpdated As HCFADBUpdated) As Boolean


        Dim lHcfaUpdated = New HCFADBUpdated

        Dim lQuery1 = "UPDATE [HCFAUpdated] SET [MainICInsuranceType] ='" & pHCFADBUpdated.MainInsuranceCompany.InsuranceType & _
"',[MainPISubscriberID] ='" & pHCFADBUpdated.MainPatientInsurance.SubscriberID & _
 "',[PatientFirstName] ='" & pHCFADBUpdated.Patient.FirstName & _
      "',[PatientMiddleName] ='" & pHCFADBUpdated.Patient.MiddleName & _
      "',[PatientLastName] ='" & pHCFADBUpdated.Patient.LastName & _
      "',[PatientAddressLine1] ='" & pHCFADBUpdated.Patient.AddressLine1 & _
      "',[PatientAddressLine2] ='" & pHCFADBUpdated.Patient.AddressLine2 & _
"',[PatientDOB] ='" & pHCFADBUpdated.Patient.DOB & _
"' ,[PatientCity] = '" & pHCFADBUpdated.Patient.City & _
     "' ,[PatientStateID] ='" & pHCFADBUpdated.Patient.StateID & _
     "' ,[PatientZipCode]  ='" & pHCFADBUpdated.Patient.ZipCode & _
     "' ,[PatientHousePhone] = '" & pHCFADBUpdated.Patient.HomePhone & _
     "' ,[PatientWorkPhone]  = '" & pHCFADBUpdated.Patient.WorkPhone & _
"',[PatientGender]='" & pHCFADBUpdated.Patient.Gender & _
"',[MainPIRelationshipToPrimaryInsurer]='" & pHCFADBUpdated.MainPatientInsurance.RelationshipToPrimaryInsurer & _
"',[PatientMartialStatus]='" & pHCFADBUpdated.Patient.MartialStatus & _
"',[PatientEmploymentStatus]='" & pHCFADBUpdated.Patient.EmploymentStatus & _
"',[PatientConditionEmployment]='" & pHCFADBUpdated.PatientConditionEmployment & _
"',[PatientConditionAutoAccident]='" & pHCFADBUpdated.PatientConditionAutoAccident & _
"',[PatientConditionAutoAccPlace]='" & pHCFADBUpdated.Patient.StateID & _
"',[PatientConditionOtherAccident]='" & pHCFADBUpdated.PatientConditionOtherAccident & _
"',[Field19]='" & pHCFADBUpdated.Field19 & _
 "',[iPatientFirstName] ='" & pHCFADBUpdated.InsurerPatient.FirstName & _
      "',[iPatientMiddleName] ='" & pHCFADBUpdated.InsurerPatient.MiddleName & _
      "',[iPatientLastName] ='" & pHCFADBUpdated.InsurerPatient.LastName & _
      "',[iPatientAddressLine1] ='" & pHCFADBUpdated.InsurerPatient.AddressLine1 & _
      "',[iPatientAddressLine2] ='" & pHCFADBUpdated.InsurerPatient.AddressLine2 & _
"',[iPatientDOB]='" & pHCFADBUpdated.InsurerPatient.DOB & _
"',[iPatientCity]='" & pHCFADBUpdated.InsurerPatient.City & _
"',[iPatientStateID]='" & pHCFADBUpdated.InsurerPatient.StateID & _
"',[iPatientZipCode]='" & pHCFADBUpdated.InsurerPatient.ZipCode & _
"',[iPatientHousePhone]='" & pHCFADBUpdated.InsurerPatient.HomePhone & _
"',[MainPIGroupNo]='" & pHCFADBUpdated.MainPatientInsurance.GroupNo & _
"',[iPatientGender]='" & pHCFADBUpdated.InsurerPatient.Gender & _
"',[iPatientEmployerName]='" & pHCFADBUpdated.InsurerPatient.EmployerName & _
"',[iPatientInsuranceName]='" & pHCFADBUpdated.InsurerPatient.InsuranceName & _
"',[MainPIPlanName]='" & pHCFADBUpdated.MainPatientInsurance.PlanName & _
 "',[OtherIPFirstName] ='" & pHCFADBUpdated.OtherInsurerPatient.FirstName & _
      "',[OtherIPMiddleName] ='" & pHCFADBUpdated.OtherInsurerPatient.MiddleName & _
      "',[OtherIPLastName] ='" & pHCFADBUpdated.OtherInsurerPatient.LastName & _
      "',[OtherIPAddressLine1] ='" & pHCFADBUpdated.OtherInsurerPatient.AddressLine1 & _
      "',[OtherIPAddressLine2] ='" & pHCFADBUpdated.OtherInsurerPatient.AddressLine2 & _
"',[OtherIPDOB]='" & pHCFADBUpdated.OtherInsurerPatient.DOB & _
"',[OtherIPGender]='" & pHCFADBUpdated.OtherInsurerPatient.Gender & _
"',[OtherIPEmployerName]='" & pHCFADBUpdated.OtherInsurerPatient.EmployerName & _
"',[OtherIPInsuranceName]='" & pHCFADBUpdated.OtherInsurerPatient.InsuranceName & _
"',[OtherPIPlanName]='" & pHCFADBUpdated.OtherPatientInsurance.PlanName & _
"',[OtherPIGroupNo]='" & pHCFADBUpdated.OtherPatientInsurance.GroupNo & _
"',[MainPISignatureDate]='" & pHCFADBUpdated.MainPatientInsurance.SignatureDate & _
"',[DateOfOccurance]='" & pHCFADBUpdated.DateOfOccurance & _
"',[DateOfCurrentIllnessQual]='" & pHCFADBUpdated.DateOfCurrentIllnessQual & _
"',[OtherDateQual1]='" & pHCFADBUpdated.OtherDateQual1 & _
"',[OtherDateQual2]='" & pHCFADBUpdated.OtherDateQual2 & _
"',[NameOfRefProviderQual]='" & pHCFADBUpdated.NameOfRefProviderQual & _
"',[PreviousOccuranceDate]='" & pHCFADBUpdated.PreviousOccuranceDate & _
"',[RefPVDFirstName]='" & pHCFADBUpdated.ReferencePvd.FirstName & _
      "',[RefPVDMiddleName]='" & pHCFADBUpdated.ReferencePvd.MiddleName & _
      "',[RefPVDLastName]='" & pHCFADBUpdated.ReferencePvd.LastName & _
      "',[RefPVDTitle]='" & pHCFADBUpdated.ReferencePvd.Title & _
      "',[RefPVDAddressLine1]='" & pHCFADBUpdated.ReferencePvd.AddressLine1 & _
      "',[RefPVDAddressLine2]='" & pHCFADBUpdated.ReferencePvd.AddressLine2 & _
      "',[RefPVDCity]='" & pHCFADBUpdated.ReferencePvd.City & _
      "',[RefPVDState]='" & pHCFADBUpdated.ReferencePvd.State & _
      "',[RefPVDZipCode]='" & pHCFADBUpdated.ReferencePvd.ZipCode & _
      "',[RefPVDWorkPhone]='" & pHCFADBUpdated.ReferencePvd.WorkPhone & _
      "',[RefPVDExt]='" & pHCFADBUpdated.ReferencePvd.Ext & _
      "',[RefPVDFax]='" & pHCFADBUpdated.ReferencePvd.Fax & _
      "',[RefPVDEmail]='" & pHCFADBUpdated.ReferencePvd.Email & _
      "',[RefPVDNPI]='" & pHCFADBUpdated.ReferencePvd.NPI & _
      "',[RefPVDSpeciality]='" & pHCFADBUpdated.ReferencePvd.Speciality & _
      "',[RefPVDFacilityID]='" & pHCFADBUpdated.ReferencePvd.Facility & _
"',[PatUnableToWorkFrom]='" & pHCFADBUpdated.PatUnableToWorkFrom & _
"',[PatUnableToWorkTo]='" & pHCFADBUpdated.PatUnableToWorkTo & _
"',[HospitalizationDateFrom]='" & pHCFADBUpdated.HospitalizationDateFrom & _
"',[HospitalizationDateTo]='" & pHCFADBUpdated.HospitalizationDateTo & _
"',[IsOutsideLab]='" & pHCFADBUpdated.IsOutsideLab & _
"',[OutSideLabCharges]='" & pHCFADBUpdated.OutsideLabCharges & _
"',[ICD1]='" & pHCFADBUpdated.ICD1 & _
"',[ICD2]='" & pHCFADBUpdated.ICD2 & _
"',[ICD3]='" & pHCFADBUpdated.ICD3 & _
"',[ICD4]='" & pHCFADBUpdated.ICD4 & _
"',[ICD5]='" & pHCFADBUpdated.ICD5 & _
"',[ICD6]='" & pHCFADBUpdated.ICD6 & _
"',[ICD7]='" & pHCFADBUpdated.ICD7 & _
"',[ICD8]='" & pHCFADBUpdated.ICD8 & _
"',[ICD9]='" & pHCFADBUpdated.ICD9 & _
"',[ICD10]='" & pHCFADBUpdated.ICD10 & _
"',[ICD11]='" & pHCFADBUpdated.ICD11 & _
"',[ICD12]='" & pHCFADBUpdated.ICD12 & _
"',[RFNU8]='" & pHCFADBUpdated.RFNU8 & _
"',[RFNU9B]='" & pHCFADBUpdated.RFNU9B & _
 "',[ServFacFacilityName]='" & pHCFADBUpdated.ServiceFacility.FacilityName & _
      "',[ServFacNPI]='" & pHCFADBUpdated.ServiceFacility.NPI & _
      "',[ServFacAddressLine1]='" & pHCFADBUpdated.ServiceFacility.AddressLine1 & _
      "',[ServFacAddressLine2]='" & pHCFADBUpdated.ServiceFacility.AddressLine2 & _
      "',[ServFacCity]='" & pHCFADBUpdated.ServiceFacility.City & _
      "',[ServFacState]='" & pHCFADBUpdated.ServiceFacility.State & _
      "',[ServFacZipCode]='" & pHCFADBUpdated.ServiceFacility.ZipCode & _
      "',[ServFacPhone]='" & pHCFADBUpdated.ServiceFacility.Phone & _
       "',[ServFacFacilityCode]='" & pHCFADBUpdated.ServiceFacility.FacilityCode & _
   "',[BPvdFirstName]='" & pHCFADBUpdated.BillingPvd.FirstName & _
        "',[BPvdMiddleName]='" & pHCFADBUpdated.BillingPvd.MiddleName & _
        "',[BPvdLastName]='" & pHCFADBUpdated.BillingPvd.LastName & _
        "',[BPvdAddressLine1]='" & pHCFADBUpdated.BillingPvd.AddressLine1 & _
        "',[BPvdAddressLine2]='" & pHCFADBUpdated.BillingPvd.AddressLine2 & _
        "',[BPvdCity]='" & pHCFADBUpdated.BillingPvd.City & _
        "',[BPvdState]='" & pHCFADBUpdated.BillingPvd.State & _
        "',[BPvdZipCode]='" & pHCFADBUpdated.BillingPvd.ZipCode & _
        "',[BPvdPhone1]='" & pHCFADBUpdated.BillingPvd.Phone1 & _
        "',[BPvdPhone2]='" & pHCFADBUpdated.BillingPvd.Phone2 & _
        "',[BPvdFax]='" & pHCFADBUpdated.BillingPvd.Fax & _
        "',[BPvdEmail]='" & pHCFADBUpdated.BillingPvd.Email & _
        "',[BPvdNPI]='" & pHCFADBUpdated.BillingPvd.NPI & _
        "',[BPvdTaxID]='" & pHCFADBUpdated.BillingPvd.TaxID & _
        "',[BPvdSSN]='" & pHCFADBUpdated.BillingPvd.SSN & _
        "',[RenPvdFirstName]='" & pHCFADBUpdated.RenderingProvider.FirstName & _
      "',[RenPvdMiddleName]='" & pHCFADBUpdated.RenderingProvider.MiddleName & _
      "',[RenPvdLastName]='" & pHCFADBUpdated.RenderingProvider.LastName & _
      "',[RenPvdDegree]='" & pHCFADBUpdated.RenderingProvider.Degree & _
"',[MedicadReSubCode]='" & pHCFADBUpdated.MedicadReSubCode & _
"',[MedicadReSubNo]='" & pHCFADBUpdated.MedicadReSubNo & _
"',[MainPIAuthorizationNumber]='" & pHCFADBUpdated.MainPatientInsurance.AuthorizationNumber & _
"',[PatientACNo]='" & pHCFADBUpdated.PatientACNo & _
"',[AcceptAssignment]='" & pHCFADBUpdated.AcceptAssignment & _
"',[TotalCharges]='" & pHCFADBUpdated.TotalCharges & _
"',[AmountPaid]='" & pHCFADBUpdated.AmountPaid & _
        "',[IsSend]='N" & _
        "',[IsBatch]='N" & _
"',[BalanceDue]='" & pHCFADBUpdated.BalanceDue & _
"',[BPvdSecIdQualifier]='" & pHCFADBUpdated.BPvdSecIdQualifier & _
        "',[BPvdSecIdValue]='" & pHCFADBUpdated.BPvdSecIdValue & _
        "',[ServFacSecIdQualifier]='" & pHCFADBUpdated.ServFacSecIdQualifier & _
"',[ServFacSecIdValue]='" & pHCFADBUpdated.ServFacSecIdValue & _
"',[ReservedField10d]='" & pHCFADBUpdated.ReservedField10d & _
"',[HCFAPreparedDate]='" & pHCFADBUpdated.HCFAPreparedDate & _
"',[SignOnFile]='" & pHCFADBUpdated.SignOnFile & _
"',[SignDate]='" & pHCFADBUpdated.SignDate & _
"',[AuthorizedPersonSign]='" & pHCFADBUpdated.AuthorizedPersonSign & _
"'  Where HCFAUpdated.HcfaId ='" & pHCFADBUpdated.HCFAID & "'"




        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand(lQuery1)

        Else
            Connection.ExecuteCommand(lQuery1)

        End If
        Return True
    

    End Function

    Public Function UpdateHcfaStatus(ByVal pPSBId As String) As Boolean
        Dim lQuery As String
        Try
            lQuery = "Update HCFAUpdated Set IsActive ='N' Where PatientSuperBillID =" & pPSBId
            If Connection.IsTransactionAlive() Then
                Connection.ExecuteTransactionCommand(lQuery)
            Else
                Connection.ExecuteCommand(lQuery)
            End If
            Return True
        Catch ex As Exception
            Throw ex
        End Try
    End Function
#End Region
End Class
