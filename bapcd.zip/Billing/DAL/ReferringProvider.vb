Imports Microsoft.VisualBasic
Imports System.xml

Public Class ReferringProviderDB

    Private mProviderID As Integer = 0
    Private mLastName As String = ""
    Private mMiddleName As String = ""
    Private mFirstName As String = ""
    Private mTitle As String = ""
    Private mAddressLine1 As String = ""
    Private mAddressLine2 As String = ""
    Private mCity As String = ""
    Private mState As String = ""
    Private mZipCode As String = ""
    Private mWorkPhone As String = ""
    Private mExt As String = ""
    Private mFax As String = ""
    Private mEmail As String = ""
    Private mNPI As String = ""
    Private mSpeciality As String = ""
    Private mFacility As Integer = 0
    Private mDegree As String = ""


    Public Sub New()
        'mPayerName = String.Empty
        'mPayerID = String.Empty
        'mState = String.Empty
        'mEnrollment = String.Empty
        'mPayerStatus = String.Empty
        'mType = String.Empty
        'mFavouriteInsuranceID = 0
    End Sub


#Region "Properties"


    Public Property ProviderID() As Integer
        Get
            Return mProviderID
        End Get
        Set(ByVal value As Integer)
            mProviderID = value
        End Set
    End Property

    Public Property LastName() As String
        Get
            Return mLastName
        End Get
        Set(ByVal value As String)
            mLastName = value
        End Set
    End Property

    Public Property MiddleName() As String
        Get
            Return mMiddleName
        End Get
        Set(ByVal value As String)
            mMiddleName = value
        End Set
    End Property
    Public Property FirstName() As String
        Get
            Return mFirstName
        End Get
        Set(ByVal value As String)
            mFirstName = value
        End Set
    End Property

    Public Property Title() As String
        Get
            Return mTitle
        End Get
        Set(ByVal value As String)
            mTitle = value
        End Set
    End Property

    Public Property AddressLine1() As String
        Get
            Return mAddressLine1
        End Get
        Set(ByVal value As String)
            mAddressLine1 = value
        End Set
    End Property

    Public Property AddressLine2() As String
        Get
            Return mAddressLine2
        End Get
        Set(ByVal value As String)
            mAddressLine2 = value
        End Set
    End Property

    Public Property City() As String
        Get
            Return mCity
        End Get
        Set(ByVal value As String)
            mCity = value
        End Set
    End Property


    Public Property State() As String
        Get
            Return mState
        End Get
        Set(ByVal value As String)
            mState = value
        End Set
    End Property

    Public Property ZipCode() As String
        Get
            Return mZipCode
        End Get
        Set(ByVal value As String)
            mZipCode = value
        End Set
    End Property


    Public Property WorkPhone() As String
        Get
            Return mWorkPhone
        End Get
        Set(ByVal value As String)
            mWorkPhone = value
        End Set
    End Property


    Public Property Ext() As String
        Get
            Return mExt
        End Get
        Set(ByVal value As String)
            mExt = value
        End Set
    End Property

    Public Property Fax() As String
        Get
            Return mFax
        End Get
        Set(ByVal value As String)
            mFax = value
        End Set
    End Property

    Public Property Email() As String
        Get
            Return mEmail
        End Get
        Set(ByVal value As String)
            mEmail = value
        End Set
    End Property

    Public Property NPI() As String
        Get
            Return mNPI
        End Get
        Set(ByVal value As String)
            mNPI = value
        End Set
    End Property

    Public Property Speciality() As String
        Get
            Return mSpeciality
        End Get
        Set(ByVal value As String)
            mSpeciality = value
        End Set
    End Property

    Public Property Facility() As Integer
        Get
            Return mFacility
        End Get
        Set(ByVal value As Integer)
            mFacility = value
        End Set
    End Property

    Public Property Degree() As String
        Get
            Return mDegree
        End Get
        Set(ByVal value As String)
            mDegree = value
        End Set
    End Property

#End Region

End Class

Public Class ReferringProvider

    Private mReferringProviderDB As ReferringProviderDB
    Private mConnection As Connection

#Region "Constructors"

    Public Sub New()
        mReferringProviderDB = New ReferringProviderDB
        mConnection = New Connection
    End Sub

    Public Sub New(ByVal pConnectionString As String)
        mReferringProviderDB = New ReferringProviderDB
        mConnection = New Connection(pConnectionString)
    End Sub

#End Region

#Region "Properties"

    Public Property ReferringProviderDB() As ReferringProviderDB
        Get
            Return mReferringProviderDB
        End Get
        Set(ByVal value As ReferringProviderDB)
            mReferringProviderDB = value
        End Set
    End Property

    Public Property Connection() As Connection
        Get
            Return mConnection
        End Get
        Set(ByVal value As Connection)
            mConnection = value
        End Set
    End Property

#End Region


    Public Function GetAllRecords(ByVal pCondition As String) As DataSet
        Dim lSpParameter(1) As SpParameter
        Dim lDataSet As DataSet = Nothing

        Try

            lSpParameter(0) = New SpParameter
            With lSpParameter(0)
                .ParameterName = "@Table"
                .ParameterType = ParameterType.Varchar
                .ParameterValue = "InsuranceCompany"
            End With

            lSpParameter(1) = New SpParameter
            With lSpParameter(1)
                .ParameterName = "@Cond"
                .ParameterType = ParameterType.Varchar
                .ParameterValue = pCondition
            End With

            lDataSet = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
            Return lDataSet

        Catch ex As Exception
            Return Nothing
        End Try
    End Function


    Public Function InsertReferringProvider() As String

        Dim lXmlDocument As New XmlDocument
        Dim lXmlElement As XmlElement

        lXmlDocument.LoadXml("<ReferringProviders></ReferringProviders>")
        lXmlElement = lXmlDocument.CreateElement("ReferringProvider")

        With lXmlElement
            .SetAttribute("FirstName", ReferringProviderDB.FirstName)
            .SetAttribute("MiddleName", ReferringProviderDB.MiddleName)
            .SetAttribute("LastName", ReferringProviderDB.LastName)
            .SetAttribute("AddressLine1", ReferringProviderDB.AddressLine1)
            .SetAttribute("AddressLine2", ReferringProviderDB.AddressLine2)
            .SetAttribute("City", ReferringProviderDB.City)
            .SetAttribute("State", ReferringProviderDB.State)
            .SetAttribute("ZipCode", ReferringProviderDB.ZipCode)
            .SetAttribute("WorkPhone", ReferringProviderDB.WorkPhone)
            .SetAttribute("Fax", ReferringProviderDB.Fax)
            .SetAttribute("Email", ReferringProviderDB.Email)
            .SetAttribute("NPI", ReferringProviderDB.NPI)
            .SetAttribute("Ext", ReferringProviderDB.Ext)
            .SetAttribute("Speciality", ReferringProviderDB.Speciality)
            .SetAttribute("FacilityID", ReferringProviderDB.Facility)
            .SetAttribute("IsDelete", "N")
            .SetAttribute("Degree", ReferringProviderDB.Degree)
        End With

        lXmlDocument.DocumentElement.AppendChild(lXmlElement.CloneNode(True))


        Connection.ExecuteCommand("InsertReferringProvider", lXmlDocument.DocumentElement.OuterXml.ToString)
        Return "Referring Provider Added Successfully"


        'Dim lQuery As String = String.Empty

        'Try
        '    lQuery = "Insert into ReferringProvider (FirstName,MiddleName,LastName,AddressLine1,AddressLine2, " _
        '    & "City,State,ZipCode,WorkPhone,Fax,Email,NPI,Ext,Speciality,FacilityID,IsDelete) " _
        '    & "Values (" _
        '    & "'" & ReferringProviderDB.FirstName & "','" & ReferringProviderDB.MiddleName & "','" & ReferringProviderDB.LastName & "'," _
        '    & "'" & ReferringProviderDB.AddressLine1 & "','" & ReferringProviderDB.AddressLine2 & "','" & ReferringProviderDB.City & "'," _
        '    & "'" & ReferringProviderDB.State & "','" & ReferringProviderDB.ZipCode & "','" & ReferringProviderDB.WorkPhone & "'," _
        '    & "'" & ReferringProviderDB.Fax & "','" & ReferringProviderDB.Email & "','" & ReferringProviderDB.NPI & "'," _
        '    & "'" & ReferringProviderDB.Ext & "','" & ReferringProviderDB.Speciality & "','" & ReferringProviderDB.Facility & "','N')"

        '    Connection.ExecuteCommand(lQuery)
        '    Return "Referring Provider Added Successfully"

        'Catch ex As Exception
        '    Return "Referring Provider Not Added - Please Try again"

        'End Try


    End Function


    Public Function GetAllRecords(ByRef pUser As User, ByVal pCondition As String)

        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()

        Try
            lSpParameter(0) = New SpParameter
            lSpParameter(0).ParameterName = "@Table"
            lSpParameter(0).ParameterType = ParameterType.Varchar
            lSpParameter(0).ParameterValue = "ReferringProvider"

            lSpParameter(1) = New SpParameter
            lSpParameter(1).ParameterName = "@Cond"
            lSpParameter(1).ParameterType = ParameterType.Varchar
            lSpParameter(1).ParameterValue = pCondition


            lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)

            Return lDs

        Catch ex As Exception
            Throw New Exception(ex.Message & " (Error in GetCurrentRxForDoctor)")
        End Try


    End Function

    Public Function GetReferringProvider(ByRef pUser As User, ByVal pCondition As String)

        Dim lSpParameter(0) As SpParameter
        Dim lDs As New DataSet()

        Try


            lSpParameter(0) = New SpParameter
            lSpParameter(0).ParameterName = "@Cond"
            lSpParameter(0).ParameterType = ParameterType.Varchar
            lSpParameter(0).ParameterValue = pCondition


            lDs = Connection.ExecuteQuery("GetReferringProvider", lSpParameter)

            Return lDs

        Catch ex As Exception
            Throw New Exception(ex.Message & " (Error in GetCurrentRxForDoctor)")
        End Try


    End Function

    Public Function UpdateReferringProvider() As Boolean

        Dim lQuery As String = String.Empty

        Try
            lQuery = "Update ReferringProvider " & _
            "set " & _
            "FirstName = '" & ReferringProviderDB.FirstName & "', " & _
            "MiddleName = '" & ReferringProviderDB.MiddleName & "', " & _
            "LastName = '" & ReferringProviderDB.LastName & "', " & _
            "AddressLine1 = '" & ReferringProviderDB.AddressLine1 & "', " & _
            "AddressLine2 = '" & ReferringProviderDB.AddressLine2 & "', " & _
            "City = '" & ReferringProviderDB.City & "', " & _
            "State = '" & ReferringProviderDB.State & "', " & _
            "ZipCode = '" & ReferringProviderDB.ZipCode & "', " & _
            "WorkPhone = '" & ReferringProviderDB.WorkPhone & "', " & _
            "Fax = '" & ReferringProviderDB.Fax & "', " & _
            "Email = '" & ReferringProviderDB.Email & "', " & _
            "NPI = '" & ReferringProviderDB.NPI & "', " & _
            "Ext = '" & ReferringProviderDB.Ext & "', " & _
            "Speciality = '" & ReferringProviderDB.Speciality & "', " & _
            "FacilityID = " & ReferringProviderDB.Facility & ", " & _
            "Degree = '" & ReferringProviderDB.Degree & "' " & _
            " where " & _
            "ProviderID = " & ReferringProviderDB.ProviderID


            Connection.ExecuteCommand(lQuery)
            Return True


        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Function DeleteReferringProvider() As Boolean

        Dim lQuery As String = String.Empty

        Try
            lQuery = "Update ReferringProvider Set IsDelete='Y' where ProviderID = " & ReferringProviderDB.ProviderID


            Connection.ExecuteCommand(lQuery)
            Return True

        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Function GetRecordByID(ByVal lDT As DataTable) As Boolean

        With lDT
            If .Rows.Count > 0 Then
                Me.ReferringProviderDB.ProviderID = .Rows(0)("ProviderID")
                Me.ReferringProviderDB.FirstName = .Rows(0)("FirstName")
                Me.ReferringProviderDB.MiddleName = .Rows(0)("MiddleName")
                Me.ReferringProviderDB.LastName = .Rows(0)("LastName")
                Me.ReferringProviderDB.Title = .Rows(0)("Title")
                Me.ReferringProviderDB.AddressLine1 = .Rows(0)("AddressLine1")
                Me.ReferringProviderDB.AddressLine2 = .Rows(0)("AddressLine2")
                Me.ReferringProviderDB.City = .Rows(0)("City")
                Me.ReferringProviderDB.State = .Rows(0)("State")
                Me.ReferringProviderDB.ZipCode = .Rows(0)("ZipCode")
                Me.ReferringProviderDB.WorkPhone = .Rows(0)("WorkPhone")
                Me.ReferringProviderDB.Ext = .Rows(0)("Ext")
                Me.ReferringProviderDB.Fax = .Rows(0)("Fax")
                Me.ReferringProviderDB.Email = .Rows(0)("Email")
                Me.ReferringProviderDB.NPI = .Rows(0)("NPI")
                Me.ReferringProviderDB.Speciality = .Rows(0)("Speciality")
                Me.ReferringProviderDB.Facility = .Rows(0)("FacilityID")

                Return True
            End If
        End With

        Return False

    End Function

    Public Function GetRefferingProviderForCombo() As DataSet
        Dim lDs As New DataSet
        Dim lQuery As String = ""

        Try
            lQuery = "Select '[Select]' as FullName,'' as ID from ReferringProvider union Select Replace(FirstName + ' ' + MiddleName + ' ' + LastName + ' ' + Degree,'  ',' ')  as FullName,NPI as ID from ReferringProvider where IsDelete='N' order by FullName"


            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If
            Return lDs

        Catch ex As Exception
            Throw New Exception(ex.Message + " : Billing\DAL\RefferingProvider.GetRefferingProviderForCombo() As DataSet ")
        End Try
    End Function

    Public Function CheckNpiExist(ByVal pNPI As String) As DataSet
        Dim lDs As New DataSet
        Dim lQuery As String = ""

        Try
            lQuery = "select * from ReferringProvider where NPI='" & pNPI & "' and IsDelete='N'"

            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If
            Return lDs
        Catch ex As Exception
            Throw New Exception(ex.Message + " : Billing\DAL\RefferingProvider.CheckNpiExist() As DataSet ")
        End Try
    End Function

    Public Function CheckNpiExistEdit(ByVal pNPI As String, ByVal pID As String) As DataSet
        Dim lDs As New DataSet
        Dim lQuery As String = ""

        Try
            lQuery = "select * from ReferringProvider where NPI='" & pNPI & "' and ProviderID <> '" & pID & "' and IsDelete='N'"

            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If
            Return lDs
        Catch ex As Exception
            Throw New Exception(ex.Message + " : Billing\DAL\RefferingProvider.CheckNpiExist() As DataSet ")
        End Try
    End Function
    Public Function GetReferringProviderById() As Boolean
        Dim lQuery As String
        Try
            Dim lDs As New DataSet()
            lQuery = "select * FROM ReferringProvider where NPI='" & Me.ReferringProviderDB.NPI & "' "

            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If
            With lDs.Tables(0)
                If .Rows.Count > 0 Then
                    ReferringProviderDB.ProviderID = .Rows(0)("ProviderID")
                    ReferringProviderDB.FirstName = .Rows(0)("FirstName")
                    ReferringProviderDB.MiddleName = .Rows(0)("MiddleName")
                    ReferringProviderDB.LastName = .Rows(0)("LastName")
                    ReferringProviderDB.AddressLine1 = .Rows(0)("AddressLine1")
                    ReferringProviderDB.AddressLine2 = .Rows(0)("AddressLine2")
                    ReferringProviderDB.City = .Rows(0)("City")
                    ReferringProviderDB.State = .Rows(0)("State")
                    ReferringProviderDB.ZipCode = .Rows(0)("ZipCode")
                    ReferringProviderDB.Degree = .Rows(0)("Degree")
                    ReferringProviderDB.Ext = .Rows(0)("Ext")
                    ReferringProviderDB.Fax = .Rows(0)("Fax")
                    ReferringProviderDB.Email = .Rows(0)("Email")
                    ReferringProviderDB.NPI = .Rows(0)("NPI")
                    ReferringProviderDB.WorkPhone = .Rows(0)("WorkPhone")
                    ReferringProviderDB.Facility = .Rows(0)("FacilityID")
                    ReferringProviderDB.Speciality = .Rows(0)("Speciality")
                    ReferringProviderDB.Title = .Rows(0)("Title")
                End If
                Return True
            End With

        Catch ex As Exception
            Return False
        End Try
    End Function



    Public Function GetSpeciality() As DataSet
        Dim lDs As New DataSet
        Dim lQuery As String = ""

        Try
            lQuery = "select SpecializationId='Select One',Specialization='', Code='', Classification='',ID='1' union all Select (Case Specialization when '' then (Classification + '-' +  Code) else (Specialization + '-' +  Code) end) as SpecializationId ,Specialization, Code, Classification,ID='2' from ProviderTaxonomyCodes order by ID,SpecializationId asc "


            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If
            Return lDs

        Catch ex As Exception
            Throw New Exception(ex.Message + " : Billing\DAL\RefferingProvider.GetSpeciality() As DataSet ")
        End Try
    End Function
End Class



