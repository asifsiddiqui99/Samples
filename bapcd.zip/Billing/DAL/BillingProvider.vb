Imports Microsoft.VisualBasic

Public Class BillingProviderDB

#Region "Fields"
    Private mBillingProviderId As String = ""
    Private mFirstName As String = ""
    Private mMiddleName As String = ""
    Private mLastName As String = ""
    Private mAddressLine1 As String = ""
    Private mAddressLine2 As String = ""
    Private mCity As String = ""
    Private mState As String = ""
    Private mZipCode As String = ""
    Private mPhone1 As String = ""
    Private mPhone2 As String = ""
    Private mFax As String = ""
    Private mEmail As String = ""
    Private mNPI As String = ""
    Private mTaxID As String = ""
    Private mSSN As String = ""
    Private mProviderID As String = ""
    Private mProviderNPI As String = ""
    Private mEntryType As String = ""
    Private mEntryInsuranceTypeCode As String = ""
    Private mEntryInsuranceTypeValue As String = ""
#End Region

#Region "Properties"
    Public Property BillingProviderId() As String
        Get
            Return mBillingProviderId
        End Get
        Set(ByVal value As String)
            mBillingProviderId = value
        End Set
    End Property
    Public Property FirstName() As String
        Get
            Return mFirstName
        End Get
        Set(ByVal value As String)
            mFirstName = value
        End Set
    End Property
    Public Property MiddleName() As String
        Get
            Return mMiddleName
        End Get
        Set(ByVal value As String)
            mMiddleName = value
        End Set
    End Property
    Public Property LastName() As String
        Get
            Return mLastName
        End Get
        Set(ByVal value As String)
            mLastName = value
        End Set
    End Property
    Public Property AddressLine1() As String
        Get
            Return mAddressLine1
        End Get
        Set(ByVal value As String)
            mAddressLine1 = value
        End Set
    End Property
    Public Property AddressLine2() As String
        Get
            Return mAddressLine2
        End Get
        Set(ByVal value As String)
            mAddressLine2 = value
        End Set
    End Property
    Public Property City() As String
        Get
            Return mCity
        End Get
        Set(ByVal value As String)
            mCity = value
        End Set
    End Property
    Public Property State() As String
        Get
            Return mState
        End Get
        Set(ByVal value As String)
            mState = value
        End Set
    End Property
    Public Property ZipCode() As String
        Get
            Return mZipCode
        End Get
        Set(ByVal value As String)
            mZipCode = value
        End Set
    End Property
    Public Property Phone1() As String
        Get
            Return mPhone1
        End Get
        Set(ByVal value As String)
            mPhone1 = value
        End Set
    End Property
    Public Property Phone2() As String
        Get
            Return mPhone2
        End Get
        Set(ByVal value As String)
            mPhone2 = value
        End Set
    End Property
    Public Property Fax() As String
        Get
            Return mFax
        End Get
        Set(ByVal value As String)
            mFax = value
        End Set
    End Property
    Public Property Email() As String
        Get
            Return mEmail
        End Get
        Set(ByVal value As String)
            mEmail = value
        End Set
    End Property
    Public Property NPI() As String
        Get
            Return mNPI
        End Get
        Set(ByVal value As String)
            mNPI = value
        End Set
    End Property
    Public Property TaxID() As String
        Get
            Return mTaxID
        End Get
        Set(ByVal value As String)
            mTaxID = value
        End Set
    End Property
    Public Property SSN() As String
        Get
            Return mSSN
        End Get
        Set(ByVal value As String)
            mSSN = value
        End Set
    End Property
    Public Property ProviderID() As String
        Get
            Return mProviderID
        End Get
        Set(ByVal value As String)
            mProviderID = value
        End Set
    End Property
    Public Property ProviderNPI() As String
        Get
            Return mProviderNPI
        End Get
        Set(ByVal value As String)
            mProviderNPI = value
        End Set
    End Property
    Public Property EntryType() As String
        Get
            Return mEntryType
        End Get
        Set(ByVal value As String)
            mEntryType = value
        End Set
    End Property
    Public Property EntryInsuranceTypeCode() As String
        Get
            Return mEntryInsuranceTypeCode
        End Get
        Set(ByVal value As String)
            mEntryInsuranceTypeCode = value
        End Set
    End Property
    Public Property EntryInsuranceTypeValue() As String
        Get
            Return mEntryInsuranceTypeValue
        End Get
        Set(ByVal value As String)
            mEntryInsuranceTypeValue = value
        End Set
    End Property
#End Region

End Class

Public Class BillingProvider

#Region "Fields"
    Private mConnection As Connection
    Private mConnectionString As String
    Private mBillingProvider As New BillingProviderDB
#End Region

#Region "Property"
    Public Property BillingProvider() As BillingProviderDB
        Get
            Return mBillingProvider
        End Get
        Set(ByVal value As BillingProviderDB)
            mBillingProvider = value
        End Set
    End Property
    Public ReadOnly Property Connection() As ElixirLibrary.Connection
        Get
            Return mConnection
        End Get
    End Property
    Public ReadOnly Property ConnectionString() As String
        Get
            Return mConnectionString
        End Get
    End Property
#End Region

#Region "Constructor"
    Public Sub New(ByVal pConnectionString As String)
        If pConnectionString = "" Then
            Throw New ArgumentException("ConnectionString can not be empty")
        End If
        mConnectionString = pConnectionString
        mConnection = New Connection(mConnectionString)

    End Sub
    Public Sub New(ByVal pConnection As Connection)
        If pConnection Is Nothing Then
            Throw New ArgumentException("Connection can not be empty")
        End If
        mConnection = pConnection
    End Sub
#End Region

#Region "Methods"
    Public Function GetRecordByID() As Boolean
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()
        Try
            lSpParameter(0).ParameterName = "@Table"
            lSpParameter(0).ParameterType = ParameterType.Varchar
            lSpParameter(0).ParameterValue = "BillingProvider"

            lSpParameter(1).ParameterName = "@Cond"
            lSpParameter(1).ParameterType = ParameterType.Varchar
            lSpParameter(1).ParameterValue = ""

            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery("SelectAllRecords", lSpParameter)
            Else
                lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
            End If

            With lDs.Tables(0)
                If .Rows.Count > 0 Then
                    BillingProvider.BillingProviderId = .Rows(0)("BillingProviderId")
                    BillingProvider.FirstName = .Rows(0)("FirstName")
                    BillingProvider.MiddleName = .Rows(0)("MiddleName")
                    BillingProvider.LastName = .Rows(0)("LastName")
                    BillingProvider.AddressLine1 = .Rows(0)("AddressLine1")
                    BillingProvider.AddressLine2 = .Rows(0)("AddressLine2")
                    BillingProvider.City = .Rows(0)("City")
                    BillingProvider.State = .Rows(0)("State")
                    BillingProvider.ZipCode = .Rows(0)("ZipCode")
                    BillingProvider.Phone1 = .Rows(0)("Phone1")
                    BillingProvider.Phone2 = .Rows(0)("Phone2")
                    BillingProvider.Fax = .Rows(0)("Fax")
                    BillingProvider.Email = .Rows(0)("Email")
                    BillingProvider.NPI = .Rows(0)("NPI")
                    BillingProvider.TaxID = .Rows(0)("TaxID")
                    BillingProvider.SSN = .Rows(0)("SSN")
                    BillingProvider.ProviderID = .Rows(0)("ProviderID")
                    BillingProvider.ProviderNPI = .Rows(0)("ProviderNPI")
                    BillingProvider.EntryType = .Rows(0)("EntryType")
                    BillingProvider.EntryInsuranceTypeCode = .Rows(0)("EntryInsuranceTypeCode")
                    BillingProvider.EntryInsuranceTypeValue = .Rows(0)("EntryInsuranceTypeValue")
                End If
            End With
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Function GetBillingProvider(ByVal pCon As String) As Boolean
        Dim lQuery As String
        Try
            Dim lDs As New DataSet()
            lQuery = "select * FROM BillingProvider where 1=1 and " & pCon
            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If
            With lDs.Tables(0)
                If .Rows.Count > 0 Then
                    BillingProvider.BillingProviderId = .Rows(0)("BillingProviderId")
                    BillingProvider.FirstName = .Rows(0)("FirstName")
                    BillingProvider.MiddleName = .Rows(0)("MiddleName")
                    BillingProvider.LastName = .Rows(0)("LastName")
                    BillingProvider.AddressLine1 = .Rows(0)("AddressLine1")
                    BillingProvider.AddressLine2 = .Rows(0)("AddressLine2")
                    BillingProvider.City = .Rows(0)("City")
                    BillingProvider.State = .Rows(0)("State")
                    BillingProvider.ZipCode = .Rows(0)("ZipCode")
                    BillingProvider.Phone1 = .Rows(0)("Phone1")
                    BillingProvider.Phone2 = .Rows(0)("Phone2")
                    BillingProvider.Fax = .Rows(0)("Fax")
                    BillingProvider.Email = .Rows(0)("Email")
                    BillingProvider.NPI = .Rows(0)("NPI")
                    BillingProvider.TaxID = .Rows(0)("TaxID")
                    BillingProvider.SSN = .Rows(0)("SSN")
                    BillingProvider.ProviderID = .Rows(0)("ProviderID")
                    BillingProvider.ProviderNPI = .Rows(0)("ProviderNPI")
                    BillingProvider.EntryType = .Rows(0)("EntryType")
                    BillingProvider.EntryInsuranceTypeCode = .Rows(0)("EntryInsuranceTypeCode")
                    BillingProvider.EntryInsuranceTypeValue = .Rows(0)("EntryInsuranceTypeValue")
                End If
                Return True
            End With

        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Function GetBillingProviderById() As Boolean
        Dim lQuery As String
        Try
            Dim lDs As New DataSet()
            lQuery = "select Top 1 * FROM BillingProvider where (ProviderId=" & BillingProvider.ProviderID & " and UPPER([EntryInsuranceTypeValue])='" & BillingProvider.EntryInsuranceTypeValue.ToUpper & "') or ProviderId=0 order by ProviderId desc"

            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If
            With lDs.Tables(0)
                If .Rows.Count > 0 Then
                    BillingProvider.BillingProviderId = .Rows(0)("BillingProviderId")
                    BillingProvider.FirstName = .Rows(0)("FirstName")
                    BillingProvider.MiddleName = .Rows(0)("MiddleName")
                    BillingProvider.LastName = .Rows(0)("LastName")
                    BillingProvider.AddressLine1 = .Rows(0)("AddressLine1")
                    BillingProvider.AddressLine2 = .Rows(0)("AddressLine2")
                    BillingProvider.City = .Rows(0)("City")
                    BillingProvider.State = .Rows(0)("State")
                    BillingProvider.ZipCode = .Rows(0)("ZipCode")
                    BillingProvider.Phone1 = .Rows(0)("Phone1")
                    BillingProvider.Phone2 = .Rows(0)("Phone2")
                    BillingProvider.Fax = .Rows(0)("Fax")
                    BillingProvider.Email = .Rows(0)("Email")
                    BillingProvider.NPI = .Rows(0)("NPI")
                    BillingProvider.TaxID = .Rows(0)("TaxID")
                    BillingProvider.SSN = .Rows(0)("SSN")
                    BillingProvider.ProviderID = .Rows(0)("ProviderID")
                    BillingProvider.ProviderNPI = .Rows(0)("ProviderNPI")
                    BillingProvider.EntryType = .Rows(0)("EntryType")
                    BillingProvider.EntryInsuranceTypeCode = .Rows(0)("EntryInsuranceTypeCode")
                    BillingProvider.EntryInsuranceTypeValue = .Rows(0)("EntryInsuranceTypeValue")
                End If
                Return True
            End With

        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Function GetBillingProviderByBillingProviderID() As Boolean
        Dim lQuery As String
        Try
            Dim lDs As New DataSet()
            lQuery = "select Top 1 * FROM BillingProvider where billingproviderid = " & BillingProvider.BillingProviderId

            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If
            With lDs.Tables(0)
                If .Rows.Count > 0 Then
                    BillingProvider.BillingProviderId = .Rows(0)("BillingProviderId")
                    BillingProvider.FirstName = .Rows(0)("FirstName")
                    BillingProvider.MiddleName = .Rows(0)("MiddleName")
                    BillingProvider.LastName = .Rows(0)("LastName")
                    BillingProvider.AddressLine1 = .Rows(0)("AddressLine1")
                    BillingProvider.AddressLine2 = .Rows(0)("AddressLine2")
                    BillingProvider.City = .Rows(0)("City")
                    BillingProvider.State = .Rows(0)("State")
                    BillingProvider.ZipCode = .Rows(0)("ZipCode")
                    BillingProvider.Phone1 = .Rows(0)("Phone1")
                    BillingProvider.Phone2 = .Rows(0)("Phone2")
                    BillingProvider.Fax = .Rows(0)("Fax")
                    BillingProvider.Email = .Rows(0)("Email")
                    BillingProvider.NPI = .Rows(0)("NPI")
                    BillingProvider.TaxID = .Rows(0)("TaxID")
                    BillingProvider.SSN = .Rows(0)("SSN")
                    BillingProvider.ProviderID = .Rows(0)("ProviderID")
                    BillingProvider.ProviderNPI = .Rows(0)("ProviderNPI")
                    BillingProvider.EntryType = .Rows(0)("EntryType")
                    BillingProvider.EntryInsuranceTypeCode = .Rows(0)("EntryInsuranceTypeCode")
                    BillingProvider.EntryInsuranceTypeValue = .Rows(0)("EntryInsuranceTypeValue")
                End If
                Return True
            End With

        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Function UpdateRecord() As Boolean
        Dim lQuery As String
        Try
            With Me.BillingProvider

                lQuery = "UPDATE BillingProvider " _
                                  & "SET FirstName = '" & .FirstName & "'" _
                                  & ",MiddleName = '" & .MiddleName & "'" _
                                  & ",LastName = '" & .LastName & "'" _
                                  & ",AddressLine1 = '" & .AddressLine1 & "'" _
                                  & ",AddressLine2 = '" & .AddressLine2 & "'" _
                                  & ",City = '" & .City & "'" _
                                  & ",State= '" & .State & "'" _
                                  & ",ZipCode = '" & .ZipCode & "'" _
                                  & ",Phone1 = '" & .Phone1 & "'" _
                                  & ",Phone2 = '" & .Phone2 & "'" _
                                  & ",Fax = '" & .Fax & "'" _
                                  & ",Email = '" & .Email & "'" _
                                  & ",NPI = '" & .NPI & "'" _
                                  & ",TaxID = '" & .TaxID & "'" _
                                  & ",SSN= '" & .SSN & "'" _
                                  & ",ProviderID = '" & .ProviderID & "'" _
                                  & ",ProviderNPI = '" & .ProviderNPI & "'" _
                                  & ",EntryType = '" & .EntryType & "'" _
                                  & ",EntryInsuranceTypeCode = '" & .EntryInsuranceTypeCode & "'" _
                                  & ",EntryInsuranceTypeValue ='" & .EntryInsuranceTypeValue & "'" _
                                  & "WHERE BillingProviderId=" & .BillingProviderId


            End With

                If Connection.IsTransactionAlive() Then
                    Connection.ExecuteTransactionCommand(lQuery)
                Else
                    Connection.ExecuteCommand(lQuery)
                End If
            Return True
        Catch ex As Exception
            Return False
            Throw New Exception(ex.Message + " : BILLING\DAL\BillingProvider.UpdateRecord() ")
        End Try

    End Function

    Public Function InsertRecord() As Boolean
        Dim lXmlDocument As New XmlDocument
        Dim lXmlElement As XmlElement
        Try
            lXmlDocument.LoadXml("<BillingProviders></BillingProviders>")
            lXmlElement = lXmlDocument.CreateElement("BillingProvider")

            With lXmlElement
                .SetAttribute(("FirstName"), BillingProvider.FirstName)
                .SetAttribute(("MiddleName"), BillingProvider.MiddleName)
                .SetAttribute(("LastName"), BillingProvider.LastName)
                .SetAttribute(("AddressLine1"), BillingProvider.AddressLine1)
                .SetAttribute(("AddressLine2"), BillingProvider.AddressLine2)
                .SetAttribute(("City"), BillingProvider.City)
                .SetAttribute(("State"), BillingProvider.State)
                .SetAttribute(("ZipCode"), BillingProvider.ZipCode)
                .SetAttribute(("Phone1"), BillingProvider.Phone1)
                .SetAttribute(("Phone2"), BillingProvider.Phone2)
                .SetAttribute(("Fax"), BillingProvider.Fax)
                .SetAttribute(("Email"), BillingProvider.Email)
                .SetAttribute(("NPI"), BillingProvider.NPI)
                .SetAttribute(("TaxID"), BillingProvider.TaxID)
                .SetAttribute(("SSN"), BillingProvider.SSN)
                .SetAttribute(("ProviderID"), BillingProvider.ProviderID)
                .SetAttribute(("ProviderNPI"), BillingProvider.ProviderNPI)
                .SetAttribute(("EntryType"), BillingProvider.EntryType)
                .SetAttribute(("EntryInsuranceTypeCode"), BillingProvider.EntryInsuranceTypeCode)
                .SetAttribute(("EntryInsuranceTypeValue"), BillingProvider.EntryInsuranceTypeValue)
            End With

            lXmlDocument.DocumentElement.AppendChild(lXmlElement.CloneNode(True))

            If Connection.IsTransactionAlive() Then
                Connection.ExecuteTransactionCommand("InsertBillingProvider", lXmlDocument.InnerXml.ToString)
            Else
                Connection.ExecuteCommand("InsertBillingProvider", lXmlDocument.InnerXml.ToString)
            End If
            Return True
        Catch ex As Exception
            Return False
            Throw New Exception(ex.Message + " : BILLING\DAL\BillingProvider.InsertRecord() ")
        End Try
    End Function
    
    Public Function LoadAllProvider() As DataSet
        Dim lQuery As String
        Try
            Dim lDs As New DataSet()
            lQuery = "select * from BillingProvider where EntryTYpe='G' select convert(varchar,EmployeeID) + '|' + NPI as EmployeeID,FirstName + ' ' + LastName + ' ' + MiddleName as [Name] from Employee where IsNull(IsProvider,'N') = 'Y' "
            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If
            Return lDs
        Catch ex As Exception
            Return Nothing
        End Try
    End Function
    Public Function LoadAllProvider(ByVal pCond As String) As DataSet
        Dim lQuery As String
        Try
            Dim lDs As New DataSet()
            lQuery = pCond & "select EmployeeID,FirstName + ' ' + LastName + ' ' + MiddleName as [Name] from Employee where IsNull(IsProvider,'N') = 'Y'  "
            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If
            Return lDs
        Catch ex As Exception
            Return Nothing
        End Try
    End Function
    Public Function AutocompeteQuery(ByVal pCond As String) As DataSet
        Dim lQuery As String
        Dim lDs As New DataSet()
        Try
            lQuery = "select EmployeeID,FirstName + ' ' + LastName + ' ' + MiddleName as [Name] from Employee   where IsNull(IsProvider,'N') = 'Y'   and FirstName  like '" & pCond & "%' "
            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If
            Return lDs
        Catch ex As Exception

        End Try
        Return Nothing
    End Function
    Public Sub InsertRecordALL(ByVal pXmlBillingProviderALL As String)

        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand("InsertBillingProvider", pXmlBillingProviderALL)
        Else
            Connection.ExecuteCommand("InsertBillingProvider", pXmlBillingProviderALL)
        End If

    End Sub


    Public Function CheckRecord(ByVal pProviderId As String, ByVal pInsuranceTypeID As String) As DataSet
        Dim lQuery As String
        Try
            Dim lDs As New DataSet()
            If (pProviderId.Contains("|")) Then
                pProviderId = pProviderId.Split("|")(0)
            End If

            If (pInsuranceTypeID = "0") Then
                lQuery = "select distinct EntryInsuranceTypeCode from BillingProvider where ProviderID='" & pProviderId & "'"
            Else
                lQuery = "select distinct EntryInsuranceTypeCode from BillingProvider where ProviderID='" & pProviderId & "' and EntryInsuranceTypeCode='" & pInsuranceTypeID & "'"
            End If
            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If
            Return lDs
        Catch ex As Exception
            Return Nothing
        End Try
    End Function
    Public Function DeleteBillingProviedr(ByVal pProviderId As String, ByVal pInsuranceTypeIDs As String) As Boolean

        Dim lQuery As String = String.Empty
        Try
            If (pProviderId.Contains("|")) Then
                pProviderId = pProviderId.Split("|")(0)
            End If
            If (pInsuranceTypeIDs.Contains("|")) Then
                pInsuranceTypeIDs = pInsuranceTypeIDs.Replace("|", ",")
            End If
            lQuery = "DELETE FROM BillingProvider WHERE ProviderID= '" & pProviderId & "' and EntryInsuranceTypeCode in (" & pInsuranceTypeIDs & ")"
            Connection.ExecuteCommand(lQuery)
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Function SearchBillingProvider(ByVal pCond As String) As DataSet
        Dim lQuery As String
        Dim lDs As New DataSet()
        Try
            lQuery = "SELECT Employee.FirstName + ' ' + Employee.LastName as DoctorName,BillingProviderId,BillingProvider.FirstName + ' ' + BillingProvider.MiddleName + ' ' + BillingProvider.LastName as [Name],BillingProvider.AddressLine1,BillingProvider.AddressLine2,BillingProvider.City,BillingProvider.State,BillingProvider.ZipCode,BillingProvider.Phone1,BillingProvider.Phone2,BillingProvider.Fax,BillingProvider.Email,BillingProvider.NPI,BillingProvider.TaxID,BillingProvider.SSN,BillingProvider.ProviderID,BillingProvider.ProviderNPI,EntryType=(Case BillingProvider.EntryType when 'G' then 'General' else 'Specific' end),BillingProvider.EntryInsuranceTypeCode,BillingProvider.EntryInsuranceTypeValue FROM BillingProvider,Employee   where 1=1 and BillingProvider.ProviderID *=Employee.EmployeeID  " & pCond
            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If
            Return lDs
        Catch ex As Exception
            Return lDs
        End Try
    End Function

    Public Function LoadBillingProvider() As DataSet
        Dim lQuery As String
        Dim lDs As New DataSet()
        Try
            lQuery = "SELECT BillingProviderId as ID,FirstName + ' ' + MiddleName + ' ' + LastName as [Name] FROM BillingProvider  where 1=1 "
            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If
            Return lDs
        Catch ex As Exception
            Return lDs
        End Try
    End Function

    Public Function GetBillingProvider(ByVal pProviderId As String, ByVal pFavInsuranceId As String) As DataSet
        Dim lQuery As String
        Dim lDs As New DataSet()
        Try
            lQuery = "select BillingProviderId  from billingprovider where ProviderId='" & pProviderId & "' and Upper(EntryInsuranceTypeValue) = (SELECT InsuranceType FROM FavouriteInsurance where FavouriteInsuranceID='" & pFavInsuranceId & "') " _
           & " union all select BillingProviderId  from billingprovider where ProviderId='" & pProviderId & "' and Upper(EntryInsuranceTypeValue) ='ALL'" _
           & " union all select BillingProviderId  from billingprovider where Upper(EntryType) ='G' "

            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If
            Return lDs
        Catch ex As Exception
            Return lDs
        End Try
    End Function
#End Region

End Class
