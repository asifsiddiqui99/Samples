Imports Microsoft.VisualBasic
Public Class ClaimBatchHdrDB

#Region "Fields"

    Dim mBatchID As String = ""
    Dim mBatchDisplayID As String = ""
    Dim mCreationDate As String = ""
    Dim mSendDate As String = ""
    Dim mStatus As String = ""
    Dim mCreateByUserID As String = ""
    Dim mBatchEDI As String = ""

#End Region

#Region "Property"

    Public Property BatchID() As String
        Get
            Return mBatchID
        End Get
        Set(ByVal value As String)
            mBatchID = value
        End Set
    End Property

    Public Property BatchDisplayID() As String
        Get
            Return mBatchDisplayID
        End Get
        Set(ByVal value As String)
            mBatchDisplayID = value
        End Set
    End Property

    Public Property CreationDate() As String
        Get
            Return mCreationDate
        End Get
        Set(ByVal value As String)
            mCreationDate = value
        End Set
    End Property

    Public Property SendDate() As String
        Get
            Return mSendDate
        End Get
        Set(ByVal value As String)
            mSendDate = value
        End Set
    End Property

    Public Property Status() As String
        Get
            Return mStatus
        End Get
        Set(ByVal value As String)
            mStatus = value
        End Set
    End Property

    Public Property CreateByUserID() As String
        Get
            Return mCreateByUserID
        End Get
        Set(ByVal value As String)
            mCreateByUserID = value
        End Set
    End Property

    Public Property BatchEDI() As String
        Get
            Return mBatchEDI
        End Get
        Set(ByVal value As String)
            mBatchEDI = value
        End Set
    End Property

#End Region

End Class

Public Class ClaimBatchHdr
    Implements IDetail
#Region "Fields"

    Private mConnection As Connection
    Private mConnectionString As String
    Private mClaimBatchHdrDB As New ClaimBatchHdrDB

#End Region

#Region "Property"

    Public Property ClaimBatchHdr() As ClaimBatchHdrDB
        Get
            Return mClaimBatchHdrDB
        End Get
        Set(ByVal value As ClaimBatchHdrDB)
            mClaimBatchHdrDB = value
        End Set
    End Property

    Public ReadOnly Property Connection() As ElixirLibrary.Connection Implements IDetail.Connection
        Get
            Return mConnection
        End Get
    End Property

    Public ReadOnly Property ConnectionString() As String Implements IDetail.ConnectionString
        Get
            Return mConnectionString
        End Get
    End Property

#End Region

#Region "Constructor"
    Public Sub New(ByVal pConnectionString As String)
        If pConnectionString = "" Then
            Throw New ArgumentException("ConnectionString can not be empty")
        End If
        mConnectionString = pConnectionString
        mConnection = New Connection(mConnectionString)

    End Sub
    Public Sub New(ByVal pConnection As Connection)
        If pConnection Is Nothing Then
            Throw New ArgumentException("Connection can not be empty")
        End If
        mConnection = pConnection
    End Sub

#End Region

#Region "Methods"
    Public Sub DeleteRecord(ByVal pCondition As String) Implements IDetail.DeleteRecord

    End Sub
    Public Sub DeleteRecordByID() Implements IDetail.DeleteRecordByID

    End Sub
    Public Function GetAllRecords() As System.Data.DataSet Implements IDetail.GetAllRecords
        Dim lds As New DataSet
        Return lds
    End Function
    Public Function GetAllRecords(ByVal pCondition As String) As System.Data.DataSet Implements IDetail.GetAllRecords
        Dim lds As New DataSet
        Return lds
    End Function
    Public Function GetRecordByID() As Boolean Implements IDetail.GetRecordByID
        Return True
    End Function
    Public Sub InsertRecord() Implements IDetail.InsertRecord
        Dim lXmlDocument As New XmlDocument
        Dim lXmlElement As XmlElement

        lXmlDocument.LoadXml("<ClaimBatchHdrs></ClaimBatchHdrs>")
        lXmlElement = lXmlDocument.CreateElement("ClaimBatchHdr")

        With lXmlElement

            .SetAttribute("BatchID", ClaimBatchHdr.BatchID)
            .SetAttribute("BatchDisplayID", ClaimBatchHdr.BatchDisplayID)
            .SetAttribute("CreationDate", ClaimBatchHdr.CreationDate)
            '.SetAttribute("SendDate", ClaimBatchHdr.SendDate)
            .SetAttribute("Status", ClaimBatchHdr.Status)
            .SetAttribute("CreateByUserID", ClaimBatchHdr.CreateByUserID)
            .SetAttribute("BatchEDI", ClaimBatchHdr.BatchEDI)

        End With

        lXmlDocument.DocumentElement.AppendChild(lXmlElement.CloneNode(True))

        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand("InsertClaimBatchHdr", lXmlDocument.InnerXml.ToString)
        Else
            Connection.ExecuteCommand("InsertClaimBatchHdr", lXmlDocument.InnerXml.ToString)
        End If

    End Sub
    Public Sub UpdateRecord() Implements IDetail.UpdateRecord

    End Sub
    Public Sub UpdateRecord(ByVal pCondition As String) Implements IDetail.UpdateRecord

    End Sub
    Public Function GetSendDate(ByVal pHCFAIDID As String) As String
        Dim lSendDate As String = ""
        Dim lDs As DataSet = Nothing
        Dim lQuery As String = String.Empty

        Try

            lQuery = "select CBHdr.SendDate from ClaimBatchHdr CBHdr, ClaimBatchDtl CBDtl where CBDtl.BatchID=CBHdr.BatchID and CBHdr.SendDate<>'' and CBDtl.ClaimId=" & pHCFAIDID


            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If
            If lDs.Tables(0).Rows.Count > 0 Then
                lSendDate = lDs.Tables(0).Rows(0).Item("SendDate").ToString
                Return lSendDate
            Else
                Return ""
            End If


        Catch ex As Exception
            Return Nothing
        End Try



    End Function
#End Region

End Class
