Imports Microsoft.VisualBasic
Imports System.Xml

Public Class FacilityDB
    Private mFacilityID As String = "0"
    Private mFacilityName As String = ""
    Private mNPI As String = ""
    Private mAddressLine1 As String = ""
    Private mAddressLine2 As String = ""
    Private mCity As String = ""
    Private mState As String = ""
    Private mZipCode As String = ""
    Private mPhone As String = ""
    Private mFax As String = ""
    Private mFacilityCode As String = ""



    Public Property FacilityID() As String
        Get
            Return mFacilityID
        End Get
        Set(ByVal value As String)
            mFacilityID = value
        End Set
    End Property

    Public Property FacilityName() As String
        Get
            Return mFacilityName
        End Get
        Set(ByVal value As String)
            mFacilityName = value
        End Set
    End Property

    Public Property NPI() As String
        Get
            Return mNPI
        End Get
        Set(ByVal value As String)
            mNPI = value
        End Set
    End Property

    Public Property AddressLine1() As String
        Get
            Return mAddressLine1
        End Get
        Set(ByVal value As String)
            mAddressLine1 = value
        End Set
    End Property

    Public Property AddressLine2() As String
        Get
            Return mAddressLine2
        End Get
        Set(ByVal value As String)
            mAddressLine2 = value
        End Set
    End Property

    Public Property City() As String
        Get
            Return mCity
        End Get
        Set(ByVal value As String)
            mCity = value
        End Set
    End Property

    Public Property State() As String
        Get
            Return mState
        End Get
        Set(ByVal value As String)
            mState = value
        End Set
    End Property

    Public Property ZipCode() As String
        Get
            Return mZipCode
        End Get
        Set(ByVal value As String)
            mZipCode = value
        End Set
    End Property

    Public Property Phone() As String
        Get
            Return mPhone
        End Get
        Set(ByVal value As String)
            mPhone = value
        End Set
    End Property

    Public Property Fax() As String
        Get
            Return mFax
        End Get
        Set(ByVal value As String)
            mFax = value
        End Set
    End Property

    Public Property FacilityCode() As String
        Get
            Return mFacilityCode
        End Get
        Set(ByVal value As String)
            mFacilityCode = value
        End Set
    End Property

End Class


Public Class Facility

    Private mFacilityDB As FacilityDB
    Private mConnection As Connection


    Public Sub New()
        mFacilityDB = New FacilityDB
        mConnection = New Connection
    End Sub

    Public Sub New(ByVal pConnectionString As String)
        mFacilityDB = New FacilityDB
        mConnection = New Connection(pConnectionString)
    End Sub

    Public Sub New(ByVal pConnection As Connection)
        mFacilityDB = New FacilityDB
        mConnection = pConnection
    End Sub

    Public Property FacilityDB() As FacilityDB
        Get
            Return mFacilityDB
        End Get
        Set(ByVal value As FacilityDB)
            mFacilityDB = value
        End Set
    End Property

    Public Property Connection() As Connection
        Get
            Return mConnection
        End Get
        Set(ByVal value As Connection)
            mConnection = value
        End Set
    End Property


    Public Function InsertFacility() As Boolean

        Dim lQuery As String = String.Empty
        Dim lXmlDocument As New XmlDocument
        Dim lXmlElement As XmlElement

        Try
            lXmlDocument.LoadXml("<Facilities></Facilities>")
            lXmlElement = lXmlDocument.CreateElement("Facility")

            With lXmlElement
                .SetAttribute("FacilityName", FacilityDB.FacilityName)
                .SetAttribute("NPI", FacilityDB.NPI)
                .SetAttribute("AddressLine1", FacilityDB.AddressLine1)
                .SetAttribute("AddressLine2", FacilityDB.AddressLine2)
                .SetAttribute("City", FacilityDB.City)
                .SetAttribute("State", FacilityDB.State)
                .SetAttribute("Phone", FacilityDB.Phone)
                .SetAttribute("Fax", FacilityDB.Fax)
                .SetAttribute("ZipCode", FacilityDB.ZipCode)
                .SetAttribute("IsDelete", "N")
                .SetAttribute("FacilityCode", FacilityDB.FacilityCode)
            End With

            lXmlDocument.DocumentElement.AppendChild(lXmlElement.CloneNode(True))
            Connection.ExecuteCommand("InsertFacility", lXmlDocument.DocumentElement.OuterXml)
            Return True
        Catch ex As Exception
            Return False
        End Try

        'Dim lQuery As String = String.Empty

        'Try
        '    lQuery = "Insert into Facility (FacilityName,NPI,AddressLine1,AddressLine2,City,State,Phone,Fax,ZipCode,IsDelete) " _
        '    & " Values  ('" & FacilityDB.FacilityName & "','" & FacilityDB.NPI & "','" & FacilityDB.AddressLine1 & "', " _
        '    & "'" & FacilityDB.AddressLine2 & "','" & FacilityDB.City & "','" & FacilityDB.State & "'," _
        '    & "'" & FacilityDB.Phone & "','" & FacilityDB.Fax & "','" & FacilityDB.ZipCode & "','N')"

        '    Connection.ExecuteCommand(lQuery)
        '    Return True

      

    End Function

    Public Function GetFacilityName(ByRef pUser As User, ByVal pCondition As String)

        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()

        Try


            lSpParameter(0) = New SpParameter
            lSpParameter(0).ParameterName = "@Table"
            lSpParameter(0).ParameterType = ParameterType.Varchar
            lSpParameter(0).ParameterValue = "Facility"

            lSpParameter(1) = New SpParameter
            lSpParameter(1).ParameterName = "@Cond"
            lSpParameter(1).ParameterType = ParameterType.Varchar
            lSpParameter(1).ParameterValue = pCondition


            lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)

            Return lDs

        Catch ex As Exception
            Throw New Exception(ex.Message & " (Error in GetCurrentRxForDoctor)")
        End Try


    End Function

    Public Function GetAllRecords(ByRef pUser As User, ByVal pCondition As String)

        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()

        Try


            lSpParameter(0) = New SpParameter
            lSpParameter(0).ParameterName = "@Table"
            lSpParameter(0).ParameterType = ParameterType.Varchar
            lSpParameter(0).ParameterValue = "Facility"

            lSpParameter(1) = New SpParameter
            lSpParameter(1).ParameterName = "@Cond"
            lSpParameter(1).ParameterType = ParameterType.Varchar
            lSpParameter(1).ParameterValue = pCondition


            lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)

            Return lDs

        Catch ex As Exception
            Throw New Exception(ex.Message & " (Error in GetCurrentRxForDoctor)")
        End Try


    End Function


    Public Function UpdateFacility() As Boolean

        Dim lQuery As String = String.Empty

        Try
            lQuery = "Update Facility " & _
            "set " & _
            "FacilityName = '" & FacilityDB.FacilityName & "', " & _
            "NPI = '" & FacilityDB.NPI & "', " & _
            "AddressLine1 = '" & FacilityDB.AddressLine1 & "', " & _
            "AddressLine2 = '" & FacilityDB.AddressLine2 & "', " & _
            "City = '" & FacilityDB.City & "', " & _
            "State = '" & FacilityDB.State & "', " & _
            "ZipCode = '" & FacilityDB.ZipCode & "', " & _
            "Phone = '" & FacilityDB.Phone & "', " & _
            "Fax = '" & FacilityDB.Fax & "', " & _
            "FacilityCode = '" & FacilityDB.FacilityCode & "' " & _
            "where " & _
            "FacilityID = " & FacilityDB.FacilityID


            Connection.ExecuteCommand(lQuery)
            Return True

        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Function DeleteFacility() As Boolean

        Dim lQuery As String = String.Empty

        Try
            lQuery = "Update Facility Set IsDelete='Y' where FacilityID=" & FacilityDB.FacilityID
          
            Connection.ExecuteCommand(lQuery)
            Return True

        Catch ex As Exception
            Return False
        End Try
    End Function


    Public Function GetAllRecordsforSearchWindow(ByRef pUser As User, ByVal pCondition As String)

        Dim lQuery As String = String.Empty


        Dim lDs As New DataSet()

        lQuery = "Select FacilityID,FacilityName,(AddressLine1+AddressLine2)as Address,City,State,ZipCode,Phone,NPI,FacilityCode from Facility where 1=1 " & pCondition

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery(lQuery)
        Else
            lDs = Connection.ExecuteQuery(lQuery)
        End If

        Return lDs

    End Function

    Public Function GetRecordById(ByVal lDT As DataTable) As Boolean

        With lDT
            If .Rows.Count > 0 Then
                If (Not IsDBNull(.Rows(0)("FacilityID"))) Then
                    Me.FacilityDB.FacilityID = .Rows(0)("FacilityID")
                Else
                    Me.FacilityDB.FacilityID = ""
                End If

                If (Not IsDBNull(.Rows(0)("FacilityName"))) Then
                    Me.FacilityDB.FacilityName = .Rows(0)("FacilityName")
                Else
                    Me.FacilityDB.FacilityName = ""
                End If

                If (Not IsDBNull(.Rows(0)("NPI"))) Then
                    Me.FacilityDB.NPI = .Rows(0)("NPI")
                Else
                    Me.FacilityDB.NPI = ""
                End If

                If (Not IsDBNull(.Rows(0)("City"))) Then
                    Me.FacilityDB.City = .Rows(0)("City")
                Else
                    Me.FacilityDB.City = ""
                End If

                If (Not IsDBNull(.Rows(0)("AddressLine1"))) Then
                    Me.FacilityDB.AddressLine1 = .Rows(0)("AddressLine1")
                Else
                    Me.FacilityDB.AddressLine1 = ""
                End If

                If (Not IsDBNull(.Rows(0)("AddressLine2"))) Then
                    Me.FacilityDB.AddressLine2 = .Rows(0)("AddressLine2")
                Else
                    Me.FacilityDB.AddressLine2 = ""
                End If

                If (Not IsDBNull(.Rows(0)("City"))) Then
                    Me.FacilityDB.City = .Rows(0)("City")
                Else
                    Me.FacilityDB.City = ""
                End If


                If (Not IsDBNull(.Rows(0)("Abbr"))) Then
                    Me.FacilityDB.State = .Rows(0)("Abbr")
                Else
                    Me.FacilityDB.State = ""
                End If

                If (Not IsDBNull(.Rows(0)("ZipCode"))) Then
                    Me.FacilityDB.ZipCode = .Rows(0)("ZipCode")
                Else
                    Me.FacilityDB.ZipCode = ""
                End If

                If (Not IsDBNull(.Rows(0)("Phone"))) Then
                    Me.FacilityDB.Phone = .Rows(0)("Phone")
                Else
                    Me.FacilityDB.Phone = ""
                End If

                If (Not IsDBNull(.Rows(0)("Fax"))) Then
                    Me.FacilityDB.Fax = .Rows(0)("Fax")
                Else
                    Me.FacilityDB.Fax = ""
                End If

                If (Not IsDBNull(.Rows(0)("FacilityCode"))) Then
                    Me.FacilityDB.FacilityCode = .Rows(0)("FacilityCode")
                Else
                    Me.FacilityDB.FacilityCode = ""
                End If


                Return True
            Else
                Return False
            End If
        End With


    End Function

    Public Function GetFacilityById(ByVal pCondition As String) As Boolean
        Dim lQuery As String
        Try
            Dim lDs As New DataSet()
            lQuery = "select * FROM Facility where 1=1 and " & pCondition & " "

            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If
            With lDs.Tables(0)
                If .Rows.Count > 0 Then
                    If (Not IsDBNull(.Rows(0)("FacilityID"))) Then
                        Me.FacilityDB.FacilityID = .Rows(0)("FacilityID")
                    Else
                        Me.FacilityDB.FacilityID = ""
                    End If

                    If (Not IsDBNull(.Rows(0)("FacilityName"))) Then
                        Me.FacilityDB.FacilityName = .Rows(0)("FacilityName")
                    Else
                        Me.FacilityDB.FacilityName = ""
                    End If

                    If (Not IsDBNull(.Rows(0)("NPI"))) Then
                        Me.FacilityDB.NPI = .Rows(0)("NPI")
                    Else
                        Me.FacilityDB.NPI = ""
                    End If

                    If (Not IsDBNull(.Rows(0)("City"))) Then
                        Me.FacilityDB.City = .Rows(0)("City")
                    Else
                        Me.FacilityDB.City = ""
                    End If

                    If (Not IsDBNull(.Rows(0)("AddressLine1"))) Then
                        Me.FacilityDB.AddressLine1 = .Rows(0)("AddressLine1")
                    Else
                        Me.FacilityDB.AddressLine1 = ""
                    End If

                    If (Not IsDBNull(.Rows(0)("AddressLine2"))) Then
                        Me.FacilityDB.AddressLine2 = .Rows(0)("AddressLine2")
                    Else
                        Me.FacilityDB.AddressLine2 = ""
                    End If

                    If (Not IsDBNull(.Rows(0)("City"))) Then
                        Me.FacilityDB.City = .Rows(0)("City")
                    Else
                        Me.FacilityDB.City = ""
                    End If


                    If (Not IsDBNull(.Rows(0)("State"))) Then
                        Me.FacilityDB.State = .Rows(0)("State")
                    Else
                        Me.FacilityDB.State = ""
                    End If

                    If (Not IsDBNull(.Rows(0)("ZipCode"))) Then
                        Me.FacilityDB.ZipCode = .Rows(0)("ZipCode")
                    Else
                        Me.FacilityDB.ZipCode = ""
                    End If

                    If (Not IsDBNull(.Rows(0)("Phone"))) Then
                        Me.FacilityDB.Phone = .Rows(0)("Phone")
                    Else
                        Me.FacilityDB.Phone = ""
                    End If

                    If (Not IsDBNull(.Rows(0)("Fax"))) Then
                        Me.FacilityDB.Fax = .Rows(0)("Fax")
                    Else
                        Me.FacilityDB.Fax = ""
                    End If

                    If (Not IsDBNull(.Rows(0)("FacilityCode"))) Then
                        Me.FacilityDB.FacilityCode = .Rows(0)("FacilityCode")
                    Else
                        Me.FacilityDB.FacilityCode = ""
                    End If
                End If
                Return True
            End With

        Catch ex As Exception
            Return False
        End Try
    End Function

    ''Kanwal jeet
    Public Function GetFacilityIDInClinic() As Integer
        Dim lFacilityId As Integer
        Dim lQuery As String = String.Empty

        Try
            lQuery = "select count(*) from ClinicInfo where FacilityId = " & FacilityDB.FacilityID
            Return Connection.ExecuteScalarCommand(lQuery)
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Public Function GetActiveFacilityList() As DataSet
        Dim lQuery As String

        Dim lDs As New DataSet()
        lQuery = "SELECT FacilityID,FacilityName FROM Facility where IsDelete='N' Order By FacilityCode "

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery(lQuery)
        Else
            lDs = Connection.ExecuteQuery(lQuery)
        End If
        Return lDs
    End Function




End Class
