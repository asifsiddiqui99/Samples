﻿Imports Microsoft.VisualBasic

Public Class PatientInsuranceForLabs



#Region "Fields"
    Private mConnection As Connection
    Private mConnectionString
    Private mPatientInsurance(3) As PatientInsuranceDB
    Private mInsuranceDB(3) As InsuranceDB
    Private mPatientDB(3) As PatientDB
    Private mInsuranceCount As Integer


#End Region

#Region "Property"

    Public Property InsuranceCount() As Integer
        Get
            Return mInsuranceCount
        End Get
        Set(ByVal value As Integer)
            mInsuranceCount = value
        End Set
    End Property

    Public ReadOnly Property Connection() As ElixirLibrary.Connection
        Get
            Return mConnection
        End Get
    End Property

    Public ReadOnly Property ConnectionString() As String
        Get
            Return mConnectionString
        End Get
    End Property

    Public Property PatientInsurance(ByVal pIndex As Integer) As PatientInsuranceDB
        Get
            Return mPatientInsurance(pindex)
        End Get
        Set(ByVal value As PatientInsuranceDB)
            mPatientInsurance(pIndex) = value
        End Set
    End Property

    Public Property InsuranceDB(ByVal pIndex As Integer) As InsuranceDB
        Get
            Return mInsuranceDB(pIndex)
        End Get
        Set(ByVal value As InsuranceDB)
            mInsuranceDB(pIndex) = value
        End Set
    End Property


    Public Property PatientDB(ByVal pIndex As Integer) As PatientDB
        Get
            Return mPatientDB(pIndex)
        End Get
        Set(ByVal value As PatientDB)
            mPatientDB(pIndex) = value
        End Set
    End Property


#End Region

#Region "Constructor"
    ''' <summary>
    ''' Creates new Conection Object based on Given Connection String 
    ''' </summary>
    ''' <param name="pConnectionString">
    ''' Contains Connection String 
    ''' </param>
    ''' <remarks>
    ''' Use when not using transaction
    ''' Must Specify Connection String other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnectionString As String)
        If pConnectionString = "" Then
            Throw New ArgumentException("ConnectionString can not be empty")
        End If

        mConnectionString = pConnectionString
        mConnection = New Connection(mConnectionString)

    End Sub

    ''' <summary>
    ''' Assign given connection to the current Object
    ''' </summary>
    ''' <param name="pConnection">
    ''' Contains refrence to the connection object
    ''' </param>
    ''' <remarks>
    ''' Use when  using Transaction
    ''' Must Specify Connection other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnection As Connection)
        If pConnection Is Nothing Then
            Throw New ArgumentException("Connection can not be empty")
        End If

        mConnection = pConnection
    End Sub
#End Region



    Public Function GetRecordByID(ByVal pPatientID As Integer) As Boolean
        Dim lSpParameter(0) As SpParameter
        Dim lDs As New DataSet()
        Dim lCondition As String = ""

        Try
            lSpParameter(0).ParameterName = "@PatientId"
            lSpParameter(0).ParameterType = ParameterType.Varchar
            lSpParameter(0).ParameterValue = pPatientID




            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery("InsuranceInfo", lSpParameter)
            Else
                lDs = Connection.ExecuteQuery("InsuranceInfo", lSpParameter)
            End If


            For x As Integer = 0 To lDs.Tables(0).Rows.Count - 1
                With lDs.Tables(0)
                    InsuranceCount += 1
                    Me.PatientInsurance(x) = New PatientInsuranceDB
                    Me.PatientInsurance(x).PatientInsID = .Rows(x)("PatientInsID")
                    Me.PatientInsurance(x).PatientID = .Rows(x)("PatientID")
                    Me.PatientInsurance(x).Type = .Rows(x)("Type")
                    Me.PatientInsurance(x).Active = .Rows(x)("Active")
                    Me.PatientInsurance(x).Deductable = .Rows(x)("Deductable")
                    Me.PatientInsurance(x).GroupNo = .Rows(x)("GroupNo")
                    Me.PatientInsurance(x).InsuranceCompanyName = .Rows(x)("InsuranceCompany")
                    Me.PatientInsurance(x).InsuranceCompanyID = .Rows(x)("InsuranceCompanyID")
                    Me.PatientInsurance(x).InsurerId = .Rows(x)("InsurerId")
                    Me.PatientInsurance(x).PayerId = .Rows(x)("PayerId1")
                    Me.PatientInsurance(x).InsuredAuthorization = .Rows(x)("InsuredAuthorization")
                    Me.PatientInsurance(x).PlanName = .Rows(x)("PlanName")
                    Me.PatientInsurance(x).RelationshipToPrimaryInsurer = .Rows(x)("RelationshipToPrimaryInsurer")
                    Me.PatientInsurance(x).SignatureDate = .Rows(x)("SignatureDate")
                    Me.PatientInsurance(x).SignatureOfFile = .Rows(x)("SignatureOfFile")
                    Me.PatientInsurance(x).SubscriberID = .Rows(x)("SubscriberID")
                    Me.PatientInsurance(x).VisitCopayment = .Rows(x)("VisitCopayment")

                    Me.PatientInsurance(x).EffectiveDateFrom = IIf(IsDBNull(.Rows(x)("EffectiveDateFrom")), "1/1/1900", .Rows(x)("EffectiveDateFrom"))
                    Me.PatientInsurance(x).EffectiveDateTo = IIf(IsDBNull(.Rows(x)("EffectiveDateTo")), "1/1/1900", .Rows(x)("EffectiveDateTo"))
                    Me.PatientInsurance(x).AuthorizationNumber = .Rows(x)("AuthorizationNumber")
                    Me.PatientInsurance(x).CoInsurance = .Rows(x)("CoInsurance")
                    Me.PatientInsurance(x).InsuranceCompanyPhoneNumber = .Rows(x)("InsuranceCompanyPhoneNumber")
                    Me.PatientInsurance(x).InsurerInsuranceType = .Rows(x)("InsurerInsuranceType")
                    Me.PatientInsurance(x).InsurerInsuranceId = .Rows(x)("InsurerInsuranceId")

                    Me.mInsuranceDB(x) = New InsuranceDB
                    Me.mInsuranceDB(x).AddressLine1 = .Rows(x)("AddressLine1")
                    Me.mInsuranceDB(x).AddressLine2 = .Rows(x)("AddressLine2")
                    Me.mInsuranceDB(x).CompanyName = .Rows(x)("CompanyName")
                    Me.mInsuranceDB(x).City = .Rows(x)("City")
                    Me.mInsuranceDB(x).State = .Rows(x)("State")
                    Me.mInsuranceDB(x).ZipCode = .Rows(x)("ZipCode")


                    Me.mPatientDB(x) = New PatientDB
                    Me.mPatientDB(x).AddressLine1 = .Rows(x)("AddressLine11")
                    Me.mPatientDB(x).AddressLine2 = .Rows(x)("AddressLine21")
                    Me.mPatientDB(x).FirstName = .Rows(x)("FirstName")
                    Me.mPatientDB(x).LastName = .Rows(x)("LastName")
                    Me.mPatientDB(x).MiddleName = .Rows(x)("MiddleName")
                    Me.mPatientDB(x).City = .Rows(x)("City1")
                    Me.mPatientDB(x).StateID = .Rows(x)("StateID")
                    Me.mPatientDB(x).ZipCode = .Rows(x)("ZipCode1")
                    Me.mPatientDB(x).HomePhone = .Rows(x)("HousePhone")



                End With
            Next

            Return True
        Catch ex As Exception
            Return False
        End Try



    End Function




End Class
