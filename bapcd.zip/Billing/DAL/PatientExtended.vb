Imports Microsoft.VisualBasic

Public Class PatientDBExtended
    Inherits PatientDB

#Region "Fields"
    Private mMartialStatus As String = "Single"
    Private mCellPhoneNumber As String = ""

    '' Emergency contacts
    Private mEmergencyContactName As String = ""
    Private mEmergencyContactRelationship As String = "Self"
    Private mEmergencyContactPhone As String = ""
    Private mEmergencyContactAddress As String = ""
    Private mEmergencyContactCity As String = ""
    Private mEmergencyContactZip As String = ""
    Private mEmergencyContactState As String = "1"

    '' Employment Information
    Private mEmployerName As String = ""
    Private mEmploymentStatus As String = "Permenant"
    Private mEmployerAddressLine1 As String = ""
    Private mEmployerAddressLine2 As String = ""
    Private mEmployerPhoneNumber As String = ""
    Private mEmployerCity As String = ""
    Private mEmployerState As String = "1"
    Private mEmployerZip As String = ""

    '' Responsible Party Information
    Private mResponsibleName As String = ""
    Private mResponsibleRelationship As String = "Self"
    Private mResponsibleHomePhone As String = ""
    Private mResponsibleWorkPhone As String = ""
    Private mResponsibleAddress As String = ""
    Private mResponsibleSSN As String = ""
    Private mResponsibleCity As String = ""
    Private mResponsibleState As String = "1"
    Private mResponsibleZip As String = ""

    ''Insurance
    Private mPrimaryInsurance As New PatientInsuranceDB
    Private mSecondaryInsurance As New PatientInsuranceDB
    Private mTertiaryyInsurance As New PatientInsuranceDB

    '' New Fields 15 Dec 2009
    Private mEmergencyContactName2 As String = ""
    Private mEmergencyContactRelationship2 As String = "OTHER"
    Private mEmergencyContactPhone2 As String = ""
    Private mPreferredHomePh As String = "N"
    Private mPreferredWorkPh As String = "N"
    Private mPreferredCellPh As String = "N"

    ''New Field 20 dec 2009

    Private mEmployeeDesignation As String = ""

    ''New Field 20 dec 2011
    Private mGuarantorId As String = ""
    Private mPatientisGuarantor As String = ""
    Private mIsMedicationActive As String = ""
    Private mMultipleRace As String = ""

    ' Added By Affan Toor | Date: 24-03-14
    Private mIsIncompleteStatus As String = "N"
#End Region


#Region "Properties"

    Public Property IsIncompleteStatus() As String
        Get
            Return mIsIncompleteStatus
        End Get
        Set(ByVal value As String)
            mIsIncompleteStatus = value
        End Set
    End Property

    Public Property IsMedicationActive() As String
        Get
            Return mIsMedicationActive
        End Get
        Set(ByVal value As String)
            mIsMedicationActive = value
        End Set
    End Property

    Public Property EmergencyContactName2() As String
        Get
            Return mEmergencyContactName2
        End Get
        Set(ByVal value As String)
            mEmergencyContactName2 = value
        End Set
    End Property
    Public Property EmergencyContactRelationship2() As String
        Get
            Return mEmergencyContactRelationship2
        End Get
        Set(ByVal value As String)
            mEmergencyContactRelationship2 = value
        End Set
    End Property
    Public Property EmergencyContactPhone2() As String
        Get
            Return mEmergencyContactPhone2
        End Get
        Set(ByVal value As String)
            mEmergencyContactPhone2 = value
        End Set
    End Property
    Public Property PreferredHomePh() As String
        Get
            Return mPreferredHomePh
        End Get
        Set(ByVal value As String)
            mPreferredHomePh = value
        End Set
    End Property
    Public Property PreferredWorkPh() As String
        Get
            Return mPreferredWorkPh
        End Get
        Set(ByVal value As String)
            mPreferredWorkPh = value
        End Set
    End Property
    Public Property PreferredCellPh() As String
        Get
            Return mPreferredCellPh
        End Get
        Set(ByVal value As String)
            mPreferredCellPh = value
        End Set
    End Property



    Public Property MartialStatus() As String
        Get
            Return mMartialStatus
        End Get
        Set(ByVal value As String)
            mMartialStatus = value
        End Set
    End Property

    Public Property CellPhoneNumber() As String
        Get
            Return mCellPhoneNumber
        End Get
        Set(ByVal value As String)
            mCellPhoneNumber = value
        End Set
    End Property

    Public Property EmergencyContactName() As String
        Get
            Return mEmergencyContactName
        End Get
        Set(ByVal value As String)
            mEmergencyContactName = value
        End Set
    End Property

    Public Property EmergencyContactRelationship() As String
        Get
            Return mEmergencyContactRelationship
        End Get
        Set(ByVal value As String)
            mEmergencyContactRelationship = value
        End Set
    End Property

    Public Property EmergencyContactPhone() As String
        Get
            Return mEmergencyContactPhone
        End Get
        Set(ByVal value As String)
            mEmergencyContactPhone = value
        End Set
    End Property

    Public Property EmergencyContactAddress() As String
        Get
            Return mEmergencyContactAddress
        End Get
        Set(ByVal value As String)
            mEmergencyContactAddress = value
        End Set
    End Property

    Public Property EmergencyContactCity() As String
        Get
            Return mEmergencyContactCity
        End Get
        Set(ByVal value As String)
            mEmergencyContactCity = value
        End Set
    End Property

    Public Property EmergencyContactZip() As String
        Get
            Return mEmergencyContactZip
        End Get
        Set(ByVal value As String)
            mEmergencyContactZip = value
        End Set
    End Property

    Public Property EmergencyContactState() As String
        Get
            Return mEmergencyContactState
        End Get
        Set(ByVal value As String)
            mEmergencyContactState = value
        End Set
    End Property

    Public Property EmployerName() As String
        Get
            Return mEmployerName
        End Get
        Set(ByVal value As String)
            mEmployerName = value
        End Set
    End Property

    Public Property EmploymentStatus() As String
        Get
            Return mEmploymentStatus
        End Get
        Set(ByVal value As String)
            mEmploymentStatus = value
        End Set
    End Property

    Public Property EmployerAddressLine1() As String
        Get
            Return mEmployerAddressLine1
        End Get
        Set(ByVal value As String)
            mEmployerAddressLine1 = value
        End Set
    End Property

    Public Property EmployerAddressLine2() As String
        Get
            Return mEmployerAddressLine2
        End Get
        Set(ByVal value As String)
            mEmployerAddressLine2 = value
        End Set
    End Property

    Public Property EmployerPhoneNumber() As String
        Get
            Return mEmployerPhoneNumber
        End Get
        Set(ByVal value As String)
            mEmployerPhoneNumber = value
        End Set
    End Property
    Public Property EmployerCity() As String
        Get
            Return mEmployerCity
        End Get
        Set(ByVal value As String)
            mEmployerCity = value
        End Set
    End Property

    Public Property EmployerState() As String
        Get
            Return mEmployerState
        End Get
        Set(ByVal value As String)
            mEmployerState = value
        End Set
    End Property

    Public Property EmployerZip() As String
        Get
            Return mEmployerZip
        End Get
        Set(ByVal value As String)
            mEmployerZip = value
        End Set
    End Property

    Public Property ResponsibleName() As String
        Get
            Return mResponsibleName
        End Get
        Set(ByVal value As String)
            mResponsibleName = value
        End Set
    End Property

    Public Property ResponsibleRelationship() As String
        Get
            Return mResponsibleRelationship
        End Get
        Set(ByVal value As String)
            mResponsibleRelationship = value
        End Set
    End Property

    Public Property ResponsibleHomePhone() As String
        Get
            Return mResponsibleHomePhone
        End Get
        Set(ByVal value As String)
            mResponsibleHomePhone = value
        End Set
    End Property

    Public Property ResponsibleWorkPhone() As String
        Get
            Return mResponsibleWorkPhone
        End Get
        Set(ByVal value As String)
            mResponsibleWorkPhone = value
        End Set
    End Property

    Public Property ResponsibleAddress() As String
        Get
            Return mResponsibleAddress
        End Get
        Set(ByVal value As String)
            mResponsibleAddress = value
        End Set
    End Property

    Public Property ResponsibleCity() As String
        Get
            Return mResponsibleCity
        End Get
        Set(ByVal value As String)
            mResponsibleCity = value
        End Set
    End Property

    Public Property ResponsibleState() As String
        Get
            Return mResponsibleState
        End Get
        Set(ByVal value As String)
            mResponsibleState = value
        End Set
    End Property

    Public Property ResponsibleZip() As String
        Get
            Return mResponsibleZip
        End Get
        Set(ByVal value As String)
            mResponsibleZip = value
        End Set
    End Property

    Public Property ResponsibleSSN() As String
        Get
            Return mResponsibleSSN
        End Get
        Set(ByVal value As String)
            mResponsibleSSN = value
        End Set
    End Property

    Public Property PrimaryInsurance() As PatientInsuranceDB
        Get
            Return mPrimaryInsurance
        End Get
        Set(ByVal value As PatientInsuranceDB)
            mPrimaryInsurance = value
        End Set
    End Property

    Public Property SecondaryInsurance() As PatientInsuranceDB
        Get
            Return mSecondaryInsurance
        End Get
        Set(ByVal value As PatientInsuranceDB)
            mSecondaryInsurance = value
        End Set
    End Property

    Public Property TertiaryInsurance() As PatientInsuranceDB
        Get
            Return mTertiaryyInsurance
        End Get
        Set(ByVal value As PatientInsuranceDB)
            mTertiaryyInsurance = value
        End Set
    End Property
    'EmployeeDesignation
    Public Property EmployeeDesignation() As String
        Get
            Return mEmployeeDesignation
        End Get
        Set(ByVal value As String)
            mEmployeeDesignation = value
        End Set
    End Property

    Public Property GuarantorId() As String
        Get
            Return mGuarantorId
        End Get
        Set(ByVal value As String)
            mGuarantorId = value
        End Set
    End Property

    Public Property PatientisGuarantor() As String
        Get
            Return mPatientisGuarantor
        End Get
        Set(ByVal value As String)
            mPatientisGuarantor = value
        End Set
    End Property

    Public Property MultipleRace() As String
        Get
            Return mMultipleRace
        End Get
        Set(ByVal value As String)
            mMultipleRace = value
        End Set
    End Property
#End Region

End Class

Public Class PatientExtended
    Inherits Patient

    Private mPatient As New PatientDBExtended

    Public Overloads Property Patient() As PatientDBExtended
        Get
            Return mPatient
        End Get
        Set(ByVal value As PatientDBExtended)
            mPatient = value
        End Set
    End Property
#Region "Constructors"
    ''' <summary>
    ''' Creates new Conection Object based on Given Connection String 
    ''' </summary>
    ''' <param name="pConnectionString">
    ''' Contains Connection String 
    ''' </param>
    ''' <remarks>
    ''' Use when not using transaction
    ''' Must Specify Connection String other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnectionString As String)
        MyBase.New(pConnectionString)
    End Sub
    ''' <summary>
    ''' Assign given connection to the current Object
    ''' </summary>
    ''' <param name="pConnection">
    ''' Contains refrence to the connection object
    ''' </param>
    ''' <remarks>
    ''' Use when  using Transaction
    ''' Must Specify Connection other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnection As Connection)
        MyBase.New(pConnection)
    End Sub

#End Region

#Region "Methods"

    Public Overloads Sub InsertRecord()
        Try
            Dim lXmlDocument As New XmlDocument
            Dim lXmlElement As XmlElement

            lXmlDocument.LoadXml("<Patients></Patients>")
            lXmlElement = lXmlDocument.CreateElement("Patient")

            With lXmlElement
                .SetAttribute("PatientID", Patient.PatientID)
                .SetAttribute("PatientCode", Patient.PatientCode)
                .SetAttribute("Title", Patient.Title)
                .SetAttribute("Occupation", Patient.Occupation)
                .SetAttribute("FirstName", Patient.FirstName)
                .SetAttribute("MiddleName", Patient.MiddleName)
                .SetAttribute("LastName", Patient.LastName)
                .SetAttribute("MartialStatus", Patient.MartialStatus)
                .SetAttribute("AddressLine1", Patient.AddressLine1)
                .SetAttribute("AddressLine2", Patient.AddressLine2)
                .SetAttribute("City", Patient.City)
                .SetAttribute("StateID", Patient.StateID)
                .SetAttribute("ZipCode", Patient.ZipCode)
                .SetAttribute("HousePhone", Patient.HomePhone)
                .SetAttribute("WorkPhone", Patient.WorkPhone)
                .SetAttribute("WorkPhoneExtension", Patient.WorkPhoneExtension)
                .SetAttribute("Fax", Patient.Fax)
                .SetAttribute("Email", Patient.Email)
                .SetAttribute("Occupation", Patient.Occupation)
                .SetAttribute("DOB", Patient.DOB)
                .SetAttribute("Gender", Patient.Gender)
                .SetAttribute("InsuranceID", Patient.InsuranceID)
                .SetAttribute("InsuranceName", Patient.InsuranceName)
                .SetAttribute("NcpdpID", Patient.NCPDPID)
                .SetAttribute("PharmacyName", Patient.PharmacyName)
                .SetAttribute("PharmacyProvider", Patient.PharmacyProvider)
                .SetAttribute("SSN", Patient.SSN)
                .SetAttribute("IsDeleted", Patient.IsDeleted)
                .SetAttribute("PictureFilePath", Patient.PictureFilePath)
                .SetAttribute("CellPhoneNumber", Patient.CellPhoneNumber)
                ''New Field 20 dec 2011
                .SetAttribute("GuarantorId", Patient.GuarantorId)
                .SetAttribute("PatientisaGuarantor", Patient.PatientisGuarantor)
                .SetAttribute("CardDrivingLicense", Patient.DrivingLicenseCardImage)

                .SetAttribute("EmergencyContactName", Patient.EmergencyContactName)
                .SetAttribute("EmergencyContactRelationship", Patient.EmergencyContactRelationship)
                .SetAttribute("EmergencyContactPhone", Patient.EmergencyContactPhone)
                .SetAttribute("EmergencyContactAddress", Patient.EmergencyContactAddress)
                .SetAttribute("EmergencyContactCity", Patient.EmergencyContactCity)
                .SetAttribute("EmergencyContactZip", Patient.EmergencyContactZip)
                .SetAttribute("EmergencyContactState", Patient.EmergencyContactState)

                .SetAttribute("EmployerName", Patient.EmployerName)
                If Patient.EmploymentStatus = "Select" Then
                    .SetAttribute("EmploymentStatus", "")
                Else
                    .SetAttribute("EmploymentStatus", Patient.EmploymentStatus)
                End If

                .SetAttribute("EmployerAddressLine1", Patient.EmployerAddressLine1)
                .SetAttribute("EmployerAddressLine2", Patient.EmployerAddressLine2)
                .SetAttribute("EmployerPhoneNumber", Patient.EmployerPhoneNumber)
                .SetAttribute("EmployerCity", Patient.EmployerCity)
                .SetAttribute("EmployerZip", Patient.EmployerZip)
                .SetAttribute("EmployerState", Patient.EmployerState)

                .SetAttribute("ResponsibleName", Patient.ResponsibleName)
                .SetAttribute("ResponsibleRelationship", Patient.ResponsibleRelationship)
                .SetAttribute("ResponsibleHomePhone", Patient.ResponsibleHomePhone)
                .SetAttribute("ResponsibleWorkPhone", Patient.ResponsibleWorkPhone)
                .SetAttribute("ResponsibleAddress", Patient.ResponsibleAddress)
                .SetAttribute("ResponsibleSSN", Patient.ResponsibleSSN)
                .SetAttribute("ResponsibleCity", Patient.ResponsibleCity)
                .SetAttribute("ResponsibleState", Patient.ResponsibleState)
                .SetAttribute("ResponsibleZip", Patient.ResponsibleZip)

                .SetAttribute("NCPDPID2", Patient.NCPDPID2)
                .SetAttribute("PharmacyName2", Patient.PharmacyName2)
                .SetAttribute("PharmacyProvider2", Patient.PharmacyProvider2)

                '' New fields start in billing development cycle
                .SetAttribute("EmergencyContactName2", Patient.EmergencyContactName2)
                .SetAttribute("EmergencyContactRelationship2", Patient.EmergencyContactRelationship2)
                .SetAttribute("EmergencyContactPhone2", Patient.EmergencyContactPhone2)
                .SetAttribute("PreferredHomePh", Patient.PreferredHomePh)
                .SetAttribute("PreferredWorkPh", Patient.PreferredWorkPh)
                .SetAttribute("PreferredCellPh", Patient.PreferredCellPh)
                '' New fields End in billing development cycle
                'field added by madiha on 20/12/2009
                .SetAttribute("EmployeeDesignation", Patient.EmployeeDesignation)

                'Field Added by Imran Khan on 04/05/2012
                '-------------

                .SetAttribute("AccessMedHistory", Patient.AccessMedHistory)
                .SetAttribute("Race", Patient.Race)
                .SetAttribute("Language", Patient.Language)
                .SetAttribute("Ethinicity", Patient.Ethinicty)
                .SetAttribute("IsTransfered", Patient.IsTransfered)
                .SetAttribute("TransferedBy", Patient.TransferedBy)
                .SetAttribute("CommunicationMethod", Patient.CommunicationMethod)
                .SetAttribute("IsMedicationActive", "Y")
                .SetAttribute("TransferedDate", Patient.TransferedDate)
                .SetAttribute("ReferredTo", Patient.ReferredTo)
                '------------

                ' Code by HJ 25 Nov 2013 Start

                '.SetAttribute("MotherMaidenName", Patient.MotherMaidenName)
                .SetAttribute("ImmunizationRegistryStatus", Patient.ImmunizationRegistryStatus)
                .SetAttribute("IRSCode", Patient.IRSCode)
                .SetAttribute("IRSEffectiveDate", Patient.IRSEffectiveDate)
                .SetAttribute("PublicityCode", Patient.PublicityCode)
                .SetAttribute("PCCode", Patient.PCCode)
                .SetAttribute("PCEffectiveDate", Patient.PCEffectiveDate)
                .SetAttribute("PICode", Patient.PICode)
                .SetAttribute("PIEffectiveDate", Patient.PIEffectiveDate)

                .SetAttribute("LanguageCode", Patient.LanguageCode)

                ' Code by HJ 25 Nov 2013 End

                ' Code by HJ 28 Nov 2013 Start

                .SetAttribute("MotherLastName", Patient.MotherLastName)
                .SetAttribute("MotherFirstName", Patient.MotherFirstName)
                .SetAttribute("MultipleRace", Patient.MultipleRace.TrimEnd("|"))

                ' Code by HJ 28 Nov 2013 End

                ' START => Added by Affan Toor | Date: 24-03-14
                .SetAttribute("IsIncompleteStatus", Patient.IsIncompleteStatus)


                ' END => Added by Affan Toor | Date: 24-03-14
            End With

            lXmlDocument.DocumentElement.AppendChild(lXmlElement.CloneNode(True))

            If Connection.IsTransactionAlive() Then
                Connection.ExecuteTransactionCommand("InsertPatient", lXmlDocument.InnerXml.ToString)
            Else
                Connection.ExecuteCommand("InsertPatient", lXmlDocument.InnerXml.ToString)
            End If
        Catch ex As Exception
            Throw New Exception(ex.Message & " : DAL\PatientExtended.InsertRecord() ")
        End Try


    End Sub

    Public Overloads Sub UpdateRecord()
        Dim lCondition As String

        lCondition = "And PatientID = " & Me.Patient.PatientID
        UpdateRecord(lCondition)

    End Sub
    Public Overloads Sub UpdateRecord(ByVal lCondition As String)
        Dim lQuery As String

        Try
            With Me.Patient

                ''FormatData()

                lQuery = "Update Patient Set " _
                       & "Title ='" & .Title & "', " _
                       & "FirstName ='" & .FirstName & "', " _
                       & "MiddleName ='" & .MiddleName & "', " _
                       & "LastName ='" & .LastName & "', " _
                       & "AddressLine1 ='" & .AddressLine1 & "', " _
                       & "AddressLine2 ='" & .AddressLine2 & "', " _
                       & "City ='" & .City & "', " _
                       & "StateID ='" & .StateID & "', " _
                       & "ZipCode ='" & .ZipCode & "', " _
                       & "HousePhone ='" & .HomePhone & "', " _
                       & "WorkPhone ='" & .WorkPhone & "', " _
                       & "WorkPhoneExtension ='" & .WorkPhoneExtension & "', " _
                       & "Fax ='" & .Fax & "', " _
                       & "Email ='" & .Email & "', " _
                       & "Occupation ='" & .Occupation & "', " _
                       & "DOB ='" & .DOB & "', " _
                       & "Gender ='" & .Gender & "', " _
                       & "MartialStatus ='" & .MartialStatus & "', " _
                       & "NCPDPID ='" & .NCPDPID & "', " _
                       & "PharmacyName ='" & .PharmacyName & "', " _
                       & "PharmacyProvider ='" & .PharmacyProvider & "', " _
                       & "SSN ='" & .SSN & "', " _
                       & "PictureFilePath ='" & .PictureFilePath & "', " _
                       & "CardDrivingLicense ='" & .DrivingLicenseCardImage & "', " _
                       & "IsDeleted ='" & .IsDeleted & "'," _
                       & "CellPhoneNumber ='" & .CellPhoneNumber & "', " _
                       & "EmergencyContactName ='" & .EmergencyContactName & "', " _
                       & "EmergencyContactRelationship ='" & .EmergencyContactRelationship & "', " _
                       & "EmergencyContactPhone ='" & .EmergencyContactPhone & "'," _
                       & "EmergencyContactAddress ='" & .EmergencyContactAddress & "', " _
                       & "EmergencyContactCity ='" & .EmergencyContactCity & "', " _
                       & "EmergencyContactZip ='" & .EmergencyContactZip & "', " _
                       & "EmergencyContactState ='" & .EmergencyContactState & "', " _
                       & "EmployerName ='" & .EmployerName & "', " _
                       & "EmploymentStatus ='" & .EmploymentStatus & "', " _
                       & "EmployerAddressLine1 ='" & .EmployerAddressLine1 & "', " _
                       & "EmployerAddressLine2 ='" & .EmployerAddressLine2 & "', " _
                       & "EmployerPhoneNumber ='" & .EmployerPhoneNumber & "', " _
                       & "EmployerCity ='" & .EmployerCity & "', " _
                       & "EmployerZip ='" & .EmployerZip & "', " _
                       & "EmployerState ='" & .EmployerState & "', " _
                       & "ResponsibleName ='" & .ResponsibleName & "', " _
                       & "ResponsibleRelationship ='" & .ResponsibleRelationship & "', " _
                       & "ResponsibleHomePhone ='" & .ResponsibleHomePhone & "'," _
                       & "ResponsibleWorkPhone ='" & .ResponsibleWorkPhone & "', " _
                       & "ResponsibleAddress ='" & .ResponsibleAddress & "', " _
                       & "ResponsibleSSN ='" & .ResponsibleSSN & "', " _
                       & "ResponsibleCity ='" & .ResponsibleCity & "', " _
                       & "ResponsibleState ='" & .ResponsibleState & "', " _
                       & "ResponsibleZip ='" & .ResponsibleZip & "', " _
                       & "NCPDPID2 ='" & .NCPDPID2 & "', " _
                       & "PharmacyName2='" & .PharmacyName2 & "', " _
                       & "PharmacyProvider2 ='" & .PharmacyProvider2 & "', " _
                       & "EmergencyContactName2 ='" & .EmergencyContactName2 & "', " _
                       & "EmergencyContactRelationship2 ='" & .EmergencyContactRelationship2 & "', " _
                       & "EmergencyContactPhone2 ='" & .EmergencyContactPhone2 & "', " _
                       & "PreferredHomePh ='" & .PreferredHomePh & "', " _
                       & "PreferredWorkPh ='" & .PreferredWorkPh & "', " _
                       & "PreferredCellPh ='" & .PreferredCellPh & "', " _
                       & "EmployeeDesignation ='" & .EmployeeDesignation & "', " _
                       & "GuarantorId ='" & .GuarantorId & "', " _
                       & "PatientisaGuarantor ='" & .PatientisGuarantor & "' ," _
                       & "AccessMedHistory ='" & .AccessMedHistory & "' ," _
                       & "Race ='" & .Race & "' ," _
                       & "LanguageCode ='" & .LanguageCode & "' ," _
                       & "Language ='" & .Language & "' ," _
                       & "IsTransfered ='" & .IsTransfered & "' ," _
                       & "TransferedBy ='" & .TransferedBy & "' ," _
                       & "CommunicationMethod ='" & .CommunicationMethod & "' ," _
                       & "TransferedDate ='" & .TransferedDate & "' ," _
                       & "ReferredTo ='" & .ReferredTo & "' ," _
                       & "MotherLastName ='" & .MotherLastName & "' ," _
                       & "MotherFirstName ='" & .MotherFirstName & "' ," _
                       & "ImmunizationRegistryStatus ='" & .ImmunizationRegistryStatus & "' ," _
                       & "IRSCode ='" & .IRSCode & "' ," _
                       & "IRSEffectiveDate ='" & .IRSEffectiveDate & "' ," _
                       & "PublicityCode ='" & .PublicityCode & "' ," _
                       & "PCCode ='" & .PCCode & "' ," _
                       & "PCEffectiveDate ='" & .PCEffectiveDate & "' ," _
                       & "PICode ='" & .PICode & "' ," _
                       & "PIEffectiveDate ='" & .PIEffectiveDate & "' ," _
                       & "Ethinicity ='" & .Ethinicty & "', " _
                       & "MultipleRace ='" & .MultipleRace.ToString().TrimEnd("|") & "' " _
                       & "Where 1 = 1 " _
                       & lCondition
            End With

            If Connection.IsTransactionAlive() Then
                Connection.ExecuteTransactionCommand(lQuery)
            Else
                Connection.ExecuteCommand(lQuery)
            End If
        Catch ex As Exception
            Throw New Exception(ex.Message & " : DAL\PatientExtended.UpdateRecord(ByVal lCondition As String) ")
        End Try


    End Sub

    Public Sub UpdatePatientInCompleteRecord()
        Dim lQuery As String

        Try
            Dim lCondition As String
            lCondition = "And PatientID = " & Me.Patient.PatientID

            With Me.Patient

                ''FormatData()

                lQuery = "Update Patient Set " _
                       & "FirstName ='" & .FirstName & "', " _
                       & "LastName ='" & .LastName & "', " _
                       & "HousePhone ='" & .HomePhone & "', " _
                       & "DOB ='" & .DOB & "', " _
                       & "Gender ='" & .Gender & "', " _
                       & "IsDeleted ='N', " _
                       & "IsIncompleteStatus = 'N' " _
                       & "Where 1 = 1 " _
                       & lCondition
            End With

            If Connection.IsTransactionAlive() Then
                Connection.ExecuteTransactionCommand(lQuery)
            Else
                Connection.ExecuteCommand(lQuery)
            End If
        Catch ex As Exception
            Throw New Exception(ex.Message & " : DAL\PatientExtended.UpdatePatientInCompleteRecord() ")
        End Try

    End Sub
    Public Sub UpdateRecordPreview()
        Dim lQuery As String

        Try
            Dim lCondition As String
            lCondition = "And PatientID = " & Me.Patient.PatientID

            With Me.Patient

                ''FormatData()

                lQuery = "Update Patient Set " _
                       & "FirstName ='" & .FirstName & "', " _
                       & "MiddleName ='" & .MiddleName & "', " _
                       & "LastName ='" & .LastName & "', " _
                       & "AddressLine1 ='" & .AddressLine1 & "', " _
                       & "AddressLine2 ='" & .AddressLine2 & "', " _
                       & "City ='" & .City & "', " _
                       & "StateID ='" & .StateID & "', " _
                       & "ZipCode ='" & .ZipCode & "', " _
                       & "HousePhone ='" & .HomePhone & "', " _
                       & "DOB ='" & .DOB & "', " _
                       & "Gender ='" & .Gender & "', " _
                       & "ResponsibleName ='" & .ResponsibleName & "', " _
                       & "ResponsibleRelationship ='" & .ResponsibleRelationship & "', " _
                       & "ResponsibleHomePhone ='" & .ResponsibleHomePhone & "'," _
                       & "ResponsibleWorkPhone ='" & .ResponsibleWorkPhone & "', " _
                       & "ResponsibleAddress ='" & .ResponsibleAddress & "', " _
                       & "ResponsibleSSN ='" & .ResponsibleSSN & "', " _
                       & "ResponsibleCity ='" & .ResponsibleCity & "', " _
                       & "ResponsibleState ='" & .ResponsibleState & "', " _
                       & "ResponsibleZip ='" & .ResponsibleZip & "' " _
                       & "Where 1 = 1 " _
                       & lCondition
            End With

            If Connection.IsTransactionAlive() Then
                Connection.ExecuteTransactionCommand(lQuery)
            Else
                Connection.ExecuteCommand(lQuery)
            End If
        Catch ex As Exception
            Throw New Exception(ex.Message & " : DAL\PatientExtended.UpdateRecordPreview() ")
        End Try

    End Sub

    Public Overloads Function GetRecordByID() As Boolean
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()


        Try

            lSpParameter(0).ParameterName = "@Table"
            lSpParameter(0).ParameterType = ParameterType.Varchar
            lSpParameter(0).ParameterValue = "Patient"

            lSpParameter(1).ParameterName = "@Cond"
            lSpParameter(1).ParameterType = ParameterType.Varchar
            lSpParameter(1).ParameterValue = "And PatientID = " & Patient.PatientID

            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery("SelectAllRecords", lSpParameter)
            Else
                lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
            End If


            With lDs.Tables(0)
                If .Rows.Count > 0 Then

                    Me.Patient.PatientID = .Rows(0)("PatientID")
                    Me.Patient.Title = .Rows(0)("Title")
                    Me.Patient.Occupation = .Rows(0)("Occupation")
                    Me.Patient.MartialStatus = .Rows(0)("MartialStatus")
                    Me.Patient.FirstName = .Rows(0)("FirstName")
                    Me.Patient.MiddleName = .Rows(0)("MiddleName")
                    Me.Patient.LastName = .Rows(0)("LastName")
                    Me.Patient.AddressLine1 = .Rows(0)("AddressLine1")
                    Me.Patient.AddressLine2 = .Rows(0)("AddressLine2")
                    Me.Patient.City = .Rows(0)("City")
                    Me.Patient.StateID = .Rows(0)("StateID")
                    Me.Patient.ZipCode = .Rows(0)("ZipCode")
                    Me.Patient.HomePhone = .Rows(0)("HousePhone")
                    Me.Patient.WorkPhone = .Rows(0)("WorkPhone")
                    Me.Patient.WorkPhoneExtension = .Rows(0)("WorkPhoneExtension")
                    Me.Patient.Fax = .Rows(0)("Fax")
                    Me.Patient.Email = .Rows(0)("Email")
                    Me.Patient.Occupation = .Rows(0)("Occupation")
                    Me.Patient.DOB = .Rows(0)("DOB")
                    Me.Patient.Gender = .Rows(0)("Gender")
                    Me.Patient.NCPDPID = .Rows(0)("NCPDPID")
                    Me.Patient.NCPDPID2 = .Rows(0)("NCPDPID2")
                    Me.Patient.PharmacyName = .Rows(0)("PharmacyName")
                    Me.Patient.PharmacyName2 = .Rows(0)("PharmacyName2")
                    Me.Patient.PharmacyProvider = .Rows(0)("PharmacyProvider")
                    Me.Patient.PharmacyProvider2 = .Rows(0)("PharmacyProvider2")
                    Me.Patient.SSN = .Rows(0)("SSN")
                    Me.Patient.IsDeleted = .Rows(0)("IsDeleted")
                    Me.Patient.PictureFilePath = .Rows(0)("PictureFilePath")
                    Me.Patient.CellPhoneNumber = .Rows(0)("CellPhoneNumber")
                    Me.Patient.EmergencyContactName = .Rows(0)("EmergencyContactName")
                    Me.Patient.EmergencyContactRelationship = .Rows(0)("EmergencyContactRelationship")
                    Me.Patient.EmergencyContactPhone = .Rows(0)("EmergencyContactPhone")
                    Me.Patient.EmergencyContactAddress = .Rows(0)("EmergencyContactAddress")
                    Me.Patient.EmergencyContactCity = .Rows(0)("EmergencyContactCity")
                    Me.Patient.EmergencyContactZip = .Rows(0)("EmergencyContactZip")
                    Me.Patient.EmergencyContactState = .Rows(0)("EmergencyContactState")
                    Me.Patient.EmployerName = .Rows(0)("EmployerName")
                    Me.Patient.EmploymentStatus = .Rows(0)("EmploymentStatus")
                    Me.Patient.EmployerAddressLine1 = .Rows(0)("EmployerAddressLine1")
                    Me.Patient.EmployerAddressLine2 = .Rows(0)("EmployerAddressLine2")
                    Me.Patient.EmployerPhoneNumber = .Rows(0)("EmployerPhoneNumber")
                    Me.Patient.EmployerCity = .Rows(0)("EmployerCity")
                    Me.Patient.EmployerZip = .Rows(0)("EmployerZip")
                    Me.Patient.EmployerState = .Rows(0)("EmployerState")
                    ''Added by Madiha on 01/08/2011 for cardscan

                    Me.Patient.DrivingLicenseCardImage = .Rows(0)("CardDrivingLicense").ToString

                    Me.Patient.ResponsibleName = .Rows(0)("ResponsibleName")
                    Me.Patient.ResponsibleRelationship = .Rows(0)("ResponsibleRelationship")
                    Me.Patient.ResponsibleHomePhone = .Rows(0)("ResponsibleHomePhone")
                    Me.Patient.ResponsibleWorkPhone = .Rows(0)("ResponsibleWorkPhone")
                    Me.Patient.ResponsibleAddress = .Rows(0)("ResponsibleAddress")
                    Me.Patient.ResponsibleSSN = .Rows(0)("ResponsibleSSN")
                    Me.Patient.ResponsibleCity = .Rows(0)("ResponsibleCity")
                    Me.Patient.ResponsibleState = .Rows(0)("ResponsibleState")
                    Me.Patient.ResponsibleZip = .Rows(0)("ResponsibleZip")


                    Me.Patient.EmergencyContactName2 = .Rows(0)("EmergencyContactName2")
                    Me.Patient.EmergencyContactRelationship2 = .Rows(0)("EmergencyContactRelationship2")
                    Me.Patient.EmergencyContactPhone2 = .Rows(0)("EmergencyContactPhone2")
                    Me.Patient.PreferredHomePh = .Rows(0)("PreferredHomePh")
                    Me.Patient.PreferredWorkPh = .Rows(0)("PreferredWorkPh")
                    Me.Patient.PreferredCellPh = .Rows(0)("PreferredCellPh")
                    ''Added by Madiha on 20/12/2009
                    Me.Patient.EmployeeDesignation = .Rows(0)("EmployeeDesignation")
                    Me.Patient.PatientisGuarantor = .Rows(0)("PatientisaGuarantor")
                    Me.Patient.GuarantorId = .Rows(0)("GuarantorId")

                    'Added by Imran Khan on 04/05/2012
                    Me.Patient.Race = .Rows(0)("Race")
                    Me.Patient.Language = .Rows(0)("Language")
                    Me.Patient.Ethinicty = .Rows(0)("Ethinicity")
                    Me.Patient.AccessMedHistory = .Rows(0)("AccessMedHistory")
                    Me.Patient.IsMedicationActive = .Rows(0)("IsMedicationActive")
                    Me.Patient.IsTransfered = .Rows(0)("IsTransfered").ToString
                    Me.Patient.TransferedBy = .Rows(0)("TransferedBy").ToString
                    Me.Patient.CommunicationMethod = .Rows(0)("CommunicationMethod").ToString
                    Me.Patient.TransferedDate = .Rows(0)("TransferedDate").ToString
                    Me.Patient.ReferredTo = .Rows(0)("ReferredTo").ToString

                    ' Code by HJ 25 Nov 2013 Start
                    'Me.Patient.MotherMaidenName = .Rows(0)("MotherMaidenName")
                    Me.Patient.ImmunizationRegistryStatus = .Rows(0)("ImmunizationRegistryStatus").ToString()
                    Me.Patient.IRSCode = .Rows(0)("IRSCode").ToString()
                    Me.Patient.IRSEffectiveDate = If(IsDBNull(.Rows(0)("IRSEffectiveDate")), New Date(), .Rows(0)("IRSEffectiveDate"))
                    Me.Patient.PublicityCode = .Rows(0)("PublicityCode").ToString()
                    Me.Patient.PCCode = .Rows(0)("PCCode").ToString()
                    Me.Patient.PCEffectiveDate = If(IsDBNull(.Rows(0)("PCEffectiveDate")), New Date(), .Rows(0)("PCEffectiveDate"))
                    Me.Patient.PICode = .Rows(0)("PICode").ToString()
                    Me.Patient.PIEffectiveDate = If(IsDBNull(.Rows(0)("PCEffectiveDate")), New Date(), .Rows(0)("PIEffectiveDate"))

                    ' Code by HJ 25 Nov 2013 End

                    ' Code by HJ 28 Nov 2013 Start

                    Me.Patient.MotherLastName = .Rows(0)("MotherLastName").ToString
                    Me.Patient.MotherFirstName = .Rows(0)("MotherFirstName").ToString
                    Me.Patient.MultipleRace = IIf(IsDBNull(.Rows(0)("MultipleRace")), "", .Rows(0)("MultipleRace"))


                    ' Code by HJ 28 Nov 2013 End

                    Return (True)
                Else
                    Return False
                End If
            End With
        Catch ex As Exception
            Throw New Exception(ex.Message & " : DAL\PatientExtended.GetRecordByID() ")
        End Try


    End Function

    Public Overloads Function GetRecordByID(ByVal lDT As DataTable) As Boolean
        Try

            With lDT
                If .Rows.Count > 0 Then
                    Me.Patient.PatientID = .Rows(0)("PatientID")
                    Me.Patient.Title = .Rows(0)("Title")
                    Me.Patient.Occupation = .Rows(0)("Occupation")
                    Me.Patient.MartialStatus = .Rows(0)("MartialStatus")
                    Me.Patient.FirstName = .Rows(0)("FirstName")
                    Me.Patient.MiddleName = .Rows(0)("MiddleName")
                    Me.Patient.LastName = .Rows(0)("LastName")
                    Me.Patient.AddressLine1 = .Rows(0)("AddressLine1")
                    Me.Patient.AddressLine2 = .Rows(0)("AddressLine2")
                    Me.Patient.City = .Rows(0)("City")
                    Me.Patient.StateID = .Rows(0)("Abbr")
                    Me.Patient.ZipCode = .Rows(0)("ZipCode")
                    Me.Patient.HomePhone = .Rows(0)("HousePhone")
                    Me.Patient.WorkPhone = .Rows(0)("WorkPhone")
                    Me.Patient.WorkPhoneExtension = .Rows(0)("WorkPhoneExtension")
                    Me.Patient.Fax = .Rows(0)("Fax")
                    Me.Patient.Email = .Rows(0)("Email")
                    Me.Patient.Occupation = .Rows(0)("Occupation")
                    Me.Patient.DOB = .Rows(0)("DOB")
                    Me.Patient.Gender = .Rows(0)("Gender")
                    Me.Patient.NCPDPID = .Rows(0)("NCPDPID")
                    Me.Patient.NCPDPID2 = .Rows(0)("NCPDPID2")
                    Me.Patient.PharmacyName = .Rows(0)("PharmacyName")
                    Me.Patient.PharmacyName2 = .Rows(0)("PharmacyName2")
                    Me.Patient.PharmacyProvider = .Rows(0)("PharmacyProvider")
                    Me.Patient.PharmacyProvider2 = .Rows(0)("PharmacyProvider2")
                    Me.Patient.SSN = .Rows(0)("SSN")
                    Me.Patient.IsDeleted = .Rows(0)("IsDeleted")
                    Me.Patient.PictureFilePath = .Rows(0)("PictureFilePath")
                    Me.Patient.CellPhoneNumber = .Rows(0)("CellPhoneNumber")
                    Me.Patient.EmergencyContactName = .Rows(0)("EmergencyContactName")
                    Me.Patient.EmergencyContactRelationship = .Rows(0)("EmergencyContactRelationship")
                    Me.Patient.EmergencyContactPhone = .Rows(0)("EmergencyContactPhone")
                    Me.Patient.EmergencyContactAddress = .Rows(0)("EmergencyContactAddress")
                    Me.Patient.EmergencyContactCity = .Rows(0)("EmergencyContactCity")
                    Me.Patient.EmergencyContactZip = .Rows(0)("EmergencyContactZip")
                    Me.Patient.EmergencyContactState = .Rows(0)("EmergencyContactState")
                    Me.Patient.EmployerName = .Rows(0)("EmployerName")
                    Me.Patient.EmploymentStatus = .Rows(0)("EmploymentStatus")
                    Me.Patient.EmployerAddressLine1 = .Rows(0)("EmployerAddressLine1")
                    Me.Patient.EmployerAddressLine2 = .Rows(0)("EmployerAddressLine2")
                    Me.Patient.EmployerPhoneNumber = .Rows(0)("EmployerPhoneNumber")
                    Me.Patient.EmployerCity = .Rows(0)("EmployerCity")
                    Me.Patient.EmployerZip = .Rows(0)("EmployerZip")
                    Me.Patient.EmployerState = .Rows(0)("EmployerState")

                    Me.Patient.ResponsibleName = .Rows(0)("ResponsibleName")
                    Me.Patient.ResponsibleRelationship = .Rows(0)("ResponsibleRelationship")
                    Me.Patient.ResponsibleHomePhone = .Rows(0)("ResponsibleHomePhone")
                    Me.Patient.ResponsibleWorkPhone = .Rows(0)("ResponsibleWorkPhone")
                    Me.Patient.ResponsibleAddress = .Rows(0)("ResponsibleAddress")
                    Me.Patient.ResponsibleSSN = .Rows(0)("ResponsibleSSN")
                    Me.Patient.ResponsibleCity = .Rows(0)("ResponsibleCity")
                    Me.Patient.ResponsibleState = .Rows(0)("ResponsibleState")
                    Me.Patient.ResponsibleZip = .Rows(0)("ResponsibleZip")

                    Me.Patient.EmergencyContactName2 = .Rows(0)("EmergencyContactName2")
                    Me.Patient.EmergencyContactRelationship2 = .Rows(0)("EmergencyContactRelationship2")
                    Me.Patient.EmergencyContactPhone2 = .Rows(0)("EmergencyContactPhone2")
                    Me.Patient.PreferredHomePh = .Rows(0)("PreferredHomePh")
                    Me.Patient.PreferredWorkPh = .Rows(0)("PreferredWorkPh")
                    Me.Patient.PreferredCellPh = .Rows(0)("PreferredCellPh")
                    ''Added by Madiha on 20/12/2009
                    Me.Patient.EmployeeDesignation = .Rows(0)("EmployeeDesignation")

                    Return True
                Else
                    Return False
                End If
            End With
        Catch ex As Exception
            Throw New Exception(ex.Message & " : DAL\PatientExtended.GetRecordByID(ByVal lDT As DataTable) ")
        End Try


    End Function
    Public Overloads Function GetPatientWithDetailsByID() As Boolean
        Dim lSpParameter(0) As SpParameter
        Dim lDs As New DataSet()


        Try

            lSpParameter(0).ParameterName = "@PatientId"
            lSpParameter(0).ParameterType = ParameterType.BigInt
            lSpParameter(0).ParameterValue = Patient.PatientID


            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery("GetPatientWithDetails", lSpParameter)
            Else
                lDs = Connection.ExecuteQuery("GetPatientWithDetails", lSpParameter)
            End If


            With lDs.Tables(0)
                If .Rows.Count > 0 Then

                    Me.Patient.PatientID = .Rows(0)("PatientID")
                    Me.Patient.Title = .Rows(0)("Title")
                    Me.Patient.Occupation = .Rows(0)("Occupation")
                    Me.Patient.MartialStatus = .Rows(0)("MartialStatus")
                    Me.Patient.FirstName = .Rows(0)("FirstName")
                    Me.Patient.MiddleName = .Rows(0)("MiddleName")
                    Me.Patient.LastName = .Rows(0)("LastName")
                    Me.Patient.AddressLine1 = .Rows(0)("AddressLine1")
                    Me.Patient.AddressLine2 = .Rows(0)("AddressLine2")
                    Me.Patient.City = .Rows(0)("City")
                    Me.Patient.StateID = .Rows(0)("StateID")
                    Me.Patient.ZipCode = .Rows(0)("ZipCode")
                    Me.Patient.HomePhone = .Rows(0)("HousePhone")
                    Me.Patient.WorkPhone = .Rows(0)("WorkPhone")
                    Me.Patient.WorkPhoneExtension = .Rows(0)("WorkPhoneExtension")
                    Me.Patient.Fax = .Rows(0)("Fax")
                    Me.Patient.Email = .Rows(0)("Email")
                    Me.Patient.Occupation = .Rows(0)("Occupation")
                    Me.Patient.DOB = .Rows(0)("DOB")
                    Me.Patient.Gender = .Rows(0)("Gender")
                    Me.Patient.NCPDPID = .Rows(0)("NCPDPID")
                    Me.Patient.NCPDPID2 = .Rows(0)("NCPDPID2")
                    Me.Patient.PharmacyName = .Rows(0)("PharmacyName")
                    Me.Patient.PharmacyName2 = .Rows(0)("PharmacyName2")
                    Me.Patient.PharmacyProvider = .Rows(0)("PharmacyProvider")
                    Me.Patient.PharmacyProvider2 = .Rows(0)("PharmacyProvider2")
                    Me.Patient.SSN = .Rows(0)("SSN")
                    ''''''''''''''Jugar kaam baad main sahi kerna hai State ki abbrivation k liay
                    Me.Patient.IsDeleted = .Rows(0)("Abbr")
                    ''''''''''''''Jugar kaam baad main sahi kerna hai
                    Me.Patient.PictureFilePath = .Rows(0)("PictureFilePath")
                    Me.Patient.CellPhoneNumber = .Rows(0)("CellPhoneNumber")
                    Me.Patient.EmergencyContactName = .Rows(0)("EmergencyContactName")
                    Me.Patient.EmergencyContactRelationship = .Rows(0)("EmergencyContactRelationship")
                    Me.Patient.EmergencyContactPhone = .Rows(0)("EmergencyContactPhone")
                    Me.Patient.EmergencyContactAddress = .Rows(0)("EmergencyContactAddress")
                    Me.Patient.EmergencyContactCity = .Rows(0)("EmergencyContactCity")
                    Me.Patient.EmergencyContactZip = .Rows(0)("EmergencyContactZip")
                    Me.Patient.EmergencyContactState = .Rows(0)("EmergencyContactState")
                    Me.Patient.EmployerName = .Rows(0)("EmployerName")
                    Me.Patient.EmploymentStatus = .Rows(0)("EmploymentStatus")
                    Me.Patient.EmployerAddressLine1 = .Rows(0)("EmployerAddressLine1")
                    Me.Patient.EmployerAddressLine2 = .Rows(0)("EmployerAddressLine2")
                    Me.Patient.EmployerPhoneNumber = .Rows(0)("EmployerPhoneNumber")
                    Me.Patient.EmployerCity = .Rows(0)("EmployerCity")
                    Me.Patient.EmployerZip = .Rows(0)("EmployerZip")
                    Me.Patient.LanguageCode = IIf(IsDBNull(.Rows(0)("code")), "", .Rows(0)("code"))

                    Me.Patient.EmployerState = .Rows(0)("EmployerState")

                    ' added by Affan Toor on June 04, 2012
                    Try
                        Me.Patient.Race = .Rows(0)("Race")
                        Me.Patient.Ethinicty = .Rows(0)("Ethinicity")
                    Catch ex As Exception
                        ' no worries, keep going...
                    End Try

                    Me.Patient.ResponsibleName = .Rows(0)("ResponsibleName")
                    Me.Patient.ResponsibleRelationship = .Rows(0)("ResponsibleRelationship")
                    Me.Patient.ResponsibleHomePhone = .Rows(0)("ResponsibleHomePhone")
                    Me.Patient.ResponsibleWorkPhone = .Rows(0)("ResponsibleWorkPhone")
                    Me.Patient.ResponsibleAddress = .Rows(0)("ResponsibleAddress")
                    Me.Patient.ResponsibleSSN = .Rows(0)("ResponsibleSSN")
                    Me.Patient.ResponsibleCity = .Rows(0)("ResponsibleCity")
                    Me.Patient.ResponsibleState = .Rows(0)("ResponsibleState")
                    Me.Patient.ResponsibleZip = .Rows(0)("ResponsibleZip")

                    Me.Patient.EmergencyContactName2 = .Rows(0)("EmergencyContactName2")
                    Me.Patient.EmergencyContactRelationship2 = .Rows(0)("EmergencyContactRelationship2")
                    Me.Patient.EmergencyContactPhone2 = .Rows(0)("EmergencyContactPhone2")
                    Me.Patient.PreferredHomePh = .Rows(0)("PreferredHomePh")
                    Me.Patient.PreferredWorkPh = .Rows(0)("PreferredWorkPh")
                    Me.Patient.PreferredCellPh = .Rows(0)("PreferredCellPh")
                    ''Added by Madiha on 20/12/2009
                    Me.Patient.EmployeeDesignation = .Rows(0)("EmployeeDesignation")


                    Me.Patient.ImmunizationRegistryStatus = IIf(IsDBNull(.Rows(0)("ImmunizationRegistryStatus")), "", .Rows(0)("ImmunizationRegistryStatus")) '.Rows(0)("ImmunizationRegistryStatus")
                    Me.Patient.IRSCode = IIf(IsDBNull(.Rows(0)("IRSCode")), "", .Rows(0)("IRSCode")) '.Rows(0)("IRSCode")
                    Me.Patient.IRSEffectiveDate = IIf(IsDBNull(.Rows(0)("IRSEffectiveDate")), "", .Rows(0)("IRSEffectiveDate")) ' .Rows(0)("IRSEffectiveDate")
                    Me.Patient.PublicityCode = IIf(IsDBNull(.Rows(0)("PublicityCode")), "", .Rows(0)("PublicityCode")) ' .Rows(0)("PublicityCode")
                    Me.Patient.PCCode = IIf(IsDBNull(.Rows(0)("PCCode")), "", .Rows(0)("PCCode")) ' .Rows(0)("PCCode")
                    Me.Patient.PCEffectiveDate = IIf(IsDBNull(.Rows(0)("PCEffectiveDate")), "", .Rows(0)("PCEffectiveDate")) ' .Rows(0)("PCEffectiveDate")
                    Me.Patient.PICode = IIf(IsDBNull(.Rows(0)("PICode")), "", .Rows(0)("PICode")) '.Rows(0)("PICode")
                    Me.Patient.PIEffectiveDate = IIf(IsDBNull(.Rows(0)("PIEffectiveDate")), "", .Rows(0)("PIEffectiveDate")) '.Rows(0)("PIEffectiveDate")

                    ' Code by HJ 25 Nov 2013 End
                    Me.Patient.GuarantorId = IIf(IsDBNull(.Rows(0)("GuarantorId")), "", .Rows(0)("GuarantorId")) 'GuarantorId
                    ' Code by HJ 28 Nov 2013 Start

                    Me.Patient.MotherLastName = IIf(IsDBNull(.Rows(0)("MotherLastName")), "", .Rows(0)("MotherLastName")) '.Rows(0)("MotherLastName").ToString
                    Me.Patient.MotherFirstName = IIf(IsDBNull(.Rows(0)("MotherFirstName")), "", .Rows(0)("MotherFirstName")) '.Rows(0)("MotherFirstName").ToString
                    Me.Patient.MultipleRace = IIf(IsDBNull(.Rows(0)("MultipleRace")), "", .Rows(0)("MultipleRace")) '.Rows(0)("MotherFirstName").ToString

                    ' Code by HJ 28 Nov 2013 End



                    Dim lTotalRecords As Integer = .Rows.Count
                    ''Insurance logic

                    ''PrimaryInsurance
                    Dim i As Integer = 0
                    For i = 0 To .Rows.Count - 1
                        If (Not (IsDBNull(.Rows(i)("Type")) And IsDBNull(.Rows(i)("InsuranceCompanyID")) And IsDBNull(.Rows(i)("InsuranceCompany")) And IsDBNull(.Rows(i)("PayerId")) And IsDBNull(.Rows(i)("Active")))) Then
                            If (.Rows(i)("Active").ToString = "Y" And .Rows(i)("Type").ToString = "P" And .Rows(i)("InsuranceCompanyID").ToString <> "0") Then
                                Me.Patient.PrimaryInsurance.InsurerId = .Rows(i)("InsurerId").ToString
                                Me.Patient.PrimaryInsurance.PayerId = .Rows(i)("PayerId").ToString
                                Me.Patient.PrimaryInsurance.InsuranceCompanyID = .Rows(i)("InsuranceCompanyId").ToString
                                Me.Patient.PrimaryInsurance.InsuranceCompanyName = .Rows(i)("InsuranceCompany").ToString
                                Me.Patient.PrimaryInsurance.RelationshipToPrimaryInsurer = .Rows(i)("RelationshipToPrimaryInsurer").ToString()
                                Me.Patient.PrimaryInsurance.SubscriberID = .Rows(i)("SubscriberID").ToString()
                                Me.Patient.PrimaryInsurance.GroupNo = .Rows(i)("GroupNo").ToString()
                                Me.Patient.PrimaryInsurance.PlanName = .Rows(i)("PlanName").ToString()
                            End If
                            If (.Rows(i)("Active").ToString = "Y" And .Rows(i)("Type").ToString = "P" And .Rows(i)("InsuranceCompanyID").ToString = "0" And Not (IsDBNull(.Rows(i)("CompanyId")))) Then
                                Me.Patient.PrimaryInsurance.InsurerId = .Rows(i)("InsurerId").ToString
                                Me.Patient.PrimaryInsurance.PayerId = .Rows(i)("Payer").ToString
                                Me.Patient.PrimaryInsurance.InsuranceCompanyID = .Rows(i)("CompanyId").ToString
                                Me.Patient.PrimaryInsurance.InsuranceCompanyName = .Rows(i)("CompanyName").ToString
                                Me.Patient.PrimaryInsurance.RelationshipToPrimaryInsurer = .Rows(i)("RelationshipToPrimaryInsurer").ToString()
                                Me.Patient.PrimaryInsurance.SubscriberID = .Rows(i)("SubscriberID").ToString()
                                Me.Patient.PrimaryInsurance.GroupNo = .Rows(i)("GroupNo").ToString()
                                Me.Patient.PrimaryInsurance.PlanName = .Rows(i)("PlanName").ToString()
                            End If
                        End If
                    Next i
                    ''PrimaryInsurance


                    ''SecondaryInsurance
                    'Dim i As Integer = 0
                    For i = 0 To .Rows.Count - 1
                        If (Not (IsDBNull(.Rows(i)("Type")) And IsDBNull(.Rows(i)("InsuranceCompanyID")) And IsDBNull(.Rows(i)("InsuranceCompany")) And IsDBNull(.Rows(i)("PayerId")) And IsDBNull(.Rows(i)("Active")))) Then
                            If (.Rows(i)("Active").ToString = "Y" And .Rows(i)("Type").ToString = "S" And .Rows(i)("InsuranceCompanyID").ToString <> "0") Then
                                Me.Patient.SecondaryInsurance.InsurerId = .Rows(i)("InsurerId").ToString
                                Me.Patient.SecondaryInsurance.PayerId = .Rows(i)("PayerId").ToString
                                Me.Patient.SecondaryInsurance.InsuranceCompanyID = .Rows(i)("InsuranceCompanyId").ToString
                                Me.Patient.SecondaryInsurance.InsuranceCompanyName = .Rows(i)("InsuranceCompany").ToString
                                Me.Patient.SecondaryInsurance.RelationshipToPrimaryInsurer = .Rows(i)("RelationshipToPrimaryInsurer").ToString()
                                Me.Patient.SecondaryInsurance.SubscriberID = .Rows(i)("SubscriberID").ToString()
                                Me.Patient.SecondaryInsurance.GroupNo = .Rows(i)("GroupNo").ToString()
                                Me.Patient.SecondaryInsurance.PlanName = .Rows(i)("PlanName").ToString()
                            End If
                            If (.Rows(i)("Active").ToString = "Y" And .Rows(i)("Type").ToString = "S" And .Rows(i)("InsuranceCompanyID").ToString = "0" And Not (IsDBNull(.Rows(i)("CompanyId")))) Then
                                Me.Patient.SecondaryInsurance.InsurerId = .Rows(i)("InsurerId").ToString
                                Me.Patient.SecondaryInsurance.PayerId = .Rows(i)("Payer").ToString
                                Me.Patient.SecondaryInsurance.InsuranceCompanyID = .Rows(i)("CompanyId").ToString
                                Me.Patient.SecondaryInsurance.InsuranceCompanyName = .Rows(i)("CompanyName").ToString
                                Me.Patient.SecondaryInsurance.RelationshipToPrimaryInsurer = .Rows(i)("RelationshipToPrimaryInsurer").ToString()
                                Me.Patient.SecondaryInsurance.SubscriberID = .Rows(i)("SubscriberID").ToString()
                                Me.Patient.SecondaryInsurance.GroupNo = .Rows(i)("GroupNo").ToString()
                                Me.Patient.SecondaryInsurance.PlanName = .Rows(i)("PlanName").ToString()
                            End If
                        End If
                    Next i
                    ''SecondaryInsurance


                    ''Tertiary Insurance
                    'Dim i As Integer = 0
                    For i = 0 To .Rows.Count - 1
                        If (Not (IsDBNull(.Rows(i)("Type")) And IsDBNull(.Rows(i)("InsuranceCompanyID")) And IsDBNull(.Rows(i)("InsuranceCompany")) And IsDBNull(.Rows(i)("PayerId")) And IsDBNull(.Rows(i)("Active")))) Then
                            If (.Rows(i)("Active").ToString = "Y" And .Rows(i)("Type").ToString = "T" And .Rows(i)("InsuranceCompanyID").ToString <> "0") Then
                                Me.Patient.TertiaryInsurance.InsurerId = .Rows(i)("InsurerId").ToString
                                Me.Patient.TertiaryInsurance.PayerId = .Rows(i)("PayerId").ToString
                                Me.Patient.TertiaryInsurance.InsuranceCompanyID = .Rows(i)("InsuranceCompanyId").ToString
                                Me.Patient.TertiaryInsurance.InsuranceCompanyName = .Rows(i)("InsuranceCompany").ToString
                                Me.Patient.TertiaryInsurance.RelationshipToPrimaryInsurer = .Rows(i)("RelationshipToPrimaryInsurer").ToString()
                                Me.Patient.TertiaryInsurance.SubscriberID = .Rows(i)("SubscriberID").ToString()
                                Me.Patient.TertiaryInsurance.GroupNo = .Rows(i)("GroupNo").ToString()
                                Me.Patient.TertiaryInsurance.PlanName = .Rows(i)("PlanName").ToString()
                            End If
                            If (.Rows(i)("Active").ToString = "Y" And .Rows(i)("Type").ToString = "T" And .Rows(i)("InsuranceCompanyID").ToString = "0" And Not (IsDBNull(.Rows(i)("CompanyId")))) Then
                                Me.Patient.TertiaryInsurance.InsurerId = .Rows(i)("InsurerId").ToString
                                Me.Patient.TertiaryInsurance.PayerId = .Rows(i)("Payer").ToString
                                Me.Patient.TertiaryInsurance.InsuranceCompanyID = .Rows(i)("CompanyId").ToString
                                Me.Patient.TertiaryInsurance.InsuranceCompanyName = .Rows(i)("CompanyName").ToString
                                Me.Patient.TertiaryInsurance.RelationshipToPrimaryInsurer = .Rows(i)("RelationshipToPrimaryInsurer").ToString()
                                Me.Patient.TertiaryInsurance.SubscriberID = .Rows(i)("SubscriberID").ToString()
                                Me.Patient.TertiaryInsurance.GroupNo = .Rows(i)("GroupNo").ToString()
                                Me.Patient.TertiaryInsurance.PlanName = .Rows(i)("PlanName").ToString()
                            End If
                        End If
                    Next i
                    ''tertiary Insurance


                    ''Insurance logic

                    Return True
                Else
                    Return False
                End If
            End With
        Catch ex As Exception
            Throw New Exception(ex.Message & " : DAL\PatientExtended.GetPatientWithDetailsByID() ")
        End Try

    End Function

    Public Function GetPatientEncounters(PatientID As Integer) As DataSet
        Dim lDs As DataSet

        Dim lSpParameter(0) As SpParameter



        Try
            lSpParameter(0).ParameterName = "@PatientId"
            lSpParameter(0).ParameterType = ParameterType.BigInt
            lSpParameter(0).ParameterValue = PatientID

            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery("GetPatientEncounters", lSpParameter)
            Else
                lDs = Connection.ExecuteQuery("GetPatientEncounters", lSpParameter)
            End If

            Return lDs
        Catch ex As Exception
            Throw New Exception(ex.Message & " : DAL\PatientExtended.GetPatientEncounters() ")
        End Try
    End Function

    Public Function GetPatientEncountersByID(PatientID As Integer, EncounterId As Integer) As DataSet
        Dim lDs As DataSet
        Dim lSpParameter(1) As SpParameter
        Try
            lSpParameter(0).ParameterName = "@PatientId"
            lSpParameter(0).ParameterType = ParameterType.BigInt
            lSpParameter(0).ParameterValue = PatientID

            lSpParameter(1).ParameterName = "@EncounterId"
            lSpParameter(1).ParameterType = ParameterType.BigInt
            lSpParameter(1).ParameterValue = EncounterId

            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery("GetPatientEncounterById", lSpParameter)
            Else
                lDs = Connection.ExecuteQuery("GetPatientEncounterById", lSpParameter)
            End If

            Return lDs
        Catch ex As Exception
            Throw New Exception(ex.Message & " : DAL\PatientExtended.GetPatientEncounterById() ")
        End Try
    End Function

    Public Function GetProceduresByPatientID(PatientID As Integer) As DataSet
        Dim lDs As DataSet
        Dim lSpParameter(0) As SpParameter
        Try
            lSpParameter(0).ParameterName = "@PatientId"
            lSpParameter(0).ParameterType = ParameterType.BigInt
            lSpParameter(0).ParameterValue = PatientID

            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery("GetProceduresByPatientID", lSpParameter)
            Else
                lDs = Connection.ExecuteQuery("GetProceduresByPatientID", lSpParameter)
            End If

            Return lDs
        Catch ex As Exception
            Throw New Exception(ex.Message & " : DAL\PatientExtended.GetProceduresByPatientID() ")
        End Try
    End Function

    Public Overloads Function GetPatientInsCompanyByID() As Boolean

        Dim lDs As New DataSet()


        Try

            Dim lQuery As String

            lQuery = "select PIns.[Type],PIns.InsuranceCompanyId,DIns.InsuranceCompanyId,IC.CompanyName from " _
                    & " patientinsurance PIns,Patientinsurance DIns,favouriteinsurance IC where PIns.patientid= " _
                   & Patient.PatientID & " and PIns.Active='Y' AND PIns.InsurerinsuranceId*=DIns.PatientInsID " _
                   & "AND IC.favouriteInsuranceid= case PIns.InsuranceCompanyId when 0 then DIns.InsuranceCompanyId else PIns.InsuranceCompanyId end"


            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If




            With lDs.Tables(0)
                If .Rows.Count > 0 Then


                    Dim i As Integer = 0
                    For i = 0 To .Rows.Count - 1

                        If (.Rows(i)("Type").ToString.ToUpper = "P") Then
                            Me.Patient.PrimaryInsurance.InsuranceCompanyName = .Rows(i)("CompanyName").ToString
                        ElseIf (.Rows(i)("Type").ToString.ToUpper = "S") Then
                            Me.Patient.SecondaryInsurance.InsuranceCompanyName = .Rows(i)("CompanyName").ToString
                        ElseIf (.Rows(i)("Type").ToString.ToUpper = "T") Then
                            Me.Patient.TertiaryInsurance.InsuranceCompanyName = .Rows(i)("CompanyName").ToString
                        End If


                    Next i

                    Return True
                Else
                    Return False
                End If
            End With
        Catch ex As Exception
            Throw New Exception(ex.Message & " : DAL\PatientExtended.GetPatientInsCompanyByID() ")
        End Try

    End Function

    Public Function GetPatientRelatedPersons() As DataSet
        Dim lDs As DataSet

        Dim lSpParameter(0) As SpParameter



        Try
            lSpParameter(0).ParameterName = "@PatientId"
            lSpParameter(0).ParameterType = ParameterType.BigInt
            lSpParameter(0).ParameterValue = Patient.PatientID

            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery("GetPatientRelatedPersons", lSpParameter)
            Else
                lDs = Connection.ExecuteQuery("GetPatientRelatedPersons", lSpParameter)
            End If

            Return lDs
        Catch ex As Exception
            Throw New Exception(ex.Message & " : DAL\PatientExtended.GetPatientRelatedPersons() ")
        End Try
    End Function
    Public Function GetPatientInsuranceHistory() As DataSet
        Dim lDs As DataSet

        Dim lSpParameter(0) As SpParameter


        Try
            lSpParameter(0).ParameterName = "@PatientId"
            lSpParameter(0).ParameterType = ParameterType.BigInt
            lSpParameter(0).ParameterValue = Patient.PatientID

            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery("GetPatientInsuranceHistory", lSpParameter)
            Else
                lDs = Connection.ExecuteQuery("GetPatientInsuranceHistory", lSpParameter)
            End If

            Return lDs
        Catch ex As Exception
            Throw New Exception(ex.Message & " : DAL\PatientExtended.GetPatientInsuranceHistory() ")
        End Try
    End Function

    Public Function GetPatientStatement(ByVal pCondition As String, ByVal pOrderby As String) As DataSet
        Dim lDs As DataSet

        Dim lSpParameter(2) As SpParameter



        Try
            lSpParameter(0).ParameterName = "@Cond"
            lSpParameter(0).ParameterType = ParameterType.Varchar
            lSpParameter(0).ParameterValue = pCondition

            lSpParameter(1).ParameterName = "@Ordrby"
            lSpParameter(1).ParameterType = ParameterType.Varchar
            lSpParameter(1).ParameterValue = pOrderby

            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery("SearchForGenerateStatement", lSpParameter)
            Else
                lDs = Connection.ExecuteQuery("SearchForGenerateStatement", lSpParameter)
            End If

            Return lDs
        Catch ex As Exception
            Throw New Exception(ex.Message & " : DAL\PatientExtended.SearchForGenerateStatement() ")
        End Try
    End Function

    Public Function GetPatientStatementinfo(ByVal pPatientID As String) As DataSet
        Dim lDs As DataSet
        Dim lQuery As String
        '        lQuery = "Select LastName + ', ' + FirstName as BillTo , " & _
        '" (select top 1 ClinicName from clinicInfo) as PlaceofService,(select top 1 AddressLine1 + ' ' + AddressLine2 from Clinicinfo) as ClinicInfo1" & _
        '",AddressLine1 + ' ' + AddressLine2 as PatientInformation1" & _
        '", Case when Len(ZipCode) > 5 then City + ' ' +  " & _
        ' " (select Abbr from [State] where StateID = Patient.StateID) + ' ' + Substring(ZipCode,1,5) + '-' + Substring(ZipCode,6,Len(ZipCode)) else City + ' ' +" & _
        ' " (select Abbr from [State] where StateID = Patient.StateID) + ' ' + ZipCode" & _
        ' " End" & _
        '" as PatientInformation2" & _
        '", Case when Len(select top 1 ZipCode from clinicInfo) > 5 then (select top 1 City from clinicInfo) + ' ' +  " & _
        ' " (select Abbr from [State] where StateID =(select top 1 StateID from clinicInfo)) + ' ' + Substring()select top 1 ZipCode from clinicInfo),1,5) + '-' + Substring((select top 1 ZipCode from clinicInfo),6,Len(select top 1 ZipCode from clinicInfo)) else (select top 1 City from clinicInfo) + ' ' +" & _
        ' " (select Abbr from [State] where StateID = (select top 1 StateID from clinicInfo)) + ' ' + select top 1 ZipCode from clinicInfo" & _
        ' " End" & _
        '" as Clinicinfo2" & _
        '",RIGHT('00000'+ CONVERT(VARCHAR,PatientID),5) as ChartNo,'(' + Substring(HousePhone,1,3) + ')-' + Substring(HousePhone,4,3)+ '-' + Substring(HousePhone,7,Len(HousePhone)) as Phone,EmployerName as ReferingPhysician," & _
        '" '000002' as StatementID,CONVERT(varchar,getdate(),101) as BillingDate" & _
        '" from Patient" & _
        '" where PatientID = " & pPatientID

        lQuery = "Select Case When MiddleName='' then FirstName + ' ' + LastName  else FirstName + ' ' +  MiddleName + ' ' + LastName End As BillTo , " & _
 "(select top 1 ClinicName from clinicInfo) as PlaceofService," & _
 "(select top 1 AddressLine1 + ' ' + AddressLine2 from Clinicinfo) as ClinicInfo1," & _
 "AddressLine1 + ' ' + AddressLine2 as PatientInformation1, " & _
 "Case when Len(ZipCode) > 5 " & _
 "then City + ', ' +   (select Abbr from [State] where StateID = Patient.StateID) + ' ' + " & _
 "Substring(ZipCode,1,5) + '-' + Substring(ZipCode,6,Len(ZipCode)) else " & _
 " City + ', ' + (select Abbr from [State] where StateID = Patient.StateID) + ' ' + ZipCode " & _
 "End as PatientInformation2, " & _
 "Case when Len((select top 1 ZipCode from clinicInfo)) > 5 " & _
"then (select top 1 City from clinicInfo) + ' ' +   (select Abbr from [State] where StateID =" & _
 "(select top 1 StateID from clinicInfo)) + ' ' + " & _
 "Substring((select top 1 ZipCode from clinicInfo),1,5) + '-' + " & _
 "Substring((select top 1 ZipCode from clinicInfo),6,Len((select top 1 ZipCode from clinicInfo))) " & _
 "else " & _
 "(select top 1 City from clinicInfo) + ' ' + " & _
  "(select Abbr from [State] where StateID = (select top 1 StateID from clinicInfo)) + ' ' + " & _
   "(select top 1 ZipCode from clinicInfo) End as Clinicinfo2, " & _
  " RIGHT('00000'+ CONVERT(VARCHAR,PatientID),5) " & _
   " as ChartNo,'(' + Substring(HousePhone,1,3) + ')-' + Substring(HousePhone,4,3)+ '-' + Substring(HousePhone,7,Len(HousePhone)) as Phone," & _
"'(' + Substring((select top 1 Phone1 from clinicInfo),1,3) + ')' + Substring((select top 1 Phone1 from clinicInfo),4,3)+  Substring((select top 1 Phone1 from clinicInfo),7,Len((select top 1 Phone1 from clinicInfo))) as ClinicPhone,EmployerName as ReferingPhysician, '000002' as StatementID,CONVERT(varchar,getdate(),101) as BillingDate from Patient" & _
   " where PatientID = " & pPatientID


        Try
            If Connection.IsTransactionAlive() Then

                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If

            Return lDs
        Catch ex As Exception
            Throw New Exception(ex.Message & " : DAL\PatientExtended.GetPatientStatementinfo() ")
        End Try

    End Function

    Public Function GetPatientStatementView(ByVal pPatientID As Integer) As DataSet
        Dim lDs As DataSet

        Dim lSpParameter(0) As SpParameter



        Try
            lSpParameter(0).ParameterName = "@PatientID"
            lSpParameter(0).ParameterType = ParameterType.BigInt
            lSpParameter(0).ParameterValue = pPatientID

            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery("PatientStatementView", lSpParameter)
            Else
                lDs = Connection.ExecuteQuery("PatientStatementView", lSpParameter)
            End If

            Return lDs
        Catch ex As Exception
            Throw New Exception(ex.Message & " : DAL\PatientExtended.SearchForGenerateStatement() ")
        End Try
    End Function
    Public Function GetPatientState(ByVal pStateID As Integer) As String
        Dim lDs As DataSet

        Try

            Dim lQuery As String = "Select Abbr from State where StateID=" & pStateID

            lDs = Connection.ExecuteQuery(lQuery)

            Return lDs.Tables(0).Rows(0).Item(0).ToString



        Catch ex As Exception
            Return ""
        End Try

    End Function
#End Region

End Class
