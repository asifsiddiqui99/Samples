Imports Microsoft.VisualBasic


Public Class PaymentCPTDetailDB

#Region "Fields"


    Private mLineID As String
    Private mPaymentDtlID As String
    Private mCPTCode As String
    Private mCharges As String
    Private mAllowedAmount As String
    Private mAmount As String
    Private mDeductable As String
    Private mCopay As String
    Private mPreviousInsurancePaymnent As String
    Private mPreviousPatientPaymnent As String
    Private mAdjustment As Double
    Private mDateOfService As String
    Private mPatientSuperBillID As String
    Private mCPTBalance As String
    Private mCPTId As String
    Private mAdjustmentCollection As New AdjustmentCollection

#End Region

#Region "Properties"

    Public Property LineID() As String
        Get
            Return mLineID
        End Get
        Set(ByVal value As String)
            mLineID = value
        End Set
    End Property

    Public Property PaymentDtlID() As String
        Get
            Return mPaymentDtlID
        End Get
        Set(ByVal value As String)
            mPaymentDtlID = value
        End Set
    End Property

    Public Property CPTCode() As String
        Get
            Return mCPTCode
        End Get
        Set(ByVal value As String)
            mCPTCode = value
        End Set
    End Property


    Public Property Charges() As String
        Get
            Return mCharges
        End Get
        Set(ByVal value As String)
            mCharges = value
        End Set
    End Property

    Public Property AllowedAmount() As String
        Get
            Return mAllowedAmount
        End Get
        Set(ByVal value As String)
            mAllowedAmount = value
        End Set
    End Property

    Public Property Amount() As String
        Get
            Return mAmount
        End Get
        Set(ByVal value As String)
            mAmount = value
        End Set
    End Property

    Public Property Deductable() As String
        Get
            Return mDeductable
        End Get
        Set(ByVal value As String)
            mDeductable = value
        End Set
    End Property

    Public Property Copay() As String
        Get
            Return mCopay
        End Get
        Set(ByVal value As String)
            mCopay = value
        End Set
    End Property

    Public Property AdjustmentCollection() As AdjustmentCollection
        Get
            Return mAdjustmentCollection
        End Get
        Set(ByVal value As AdjustmentCollection)
            mAdjustmentCollection = value
        End Set
    End Property

    Public Property PreviousPatientPaymnent() As String
        Get
            Return mPreviousPatientPaymnent
        End Get
        Set(ByVal value As String)
            mPreviousPatientPaymnent = value
        End Set
    End Property


    Public Property PreviousInsurancePaymnent() As String
        Get
            Return mPreviousInsurancePaymnent
        End Get
        Set(ByVal value As String)
            mPreviousInsurancePaymnent = value
        End Set
    End Property

    Public Property Adjustment() As Double
        Get
            Return mAdjustment
        End Get
        Set(ByVal value As Double)
            mAdjustment = value
        End Set
    End Property


    Public Property DateOfService() As String
        Get
            Return mDateOfService
        End Get
        Set(ByVal value As String)
            mDateOfService = value
        End Set
    End Property

    Public Property PatientSuperBillID() As String
        Get
            Return mPatientSuperBillID
        End Get
        Set(ByVal value As String)
            mPatientSuperBillID = value
        End Set
    End Property


    Public Property CPTBalance() As String
        Get
            Return mCPTBalance
        End Get
        Set(ByVal value As String)
            mCPTBalance = value
        End Set
    End Property


    Public Property CPTId() As String
        Get
            Return mCPTId
        End Get
        Set(ByVal value As String)
            mCPTId = value
        End Set
    End Property

#End Region


End Class

Public Class PaymentCPTDetail
    Implements IDetail


#Region "Fields"
    Private mConnection As Connection
    Private mConnectionString As String
    Private mPaymentCPTDetail As New PaymentCPTDetailDB
#End Region

#Region "Property"
    Public ReadOnly Property Connection() As ElixirLibrary.Connection Implements IDetail.Connection
        Get
            Return mConnection
        End Get
    End Property

    Public ReadOnly Property ConnectionString() As String Implements IDetail.ConnectionString
        Get
            Return mConnectionString
        End Get
    End Property
    Public Property PaymentCPTDetail() As PaymentCPTDetailDB
        Get
            Return mPaymentCPTDetail
        End Get
        Set(ByVal value As PaymentCPTDetailDB)
            mPaymentCPTDetail = value
        End Set
    End Property
#End Region

#Region "Constructor"
    ''' <summary>
    ''' Creates new Conection Object based on Given Connection String 
    ''' </summary>
    ''' <param name="pConnectionString">
    ''' Contains Connection String 
    ''' </param>
    ''' <remarks>
    ''' Use when not using transaction
    ''' Must Specify Connection String other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnectionString As String)
        If pConnectionString = "" Then
            Throw New ArgumentException("ConnectionString can not be empty")
        End If

        mConnectionString = pConnectionString
        mConnection = New Connection(mConnectionString)

    End Sub

    ''' <summary>
    ''' Assign given connection to the current Object
    ''' </summary>
    ''' <param name="pConnection">
    ''' Contains refrence to the connection object
    ''' </param>
    ''' <remarks>
    ''' Use when  using Transaction
    ''' Must Specify Connection other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnection As Connection)
        If pConnection Is Nothing Then
            Throw New ArgumentException("Connection can not be empty")
        End If

        mConnection = pConnection
    End Sub
#End Region

#Region "Method"
    ''' <summary>
    ''' Delete Record Acoording to Given Condition
    ''' </summary>
    ''' <param name="lCondition"></param>
    ''' <remarks></remarks>
    Public Sub DeleteRecord(ByVal lCondition As String) Implements IDetail.DeleteRecord

        Dim lSpParameter(1) As SpParameter

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "PaymentCPTDetail"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = lCondition

        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand("DeleteRecords", lSpParameter)
        Else
            Connection.ExecuteCommand("DeleteRecords", lSpParameter)
        End If

    End Sub
    ''' <summary>
    ''' Delete Record on Primary Key
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub DeleteRecordByID() Implements IDetail.DeleteRecordByID
        Dim lCondition As String

        lCondition = "AND PaymentDtlID= " & PaymentCPTDetail.PaymentDtlID
        DeleteRecord(lCondition)

    End Sub
    ''' <summary>
    ''' Get All Records unconditional
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetAllRecords() As System.Data.DataSet Implements IDetail.GetAllRecords
        Dim lCondition As String = ""
        Dim lDs As New DataSet()

        lDs = GetAllRecords(lCondition)

        Return lDs
    End Function
    ''' <summary>
    ''' Get  Records on specified Condition
    ''' </summary>
    ''' <param name="lCondition"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetAllRecords(ByVal lCondition As String) As System.Data.DataSet Implements IDetail.GetAllRecords
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "PaymentCPTDetail"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = lCondition

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("SelectAllRecords", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
        End If

        Return lDs

    End Function
    ''' <summary>
    ''' Insert record
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub InsertRecord() Implements IDetail.InsertRecord
        Throw New NotImplementedException
    End Sub
    Public Sub InsertPaymentCPTDtl(ByVal pPaymentId As String)
        Dim lXmlDocument As New XmlDocument
        Dim lXmlElement As XmlElement

        Try

            lXmlDocument.LoadXml("<PaymentCPTDetails></PaymentCPTDetails>")
            lXmlElement = lXmlDocument.CreateElement("PaymentCPTDetail")

            With lXmlElement
                .SetAttribute("PaymentDtlID", PaymentCPTDetail.PaymentDtlID)
                .SetAttribute("CPTCode", PaymentCPTDetail.CPTCode)
                .SetAttribute("Charges", PaymentCPTDetail.Charges)
                .SetAttribute("AllowedAmount", PaymentCPTDetail.AllowedAmount)
                .SetAttribute("Amount", PaymentCPTDetail.Amount)
                .SetAttribute("Deductable", PaymentCPTDetail.Deductable)
                .SetAttribute("Copay", PaymentCPTDetail.Copay)
                .SetAttribute("CptId", PaymentCPTDetail.CPTId)
            End With


            lXmlDocument.DocumentElement.AppendChild(lXmlElement.CloneNode(True))

            If ((PaymentCPTDetail.Amount <> 0) And (PaymentCPTDetail.Amount IsNot Nothing)) Then
                If Connection.IsTransactionAlive() Then
                    Connection.ExecuteTransactionCommand("InsertPaymentCPTDetail", lXmlDocument.InnerXml.ToString)
                Else
                    Connection.ExecuteCommand("InsertPaymentCPTDetail", lXmlDocument.InnerXml.ToString)
                End If
            End If


            InsertAdjustment(pPaymentId)

        Catch ex As Exception
            Throw New Exception(ex.Message + " : DAL\PaymentCPTDetail.InsertPaymentCPTDtl() ")
        End Try


    End Sub

    Public Sub InsertAdjustment(ByVal pPaymentId As String)
        Dim lAdjustment As New Adjustment(Connection)

        Try
            For Each lAdjustmentDB As AdjustmentDB In PaymentCPTDetail.AdjustmentCollection
                If (lAdjustmentDB.IsPrevious = "No") Then
                    lAdjustmentDB.PaymentID = pPaymentId                    
                    lAdjustmentDB.PaymentDtlID = PaymentCPTDetail.PaymentDtlID
                    'lAdjustmentDB.AdjustmentDate = PaymentCPTDetail.DateOfService
                    lAdjustment.Adjustment = lAdjustmentDB
                    lAdjustment.InsertRecord()
                End If

            Next

        Catch ex As Exception
            Throw
        End Try

    End Sub

    Public Sub InsertAdjustmentOnly(ByVal pPaymentId As String)
        Dim lAdjustment As New Adjustment(Connection)

        Try
            For Each lAdjustmentDB As AdjustmentDB In PaymentCPTDetail.AdjustmentCollection
                lAdjustmentDB.PaymentID = pPaymentId
                lAdjustmentDB.PaymentDtlID = PaymentCPTDetail.PaymentDtlID
                lAdjustment.Adjustment = lAdjustmentDB
                lAdjustment.InsertAdjustmentOnly()
            Next
        Catch ex As Exception
            Throw
        End Try

    End Sub


    Public Sub InsertRecord(ByVal pInsertPaymentCPTDetailXml As String)
        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand("InsertPaymentCPTDetail", pInsertPaymentCPTDetailXml)
        Else
            Connection.ExecuteCommand("InsertPaymentCPTDetail", pInsertPaymentCPTDetailXml)
        End If

    End Sub

   
    ''' <summary>
    ''' Update Record unconditional
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub UpdateRecord() Implements IDetail.UpdateRecord
        Dim lCondition As String

        lCondition = "And PaymentDtlID = " & Me.PaymentCPTDetail.PaymentDtlID
        UpdateRecord(lCondition)

    End Sub
    Public Sub UpdateRecord(ByVal lCondition As String) Implements IDetail.UpdateRecord

        Dim lQuery As String

        With Me.PaymentCPTDetail


            lQuery = "Update PaymentDtl Set " _
                   & "Charges =" & .Charges & ", " _
                   & "AllowedAmount =" & .AllowedAmount & ", " _
                   & "Amount =" & .Amount & ", " _
                   & "Deductable =" & .Deductable & ", " _
                   & "Copay =" & .Copay & ", " _
                   & "Where 1 = 1 " _
                   & lCondition


        End With

        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand(lQuery)
        Else
            Connection.ExecuteCommand(lQuery)
        End If
    End Sub
    
    ''' <summary>
    ''' Get Single Record By Primary Key
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetRecordByID() As Boolean Implements IDetail.GetRecordByID
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "PaymentCPTDetail"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = "And PaymentID = " & Me.PaymentCPTDetail.PaymentDtlID

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("SelectAllRecords", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
        End If


        With lDs.Tables(0)
            If .Rows.Count > 0 Then

                Me.PaymentCPTDetail.LineID = .Rows(0)("LineID")
                Me.PaymentCPTDetail.PaymentDtlID = .Rows(0)("PaymentDtlID")
                Me.PaymentCPTDetail.CPTCode = .Rows(0)("CPTCode")
                Me.PaymentCPTDetail.Charges = .Rows(0)("Charges")
                Me.PaymentCPTDetail.AllowedAmount = .Rows(0)("AllowedAmount")
                Me.PaymentCPTDetail.Amount = .Rows(0)("Amount")
                Me.PaymentCPTDetail.Deductable = .Rows(0)("Deductable")
                Me.PaymentCPTDetail.Copay = .Rows(0)("Copay")

                Return True
            End If
        End With

        Return False

    End Function

#End Region

End Class

Public Class PaymentCPTDetailCollection
    Inherits CollectionBase

    Public Function Add(ByVal pPaymentCPTDetail As PaymentCPTDetailDB) As Integer
        Return List.Add(pPaymentCPTDetail)
    End Function

    Public Sub Remove(ByVal pPaymentCPTDetail As PaymentCPTDetailDB)
        List.Remove(pPaymentCPTDetail)
    End Sub

    Default Public Property Item(ByVal Index As Integer) As PaymentCPTDetailDB
        Get
            Return CType(List.Item(Index), PaymentCPTDetailDB)
        End Get
        Set(ByVal Value As PaymentCPTDetailDB)
            List.Item(Index) = Value
        End Set
    End Property

    Public Shadows Function Count() As Integer
        Return List.Count
    End Function



End Class