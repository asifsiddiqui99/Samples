Imports Microsoft.VisualBasic

Public Class PatientStatementTransactionDtlDB
#Region "Fields"
    Private mStatementID As Integer = 0    
    Private mVisitID As Integer = 0
    Private mProviderLastName As String = ""
    Private mProviderFirstName As String = ""
    Private mProviderMiddleName As String = ""
    Private mDOS As String = ""
    Private mPOS As String = ""
    Private mCPTCode As String = ""
    Private mDescription As String = ""
    Private mcharges As Double = 0.0
    Private mCredit As Double = 0.0
    Private mBalance As Double = 0.0

#End Region
#Region "Properties"

    Public Property StatementID() As Integer
        Get
            Return mStatementID
        End Get
        Set(ByVal value As Integer)
            mStatementID = value
        End Set
    End Property
  
    Public Property VisitID() As Integer
        Get
            Return mVisitID
        End Get
        Set(ByVal value As Integer)
            mVisitID = value
        End Set
    End Property

    Public Property ProviderLastName() As String
        Get
            Return mProviderLastName
        End Get
        Set(ByVal value As String)
            mProviderLastName = value
        End Set
    End Property

    Public Property ProviderFirstName() As String
        Get
            Return mProviderFirstName
        End Get
        Set(ByVal value As String)
            mProviderFirstName = value
        End Set
    End Property

    Public Property ProviderMiddleName() As String
        Get
            Return mProviderMiddleName
        End Get
        Set(ByVal value As String)
            mProviderMiddleName = value
        End Set
    End Property

    Public Property DOS() As String
        Get
            Return mDOS
        End Get
        Set(ByVal value As String)
            mDOS = value
        End Set
    End Property

    Public Property POS() As String
        Get
            Return mPOS
        End Get
        Set(ByVal value As String)
            mPOS = value
        End Set
    End Property

    Public Property CPTCode() As String
        Get
            Return mCPTCode
        End Get
        Set(ByVal value As String)
            mCPTCode = value
        End Set
    End Property

    Public Property Description() As String
        Get
            Return mDescription
        End Get
        Set(ByVal value As String)
            mDescription = value
        End Set
    End Property

    Public Property charges() As Double
        Get
            Return mcharges
        End Get
        Set(ByVal value As Double)
            mcharges = value
        End Set
    End Property

    Public Property Credit() As Double
        Get
            Return mCredit
        End Get
        Set(ByVal value As Double)
            mCredit = value
        End Set
    End Property

    Public Property Balance() As Double
        Get
            Return mBalance
        End Get
        Set(ByVal value As Double)
            mBalance = value
        End Set
    End Property

#End Region
End Class

Public Class PatientStatementTransactionDtl
#Region "Fields"
    Private mConnection As Connection
    Private mConnectionString
    Private mPatientStatementTransactionDtlDB As New PatientStatementTransactionDtlDB
#End Region
#Region "Property"
    Public ReadOnly Property Connection() As ElixirLibrary.Connection
        Get
            Return mConnection
        End Get
    End Property
    Public ReadOnly Property ConnectionString() As String
        Get
            Return mConnectionString
        End Get
    End Property
    Public Property PatientStatementTransactionDtlDB() As PatientStatementTransactionDtlDB
        Get
            Return mPatientStatementTransactionDtlDB
        End Get
        Set(ByVal value As PatientStatementTransactionDtlDB)
            mPatientStatementTransactionDtlDB = value
        End Set
    End Property
#End Region
#Region "Constructor"
    Public Sub New(ByVal pConnectionString As String)
        If pConnectionString = "" Then
            Throw New ArgumentException("ConnectionString can not be empty")
        End If
        mConnectionString = pConnectionString
        mConnection = New Connection(mConnectionString)
    End Sub
    Public Sub New(ByVal pConnection As Connection)
        If pConnection Is Nothing Then
            Throw New ArgumentException("Connection can not be empty")
        End If
        mConnection = pConnection
    End Sub
#End Region
#Region "Methods"
    Public Function InsertPatientStatementTransactionDtl() As String
        Try
            Dim lXmlDocument As New XmlDocument
            Dim lXmlElement As XmlElement
            lXmlDocument.LoadXml("<PatientStatementTransactionDtls></PatientStatementTransactionDtls>")
            lXmlElement = lXmlDocument.CreateElement("PatientStatementTransactionDtl")
            With lXmlElement
                .SetAttribute("StatementID", PatientStatementTransactionDtlDB.StatementID)
                .SetAttribute("VisitID", PatientStatementTransactionDtlDB.VisitID)
                .SetAttribute("ProviderLastName", PatientStatementTransactionDtlDB.ProviderLastName)
                .SetAttribute("ProviderFirstName", PatientStatementTransactionDtlDB.ProviderFirstName)
                .SetAttribute("ProviderMiddleName", PatientStatementTransactionDtlDB.ProviderMiddleName)
                .SetAttribute("DOS", PatientStatementTransactionDtlDB.DOS)
                .SetAttribute("POS", PatientStatementTransactionDtlDB.POS)
                .SetAttribute("CPTCode", PatientStatementTransactionDtlDB.CPTCode)
                .SetAttribute("Description", PatientStatementTransactionDtlDB.Description)
                .SetAttribute("Charges", PatientStatementTransactionDtlDB.charges)
                .SetAttribute("Credit", PatientStatementTransactionDtlDB.Credit)
                .SetAttribute("Balance", PatientStatementTransactionDtlDB.Balance)
            End With
            lXmlDocument.DocumentElement.AppendChild(lXmlElement.CloneNode(True))
            
            If Connection.IsTransactionAlive() Then
                Connection.ExecuteTransactionCommand("InsertPatientStatementTransactionDtl", lXmlDocument.InnerXml.ToString)
            Else
                Connection.ExecuteCommand("InsertPatientStatementTransactionDtl", lXmlDocument.InnerXml.ToString)
            End If


            Return "Patient Statement Transaction Details Added Successfully"
        Catch ex As Exception
            Return ""

        End Try
    End Function


    Public Function GetInformationForPatientStatementTransactionDtl(ByVal lpatientID As Integer) As System.Data.DataSet
        Dim lSpParameter(0) As SpParameter
        Dim lDs As New DataSet()


        lSpParameter(0).ParameterName = "@PatientID"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = lpatientID

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("PatientStatementView", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("PatientStatementView", lSpParameter)
        End If

        Return lDs

    End Function
#End Region
End Class
