Imports Microsoft.VisualBasic

Public Class HCFADetailDB
#Region "Fields"

    Private mHCFAID As String = ""
    Private mLineId As String = ""
    Private mDateOfServiceFrom As String = ""
    Private mDateOfServiceTo As String = ""
    Private mPlaceOfService As String = ""
    Private mTypeOfService As String = ""
    Private mCPTCode As String = ""
    Private mModifierA As String = ""
    Private mModifierB As String = ""
    Private mModifierC As String = ""
    Private mModifierD As String = ""
    Private mDignosisPointer As String = ""
    Private mCharges As Double = 0.0
    Private mDays As String = ""
    Private mEPSDT As String = ""
    Private mEmergency As String = ""
    Private mCOB As String = ""
    Private mNPI As String = ""
    Private mPrescriberLicenceID As String = ""


#End Region

#Region "Properties"

    Public Property HCFAID() As String
        Get
            Return mHCFAID
        End Get
        Set(ByVal value As String)
            mHCFAID = value
        End Set
    End Property

    Public Property LineId() As String
        Get
            Return mLineId
        End Get
        Set(ByVal value As String)
            mLineId = value
        End Set
    End Property

    Public Property DateOfServiceFrom() As String
        Get
            Return mDateOfServiceFrom
        End Get
        Set(ByVal value As String)
            mDateOfServiceFrom = value
        End Set
    End Property

    Public Property DateOfServiceTo() As String
        Get
            Return mDateOfServiceTo
        End Get
        Set(ByVal value As String)
            mDateOfServiceTo = value
        End Set
    End Property
    Public Property PlaceOfService() As String
        Get
            Return mPlaceOfService
        End Get
        Set(ByVal value As String)
            mPlaceOfService = value
        End Set
    End Property
    Public Property TypeOfService() As String
        Get
            Return mTypeOfService
        End Get
        Set(ByVal value As String)
            mTypeOfService = value
        End Set
    End Property

    Public Property CPTCode() As String
        Get
            Return mCPTCode
        End Get
        Set(ByVal value As String)
            mCPTCode = value
        End Set
    End Property

    Public Property ModifierA() As String
        Get
            Return mModifierA
        End Get
        Set(ByVal value As String)
            mModifierA = value
        End Set
    End Property

    Public Property ModifierB() As String
        Get
            Return mModifierB
        End Get
        Set(ByVal value As String)
            mModifierB = value
        End Set
    End Property

    Public Property ModifierC() As String
        Get
            Return mModifierC
        End Get
        Set(ByVal value As String)
            mModifierC = value
        End Set
    End Property

    Public Property ModifierD() As String
        Get
            Return mModifierD
        End Get
        Set(ByVal value As String)
            mModifierD = value
        End Set
    End Property

    Public Property DignosisPointer() As String
        Get
            Return mDignosisPointer
        End Get
        Set(ByVal value As String)
            mDignosisPointer = value
        End Set
    End Property

    Public Property Charges() As Double
        Get
            Return mCharges
        End Get
        Set(ByVal value As Double)
            mCharges = value
        End Set
    End Property

    Public Property Days() As String
        Get
            Return mDays
        End Get
        Set(ByVal value As String)
            mDays = value
        End Set
    End Property

    Public Property EPSDT() As String
        Get
            Return mEPSDT
        End Get
        Set(ByVal value As String)
            mEPSDT = value
        End Set
    End Property

    Public Property NPI() As String
        Get
            Return Me.mNPI
        End Get
        Set(ByVal value As String)
            mNPI = value
        End Set
    End Property

    Public Property Emergency() As String
        Get
            Return Me.mEmergency
        End Get
        Set(ByVal value As String)
            Me.mEmergency = value
        End Set
    End Property

    Public Property COB() As String
        Get
            Return Me.mCOB
        End Get
        Set(ByVal value As String)
            Me.mCOB = value
        End Set
    End Property

    Public Property PrescriberLicenceID() As String
        Get
            Return Me.mPrescriberLicenceID
        End Get
        Set(ByVal value As String)
            mPrescriberLicenceID = value
        End Set
    End Property


#End Region
End Class


Public Class HCFADetail
#Region "Fields"
    Private mConnection As Connection
    Private mConnectionString
    Private mHCFADetail As New HCFADetailDB
    Private mHCFADetailColl As New HCFADetailColl
#End Region

#Region "Property"
    Public ReadOnly Property Connection() As ElixirLibrary.Connection
        Get
            Return mConnection
        End Get
    End Property

    Public ReadOnly Property ConnectionString() As String
        Get
            Return mConnectionString
        End Get
    End Property
    Public Property HCFADetail() As HCFADetailDB
        Get
            Return mHCFADetail
        End Get
        Set(ByVal value As HCFADetailDB)
            mHCFADetail = value
        End Set
    End Property
    Public Property HCFADetailCol() As HCFADetailColl
        Get
            Return mHCFADetailColl
        End Get
        Set(ByVal value As HCFADetailColl)
            mHCFADetailColl = value
        End Set
    End Property
#End Region

#Region "Constructor"
    ''' <summary>
    ''' Creates new Conection Object based on Given Connection String 
    ''' </summary>
    ''' <param name="pConnectionString">
    ''' Contains Connection String 
    ''' </param>
    ''' <remarks>
    ''' Use when not using transaction
    ''' Must Specify Connection String other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnectionString As String)
        If pConnectionString = "" Then
            Throw New ArgumentException("ConnectionString can not be empty")
        End If

        mConnectionString = pConnectionString
        mConnection = New Connection(mConnectionString)

    End Sub

    ''' <summary>
    ''' Assign given connection to the current Object
    ''' </summary>
    ''' <param name="pConnection">
    ''' Contains refrence to the connection object
    ''' </param>
    ''' <remarks>
    ''' Use when  using Transaction
    ''' Must Specify Connection other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnection As Connection)
        If pConnection Is Nothing Then
            Throw New ArgumentException("Connection can not be empty")
        End If

        mConnection = pConnection
    End Sub
#End Region


#Region "Method"
    ''' <summary>
    ''' Get Single Record By Primary Key
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetRecordsByID() As HCFADetailColl
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()
        Dim lHcfaDetailColl As New HCFADetailColl
        Dim lHcfaDtl As HCFADetailDB

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "HCFADetail"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = "And HCFAID = " & Me.HCFADetail.HCFAID

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("SelectAllRecords", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
        End If


        With lDs.Tables(0)
            If .Rows.Count > 0 Then
                Dim index As Int32
                For index = 0 To .Rows.Count - 1
                    lHcfaDtl = New HCFADetailDB()

                    If (Not IsDBNull(.Rows(index)("Charges"))) Then
                        lHcfaDtl.Charges = .Rows(index)("Charges")
                    Else
                        lHcfaDtl.Charges = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("COB"))) Then
                        lHcfaDtl.COB = .Rows(index)("COB")
                    Else
                        lHcfaDtl.COB = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("CPTCode"))) Then
                        lHcfaDtl.CPTCode = .Rows(index)("CPTCode")
                    Else
                        lHcfaDtl.CPTCode = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("DateOfServiceFrom"))) Then
                        lHcfaDtl.DateOfServiceFrom = .Rows(index)("DateOfServiceFrom")
                    Else
                        lHcfaDtl.DateOfServiceFrom = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("DateOfServiceTo"))) Then
                        lHcfaDtl.DateOfServiceTo = .Rows(index)("DateOfServiceTo")
                    Else
                        lHcfaDtl.DateOfServiceTo = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("Days"))) Then
                        lHcfaDtl.Days = .Rows(index)("Days")
                    Else
                        lHcfaDtl.Days = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("DignosisPointer"))) Then
                        lHcfaDtl.DignosisPointer = .Rows(index)("DignosisPointer")
                    Else
                        lHcfaDtl.DignosisPointer = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("Emergency"))) Then
                        lHcfaDtl.Emergency = .Rows(index)("Emergency")
                    Else
                        lHcfaDtl.Emergency = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("EPSDT"))) Then
                        lHcfaDtl.EPSDT = .Rows(index)("EPSDT")
                    Else
                        lHcfaDtl.EPSDT = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("HCFAID"))) Then
                        lHcfaDtl.HCFAID = .Rows(index)("HCFAID")
                    Else
                        lHcfaDtl.HCFAID = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("ModifierA"))) Then
                        lHcfaDtl.ModifierA = .Rows(index)("ModifierA")
                    Else
                        lHcfaDtl.ModifierA = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("ModifierB"))) Then
                        lHcfaDtl.ModifierB = .Rows(index)("ModifierB")
                    Else
                        lHcfaDtl.ModifierB = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("ModifierC"))) Then
                        lHcfaDtl.ModifierC = .Rows(index)("ModifierC")
                    Else
                        lHcfaDtl.ModifierC = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("ModifierD"))) Then
                        lHcfaDtl.ModifierD = .Rows(index)("ModifierD")
                    Else
                        lHcfaDtl.ModifierD = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("LineId"))) Then
                        lHcfaDtl.LineId = .Rows(index)("LineId")
                    Else
                        lHcfaDtl.LineId = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("NPI"))) Then
                        lHcfaDtl.NPI = .Rows(index)("NPI")
                    Else
                        lHcfaDtl.NPI = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("PrescriberLicenceID"))) Then
                        lHcfaDtl.PrescriberLicenceID = .Rows(index)("PrescriberLicenceID")
                    Else
                        lHcfaDtl.PrescriberLicenceID = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("PlaceOfService"))) Then
                        lHcfaDtl.PlaceOfService = .Rows(index)("PlaceOfService")
                    Else
                        lHcfaDtl.PlaceOfService = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("TypeOfService"))) Then
                        lHcfaDtl.TypeOfService = .Rows(index)("TypeOfService")
                    Else
                        lHcfaDtl.TypeOfService = ""
                    End If

                    lHcfaDetailColl.Add(lHcfaDtl)
                Next

            End If

            Return lHcfaDetailColl
        End With

    End Function

    Public Function GetRecordsFromPatientCPT(ByVal lPatientSuperBillID As String) As HCFADetailColl
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()
        Dim lHcfaDtl As HCFADetailDB
        Dim lHcfaDtlColl As New HCFADetailColl()
        'Dim lHcfaDetailColl As New HCFADetailColl

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "PatientCPT"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = "And PatientSuperBillID = " & lPatientSuperBillID

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("SelectAllRecords", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
        End If


        With lDs.Tables(0)
            If .Rows.Count > 0 Then
                Dim index As Int32
                For index = 0 To .Rows.Count - 1
                    lHcfaDtl = New HCFADetailDB()
                    If (Not IsDBNull(.Rows(index)("Charges"))) Then
                        lHcfaDtl.Charges = .Rows(index)("Charges")
                    Else
                        lHcfaDtl.Charges = ""
                    End If


                    If (Not IsDBNull(.Rows(index)("Code"))) Then
                        lHcfaDtl.CPTCode = .Rows(index)("Code")
                    Else
                        lHcfaDtl.CPTCode = ""
                    End If


                    If (Not IsDBNull(.Rows(index)("Days"))) Then
                        lHcfaDtl.Days = .Rows(index)("Days")
                    Else
                        lHcfaDtl.Days = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("Pointer"))) Then
                        lHcfaDtl.DignosisPointer = .Rows(index)("Pointer")
                    Else
                        lHcfaDtl.DignosisPointer = ""
                    End If


                    If (Not IsDBNull(.Rows(index)("ModifierA"))) Then
                        lHcfaDtl.ModifierA = .Rows(index)("ModifierA")
                    Else
                        lHcfaDtl.ModifierA = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("ModifierB"))) Then
                        lHcfaDtl.ModifierB = .Rows(index)("ModifierB")
                    Else
                        lHcfaDtl.ModifierB = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("ModifierC"))) Then
                        lHcfaDtl.ModifierC = .Rows(index)("ModifierC")
                    Else
                        lHcfaDtl.ModifierC = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("ModifierD"))) Then
                        lHcfaDtl.ModifierD = .Rows(index)("ModifierD")
                    Else
                        lHcfaDtl.ModifierD = ""
                    End If


                    If (Not IsDBNull(.Rows(index)("POS"))) Then
                        lHcfaDtl.PlaceOfService = .Rows(index)("POS")
                    Else
                        lHcfaDtl.PlaceOfService = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("CPTDate"))) Then
                        lHcfaDtl.DateOfServiceFrom = .Rows(index)("CPTDate")
                    Else
                        lHcfaDtl.DateOfServiceFrom = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("CPTDate"))) Then
                        lHcfaDtl.DateOfServiceTo = DateAdd(DateInterval.Day, .Rows(index)("Days") - 1, CType(.Rows(index)("CPTDate"), Date))
                    Else
                        lHcfaDtl.DateOfServiceTo = ""
                    End If


                    lHcfaDtlColl.Add(lHcfaDtl)

                Next

            End If

            Return lHcfaDtlColl
        End With

    End Function

    Public Sub InsertRecord()
        Dim lXmlDocument As New XmlDocument
        Dim lXmlElement As XmlElement

        Dim index As Int32

        lXmlDocument.LoadXml("<HCFADetails></HCFADetails>")
        lXmlElement = lXmlDocument.CreateElement("HCFADetail")


        For index = 0 To HCFADetailCol.Count - 1
            With lXmlElement
                .SetAttribute("HCFAID", HCFADetailCol.Item(index).HCFAID)
                .SetAttribute("DateOfServiceFrom", HCFADetailCol.Item(index).DateOfServiceFrom)
                .SetAttribute("DateOfServiceTo", HCFADetailCol.Item(index).DateOfServiceTo)
                .SetAttribute("PlaceOfService", HCFADetailCol.Item(index).PlaceOfService)
                .SetAttribute("TypeOfService", HCFADetailCol.Item(index).TypeOfService)
                .SetAttribute("CPTCode", HCFADetailCol.Item(index).CPTCode)
                .SetAttribute("ModifierA", HCFADetailCol.Item(index).ModifierA)
                .SetAttribute("ModifierB", HCFADetailCol.Item(index).ModifierB)
                .SetAttribute("ModifierC", HCFADetailCol.Item(index).ModifierC)
                .SetAttribute("ModifierD", HCFADetailCol.Item(index).ModifierD)
                .SetAttribute("DignosisPointer", HCFADetailCol.Item(index).DignosisPointer)
                .SetAttribute("Charges", HCFADetailCol.Item(index).Charges)
                .SetAttribute("Days", HCFADetailCol.Item(index).Days)
                .SetAttribute("EPSDT", HCFADetailCol.Item(index).EPSDT)
                .SetAttribute("Emergency", HCFADetailCol.Item(index).Emergency)
                .SetAttribute("COB", HCFADetailCol.Item(index).COB)
                .SetAttribute("NPI", HCFADetailCol.Item(index).NPI)
                .SetAttribute("PrescriberLicenceID", HCFADetailCol.Item(index).PrescriberLicenceID)
            End With

            lXmlDocument.DocumentElement.AppendChild(lXmlElement.CloneNode(True))
        Next

        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand("InsertHCFADetail", lXmlDocument.InnerXml.ToString)
        Else
            Connection.ExecuteCommand("InsertHCFADetail", lXmlDocument.InnerXml.ToString)
        End If

    End Sub

    Public Sub DeleteRecord(ByVal pCondition As String)
        Dim lSpParameter(1) As SpParameter

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "HCFADetail"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = pCondition

        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand("DeleteRecords", lSpParameter)
        Else
            Connection.ExecuteCommand("DeleteRecords", lSpParameter)
        End If
    End Sub
    Public Sub DeleteRecordByID()
        Dim lCondition As String

        lCondition = "And HCFAID = " & Me.HCFADetail.HCFAID
        DeleteRecord(lCondition)

    End Sub

#End Region

End Class


Public Class HCFADetailColl
    Inherits CollectionBase
    Public Function Add(ByVal pHCFADetail As HCFADetailDB) As Integer
        'Me.InnerList.Insert(Me.Count, pHCFADetail)
        Me.List.Add(pHCFADetail)
    End Function
    Public Sub Remove(ByVal pHCFADetail As HCFADetailDB)
        Dim lIndex As Integer

        lIndex = IndexOf(pHCFADetail)

        If lIndex > -1 Then
            List.RemoveAt(lIndex)
        End If

    End Sub
    Default Public Property Item(ByVal Index As Integer) As HCFADetailDB
        Get
            If (Index < List.Count) Then
                Return CType(List.Item(Index), HCFADetailDB)
            Else
                Return (Nothing)
            End If
        End Get
        Set(ByVal Value As HCFADetailDB)
            List.Item(Index) = Value
        End Set
    End Property

    Public Shadows Function Count() As Integer
        Return List.Count
    End Function

    Public Function IndexOf(ByVal obj As Object) As Integer
        Dim lIndex As Integer = 0
        Dim lFound As Integer = 0

        For Each lObj As Object In List
            lFound = CType(lObj, HCFADetailDB).CPTCode.CompareTo(CType(obj, HCFADetailDB).CPTCode)
            If lFound = 0 Then
                Return lIndex
            End If
            lIndex += 1
        Next
        Return -1

    End Function

End Class
