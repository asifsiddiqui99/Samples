Imports Microsoft.VisualBasic

Public Class PatientNotesDB

#Region "Fields"

    Private mNoteId As Integer = 0
    Private mPatientId As Integer = 0
    Private mNoteDate As String = ""
    Private mNotes As String = ""

    

#End Region



#Region "Properties"
    Public Property NoteId() As Integer
        Get
            Return mNoteId
        End Get
        Set(ByVal value As Integer)
            mNoteId = value
        End Set
    End Property

    Public Property PatientId() As Integer
        Get
            Return mPatientId
        End Get
        Set(ByVal value As Integer)
            mPatientId = value
        End Set
    End Property

    Public Property NoteDate() As String
        Get
            Return mNoteDate
        End Get
        Set(ByVal value As String)
            mNoteDate = value
        End Set
    End Property

    Public Property Notes() As String
        Get
            Return mNotes
        End Get
        Set(ByVal value As String)
            mNotes = value
        End Set
    End Property

#End Region


End Class

Public Class PatientNotes
    Implements IDetail

#Region "Fields"
    Private mConnection As Connection
    Private mConnectionString
    Private mPatientNotes As New PatientNotesDB
#End Region

#Region "Property"


    Public ReadOnly Property Connection() As ElixirLibrary.Connection Implements IDetail.Connection
        Get
            Return mConnection
        End Get
    End Property

    Public ReadOnly Property ConnectionString() As String Implements IDetail.ConnectionString
        Get
            Return mConnectionString
        End Get
    End Property

    Public Property PatientNotes() As PatientNotesDB
        Get
            Return mPatientNotes
        End Get
        Set(ByVal value As PatientNotesDB)
            mPatientNotes = value
        End Set
    End Property

#End Region

#Region "Constructor"
    ''' <summary>
    ''' Creates new Conection Object based on Given Connection String 
    ''' </summary>
    ''' <param name="pConnectionString">
    ''' Contains Connection String 
    ''' </param>
    ''' <remarks>
    ''' Use when not using transaction
    ''' Must Specify Connection String other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnectionString As String)
        If pConnectionString = "" Then
            Throw New ArgumentException("ConnectionString can not be empty")
        End If

        mConnectionString = pConnectionString
        mConnection = New Connection(mConnectionString)

    End Sub

    ''' <summary>
    ''' Assign given connection to the current Object
    ''' </summary>
    ''' <param name="pConnection">
    ''' Contains refrence to the connection object
    ''' </param>
    ''' <remarks>
    ''' Use when  using Transaction
    ''' Must Specify Connection other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnection As Connection)
        If pConnection Is Nothing Then
            Throw New ArgumentException("Connection can not be empty")
        End If

        mConnection = pConnection
    End Sub
#End Region


#Region "Methods"
    Public Sub InsertRecord(ByVal pXml As String)

        Try
            If (pXml <> "") Then
                If Connection.IsTransactionAlive() Then
                    Connection.ExecuteTransactionCommand("InsertPatientNotes", pXml)
                Else
                    Connection.ExecuteCommand("InsertPatientNotes", pXml)
                End If
            End If
        Catch ex As Exception
            Throw New Exception(ex.Message & " : DAL\PatientInsurance.InsertRecord() ")
        End Try


    End Sub

    Public Sub DeleteRecord(ByVal lCondition As String) Implements IDetail.DeleteRecord
        Dim lSpParameter(1) As SpParameter
        Try
            lSpParameter(0).ParameterName = "@Table"
            lSpParameter(0).ParameterType = ParameterType.Varchar
            lSpParameter(0).ParameterValue = "PatientNotes"

            lSpParameter(1).ParameterName = "@Cond"
            lSpParameter(1).ParameterType = ParameterType.Varchar
            lSpParameter(1).ParameterValue = lCondition



            If Connection.IsTransactionAlive() Then
                Connection.ExecuteTransactionCommand("DeleteRecords", lSpParameter)
            Else
                Connection.ExecuteCommand("DeleteRecords", lSpParameter)
            End If
        Catch ex As Exception
            Throw New Exception(ex.Message & " : DAL\PatientInsurance.DeleteRecord(ByVal lCondition As String) ")
        End Try


    End Sub


    Public Sub InsertRecordPayment(ByVal lUser As User, ByVal pPaitientNotes As PatientNotesDB, ByVal pVisitId As String)
        Dim lPatientId As String = String.Empty
        Dim lds As DataSet
        Dim lQuery As String = String.Empty
        Dim lConnection As New Connection(lUser.ConnectionString)
        Dim lId As Integer = 0
        Try
            lds = New DataSet
            lQuery = "select PatientId from PatientSuperBill where PatientSuperBillID ='" & pVisitId & "' group by PatientId"
            lds = lConnection.ExecuteQuery(lQuery)
            lPatientId = lds.Tables(0).Rows(0)(0).ToString
            lId = Convert.ToInt32(lPatientId)
            lQuery = "insert into PatientNotes (PatientId,NoteDate,Notes)values(" & lId & ",'" & System.DateTime.Today & "','" & pPaitientNotes.Notes & "')"

            If lConnection.IsTransactionAlive() Then
                lds = lConnection.ExecuteTransactionQuery(lQuery)
            Else
                lds = lConnection.ExecuteQuery(lQuery)
            End If

        Catch ex As Exception

        End Try
    End Sub
#End Region





    Public Function GetAllRecords() As System.Data.DataSet Implements IDetail.GetAllRecords

    End Function

    Public Function GetAllRecords(ByVal pCondition As String) As System.Data.DataSet Implements IDetail.GetAllRecords
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "PatientNotes"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = pCondition

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("SelectAllRecords", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
        End If

        Return lDs
    End Function

    Public Function GetRecordByID() As Boolean Implements IDetail.GetRecordByID

    End Function

    Public Sub InsertRecord() Implements IDetail.InsertRecord

    End Sub

    Public Sub UpdateRecord() Implements IDetail.UpdateRecord

    End Sub

    Public Sub UpdateRecord(ByVal pCondition As String) Implements IDetail.UpdateRecord

    End Sub

    Public Sub DeleteRecordByID() Implements IDetail.DeleteRecordByID
        Dim lCondition As String

        lCondition = "AND PatientID = " & Me.PatientNotes.PatientId
        DeleteRecord(lCondition)

    End Sub
End Class
