Imports System
Imports System.Web
Imports System.Web.Services
Imports System.Web.Services.Protocols
Imports System.Data
Imports ElixirLibrary
Imports System.Xml

#Region "Credits"

'Created By     :       Anila Khwaja 
'Dated          :       July 5th, 2007

#End Region

''' <summary>
''' Class To Encapsulate PatientInsurance Table
''' </summary>
''' <remarks></remarks>
Public Class PatientInsuranceDB

#Region "Fields"

    Private mPatientInsID As Integer = 0
    Private mPatientID As Integer = 0
    Private mType As String = ""
    Private mRelationshipToPrimaryInsurer As String = ""
    Private mInsurerId As Integer = 0
    Private mInsuranceCompanyID As Integer = 0
    Private mInsuranceCompanyName As String = ""
    Private mPayerId As String = ""
    Private mSubscriberID As String = "0"
    Private mGroupNo As String = ""
    Private mPlanName As String = ""
    Private mInsuredAuthorization As String = ""
    Private mDeductable As String = ""
    Private mVisitCopayment As String = ""
    Private mSignatureOfFile As String = ""
    Private mSignatureDate As String = ""
    Private mActive As String = "Y"
    Private mSecRelationshipToPrimaryInsurer As String = ""
    Private mSecInsuranceCompanyID As Integer = 0
    Private mSecInsuranceCompany As Integer = 0
    Private mSecSubscriberID As Integer = 0
    Private mSecGroupNo As String = ""
    Private mSecPlanName As String = ""
    Private mSecInsuredAuthorization As String = ""
    Private mSecDeductable As String = ""
    Private mSecVisitCopayment As String = ""
    Private mSecSignatureOfFile As String = ""
    Private mSecSignatureDate As String = ""


    '' New Fields 16 Dec 2009
    Private mEffectiveDateFrom As String = ""
    Private mEffectiveDateTo As String = ""
    Private mAuthorizationNumber As String = ""
    Private mCoInsurance As String = ""
    Private mInsuranceCompanyPhoneNumber As String = ""


    '' New Fields 12 Jan 2010 to get insurer which level Insurance is added in Patient 
    '' after deciding that now insurer any level insurance can be added in patient any level insurance.
    Private mInsurerInsuranceType As String = ""
    Private mInsurerInsuranceId As Integer = 0


    ''added by madiha
    Private mCardFrontImage As String = ""
    Private mCardBackImage As String = ""


#End Region



#Region "Properties"

    Public Property PatientInsID() As Integer
        Get
            Return mPatientInsID
        End Get
        Set(ByVal value As Integer)
            mPatientInsID = value
        End Set
    End Property
    Public Property InsurerInsuranceId() As Integer
        Get
            Return mInsurerInsuranceId
        End Get
        Set(ByVal value As Integer)
            mInsurerInsuranceId = value
        End Set
    End Property
    Public Property InsurerInsuranceType() As String
        Get
            Return mInsurerInsuranceType
        End Get
        Set(ByVal value As String)
            mInsurerInsuranceType = value
        End Set
    End Property
    Public Property EffectiveDateFrom() As String
        Get
            Return mEffectiveDateFrom
        End Get
        Set(ByVal value As String)
            mEffectiveDateFrom = value
        End Set
    End Property
    Public Property EffectiveDateTo() As String
        Get
            Return mEffectiveDateTo
        End Get
        Set(ByVal value As String)
            mEffectiveDateTo = value
        End Set
    End Property
    Public Property AuthorizationNumber() As String
        Get
            Return mAuthorizationNumber
        End Get
        Set(ByVal value As String)
            mAuthorizationNumber = value
        End Set
    End Property
    Public Property CoInsurance() As String
        Get
            Return mCoInsurance
        End Get
        Set(ByVal value As String)
            mCoInsurance = value
        End Set
    End Property
    Public Property InsuranceCompanyPhoneNumber() As String
        Get
            Return mInsuranceCompanyPhoneNumber
        End Get
        Set(ByVal value As String)
            mInsuranceCompanyPhoneNumber = value
        End Set
    End Property

    Public Property InsurerId() As Integer
        Get
            Return mInsurerId
        End Get
        Set(ByVal value As Integer)
            mInsurerId = value
        End Set
    End Property

    Public Property Active() As String
        Get
            Return mActive
        End Get
        Set(ByVal value As String)
            mActive = value
        End Set
    End Property

    Public Property SignatureDate() As String
        Get
            Return mSignatureDate
        End Get
        Set(ByVal value As String)
            mSignatureDate = value
        End Set
    End Property

    Public Property SignatureOfFile() As String
        Get
            Return mSignatureOfFile
        End Get
        Set(ByVal value As String)
            mSignatureOfFile = value
        End Set
    End Property

    Public Property VisitCopayment() As String
        Get
            Return mVisitCopayment
        End Get
        Set(ByVal value As String)
            mVisitCopayment = value
        End Set
    End Property

    Public Property Deductable() As String
        Get
            Return mDeductable
        End Get
        Set(ByVal value As String)
            mDeductable = value
        End Set
    End Property

    Public Property InsuredAuthorization() As String
        Get
            Return mInsuredAuthorization
        End Get
        Set(ByVal value As String)
            mInsuredAuthorization = value
        End Set
    End Property

    Public Property PlanName() As String
        Get
            Return mPlanName
        End Get
        Set(ByVal value As String)
            mPlanName = value
        End Set
    End Property
    Public Property GroupNo() As String
        Get
            Return mGroupNo
        End Get
        Set(ByVal value As String)
            mGroupNo = value
        End Set
    End Property

    Public Property SubscriberID() As String
        Get
            Return mSubscriberID
        End Get
        Set(ByVal value As String)
            mSubscriberID = value
        End Set
    End Property

    Public Property InsuranceCompanyName() As String
        Get
            Return mInsuranceCompanyName
        End Get
        Set(ByVal value As String)
            mInsuranceCompanyName = value
        End Set
    End Property

    Public Property InsuranceCompanyID() As Integer
        Get
            Return mInsuranceCompanyID
        End Get
        Set(ByVal value As Integer)
            mInsuranceCompanyID = value
        End Set
    End Property
    Public Property PayerId() As String
        Get
            Return mPayerId
        End Get
        Set(ByVal value As String)
            mPayerId = value
        End Set
    End Property

    Public Property RelationshipToPrimaryInsurer() As String
        Get
            Return mRelationshipToPrimaryInsurer
        End Get
        Set(ByVal value As String)
            mRelationshipToPrimaryInsurer = value
        End Set
    End Property

    Public Property Type() As String
        Get
            Return mType
        End Get
        Set(ByVal value As String)
            mType = value
        End Set
    End Property

    Public Property PatientID() As Integer
        Get
            Return mPatientID
        End Get
        Set(ByVal value As Integer)
            mPatientID = value
        End Set
    End Property


    Public Property SecSignatureDate() As String
        Get
            Return mSecSignatureDate
        End Get
        Set(ByVal value As String)
            mSecSignatureDate = value
        End Set
    End Property

    Public Property SecSignatureOfFile() As String
        Get
            Return mSecSignatureOfFile
        End Get
        Set(ByVal value As String)
            mSecSignatureOfFile = value
        End Set
    End Property

    Public Property SecVisitCopayment() As String
        Get
            Return mSecVisitCopayment
        End Get
        Set(ByVal value As String)
            mSecVisitCopayment = value
        End Set
    End Property

    Public Property SecDeductable() As String
        Get
            Return mSecDeductable
        End Get
        Set(ByVal value As String)
            mSecDeductable = value
        End Set
    End Property

    Public Property SecInsuredAuthorization() As String
        Get
            Return mSecInsuredAuthorization
        End Get
        Set(ByVal value As String)
            mSecInsuredAuthorization = value
        End Set
    End Property

    Public Property SecPlanName() As String
        Get
            Return mSecPlanName
        End Get
        Set(ByVal value As String)
            mSecPlanName = value
        End Set
    End Property
    Public Property SecGroupNo() As String
        Get
            Return mSecGroupNo
        End Get
        Set(ByVal value As String)
            mSecGroupNo = value
        End Set
    End Property


    Public Property SecSubscriberID() As Integer
        Get
            Return mSecSubscriberID
        End Get
        Set(ByVal value As Integer)
            mSecSubscriberID = value
        End Set
    End Property

    Public Property SecInsuranceCompany() As Integer
        Get
            Return mSecInsuranceCompany
        End Get
        Set(ByVal value As Integer)
            mSecInsuranceCompany = value
        End Set
    End Property

    Public Property SecInsuranceCompanyID() As Integer
        Get
            Return mSecInsuranceCompanyID
        End Get
        Set(ByVal value As Integer)
            mSecInsuranceCompanyID = value
        End Set
    End Property

    Public Property SecRelationshipToPrimaryInsurer() As String
        Get
            Return mSecRelationshipToPrimaryInsurer
        End Get
        Set(ByVal value As String)
            mSecRelationshipToPrimaryInsurer = value
        End Set
    End Property

    ''added by madiha
    Public Property CardFrontImage() As String
        Get
            Return mCardFrontImage
        End Get
        Set(ByVal value As String)
            If value Is Nothing Then
                mCardFrontImage = ""
            Else
                mCardFrontImage = value
            End If
        End Set
    End Property
    Public Property CardBackImage() As String
        Get
            Return mCardBackImage
        End Get
        Set(ByVal value As String)
            If value Is Nothing Then
                mCardBackImage = ""
            Else
                mCardBackImage = value
            End If
        End Set
    End Property

#End Region


End Class

''' <summary>
''' Class Contain General Methods of PatientInsurance Entity
''' </summary>
''' <remarks></remarks>

Public Class PatientInsurance
    Implements IDetail

#Region "Fields"
    Private mConnection As Connection
    Private mConnectionString
    Private mPatientInsurance As New PatientInsuranceDB
#End Region

#Region "Property"


    Public ReadOnly Property Connection() As ElixirLibrary.Connection Implements IDetail.Connection
        Get
            Return mConnection
        End Get
    End Property

    Public ReadOnly Property ConnectionString() As String Implements IDetail.ConnectionString
        Get
            Return mConnectionString
        End Get
    End Property

    Public Property PatientInsurance() As PatientInsuranceDB
        Get
            Return mPatientInsurance
        End Get
        Set(ByVal value As PatientInsuranceDB)
            mPatientInsurance = value
        End Set
    End Property

#End Region

#Region "Constructor"
    ''' <summary>
    ''' Creates new Conection Object based on Given Connection String 
    ''' </summary>
    ''' <param name="pConnectionString">
    ''' Contains Connection String 
    ''' </param>
    ''' <remarks>
    ''' Use when not using transaction
    ''' Must Specify Connection String other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnectionString As String)
        If pConnectionString = "" Then
            Throw New ArgumentException("ConnectionString can not be empty")
        End If

        mConnectionString = pConnectionString
        mConnection = New Connection(mConnectionString)

    End Sub

    ''' <summary>
    ''' Assign given connection to the current Object
    ''' </summary>
    ''' <param name="pConnection">
    ''' Contains refrence to the connection object
    ''' </param>
    ''' <remarks>
    ''' Use when  using Transaction
    ''' Must Specify Connection other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnection As Connection)
        If pConnection Is Nothing Then
            Throw New ArgumentException("Connection can not be empty")
        End If

        mConnection = pConnection
    End Sub
#End Region



#Region "Method"

    ''' <summary>
    ''' Delete Record Acoording to Given Condition
    ''' </summary>
    ''' <param name="lCondition"></param>
    ''' <remarks></remarks>
    Public Sub DeleteRecord(ByVal lCondition As String) Implements IDetail.DeleteRecord
        Dim lSpParameter(1) As SpParameter
        Try
            lSpParameter(0).ParameterName = "@Table"
            lSpParameter(0).ParameterType = ParameterType.Varchar
            lSpParameter(0).ParameterValue = "PatientInsurance"

            lSpParameter(1).ParameterName = "@Cond"
            lSpParameter(1).ParameterType = ParameterType.Varchar
            lSpParameter(1).ParameterValue = lCondition



            If Connection.IsTransactionAlive() Then
                Connection.ExecuteTransactionCommand("DeleteRecords", lSpParameter)
            Else
                Connection.ExecuteCommand("DeleteRecords", lSpParameter)
            End If
        Catch ex As Exception
            Throw New Exception(ex.Message & " : DAL\PatientInsurance.DeleteRecord(ByVal lCondition As String) ")
        End Try
       

    End Sub



    ''' <summary>
    ''' Delete Record on Primary Key - not applicable
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub DeleteRecordByID() Implements IDetail.DeleteRecordByID
        'Dim lCondition As String

        'lCondition = "AND PatientID= " & PatientInsurance.PatientID & "AND Type='" & PatientInsurance.Type & "'"
        'DeleteRecord(lCondition)

    End Sub


    ''' <summary>
    ''' Get All Records unconditional
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetAllRecords() As System.Data.DataSet Implements IDetail.GetAllRecords
        'Dim lCondition As String = "AND Active= '' "
        'Dim lDs As New DataSet()

        'lDs = GetAllRecords(lCondition)

        'Return lDs
    End Function

    ''' <summary>
    ''' Get  Records on specified Condition
    ''' </summary>
    ''' <param name="lCondition"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetAllRecords(ByVal lCondition As String) As System.Data.DataSet Implements IDetail.GetAllRecords
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()

        Try
            lSpParameter(0).ParameterName = "@Table"
            lSpParameter(0).ParameterType = ParameterType.Varchar
            lSpParameter(0).ParameterValue = "PatientInsurance"

            lSpParameter(1).ParameterName = "@Cond"
            lSpParameter(1).ParameterType = ParameterType.Varchar
            lSpParameter(1).ParameterValue = lCondition

            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery("SelectAllRecords", lSpParameter)
            Else
                lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
            End If

            Return lDs
        Catch ex As Exception
            Throw New Exception(ex.Message & " : DAL\PatientInsurance.GetAllRecords(ByVal lCondition As String) ")
        End Try


        

    End Function

    ''' <summary>
    ''' Insert record
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub InsertRecord() Implements IDetail.InsertRecord
        Dim lXmlDocument As New XmlDocument
        Dim lXmlElement As XmlElement

        Try

            lXmlDocument.LoadXml("<PatientInsurances></PatientInsurances>")
            lXmlElement = lXmlDocument.CreateElement("PatientInsurance")

            With lXmlElement
                .SetAttribute("PatientInsID", PatientInsurance.PatientInsID)
                .SetAttribute("PatientID", PatientInsurance.PatientID)
                .SetAttribute("Type", PatientInsurance.Type)
                .SetAttribute("RelationshipToPrimaryInsurer", PatientInsurance.RelationshipToPrimaryInsurer)
                .SetAttribute("PayerId", PatientInsurance.PayerId)
                .SetAttribute("InsuranceCompanyID", PatientInsurance.InsuranceCompanyID)
                .SetAttribute("InsuranceCompany", PatientInsurance.InsuranceCompanyName)
                .SetAttribute("SubscriberID", PatientInsurance.SubscriberID)
                .SetAttribute("GroupNo", PatientInsurance.GroupNo)
                .SetAttribute("PlanName", PatientInsurance.PlanName)
                .SetAttribute("InsuredAuthorization", PatientInsurance.InsuredAuthorization)
                .SetAttribute("Deductable", PatientInsurance.Deductable)
                .SetAttribute("VisitCopayment", PatientInsurance.VisitCopayment)
                .SetAttribute("SignatureOfFile", PatientInsurance.SignatureOfFile)
                .SetAttribute("SignatureDate", PatientInsurance.SignatureDate)
                .SetAttribute("Active", PatientInsurance.Active)
                .SetAttribute("InsurerId", PatientInsurance.InsurerId)
                .SetAttribute("EffectiveDateFrom", PatientInsurance.EffectiveDateFrom)
                .SetAttribute("EffectiveDateTo", PatientInsurance.EffectiveDateTo)
                .SetAttribute("AuthorizationNumber", PatientInsurance.AuthorizationNumber)
                .SetAttribute("CoInsurance", PatientInsurance.CoInsurance)
                .SetAttribute("InsuranceCompanyPhoneNumber", PatientInsurance.InsuranceCompanyPhoneNumber)
                .SetAttribute("InsurerInsuranceType", PatientInsurance.InsurerInsuranceType)
                .SetAttribute("InsurerInsuranceId", PatientInsurance.InsurerInsuranceId)
                .SetAttribute("CardFrontImage", PatientInsurance.CardFrontImage)
                .SetAttribute("CardBackImage", PatientInsurance.CardBackImage)
            End With

            lXmlDocument.DocumentElement.AppendChild(lXmlElement.CloneNode(True))

            If Connection.IsTransactionAlive() Then
                Connection.ExecuteTransactionCommand("InsertPatientInsurance", lXmlDocument.InnerXml.ToString)
            Else
                Connection.ExecuteCommand("InsertPatientInsurance", lXmlDocument.InnerXml.ToString)
            End If

        Catch ex As Exception
            Throw New Exception(ex.Message & " : DAL\PatientInsurance.InsertRecord() ")
        End Try


    End Sub

    ''' <summary>
    ''' Update Record unconditional
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub UpdateRecord() Implements IDetail.UpdateRecord
        Dim lCondition As String

        '''''& " AND RelationshipToPrimaryInsurer='" & Me.PatientInsurance.RelationshipToPrimaryInsurer & "' " _

        lCondition = "AND PatientID= " & Me.PatientInsurance.PatientID & "" _
        & " AND Type='" & Me.PatientInsurance.Type & "' " _
        & " AND InsuranceCompanyID='" & Me.PatientInsurance.InsuranceCompanyID & "' " _
        & " AND InsuranceCompany='" & Me.PatientInsurance.InsuranceCompanyName & "' " _
        & " AND InsurerId= " & Me.PatientInsurance.InsurerId & "" _
        & " AND InsurerInsuranceId= " & Me.PatientInsurance.InsurerInsuranceId & "" _
        & " AND Active='Y'"

        UpdateRecord(lCondition)

    End Sub

    Public Sub UpdateRecord(ByVal lCondition As String) Implements IDetail.UpdateRecord

        Dim lQuery As String
        Try
            With Me.PatientInsurance

                lQuery = "Update PatientInsurance Set " _
                & "RelationshipToPrimaryInsurer ='" & .RelationshipToPrimaryInsurer & "', " _
                & "InsuranceCompanyID ='" & .InsuranceCompanyID & "', " _
                & "InsuranceCompany ='" & .InsuranceCompanyName & "', " _
                & "PayerId ='" & .PayerId & "', " _
                & "SubscriberID='" & .SubscriberID & "', " _
                & "GroupNo='" & .GroupNo & "', " _
                & "PlanName='" & .PlanName & "', " _
                & "InsuredAuthorization='" & .InsuredAuthorization & "', " _
                & "Deductable='" & .Deductable & "', " _
                & "VisitCopayment='" & .VisitCopayment & "', " _
                & "SignatureOfFile='" & .SignatureOfFile & "', " _
                & "SignatureDate='" & .SignatureDate & "', " _
                & "Active='" & .Active & "', " _
                & "InsurerId=" & .InsurerId & "," _
                & "EffectiveDateFrom='" & .EffectiveDateFrom & "', " _
                & "EffectiveDateTo='" & .EffectiveDateTo & "', " _
                & "AuthorizationNumber='" & .AuthorizationNumber & "', " _
                & "CoInsurance='" & .CoInsurance & "', " _
                & "InsuranceCompanyPhoneNumber='" & .InsuranceCompanyPhoneNumber & "', " _
                & "InsurerInsuranceType='" & .InsurerInsuranceType & "', " _
                & "CardFrontImage ='" & .CardFrontImage & "', " _
                & "CardBackImage ='" & .CardBackImage & "', " _
                & "InsurerInsuranceId='" & .InsurerInsuranceId & "' " _
                & "Where 1 = 1 " _
                & lCondition

            End With

            If Connection.IsTransactionAlive() Then
                Connection.ExecuteTransactionCommand(lQuery)
            Else
                Connection.ExecuteCommand(lQuery)
            End If
        Catch ex As Exception
            Throw New Exception(ex.Message & " : DAL\PatientInsurance.UpdateRecord(ByVal lCondition As String) ")
        End Try

        
    End Sub

    ''' <summary>
    ''' Get Single Record By Primary Key (PatienId and Type)
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetRecordByID() As Boolean Implements IDetail.GetRecordByID
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()
        Dim lCondition As String = ""

        Try
            lSpParameter(0).ParameterName = "@Table"
            lSpParameter(0).ParameterType = ParameterType.Varchar
            lSpParameter(0).ParameterValue = "PatientInsurance"

            If (PatientInsurance.PatientInsID = 0) Then
                lCondition = "AND PatientID= " & PatientInsurance.PatientID & " AND Type='" & PatientInsurance.Type & "' AND Active='Y'"
            Else
                lCondition = "AND PatientID= " & PatientInsurance.PatientID & " AND PatientInsID=" & PatientInsurance.PatientInsID & " AND Type='" & PatientInsurance.Type & "' AND Active='Y'"
            End If

            lSpParameter(1).ParameterName = "@Cond"
            lSpParameter(1).ParameterType = ParameterType.Varchar
            lSpParameter(1).ParameterValue = lCondition

            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery("SelectAllRecords", lSpParameter)
            Else
                lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
            End If


            With lDs.Tables(0)
                If .Rows.Count > 0 Then

                    Me.PatientInsurance.PatientInsID = .Rows(0)("PatientInsID")
                    Me.PatientInsurance.PatientID = .Rows(0)("PatientID")
                    Me.PatientInsurance.Type = .Rows(0)("Type")
                    Me.PatientInsurance.Active = .Rows(0)("Active")
                    Me.PatientInsurance.Deductable = .Rows(0)("Deductable")
                    Me.PatientInsurance.GroupNo = .Rows(0)("GroupNo")
                    Me.PatientInsurance.InsuranceCompanyName = .Rows(0)("InsuranceCompany")
                    Me.PatientInsurance.InsuranceCompanyID = .Rows(0)("InsuranceCompanyID")
                    Me.PatientInsurance.InsurerId = .Rows(0)("InsurerId")
                    Me.PatientInsurance.PayerId = .Rows(0)("PayerId")
                    Me.PatientInsurance.InsuredAuthorization = .Rows(0)("InsuredAuthorization")
                    Me.PatientInsurance.PlanName = .Rows(0)("PlanName")
                    Me.PatientInsurance.RelationshipToPrimaryInsurer = .Rows(0)("RelationshipToPrimaryInsurer")
                    Me.PatientInsurance.SignatureDate = .Rows(0)("SignatureDate")
                    Me.PatientInsurance.SignatureOfFile = .Rows(0)("SignatureOfFile")
                    Me.PatientInsurance.SubscriberID = .Rows(0)("SubscriberID")
                    Me.PatientInsurance.VisitCopayment = .Rows(0)("VisitCopayment")

                    Me.PatientInsurance.EffectiveDateFrom = IIf(IsDBNull(.Rows(0)("EffectiveDateFrom")), "1/1/1900", .Rows(0)("EffectiveDateFrom"))
                    Me.PatientInsurance.EffectiveDateTo = IIf(IsDBNull(.Rows(0)("EffectiveDateTo")), "1/1/1900", .Rows(0)("EffectiveDateTo"))
                    Me.PatientInsurance.AuthorizationNumber = .Rows(0)("AuthorizationNumber")
                    Me.PatientInsurance.CoInsurance = .Rows(0)("CoInsurance")
                    Me.PatientInsurance.InsuranceCompanyPhoneNumber = .Rows(0)("InsuranceCompanyPhoneNumber")
                    Me.PatientInsurance.InsurerInsuranceType = .Rows(0)("InsurerInsuranceType")
                    Me.PatientInsurance.InsurerInsuranceId = .Rows(0)("InsurerInsuranceId")
                    ''Added by madiha for cardscan image url
                    Me.PatientInsurance.CardFrontImage = .Rows(0)("CardFrontImage")
                    Me.PatientInsurance.CardBackImage = .Rows(0)("CardBackImage")
                    Return True
                Else
                    Return False
                End If
            End With
        Catch ex As Exception
            Throw New Exception(ex.Message & " : DAL\PatientInsurance.GetRecordByID() ")
        End Try

        

    End Function




    Public Function CheckInsurance() As String
        Dim lResult As String

        Dim lSpParameter(5) As SpParameter
        Dim lDs As New DataSet()

        Try
            lSpParameter(0).ParameterName = "@PatientId"
            lSpParameter(0).ParameterType = ParameterType.BigInt
            lSpParameter(0).ParameterValue = PatientInsurance.PatientID

            lSpParameter(1).ParameterName = "@InsuranceId"
            lSpParameter(1).ParameterType = ParameterType.BigInt
            lSpParameter(1).ParameterValue = PatientInsurance.InsuranceCompanyID

            lSpParameter(2).ParameterName = "@Type"
            lSpParameter(2).ParameterType = ParameterType.Varchar
            lSpParameter(2).ParameterValue = PatientInsurance.Type

            lSpParameter(3).ParameterName = "@InsurerId"
            lSpParameter(3).ParameterType = ParameterType.BigInt
            lSpParameter(3).ParameterValue = PatientInsurance.InsurerId

            lSpParameter(4).ParameterName = "@RelationShip"
            lSpParameter(4).ParameterType = ParameterType.Varchar
            lSpParameter(4).ParameterValue = PatientInsurance.RelationshipToPrimaryInsurer

            lSpParameter(5).ParameterName = "@InsurerInsuranceId"
            lSpParameter(5).ParameterType = ParameterType.BigInt
            lSpParameter(5).ParameterValue = PatientInsurance.InsurerInsuranceId


            If Connection.IsTransactionAlive() Then
                lResult = Convert.ToString(Connection.ExecuteTransactionScalarCommand("CheckPatientInsurance", lSpParameter))
            Else
                lResult = Convert.ToString(Connection.ExecuteScalarCommand("CheckPatientInsurance", lSpParameter))
            End If

            Return lResult
        Catch ex As Exception
            Throw New Exception(ex.Message & " : DAL\PatientInsurance.CheckInsurance() ")
        End Try

        

    End Function
    Public Function CheckSelfInsurance() As Boolean
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()


        Try
            lSpParameter(0).ParameterName = "@Table"
            lSpParameter(0).ParameterType = ParameterType.Varchar
            lSpParameter(0).ParameterValue = "PatientInsurance"

            lSpParameter(1).ParameterName = "@Cond"
            lSpParameter(1).ParameterType = ParameterType.Varchar
            lSpParameter(1).ParameterValue = "AND PatientID= " & PatientInsurance.PatientID & "AND Type='" & PatientInsurance.Type & "' AND PatientInsID=" & PatientInsurance.PatientInsID & " AND Active='Y'"

            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery("CheckSelfInsurance", lSpParameter)
            Else
                lDs = Connection.ExecuteQuery("CheckSelfInsurance", lSpParameter)
            End If


            With lDs.Tables(0)
                If .Rows.Count > 0 Then
                    Me.PatientInsurance.PatientInsID = .Rows(0)("PatientInsID")
                    Me.PatientInsurance.PatientID = .Rows(0)("PatientID")
                    Me.PatientInsurance.Type = .Rows(0)("Type")
                    Me.PatientInsurance.Active = .Rows(0)("Active")
                    Me.PatientInsurance.Deductable = .Rows(0)("Deductable")
                    Me.PatientInsurance.GroupNo = .Rows(0)("GroupNo")
                    Me.PatientInsurance.InsuranceCompanyName = .Rows(0)("InsuranceCompany")
                    Me.PatientInsurance.InsuranceCompanyID = .Rows(0)("InsuranceCompanyID")
                    Me.PatientInsurance.InsurerId = .Rows(0)("InsurerId")
                    Me.PatientInsurance.PayerId = .Rows(0)("PayerId")
                    Me.PatientInsurance.InsuredAuthorization = .Rows(0)("InsuredAuthorization")
                    Me.PatientInsurance.PlanName = .Rows(0)("PlanName")
                    Me.PatientInsurance.RelationshipToPrimaryInsurer = .Rows(0)("RelationshipToPrimaryInsurer")
                    Me.PatientInsurance.SignatureDate = .Rows(0)("SignatureDate")
                    Me.PatientInsurance.SignatureOfFile = .Rows(0)("SignatureOfFile")
                    Me.PatientInsurance.SubscriberID = .Rows(0)("SubscriberID")
                    Me.PatientInsurance.VisitCopayment = .Rows(0)("VisitCopayment")

                    Me.PatientInsurance.EffectiveDateFrom = .Rows(0)("EffectiveDateFrom")
                    Me.PatientInsurance.EffectiveDateTo = .Rows(0)("EffectiveDateTo")
                    Me.PatientInsurance.AuthorizationNumber = .Rows(0)("AuthorizationNumber")
                    Me.PatientInsurance.CoInsurance = .Rows(0)("CoInsurance")
                    Me.PatientInsurance.InsuranceCompanyPhoneNumber = .Rows(0)("InsuranceCompanyPhoneNumber")
                    Me.PatientInsurance.InsurerInsuranceType = .Rows(0)("InsurerInsuranceType")
                    Me.PatientInsurance.InsurerInsuranceId = .Rows(0)("InsurerInsuranceId")

                    ''Added by madiha for cardscan image url
                    Me.PatientInsurance.CardFrontImage = .Rows(0)("CardFrontImage")
                    Me.PatientInsurance.CardBackImage = .Rows(0)("CardBackImage")
                    Return True
                End If
            End With
        Catch ex As Exception
            Throw New Exception(ex.Message & " : Billing\DAL\PatientInsurance.CheckSelfInsurance()")
        End Try

        Return False

    End Function

    Public Function GetActiveInsurances(ByVal lCondition As String) As System.Data.DataSet
        Dim lDs As New DataSet()
        Dim lQuery As String
        lQuery = "select FullType= case " _
   & "when Inc.[Type] = 'S' or Inc.[Type]= 's' then 'Secondary' " _
   & "when Inc.[Type] = 'P' or Inc.[Type]= 'p' then 'Primary' " _
   & "when Inc.[Type] = 'T' or Inc.[Type]= 't' then 'Tertiary' " _
   & "end ,Inc.*, FavInc.CompanyName,FavInc.PayerID,FavInc.AddressLine1 " _
   & "From PatientInsurance Inc, FavouriteInsurance FavInc " _
   & "Where Inc.Active ='Y' " _
   & "And Inc.InsuranceCompanyID <> 0 " _
   & "And Inc.InsuranceCompanyID = FavInc.FavouriteInsuranceID " & lCondition _
   & " Order By FavInc.CompanyName"



        Try
            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If
            Return lDs
        Catch ex As Exception
            Throw New Exception(ex.Message & " : DAL\PatientInsurances.GetActiveInsurances(ByVal lCondition As String) ")
        End Try


    End Function
    '' To set all insurance enries inActive where selected patient insurance is entered as insurer 

    Public Sub SetDependentsInsuranceInActive()

        Dim lQuery As String
        Dim lCondition As String = " AND InsurerInsuranceId=" & Me.PatientInsurance.PatientInsID & "" _
        & " AND InsurerInsuranceId!=0 "
                                      

        Try
            With Me.PatientInsurance

                lQuery = "Update PatientInsurance Set " _
                & "Active ='N'" _
                & "Where 1 = 1 " _
                & lCondition

            End With

            If Connection.IsTransactionAlive() Then
                Connection.ExecuteTransactionCommand(lQuery)
            Else
                Connection.ExecuteCommand(lQuery)
            End If
        Catch ex As Exception
            Throw New Exception(ex.Message & " : DAL\PatientInsurance.SetDependentsInsuranceInActive() ")
        End Try
    End Sub

    Public Sub SetRemovedInsuranceInActive(ByVal pPatientId As String, ByVal pType As String)

        Dim lQuery As String
        Dim lCondition As String = " AND PatientID='" & pPatientId & "' and Type='" & pType & "'"


        Try
            With Me.PatientInsurance

                lQuery = "Update PatientInsurance Set " _
                & "Active ='N' " _
                & "Where 1 = 1 " _
                & lCondition

            End With

            If Connection.IsTransactionAlive() Then
                Connection.ExecuteTransactionCommand(lQuery)
            Else
                Connection.ExecuteCommand(lQuery)
            End If
        Catch ex As Exception
            Throw New Exception(ex.Message & " : DAL\PatientInsurance.SetRemovedInsuranceInActive() ")
        End Try
    End Sub





#End Region




End Class
