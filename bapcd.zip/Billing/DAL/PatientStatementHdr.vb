Imports Microsoft.VisualBasic
Imports ElixirLibrary
Public Class PatientStatementHdrDB
#Region "Fields"
    Private mBatchSentDate As String
    Private mCreatedByUserID As String
#End Region

#Region "Properties"
    Public Property BatchSentDate() As String
        Get
            Return mBatchSentDate
        End Get
        Set(ByVal value As String)
            mBatchSentDate = value
        End Set
    End Property

    Public Property CreatedByUserID() As String
        Get
            Return mCreatedByUserID
        End Get
        Set(ByVal value As String)
            mCreatedByUserID = value
        End Set
    End Property
#End Region


End Class

Public Class PatientStatementHdr
#Region "Fields"
    Private mConnection As Connection
    Private mConnectionString As String
    Private mPatientStatementHdrDB As New PatientStatementHdrDB

#End Region

#Region "Property"
    Public ReadOnly Property Connection() As ElixirLibrary.Connection
        Get
            Return mConnection
        End Get
    End Property

    Public ReadOnly Property ConnectionString() As String
        Get
            Return mConnectionString
        End Get
    End Property
    Public Property PatientStatementHdr() As PatientStatementHdrDB
        Get
            Return mPatientStatementHdrDB
        End Get
        Set(ByVal value As PatientStatementHdrDB)
            mPatientStatementHdrDB = value
        End Set
    End Property

#End Region

#Region "Constructor"
    ''' <summary>
    ''' Creates new Conection Object based on Given Connection String 
    ''' </summary>
    ''' <param name="pConnectionString">
    ''' Contains Connection String 
    ''' </param>
    ''' <remarks>
    ''' Use when not using transaction
    ''' Must Specify Connection String other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnectionString As String)
        If pConnectionString = "" Then
            Throw New ArgumentException("ConnectionString can not be empty")
        End If

        mConnectionString = pConnectionString
        mConnection = New Connection(mConnectionString)

    End Sub

    ''' <summary>
    ''' Assign given connection to the current Object
    ''' </summary>
    ''' <param name="pConnection">
    ''' Contains refrence to the connection object
    ''' </param>
    ''' <remarks>
    ''' Use when  using Transaction
    ''' Must Specify Connection other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnection As Connection)
        If pConnection Is Nothing Then
            Throw New ArgumentException("Connection can not be empty")
        End If

        mConnection = pConnection
    End Sub
#End Region

    Public Function InsertRecord() As Integer
        Dim lXmlDocument As New XmlDocument
        Dim lXmlElement As XmlElement


        Try
            lXmlDocument.LoadXml("<PatientStatementHdrs></PatientStatementHdrs>")
            lXmlElement = lXmlDocument.CreateElement("PatientStatementHdr")

            With lXmlElement

                .SetAttribute("BatchSentDate", Now.Date)
                .SetAttribute("CreatedByUserID", PatientStatementHdr.CreatedByUserID)
                .SetAttribute("BatchXml", "")


            End With

            lXmlDocument.DocumentElement.AppendChild(lXmlElement.CloneNode(True))

            If Connection.IsTransactionAlive() Then
                Connection.ExecuteTransactionCommand("InsertPatientStatementHdr", lXmlDocument.InnerXml.ToString)
            Else
                Connection.ExecuteCommand("InsertPatientStatementHdr", lXmlDocument.InnerXml.ToString)
            End If


            ''getting maximum batchstatementid.........

            Dim lQuery As String
            Try
                Dim lDs As New DataSet()
                lQuery = "Select Max(StatementBatchID) as StatementBatchID from PatientStatementHdr"


                If Connection.IsTransactionAlive() Then
                    lDs = Connection.ExecuteTransactionQuery(lQuery)
                Else
                    lDs = Connection.ExecuteQuery(lQuery)
                End If

                Return lDs.Tables(0).Rows(0).Item(0).ToString
            Catch ex As Exception
                Throw New Exception(ex.Message + " : DAL\Clinic.GetFacilities(ByVal lCondition As String)As System.Data.DataSet ")
            End Try


        Catch ex As Exception

        End Try


    End Function

    Public Function GetMaximumStatementBatchID() As Integer
        Dim lQuery As String
        Try
            Dim lDs As New DataSet()
            lQuery = "Select Max(StatementBatchID) as StatementBatchID from PatientStatementHdr"


            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If

            Return lDs.Tables(0).Rows(0).Item(0).ToString
        Catch ex As Exception
            Throw New Exception(ex.Message + " : DAL\Clinic.GetFacilities(ByVal lCondition As String)As System.Data.DataSet ")
        End Try

    End Function

    Public Function GetAllRecords(ByVal pStatementBatchID As Integer) As DataSet
        Dim lQuery As String
        Try
            Dim lDs As New DataSet()
            lQuery = "Select * from PatientStatementHdr where StatementBatchID=" & pStatementBatchID


            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If

            Return lDs

        Catch ex As Exception
            Throw New Exception(ex.Message + " : DAL\Clinic.GetFacilities(ByVal lCondition As String)As System.Data.DataSet ")
        End Try

    End Function

    Public Function UpdatePatientStatementHdr(ByVal pStatementBatchID As Integer, ByVal pBatchXml As String) As Integer
        Dim lQuery As String
        Try
            Dim lDs As New DataSet()
            lQuery = "Update PatientStatementHdr Set BatchXml='" & pBatchXml & "' where StatementBatchID= " & pStatementBatchID


            If Connection.IsTransactionAlive() Then
                Connection.ExecuteTransactionQuery(lQuery)
            Else
                Connection.ExecuteQuery(lQuery)
            End If


        Catch ex As Exception
            Throw New Exception(ex.Message + " : DAL\Clinic.GetFacilities(ByVal lCondition As String)As System.Data.DataSet ")
        End Try

    End Function

End Class
