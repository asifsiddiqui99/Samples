Imports Microsoft.VisualBasic

Public Class PatientICDDB

#Region "Fields"
    Private mLineId As String
    Private mPatientSuperBillId As String
    Private mCode As String
    Private mDescription As String
    Private mIsGridItem As String
    Private mIsSelected As String
    Private mLineNumber As String
    Private mIMOCode As String
#End Region


#Region "Properties"

    Public Property IMOCode() As String
        Get
            Return mIMOCode
        End Get
        Set(ByVal value As String)
            mIMOCode = value
        End Set
    End Property

    Public Property LineId() As String
        Get
            Return mLineId
        End Get
        Set(ByVal value As String)
            mLineId = value
        End Set
    End Property

    Public Property PatientSuperBillId() As String
        Get
            Return mPatientSuperBillId
        End Get
        Set(ByVal value As String)
            mPatientSuperBillId = value
        End Set
    End Property

    Public Property Code() As String
        Get
            Return mCode
        End Get
        Set(ByVal value As String)
            mCode = value
        End Set
    End Property

    Public Property Description() As String
        Get
            Return mDescription
        End Get
        Set(ByVal value As String)
            mDescription = value
        End Set
    End Property

    Public Property IsGridItem() As String
        Get
            Return mIsGridItem
        End Get
        Set(ByVal value As String)
            mIsGridItem = value
        End Set
    End Property

    Public Property IsSelected() As String
        Get
            Return mIsSelected
        End Get
        Set(ByVal value As String)
            mIsSelected = value
        End Set
    End Property

    Public Property LineNumber() As String
        Get
            Return mLineNumber
        End Get
        Set(ByVal value As String)
            mLineNumber = value
        End Set
    End Property

#End Region
End Class


Public Class PatientICD
#Region "Fields"
    Private mConnection As Connection
    Private mConnectionString
    Private mPatientICD As New PatientICDDB
#End Region

#Region "Property"
    Public ReadOnly Property Connection() As ElixirLibrary.Connection
        Get
            Return mConnection
        End Get
    End Property

    Public ReadOnly Property ConnectionString() As String
        Get
            Return mConnectionString
        End Get
    End Property
    Public Property PatientICD() As PatientICDDB
        Get
            Return mPatientICD
        End Get
        Set(ByVal value As PatientICDDB)
            mPatientICD = value
        End Set
    End Property
#End Region

#Region "Constructor"
    ''' <summary>
    ''' Creates new Conection Object based on Given Connection String 
    ''' </summary>
    ''' <param name="pConnectionString">
    ''' Contains Connection String 
    ''' </param>
    ''' <remarks>
    ''' Use when not using transaction
    ''' Must Specify Connection String other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnectionString As String)
        If pConnectionString = "" Then
            Throw New ArgumentException("ConnectionString can not be empty")
        End If

        mConnectionString = pConnectionString
        mConnection = New Connection(mConnectionString)

    End Sub

    ''' <summary>
    ''' Assign given connection to the current Object
    ''' </summary>
    ''' <param name="pConnection">
    ''' Contains refrence to the connection object
    ''' </param>
    ''' <remarks>
    ''' Use when  using Transaction
    ''' Must Specify Connection other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnection As Connection)
        If pConnection Is Nothing Then
            Throw New ArgumentException("Connection can not be empty")
        End If

        mConnection = pConnection
    End Sub
#End Region

#Region "Method"
    ''' <summary>
    ''' Delete Record Acoording to Given Condition
    ''' </summary>
    ''' <param name="lCondition"></param>
    ''' <remarks></remarks>
    Public Sub DeleteRecord(ByVal lCondition As String)

        Dim lSpParameter(1) As SpParameter

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "PatientICD"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = lCondition

        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand("DeleteRecords", lSpParameter)
        Else
            Connection.ExecuteCommand("DeleteRecords", lSpParameter)
        End If

    End Sub
    ''' <summary>
    ''' Delete Record on Primary Key
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub DeleteRecordByID()
        Dim lCondition As String

        lCondition = "AND PatientSuperBillId= " & PatientICD.PatientSuperBillId
        DeleteRecord(lCondition)

    End Sub
    ''' <summary>
    ''' Get All Records unconditional
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetAllRecords(ByVal lTable As String) As System.Data.DataSet
        Dim lCondition As String = ""
        Dim lDs As New DataSet()

        lDs = GetAllRecords(lCondition, lTable)

        Return lDs
    End Function
    ''' <summary>
    ''' Get  Records on specified Condition
    ''' </summary>
    ''' <param name="lCondition"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    ''' 
    Public Function GetAllRecords(ByVal lCondition As String, ByVal lTable As String) As System.Data.DataSet
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = lTable

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = lCondition

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("SelectAllRecords", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
        End If

        Return lDs

    End Function
    ''' <summary>
    ''' Insert record
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub InsertRecord()
        Dim lXmlDocument As New XmlDocument
        Dim lXmlElement As XmlElement

        lXmlDocument.LoadXml("<PatientICDies></PatientICDies>")
        lXmlElement = lXmlDocument.CreateElement("PatientICD")


        With lXmlElement
            .SetAttribute("PatientSuperBillId", PatientICD.PatientSuperBillId)
            .SetAttribute("Code", PatientICD.Code)
            .SetAttribute("Description", PatientICD.Description)
            .SetAttribute("IsGridItem", PatientICD.IsGridItem)
            .SetAttribute("IsSelected", PatientICD.IsSelected)
            .SetAttribute("LineNumber", PatientICD.LineNumber)
            .SetAttribute("IMOCode", PatientICD.IMOCode)

        End With

        lXmlDocument.DocumentElement.AppendChild(lXmlElement.CloneNode(True))

        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand("InsertPatientICD", lXmlDocument.InnerXml.ToString)
        Else
            Connection.ExecuteCommand("InsertPatientICD", lXmlDocument.InnerXml.ToString)
        End If

    End Sub
    ''' <summary>
    ''' Update Record unconditional
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub UpdateRecord()
        Dim lCondition As String

        lCondition = "And PatientSuperBillID = " & Me.PatientICD.PatientSuperBillId
        UpdateRecord(lCondition)

    End Sub
    Public Sub UpdateRecord(ByVal lCondition As String)

        Dim lQuery As String

        With Me.PatientICD

            lQuery = "Update PatientCPT Set  " _
                        & "PatientSuperBillId =" & .PatientSuperBillId & ", " _
                        & "Code ='" & .Code & "', " _
                        & "Description ='" & .Description & "', " _
                        & "IsGridItem ='" & .IsGridItem & "', " _
                        & "IsSelected ='" & .IsSelected & "', " _
                        & "LineNumber =" & .LineNumber & " " _
                        & "Where 1 = 1 " _
                        & lCondition


        End With

        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand(lQuery)
        Else
            Connection.ExecuteCommand(lQuery)
        End If
    End Sub
    ''' <summary>
    ''' Get Single Record By Primary Key
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetRecordByID(ByVal lTable As String) As Boolean
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = lTable

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = "And LineID = " & PatientICD.LineId

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("SelectAllRecords", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
        End If


        With lDs.Tables(0)
            If .Rows.Count > 0 Then

                Me.PatientICD.LineId = .Rows(0)("LineId")
                Me.PatientICD.PatientSuperBillId = .Rows(0)("PatientSuperBillId")
                Me.PatientICD.Code = .Rows(0)("Code")
                Me.PatientICD.Description = .Rows(0)("Description")
                Me.PatientICD.IsGridItem = .Rows(0)("IsGridItem")
                Me.PatientICD.IsSelected = .Rows(0)("IsSelected")
                Me.PatientICD.LineNumber = .Rows(0)("LineNumber")

                Return True
            End If
        End With

        Return False

    End Function



    Public Function GetPatientICDCollection(ByVal pCondition As String) As PatientICDColl
        Dim lCond As String
        Dim lDs As DataSet
        Dim lPatientICD As PatientICDDB
        Dim lPatientICDColl As New PatientICDColl()

        lCond = " And PatientSuperBillId =" & Me.PatientICD.PatientSuperBillId & " " & pCondition & " Order By LineNumber "
        lDs = GetAllRecords(lCond, "PatientICD")

        If lDs.Tables(0).Rows.Count > 0 Then

            For Each lRow As DataRow In lDs.Tables(0).Rows

                lPatientICD = New PatientICDDB()

                lPatientICD.LineId = lRow("LineId")
                lPatientICD.PatientSuperBillId = lRow("PatientSuperBillId")
                lPatientICD.Code = lRow("Code")
                lPatientICD.Description = lRow("Description")
                lPatientICD.IsGridItem = lRow("IsGridItem")
                lPatientICD.IsSelected = lRow("IsSelected")
                lPatientICD.LineNumber = lRow("LineNumber")

                lPatientICDColl.Add(lPatientICD)
            Next
        End If

        Return lPatientICDColl
    End Function


    Public Sub InsertPatientICD(ByVal pXmlContent As String)
        Try
            If Connection.IsTransactionAlive() Then
                Connection.ExecuteTransactionCommand("InsertPatientICDForEncounter", pXmlContent)
            Else
                Connection.ExecuteCommand("InsertPatientICDForEncounter", pXmlContent)
            End If

        Catch ex As Exception
            Throw New Exception(ex.Message + ": DAl/PatientICD.InsertPatientICD()")

        End Try
    End Sub
#End Region

End Class

Public Class PatientICDColl
    Inherits CollectionBase


    Public Function Add(ByVal pPatientICD As PatientICDDB) As Integer
        Return List.Add(pPatientICD)
    End Function

    Public Sub Remove(ByVal pPatientICD As PatientICDDB)
        Dim lIndex As Integer

        lIndex = IndexOf(pPatientICD)

        If lIndex > -1 Then
            List.RemoveAt(lIndex)
        End If

    End Sub

    Default Public Property Item(ByVal Index As Integer) As PatientICDDB
        Get
            Return CType(List.Item(Index), PatientICDDB)
        End Get
        Set(ByVal Value As PatientICDDB)
            List.Item(Index) = Value
        End Set
    End Property

    Public Shadows Function Count() As Integer
        Return List.Count
    End Function


    Public Function IndexOf(ByVal obj As Object) As Integer
        Dim lIndex As Integer = 0
        Dim lFound As Integer = 0

        For Each lObj As Object In List
            lFound = CType(lObj, PatientICDDB).Code.CompareTo(CType(obj, PatientICDDB).Code)
            If lFound = 0 Then
                Return lIndex
            End If
            lIndex += 1
        Next
        Return -1

    End Function

End Class