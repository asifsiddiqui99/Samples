Imports Microsoft.VisualBasic

Public Class FeeSchedule
#Region "Fields"
    Private mConnection As Connection
    Private mConnectionString As String

    Private mCPTCode As String = ""
    Private mDescription As String = ""
    Private mFee As Integer = 0
    Private mCreateDate As Date
    Private mModifiedDate As Date
    Private mFavInsuranceId As Integer = 0
#End Region


#Region "Properties"
    Public Property CPTCode() As String
        Get
            Return mCPTCode
        End Get
        Set(ByVal value As String)
            mCPTCode = value
        End Set
    End Property
    Public Property Description() As String
        Get
            Return mDescription
        End Get
        Set(ByVal value As String)
            mDescription = value
        End Set
    End Property
    Public Property Fee() As Integer
        Get
            Return mFee
        End Get
        Set(ByVal value As Integer)
            mFee = value
        End Set
    End Property
    Public Property FavInsuranceId() As Integer
        Get
            Return mFavInsuranceId
        End Get
        Set(ByVal value As Integer)
            mFavInsuranceId = value
        End Set
    End Property
    Public Property CreateDate() As Date
        Get
            Return mCreateDate
        End Get
        Set(ByVal value As Date)
            mCreateDate = value
        End Set
    End Property
    Public Property ModifiedDate() As Date
        Get
            Return mModifiedDate
        End Get
        Set(ByVal value As Date)
            mModifiedDate = value
        End Set
    End Property
#End Region
#Region "Property"

    Public ReadOnly Property Connection() As ElixirLibrary.Connection
        Get
            Return mConnection
        End Get
    End Property
    Public ReadOnly Property ConnectionString() As String
        Get
            Return mConnectionString
        End Get
    End Property
#End Region
#Region "Constructor"
    Public Sub New(ByVal pConnectionString As String)
        If pConnectionString = "" Then
            Throw New ArgumentException("ConnectionString can not be empty")
        End If
        mConnectionString = pConnectionString
        mConnection = New Connection(mConnectionString)

    End Sub
    Public Sub New(ByVal pConnection As Connection)
        If pConnection Is Nothing Then
            Throw New ArgumentException("Connection can not be empty")
        End If
        mConnection = pConnection
    End Sub
#End Region

#Region "Methods"
    Public Function SearchFeeSchedule(ByVal pCond As Integer) As DataSet
        Dim lQuery As String
        Dim lDs As New DataSet()
        Try
            lQuery = "select CompanyName,ID,CreateDate,ModifiedDate,FavInsuranceId from FeeSchedulehdr where FavInsuranceId=" & pCond & ""
            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If
            Return lDs
        Catch ex As Exception
            Return lDs
        End Try
    End Function
    'this method is for filling the Combo items'
    Public Function GetFavInsurance() As DataSet
        Dim lQuery As String
        Dim lDs As New DataSet()
        Try
            lQuery = "Select CompanyName,FavInsuranceId from FeeSchedulehdr"
            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If
            Return lDs
        Catch ex As Exception
            Return lDs
        End Try
    End Function

    Public Function GetAllFeeSchedule() As DataSet
        Dim lQuery As String
        Dim lDs As New DataSet()
        Try
            lQuery = "Select * from FeeSchedulehdr order by companyName asc"
            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If
            Return lDs
        Catch ex As Exception
            Return lDs
        End Try
    End Function
    Public Function GetFavIDByHdrID(ByVal pCond As Integer) As String
        Dim lQuery As String
        Dim lDs As String
        Try
            lQuery = "select FavInsuranceId from feeScheduleHdr where  ID=" & pCond & ""
            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionScalarCommand(lQuery)
            Else
                lDs = Connection.ExecuteScalarCommand(lQuery)
            End If
            Return lDs
        Catch ex As Exception
            Return Nothing
        End Try
    End Function


    Public Function DeleteFeeSchedule(ByVal pCond As Integer) As Boolean
        Dim lQuery As String
        Dim lDs As New DataSet()
        Try
            lQuery = "delete from FeeScheduledtl where hdrId=" & pCond & ""
            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If

            lQuery = "delete from FeeSchedulehdr where ID=" & pCond & ""
            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If

            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Function AutocompeteQuery(ByVal pCond As String) As DataSet
        Dim lQuery As String
        Dim lDs As New DataSet()
        Try
            lQuery = "select Distinct CompanyName,favInsuranceId from FeeSchedulehdr where CompanyName like '" & pCond & "%' "
            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If
            Return lDs
        Catch ex As Exception

        End Try
        Return Nothing
    End Function

    Public Function GetCompanyName(ByVal pCond As Integer) As DataSet
        Dim lQuery As String
        Dim lDs As New DataSet()
        Try
            lQuery = "select CompanyName from FeeSchedulehdr where Id='" & pCond & "' "
            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If
            Return lDs
        Catch ex As Exception

        End Try
        Return Nothing
    End Function

    Public Function FillSelectedGrid(ByVal pCond As Integer) As DataSet
        Dim lQuery As String
        Dim lDs As New DataSet()
        Try
            'lQuery = "select  CPTCode ,Description,Fee ,Modifiers from FeeScheduledtl where hdrId IN(select ID from FeeSchedulehdr where favInsuranceId=" & pCond & ")"
            lQuery = "select  CPTCode ,Description,Fee ,Modifiers from FeeScheduledtl where hdrId =" & pCond & " order by CPTCode "
            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If
            Return lDs
        Catch ex As Exception

        End Try
        Return Nothing
    End Function

    Public Function GetSelectedCmpnyNames(ByVal pCond As Integer) As DataSet
        Dim lQuery As String
        Dim lDs As New DataSet()
        Try
            lQuery = "select CompanyName,FavouriteInsuranceID from FavouriteInsurance where Not FavouriteInsuranceID=" & pCond & " order by CompanyName"
            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If
            Return lDs
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

#End Region

#Region "Methods IMRan"
    Public Function SearchFeeSchedule(ByVal pCond As String) As DataSet
        Dim lQuery As String = ""
        Dim lDs As New DataSet()
        Try
            'lQuery = "SELECT Employee.FirstName + ' ' + Employee.LastName as DoctorName,BillingProviderId,BillingProvider.FirstName + ' ' + BillingProvider.MiddleName + ' ' + BillingProvider.LastName as [Name],BillingProvider.AddressLine1,BillingProvider.AddressLine2,BillingProvider.City,BillingProvider.State,BillingProvider.ZipCode,BillingProvider.Phone1,BillingProvider.Phone2,BillingProvider.Fax,BillingProvider.Email,BillingProvider.NPI,BillingProvider.TaxID,BillingProvider.SSN,BillingProvider.ProviderID,BillingProvider.ProviderNPI,EntryType=(Case BillingProvider.EntryType when 'G' then 'General' else 'Specific' end),BillingProvider.EntryInsuranceTypeCode,BillingProvider.EntryInsuranceTypeValue FROM BillingProvider,Employee   where 1=1 and BillingProvider.ProviderID *=Employee.EmployeeID  " & pCond
            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If
            Return lDs
        Catch ex As Exception
            Return lDs
        End Try
    End Function


    Public Function AutocompeteQueryForAddFeeSch(ByVal pCond As String) As DataSet
        Dim lQuery As String
        Dim lDs As New DataSet()
        Try
            lQuery = "SELECT FavouriteInsuranceID,CompanyName from FavouriteInsurance where CompanyName like '" & pCond & "%' order by CompanyName"
            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If
            Return lDs
        Catch ex As Exception

        End Try
        Return Nothing
    End Function

    Public Function SaveFeeSchedule(ByVal pGridView As GridView, ByVal pFavID As Integer, ByVal pCompanyName As String, ByVal pHdrID As Integer, ByVal pUpdate As String) As Boolean
        Dim lDs As New DataSet()
        Dim lXmlDocument As New XmlDocument
        Dim lXmlElement As XmlElement

        Try




            lXmlDocument.LoadXml("<FeeSchedules></FeeSchedules>")
            '            lXmlElement = lXmlDocument.DocumentElement


            With lXmlDocument.DocumentElement
                If pUpdate.Equals("Update") Then
                    .SetAttribute("ID", pHdrID)
                End If
                .SetAttribute("FavInsuranceId", pFavID)
                .SetAttribute("CompanyName", pCompanyName)
                .SetAttribute("CreateDate", Date.Now())
                .SetAttribute("ModifiedDate", Date.Now())
            End With

            'lXmlDocument.DocumentElement.AppendChild(lXmlElement.CloneNode(True))

            For index As Integer = 0 To pGridView.Rows.Count - 1
                lXmlElement = lXmlDocument.CreateElement("FeeSchedule")


                With lXmlElement
                    .SetAttribute("CPTCode", pGridView.Rows(index).Cells(0).Text.Replace("&nbsp;", ""))
                    .SetAttribute("Description", pGridView.Rows(index).Cells(1).Text.Replace("&nbsp;", "").Replace("amp;", ""))
                    .SetAttribute("Modifiers", pGridView.Rows(index).Cells(3).Text.Replace("&nbsp;", "").Replace("amp;", ""))

                    'If CType(pGridView.Rows(index).Cells(2).FindControl("TextBox2"), TextBox).Text.Equals("") Then
                    '    CType(pGridView.Rows(index).Cells(2).FindControl("TextBox2"), TextBox).Text = "0"
                    'End If
                    .SetAttribute("Fee", pGridView.Rows(index).Cells(2).Text.Replace("&nbsp;", "").Replace("amp;", ""))
                End With

                lXmlDocument.DocumentElement.AppendChild(lXmlElement.CloneNode(True))
            Next

            If pUpdate.Equals("Update") Then
                Connection.ExecuteCommand("UpdateFeeSchedule", lXmlDocument.DocumentElement.OuterXml.ToString)
            Else
                Connection.ExecuteCommand("InsertFeeSchedule", lXmlDocument.DocumentElement.OuterXml.ToString)
            End If
            Return True
        Catch ex As Exception
            Return False
        End Try



    End Function
    Public Function SaveFeeSchedule(ByVal pXmlDoc As String) As Boolean


        Try
            If Connection.IsTransactionAlive() Then
                Connection.ExecuteTransactionCommand("InsertFeeSchedule", pXmlDoc)
            Else
                Connection.ExecuteCommand("InsertFeeSchedule", pXmlDoc)
            End If


        Catch ex As Exception
            Return False
        End Try



    End Function

    Public Function GetFavouriteInsurance() As DataSet
        Dim lQuery As String
        Dim lDs As New DataSet()
        Try
            lQuery = "SELECT FavouriteInsuranceID,CompanyName from FavouriteInsurance order by CompanyName asc"

            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If
            Return lDs
        Catch ex As Exception
            Return lDs
        End Try
    End Function


    Public Function GetFeeSchedule(ByVal pFeeschduleID As Integer) As DataSet
        Dim lQuery As String
        Dim lDs As New DataSet()
        Try
            lQuery = "select a.CPTCode as CPTCode,a.Description as Description,a.Fee as Fee , a.Modifiers from   FeeScheduledtl as a join FeeScheduleHdr as b on a.HdrID = b.ID" _
                      & " where b.id = " & pFeeschduleID.ToString & " order by CPTCode"

            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If
            Return lDs
        Catch ex As Exception
            Return lDs
        End Try
    End Function
    Public Function DeleteFeeScheduleImport(ByVal pFavID As Integer) As Boolean

        Try
            Dim lSpParameter(0) As SpParameter

            lSpParameter(0).ParameterName = "@FavID"
            lSpParameter(0).ParameterType = ParameterType.Varchar
            lSpParameter(0).ParameterValue = pFavID

            If Connection.IsTransactionAlive() Then
                Connection.ExecuteTransactionCommand("DeleteFeeSchedule", lSpParameter)
                Return True
            Else
                Connection.ExecuteCommand("DeleteFeeSchedule", lSpParameter)
            End If
        Catch ex As Exception
            Return False
        End Try
    End Function



    Public Function InsuranceCompanyExists(ByVal pFavoriteInsuranceID As Integer, ByVal pFavoriteInsuranceName As String) As Integer


        Dim lQuery As String = String.Empty
        Dim lSpParameter(0) As SpParameter
        Dim lResult As New DataSet

        Try

            lQuery = "Select ID from FeeScheduleHdr where FavInsuranceID =" & pFavoriteInsuranceID & " or upper(CompanyName)='" & pFavoriteInsuranceName & "'"

            lResult = Connection.ExecuteQuery(lQuery)

            If (lResult.Tables.Count > 0 AndAlso lResult.Tables(0).Rows.Count > 0) Then
                Return lResult.Tables(0).Rows(0).Item("ID").ToString
            Else
                Return 0
            End If


        Catch ex As Exception
            Return Nothing
        End Try
    End Function


    Public Function GetModifiers(ByVal pCond As String) As DataSet


        Dim lQuery As String = String.Empty
        Dim lSpParameter(0) As SpParameter
        Dim lResult As DataSet

        Try

            lQuery = "Select * from Modifiers where Modifier Like '%" & pCond & "%'"



            lResult = Connection.ExecuteQuery(lQuery)

            Return lResult



        Catch ex As Exception

        End Try
    End Function

#End Region
End Class
