Imports Microsoft.VisualBasic

Public Class AdjustmentDB

#Region "Fields"
    Private mAdjustmentID As String
    Private mAdjustmentDate As String
    Private mVisitID As String
    Private mCPTCode As String
    Private mAdjustmentDescription As String
    Private mReasonCode As String
    Private mAdjustmentType As String
    Private mAmount As String
    Private mUserID As String
    Private mPaymentDtlID As String
    Private mPaymentID As String
    Private mIsPrevious As String
    Private mCPTID As String
    Private mNotes As String
#End Region


#Region "Properties"
    Public Property AdjustmentID() As String
        Get
            Return mAdjustmentID
        End Get
        Set(ByVal value As String)
            mAdjustmentID = value
        End Set
    End Property

    Public Property AdjustmentDate() As String
        Get
            Return mAdjustmentDate
        End Get
        Set(ByVal value As String)
            mAdjustmentDate = value
        End Set
    End Property

    Public Property VisitID() As String
        Get
            Return mVisitID
        End Get
        Set(ByVal value As String)
            mVisitID = value
        End Set
    End Property


    Public Property CPTCode() As String
        Get
            Return mCPTCode
        End Get
        Set(ByVal value As String)
            mCPTCode = value
        End Set
    End Property

    Public Property AdjustmentDescription() As String
        Get
            Return mAdjustmentDescription
        End Get
        Set(ByVal value As String)
            mAdjustmentDescription = value
        End Set
    End Property

    Public Property ReasonCode() As String
        Get
            Return mReasonCode
        End Get
        Set(ByVal value As String)
            mReasonCode = value
        End Set
    End Property

    Public Property AdjustmentType() As String
        Get
            Return mAdjustmentType
        End Get
        Set(ByVal value As String)
            mAdjustmentType = value
        End Set
    End Property

    Public Property Amount() As String
        Get
            Return mAmount
        End Get
        Set(ByVal value As String)
            mAmount = value
        End Set
    End Property

    Public Property UserID() As String
        Get
            Return mUserID
        End Get
        Set(ByVal value As String)
            mUserID = value
        End Set
    End Property

    Public Property PaymentDtlID() As String
        Get
            Return mPaymentDtlID
        End Get
        Set(ByVal value As String)
            mPaymentDtlID = value
        End Set
    End Property

    Public Property PaymentID() As String
        Get
            Return mPaymentID
        End Get
        Set(ByVal value As String)
            mPaymentID = value
        End Set
    End Property

    Public Property IsPrevious() As String
        Get
            Return mIsPrevious
        End Get
        Set(ByVal value As String)
            mIsPrevious = value
        End Set
    End Property

    Public Property CPTID() As String
        Get
            Return mCPTID
        End Get
        Set(ByVal value As String)
            mCPTID = value
        End Set
    End Property

    Public Property Notes() As String
        Get
            Return mNotes
        End Get
        Set(ByVal value As String)
            mNotes = value
        End Set
    End Property

#End Region


End Class


Public Class AdjustmentCollection
    Inherits CollectionBase

    Public Function Add(ByVal pAdjustmentDB As AdjustmentDB) As Integer
        Return List.Add(pAdjustmentDB)
    End Function

    Public Sub Remove(ByVal pAdjustmentDB As AdjustmentDB)
        List.Remove(pAdjustmentDB)
    End Sub

    Default Public Property Item(ByVal Index As Integer) As AdjustmentDB
        Get
            Return CType(List.Item(Index), AdjustmentDB)
        End Get
        Set(ByVal Value As AdjustmentDB)
            List.Item(Index) = Value
        End Set
    End Property

    Public Shadows Function Count() As Integer
        Return List.Count
    End Function



End Class

Public Class Adjustment
    Implements IDetail


#Region "Fields"
    Private mConnection As Connection
    Private mConnectionString As String
    Private mAdjustment As New AdjustmentDB

#End Region

#Region "Property"
    Public ReadOnly Property Connection() As ElixirLibrary.Connection Implements IDetail.Connection
        Get
            Return mConnection
        End Get
    End Property

    Public ReadOnly Property ConnectionString() As String Implements IDetail.ConnectionString
        Get
            Return mConnectionString
        End Get
    End Property
    Public Property Adjustment() As AdjustmentDB
        Get
            Return mAdjustment
        End Get
        Set(ByVal value As AdjustmentDB)
            mAdjustment = value
        End Set
    End Property

#End Region

#Region "Constructor"
    ''' <summary>
    ''' Creates new Conection Object based on Given Connection String 
    ''' </summary>
    ''' <param name="pConnectionString">
    ''' Contains Connection String 
    ''' </param>
    ''' <remarks>
    ''' Use when not using transaction
    ''' Must Specify Connection String other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnectionString As String)
        If pConnectionString = "" Then
            Throw New ArgumentException("ConnectionString can not be empty")
        End If

        mConnectionString = pConnectionString
        mConnection = New Connection(mConnectionString)

    End Sub

    ''' <summary>
    ''' Assign given connection to the current Object
    ''' </summary>
    ''' <param name="pConnection">
    ''' Contains refrence to the connection object
    ''' </param>
    ''' <remarks>
    ''' Use when  using Transaction
    ''' Must Specify Connection other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnection As Connection)
        If pConnection Is Nothing Then
            Throw New ArgumentException("Connection can not be empty")
        End If

        mConnection = pConnection
    End Sub
#End Region


#Region "Method"
    ''' <summary>
    ''' Delete Record Acoording to Given Condition
    ''' </summary>
    ''' <param name="lCondition"></param>
    ''' <remarks></remarks>
    Public Sub DeleteRecord(ByVal lCondition As String) Implements IDetail.DeleteRecord

        Throw New NotImplementedException
    End Sub
    ''' <summary>
    ''' Delete Record on Primary Key
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub DeleteRecordByID() Implements IDetail.DeleteRecordByID

        Throw New NotImplementedException

    End Sub
    ''' <summary>
    ''' Get All Records unconditional
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetAllRecords() As System.Data.DataSet Implements IDetail.GetAllRecords
        Dim lCondition As String = ""
        Dim lDs As New DataSet()

        lDs = GetAllRecords(lCondition)

        Return lDs
    End Function
    ''' <summary>
    ''' Get  Records on specified Condition
    ''' </summary>
    ''' <param name="lCondition"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetAllRecords(ByVal lCondition As String) As System.Data.DataSet Implements IDetail.GetAllRecords
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "Adjustment"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = lCondition

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("SelectAllRecords", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
        End If

        Return lDs

    End Function

    ''' <summary>
    ''' Insert record
    ''' </summary>
    ''' <remarks></remarks>
    'Public Sub InsertRecord() Implements IDetail.InsertRecord
    '    Dim lXmlDocument As New XmlDocument
    '    Dim lXmlElement As XmlElement

    '    Try
    '        lXmlDocument.LoadXml("<Adjustments></Adjustments>")
    '        lXmlElement = lXmlDocument.CreateElement("Adjustment")

    '        With lXmlElement

    '            '.SetAttribute("AdjustmentID", Adjustment.AdjustmentID)
    '            .SetAttribute("AdjustmentDate", Adjustment.AdjustmentDate)
    '            .SetAttribute("VisitID", Adjustment.VisitID)
    '            .SetAttribute("CPTCode", Adjustment.CPTCode)
    '            .SetAttribute("AdjustmentDescription", Adjustment.AdjustmentDescription)
    '            .SetAttribute("ReasonCode", Adjustment.ReasonCode)
    '            .SetAttribute("AdjustmentType", Adjustment.AdjustmentType)
    '            .SetAttribute("Amount", Adjustment.Amount)
    '            .SetAttribute("UserID", Adjustment.UserID)
    '            .SetAttribute("PaymentDtlID", Adjustment.PaymentDtlID)
    '            .SetAttribute("PaymentID", Adjustment.PaymentID)

    '        End With

    '        lXmlDocument.DocumentElement.AppendChild(lXmlElement.CloneNode(True))

    '        If Connection.IsTransactionAlive() Then
    '            Connection.ExecuteTransactionCommand("InsertAdjustment", lXmlDocument.InnerXml.ToString)
    '        Else
    '            Connection.ExecuteCommand("InsertAdjustment", lXmlDocument.InnerXml.ToString)
    '        End If

    '    Catch ex As Exception
    '        Throw New Exception(ex.Message + " : DAL\Adjustment.InsertRecord() ")
    '    End Try


    'End Sub

    Public Sub InsertRecord() Implements IDetail.InsertRecord
        Dim lXmlDocument As New XmlDocument
        Dim lXmlElement As XmlElement

        Try
            lXmlDocument.LoadXml("<Adjustments></Adjustments>")
            lXmlElement = lXmlDocument.CreateElement("Adjustment")

            With lXmlElement

                '.SetAttribute("AdjustmentID", Adjustment.AdjustmentID)
                .SetAttribute("AdjustmentDate", Adjustment.AdjustmentDate)
                .SetAttribute("VisitID", Adjustment.VisitID)
                .SetAttribute("CPTCode", Adjustment.CPTCode)
                .SetAttribute("AdjustmentDescription", Adjustment.AdjustmentDescription)
                .SetAttribute("ReasonCode", Adjustment.ReasonCode)
                .SetAttribute("AdjustmentType", Adjustment.AdjustmentType)
                .SetAttribute("Amount", Adjustment.Amount)
                .SetAttribute("UserID", Adjustment.UserID)
                .SetAttribute("PaymentDtlID", Adjustment.PaymentDtlID)
                .SetAttribute("PaymentID", Adjustment.PaymentID)
                .SetAttribute("CptId", Adjustment.CPTID)
                .SetAttribute("Notes", Adjustment.Notes)
            End With

            lXmlDocument.DocumentElement.AppendChild(lXmlElement.CloneNode(True))

            If Connection.IsTransactionAlive() Then
                Connection.ExecuteTransactionCommand("InsertAdjustment", lXmlDocument.InnerXml.ToString)
            Else
                Connection.ExecuteCommand("InsertAdjustment", lXmlDocument.InnerXml.ToString)
            End If

        Catch ex As Exception
            Throw New Exception(ex.Message + " : DAL\Adjustment.InsertRecord() ")
        End Try


    End Sub
    ''' <summary>
    ''' Update Record unconditional
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub UpdateRecord() Implements IDetail.UpdateRecord

        Throw New NotImplementedException

    End Sub
    Public Sub UpdateRecord(ByVal lCondition As String) Implements IDetail.UpdateRecord

        Throw New NotImplementedException

    End Sub
    


    Public Function GetRecordByID() As Boolean Implements IDetail.GetRecordByID

        Throw New NotImplementedException

    End Function


    Public Function InsertAdjustmentOnly() As String
        Dim lXmlDocument As New XmlDocument
        Dim lXmlElement As XmlElement
        'Dim lds As New DataSet
        Dim lID As String = ""
        Try
            lXmlDocument.LoadXml("<Adjustments></Adjustments>")
            lXmlElement = lXmlDocument.CreateElement("Adjustment")

            With lXmlElement

                '.SetAttribute("AdjustmentID", Adjustment.AdjustmentID)
                .SetAttribute("AdjustmentDate", Adjustment.AdjustmentDate)
                .SetAttribute("VisitID", Adjustment.VisitID)
                .SetAttribute("CPTCode", Adjustment.CPTCode)
                .SetAttribute("AdjustmentDescription", Adjustment.AdjustmentDescription)
                .SetAttribute("ReasonCode", Adjustment.ReasonCode)
                .SetAttribute("AdjustmentType", Adjustment.AdjustmentType)
                .SetAttribute("Amount", Adjustment.Amount)
                .SetAttribute("UserID", Adjustment.UserID)
                .SetAttribute("PaymentDtlID", Adjustment.PaymentDtlID)
                .SetAttribute("PaymentID", Adjustment.PaymentID)

            End With

            lXmlDocument.DocumentElement.AppendChild(lXmlElement.CloneNode(True))

            If Connection.IsTransactionAlive() Then
                lID = Connection.ExecuteTransactionScalarCommand("InsertAdjustmentOnly", lXmlDocument.InnerXml.ToString)
            Else
                lID = Connection.ExecuteScalarCommand("InsertAdjustmentOnly", lXmlDocument.InnerXml.ToString)
            End If

            'If (lds.Tables.Count > 0 AndAlso lds.Tables(0).Rows.Count > 0) Then
            '    lID = lds.Tables(0).Rows(0).Item(0).ToString()
            'End If

            Return lID

        Catch ex As Exception
            Throw New Exception(ex.Message + " : DAL\Adjustment.InsertAdjustmentOnly() ")
        End Try


    End Function

#End Region

End Class