Imports Microsoft.VisualBasic
Imports System.Xml


Public Class RemittanceHdrDB
#Region "Fields"
    'Private mLineId As String = ""
    Private mRemittanceId As String = ""
    Private mReassociationTraceNumber As String = ""
    Private mPaymentId As String = "0"
    Private mRemittanceMessageReceiveDate As String = ""
    Private mCheckAmount As String = "0"
    Private mCheckNumber As String = ""
    Private mCheckDate As String = ""
    Private mProviderAdjustmentAmount As String = "0"
    Private mPrescriberNPI As String = ""
    Private mProviderReference As String = ""
    Private mProductionDate As String = ""
    Private mPayerContactName As String = ""
    Private mPayerCommunicationNumberQualifier As String = ""
    Private mPayerCommunicationNumber As String = ""
    Private mPayerName As String = ""
    Private mPayerAddress As String = ""
    Private mPayerCity As String = ""
    Private mPayerState As String = ""
    Private mPayerZip As String = ""
    Private mAdditionalPayerIdentification As String = ""
    Private mPayeeName As String = ""
    Private mPayeeAddress As String = ""
    Private mPayeeCity As String = ""
    Private mPayeeState As String = ""
    Private mPayeeZip As String = ""
    Private mAdditionalPayeeIdentification As String = ""
    Private mFileName As String = ""
    Private mIsPosted As String = "N"
    Private mFileContent As String = ""

#End Region

#Region "Properties"

    
    Public Property RemittanceId() As String
        Get
            Return mRemittanceId
        End Get
        Set(ByVal value As String)
            mRemittanceId = value
        End Set
    End Property
    Public Property ReassociationTraceNumber() As String
        Get
            Return mReassociationTraceNumber
        End Get
        Set(ByVal value As String)
            mReassociationTraceNumber = value
        End Set
    End Property
    Public Property PaymentId() As String
        Get
            Return mPaymentId
        End Get
        Set(ByVal value As String)
            mPaymentId = value
        End Set
    End Property
    Public Property RemittanceMessageReceiveDate() As String
        Get
            Return mRemittanceMessageReceiveDate
        End Get
        Set(ByVal value As String)
            mRemittanceMessageReceiveDate = value
        End Set
    End Property
    Public Property CheckAmount() As String
        Get
            Return mCheckAmount
        End Get
        Set(ByVal value As String)
            mCheckAmount = value
        End Set
    End Property
    Public Property CheckNumber() As String
        Get
            Return mCheckNumber
        End Get
        Set(ByVal value As String)
            mCheckNumber = value
        End Set
    End Property
    Public Property CheckDate() As String
        Get
            Return mCheckDate
        End Get
        Set(ByVal value As String)
            mCheckDate = value
        End Set
    End Property
    Public Property ProviderAdjustmentAmount() As String
        Get
            Return mProviderAdjustmentAmount
        End Get
        Set(ByVal value As String)
            mProviderAdjustmentAmount = value
        End Set
    End Property
    Public Property PrescriberNPI() As String
        Get
            Return mPrescriberNPI
        End Get
        Set(ByVal value As String)
            mPrescriberNPI = value
        End Set
    End Property
    Public Property ProviderReference() As String
        Get
            Return mProviderReference
        End Get
        Set(ByVal value As String)
            mProviderReference = value
        End Set
    End Property
    Public Property ProductionDate() As String
        Get
            Return mProductionDate
        End Get
        Set(ByVal value As String)
            mProductionDate = value
        End Set
    End Property
    Public Property PayerContactName() As String
        Get
            Return mPayerContactName
        End Get
        Set(ByVal value As String)
            mPayerContactName = value
        End Set
    End Property
    Public Property PayerCommunicationNumberQualifier() As String
        Get
            Return mPayerCommunicationNumberQualifier
        End Get
        Set(ByVal value As String)
            mPayerCommunicationNumberQualifier = value
        End Set
    End Property
    Public Property PayerCommunicationNumber() As String
        Get
            Return mPayerCommunicationNumber
        End Get
        Set(ByVal value As String)
            mPayerCommunicationNumber = value
        End Set
    End Property
    Public Property PayerName() As String
        Get
            Return mPayerName
        End Get
        Set(ByVal value As String)
            mPayerName = value
        End Set
    End Property
    Public Property PayerAddress() As String
        Get
            Return mPayerAddress
        End Get
        Set(ByVal value As String)
            mPayerAddress = value
        End Set
    End Property
    Public Property PayerCity() As String
        Get
            Return mPayerCity
        End Get
        Set(ByVal value As String)
            mPayerCity = value
        End Set
    End Property
    Public Property PayerState() As String
        Get
            Return mPayerState
        End Get
        Set(ByVal value As String)
            mPayerState = value
        End Set
    End Property
    Public Property PayerZip() As String
        Get
            Return mPayerZip
        End Get
        Set(ByVal value As String)
            mPayerZip = value
        End Set
    End Property
    Public Property AdditionalPayerIdentification() As String
        Get
            Return mAdditionalPayerIdentification
        End Get
        Set(ByVal value As String)
            mAdditionalPayerIdentification = value
        End Set
    End Property
    Public Property PayeeName() As String
        Get
            Return mPayeeName
        End Get
        Set(ByVal value As String)
            mPayeeName = value
        End Set
    End Property
    Public Property PayeeAddress() As String
        Get
            Return mPayeeAddress
        End Get
        Set(ByVal value As String)
            mPayeeAddress = value
        End Set
    End Property
    Public Property PayeeCity() As String
        Get
            Return mPayeeCity
        End Get
        Set(ByVal value As String)
            mPayeeCity = value
        End Set
    End Property
    Public Property PayeeState() As String
        Get
            Return mPayeeState
        End Get
        Set(ByVal value As String)
            mPayeeState = value
        End Set
    End Property
    Public Property PayeeZip() As String
        Get
            Return mPayeeZip
        End Get
        Set(ByVal value As String)
            mPayeeZip = value
        End Set
    End Property
    Public Property AdditionalPayeeIdentification() As String
        Get
            Return mAdditionalPayeeIdentification
        End Get
        Set(ByVal value As String)
            mAdditionalPayeeIdentification = value
        End Set
    End Property
    Public Property FileName() As String
        Get
            Return mFileName
        End Get
        Set(ByVal value As String)
            mFileName = value
        End Set
    End Property
    Public Property IsPosted() As String
        Get
            Return mIsPosted
        End Get
        Set(ByVal value As String)
            mIsPosted = value
        End Set
    End Property
    Public Property FileContent() As String
        Get
            Return mFileContent
        End Get
        Set(ByVal value As String)
            mFileContent = value
        End Set
    End Property

#End Region
End Class
Public Class RemittanceHdr
    Implements IDetail
#Region "Fields"
    Private mConnection As Connection
    Private mConnectionString As String
    Private mRemittanceHdr As New RemittanceHdrDB
#End Region

#Region "Property"
    
    Public Property RemittanceHdr() As RemittanceHdrDB
        Get
            Return mRemittanceHdr
        End Get
        Set(ByVal value As RemittanceHdrDB)
            mRemittanceHdr = value
        End Set
    End Property
    Public ReadOnly Property Connection() As ElixirLibrary.Connection Implements IDetail.Connection
        Get
            Return mConnection
        End Get
    End Property

    Public ReadOnly Property ConnectionString() As String Implements IDetail.ConnectionString
        Get
            Return mConnectionString
        End Get
    End Property

#End Region

#Region "Constructor"

    Public Sub New(ByVal pConnectionString As String)
        If pConnectionString = "" Then
            Throw New ArgumentException("ConnectionString can not be empty")
        End If
        mConnectionString = pConnectionString
        mConnection = New Connection(mConnectionString)

    End Sub


    Public Sub New(ByVal pConnection As Connection)
        If pConnection Is Nothing Then
            Throw New ArgumentException("Connection can not be empty")
        End If
        mConnection = pConnection
    End Sub
#End Region

#Region "Methods"

    Public Sub InsertRecord() Implements IDetail.InsertRecord
        Dim lXmlDocument As New XmlDocument
        Dim lXmlElement As XmlElement

        lXmlDocument.LoadXml("<RemittanceHdrs></RemittanceHdrs>")
        lXmlElement = lXmlDocument.CreateElement("RemittanceHdr")

        With lXmlElement

            .SetAttribute("RemittanceId", RemittanceHdr.RemittanceId)
            .SetAttribute("ReassociationTraceNumber", RemittanceHdr.ReassociationTraceNumber)
            .SetAttribute("PaymentId", RemittanceHdr.PaymentId)
            .SetAttribute("RemittanceMessageReceiveDate", RemittanceHdr.RemittanceMessageReceiveDate)
            .SetAttribute("CheckAmount", RemittanceHdr.CheckAmount)
            .SetAttribute("CheckNumber", RemittanceHdr.CheckNumber)
            .SetAttribute("CheckDate", RemittanceHdr.CheckDate)
            .SetAttribute("ProviderAdjustmentAmount", RemittanceHdr.ProviderAdjustmentAmount)
            .SetAttribute("PrescriberNPI", RemittanceHdr.PrescriberNPI)
            .SetAttribute("ProviderReference", RemittanceHdr.ProviderReference)
            .SetAttribute("ProductionDate", RemittanceHdr.ProductionDate)
            .SetAttribute("PayerContactName", RemittanceHdr.PayerContactName)
            .SetAttribute("PayerCommunicationNumberQualifier", RemittanceHdr.PayerCommunicationNumberQualifier)
            .SetAttribute(("PayerCommunicationNumber"), RemittanceHdr.PayerCommunicationNumber)
            .SetAttribute(("PayerName"), RemittanceHdr.PayerName)
            .SetAttribute(("PayerAddress"), RemittanceHdr.PayerAddress)
            .SetAttribute(("PayerCity"), RemittanceHdr.PayerCity)
            .SetAttribute(("PayerState"), RemittanceHdr.PayerState)
            .SetAttribute(("PayerZip"), RemittanceHdr.PayerZip)
            .SetAttribute(("AdditionalPayerIdentification"), RemittanceHdr.AdditionalPayerIdentification)
            .SetAttribute(("PayeeName"), RemittanceHdr.PayeeName)
            .SetAttribute(("PayeeAddress"), RemittanceHdr.PayeeAddress)
            .SetAttribute(("PayeeCity"), RemittanceHdr.PayeeCity)
            .SetAttribute(("PayeeState"), RemittanceHdr.PayeeState)
            .SetAttribute(("PayeeZip"), RemittanceHdr.PayeeZip)
            .SetAttribute(("AdditionalPayeeIdentification"), RemittanceHdr.AdditionalPayeeIdentification)
            .SetAttribute(("FileName"), RemittanceHdr.FileName)
            .SetAttribute(("IsPosted"), RemittanceHdr.IsPosted) ''FileContent
            .SetAttribute(("FileContent"), RemittanceHdr.FileContent)


        End With

        lXmlDocument.DocumentElement.AppendChild(lXmlElement.CloneNode(True))

        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand("InsertRemittanceHdr", lXmlDocument.InnerXml.ToString)
        Else
            Connection.ExecuteCommand("InsertRemittanceHdr", lXmlDocument.InnerXml.ToString)
        End If
    End Sub

    Public Function GetRecordByID() As Boolean Implements IDetail.GetRecordByID
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "RemittanceHdr"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = "And RemittanceId = " & Me.RemittanceHdr.RemittanceId

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("SelectAllRecords", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
        End If


        With lDs.Tables(0)
            If .Rows.Count > 0 Then

                Me.RemittanceHdr.RemittanceId = .Rows(0)("RemittanceId")
                Me.RemittanceHdr.ReassociationTraceNumber = .Rows(0)("ReassociationTraceNumber")
                Me.RemittanceHdr.PaymentId = .Rows(0)("PaymentId")
                Me.RemittanceHdr.RemittanceMessageReceiveDate = .Rows(0)("RemittanceMessageReceiveDate")
                Me.RemittanceHdr.CheckAmount = .Rows(0)("CheckAmount")
                Me.RemittanceHdr.CheckNumber = .Rows(0)("CheckNumber")
                Me.RemittanceHdr.CheckDate = .Rows(0)("CheckDate")
                Me.RemittanceHdr.ProviderAdjustmentAmount = .Rows(0)("ProviderAdjustmentAmount")
                Me.RemittanceHdr.PrescriberNPI = .Rows(0)("PrescriberNPI")
                Me.RemittanceHdr.ProviderReference = .Rows(0)("ProviderReference")
                Me.RemittanceHdr.ProductionDate = .Rows(0)("ProductionDate")
                Me.RemittanceHdr.PayerContactName = .Rows(0)("PayerContactName")
                Me.RemittanceHdr.PayerCommunicationNumberQualifier = .Rows(0)("PayerCommunicationNumberQualifier")
                Me.RemittanceHdr.PayerCommunicationNumber = .Rows(0)("PayerCommunicationNumber")
                Me.RemittanceHdr.PayerName = .Rows(0)("PayerName")
                Me.RemittanceHdr.PayerAddress = .Rows(0)("PayerAddress")
                Me.RemittanceHdr.PayerCity = .Rows(0)("PayerCity")
                Me.RemittanceHdr.PayerState = .Rows(0)("PayerState")
                Me.RemittanceHdr.PayerZip = .Rows(0)("PayerZip")
                Me.RemittanceHdr.AdditionalPayerIdentification = .Rows(0)("AdditionalPayerIdentification")
                Me.RemittanceHdr.PayeeName = .Rows(0)("PayeeName")
                Me.RemittanceHdr.PayeeAddress = .Rows(0)("PayeeAddress")
                Me.RemittanceHdr.PayeeCity = .Rows(0)("PayeeCity")
                Me.RemittanceHdr.PayeeState = .Rows(0)("PayeeState")
                Me.RemittanceHdr.PayeeZip = .Rows(0)("PayeeZip")
                Me.RemittanceHdr.AdditionalPayeeIdentification = .Rows(0)("AdditionalPayeeIdentification")
                Me.RemittanceHdr.FileName = .Rows(0)("FileName")
                Me.RemittanceHdr.IsPosted = .Rows(0)("IsPosted") ''FileContent
                Me.RemittanceHdr.FileContent = .Rows(0)("FileContent")

                Return True
            End If
        End With

        Return False
    End Function

    Public Sub DeleteRecord(ByVal lCondition As String) Implements IDetail.DeleteRecord
    End Sub
    Public Sub DeleteRecordByID() Implements IDetail.DeleteRecordByID
    End Sub
    Public Function GetAllRecords() As System.Data.DataSet Implements IDetail.GetAllRecords
        Dim lDs As New DataSet()
        lDs = GetAllRecords("")
        Return lDs
    End Function
    Public Function GetAllRecords(ByVal lCondition As String) As System.Data.DataSet Implements IDetail.GetAllRecords
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "RemittanceHdr"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = lCondition '"And RemittanceId = " & Me.RemittanceHdr.RemittanceId

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("SelectAllRecords", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
        End If
        Return lDs
    End Function
    Public Sub UpdateRecord() Implements IDetail.UpdateRecord
    End Sub
    Public Sub UpdateRecord(ByVal lCondition As String) Implements IDetail.UpdateRecord
    End Sub
    Public Function GetRecordByIDExtended() As Boolean
        Return True
    End Function
    Public Sub LogicalDelete()
    End Sub
    Public Function GetUniqueId() As Boolean
        Dim lDs As New DataSet()

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("Exec GetRemittanceUniqueId")
        Else
            lDs = Connection.ExecuteQuery("Exec GetRemittanceUniqueId")
        End If

        If lDs.Tables(0).Rows.Count > 0 Then
            Me.RemittanceHdr.RemittanceId = lDs.Tables(0).Rows(0)("RemittanceId")
            Return True
        Else
            Return False
        End If
    End Function

    Public Sub SetPosted()
        Dim lQuery As String

        Try
            lQuery = "UPDATE RemittanceHdr SET PaymentId = '" & RemittanceHdr.PaymentId & "',IsPosted ='Y'  WHERE ReassociationTraceNumber = '" & RemittanceHdr.ReassociationTraceNumber & "' "

            If Connection.IsTransactionAlive() Then
                Connection.ExecuteTransactionCommand(lQuery)
            Else
                Connection.ExecuteCommand(lQuery)
            End If


        Catch ex As Exception
            Throw
        End Try

    End Sub
#End Region

End Class
