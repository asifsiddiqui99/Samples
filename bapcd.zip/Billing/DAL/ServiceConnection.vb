Imports Microsoft.VisualBasic
Imports system.Net.Sockets
Imports System.Data
Imports system.IO

Public Class ServiceConnection
    Public Shared Function CallIMOProblemITService(ByVal pSearchString As String, ByVal pType As String) As String
        Dim lTcpClient As TcpClient = New TcpClient
        Dim lSearch As String
        Dim lNetworkStream As NetworkStream
        Dim lResult As String = ""
        Dim lBytes As Byte()


        Try
            pSearchString = pSearchString & "^" & ConfigurationManager.AppSettings("IMOOrganizationID")
            Select Case pType.ToUpper()
                Case "ICD"
                    lTcpClient.Connect(ConfigurationManager.AppSettings("IMOICDIPAddress"), ConfigurationManager.AppSettings("IMOICDPort"))
                Case "ICDDESC"
                    lTcpClient.Connect(ConfigurationManager.AppSettings("IMOICDIPAddress"), ConfigurationManager.AppSettings("IMOICDPort"))
                Case "MED"
                    lTcpClient.Connect(ConfigurationManager.AppSettings("IMOMedicalNecessityIPAddress"), ConfigurationManager.AppSettings("IMOMedicalNecessityPort"))
                Case "CPT"
                    lTcpClient.Connect(ConfigurationManager.AppSettings("IMOCPTIPAddress"), ConfigurationManager.AppSettings("IMOCPTPort"))
            End Select
            'lTcpClient.Connect("38.98.135.237", 42015)
            lSearch = pSearchString + System.Environment.NewLine
            lNetworkStream = lTcpClient.GetStream()
            lBytes = ASCIIEncoding.ASCII.GetBytes(lSearch)
            lNetworkStream = lTcpClient.GetStream()
            lBytes = ASCIIEncoding.ASCII.GetBytes(lSearch)
            lNetworkStream.Write(lBytes, 0, lBytes.Length)
            lResult = ReadBuffer(lNetworkStream)
        Catch ex As Exception
            lResult = ""
        Finally
            If (lTcpClient.Connected) Then
                lTcpClient.Close()
            End If
        End Try


        Return lResult


    End Function

    Public Shared Function ReadBuffer(ByVal pNetworkStream As NetworkStream) As String
        Dim lLenghtBuffer As Byte()
        Dim lBytesRead As Integer
        Dim lResponseLenght As Integer
        Dim lBuffer As Byte()
        Dim lResult As String


        Try
            lLenghtBuffer = New Byte(3) {}
            lBytesRead = 0

            'lBytesRead = pNetworkStream.Read(lLenghtBuffer, 0, 4)
            While lBytesRead < 4
                lBytesRead += pNetworkStream.Read(lLenghtBuffer, lBytesRead, 4 - lBytesRead)
            End While

            If BitConverter.IsLittleEndian Then
                Array.Reverse(lLenghtBuffer)
            End If
            lResponseLenght = BitConverter.ToInt32(lLenghtBuffer, 0)
            lBuffer = New Byte(lResponseLenght - 1) {}
            lBytesRead = 0

            'lBytesRead = pNetworkStream.Read(lBuffer, 0, lResponseLenght)
            While lBytesRead < lResponseLenght
                lBytesRead += pNetworkStream.Read(lBuffer, lBytesRead, lResponseLenght - lBytesRead)
            End While

            lResult = ASCIIEncoding.ASCII.GetString(lBuffer, 0, lBytesRead)
        Catch ex As Exception
            lResult = ""
        End Try

        Return lResult
    End Function
End Class
