Imports Microsoft.VisualBasic
Imports system.Collections.Generic

Public Class PaymentDtlDB

#Region "Fields"

    Private mPaymentDtlID As String
    Private mPaymentID As String
    Private mAmount As String
    Private mTotalAmount As String
    Private mTotalCharges As String
    Private mEntryDate As String
    Private mUserId As String
    Private mVisitId As String

    ''fields added by talha..
    Private mPatientName As String    
    Private mAdjustment As Double
    Private mBalance As String
    Private mPatientSuperBillID As String
    Private mDOS As String
    Private mPrvInsurancePayment As String
    Private mPrvPatientPayment As String
    Private mVisitDisplayID As String
    Private mVisitDisplayDate As String
    Private mPatientID As String
    Private mIsPrevious As String
    Private mFormattedDisplayID As String
    Private mNotes As String
    ''


    Private mPaymentCPTDetailCollection As PaymentCPTDetailCollection
    Private mAdjustmentCollection As New AdjustmentCollection
    Private mPatientLedger As PatientLedgerDB
#End Region

#Region "Properties"

    Public Property PaymentDtlID() As String
        Get
            Return mPaymentDtlID
        End Get
        Set(ByVal value As String)
            mPaymentDtlID = value
        End Set
    End Property


    Public Property PaymentID() As String
        Get
            Return mPaymentID
        End Get
        Set(ByVal value As String)
            mPaymentID = value
        End Set
    End Property


    Public Property Amount() As String
        Get
            Return mAmount
        End Get
        Set(ByVal value As String)
            mAmount = value
        End Set
    End Property

    Public Property TotalAmount() As String
        Get
            Return mTotalAmount
        End Get
        Set(ByVal value As String)
            mTotalAmount = value
        End Set
    End Property

    Public Property TotalCharges() As String
        Get
            Return mTotalCharges
        End Get
        Set(ByVal value As String)
            mTotalCharges = value
        End Set
    End Property

    Public Property EntryDate() As String
        Get
            Return mEntryDate
        End Get
        Set(ByVal value As String)
            mEntryDate = value
        End Set
    End Property


    Public Property UserId() As String
        Get
            Return mUserId
        End Get
        Set(ByVal value As String)
            mUserId = value
        End Set
    End Property

    Public Property VisitId() As String
        Get
            Return mVisitId
        End Get
        Set(ByVal value As String)
            mVisitId = value
        End Set
    End Property

    Public Property PaymentCPTDetailCollection() As PaymentCPTDetailCollection
        Get
            Return mPaymentCPTDetailCollection
        End Get
        Set(ByVal value As PaymentCPTDetailCollection)
            mPaymentCPTDetailCollection = value
        End Set
    End Property

    Public Property AdjustmentCollection() As AdjustmentCollection
        Get
            Return mAdjustmentCollection
        End Get
        Set(ByVal value As AdjustmentCollection)
            mAdjustmentCollection = value
        End Set
    End Property

    Public Property PatientLedger() As PatientLedgerDB
        Get
            Return mPatientLedger
        End Get
        Set(ByVal value As PatientLedgerDB)
            mPatientLedger = value
        End Set
    End Property

    Public Property PatientName() As String
        Get
            Return mPatientName
        End Get
        Set(ByVal value As String)
            mPatientName = value
        End Set
    End Property

    Public Property Adjustment() As Double
        Get
            Return mAdjustment
        End Get
        Set(ByVal value As Double)
            mAdjustment = value
        End Set
    End Property

    Public Property Balance() As String
        Get
            Return mBalance
        End Get
        Set(ByVal value As String)
            mBalance = value
        End Set
    End Property

    Public Property PatientSuperBillID() As String
        Get
            Return mPatientSuperBillID
        End Get
        Set(ByVal value As String)
            mPatientSuperBillID = value
        End Set
    End Property

    Public Property DOS() As String
        Get
            Return mDOS
        End Get
        Set(ByVal value As String)
            mDOS = value
        End Set
    End Property

    Public Property PrvInsurancePayment() As String
        Get
            Return mPrvInsurancePayment
        End Get
        Set(ByVal value As String)
            mPrvInsurancePayment = value
        End Set
    End Property


    Public Property PrvPatientPayment() As String
        Get
            Return mPrvPatientPayment
        End Get
        Set(ByVal value As String)
            mPrvPatientPayment = value
        End Set
    End Property

    Public Property VisitDisplayID() As String
        Get
            Return mVisitDisplayID
        End Get
        Set(ByVal value As String)
            mVisitDisplayID = value
        End Set
    End Property

    Public Property VisitDisplayDate() As String
        Get
            Return mVisitDisplayDate
        End Get
        Set(ByVal value As String)
            mVisitDisplayDate = value
        End Set
    End Property

    Public Property PatientID() As String
        Get
            Return mPatientID
        End Get
        Set(ByVal value As String)
            mPatientID = value
        End Set
    End Property

    Public Property IsPrevious() As String
        Get
            Return mIsPrevious
        End Get
        Set(ByVal value As String)
            mIsPrevious = value
        End Set
    End Property

    Public Property FormattedDisplayID() As String
        Get
            Return mFormattedDisplayID
        End Get
        Set(ByVal value As String)
            mFormattedDisplayID = value
        End Set
    End Property

    Public Property Notes() As String
        Get
            Return mNotes
        End Get
        Set(ByVal value As String)
            mNotes = value
        End Set
    End Property


#End Region


End Class



Public Class PaymentDtl
    Implements IDetail


#Region "Fields"
    Private mConnection As Connection
    Private mConnectionString As String
    Private mPaymentDtl As New PaymentDtlDB
#End Region

#Region "Property"
    Public ReadOnly Property Connection() As ElixirLibrary.Connection Implements IDetail.Connection
        Get
            Return mConnection
        End Get
    End Property

    Public ReadOnly Property ConnectionString() As String Implements IDetail.ConnectionString
        Get
            Return mConnectionString
        End Get
    End Property
    Public Property PaymentDtl() As PaymentDtlDB
        Get
            Return mPaymentDtl
        End Get
        Set(ByVal value As PaymentDtlDB)
            mPaymentDtl = value
        End Set
    End Property
#End Region

#Region "Constructor"
    ''' <summary>
    ''' Creates new Conection Object based on Given Connection String 
    ''' </summary>
    ''' <param name="pConnectionString">
    ''' Contains Connection String 
    ''' </param>
    ''' <remarks>
    ''' Use when not using transaction
    ''' Must Specify Connection String other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnectionString As String)
        If pConnectionString = "" Then
            Throw New ArgumentException("ConnectionString can not be empty")
        End If

        mConnectionString = pConnectionString
        mConnection = New Connection(mConnectionString)

    End Sub

    ''' <summary>
    ''' Assign given connection to the current Object
    ''' </summary>
    ''' <param name="pConnection">
    ''' Contains refrence to the connection object
    ''' </param>
    ''' <remarks>
    ''' Use when  using Transaction
    ''' Must Specify Connection other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnection As Connection)
        If pConnection Is Nothing Then
            Throw New ArgumentException("Connection can not be empty")
        End If

        mConnection = pConnection
    End Sub
#End Region

#Region "Method"
    ''' <summary>
    ''' Delete Record Acoording to Given Condition
    ''' </summary>
    ''' <param name="lCondition"></param>
    ''' <remarks></remarks>
    Public Sub DeleteRecord(ByVal lCondition As String) Implements IDetail.DeleteRecord

        Dim lSpParameter(1) As SpParameter

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "PaymentDtl"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = lCondition

        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand("DeleteRecords", lSpParameter)
        Else
            Connection.ExecuteCommand("DeleteRecords", lSpParameter)
        End If

    End Sub
    ''' <summary>
    ''' Delete Record on Primary Key
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub DeleteRecordByID() Implements IDetail.DeleteRecordByID
        Dim lCondition As String

        lCondition = "AND PaymentID= " & PaymentDtl.PaymentId
        DeleteRecord(lCondition)

    End Sub
    ''' <summary>
    ''' Get All Records unconditional
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetAllRecords() As System.Data.DataSet Implements IDetail.GetAllRecords
        Dim lCondition As String = ""
        Dim lDs As New DataSet()

        lDs = GetAllRecords(lCondition)

        Return lDs
    End Function
    ''' <summary>
    ''' Get  Records on specified Condition
    ''' </summary>
    ''' <param name="lCondition"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetAllRecords(ByVal lCondition As String) As System.Data.DataSet Implements IDetail.GetAllRecords
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "PaymentDtl"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = lCondition

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("SelectAllRecords", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
        End If

        Return lDs

    End Function

    Public Function InsertPayment() As Boolean
        Dim lXmlDocument As New XmlDocument
        Dim lXmlElement As XmlElement

        Try
            lXmlDocument.LoadXml("<PaymentDtls></PaymentDtls>")
            lXmlElement = lXmlDocument.CreateElement("PaymentDtl")

            With lXmlElement
                '.SetAttribute("PaymentDtlID", PaymentDtl.PaymentDtlID)
                .SetAttribute("PaymentID", PaymentDtl.PaymentID)
                .SetAttribute("Amount", PaymentDtl.Amount)
                .SetAttribute("TotalAmount", PaymentDtl.TotalAmount)
                .SetAttribute("TotalCharges", PaymentDtl.TotalCharges)
                .SetAttribute("EntryDate", PaymentDtl.EntryDate)
                .SetAttribute("UserId", PaymentDtl.UserId)
                .SetAttribute("VisitId", PaymentDtl.VisitId)
                .SetAttribute("Notes", PaymentDtl.Notes)
            End With

            Connection.BeginTrans()

            lXmlDocument.DocumentElement.AppendChild(lXmlElement.CloneNode(True))


            If ((PaymentDtl.Amount <> 0) Or CheckForCPTEnteries()) Then
                InsertPatientLedger()
                If Connection.IsTransactionAlive() Then
                    PaymentDtl.PaymentDtlID = Connection.ExecuteTransactionScalarCommand("InsertPaymentDtl", lXmlDocument.InnerXml.ToString)
                Else
                    Connection.ExecuteScalarCommand("InsertPaymentDtl", lXmlDocument.InnerXml.ToString)
                End If
            End If


            'If ((PaymentDtl.Amount <> 0) Or CheckForCPTEnteries()) Then
            '    InsertPatientLedger()
            'End If


            'If (PaymentDtl.Amount <> 0) Then
            '    If Connection.IsTransactionAlive() Then
            '        PaymentDtl.PaymentDtlID = Connection.ExecuteTransactionScalarCommand("InsertPaymentDtl", lXmlDocument.InnerXml.ToString)
            '    Else
            '        Connection.ExecuteScalarCommand("InsertPaymentDtl", lXmlDocument.InnerXml.ToString)
            '    End If
            'Else
            '    If (CheckForCPTEnteries()) Then
            '        PaymentDtl.PaymentDtlID = Connection.ExecuteTransactionScalarCommand("InsertPaymentDtl", lXmlDocument.InnerXml.ToString)
            '    End If
            'End If



            InsertPaymentCptDetail()

            InsertAdjustment()


            Connection.CommitTrans()

            Return True

        Catch ex As Exception
            Connection.RollBackTrans()
            'Throw New Exception(ex.Message + " : DAL\PaymentDtl.InsertPayment() ")
            Return False
        End Try

    End Function

    Public Sub InsertPaymentCptDetail()
        Dim lPaymentCPTDetail As New PaymentCPTDetail(Connection)

        Try
            If (PaymentDtl.PaymentCPTDetailCollection IsNot Nothing) Then
                For Each lPaymentCPTDtl As PaymentCPTDetailDB In PaymentDtl.PaymentCPTDetailCollection
                    lPaymentCPTDtl.PaymentDtlID = PaymentDtl.PaymentDtlID
                    lPaymentCPTDetail.PaymentCPTDetail = lPaymentCPTDtl

                    lPaymentCPTDetail.InsertPaymentCPTDtl(PaymentDtl.PaymentID)

                Next

            End If

        Catch ex As Exception
            Throw
        End Try

    End Sub

    Public Sub InsertAdjustment()
        Dim lAdjustment As New Adjustment(Connection)

        Try
            For Each lAdjustmentDB As AdjustmentDB In PaymentDtl.AdjustmentCollection
                If (lAdjustmentDB.IsPrevious = "No") Then
                    lAdjustmentDB.PaymentID = PaymentDtl.PaymentID
                    lAdjustmentDB.PaymentDtlID = PaymentDtl.PaymentDtlID                    
                    lAdjustment.Adjustment = lAdjustmentDB
                    lAdjustment.InsertRecord()
                End If

            Next
        Catch ex As Exception
            Throw
        End Try

    End Sub


    Public Sub InsertAdjustmentOnly()
        Dim lAdjustment As New Adjustment(Connection)

        Try
            For Each lAdjustmentDB As AdjustmentDB In PaymentDtl.AdjustmentCollection
                If (lAdjustmentDB.IsPrevious = "No") Then
                    lAdjustmentDB.PaymentID = PaymentDtl.PaymentID
                    lAdjustmentDB.PaymentDtlID = PaymentDtl.PaymentDtlID
                    lAdjustment.Adjustment = lAdjustmentDB
                    lAdjustment.InsertAdjustmentOnly()
                End If

            Next
        Catch ex As Exception
            Throw
        End Try

    End Sub



    Public Sub InsertPatientLedger()
        Dim lPatientLedger As New PatientLedger(Connection)

        Try
            If (PaymentDtl.PatientLedger IsNot Nothing) Then
                lPatientLedger.PatientLedger = PaymentDtl.PatientLedger
                lPatientLedger.InsertPatientLedger()
            End If

        Catch ex As Exception
            Throw
        End Try

    End Sub

    ''' <summary>
    ''' Insert record
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub InsertRecord() Implements IDetail.InsertRecord
        Dim lXmlDocument As New XmlDocument
        Dim lXmlElement As XmlElement

        lXmlDocument.LoadXml("<PaymentDtls></PaymentDtls>")
        lXmlElement = lXmlDocument.CreateElement("PaymentDtl")

        With lXmlElement

            .SetAttribute("PaymentDtlID", PaymentDtl.PaymentDtlID)
            .SetAttribute("PaymentID", PaymentDtl.PaymentID)
            .SetAttribute("Amount", PaymentDtl.Amount)
            .SetAttribute("TotalAmount", PaymentDtl.TotalAmount)
            .SetAttribute("TotalCharges", PaymentDtl.TotalCharges)
            .SetAttribute("EntryDate", PaymentDtl.EntryDate)
            .SetAttribute("UserId", PaymentDtl.UserId)
            .SetAttribute("VisitId", PaymentDtl.VisitId)


        End With

        lXmlDocument.DocumentElement.AppendChild(lXmlElement.CloneNode(True))

        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand("InsertPaymentDtl", lXmlDocument.InnerXml.ToString)
        Else
            Connection.ExecuteCommand("InsertPaymentDtl", lXmlDocument.InnerXml.ToString)
        End If

    End Sub

    Public Sub InsertRecord(ByVal pPaymentDtlXml As String)
        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand("InsertPaymentDtl", pPaymentDtlXml)
        Else
            Connection.ExecuteCommand("InsertPaymentDtl", pPaymentDtlXml)
        End If

    End Sub

    'Public Sub InserRecordByClaim(ByRef pClaimCollection As Hashtable)

    '    Dim lOrignalBalance As Double = 0.0
    '    Dim lBalance As Double = 0.0
    '    Dim lOriginalDeductable As Double = 0.0
    '    Dim lDeductable As Double = 0.0



    '    For Each lClaimHdr As ClaimHdrDB In pClaimCollection.Values
    '        For Each lClaimDtl As ClaimDtlDB In lClaimHdr.ClaimDtlColl
    '            With Me.PaymentDtl

    '                lOrignalBalance = CType(IIf(lClaimDtl.OrignalBalance = "", 0, lClaimDtl.OrignalBalance), Double)
    '                lBalance = CType(IIf(lClaimDtl.Balance = "", 0, lClaimDtl.Balance), Double)
    '                lDeductable = CType(IIf(lClaimDtl.Deductable = "", 0, lClaimDtl.Deductable), Double)
    '                lOriginalDeductable = CType(IIf(lClaimDtl.OriginalDeductable = "", 0, lClaimDtl.OriginalDeductable), Double)

    '                'Insert the record only if
    '                '   Balance has changed ---> caused by changes in payment, adjustment etc
    '                '   Deductable has changed. 
    '                '   The row is not that of Total values

    '                If ((lOrignalBalance <> lBalance) Or (lDeductable <> lOriginalDeductable)) And (Not lClaimDtl.CPTCode.Equals("Total")) Then
    '                    .HCFAID = lClaimHdr.HCFAID
    '                    .CPTCode = lClaimDtl.CPTCode
    '                    .AmountAllowed = lClaimDtl.AmountAllowed
    '                    .Charges = lClaimDtl.Charges
    '                    .AmountPaid = lClaimDtl.AmountPaid
    '                    .PatientPayment = lClaimDtl.PatientPayment
    '                    .Adjustment = lClaimDtl.Adjustment
    '                    .Deductable = lClaimDtl.Deductable
    '                    .Status = lClaimDtl.Status
    '                    .PatientSuperBillId = lClaimDtl.VisitNumericID
    '                    .CoInsurance = lClaimDtl.CoInsurance
    '                    .Comments = lClaimDtl.Comments
    '                    .AdjustmentCode = lClaimDtl.AdjustmentCode
    '                    .ReasonCode = lClaimDtl.ReasonCode

    '                    InsertRecord()
    '                End If

    '            End With
    '        Next
    '    Next

    'End Sub
    'Public Sub InserRecordByClaimEdit(ByRef pClaimCollection As Hashtable)
    '    Dim lOrignalBalance As Double
    '    Dim lBalance As Double

    '    For Each lClaimHdr As ClaimHdrDB In pClaimCollection.Values
    '        For Each lClaimDtl As ClaimDtlDB In lClaimHdr.ClaimDtlColl
    '            With Me.PaymentDtl

    '                lOrignalBalance = CType(IIf(lClaimDtl.OrignalBalance = "", 0, lClaimDtl.OrignalBalance), Double)
    '                lBalance = CType(IIf(lClaimDtl.Balance = "", 0, lClaimDtl.Balance), Double)


    '                'If (((lAmountPaid + lPatientPayment + lAdjustment) > 0) And ((lInsPreviousPayment + lPatPreviousPayment) = 0) Or ((lAmountPaid + lPatientPayment) > 0 And (lInsPreviousPayment + lPatPreviousPayment) > 0)) Then

    '                'End If

    '                If lOrignalBalance <> lBalance Then

    '                    If Not lClaimDtl.CPTCode.Equals("Total") Then

    '                        .HCFAID = lClaimDtl.VisitNumericID
    '                        .CPTCode = lClaimDtl.CPTCode
    '                        .AmountAllowed = lClaimDtl.AmountAllowed
    '                        .Charges = lClaimDtl.Charges
    '                        .AmountPaid = lClaimDtl.AmountPaid
    '                        .PatientPayment = lClaimDtl.PatientPayment
    '                        .Adjustment = lClaimDtl.Adjustment
    '                        .Deductable = lClaimDtl.Deductable
    '                        .Status = lClaimDtl.Status
    '                        .PatientSuperBillId = lClaimDtl.VisitNumericID
    '                        .CoInsurance = lClaimDtl.CoInsurance
    '                        .Comments = lClaimDtl.Comments

    '                        If (lClaimDtl.AdjustmentCode = "Select") Then
    '                            .AdjustmentCode = ""
    '                        Else
    '                            .AdjustmentCode = lClaimDtl.AdjustmentCode
    '                        End If

    '                        If (lClaimDtl.ReasonCode = "Select") Then
    '                            .ReasonCode = ""
    '                        Else
    '                            .ReasonCode = lClaimDtl.ReasonCode
    '                        End If


    '                        InsertRecord()
    '                        UpdateRecordLimited()

    '                    End If
    '                End If

    '            End With
    '        Next
    '    Next

    'End Sub


    ''' <summary>
    ''' Update Record unconditional
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub UpdateRecord() Implements IDetail.UpdateRecord
        Dim lCondition As String

        lCondition = "And PaymentID = " & Me.PaymentDtl.PaymentId
        UpdateRecord(lCondition)

    End Sub
    Public Sub UpdateRecord(ByVal lCondition As String) Implements IDetail.UpdateRecord

        Dim lQuery As String

        With Me.PaymentDtl

            lQuery = "Update PaymentDtl Set " _
                   & "Amount =" & .Amount & ", " _
                   & "TotalAmount =" & .TotalAmount & ", " _
                   & "TotalCharges =" & .TotalCharges & ", " _
                   & "Where 1 = 1 " _
                   & lCondition


        End With

        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand(lQuery)
        Else
            Connection.ExecuteCommand(lQuery)
        End If
    End Sub
    'Public Sub UpdateRecordLimited()

    '    Dim lQuery As String = "AND PatientSuperBillID =" & Me.PaymentDtl.HCFAID & " " _
    '                         & "AND CPTCode ='" & Me.PaymentDtl.CPTCode & "' "

    '    With Me.PaymentDtl

    '        lQuery = "Update PaymentDtl Set " _
    '               & IIf(.AmountAllowed.Equals(""), " ", "AmountAllowed =" & .AmountAllowed & ", ") _
    '               & "PatientPayment =" & .PatientPayment & ", " _
    '               & "Adjustment =" & .Adjustment & " " _
    '               & "Where 1 = 1 " _
    '               & lQuery

    '    End With

    '    If Connection.IsTransactionAlive() Then
    '        Connection.ExecuteTransactionCommand(lQuery)
    '    Else
    '        Connection.ExecuteCommand(lQuery)
    '    End If
    'End Sub
    ''' <summary>
    ''' Get Single Record By Primary Key
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetRecordByID() As Boolean Implements IDetail.GetRecordByID
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "PaymentDtl"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = "And PaymentID = " & Me.PaymentDtl.PaymentID

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("SelectAllRecords", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
        End If


        With lDs.Tables(0)
            If .Rows.Count > 0 Then

                Me.PaymentDtl.PaymentDtlID = .Rows(0)("PaymentDtlID")
                Me.PaymentDtl.PaymentID = .Rows(0)("PaymentID")
                Me.PaymentDtl.Amount = .Rows(0)("Amount")
                Me.PaymentDtl.TotalAmount = .Rows(0)("TotalAmount")
                Me.PaymentDtl.TotalCharges = .Rows(0)("TotalCharges")
                Me.PaymentDtl.EntryDate = .Rows(0)("EntryDate")
                Me.PaymentDtl.UserId = .Rows(0)("UserId")
                Me.PaymentDtl.VisitId = .Rows(0)("VisitId")

                Return True
            End If
        End With

        Return False

    End Function

    Private Function CheckForCPTEnteries() As Boolean
        Dim lindex As Integer = 0
        If (PaymentDtl.PaymentCPTDetailCollection IsNot Nothing) Then
            For lindex = 0 To PaymentDtl.PaymentCPTDetailCollection.Count - 1                
                If (PaymentDtl.PaymentCPTDetailCollection.Item(lindex).Amount <> 0) Then
                    Return True
                End If
            Next

            Return False
        End If

    End Function
    'Public Sub LogicalDelete()
    '    Dim lQuery As String

    '    lQuery = "Update PaymentDtl Set IsDeleted = 'Y' " _
    '           & "Where LineId = " & Me.PaymentDtl.LineId & " "


    '    If Connection.IsTransactionAlive() Then
    '        Connection.ExecuteTransactionCommand(lQuery)
    '    Else
    '        Connection.ExecuteCommand(lQuery)
    '    End If

    'End Sub

#End Region

End Class


Public Class PaymentDtlCollection
    Inherits CollectionBase

    Public Function Add(ByVal pPaymentDtl As PaymentDtlDB) As Integer
        Return List.Add(pPaymentDtl)
    End Function

    Public Sub Remove(ByVal pPaymentDtl As PaymentDtlDB)
        List.Remove(pPaymentDtl)
    End Sub

    Default Public Property Item(ByVal Index As Integer) As PaymentDtlDB
        Get
            Return CType(List.Item(Index), PaymentDtlDB)
        End Get
        Set(ByVal Value As PaymentDtlDB)
            List.Item(Index) = Value
        End Set
    End Property

    Public Shadows Function Count() As Integer
        Return List.Count
    End Function



End Class