Imports Microsoft.VisualBasic

Public Class ICD9DB



#Region "Fields"
    Private mLineId As String
    Private mSuperBillId As String
    Private mCode As String
    Private mDescription As String
    Private mPatientSuperBillId As String

    Private mIMOCode As String
   
#End Region

#Region "Properties"

    Public Property LineId() As String
        Get
            Return mLineId
        End Get
        Set(ByVal value As String)
            mLineId = value
        End Set
    End Property

    Public Property SuperBillId() As String
        Get
            Return mSuperBillId
        End Get
        Set(ByVal value As String)
            mSuperBillId = value
        End Set
    End Property

    Public Property Code() As String
        Get
            Return mCode
        End Get
        Set(ByVal value As String)
            mCode = value
        End Set
    End Property

    Public Property Description() As String
        Get
            Return mDescription
        End Get
        Set(ByVal value As String)
            mDescription = value
        End Set
    End Property

    Public Property PatientSuperBillId() As String
        Get
            Return mPatientSuperBillId
        End Get
        Set(ByVal value As String)
            mPatientSuperBillId = value
        End Set
    End Property

    Public Property IMOCode() As String
        Get
            Return mIMOCode
        End Get
        Set(ByVal value As String)
            mIMOCode = value
        End Set
    End Property


#End Region


    'Public Function CompareTo(ByVal obj As Object) As Integer Implements System.IComparable.CompareTo
    '    Dim lICD9DB As ICD9DB

    '    lICD9DB = CType(obj, ICD9DB)
    '    Return Me.Code.CompareTo(lICD9DB.Code)
    'End Function
End Class

Public Class ICD9

#Region "Fields"
    Private mConnection As Connection
    Private mConnectionString
    Private mICD9 As New ICD9DB
#End Region

#Region "Property"
    Public ReadOnly Property Connection() As ElixirLibrary.Connection
        Get
            Return mConnection
        End Get
    End Property

    Public ReadOnly Property ConnectionString() As String
        Get
            Return mConnectionString
        End Get
    End Property
    Public Property ICD9() As ICD9DB
        Get
            Return mICD9
        End Get
        Set(ByVal value As ICD9DB)
            mICD9 = value
        End Set
    End Property
#End Region

#Region "Constructor"
    ''' <summary>
    ''' Creates new Conection Object based on Given Connection String 
    ''' </summary>
    ''' <param name="pConnectionString">
    ''' Contains Connection String 
    ''' </param>
    ''' <remarks>
    ''' Use when not using transaction
    ''' Must Specify Connection String other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnectionString As String)
        If pConnectionString = "" Then
            Throw New ArgumentException("ConnectionString can not be empty")
        End If

        mConnectionString = pConnectionString
        mConnection = New Connection(mConnectionString)

    End Sub

    Public Sub New()
        mConnection = New Connection()
    End Sub

    ''' <summary>
    ''' Assign given connection to the current Object
    ''' </summary>
    ''' <param name="pConnection">
    ''' Contains refrence to the connection object
    ''' </param>
    ''' <remarks>
    ''' Use when  using Transaction
    ''' Must Specify Connection other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnection As Connection)
        If pConnection Is Nothing Then
            Throw New ArgumentException("Connection can not be empty")
        End If

        mConnection = pConnection
    End Sub
#End Region



#Region "Method"

    Public Function SearchICD9(ByVal pDescription As String) As System.Data.DataSet
        Dim lDs As DataSet = Nothing
        Dim lQuery As String = String.Empty

        Try
            Dim lSpParameter(0) As SpParameter

            lSpParameter(0).ParameterName = "@Description"
            lSpParameter(0).ParameterType = ParameterType.Varchar
            lSpParameter(0).ParameterValue = pDescription

            'lSpParameter(1).ParameterName = "@CPTCode"
            'lSpParameter(1).ParameterType = ParameterType.Varchar
            'lSpParameter(1).ParameterValue = pCPTCode

            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery("GetDiagnosisCodeBySearchKeyword", lSpParameter)
            Else
                lDs = Connection.ExecuteQuery("GetDiagnosisCodeBySearchKeyword", lSpParameter)
            End If

            Return lDs

        Catch ex As Exception
            Return Nothing
        End Try


    End Function

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="pDescription"></param>
    ''' <returns></returns>
    ''' <remarks>Author: Affan Toor | 04-01-13</remarks>
    Public Function SearchICD9ByCode(ByVal pDescription As String) As System.Data.DataSet
        Dim lDs As DataSet = Nothing
        Dim lQuery As String = String.Empty

        Try
            Dim lSpParameter(0) As SpParameter

            lSpParameter(0).ParameterName = "@Description"
            lSpParameter(0).ParameterType = ParameterType.Varchar
            lSpParameter(0).ParameterValue = pDescription

            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery("GetICD9ByCode", lSpParameter)
            Else
                lDs = Connection.ExecuteQuery("GetICD9ByCode", lSpParameter)
            End If

            Return lDs

        Catch ex As Exception
            Return Nothing
        End Try


    End Function

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="pICDCode"></param>
    ''' <returns></returns>
    ''' <remarks>Affan Toor | 07-11-12</remarks>
    Public Function GetIMOCodeByICD(ByVal pICDCode As String) As System.Data.DataSet
        Dim lDs As DataSet = Nothing
        Dim lQuery As String = String.Empty

        Try
            Dim lSpParameter(0) As SpParameter

            lSpParameter(0).ParameterName = "@ICD"
            lSpParameter(0).ParameterType = ParameterType.Varchar
            lSpParameter(0).ParameterValue = pICDCode

            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery("GetIMOCodeByICD", lSpParameter)
            Else
                lDs = Connection.ExecuteQuery("GetIMOCodeByICD", lSpParameter)
            End If

            Return lDs

        Catch ex As Exception
            Return Nothing
        End Try


    End Function


    ''' <summary>
    ''' Delete Record Acoording to Given Condition
    ''' </summary>
    ''' <param name="lCondition"></param>
    ''' <remarks></remarks>
    Public Sub DeleteRecord(ByVal lCondition As String)

        Dim lSpParameter(1) As SpParameter

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "SuperBillICD9"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = lCondition

        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand("DeleteRecords", lSpParameter)
        Else
            Connection.ExecuteCommand("DeleteRecords", lSpParameter)
        End If

    End Sub


    Public Sub LogicalDelete(ByVal pCondition As String)
        Dim lQuery As String = String.Empty

        lQuery = "Update SuperBillICD9 set IsDeleted = 'Y' where 1=1 " & pCondition


        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionQuery(lQuery)
        Else
            Connection.ExecuteQuery(lQuery)
        End If
    End Sub

    ''' <summary>
    ''' Delete Record on Primary Key
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub DeleteRecordByID()
        Dim lCondition As String

        lCondition = "AND SuperBillId= " & ICD9.SuperBillId
        LogicalDelete(lCondition)

    End Sub
    ''' <summary>
    ''' Get All Records unconditional
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetAllRecords(ByVal lTable As String) As System.Data.DataSet
        Dim lCondition As String = ""
        Dim lDs As New DataSet()

        lDs = GetAllRecords(lCondition, lTable)

        Return lDs
    End Function
    ''' <summary>
    ''' Get  Records on specified Condition
    ''' </summary>
    ''' <param name="lCondition"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    ''' 
    Public Function GetAllRecords(ByVal lCondition As String, ByVal lTable As String) As System.Data.DataSet
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = lTable

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = lCondition

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("SelectAllRecords", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
        End If

        Return lDs

    End Function

    'THIS FUNCTION GETS THE TOP N RECORDS
    Public Function GetTopNRecords(ByVal pCondition As String, ByVal pTable As String, ByVal pSelectionCondition As String) As System.Data.DataSet
        Dim lSpParameter(2) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = pTable

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = pCondition

        lSpParameter(2).ParameterName = "@SelectionCond"
        lSpParameter(2).ParameterType = ParameterType.Varchar
        lSpParameter(2).ParameterValue = pSelectionCondition

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("SelectTopNRecords", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("SelectTopNRecords", lSpParameter)
        End If

        Return lDs

    End Function


    ''' <summary>
    ''' Insert record
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub InsertRecord()
        Dim lXmlDocument As New XmlDocument
        Dim lXmlElement As XmlElement

        lXmlDocument.LoadXml("<SuperBillICD9S></SuperBillICD9S>")
        lXmlElement = lXmlDocument.CreateElement("SuperBillICD9")


        With lXmlElement
            .SetAttribute("SuperBillId", ICD9.SuperBillId)
            .SetAttribute("Code", ICD9.Code)
            .SetAttribute("Description", ICD9.Description)
            .SetAttribute("IsDeleted", "N")
            .SetAttribute("IMOCode", ICD9.IMOCode)
        End With

        lXmlDocument.DocumentElement.AppendChild(lXmlElement.CloneNode(True))

        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand("InsertSuperBillICD9", lXmlDocument.InnerXml.ToString)
        Else
            Connection.ExecuteCommand("InsertSuperBillICD9", lXmlDocument.InnerXml.ToString)
        End If

    End Sub
    ''' <summary>
    ''' Update Record unconditional
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub UpdateRecord()
        Dim lCondition As String

        lCondition = "And SuperBillID = " & Me.ICD9.SuperBillId
        UpdateRecord(lCondition)

    End Sub
    Public Sub UpdateRecord(ByVal lCondition As String)

        Dim lQuery As String

        With Me.ICD9
            lQuery = "Update SuperBillICD9 Set " _
                    & "SuperBillId =" & .SuperBillId & ", " _
                    & "Code ='" & .Code & "', " _
                    & "Description ='" & .Description & "' " _
                    & "Where 1 = 1 " _
                    & lCondition

        End With

        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand(lQuery)
        Else
            Connection.ExecuteCommand(lQuery)
        End If
    End Sub
    ''' <summary>
    ''' Get Single Record By Primary Key
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetRecordByID(ByVal lTable As String) As Boolean
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = lTable

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = "And LineID = " & ICD9.LineId

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("SelectAllRecords", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
        End If


        With lDs.Tables(0)
            If .Rows.Count > 0 Then

                If lTable = "SuperBillCPT" Then
                    Me.ICD9.SuperBillId = .Rows(0)("SuperBillId")
                    Me.ICD9.LineId = .Rows(0)("LineId")
                Else
                    Me.ICD9.SuperBillId = ""
                    Me.ICD9.LineId = ""
                End If

                Me.ICD9.Code = .Rows(0)("Code")
                Me.ICD9.Description = .Rows(0)("Description")


                Return True
            End If
        End With

        Return False

    End Function


    Public Function GetICDCollection(ByVal pCondition As String) As ICD9Coll
        Dim lCond As String
        Dim lDs As DataSet
        Dim lICD As ICD9DB
        Dim lICD9Coll As New ICD9Coll()

        lCond = " And SuperBillId =" & Me.ICD9.SuperBillId & "  " & pCondition
        lDs = GetAllRecords(lCond, "SuperBillICD9")

        If lDs.Tables(0).Rows.Count > 0 Then

            For Each lRow As DataRow In lDs.Tables(0).Rows
                lICD = New ICD9DB()

                lICD.Code = lRow("Code")
                lICD.Description = lRow("Description")
                lICD.SuperBillId = lRow("SuperBillId")
                lICD.LineId = lRow("LineId")
                lICD.IMOCode = lRow("IMOCode")

                lICD9Coll.Add(lICD)
            Next
        End If

        Return lICD9Coll
    End Function

    Public Function GetCPTForGenerate(ByVal pCond As String) As System.Data.DataSet
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@SuperBillId"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = Me.ICD9.SuperBillId

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = pCond

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("GetICDCodes", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("GetICDCodes", lSpParameter)
        End If

        For lCounter As Integer = 0 To 2
            If lDs.Tables(0).Rows.Count < 10 Then
                AddRow(lDs.Tables(0))
            ElseIf lDs.Tables(0).Rows.Count < 10 Then
                AddRow(lDs.Tables(1))
            Else
                AddRow(lDs.Tables(2))
            End If
        Next



        Return lDs

    End Function


    Public Function GetICDForPreview(ByVal pCond As String) As System.Data.DataSet
        Dim lSpParameter(2) As SpParameter
        Dim lDs As New DataSet()


        lSpParameter(0).ParameterName = "@PatientSuperBillId"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = Me.ICD9.PatientSuperBillId

        lSpParameter(1).ParameterName = "@SuperBillId"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = Me.ICD9.SuperBillId

        lSpParameter(2).ParameterName = "@Cond"
        lSpParameter(2).ParameterType = ParameterType.Varchar
        lSpParameter(2).ParameterValue = pCond

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("GetICDCodesForPreview", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("GetICDCodesForPreview", lSpParameter)
        End If

        For lCounter As Integer = 0 To 2
            If lDs.Tables(0).Rows.Count < 10 Then
                AddRow(lDs.Tables(0))
            ElseIf lDs.Tables(0).Rows.Count < 10 Then
                AddRow(lDs.Tables(1))
            Else
                AddRow(lDs.Tables(2))
            End If
        Next



        Return lDs

    End Function
    Public Function GetICDForPreviewPrint(ByVal pCond As String, ByVal pTableName As String) As System.Data.DataSet
        Dim lSpParameter(2) As SpParameter
        Dim lDs As New DataSet()


        lSpParameter(0).ParameterName = "@PatientSuperBillId"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = Me.ICD9.PatientSuperBillId

        lSpParameter(1).ParameterName = "@SuperBillId"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = Me.ICD9.SuperBillId

        lSpParameter(2).ParameterName = "@Cond"
        lSpParameter(2).ParameterType = ParameterType.Varchar
        lSpParameter(2).ParameterValue = pCond

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("GetICDCodesForPreview", lSpParameter, pTableName)
        Else
            lDs = Connection.ExecuteQuery("GetICDCodesForPreview", lSpParameter, pTableName)
        End If

        For lCounter As Integer = 0 To 2
            If lDs.Tables(0).Rows.Count < 10 Then
                PSBAddRow(lDs.Tables(0))
            ElseIf lDs.Tables(1).Rows.Count < 10 Then
                PSBAddRow(lDs.Tables(1))
            ElseIf lDs.Tables(2).Rows.Count < 10 Then
                PSBAddRow(lDs.Tables(2))
            End If
        Next



        Return lDs

    End Function


    Public Function GetICDForClaim(ByVal pCond As String) As System.Data.DataSet
        Dim lSpParameter(2) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@PatientSuperBillId"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = Me.ICD9.PatientSuperBillId

        lSpParameter(1).ParameterName = "@SuperBillId"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = Me.ICD9.SuperBillId

        lSpParameter(2).ParameterName = "@Cond"
        lSpParameter(2).ParameterType = ParameterType.Varchar
        lSpParameter(2).ParameterValue = pCond

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("GetICDCodesForClaim", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("GetICDCodesForClaim", lSpParameter)
        End If

        'For lCounter As Integer = 0 To 2
        '    If lDs.Tables(0).Rows.Count < 10 Then
        '        AddRowClaim(lDs.Tables(0))
        '    ElseIf lDs.Tables(0).Rows.Count < 10 Then
        '        AddRowClaim(lDs.Tables(1))
        '    Else
        '        AddRowClaim(lDs.Tables(2))
        '    End If
        'Next



        Return lDs

    End Function

    Private Sub AddRowClaim(ByRef pDataTable As DataTable)
        Dim lDr As DataRow

        lDr = pDataTable.NewRow()
        lDr(0) = 9999999
        lDr(1) = ""
        lDr(2) = ""
        lDr(3) = ""
        pDataTable.Rows.Add(lDr)

    End Sub

    Private Sub AddRow(ByRef pDataTable As DataTable)
        Dim lDr As DataRow

        lDr = pDataTable.NewRow()
        lDr(0) = 9999999
        lDr(1) = DBNull.Value
        lDr(2) = ""
        lDr(3) = ""
        pDataTable.Rows.Add(lDr)

    End Sub
    Private Sub SBAddRow(ByRef pDataTable As DataTable)
        Dim lDr As DataRow

        lDr = pDataTable.NewRow()
        lDr(0) = 9999999
        lDr(1) = DBNull.Value
        lDr(2) = ""
        lDr(3) = ""
        lDr(4) = "N"
        pDataTable.Rows.Add(lDr)

    End Sub
    Private Sub PSBAddRow(ByRef pDataTable As DataTable)
        Dim lDr As DataRow

        lDr = pDataTable.NewRow()
        lDr(0) = 9999999
        lDr(1) = DBNull.Value
        lDr(2) = ""
        lDr(3) = ""
        lDr(4) = DBNull.Value
        lDr(5) = DBNull.Value
        lDr(6) = "N"
        pDataTable.Rows.Add(lDr)

    End Sub

    Public Function GetICDBySuperBillID(ByVal pPatientSuperBillID As String) As DataSet

        Dim lQuery As String = String.Empty


        Try

            lQuery = "select Code,Description,IsGridItem, IMOCode from PatientICD where PatientSuperBillID =  " & pPatientSuperBillID & " Order By LineNumber"

            If Connection.IsTransactionAlive() Then
                GetICDBySuperBillID = Connection.ExecuteTransactionQuery(lQuery)
            Else
                GetICDBySuperBillID = Connection.ExecuteQuery(lQuery)
            End If



        Catch ex As Exception
            Return Nothing
        End Try
    End Function


    Public Function GetICDForTemplatePrint(ByVal pCond As String, ByVal pTableName As String) As System.Data.DataSet
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@SuperBillId"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = Me.ICD9.SuperBillId

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = pCond

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("GetICDCodes", lSpParameter, pTableName)
        Else
            lDs = Connection.ExecuteQuery("GetICDCodes", lSpParameter, pTableName)
        End If

        For lCounter As Integer = 0 To 2
            If lDs.Tables(0).Rows.Count < 10 Then
                SBAddRow(lDs.Tables(0))
            ElseIf lDs.Tables(0).Rows.Count < 10 Then
                SBAddRow(lDs.Tables(1))
            Else
                SBAddRow(lDs.Tables(2))
            End If
        Next



        Return lDs

    End Function

#End Region

End Class

Public Class ICD9Coll
    Inherits CollectionBase


    Public Function Add(ByVal pICD9 As ICD9DB) As Integer
        Return List.Add(pICD9)
    End Function

    Public Sub Remove(ByVal pICD9 As ICD9DB)
        Dim lIndex As Integer

        lIndex = IndexOf(pICD9)

        If lIndex > -1 Then
            List.RemoveAt(lIndex)
        End If

    End Sub

    Default Public Property Item(ByVal Index As Integer) As ICD9DB
        Get
            Return CType(List.Item(Index), ICD9DB)
        End Get
        Set(ByVal Value As ICD9DB)
            List.Item(Index) = Value
        End Set
    End Property

    Public Shadows Function Count() As Integer
        Return List.Count
    End Function


    Public Function IndexOf(ByVal obj As Object) As Integer
        Dim lIndex As Integer = 0
        Dim lFound As Integer = 0

        For Each lObj As Object In List
            lFound = CType(lObj, ICD9DB).Code.CompareTo(CType(obj, ICD9DB).Code)
            If lFound = 0 Then
                Return lIndex
            End If
            lIndex += 1
        Next
        Return -1

    End Function
    
End Class