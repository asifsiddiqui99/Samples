Imports Microsoft.VisualBasic
Public Class ClaimBatchDetailDB

#Region "Fields"
    Private mLineID As String = ""
    Private mBatchID As String = ""
    Private mClaimID As String = ""
    Private mVisitID As String = ""
    Private mStatus As String = ""
#End Region

#Region "Property"

    Public Property LineID() As String
        Get
            Return mLineID
        End Get
        Set(ByVal value As String)
            mLineID = value
        End Set
    End Property

    Public Property BatchID() As String
        Get
            Return mBatchID
        End Get
        Set(ByVal value As String)
            mBatchID = value
        End Set
    End Property

    Public Property ClaimID() As String
        Get
            Return mClaimID
        End Get
        Set(ByVal value As String)
            mClaimID = value
        End Set
    End Property

    Public Property VisitID() As String
        Get
            Return mVisitID
        End Get
        Set(ByVal value As String)
            mVisitID = value
        End Set
    End Property

    Public Property Status() As String
        Get
            Return mStatus
        End Get
        Set(ByVal value As String)
            mStatus = value
        End Set
    End Property

#End Region
End Class
Public Class ClaimBatchDetail
    Implements IDetail
#Region "Fields"
    Private mConnection As Connection
    Private mConnectionString As String
    Private mClaimBatchDetailDB As New ClaimBatchDetailDB
#End Region

#Region "Property"

    Public Property ClaimBatchDetail() As ClaimBatchDetailDB
        Get
            Return mClaimBatchDetailDB
        End Get
        Set(ByVal value As ClaimBatchDetailDB)
            mClaimBatchDetailDB = value
        End Set
    End Property

    Public ReadOnly Property Connection() As ElixirLibrary.Connection Implements IDetail.Connection
        Get
            Return mConnection
        End Get
    End Property

    Public ReadOnly Property ConnectionString() As String Implements IDetail.ConnectionString
        Get
            Return mConnectionString
        End Get
    End Property
#End Region

#Region "Constructor"
    Public Sub New(ByVal pConnectionString As String)
        If pConnectionString = "" Then
            Throw New ArgumentException("ConnectionString can not be empty")
        End If
        mConnectionString = pConnectionString
        mConnection = New Connection(mConnectionString)

    End Sub
    Public Sub New(ByVal pConnection As Connection)
        If pConnection Is Nothing Then
            Throw New ArgumentException("Connection can not be empty")
        End If
        mConnection = pConnection
    End Sub
#End Region

#Region "Methods"
    Sub InsertRecord() Implements IDetail.InsertRecord
    End Sub
    Sub UpdateRecord(ByVal pCondition As String) Implements IDetail.UpdateRecord

    End Sub
    Sub UpdateRecord() Implements IDetail.UpdateRecord

    End Sub
    Sub DeleteRecordByID() Implements IDetail.DeleteRecordByID

    End Sub
    Sub DeleteRecord(ByVal pCondition As String) Implements IDetail.DeleteRecord

    End Sub
    Function GetRecordByID() As Boolean Implements IDetail.GetRecordByID
        Return True
    End Function
    Function GetAllRecords(ByVal pCondition As String) As DataSet Implements IDetail.GetAllRecords
        Dim lds As New DataSet
        Return lds
    End Function
    Function GetAllRecords() As DataSet Implements IDetail.GetAllRecords
        Dim lds As New DataSet
        Return lds
    End Function

    Public Sub InsertRecord(ByVal pXML As String)
        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand("InsertClaimBatchDtl", pXML)
        Else
            Connection.ExecuteCommand("InsertClaimBatchDtl", pXML)
        End If
    End Sub
#End Region

End Class
