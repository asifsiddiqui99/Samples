Imports Microsoft.VisualBasic

Public Class HCFADetailDBUpdated
#Region "Fields"


    Private mLineId As String = ""
    Private mHCFAID As String = ""
    Private mDateOfServiceFrom As String = ""
    Private mDateOfServiceTo As String = ""

    Private mPlaceOfService As String = ""
    Private mTypeOfService As String = ""
    Private mCPTCode As String = ""


    Private mModifierA As String = ""
    Private mModifierB As String = ""
    Private mModifierC As String = ""
    Private mModifierD As String = ""

    Private mDignosisPointer As String = ""
    Private mCharges As String = ""
    Private mDays As String = ""
    Private mEPSDT As String = ""
    Private mEmergency As String = ""
    Private mCOB As String = ""

    Private mRenderingPvdSecIdQualifier As String = ""
    Private mRenderingPvdSecId As String = ""

    Private mCptId As String = ""

    Private mRenderingProvider As New EmployeeDB
    Private mServiceFacility As New FacilityDB


    'Private mFacilityID As String = ""
    'Private mFacilityName As String = ""
    'Private mNPI As String = ""
    'Private mAddressLine1 As String = ""
    'Private mAddressLine2 As String = ""
    'Private mCity As String = ""
    'Private mState As String = ""
    'Private mZipCode As String = ""
    'Private mPhone As String = ""
    'Private mFax As String = ""
    'Private mIsDelete As String = ""
    'Private mFacilityCode As String = ""



    'Private mRenderingPvdSecIdQualifier As String = ""
    'Private mRenderingPvdSecId As String = ""
    'Private mRenderingPvdPvdEmployeeID As String = ""
    'Private mRenderingPvdClinicCode As String = ""
    'Private mRenderingPvdDesignation As String = ""
    'Private mRenderingPvdLoginID As String = ""
    'Private mRenderingPvdPassword As String = ""
    'Private mRenderingPvdTitle As String = ""
    'Private mRenderingPvdFirstName As String = ""
    'Private mRenderingPvdMiddleName As String = ""
    'Private mRenderingPvdLastName As String = ""
    'Private mRenderingPvdGender As String = ""
    'Private mRenderingPvdDOB As String = ""
    'Private mRenderingPvdSSN As String = ""
    'Private mRenderingPvdAddressLine1 As String = ""
    'Private mRenderingPvdAddressLine2 As String = ""
    'Private mRenderingPvdCity As String = ""
    'Private mRenderingPvdStateId As String = ""
    'Private mRenderingPvdZipCode As String = ""
    'Private mRenderingPvdHomePhone As String = ""
    'Private mRenderingWorkPhone As String = ""
    'Private mRenderingPvdWorkPhoneExtension As String = ""
    'Private mRenderingPvdFax As String = ""
    'Private mRenderingPvdEmail As String = ""
    'Private mRenderingPvdLoginStatus As String = ""
    'Private mRenderingPvdSPI As String = ""
    'Private mRenderingPvdDEA As String = ""
    'Private mRenderingPvdLicence As String = ""
    'Private mRenderingPvdServiceLevel As String = ""
    'Private mRenderingPvdStartDate As String = ""
    'Private mRenderingPvdEndDate As String = ""
    'Private mRenderingPvdSigPath As String = ""
    'Private mRenderingPvdIsDeleted As String = ""
    'Private mRenderingPvdTheme As String = ""
    'Private mRenderingPvdScreeningEnabled
    'Private mRenderingPvdDAW As String = ""
    'Private mRenderingPvdSetup_ID As String = ""
    'Private mRenderingPvdNPI As String = ""
    'Private mRenderingPvdTaxID As String = ""
    'Private mRenderingPvdStateLicenseID As String = ""
    'Private mRenderingPvdDEA2 As String = ""
    'Private mRenderingPvdSpecialityCode As String = ""
    'Private mRenderingPvdIsPrintRx As String = ""
    'Private mRenderingPvdDegree As String = ""
    'Private mRenderingPvdIsActive As String = ""
    'Private mRenderingPvdIsLocked As String = ""
    'Private mRenderingPvdIsReseted As String = ""
    'Private mRenderingPvdIsSuperAdmin As String = ""
    'Private mRenderingPvdLoginCount As String = ""
    'Private mRenderingPvdCptNo As String = ""
    'Private mRenderingPvdDEASuffix As String = ""





#End Region

#Region "Properties"
    Public Property CptId() As String
        Get
            Return mCptId
        End Get
        Set(ByVal value As String)
            mCptId = value
        End Set
    End Property
    Public Property HCFAID() As String
        Get
            Return mHCFAID
        End Get
        Set(ByVal value As String)
            mHCFAID = value
        End Set
    End Property

    Public Property LineId() As String
        Get
            Return mLineId
        End Get
        Set(ByVal value As String)
            mLineId = value
        End Set
    End Property

    Public Property DateOfServiceFrom() As String
        Get
            Return mDateOfServiceFrom
        End Get
        Set(ByVal value As String)
            mDateOfServiceFrom = value
        End Set
    End Property

    Public Property DateOfServiceTo() As String
        Get
            Return mDateOfServiceTo
        End Get
        Set(ByVal value As String)
            mDateOfServiceTo = value
        End Set
    End Property
    Public Property PlaceOfService() As String
        Get
            Return mPlaceOfService
        End Get
        Set(ByVal value As String)
            mPlaceOfService = value
        End Set
    End Property
    Public Property TypeOfService() As String
        Get
            Return mTypeOfService
        End Get
        Set(ByVal value As String)
            mTypeOfService = value
        End Set
    End Property

    Public Property CPTCode() As String
        Get
            Return mCPTCode
        End Get
        Set(ByVal value As String)
            mCPTCode = value
        End Set
    End Property

    Public Property ModifierA() As String
        Get
            Return mModifierA
        End Get
        Set(ByVal value As String)
            mModifierA = value
        End Set
    End Property

    Public Property ModifierB() As String
        Get
            Return mModifierB
        End Get
        Set(ByVal value As String)
            mModifierB = value
        End Set
    End Property

    Public Property ModifierC() As String
        Get
            Return mModifierC
        End Get
        Set(ByVal value As String)
            mModifierC = value
        End Set
    End Property

    Public Property ModifierD() As String
        Get
            Return mModifierD
        End Get
        Set(ByVal value As String)
            mModifierD = value
        End Set
    End Property

    Public Property DignosisPointer() As String
        Get
            Return mDignosisPointer
        End Get
        Set(ByVal value As String)
            mDignosisPointer = value
        End Set
    End Property

    Public Property Charges() As Double
        Get
            Return mCharges
        End Get
        Set(ByVal value As Double)
            mCharges = value
        End Set
    End Property

    Public Property Days() As String
        Get
            Return mDays
        End Get
        Set(ByVal value As String)
            mDays = value
        End Set
    End Property

    Public Property EPSDT() As String
        Get
            Return mEPSDT
        End Get
        Set(ByVal value As String)
            mEPSDT = value
        End Set
    End Property

    Public Property Emergency() As String
        Get
            Return Me.mEmergency
        End Get
        Set(ByVal value As String)
            Me.mEmergency = value
        End Set
    End Property

    Public Property COB() As String
        Get
            Return Me.mCOB
        End Get
        Set(ByVal value As String)
            Me.mCOB = value
        End Set
    End Property




    Public Property RenderingProvider() As EmployeeDB
        Get
            Return mRenderingProvider
        End Get
        Set(ByVal value As EmployeeDB)
            mRenderingProvider = value
        End Set
    End Property
    Public Property ServiceFacility() As FacilityDB
        Get
            Return mServiceFacility
        End Get
        Set(ByVal value As FacilityDB)
            mServiceFacility = value
        End Set
    End Property

    Public Property RenderingPvdSecIdQualifier() As String
        Get
            Return Me.mRenderingPvdSecIdQualifier
        End Get
        Set(ByVal value As String)
            Me.mRenderingPvdSecIdQualifier = value
        End Set
    End Property

    Public Property RenderingPvdSecId() As String
        Get
            Return Me.mRenderingPvdSecId
        End Get
        Set(ByVal value As String)
            Me.mRenderingPvdSecId = value
        End Set
    End Property








#End Region



End Class


Public Class HCFADetailUpdated
#Region "Fields"
    Private mConnection As Connection
    Private mConnectionString
    Private mHCFADetailUpdated As New HCFADetailDBUpdated
    Private mHCFADetailCollUpdated As New HCFADetailCollUpdated
#End Region

#Region "Property"
    Public ReadOnly Property Connection() As ElixirLibrary.Connection
        Get
            Return mConnection
        End Get
    End Property

    Public ReadOnly Property ConnectionString() As String
        Get
            Return mConnectionString
        End Get
    End Property
    Public Property HCFADetailUpdated() As HCFADetailDBUpdated
        Get
            Return mHCFADetailUpdated
        End Get
        Set(ByVal value As HCFADetailDBUpdated)
            mHCFADetailUpdated = value
        End Set
    End Property
    Public Property HCFADetailColUpdated() As HCFADetailCollUpdated
        Get
            Return mHCFADetailCollUpdated
        End Get
        Set(ByVal value As HCFADetailCollUpdated)
            mHCFADetailCollUpdated = value
        End Set
    End Property
#End Region

#Region "Constructor"
    ''' <summary>
    ''' Creates new Conection Object based on Given Connection String 
    ''' </summary>
    ''' <param name="pConnectionString">
    ''' Contains Connection String 
    ''' </param>
    ''' <remarks>
    ''' Use when not using transaction
    ''' Must Specify Connection String other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnectionString As String)
        If pConnectionString = "" Then
            Throw New ArgumentException("ConnectionString can not be empty")
        End If

        mConnectionString = pConnectionString
        mConnection = New Connection(mConnectionString)

    End Sub

    ''' <summary>
    ''' Assign given connection to the current Object
    ''' </summary>
    ''' <param name="pConnection">
    ''' Contains refrence to the connection object
    ''' </param>
    ''' <remarks>
    ''' Use when  using Transaction
    ''' Must Specify Connection other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnection As Connection)
        If pConnection Is Nothing Then
            Throw New ArgumentException("Connection can not be empty")
        End If

        mConnection = pConnection
    End Sub
#End Region


#Region "Method"
    ''' <summary>
    ''' Get Single Record By Primary Key
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetRecordsByID() As HCFADetailCollUpdated
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()
        Dim lHcfaDetailCollUpdated As New HCFADetailCollUpdated
        Dim lHcfaDtlUpdated As HCFADetailDBUpdated

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "HCFADetailUpdated"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = "And HCFAID = " & Me.HCFADetailUpdated.HCFAID

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("SelectAllRecords", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
        End If


        With lDs.Tables(0)
            If .Rows.Count > 0 Then
                Dim index As Int32
                For index = 0 To .Rows.Count - 1
                    lHcfaDtlUpdated = New HCFADetailDBUpdated()

                    If (Not IsDBNull(.Rows(index)("Charges"))) Then
                        lHcfaDtlUpdated.Charges = .Rows(index)("Charges")
                    Else
                        lHcfaDtlUpdated.Charges = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("COB"))) Then
                        lHcfaDtlUpdated.COB = .Rows(index)("COB")
                    Else
                        lHcfaDtlUpdated.COB = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("CPTCode"))) Then
                        lHcfaDtlUpdated.CPTCode = .Rows(index)("CPTCode")
                    Else
                        lHcfaDtlUpdated.CPTCode = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("DateOfServiceFrom"))) Then
                        lHcfaDtlUpdated.DateOfServiceFrom = .Rows(index)("DateOfServiceFrom")
                    Else
                        lHcfaDtlUpdated.DateOfServiceFrom = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("DateOfServiceTo"))) Then
                        lHcfaDtlUpdated.DateOfServiceTo = .Rows(index)("DateOfServiceTo")
                    Else
                        lHcfaDtlUpdated.DateOfServiceTo = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("Days"))) Then
                        lHcfaDtlUpdated.Days = .Rows(index)("Days")
                    Else
                        lHcfaDtlUpdated.Days = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("DignosisPointer"))) Then
                        lHcfaDtlUpdated.DignosisPointer = .Rows(index)("DignosisPointer")
                    Else
                        lHcfaDtlUpdated.DignosisPointer = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("Emergency"))) Then
                        lHcfaDtlUpdated.Emergency = .Rows(index)("Emergency")
                    Else
                        lHcfaDtlUpdated.Emergency = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("EPSDT"))) Then
                        lHcfaDtlUpdated.EPSDT = .Rows(index)("EPSDT")
                    Else
                        lHcfaDtlUpdated.EPSDT = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("HCFAID"))) Then
                        lHcfaDtlUpdated.HCFAID = .Rows(index)("HCFAID")
                    Else
                        lHcfaDtlUpdated.HCFAID = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("ModifierA"))) Then
                        lHcfaDtlUpdated.ModifierA = .Rows(index)("ModifierA")
                    Else
                        lHcfaDtlUpdated.ModifierA = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("ModifierB"))) Then
                        lHcfaDtlUpdated.ModifierB = .Rows(index)("ModifierB")
                    Else
                        lHcfaDtlUpdated.ModifierB = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("ModifierC"))) Then
                        lHcfaDtlUpdated.ModifierC = .Rows(index)("ModifierC")
                    Else
                        lHcfaDtlUpdated.ModifierC = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("ModifierD"))) Then
                        lHcfaDtlUpdated.ModifierD = .Rows(index)("ModifierD")
                    Else
                        lHcfaDtlUpdated.ModifierD = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("LineId"))) Then
                        lHcfaDtlUpdated.LineId = .Rows(index)("LineId")
                    Else
                        lHcfaDtlUpdated.LineId = ""
                    End If



                    If (Not IsDBNull(.Rows(index)("PlaceOfService"))) Then
                        lHcfaDtlUpdated.PlaceOfService = .Rows(index)("PlaceOfService")
                    Else
                        lHcfaDtlUpdated.PlaceOfService = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("TypeOfService"))) Then
                        lHcfaDtlUpdated.TypeOfService = .Rows(index)("TypeOfService")
                    Else
                        lHcfaDtlUpdated.TypeOfService = ""
                    End If

                    'add by Kanwal jeet EmployeeDB feilds

                    If (Not IsDBNull(.Rows(index)("RPEmployeeID"))) Then
                        lHcfaDtlUpdated.RenderingProvider.EmployeeID = .Rows(index)("RPEmployeeID")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.EmployeeID = ""
                    End If


                    If (Not IsDBNull(.Rows(index)("RPClinicCode"))) Then
                        lHcfaDtlUpdated.RenderingProvider.ClinicCode = .Rows(index)("RPClinicCode")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.ClinicCode = ""
                    End If


                    If (Not IsDBNull(.Rows(index)("RPDesignation"))) Then
                        lHcfaDtlUpdated.RenderingProvider.Designation = .Rows(index)("RPDesignation")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.Designation = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPLoginID"))) Then
                        lHcfaDtlUpdated.RenderingProvider.LoginID = .Rows(index)("RPLoginID")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.LoginID = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPPassword"))) Then
                        lHcfaDtlUpdated.RenderingProvider.Password = .Rows(index)("RPPassword")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.Password = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPTitle"))) Then
                        lHcfaDtlUpdated.RenderingProvider.Title = .Rows(index)("RPTitle")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.Title = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPFirstName"))) Then
                        lHcfaDtlUpdated.RenderingProvider.FirstName = .Rows(index)("RPFirstName")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.FirstName = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPMiddleName"))) Then
                        lHcfaDtlUpdated.RenderingProvider.MiddleName = .Rows(index)("RPMiddleName")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.MiddleName = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPLastName"))) Then
                        lHcfaDtlUpdated.RenderingProvider.LastName = .Rows(index)("RPLastName")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.LastName = ""
                    End If


                    If (Not IsDBNull(.Rows(index)("RPGender"))) Then
                        lHcfaDtlUpdated.RenderingProvider.Gender = .Rows(index)("RPGender")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.Gender = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPDOB"))) Then
                        lHcfaDtlUpdated.RenderingProvider.DOB = .Rows(index)("RPDOB")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.DOB = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPSSN"))) Then
                        lHcfaDtlUpdated.RenderingProvider.SSN = .Rows(index)("RPSSN")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.SSN = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPAddressLine1"))) Then
                        lHcfaDtlUpdated.RenderingProvider.AddressLine1 = .Rows(index)("RPAddressLine1")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.AddressLine1 = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPAddressLine2"))) Then
                        lHcfaDtlUpdated.RenderingProvider.AddressLine2 = .Rows(index)("RPAddressLine2")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.AddressLine2 = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPCity"))) Then
                        lHcfaDtlUpdated.RenderingProvider.City = .Rows(index)("RPCity")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.City = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPStateId"))) Then
                        lHcfaDtlUpdated.RenderingProvider.StateId = .Rows(index)("RPStateId")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.StateId = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPZipCode"))) Then
                        lHcfaDtlUpdated.RenderingProvider.ZipCode = .Rows(index)("RPZipCode")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.ZipCode = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPHomePhone"))) Then
                        lHcfaDtlUpdated.RenderingProvider.HomePhone = .Rows(index)("RPHomePhone")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.HomePhone = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPWorkPhone"))) Then
                        lHcfaDtlUpdated.RenderingProvider.WorkPhone = .Rows(index)("RPWorkPhone")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.WorkPhone = ""
                    End If


                    If (Not IsDBNull(.Rows(index)("RPWorkPhoneExtension"))) Then
                        lHcfaDtlUpdated.RenderingProvider.WorkPhoneExtension = .Rows(index)("RPWorkPhoneExtension")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.WorkPhoneExtension = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPFax"))) Then
                        lHcfaDtlUpdated.RenderingProvider.Fax = .Rows(index)("RPFax")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.Fax = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPEmail"))) Then
                        lHcfaDtlUpdated.RenderingProvider.Email = .Rows(index)("RPEmail")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.Email = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPLoginStatus"))) Then
                        lHcfaDtlUpdated.RenderingProvider.LoginStatus = .Rows(index)("RPLoginStatus")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.LoginStatus = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPSPI"))) Then
                        lHcfaDtlUpdated.RenderingProvider.SPI = .Rows(index)("RPSPI")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.SPI = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPDEA"))) Then
                        lHcfaDtlUpdated.RenderingProvider.DEA = .Rows(index)("RPDEA")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.DEA = ""
                    End If


                    If (Not IsDBNull(.Rows(index)("RPLicence"))) Then
                        lHcfaDtlUpdated.RenderingProvider.Licence = .Rows(index)("RPLicence")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.Licence = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPServiceLevel"))) Then
                        lHcfaDtlUpdated.RenderingProvider.ServiceLevel = .Rows(index)("RPServiceLevel")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.ServiceLevel = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPStartDate"))) Then
                        lHcfaDtlUpdated.RenderingProvider.StartDate = .Rows(index)("RPStartDate")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.StartDate = ""
                    End If


                    If (Not IsDBNull(.Rows(index)("RPEndDate"))) Then
                        lHcfaDtlUpdated.RenderingProvider.EndDate = .Rows(index)("RPEndDate")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.EndDate = ""
                    End If



                    If (Not IsDBNull(.Rows(index)("RPSigPath"))) Then
                        lHcfaDtlUpdated.RenderingProvider.SigPath = .Rows(index)("RPSigPath")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.SigPath = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPIsDeleted"))) Then
                        lHcfaDtlUpdated.RenderingProvider.IsDeleted = .Rows(index)("RPIsDeleted")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.IsDeleted = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPTheme"))) Then
                        lHcfaDtlUpdated.RenderingProvider.Theme = .Rows(index)("RPTheme")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.Theme = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPScreeningEnabled"))) Then
                        lHcfaDtlUpdated.RenderingProvider.ScreeningEnabled = .Rows(index)("RPScreeningEnabled")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.ScreeningEnabled = ""
                    End If

                    'If (Not IsDBNull(.Rows(index)("RPDAW"))) Then
                    '    lHcfaDtlUpdated.RenderingProvider.DAW = .Rows(index)("RPDAW")
                    'Else
                    '    lHcfaDtlUpdated.RenderingProvider.DAW = ""
                    'End If

                    If (Not IsDBNull(.Rows(index)("RPSetup_ID"))) Then
                        lHcfaDtlUpdated.RenderingProvider.SetupID = .Rows(index)("RPSetup_ID")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.SetupID = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPNPI"))) Then
                        lHcfaDtlUpdated.RenderingProvider.NPI = .Rows(index)("RPNPI")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.NPI = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPTaxID"))) Then
                        lHcfaDtlUpdated.RenderingProvider.TaxID = .Rows(index)("RPTaxID")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.TaxID = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPStateLicenseID"))) Then
                        lHcfaDtlUpdated.RenderingProvider.StateLicenseID = .Rows(index)("RPStateLicenseID")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.StateLicenseID = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPDEA2"))) Then
                        lHcfaDtlUpdated.RenderingProvider.DEA2 = .Rows(index)("RPDEA2")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.DEA2 = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPSpecialityCode"))) Then
                        lHcfaDtlUpdated.RenderingProvider.SpecialityCode = .Rows(index)("RPSpecialityCode")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.SpecialityCode = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPIsPrintRx"))) Then
                        lHcfaDtlUpdated.RenderingProvider.IsPrintRx = .Rows(index)("RPIsPrintRx")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.IsPrintRx = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPDegree"))) Then
                        lHcfaDtlUpdated.RenderingProvider.Degree = .Rows(index)("RPDegree")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.Degree = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPIsActive"))) Then
                        lHcfaDtlUpdated.RenderingProvider.IsActive = .Rows(index)("RPIsActive")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.IsActive = ""
                    End If

                 
                    If (Not IsDBNull(.Rows(index)("RPIsLocked"))) Then
                        lHcfaDtlUpdated.RenderingProvider.IsLocked = .Rows(index)("RPIsLocked")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.IsLocked = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPIsReseted"))) Then
                        lHcfaDtlUpdated.RenderingProvider.IsReseted = .Rows(index)("RPIsReseted")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.IsReseted = ""
                    End If


                    If (Not IsDBNull(.Rows(index)("RPIsSuperAdmin"))) Then
                        lHcfaDtlUpdated.RenderingProvider.IsSuperAdmin = .Rows(index)("RPIsSuperAdmin")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.IsSuperAdmin = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPLoginCount"))) Then
                        lHcfaDtlUpdated.RenderingProvider.LoginCount = .Rows(index)("RPLoginCount")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.LoginCount = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPCptNo"))) Then
                        lHcfaDtlUpdated.RenderingProvider.CptNo = .Rows(index)("RPCptNo")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.CptNo = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPDEASuffix"))) Then
                        lHcfaDtlUpdated.RenderingProvider.DEASuffix = .Rows(index)("RPDEASuffix")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.DEASuffix = ""
                    End If


                    'add  FacilityDB feilds 


                    If (Not IsDBNull(.Rows(index)("FacFacilityID"))) Then
                        lHcfaDtlUpdated.ServiceFacility.FacilityID = .Rows(index)("FacFacilityID")
                    Else
                        lHcfaDtlUpdated.ServiceFacility.FacilityID = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("FacFacilityName"))) Then
                        lHcfaDtlUpdated.ServiceFacility.FacilityName = .Rows(index)("FacFacilityName")
                    Else
                        lHcfaDtlUpdated.ServiceFacility.FacilityName = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("FacNPI"))) Then
                        lHcfaDtlUpdated.ServiceFacility.NPI = .Rows(index)("FacNPI")
                    Else
                        lHcfaDtlUpdated.ServiceFacility.NPI = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("FacAddressLine1"))) Then
                        lHcfaDtlUpdated.ServiceFacility.AddressLine1 = .Rows(index)("FacAddressLine1")
                    Else
                        lHcfaDtlUpdated.ServiceFacility.AddressLine1 = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("FacAddressLine2"))) Then
                        lHcfaDtlUpdated.ServiceFacility.AddressLine2 = .Rows(index)("FacAddressLine2")
                    Else
                        lHcfaDtlUpdated.ServiceFacility.AddressLine2 = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("FacCity"))) Then
                        lHcfaDtlUpdated.ServiceFacility.City = .Rows(index)("FacCity")
                    Else
                        lHcfaDtlUpdated.ServiceFacility.City = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("FacState"))) Then
                        lHcfaDtlUpdated.ServiceFacility.State = .Rows(index)("FacState")
                    Else
                        lHcfaDtlUpdated.ServiceFacility.State = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("FacZipCode"))) Then
                        lHcfaDtlUpdated.ServiceFacility.ZipCode = .Rows(index)("FacZipCode")
                    Else
                        lHcfaDtlUpdated.ServiceFacility.ZipCode = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("FacPhone"))) Then
                        lHcfaDtlUpdated.ServiceFacility.Phone = .Rows(index)("FacPhone")
                    Else
                        lHcfaDtlUpdated.ServiceFacility.Phone = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("FacFax"))) Then
                        lHcfaDtlUpdated.ServiceFacility.Fax = .Rows(index)("FacFax")
                    Else
                        lHcfaDtlUpdated.ServiceFacility.Fax = ""
                    End If

                    'If (Not IsDBNull(.Rows(index)("FacIsDelete"))) Then
                    '    lHcfaDtlUpdated.ServiceFacility.IsDelete = .Rows(index)("FacIsDelete")
                    'Else
                    '    lHcfaDtlUpdated.ServiceFacility.IsDelete = ""
                    'End If


                    If (Not IsDBNull(.Rows(index)("FacFacilityCode"))) Then
                        lHcfaDtlUpdated.ServiceFacility.FacilityCode = .Rows(index)("FacFacilityCode").ToString
                    Else
                        lHcfaDtlUpdated.ServiceFacility.FacilityCode = "0"
                    End If

                    If (Not IsDBNull(.Rows(index)("CptId"))) Then
                        lHcfaDtlUpdated.CptId = .Rows(index)("CptId").ToString
                    Else
                        lHcfaDtlUpdated.CptId = ""
                    End If

                    lHcfaDetailCollUpdated.Add(lHcfaDtlUpdated)
                Next

            End If

            Return lHcfaDetailCollUpdated
        End With

    End Function

    Public Function GetRecordsByHCFAID(ByVal pHCFAID As String) As HCFADetailCollUpdated
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()
        Dim lHcfaDetailCollUpdated As New HCFADetailCollUpdated
        Dim lHcfaDtlUpdated As HCFADetailDBUpdated

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "HCFADetailUpdated"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = "And HCFAID = " & pHCFAID

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("SelectAllRecords", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
        End If


        With lDs.Tables(0)
            If .Rows.Count > 0 Then
                Dim index As Int32
                For index = 0 To .Rows.Count - 1
                    lHcfaDtlUpdated = New HCFADetailDBUpdated()

                    If (Not IsDBNull(.Rows(index)("Charges"))) Then
                        lHcfaDtlUpdated.Charges = .Rows(index)("Charges")
                    Else
                        lHcfaDtlUpdated.Charges = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("COB"))) Then
                        lHcfaDtlUpdated.COB = .Rows(index)("COB")
                    Else
                        lHcfaDtlUpdated.COB = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("CPTCode"))) Then
                        lHcfaDtlUpdated.CPTCode = .Rows(index)("CPTCode")
                    Else
                        lHcfaDtlUpdated.CPTCode = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("DateOfServiceFrom"))) Then
                        lHcfaDtlUpdated.DateOfServiceFrom = .Rows(index)("DateOfServiceFrom")
                    Else
                        lHcfaDtlUpdated.DateOfServiceFrom = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("DateOfServiceTo"))) Then
                        lHcfaDtlUpdated.DateOfServiceTo = .Rows(index)("DateOfServiceTo")
                    Else
                        lHcfaDtlUpdated.DateOfServiceTo = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("Days"))) Then
                        lHcfaDtlUpdated.Days = .Rows(index)("Days")
                    Else
                        lHcfaDtlUpdated.Days = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("DignosisPointer"))) Then
                        lHcfaDtlUpdated.DignosisPointer = .Rows(index)("DignosisPointer")
                    Else
                        lHcfaDtlUpdated.DignosisPointer = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("Emergency"))) Then
                        lHcfaDtlUpdated.Emergency = .Rows(index)("Emergency")
                    Else
                        lHcfaDtlUpdated.Emergency = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("EPSDT"))) Then
                        lHcfaDtlUpdated.EPSDT = .Rows(index)("EPSDT")
                    Else
                        lHcfaDtlUpdated.EPSDT = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("HCFAID"))) Then
                        lHcfaDtlUpdated.HCFAID = .Rows(index)("HCFAID")
                    Else
                        lHcfaDtlUpdated.HCFAID = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("ModifierA"))) Then
                        lHcfaDtlUpdated.ModifierA = .Rows(index)("ModifierA")
                    Else
                        lHcfaDtlUpdated.ModifierA = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("ModifierB"))) Then
                        lHcfaDtlUpdated.ModifierB = .Rows(index)("ModifierB")
                    Else
                        lHcfaDtlUpdated.ModifierB = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("ModifierC"))) Then
                        lHcfaDtlUpdated.ModifierC = .Rows(index)("ModifierC")
                    Else
                        lHcfaDtlUpdated.ModifierC = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("ModifierD"))) Then
                        lHcfaDtlUpdated.ModifierD = .Rows(index)("ModifierD")
                    Else
                        lHcfaDtlUpdated.ModifierD = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("LineId"))) Then
                        lHcfaDtlUpdated.LineId = .Rows(index)("LineId")
                    Else
                        lHcfaDtlUpdated.LineId = ""
                    End If



                    If (Not IsDBNull(.Rows(index)("PlaceOfService"))) Then
                        lHcfaDtlUpdated.PlaceOfService = .Rows(index)("PlaceOfService")
                    Else
                        lHcfaDtlUpdated.PlaceOfService = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("TypeOfService"))) Then
                        lHcfaDtlUpdated.TypeOfService = .Rows(index)("TypeOfService")
                    Else
                        lHcfaDtlUpdated.TypeOfService = ""
                    End If

                    'add by Kanwal jeet EmployeeDB feilds

                    If (Not IsDBNull(.Rows(index)("RPEmployeeID"))) Then
                        lHcfaDtlUpdated.RenderingProvider.EmployeeID = .Rows(index)("RPEmployeeID")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.EmployeeID = ""
                    End If


                    If (Not IsDBNull(.Rows(index)("RPClinicCode"))) Then
                        lHcfaDtlUpdated.RenderingProvider.ClinicCode = .Rows(index)("RPClinicCode")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.ClinicCode = ""
                    End If


                    If (Not IsDBNull(.Rows(index)("RPDesignation"))) Then
                        lHcfaDtlUpdated.RenderingProvider.Designation = .Rows(index)("RPDesignation")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.Designation = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPLoginID"))) Then
                        lHcfaDtlUpdated.RenderingProvider.LoginID = .Rows(index)("RPLoginID")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.LoginID = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPPassword"))) Then
                        lHcfaDtlUpdated.RenderingProvider.Password = .Rows(index)("RPPassword")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.Password = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPTitle"))) Then
                        lHcfaDtlUpdated.RenderingProvider.Title = .Rows(index)("RPTitle")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.Title = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPFirstName"))) Then
                        lHcfaDtlUpdated.RenderingProvider.FirstName = .Rows(index)("RPFirstName")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.FirstName = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPMiddleName"))) Then
                        lHcfaDtlUpdated.RenderingProvider.MiddleName = .Rows(index)("RPMiddleName")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.MiddleName = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPLastName"))) Then
                        lHcfaDtlUpdated.RenderingProvider.LastName = .Rows(index)("RPLastName")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.LastName = ""
                    End If


                    If (Not IsDBNull(.Rows(index)("RPGender"))) Then
                        lHcfaDtlUpdated.RenderingProvider.Gender = .Rows(index)("RPGender")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.Gender = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPDOB"))) Then
                        lHcfaDtlUpdated.RenderingProvider.DOB = .Rows(index)("RPDOB")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.DOB = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPSSN"))) Then
                        lHcfaDtlUpdated.RenderingProvider.SSN = .Rows(index)("RPSSN")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.SSN = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPAddressLine1"))) Then
                        lHcfaDtlUpdated.RenderingProvider.AddressLine1 = .Rows(index)("RPAddressLine1")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.AddressLine1 = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPAddressLine2"))) Then
                        lHcfaDtlUpdated.RenderingProvider.AddressLine2 = .Rows(index)("RPAddressLine2")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.AddressLine2 = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPCity"))) Then
                        lHcfaDtlUpdated.RenderingProvider.City = .Rows(index)("RPCity")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.City = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPStateId"))) Then
                        lHcfaDtlUpdated.RenderingProvider.StateId = .Rows(index)("RPStateId").ToString
                    Else
                        lHcfaDtlUpdated.RenderingProvider.StateId = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPZipCode"))) Then
                        lHcfaDtlUpdated.RenderingProvider.ZipCode = .Rows(index)("RPZipCode")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.ZipCode = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPHomePhone"))) Then
                        lHcfaDtlUpdated.RenderingProvider.HomePhone = .Rows(index)("RPHomePhone")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.HomePhone = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPWorkPhone"))) Then
                        lHcfaDtlUpdated.RenderingProvider.WorkPhone = .Rows(index)("RPWorkPhone")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.WorkPhone = ""
                    End If


                    If (Not IsDBNull(.Rows(index)("RPWorkPhoneExtension"))) Then
                        lHcfaDtlUpdated.RenderingProvider.WorkPhoneExtension = .Rows(index)("RPWorkPhoneExtension")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.WorkPhoneExtension = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPFax"))) Then
                        lHcfaDtlUpdated.RenderingProvider.Fax = .Rows(index)("RPFax")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.Fax = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPEmail"))) Then
                        lHcfaDtlUpdated.RenderingProvider.Email = .Rows(index)("RPEmail")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.Email = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPLoginStatus"))) Then
                        lHcfaDtlUpdated.RenderingProvider.LoginStatus = .Rows(index)("RPLoginStatus")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.LoginStatus = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPSPI"))) Then
                        lHcfaDtlUpdated.RenderingProvider.SPI = .Rows(index)("RPSPI")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.SPI = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPDEA"))) Then
                        lHcfaDtlUpdated.RenderingProvider.DEA = .Rows(index)("RPDEA")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.DEA = ""
                    End If


                    If (Not IsDBNull(.Rows(index)("RPLicence"))) Then
                        lHcfaDtlUpdated.RenderingProvider.Licence = .Rows(index)("RPLicence")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.Licence = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPServiceLevel"))) Then
                        lHcfaDtlUpdated.RenderingProvider.ServiceLevel = .Rows(index)("RPServiceLevel")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.ServiceLevel = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPStartDate"))) Then
                        lHcfaDtlUpdated.RenderingProvider.StartDate = .Rows(index)("RPStartDate")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.StartDate = ""
                    End If


                    If (Not IsDBNull(.Rows(index)("RPEndDate"))) Then
                        lHcfaDtlUpdated.RenderingProvider.EndDate = .Rows(index)("RPEndDate")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.EndDate = ""
                    End If



                    If (Not IsDBNull(.Rows(index)("RPSigPath"))) Then
                        lHcfaDtlUpdated.RenderingProvider.SigPath = .Rows(index)("RPSigPath")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.SigPath = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPIsDeleted"))) Then
                        lHcfaDtlUpdated.RenderingProvider.IsDeleted = .Rows(index)("RPIsDeleted")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.IsDeleted = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPTheme"))) Then
                        lHcfaDtlUpdated.RenderingProvider.Theme = .Rows(index)("RPTheme")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.Theme = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPScreeningEnabled"))) Then
                        lHcfaDtlUpdated.RenderingProvider.ScreeningEnabled = .Rows(index)("RPScreeningEnabled")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.ScreeningEnabled = ""
                    End If

                    'If (Not IsDBNull(.Rows(index)("RPDAW"))) Then
                    '    lHcfaDtlUpdated.RenderingProvider.DAW = .Rows(index)("RPDAW")
                    'Else
                    '    lHcfaDtlUpdated.RenderingProvider.DAW = ""
                    'End If

                    If (Not IsDBNull(.Rows(index)("RPSetup_ID"))) Then
                        lHcfaDtlUpdated.RenderingProvider.SetupID = .Rows(index)("RPSetup_ID")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.SetupID = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPNPI"))) Then
                        lHcfaDtlUpdated.RenderingProvider.NPI = .Rows(index)("RPNPI")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.NPI = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPTaxID"))) Then
                        lHcfaDtlUpdated.RenderingProvider.TaxID = .Rows(index)("RPTaxID")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.TaxID = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPStateLicenseID"))) Then
                        lHcfaDtlUpdated.RenderingProvider.StateLicenseID = .Rows(index)("RPStateLicenseID")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.StateLicenseID = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPDEA2"))) Then
                        lHcfaDtlUpdated.RenderingProvider.DEA2 = .Rows(index)("RPDEA2")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.DEA2 = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPSpecialityCode"))) Then
                        lHcfaDtlUpdated.RenderingProvider.SpecialityCode = .Rows(index)("RPSpecialityCode")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.SpecialityCode = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPIsPrintRx"))) Then
                        lHcfaDtlUpdated.RenderingProvider.IsPrintRx = .Rows(index)("RPIsPrintRx")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.IsPrintRx = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPDegree"))) Then
                        lHcfaDtlUpdated.RenderingProvider.Degree = .Rows(index)("RPDegree")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.Degree = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPIsActive"))) Then
                        lHcfaDtlUpdated.RenderingProvider.IsActive = .Rows(index)("RPIsActive")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.IsActive = ""
                    End If


                    If (Not IsDBNull(.Rows(index)("RPIsLocked"))) Then
                        lHcfaDtlUpdated.RenderingProvider.IsLocked = .Rows(index)("RPIsLocked")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.IsLocked = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPIsReseted"))) Then
                        lHcfaDtlUpdated.RenderingProvider.IsReseted = .Rows(index)("RPIsReseted")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.IsReseted = ""
                    End If


                    If (Not IsDBNull(.Rows(index)("RPIsSuperAdmin"))) Then
                        lHcfaDtlUpdated.RenderingProvider.IsSuperAdmin = .Rows(index)("RPIsSuperAdmin")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.IsSuperAdmin = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPLoginCount"))) Then
                        lHcfaDtlUpdated.RenderingProvider.LoginCount = .Rows(index)("RPLoginCount")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.LoginCount = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPCptNo"))) Then
                        lHcfaDtlUpdated.RenderingProvider.CptNo = .Rows(index)("RPCptNo")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.CptNo = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("RPDEASuffix"))) Then
                        lHcfaDtlUpdated.RenderingProvider.DEASuffix = .Rows(index)("RPDEASuffix")
                    Else
                        lHcfaDtlUpdated.RenderingProvider.DEASuffix = ""
                    End If


                    'add  FacilityDB feilds 


                    If (Not IsDBNull(.Rows(index)("FacFacilityID"))) Then
                        lHcfaDtlUpdated.ServiceFacility.FacilityID = .Rows(index)("FacFacilityID").ToString
                    Else
                        lHcfaDtlUpdated.ServiceFacility.FacilityID = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("FacFacilityName"))) Then
                        lHcfaDtlUpdated.ServiceFacility.FacilityName = .Rows(index)("FacFacilityName")
                    Else
                        lHcfaDtlUpdated.ServiceFacility.FacilityName = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("FacNPI"))) Then
                        lHcfaDtlUpdated.ServiceFacility.NPI = .Rows(index)("FacNPI")
                    Else
                        lHcfaDtlUpdated.ServiceFacility.NPI = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("FacAddressLine1"))) Then
                        lHcfaDtlUpdated.ServiceFacility.AddressLine1 = .Rows(index)("FacAddressLine1")
                    Else
                        lHcfaDtlUpdated.ServiceFacility.AddressLine1 = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("FacAddressLine2"))) Then
                        lHcfaDtlUpdated.ServiceFacility.AddressLine2 = .Rows(index)("FacAddressLine2")
                    Else
                        lHcfaDtlUpdated.ServiceFacility.AddressLine2 = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("FacCity"))) Then
                        lHcfaDtlUpdated.ServiceFacility.City = .Rows(index)("FacCity")
                    Else
                        lHcfaDtlUpdated.ServiceFacility.City = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("FacState"))) Then
                        lHcfaDtlUpdated.ServiceFacility.State = .Rows(index)("FacState")
                    Else
                        lHcfaDtlUpdated.ServiceFacility.State = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("FacZipCode"))) Then
                        lHcfaDtlUpdated.ServiceFacility.ZipCode = .Rows(index)("FacZipCode")
                    Else
                        lHcfaDtlUpdated.ServiceFacility.ZipCode = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("FacPhone"))) Then
                        lHcfaDtlUpdated.ServiceFacility.Phone = .Rows(index)("FacPhone")
                    Else
                        lHcfaDtlUpdated.ServiceFacility.Phone = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("FacFax"))) Then
                        lHcfaDtlUpdated.ServiceFacility.Fax = .Rows(index)("FacFax")
                    Else
                        lHcfaDtlUpdated.ServiceFacility.Fax = ""
                    End If

                    'If (Not IsDBNull(.Rows(index)("FacIsDelete"))) Then
                    '    lHcfaDtlUpdated.ServiceFacility.IsDelete = .Rows(index)("FacIsDelete")
                    'Else
                    '    lHcfaDtlUpdated.ServiceFacility.IsDelete = ""
                    'End If


                    If (Not IsDBNull(.Rows(index)("FacFacilityCode"))) Then
                        lHcfaDtlUpdated.ServiceFacility.FacilityCode = .Rows(index)("FacFacilityCode").ToString
                    Else
                        lHcfaDtlUpdated.ServiceFacility.FacilityCode = "0"
                    End If

                    If (Not IsDBNull(.Rows(index)("CptId"))) Then
                        lHcfaDtlUpdated.CptId = .Rows(index)("CptId").ToString
                    Else
                        lHcfaDtlUpdated.CptId = ""
                    End If

                    lHcfaDetailCollUpdated.Add(lHcfaDtlUpdated)
                Next

            End If

            Return lHcfaDetailCollUpdated
        End With

    End Function

    Public Function GetRecordsFromPatientCPTUpdated(ByVal lPatientSuperBillID As String) As HCFADetailCollUpdated
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()
        Dim lHcfaDtlUpdated As HCFADetailDBUpdated
        Dim lHcfaDtlCollUpdated As New HCFADetailCollUpdated()


        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "PatientCPT"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = "And PatientSuperBillID = " & lPatientSuperBillID

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("SelectAllRecords", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
        End If


        With lDs.Tables(0)
            If .Rows.Count > 0 Then
                Dim index As Int32
                For index = 0 To .Rows.Count - 1
                    lHcfaDtlUpdated = New HCFADetailDBUpdated()
                    If (Not IsDBNull(.Rows(index)("Charges"))) Then
                        lHcfaDtlUpdated.Charges = .Rows(index)("Charges")
                    Else
                        lHcfaDtlUpdated.Charges = ""
                    End If


                    If (Not IsDBNull(.Rows(index)("Code"))) Then
                        lHcfaDtlUpdated.CPTCode = .Rows(index)("Code")
                    Else
                        lHcfaDtlUpdated.CPTCode = ""
                    End If


                    If (Not IsDBNull(.Rows(index)("Days"))) Then
                        lHcfaDtlUpdated.Days = .Rows(index)("Days")
                    Else
                        lHcfaDtlUpdated.Days = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("Pointer"))) Then
                        lHcfaDtlUpdated.DignosisPointer = .Rows(index)("Pointer")
                    Else
                        lHcfaDtlUpdated.DignosisPointer = ""
                    End If


                    If (Not IsDBNull(.Rows(index)("ModifierA"))) Then
                        lHcfaDtlUpdated.ModifierA = .Rows(index)("ModifierA")
                    Else
                        lHcfaDtlUpdated.ModifierA = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("ModifierB"))) Then
                        lHcfaDtlUpdated.ModifierB = .Rows(index)("ModifierB")
                    Else
                        lHcfaDtlUpdated.ModifierB = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("ModifierC"))) Then
                        lHcfaDtlUpdated.ModifierC = .Rows(index)("ModifierC")
                    Else
                        lHcfaDtlUpdated.ModifierC = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("ModifierD"))) Then
                        lHcfaDtlUpdated.ModifierD = .Rows(index)("ModifierD")
                    Else
                        lHcfaDtlUpdated.ModifierD = ""
                    End If


                    If (Not IsDBNull(.Rows(index)("POS"))) Then
                        lHcfaDtlUpdated.PlaceOfService = .Rows(index)("POS")
                    Else
                        lHcfaDtlUpdated.PlaceOfService = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("DateOfServiceFrom"))) Then
                        lHcfaDtlUpdated.DateOfServiceFrom = .Rows(index)("DateOfServiceFrom")
                    Else
                        lHcfaDtlUpdated.DateOfServiceFrom = Date.Now
                    End If

                    If (Not IsDBNull(.Rows(index)("DateOfServiceTo"))) Then
                        lHcfaDtlUpdated.DateOfServiceTo = .Rows(index)("DateOfServiceTo") 'DateAdd(DateInterval.Day, .Rows(index)("Days") - 1, CType(.Rows(index)("CPTDate"), Date))
                    Else
                        lHcfaDtlUpdated.DateOfServiceTo = Date.Now
                    End If


                    If (Not IsDBNull(.Rows(index)("FacilityId")) AndAlso .Rows(index)("FacilityId") <> "") Then
                        lHcfaDtlUpdated.ServiceFacility.FacilityID = .Rows(index)("FacilityId").ToString
                    Else
                        lHcfaDtlUpdated.ServiceFacility.FacilityID = "0"
                    End If


                    If (Not IsDBNull(.Rows(index)("ProviderId")) AndAlso .Rows(index)("ProviderId") <> "") Then
                        lHcfaDtlUpdated.RenderingProvider.EmployeeID = .Rows(index)("ProviderId").ToString.Split("|")(0) '.ToString
                    Else
                        lHcfaDtlUpdated.RenderingProvider.EmployeeID = 0
                    End If


                    If (Not IsDBNull(.Rows(index)("LineId"))) Then
                        lHcfaDtlUpdated.CptId = .Rows(index)("LineId").ToString
                    Else
                        lHcfaDtlUpdated.CptId = ""
                    End If


                    lHcfaDtlCollUpdated.Add(lHcfaDtlUpdated)
                Next

            End If

            Return lHcfaDtlCollUpdated
        End With

    End Function

    Public Function GetRecordsFromPatientCPT(ByVal lPatientSuperBillID As String) As HCFADetailColl
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()
        Dim lHcfaDtl As HCFADetailDB
        Dim lHcfaDtlColl As New HCFADetailColl()


        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "PatientCPT"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = "And PatientSuperBillID = " & lPatientSuperBillID

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("SelectAllRecords", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
        End If


        With lDs.Tables(0)
            If .Rows.Count > 0 Then
                Dim index As Int32
                For index = 0 To .Rows.Count - 1
                    lHcfaDtl = New HCFADetailDB()
                    If (Not IsDBNull(.Rows(index)("Charges"))) Then
                        lHcfaDtl.Charges = .Rows(index)("Charges")
                    Else
                        lHcfaDtl.Charges = ""
                    End If


                    If (Not IsDBNull(.Rows(index)("Code"))) Then
                        lHcfaDtl.CPTCode = .Rows(index)("Code")
                    Else
                        lHcfaDtl.CPTCode = ""
                    End If


                    If (Not IsDBNull(.Rows(index)("Days"))) Then
                        lHcfaDtl.Days = .Rows(index)("Days")
                    Else
                        lHcfaDtl.Days = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("Pointer"))) Then
                        lHcfaDtl.DignosisPointer = .Rows(index)("Pointer")
                    Else
                        lHcfaDtl.DignosisPointer = ""
                    End If


                    If (Not IsDBNull(.Rows(index)("ModifierA"))) Then
                        lHcfaDtl.ModifierA = .Rows(index)("ModifierA")
                    Else
                        lHcfaDtl.ModifierA = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("ModifierB"))) Then
                        lHcfaDtl.ModifierB = .Rows(index)("ModifierB")
                    Else
                        lHcfaDtl.ModifierB = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("ModifierC"))) Then
                        lHcfaDtl.ModifierC = .Rows(index)("ModifierC")
                    Else
                        lHcfaDtl.ModifierC = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("ModifierD"))) Then
                        lHcfaDtl.ModifierD = .Rows(index)("ModifierD")
                    Else
                        lHcfaDtl.ModifierD = ""
                    End If


                    If (Not IsDBNull(.Rows(index)("POS"))) Then
                        lHcfaDtl.PlaceOfService = .Rows(index)("POS")
                    Else
                        lHcfaDtl.PlaceOfService = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("CPTDate"))) Then
                        lHcfaDtl.DateOfServiceFrom = .Rows(index)("CPTDate")
                    Else
                        lHcfaDtl.DateOfServiceFrom = ""
                    End If

                    If (Not IsDBNull(.Rows(index)("CPTDate"))) Then
                        lHcfaDtl.DateOfServiceTo = DateAdd(DateInterval.Day, .Rows(index)("Days") - 1, CType(.Rows(index)("CPTDate"), Date))
                    Else
                        lHcfaDtl.DateOfServiceTo = ""
                    End If


                    lHcfaDtlColl.Add(lHcfaDtl)

                Next

            End If

            Return lHcfaDtlColl
        End With

    End Function

    Public Function InsertRecord() As String
        Dim lXmlDocument As New XmlDocument
        Dim lXmlElement As XmlElement

        Dim index As Int32

        lXmlDocument.LoadXml("<HCFADetailUpdatedS></HCFADetailUpdatedS>")
        lXmlElement = lXmlDocument.CreateElement("HCFADetailUpdated")

        Dim lSetupID As String = "0"

        'If Not Employee.DEA.Equals("") Then
        Dim lQuery As String = "select min(id) from Setup"

        If Connection.IsTransactionAlive() Then
            lSetupID = Connection.ExecuteTransactionScalarCommand(lQuery)
        Else
            lSetupID = Connection.ExecuteScalarCommand(lQuery)
        End If
        For index = 0 To HCFADetailColUpdated.Count - 1
            With lXmlElement
                .SetAttribute("HCFAID", HCFADetailColUpdated.Item(index).HCFAID)
                .SetAttribute("DateOfServiceFrom", HCFADetailColUpdated.Item(index).DateOfServiceFrom)
                .SetAttribute("DateOfServiceTo", HCFADetailColUpdated.Item(index).DateOfServiceTo)
                .SetAttribute("PlaceOfService", HCFADetailColUpdated.Item(index).PlaceOfService)
                .SetAttribute("TypeOfService", HCFADetailColUpdated.Item(index).TypeOfService)
                .SetAttribute("CPTCode", HCFADetailColUpdated.Item(index).CPTCode)
                .SetAttribute("ModifierA", HCFADetailColUpdated.Item(index).ModifierA)
                .SetAttribute("ModifierB", HCFADetailColUpdated.Item(index).ModifierB)
                .SetAttribute("ModifierC", HCFADetailColUpdated.Item(index).ModifierC)
                .SetAttribute("ModifierD", HCFADetailColUpdated.Item(index).ModifierD)
                .SetAttribute("DignosisPointer", HCFADetailColUpdated.Item(index).DignosisPointer)
                .SetAttribute("Charges", HCFADetailColUpdated.Item(index).Charges)
                .SetAttribute("Days", HCFADetailColUpdated.Item(index).Days)
                .SetAttribute("EPSDT", HCFADetailColUpdated.Item(index).EPSDT)
                .SetAttribute("Emergency", HCFADetailColUpdated.Item(index).Emergency)
                .SetAttribute("COB", HCFADetailColUpdated.Item(index).COB)
                .SetAttribute("CptId", HCFADetailColUpdated.Item(index).CptId)

                .SetAttribute("FacFacilityID", Me.HCFADetailUpdated.ServiceFacility.FacilityID)
                .SetAttribute("FacFacilityName", Me.HCFADetailUpdated.ServiceFacility.FacilityName)
                .SetAttribute("FacNPI", Me.HCFADetailUpdated.ServiceFacility.NPI)
                .SetAttribute("FacAddressLine1", Me.HCFADetailUpdated.ServiceFacility.AddressLine1)
                .SetAttribute("FacAddressLine2", Me.HCFADetailUpdated.ServiceFacility.AddressLine2)
                .SetAttribute("FacCity", Me.HCFADetailUpdated.ServiceFacility.City)
                .SetAttribute("FacState", Me.HCFADetailUpdated.ServiceFacility.State)
                .SetAttribute("FacPhone", Me.HCFADetailUpdated.ServiceFacility.Phone)
                .SetAttribute("FacFax", Me.HCFADetailUpdated.ServiceFacility.Fax)
                .SetAttribute("FacZipCode", Me.HCFADetailUpdated.ServiceFacility.ZipCode)
                .SetAttribute("FacIsDelete", "N")
                .SetAttribute("FacFacilityCode", Me.HCFADetailUpdated.ServiceFacility.FacilityCode)



                .SetAttribute("RPEmployeeID", Me.HCFADetailUpdated.RenderingProvider.EmployeeID)
                .SetAttribute("RPClinicCode", Me.HCFADetailUpdated.RenderingProvider.ClinicCode)
                .SetAttribute("RPDesignation", Me.HCFADetailUpdated.RenderingProvider.Designation)
                .SetAttribute("RPLoginID", Me.HCFADetailUpdated.RenderingProvider.LoginID)
                .SetAttribute("RPPassword", Me.HCFADetailUpdated.RenderingProvider.Password)
                .SetAttribute("RPTitle", Me.HCFADetailUpdated.RenderingProvider.Title)
                .SetAttribute("RPFirstName", Me.HCFADetailUpdated.RenderingProvider.FirstName)
                .SetAttribute("RPMiddleName", Me.HCFADetailUpdated.RenderingProvider.MiddleName)
                .SetAttribute("RPLastName", Me.HCFADetailUpdated.RenderingProvider.LastName)
                .SetAttribute("RPGender", Me.HCFADetailUpdated.RenderingProvider.Gender)
                .SetAttribute("RPDOB", Me.HCFADetailUpdated.RenderingProvider.DOB)
                .SetAttribute("RPSSN", Me.HCFADetailUpdated.RenderingProvider.SSN)
                .SetAttribute("RPAddressLine1", Me.HCFADetailUpdated.RenderingProvider.AddressLine1)
                .SetAttribute("RPAddressLine2", Me.HCFADetailUpdated.RenderingProvider.AddressLine2)
                .SetAttribute("RPCity", Me.HCFADetailUpdated.RenderingProvider.City)
                .SetAttribute("RPStateId", Me.HCFADetailUpdated.RenderingProvider.StateId)
                .SetAttribute("RPZipCode", Me.HCFADetailUpdated.RenderingProvider.ZipCode)
                .SetAttribute("RPHomePhone", Me.HCFADetailUpdated.RenderingProvider.HomePhone)
                .SetAttribute("RPWorkPhone", Me.HCFADetailUpdated.RenderingProvider.WorkPhone)
                .SetAttribute("RPWorkPhoneExtension", Me.HCFADetailUpdated.RenderingProvider.WorkPhoneExtension)
                .SetAttribute("RPFax", Me.HCFADetailUpdated.RenderingProvider.Fax)
                .SetAttribute("RPEmail", Me.HCFADetailUpdated.RenderingProvider.Email)
                .SetAttribute("RPLoginStatus", Me.HCFADetailUpdated.RenderingProvider.LoginStatus)
                .SetAttribute("RPSPI", Me.HCFADetailUpdated.RenderingProvider.SPI)
                .SetAttribute("RPDEA", Me.HCFADetailUpdated.RenderingProvider.DEA)
                .SetAttribute("RPLicence", Me.HCFADetailUpdated.RenderingProvider.Licence)
                .SetAttribute("RPServiceLevel", Me.HCFADetailUpdated.RenderingProvider.ServiceLevel)
                .SetAttribute("RPStartDate", Me.HCFADetailUpdated.RenderingProvider.StartDate)
                .SetAttribute("RPEndDate", Me.HCFADetailUpdated.RenderingProvider.EndDate)
                .SetAttribute("RPSigPath", Me.HCFADetailUpdated.RenderingProvider.SigPath)
                .SetAttribute("RPIsDeleted", Me.HCFADetailUpdated.RenderingProvider.IsDeleted)
                .SetAttribute("RPTheme", Me.HCFADetailUpdated.RenderingProvider.Theme)
                .SetAttribute("RPScreeningEnabled", Me.HCFADetailUpdated.RenderingProvider.ScreeningEnabled)
                .SetAttribute("RPNPI", Me.HCFADetailUpdated.RenderingProvider.NPI)
                .SetAttribute("RPTaxID", Me.HCFADetailUpdated.RenderingProvider.TaxID)
                .SetAttribute("RPStateLicenseID", Me.HCFADetailUpdated.RenderingProvider.StateLicenseID)
                .SetAttribute("RPDEA2", Me.HCFADetailUpdated.RenderingProvider.DEA2)
                .SetAttribute("RPSpecialityCode", Me.HCFADetailUpdated.RenderingProvider.SpecialityCode)
                'If Not  Me.HCFADetailUpdated.RenderingProvider.DEA.Equals("RP") Then
                .SetAttribute("RPSetup_ID", lSetupID)
                'End If
                .SetAttribute("RPIsPrintRx", Me.HCFADetailUpdated.RenderingProvider.IsPrintRx)
                .SetAttribute("RPDegree", Me.HCFADetailUpdated.RenderingProvider.Degree)

                .SetAttribute("RPIsActive", Me.HCFADetailUpdated.RenderingProvider.IsActive)
                .SetAttribute("RPIsLocked", Me.HCFADetailUpdated.RenderingProvider.IsLocked)
                .SetAttribute("RPIsReseted", Me.HCFADetailUpdated.RenderingProvider.IsReseted)
                .SetAttribute("RPIsSuperAdmin", Me.HCFADetailUpdated.RenderingProvider.IsSuperAdmin)

                'If Not  Me.HCFADetailUpdated.RenderingProvider.LoginCount.Equals("RP") Then
                .SetAttribute("RPLoginCount", Me.HCFADetailUpdated.RenderingProvider.LoginCount)
                'Else

                .SetAttribute("RPCptNo", Me.HCFADetailUpdated.RenderingProvider.CptNo)
                .SetAttribute("RPDEASuffix", Me.HCFADetailUpdated.RenderingProvider.DEASuffix)

                .SetAttribute("RenderingPvdSecIdQualifier", Me.HCFADetailUpdated.RenderingPvdSecIdQualifier)
                .SetAttribute("RenderingPvdSecId", Me.HCFADetailUpdated.RenderingPvdSecId)




            End With

            lXmlDocument.DocumentElement.AppendChild(lXmlElement.CloneNode(True))
        Next



        If Connection.IsTransactionAlive() Then
            InsertRecord = Connection.ExecuteTransactionScalarCommand("InsertHCFADetailUpdated", lXmlDocument.InnerXml.ToString)
        Else
            InsertRecord = Connection.ExecuteScalarCommand("InsertHCFADetailUpdated", lXmlDocument.InnerXml.ToString)
        End If

    End Function

    Public Sub DeleteRecord(ByVal pCondition As String)
        Dim lSpParameter(1) As SpParameter

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "HCFADetailUpdated"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = pCondition

        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand("DeleteRecords", lSpParameter)
        Else
            Connection.ExecuteCommand("DeleteRecords", lSpParameter)
        End If
    End Sub
    Public Sub DeleteRecordByID()
        Dim lCondition As String

        lCondition = "And HCFAID = " & Me.HCFADetailUpdated.HCFAID
        DeleteRecord(lCondition)

    End Sub

    Public Function UpdateHCFADetailUpdated(ByVal pHCFADetailDBUpdatedColl As HCFADetailCollUpdated) As Boolean

        Dim lQuery2 As String = ""

        For Each Record As HCFADetailDBUpdated In pHCFADetailDBUpdatedColl
            lQuery2 = "UPDATE [HCFADetailUpdated]SET [DignosisPointer] ='" & Record.DignosisPointer & _
                  "', [FacFacilityCode] ='" & Record.ServiceFacility.FacilityCode & _
                   "',[RPNPI] ='" & Record.RenderingProvider.NPI & _
                   "' where CPTCode='" & Record.CPTCode & "' and HcfaId='" & Record.HCFAID & "'"
            If Connection.IsTransactionAlive() Then
                Connection.ExecuteTransactionCommand(lQuery2)

            Else
                Connection.ExecuteCommand(lQuery2)

            End If
        Next
      

        
        Return True




    End Function
#End Region

End Class


Public Class HCFADetailCollUpdated
    Inherits CollectionBase
    Public Function Add(ByVal pHCFADetailUpdated As HCFADetailDBUpdated) As Integer
        'Me.InnerList.Insert(Me.Count, pHCFADetail)
        Me.List.Add(pHCFADetailUpdated)
    End Function
    Public Sub Remove(ByVal pHCFADetailUpdated As HCFADetailDBUpdated)
        Dim lIndex As Integer

        lIndex = IndexOf(pHCFADetailUpdated)

        If lIndex > -1 Then
            List.RemoveAt(lIndex)
        End If

    End Sub
    Default Public Property Item(ByVal Index As Integer) As HCFADetailDBUpdated
        Get
            If (Index < List.Count) Then
                Return CType(List.Item(Index), HCFADetailDBUpdated)
            Else
                Return (Nothing)
            End If
        End Get
        Set(ByVal Value As HCFADetailDBUpdated)
            List.Item(Index) = Value
        End Set
    End Property

    Public Shadows Function Count() As Integer
        Return List.Count
    End Function

    Public Function IndexOf(ByVal obj As Object) As Integer
        Dim lIndex As Integer = 0
        Dim lFound As Integer = 0

        For Each lObj As Object In List
            lFound = CType(lObj, HCFADetailDBUpdated).CPTCode.CompareTo(CType(obj, HCFADetailDBUpdated).CPTCode)
            If lFound = 0 Then
                Return lIndex
            End If
            lIndex += 1
        Next
        Return -1

    End Function

End Class
