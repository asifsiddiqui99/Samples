Imports Microsoft.VisualBasic
Public Class AdjustmentScreenDB

#Region "Fields"

    Private mVisitID As Integer = 0
    Private mCPTCode As String = ""
    Private mAdjustmentDescription As String = ""
    Private mReasonCode As String = ""

    Private mAdjustmentType As String = String.Empty
    Private mAmount As Double = 0
    Private mUserID As Integer = 0
    Private mPaymentDtlID As Integer = 0
    Private mPaymentID As Integer = 0



#End Region



#Region "Properties"
    Public Property VisitID() As Integer
        Get
            Return mVisitID
        End Get
        Set(ByVal value As Integer)
            mVisitID = value
        End Set
    End Property

    Public Property PaymentID() As Integer
        Get
            Return mPaymentID
        End Get
        Set(ByVal value As Integer)
            mPaymentID = value
        End Set
    End Property

    Public Property CPTCode() As String
        Get
            Return mCPTCode
        End Get
        Set(ByVal value As String)
            mCPTCode = value
        End Set
    End Property

    Public Property AdjustmentDescription() As String
        Get
            Return mAdjustmentDescription
        End Get
        Set(ByVal value As String)
            mAdjustmentDescription = value
        End Set
    End Property

    Public Property ReasonCode() As String
        Get
            Return mReasonCode
        End Get
        Set(ByVal value As String)
            mReasonCode = value
        End Set
    End Property

    Public Property AdjustmentType() As String
        Get
            Return mAdjustmentType
        End Get
        Set(ByVal value As String)
            mAdjustmentType = value
        End Set
    End Property
    Public Property Amount() As Double
        Get
            Return mAmount
        End Get
        Set(ByVal value As Double)
            mAmount = value
        End Set
    End Property
    Public Property UserID() As Integer
        Get
            Return mUserID
        End Get
        Set(ByVal value As Integer)
            mUserID = value
        End Set
    End Property
    Public Property PaymentDtlID() As Integer
        Get
            Return mPaymentDtlID
        End Get
        Set(ByVal value As Integer)
            mPaymentDtlID = value
        End Set
    End Property
#End Region


End Class
Public Class AdjustmentScreen

#Region "Fields"
    Private mConnection As Connection
    Private mConnectionString As String

#End Region

#Region "Property"

    Public ReadOnly Property Connection() As ElixirLibrary.Connection
        Get
            Return mConnection
        End Get
    End Property
    Public ReadOnly Property ConnectionString() As String
        Get
            Return mConnectionString
        End Get
    End Property
#End Region
#Region "Constructor"
    Public Sub New(ByVal pConnectionString As String)
        If pConnectionString = "" Then
            Throw New ArgumentException("ConnectionString can not be empty")
        End If
        mConnectionString = pConnectionString
        mConnection = New Connection(mConnectionString)

    End Sub
    Public Sub New(ByVal pConnection As Connection)
        If pConnection Is Nothing Then
            Throw New ArgumentException("Connection can not be empty")
        End If
        mConnection = pConnection
    End Sub
#End Region
    Public Function GetTypeCode() As DataSet
        Dim lQuery As String
        Dim lDs As New DataSet()
        Try
            lQuery = "select AdjustmentTypeID,DrCrAdjustment,[Description]+ '-' + [Type]+'-'+ DrCrAdjustment as AdjustmentType from AdjustmentType"
            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If
            Return lDs
        Catch ex As Exception
            Return lDs
        End Try
    End Function
    Public Function GetAdjReasonCode() As DataSet
        Dim lQuery As String
        Dim lDs As New DataSet()
        Try
            lQuery = "Select * from AdjustmentReason"
            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If
            Return lDs
        Catch ex As Exception
            Return lDs
        End Try
    End Function
    Public Function GetListRecord() As DataSet
        Dim lQuery As String
        Dim lDs As New DataSet()
        Try
            lQuery = "select * from adjustment"
            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If
            Return lDs
        Catch ex As Exception
            Return lDs
        End Try
    End Function

    Public Function InsertListRecord(ByVal pAdjustmentScreenDB As AdjustmentScreenDB)
        Dim lQuery As String
        Dim lDs As New DataSet()
        Try
            lQuery = "insert into Adjustment (AdjustmentDate,VisitID,CPTCode,AdjustmentDescription,ReasonCode,AdjustmentType,Amount,UserID,PaymentDtlID,PaymentID)values('" & System.DateTime.Today & "'," & pAdjustmentScreenDB.VisitID & ",'" & pAdjustmentScreenDB.CPTCode & "','" & pAdjustmentScreenDB.AdjustmentDescription & "','" & pAdjustmentScreenDB.ReasonCode & "','" & pAdjustmentScreenDB.AdjustmentType & "'," & pAdjustmentScreenDB.Amount & "," & pAdjustmentScreenDB.UserID & "," & pAdjustmentScreenDB.PaymentDtlID & "," & pAdjustmentScreenDB.PaymentID & ")"
            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If
            Return lDs
        Catch ex As Exception
            Return lDs
        End Try
    End Function

    Public Function GetAdjustmentByVisitID(ByVal pCondition As String) As DataSet
        Dim lQuery As String
        Dim lDs As New DataSet()
        Try

            
            lQuery = "select AdjustmentDescription,AdjustmentType,ReasonCode,Amount,IsPrevious='Yes',Notes from Adjustment where 1=1 " & pCondition

            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If
            Return lDs
        Catch ex As Exception
            Return lDs
        End Try
    End Function
End Class
