Imports Microsoft.VisualBasic

Public Class PatientCPTDB

#Region "Fields"

    Private mLineId As String
    Private mPatientSuperBillId As String
    Private mHeading As String
    Private mCode As String
    Private mDescription As String
    Private mFees As String
    Private mIsGridItem As String
    Private mIsSelected As String
    Private mCPTDate As String
    Private mPOS As String
    Private mModifierA As String
    Private mModifierB As String
    Private mModifierC As String
    Private mModifierD As String
    Private mPointer As String
    Private mCharges As String
    Private mDays As String
    Private mLineNumber As String

    Private mHCFAID As String
    Private mDateOfServiceTo As String = ""
    Private mDateOfServiceFrom As String = ""
    Private mNPI As String = ""
    Private mEPSDT As String
    Private mEMG As String
    Private mPrescriberLicenceID As String = ""
    Private mCOB As String = ""

    Private mIMOCode As String = String.Empty

    Private mFacilityId As String = ""
    Private mProviderId As String = ""
    Private mProviderSecIdQualifier As String = ""
    Private mProviderSecId As String = ""

    Private mIsDeleted As String = "N"
#End Region

#Region "Properties"
    Public Property IsDeleted() As String
        Get
            Return mIsDeleted
        End Get
        Set(ByVal value As String)
            mIsDeleted = value
        End Set
    End Property

    Public Property IMOCode() As String
        Get
            Return mIMOCode
        End Get
        Set(ByVal value As String)
            mIMOCode = value
        End Set
    End Property

    Public Property COB() As String
        Get
            Return mCOB
        End Get
        Set(ByVal value As String)
            mCOB = value
        End Set
    End Property

    Public Property PrescriberLicenceID() As String
        Get
            Return mPrescriberLicenceID
        End Get
        Set(ByVal value As String)
            mPrescriberLicenceID = value
        End Set
    End Property

    Public Property EMG() As String
        Get
            Return mEMG
        End Get
        Set(ByVal value As String)
            mEMG = value
        End Set
    End Property

    Public Property EPSDT() As String
        Get
            Return mEPSDT
        End Get
        Set(ByVal value As String)
            mEPSDT = value
        End Set
    End Property

    Public Property HCFAID() As String
        Get
            Return mHCFAID
        End Get
        Set(ByVal value As String)
            mHCFAID = value
        End Set
    End Property

    Public Property LineId() As String
        Get
            Return mLineId
        End Get
        Set(ByVal value As String)
            mLineId = value
        End Set
    End Property

    Public Property PatientSuperBillId() As String
        Get
            Return mPatientSuperBillId
        End Get
        Set(ByVal value As String)
            mPatientSuperBillId = value
        End Set
    End Property

    Public Property Heading() As String
        Get
            Return mHeading
        End Get
        Set(ByVal value As String)
            mHeading = value
        End Set
    End Property

    Public Property Code() As String
        Get
            Return mCode
        End Get
        Set(ByVal value As String)
            mCode = value
        End Set
    End Property

    Public Property Description() As String
        Get
            Return mDescription
        End Get
        Set(ByVal value As String)
            mDescription = value
        End Set
    End Property

    Public Property Fees() As String
        Get
            Return mFees
        End Get
        Set(ByVal value As String)
            mFees = value
        End Set
    End Property

    Public Property IsGridItem() As String
        Get
            Return mIsGridItem
        End Get
        Set(ByVal value As String)
            mIsGridItem = value
        End Set
    End Property

    Public Property IsSelected() As String
        Get
            Return mIsSelected
        End Get
        Set(ByVal value As String)
            mIsSelected = value
        End Set
    End Property

    Public Property CPTDate() As String
        Get
            Return mCPTDate
        End Get
        Set(ByVal value As String)
            mCPTDate = value
        End Set
    End Property

    Public Property POS() As String
        Get
            Return mPOS
        End Get
        Set(ByVal value As String)
            mPOS = value
        End Set
    End Property

    Public Property ModifierA() As String
        Get
            Return mModifierA
        End Get
        Set(ByVal value As String)
            mModifierA = value
        End Set
    End Property

    Public Property ModifierB() As String
        Get
            Return mModifierB
        End Get
        Set(ByVal value As String)
            mModifierB = value
        End Set
    End Property

    Public Property ModifierC() As String
        Get
            Return mModifierC
        End Get
        Set(ByVal value As String)
            mModifierC = value
        End Set
    End Property

    Public Property ModifierD() As String
        Get
            Return mModifierD
        End Get
        Set(ByVal value As String)
            mModifierD = value
        End Set
    End Property

    Public Property Pointer() As String
        Get
            Return mPointer
        End Get
        Set(ByVal value As String)
            mPointer = value
        End Set
    End Property

    Public Property Charges() As String
        Get
            Return mCharges
        End Get
        Set(ByVal value As String)
            mCharges = value
        End Set
    End Property

    Public Property Days() As String
        Get
            Return mDays
        End Get
        Set(ByVal value As String)
            mDays = value
        End Set
    End Property

    Public Property LineNumber() As String
        Get
            Return mLineNumber
        End Get
        Set(ByVal value As String)
            mLineNumber = value
        End Set
    End Property

    Public Property DateOfServiceTo() As String
        Get
            Return mDateOfServiceTo
        End Get
        Set(ByVal value As String)
            mDateOfServiceTo = value
        End Set
    End Property

    Public Property DateOfServiceFrom() As String
        Get
            Return mDateOfServiceFrom
        End Get
        Set(ByVal value As String)
            mDateOfServiceFrom = value
        End Set
    End Property

    Public Property NPI() As String
        Get
            Return mNPI
        End Get
        Set(ByVal value As String)
            mNPI = value
        End Set
    End Property

    Public Property FacilityId() As String
        Get
            Return mFacilityId
        End Get
        Set(ByVal value As String)
            mFacilityId = value
        End Set
    End Property

    Public Property ProviderId() As String
        Get
            Return mProviderId
        End Get
        Set(ByVal value As String)
            mProviderId = value
        End Set
    End Property

    Public Property ProviderSecIdQualifier() As String
        Get
            Return mProviderSecIdQualifier
        End Get
        Set(ByVal value As String)
            mProviderSecIdQualifier = value
        End Set
    End Property

    Public Property ProviderSecId() As String
        Get
            Return mProviderSecId
        End Get
        Set(ByVal value As String)
            mProviderSecId = value
        End Set
    End Property

#End Region
End Class

Public Class PatientCPT
#Region "Fields"
    Private mConnection As Connection
    Private mConnectionString
    Private mPatientCPT As New PatientCPTDB
#End Region

#Region "Property"
    Public ReadOnly Property Connection() As ElixirLibrary.Connection
        Get
            Return mConnection
        End Get
    End Property

    Public ReadOnly Property ConnectionString() As String
        Get
            Return mConnectionString
        End Get
    End Property
    Public Property PatientCPT() As PatientCPTDB
        Get
            Return mPatientCPT
        End Get
        Set(ByVal value As PatientCPTDB)
            mPatientCPT = value
        End Set
    End Property
#End Region

#Region "Constructor"
    ''' <summary>
    ''' Creates new Conection Object based on Given Connection String 
    ''' </summary>
    ''' <param name="pConnectionString">
    ''' Contains Connection String 
    ''' </param>
    ''' <remarks>
    ''' Use when not using transaction
    ''' Must Specify Connection String other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnectionString As String)
        If pConnectionString = "" Then
            Throw New ArgumentException("ConnectionString can not be empty")
        End If

        mConnectionString = pConnectionString
        mConnection = New Connection(mConnectionString)

    End Sub

    ''' <summary>
    ''' Assign given connection to the current Object
    ''' </summary>
    ''' <param name="pConnection">
    ''' Contains refrence to the connection object
    ''' </param>
    ''' <remarks>
    ''' Use when  using Transaction
    ''' Must Specify Connection other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnection As Connection)
        If pConnection Is Nothing Then
            Throw New ArgumentException("Connection can not be empty")
        End If

        mConnection = pConnection
    End Sub
#End Region

#Region "Method"
    ''' <summary>
    ''' Delete Record Acoording to Given Condition
    ''' </summary>
    ''' <param name="lCondition"></param>
    ''' <remarks></remarks>
    Public Sub DeleteRecord(ByVal lCondition As String)

        Dim lSpParameter(1) As SpParameter

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "PatientCPT"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = lCondition

        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand("DeleteRecords", lSpParameter)
        Else
            Connection.ExecuteCommand("DeleteRecords", lSpParameter)
        End If

    End Sub
    ''' <summary>
    ''' Delete Record on Primary Key
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub DeleteRecordByID()
        Dim lCondition As String

        lCondition = "AND PatientSuperBillId= " & PatientCPT.PatientSuperBillId
        DeleteRecord(lCondition)

    End Sub
    ''' <summary>
    ''' Get All Records unconditional
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetAllRecords(ByVal lTable As String) As System.Data.DataSet
        Dim lCondition As String = ""
        Dim lDs As New DataSet()

        lDs = GetAllRecords(lCondition, lTable)

        Return lDs
    End Function
    ''' <summary>
    ''' Get  Records on specified Condition
    ''' </summary>
    ''' <param name="lCondition"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    ''' 
    Public Function GetAllRecords(ByVal lCondition As String, ByVal lTable As String) As System.Data.DataSet
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = lTable

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = lCondition

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("SelectAllRecords", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
        End If

        Return lDs

    End Function
    ''' <summary>
    ''' Insert record
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub InsertRecord()
        Dim lXmlDocument As New XmlDocument
        Dim lXmlElement As XmlElement

        lXmlDocument.LoadXml("<PatientCPTies></PatientCPTies>")
        lXmlElement = lXmlDocument.CreateElement("PatientCPT")


        With lXmlElement
            .SetAttribute("PatientSuperBillId", PatientCPT.PatientSuperBillId)
            .SetAttribute("Heading", PatientCPT.Heading)
            .SetAttribute("Code", PatientCPT.Code)
            .SetAttribute("Description", PatientCPT.Description)
            .SetAttribute("Fees", PatientCPT.Fees)
            .SetAttribute("IsGridItem", PatientCPT.IsGridItem)
            .SetAttribute("IsSelected", PatientCPT.IsSelected)
            .SetAttribute("CPTDate", PatientCPT.CPTDate)
            .SetAttribute("POS", PatientCPT.POS)
            .SetAttribute("ModifierA", PatientCPT.ModifierA)
            .SetAttribute("ModifierB", PatientCPT.ModifierB)
            .SetAttribute("ModifierC", PatientCPT.ModifierC)
            .SetAttribute("ModifierD", PatientCPT.ModifierD)
            .SetAttribute("Pointer", PatientCPT.Pointer)
            .SetAttribute("Charges", PatientCPT.Charges)
            .SetAttribute("Days", PatientCPT.Days)
            .SetAttribute("LineNumber", PatientCPT.LineNumber)
            .SetAttribute("HCFAID", PatientCPT.HCFAID)
            .SetAttribute("DateOfServiceTo", PatientCPT.DateOfServiceTo)
            .SetAttribute("DateOfServiceFrom", PatientCPT.DateOfServiceFrom)
            .SetAttribute("NPI", PatientCPT.NPI)
            .SetAttribute("COB", PatientCPT.COB)
            .SetAttribute("EPSDT", PatientCPT.EPSDT)
            .SetAttribute("PrescriberLicenceID", PatientCPT.PrescriberLicenceID)
            .SetAttribute("Emergency", PatientCPT.EMG)
            .SetAttribute("IMOCode", PatientCPT.IMOCode)

            .SetAttribute("FacilityId", PatientCPT.FacilityId)
            .SetAttribute("ProviderId", PatientCPT.ProviderId)
            .SetAttribute("ProviderSecIdQualifier", PatientCPT.ProviderSecIdQualifier)
            .SetAttribute("ProviderSecId", PatientCPT.ProviderSecId)

            .SetAttribute("IsDeleted", PatientCPT.IsDeleted)
        End With

        lXmlDocument.DocumentElement.AppendChild(lXmlElement.CloneNode(True))

        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand("InsertPatientCPT", lXmlDocument.InnerXml.ToString)
        Else
            Connection.ExecuteCommand("InsertPatientCPT", lXmlDocument.InnerXml.ToString)
        End If

    End Sub
    ''' <summary>
    ''' Update Record unconditional
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub UpdateRecord()
        Dim lCondition As String

        lCondition = "And PatientSuperBillID = " & Me.PatientCPT.PatientSuperBillId
        UpdateRecord(lCondition)

    End Sub
    Public Sub UpdateRecord(ByVal lCondition As String)

        Dim lQuery As String

        With Me.PatientCPT

            'lQuery = "Update PatientCPT Set  " _
            '            & "HCFAID =" & .HCFAID & ", " _
            '            & "Heading ='" & .Heading & "', " _
            '            & "Code ='" & .Code & "', " _
            '            & "Description ='" & .Description & "', " _
            '            & "Fees =" & .Fees & ", " _
            '            & "IsGridItem ='" & .IsGridItem & "', " _
            '            & "IsSelected ='" & .IsSelected & "', " _
            '            & "CPTDate ='" & .CPTDate & "', " _
            '            & "POS =" & .POS & ", " _
            '            & "ModifierA ='" & .ModifierA & "', " _
            '            & "ModifierB ='" & .ModifierB & "', " _
            '            & "ModifierC ='" & .ModifierC & "', " _
            '            & "ModifierD ='" & .ModifierD & "', " _
            '            & "NPI ='" & .NPI & "', " _
            '            & "Pointer =" & .Pointer & ", " _
            '            & "Charges =" & .Charges & ", " _
            '            & "Days =" & .Days & ", " _
            '            & "LineNumber =" & .LineNumber & " " _
            '            & "Where 1 = 1 " _
            '            & lCondition



            lQuery = "Update PatientCPT Set  " _
                       & "HCFAID =" & .HCFAID.ToString & ", " _
                       & "DateOfServiceTo ='" & .DateOfServiceFrom & "', " _
                       & "DateOfServiceFrom ='" & .DateOfServiceTo & "', " _
                       & "POS =" & .POS.ToString & ", " _
                       & "ModifierA ='" & .ModifierA.ToString & "', " _
                       & "ModifierB ='" & .ModifierB.ToString & "', " _
                       & "ModifierC ='" & .ModifierC.ToString & "', " _
                       & "ModifierD ='" & .ModifierD.ToString & "', " _
                       & "EPSDT ='" & .EPSDT.ToString & "', " _
                       & "Emergency ='" & .EMG.ToString & "', " _
                       & "NPI ='" & .NPI.ToString & "', " _
                       & "PrescriberLicenceID ='" & .PrescriberLicenceID.ToString & "', " _
                       & "COB ='" & .COB.ToString & "', " _
                       & "FacilityId='" & .FacilityId.ToString & "', " _
                       & "ProviderId='" & .ProviderId.ToString & "', " _
                       & "ProviderSecIdQualifier='" & .ProviderSecIdQualifier.ToString & "', " _
                       & "ProviderSecId='" & .ProviderSecId.ToString & "', " _
                       & "IsDeleted='" & .IsDeleted.ToString & "' " _
                       & IIf(.Pointer.ToString.Equals(""), "", ", Pointer =" & .Pointer.ToString) _
                       & IIf(.Charges.ToString.Equals(""), "", ", Charges =" & .Charges.ToString) _
                       & IIf(.Days.ToString.Equals(""), "", ", Days =" & .Days.ToString & " ") _
                       & "Where 1 = 1 And Code= '" & .Code & "' " _
                       & lCondition


        End With

        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand(lQuery)
        Else
            Connection.ExecuteCommand(lQuery)
        End If
    End Sub
    ''' <summary>
    ''' Get Single Record By Primary Key
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetRecordByID(ByVal lTable As String) As Boolean
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = lTable

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = "And LineID = " & PatientCPT.LineId

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("SelectAllRecords", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
        End If


        With lDs.Tables(0)
            If .Rows.Count > 0 Then

                Me.PatientCPT.LineId = .Rows(0)("LineId")
                Me.PatientCPT.PatientSuperBillId = .Rows(0)("PatientSuperBillId")
                Me.PatientCPT.Heading = .Rows(0)("Heading")
                Me.PatientCPT.Code = .Rows(0)("Code")
                Me.PatientCPT.Description = .Rows(0)("Description")
                Me.PatientCPT.Fees = .Rows(0)("Fees")
                Me.PatientCPT.IsGridItem = .Rows(0)("IsGridItem")
                Me.PatientCPT.IsSelected = .Rows(0)("IsSelected")
                Me.PatientCPT.CPTDate = .Rows(0)("CPTDate")
                Me.PatientCPT.POS = .Rows(0)("POS")
                Me.PatientCPT.ModifierA = .Rows(0)("ModifierA")
                Me.PatientCPT.ModifierB = .Rows(0)("ModifierB")
                Me.PatientCPT.ModifierC = .Rows(0)("ModifierC")
                Me.PatientCPT.ModifierD = .Rows(0)("ModifierD")
                Me.PatientCPT.Pointer = .Rows(0)("Pointer")
                Me.PatientCPT.Charges = .Rows(0)("Charges")
                Me.PatientCPT.Days = .Rows(0)("Days")
                Me.PatientCPT.LineId = .Rows(0)("LineNumber")
                Me.PatientCPT.NPI = .Rows(0)("NPI")
                Me.PatientCPT.PrescriberLicenceID = .Rows(0)("PrescriberLicenceID")
                Me.PatientCPT.EMG = .Rows(0)("Emergency")
                Me.PatientCPT.EPSDT = .Rows(0)("EPSDT")
                Me.PatientCPT.COB = .Rows(0)("COB")

                Me.PatientCPT.FacilityId = .Rows(0)("FacilityId")
                Me.PatientCPT.ProviderId = .Rows(0)("ProviderId")
                Me.PatientCPT.ProviderSecIdQualifier = .Rows(0)("ProviderSecIdQualifier")
                Me.PatientCPT.ProviderSecId = .Rows(0)("ProviderSecId")

                Me.PatientCPT.IsDeleted = .Rows(0)("IsDeleted")

                Return True
            End If
        End With

        Return False

    End Function
    Public Function GetPatientCPTCollection(ByVal pCondition As String) As PatientCPTColl
        Dim lCond As String
        Dim lDs As DataSet
        Dim lPatientCPT As PatientCPTDB
        Dim lPatientCPTColl As New PatientCPTColl()

        lCond = " And PatientSuperBillId =" & Me.PatientCPT.PatientSuperBillId & " " & pCondition & "Order by LineNumber"
        lDs = GetAllRecords(lCond, "PatientCPT")

        If lDs.Tables(0).Rows.Count > 0 Then

            For Each lRow As DataRow In lDs.Tables(0).Rows
                lPatientCPT = New PatientCPTDB()

                lPatientCPT.LineId = lRow("LineId")
                lPatientCPT.PatientSuperBillId = lRow("PatientSuperBillId")
                lPatientCPT.Heading = lRow("Heading")
                lPatientCPT.Code = lRow("Code")
                lPatientCPT.Description = lRow("Description")
                lPatientCPT.Fees = lRow("Fees")
                lPatientCPT.IsGridItem = lRow("IsGridItem")
                lPatientCPT.IsSelected = lRow("IsSelected")
                lPatientCPT.CPTDate = lRow("CPTDate")
                lPatientCPT.POS = lRow("POS")
                lPatientCPT.ModifierA = lRow("ModifierA")
                lPatientCPT.ModifierB = lRow("ModifierB")
                lPatientCPT.ModifierC = lRow("ModifierC")
                lPatientCPT.ModifierD = lRow("ModifierD")
                lPatientCPT.Pointer = lRow("Pointer")
                lPatientCPT.Charges = lRow("Charges")
                lPatientCPT.Days = lRow("Days")
                lPatientCPT.LineNumber = lRow("LineNumber")
                lPatientCPT.NPI = lRow("NPI")
                lPatientCPT.PrescriberLicenceID = lRow("PrescriberLicenceID")
                lPatientCPT.EMG = lRow("Emergency")
                lPatientCPT.EPSDT = lRow("EPSDT")
                lPatientCPT.COB = lRow("COB")

                Me.PatientCPT.FacilityId = lRow("FacilityId")
                Me.PatientCPT.ProviderId = lRow("ProviderId")
                Me.PatientCPT.ProviderSecIdQualifier = lRow("ProviderSecIdQualifier")
                Me.PatientCPT.ProviderSecId = lRow("ProviderSecId")

                Me.PatientCPT.IsDeleted = lRow("IsDeleted")

                lPatientCPTColl.Add(lPatientCPT)
            Next
        End If

        Return lPatientCPTColl
    End Function
    Public Function GenerateClaim(ByVal pPatientSuperBillId As String) As Boolean

        Dim lQuery As String = ""


        Try

            lQuery = "update PatientCPT " _
            & " set HCFAID = ((LineNumber - 1) / 6) + 1 " _
            & "where PatientSuperBillId = " & pPatientSuperBillId


            If Connection.IsTransactionAlive() Then
                Connection.ExecuteTransactionCommand(lQuery)
            Else
                Connection.ExecuteCommand(lQuery)
            End If


        Catch ex As Exception
            Return False
        End Try
    End Function
    Public Sub UpdateRecordForPatientCPT(ByVal pSuperBillID As String, ByVal pHCFAID As String)

        Dim lQuery As String


        lQuery = "Update PatientCPT Set  " _
                    & "HCFAID =" & pHCFAID & " " _
                    & " Where PatientSuperBillID = " & pSuperBillID

        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand(lQuery)
        Else
            Connection.ExecuteCommand(lQuery)
        End If
    End Sub

    Public Sub UpdatePatCptColFromHcfaCptCol(ByVal pHcfaCptCol As HCFADetailCollUpdated)
        Dim lQuery As String
        Dim lHcfaDtl As HCFADetailDBUpdated
        Dim lCondition As String

        lCondition = "And PatientSuperBillID = " & Me.PatientCPT.PatientSuperBillId

        If (pHcfaCptCol Is Nothing Or pHcfaCptCol.Count = 0) Then
            Throw New Exception("No CPT(s) to Update")
        End If

        For Each lHcfaDtl In pHcfaCptCol

            With lHcfaDtl

                lQuery = "Update PatientCPT Set  " _
                           & "POS ='" & .ServiceFacility.FacilityCode & "', " _
                           & "EPSDT ='" & .EPSDT.ToString & "', " _
                           & "Emergency ='" & .Emergency & "', " _
                           & "NPI ='" & .RenderingProvider.NPI & "', " _
                           & "COB ='" & .COB.ToString & "', " _
                           & "FacilityId='" & .ServiceFacility.FacilityID & "', " _
                           & "ProviderSecIdQualifier='" & .RenderingPvdSecIdQualifier & "', " _
                           & "ProviderSecId='" & .RenderingPvdSecId & "', " _
                           & "Pointer ='" & .DignosisPointer.ToString & "'" _
                           & "Where 1 = 1 And LineId= '" & .LineId & "' " _
                           & lCondition
            End With

            If Connection.IsTransactionAlive() Then
                Connection.ExecuteTransactionCommand(lQuery)
            Else
                Connection.ExecuteCommand(lQuery)
            End If
        Next

    End Sub

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="pXmlContent"></param>
    ''' <remarks>Author: Affan Toor | 07-11-12</remarks>
    Public Sub InsertPatientCPT(ByVal pXmlContent As String)
        Try
            If Connection.IsTransactionAlive() Then
                Connection.ExecuteTransactionCommand("InsertPatientCPTForEncounter", pXmlContent)
            Else
                Connection.ExecuteCommand("InsertPatientCPTForEncounter", pXmlContent)
            End If

        Catch ex As Exception
            Throw New Exception(ex.Message + ": DAl/PatientCPT.InsertPatientCPT()")

        End Try
    End Sub
#End Region
End Class


Public Class PatientCPTColl
    Inherits CollectionBase

    Public Function Add(ByVal pPatientCPT As PatientCPTDB) As Integer
        Return List.Add(pPatientCPT)
    End Function

    Public Sub Remove(ByVal pPatientCPT As PatientCPTDB)
        Dim lIndex As Integer

        lIndex = IndexOf(pPatientCPT)

        If lIndex > -1 Then
            List.RemoveAt(lIndex)
        End If

    End Sub

    Default Public Property Item(ByVal Index As Integer) As PatientCPTDB
        Get
            Return CType(List.Item(Index), PatientCPTDB)
        End Get
        Set(ByVal Value As PatientCPTDB)
            List.Item(Index) = Value
        End Set
    End Property

    Public Shadows Function Count() As Integer
        Return List.Count
    End Function

    Public Function IndexOf(ByVal obj As Object) As Integer
        Dim lIndex As Integer = 0
        Dim lFound As Integer = 0

        For Each lObj As Object In List
            lFound = CType(lObj, PatientCPTDB).Code.CompareTo(CType(obj, PatientCPTDB).Code)
            If lFound = 0 Then
                Return lIndex
            End If
            lIndex += 1
        Next
        Return -1

    End Function

   

End Class