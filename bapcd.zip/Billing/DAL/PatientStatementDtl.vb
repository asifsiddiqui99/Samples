Imports Microsoft.VisualBasic
Public Class PatientStatementDtlDB
#Region "Fields"
    Private mStatementBatchID As Integer = 0
    Private mStatementId As Integer = 0
    Private mPatientID As Integer = 0
    Private mStatementDate As Date = Date.Now
    Private mPlaceOfService As String = ""
    Private mBillToLastName As String = ""
    Private mBillToMiddleName As String = ""
    Private mBillToFirstName As String = ""
    Private mPatientLastName As String = ""
    Private mPatientMiddleName As String = ""
    Private mPatienFirstName As String = ""
    Private mPatientAddressLine1 As String = ""
    Private mPatientAddressLine2 As String = ""
    Private mPatientCity As String = ""
    Private mPatientState As String = ""
    Private mPatientZip As String = ""
    Private mGuarantorLastName As String = ""
    Private mGuarantorMiddleName As String = ""
    Private mGuarantorFirstName As String = ""
    Private mGuarantorAddressLine1 As String = ""
    Private mGuarantorAddressLine2 As String = ""
    Private mGuarantorCity As String = ""
    Private mGuarantorState As String = ""
    Private mGuarantorZip As String = ""
    Private mReferringProviderLastName As String = ""
    Private mReferringProviderMiddleName As String = ""
    Private mReferringProviderFirstName As String = ""
    Private mMessage As String = ""
    Private mTotalAmount As Double = 0.0
    Private mInsurancePending As Double = 0.0
    Private mTotalDue As Double = 0.0
    Private mCurrent As Double = 0.0
    Private mDays30 As Double = 0.0
    Private mDays60 As Double = 0.0
    Private mDays90 As Double = 0.0
    Private mClinicName As String = ""
    Private mClinicAddressLine1 As String = ""
    Private mClinicAddressLine2 As String = ""
    Private mClinicCity As String = ""
    Private mClinicState As String = ""
    Private mClinicZip As String = ""
    Private mClinicPhone As String = ""
    Private mPatientStatementDetailDb2 As PatientStatementDtlDB()
#End Region
#Region "Properties"

    Public Property StatementBatchID() As Integer
        Get
            Return mStatementBatchID
        End Get
        Set(ByVal value As Integer)
            mStatementBatchID = value
        End Set
    End Property
    Public Property StatementId() As Integer
        Get
            Return mStatementId
        End Get
        Set(ByVal value As Integer)
            mStatementId = value
        End Set
    End Property
    Public Property PatientID() As Integer
        Get
            Return mPatientID
        End Get
        Set(ByVal value As Integer)
            mPatientID = value
        End Set
    End Property
    Public Property StatementDate() As Date
        Get
            Return mStatementDate
        End Get
        Set(ByVal value As Date)
            mStatementDate = value
        End Set
    End Property
    Public Property PlaceOfService() As String
        Get
            Return mPlaceOfService
        End Get
        Set(ByVal value As String)
            mPlaceOfService = value
        End Set
    End Property
    Public Property BillToLastName() As String
        Get
            Return mBillToLastName
        End Get
        Set(ByVal value As String)
            mBillToLastName = value
        End Set
    End Property
    Public Property BillToMiddleName() As String
        Get
            Return mBillToMiddleName
        End Get
        Set(ByVal value As String)
            mBillToMiddleName = value
        End Set
    End Property
    Public Property BillToFirstName() As String
        Get
            Return mBillToFirstName
        End Get
        Set(ByVal value As String)
            mBillToFirstName = value
        End Set
    End Property
    Public Property PatientLastName() As String
        Get
            Return mPatientLastName
        End Get
        Set(ByVal value As String)
            mPatientLastName = value
        End Set
    End Property
    Public Property PatientMiddleName() As String
        Get
            Return mPatientMiddleName
        End Get
        Set(ByVal value As String)
            mPatientMiddleName = value
        End Set
    End Property
    Public Property PatienFirstName() As String
        Get
            Return mPatienFirstName
        End Get
        Set(ByVal value As String)
            mPatienFirstName = value
        End Set
    End Property
    Public Property PatientAddressLine1() As String
        Get
            Return mPatientAddressLine1
        End Get
        Set(ByVal value As String)
            mPatientAddressLine1 = value
        End Set
    End Property
    Public Property PatientAddressLine2() As String
        Get
            Return mPatientAddressLine2
        End Get
        Set(ByVal value As String)
            mPatientAddressLine2 = value
        End Set
    End Property
    Public Property PatientCity() As String
        Get
            Return mPatientCity
        End Get
        Set(ByVal value As String)
            mPatientCity = value
        End Set
    End Property
    Public Property PatientState() As String
        Get
            Return mPatientState
        End Get
        Set(ByVal value As String)
            mPatientState = value
        End Set
    End Property
    Public Property PatientZip() As String
        Get
            Return mPatientZip
        End Get
        Set(ByVal value As String)
            mPatientZip = value
        End Set
    End Property
    Public Property GuarantorLastName() As String
        Get
            Return mGuarantorLastName
        End Get
        Set(ByVal value As String)
            mGuarantorLastName = value
        End Set
    End Property
    Public Property GuarantorMiddleName() As String
        Get
            Return mGuarantorMiddleName
        End Get
        Set(ByVal value As String)
            mGuarantorMiddleName = value
        End Set
    End Property
    Public Property GuarantorFirstName() As String
        Get
            Return mGuarantorFirstName
        End Get
        Set(ByVal value As String)
            mGuarantorFirstName = value
        End Set
    End Property
    Public Property GuarantorAddressLine1() As String
        Get
            Return mGuarantorAddressLine1
        End Get
        Set(ByVal value As String)
            mGuarantorAddressLine1 = value
        End Set
    End Property
    Public Property GuarantorAddressLine2() As String
        Get
            Return mGuarantorAddressLine2
        End Get
        Set(ByVal value As String)
            mGuarantorAddressLine2 = value
        End Set
    End Property
    Public Property GuarantorCity() As String
        Get
            Return mGuarantorCity
        End Get
        Set(ByVal value As String)
            mGuarantorCity = value
        End Set
    End Property
    Public Property GuarantorState() As String
        Get
            Return mGuarantorState
        End Get
        Set(ByVal value As String)
            mGuarantorState = value
        End Set
    End Property
    Public Property GuarantorZip() As String
        Get
            Return mGuarantorZip
        End Get
        Set(ByVal value As String)
            mGuarantorZip = value
        End Set
    End Property
    Public Property ReferringProviderLastName() As String
        Get
            Return mReferringProviderLastName
        End Get
        Set(ByVal value As String)
            mReferringProviderLastName = value
        End Set
    End Property
    Public Property ReferringProviderMiddleName() As String
        Get
            Return mReferringProviderMiddleName
        End Get
        Set(ByVal value As String)
            mReferringProviderMiddleName = value
        End Set
    End Property
    Public Property ReferringProviderFirstName() As String
        Get
            Return mReferringProviderFirstName
        End Get
        Set(ByVal value As String)
            mReferringProviderFirstName = value
        End Set
    End Property
    Public Property Message() As String
        Get
            Return mMessage
        End Get
        Set(ByVal value As String)
            mMessage = value
        End Set
    End Property
    Public Property TotalAmount() As Double
        Get
            Return mTotalAmount
        End Get
        Set(ByVal value As Double)
            mTotalAmount = value
        End Set
    End Property
    Public Property InsurancePending() As Double
        Get
            Return mInsurancePending
        End Get
        Set(ByVal value As Double)
            mInsurancePending = value
        End Set
    End Property
    Public Property TotalDue() As Double
        Get
            Return mTotalDue
        End Get
        Set(ByVal value As Double)
            mTotalDue = value
        End Set
    End Property
    Public Property Current() As Double
        Get
            Return mCurrent
        End Get
        Set(ByVal value As Double)
            mCurrent = value
        End Set
    End Property
    Public Property Days30() As Double
        Get
            Return mDays30
        End Get
        Set(ByVal value As Double)
            mDays30 = value
        End Set
    End Property
    Public Property Days60() As Double
        Get
            Return mDays60
        End Get
        Set(ByVal value As Double)
            mDays60 = value
        End Set
    End Property
    Public Property Days90() As Double
        Get
            Return mDays90
        End Get
        Set(ByVal value As Double)
            mDays90 = value
        End Set
    End Property
    Public Property ClinicName() As String
        Get
            Return mClinicName
        End Get
        Set(ByVal value As String)
            mClinicName = value
        End Set
    End Property
    Public Property ClinicAddressLine1() As String
        Get
            Return mClinicAddressLine1
        End Get
        Set(ByVal value As String)
            mClinicAddressLine1 = value
        End Set
    End Property
    Public Property ClinicAddressLine2() As String
        Get
            Return mClinicAddressLine2
        End Get
        Set(ByVal value As String)
            mClinicAddressLine2 = value
        End Set
    End Property
    Public Property ClinicCity() As String
        Get
            Return mClinicCity
        End Get
        Set(ByVal value As String)
            mClinicCity = value
        End Set
    End Property
    Public Property ClinicState() As String
        Get
            Return mClinicState
        End Get
        Set(ByVal value As String)
            mClinicState = value
        End Set
    End Property
    Public Property ClinicZip() As String
        Get
            Return mClinicZip
        End Get
        Set(ByVal value As String)
            mClinicZip = value
        End Set
    End Property
    Public Property ClinicPhone() As String
        Get
            Return mClinicPhone
        End Get
        Set(ByVal value As String)
            mClinicPhone = value
        End Set
    End Property
#End Region
End Class

Public Class PatientStatementDtl
#Region "Fields"
    Private mConnection As Connection
    Private mConnectionString
    Private mPatientStatementDtlDB As New PatientStatementDtlDB
#End Region
#Region "Property"
    Public ReadOnly Property Connection() As ElixirLibrary.Connection
        Get
            Return mConnection
        End Get
    End Property
    Public ReadOnly Property ConnectionString() As String
        Get
            Return mConnectionString
        End Get
    End Property
    Public Property PatientStatementDtlDB() As PatientStatementDtlDB
        Get
            Return mPatientStatementDtlDB
        End Get
        Set(ByVal value As PatientStatementDtlDB)
            mPatientStatementDtlDB = value
        End Set
    End Property
#End Region
#Region "Constructor"
    Public Sub New(ByVal pConnectionString As String)
        If pConnectionString = "" Then
            Throw New ArgumentException("ConnectionString can not be empty")
        End If
        mConnectionString = pConnectionString
        mConnection = New Connection(mConnectionString)
    End Sub
    Public Sub New(ByVal pConnection As Connection)
        If pConnection Is Nothing Then
            Throw New ArgumentException("Connection can not be empty")
        End If
        mConnection = pConnection
    End Sub
#End Region
#Region "Methods"
    Public Function InsertPatientStatementDtl() As Integer
        Try
            Dim lQuery As String
            Dim lResult As New DataSet

            Dim lCondition As String = ""

            Dim lXmlDocument As New XmlDocument
            Dim lXmlElement As XmlElement

            lXmlDocument.LoadXml("<PatientStatementDtls></PatientStatementDtls>")
            lXmlElement = lXmlDocument.CreateElement("PatientStatementDtl")
            With lXmlElement
                .SetAttribute("StatementBatchID", PatientStatementDtlDB.StatementBatchID)
                .SetAttribute("StatementId", PatientStatementDtlDB.StatementId)
                .SetAttribute("StatementDate", PatientStatementDtlDB.StatementDate)
                .SetAttribute("PlaceOfService", PatientStatementDtlDB.PlaceOfService)
                .SetAttribute("PatientID", PatientStatementDtlDB.PatientID)
                .SetAttribute("BillToLastName", PatientStatementDtlDB.BillToLastName)
                .SetAttribute("BillToMiddleName", PatientStatementDtlDB.BillToMiddleName)
                .SetAttribute("BillToFirstName", PatientStatementDtlDB.BillToFirstName)
                .SetAttribute("PatientLastName", PatientStatementDtlDB.PatientLastName)
                .SetAttribute("PatientMiddleName", PatientStatementDtlDB.PatientMiddleName)
                .SetAttribute("PatienFirstName", PatientStatementDtlDB.PatienFirstName)
                .SetAttribute("PatientAddressLine1", PatientStatementDtlDB.PatientAddressLine1)
                .SetAttribute("PatientAddressLine2", PatientStatementDtlDB.PatientAddressLine2)
                .SetAttribute("PatientCity", PatientStatementDtlDB.PatientCity)
                .SetAttribute("PatientState", PatientStatementDtlDB.PatientState)
                .SetAttribute("PatientZip", PatientStatementDtlDB.PatientZip)
                .SetAttribute("GuarantorLastName", PatientStatementDtlDB.GuarantorLastName)
                .SetAttribute("GuarantorMiddleName", PatientStatementDtlDB.GuarantorMiddleName)
                .SetAttribute("GuarantorFirstName", PatientStatementDtlDB.GuarantorFirstName)
                .SetAttribute("GuarantorAddressLine1", PatientStatementDtlDB.GuarantorAddressLine1)
                .SetAttribute("GuarantorAddressLine2", PatientStatementDtlDB.GuarantorAddressLine2)
                .SetAttribute("GuarantorCity", PatientStatementDtlDB.GuarantorCity)
                .SetAttribute("GuarantorState", PatientStatementDtlDB.GuarantorState)
                .SetAttribute("GuarantorZip", PatientStatementDtlDB.GuarantorZip)
                .SetAttribute("ReferringProviderLastName", PatientStatementDtlDB.ReferringProviderLastName)
                .SetAttribute("ReferringProviderMiddleName", PatientStatementDtlDB.ReferringProviderMiddleName)
                .SetAttribute("ReferringProviderFirstName", PatientStatementDtlDB.ReferringProviderFirstName)
                .SetAttribute("Message", PatientStatementDtlDB.Message)
                .SetAttribute("TotalAmount", PatientStatementDtlDB.TotalAmount)
                .SetAttribute("InsurancePending", PatientStatementDtlDB.InsurancePending)
                .SetAttribute("TotalDue", PatientStatementDtlDB.TotalDue)
                .SetAttribute("Current", PatientStatementDtlDB.Current)
                .SetAttribute("Days30", PatientStatementDtlDB.Days30)
                .SetAttribute("Days60", PatientStatementDtlDB.Days60)
                .SetAttribute("Days90", PatientStatementDtlDB.Days90)
                .SetAttribute("ClinicName", PatientStatementDtlDB.ClinicName)
                .SetAttribute("ClinicAddressLine1", PatientStatementDtlDB.ClinicAddressLine1)
                .SetAttribute("ClinicAddressLine2", PatientStatementDtlDB.ClinicAddressLine2)
                .SetAttribute("ClinicCity", PatientStatementDtlDB.ClinicCity)
                .SetAttribute("ClinicState", PatientStatementDtlDB.ClinicState)
                .SetAttribute("ClinicZip", PatientStatementDtlDB.ClinicZip)
                .SetAttribute("ClinicPhone", PatientStatementDtlDB.ClinicPhone)
            End With
            lXmlDocument.DocumentElement.AppendChild(lXmlElement.CloneNode(True))
            

            If Connection.IsTransactionAlive() Then
                Connection.ExecuteTransactionCommand("InsertPatientStatementDtl", lXmlDocument.InnerXml.ToString)
            Else
                Connection.ExecuteCommand("InsertPatientStatementDtl", lXmlDocument.DocumentElement.OuterXml.ToString)
            End If



            lQuery = "Select Max(StatementID) as StatementID from PatientStatementDtl"



            If Connection.IsTransactionAlive() Then
                lResult = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lResult = Connection.ExecuteQuery(lQuery)
            End If

            Return lResult.Tables(0).Rows(0).Item(0).ToString





        Catch ex As Exception
            Return Nothing
        End Try
    End Function
    Public Function SearchRecords(ByVal pDateFrom As Date, ByVal pDateTo As Date) As DataSet

        Dim lQuery As String
        Dim lResult As New DataSet
        Dim lCondition As String = ""

        Try

            If (PatientStatementDtlDB.PatientLastName <> "") Then
                lCondition = lCondition & " (PatientLastName + ', ' + PatienFirstName) like '" & PatientStatementDtlDB.PatientLastName & "%' and "
            End If
            If (PatientStatementDtlDB.GuarantorLastName <> "") Then
                lCondition = lCondition & " GuarantorLastName like '" & PatientStatementDtlDB.GuarantorLastName & "%' and "
            End If
            If (PatientStatementDtlDB.PatientID.ToString <> "" AndAlso PatientStatementDtlDB.PatientID.ToString <> "0") Then
                lCondition = lCondition & " PatientID = '" & PatientStatementDtlDB.PatientID & "' and "
            End If

            lQuery = "SELECT StatementBatchID,StatementId,StatementDate,PatientLastName + ', ' + PatienFirstName as PatientName," & _
            "case when Len(GuarantorLastName + ', ' + GuarantorFirstName) = 1  then 'Self' else " & _
            "GuarantorLastName + ', ' + GuarantorFirstName " & _
            "End as GuarantorName,TotalDue FROM PatientStatementDtl where " & lCondition & "" & _
           " StatementDate between '" & pDateFrom.Date & "' and '" & pDateTo.Date & "' order by StatementDate desc ,PatientLastName asc"

            lResult = Connection.ExecuteQuery(lQuery)

            Return lResult

        Catch ex As Exception
            Return Nothing
        End Try

    End Function

    Public Function GetAllRecords(ByVal pStatementBatchID As Integer) As DataSet

        Dim lQuery As String
        Dim lResult As New DataSet
        Dim lCondition As String = ""

        Try


            lQuery = "Select * from PatientStatementDtl where StatementBatchID=" & pStatementBatchID

            lResult = Connection.ExecuteQuery(lQuery)

            Return lResult

        Catch ex As Exception
            Return Nothing
        End Try

    End Function
#End Region
End Class
