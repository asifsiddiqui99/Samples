Imports Microsoft.VisualBasic

Public Class HCFADB

#Region "Fields"
    Private mHCFAID As String = ""
    Private mHCFADisplayID As String = "1"
    Private mPatientSuperBillID As String = ""
    Private mType1 As String = ""
    Private mType2 As String = ""
    Private mInsuredIDNumber As String = ""
    Private mGroupNumber As String = ""
    Private mPatientName As String = ""
    Private mPatientDOB As String = ""
    Private mPatientGender As String = ""
    Private mInsuredName As String = ""
    Private mPatientAddress As String = ""
    Private mPatientCity As String = ""
    Private mPatientZipCode As String = ""
    Private mPatientState As String = ""
    Private mPatientTelephone As String = ""
    Private mPatientRelationshipToInsured As String = ""
    Private mInsuredAddress As String = ""
    Private mInsuredCity As String = ""
    Private mInsuredState As String = ""
    Private mInsuredZipCode As String = ""
    Private mInsuredTelephone As String = ""
    Private mPatientMaritalStatus As String = ""
    Private mPatientEmploymentInfo As String = ""
    Private mOtherInsuredName As String = ""
    Private mOtherInsuredPolicy As String = ""
    Private mOtherInsuredDOB As String = ""
    Private mOtherInsuredGender As String = ""
    Private mOtherInsuredEmployer As String = ""
    Private mSecondaryInsurancePlan As String = ""
    Private mIsEmploymentRelated As String = ""
    Private mIsAutoAccidentRelated As String = ""
    Private mIsOtherAccidentRelated As String = ""
    Private mReservedBlock10D As String = ""
    Private mAnotherInsuredPolicy As String = ""
    Private mAnotherInsuredDOB As String = ""
    Private mAnotherInsuredGender As String = ""
    Private mAnotherInsuredEmployerName As String = ""
    Private mAnotherInsuredInsurancePlan As String = ""
    Private mIsAnotherPlan As String = ""
    Private mReleaseInfoSignature As String = ""
    Private mReleaseInfoDate As String = ""
    Private mPaymentSignature As String = ""
    Private mDateOfOccurance As String = ""
    Private mPreviousOccuranceDate As String = ""
    Private mUnableToWorkFrom As String = ""
    Private mUnableToWorkTo As String = ""
    Private mRefferingProviderName As String = ""
    Private mRefferingProviderID As String = ""
    Private mRefferingProviderNPI As String = ""
    Private mHospitalizationDateFrom As String = ""
    Private mHospitalizationDateTo As String = ""
    Private mReservedBlock19 As String = ""
    Private mIsOutsideLab As String = ""
    Private mOutsideLabCharges As Double = 0.0
    Private mICD1 As String = ""
    Private mICD2 As String = ""
    Private mICD3 As String = ""
    Private mICD4 As String = ""
    Private mMedicaidCode As String = ""
    Private mOriginalRefrenceNumber As String = ""
    Private mPriorAuthorizationNumber As String = ""
    Private mFederalTaxID As String = ""
    Private mIsSSN As String = ""
    Private mPatientAccountNumber As String = ""
    Private mIsAcceptAssignment As String = ""
    Private mTotalCharge As Double = 0.0
    Private mAmountPaid As Double = 0.0
    Private mBalanceDue As Double = 0.0
    Private mProviderName As String = ""
    Private mHCFAPreparedDate As String = ""
    Private mFacilityId As String = ""
    Private mFacilityName As String = ""
    Private mFacilityAddress As String = ""
    Private mFacilityProvider As String = ""
    Private mFacilityCode As String = "" 'Added for 32(b) '
    Private mClinicName As String = ""
    Private mClinicAddress As String = ""
    Private mClinicCity As String = ""
    Private mClinicState As String = ""
    Private mClinicZip As String = ""
    Private mClinicPhoneNumber As String = ""
    Private mClinicPinNumber As String = ""
    Private mClinicGroupNumber As String = ""
    Private mDoctorUserID As String = ""
    Private mCreateByUserID As String = ""
    Private mInsuranceNameHdr As String = ""
    Private mInsuranceAddressHdr As String = ""
    Private mPrimaryInsuranceAddress1 As String = ""
    Private mPrimaryInsuranceAddress2 As String = ""
    Private mPrimaryInsuranceCity As String = ""
    Private mPrimaryInsuranceState As String = ""
    Private mPrimaryInsuranceZipCode As String = ""
    Private mFacilitySecondaryIdentificationQualifier As String = ""
    Private mClinicSecondaryIdentificationQualifier As String = ""
    Private mInsuranceAddressLine1 As String = ""
    Private mInsuranceAddressLine2 As String = ""
    Private mRefferingProviderIDQualifier As String = ""
    Private mIsSend As String = "N"
    Private mFacilityCity As String = ""
    Private mFacilityState As String = ""
    Private mFacilityZipCode As String = ""
    Private mHCFAType As String = "P"
    Private mMainInsID As String = "0"
    Private mOtherInsID As String = "0"

#End Region

#Region "Properties"
    Public Property HCFAID() As String
        Get
            Return mHCFAID
        End Get
        Set(ByVal value As String)
            mHCFAID = value
        End Set
    End Property
    Public Property HCFADisplayID() As String
        Get
            Return mHCFADisplayID
        End Get
        Set(ByVal value As String)
            mHCFADisplayID = value
        End Set
    End Property

    Public Property PatientSuperBillID() As String
        Get
            Return mPatientSuperBillID
        End Get
        Set(ByVal value As String)
            mPatientSuperBillID = value
        End Set
    End Property
    Public Property Type1() As String
        Get
            Return mType1
        End Get
        Set(ByVal value As String)
            mType1 = value
        End Set
    End Property
    Public Property Type2() As String
        Get
            Return mType2
        End Get
        Set(ByVal value As String)
            mType2 = value
        End Set
    End Property
    Public Property InsuredIDNumber() As String
        Get
            Return mInsuredIDNumber
        End Get
        Set(ByVal value As String)
            mInsuredIDNumber = value
        End Set
    End Property
    Public Property GroupNumber() As String
        Get
            Return mGroupNumber
        End Get
        Set(ByVal value As String)
            mGroupNumber = value
        End Set
    End Property
    Public Property PatientName() As String
        Get
            Return mPatientName
        End Get
        Set(ByVal value As String)
            mPatientName = value
        End Set
    End Property
    Public Property PatientDOB() As String
        Get
            Return mPatientDOB
        End Get
        Set(ByVal value As String)
            mPatientDOB = value
        End Set
    End Property
    Public Property PatientGender() As String
        Get
            Return mPatientGender
        End Get
        Set(ByVal value As String)
            mPatientGender = value
        End Set
    End Property
    Public Property InsuredName() As String
        Get
            Return mInsuredName
        End Get
        Set(ByVal value As String)
            mInsuredName = value
        End Set
    End Property
    Public Property PatientAddress() As String
        Get
            Return mPatientAddress
        End Get
        Set(ByVal value As String)
            mPatientAddress = value
        End Set
    End Property
    Public Property PatientCity() As String
        Get
            Return mPatientCity
        End Get
        Set(ByVal value As String)
            mPatientCity = value
        End Set
    End Property
    Public Property PatientZipCode() As String
        Get
            Return mPatientZipCode
        End Get
        Set(ByVal value As String)
            mPatientZipCode = value
        End Set
    End Property
    Public Property PatientState() As String
        Get
            Return mPatientState
        End Get
        Set(ByVal value As String)
            mPatientState = value
        End Set
    End Property
    Public Property PatientTelephone() As String
        Get
            Return mPatientTelephone
        End Get
        Set(ByVal value As String)
            mPatientTelephone = value
        End Set
    End Property
    Public Property PatientRelationshipToInsured() As String
        Get
            Return mPatientRelationshipToInsured
        End Get
        Set(ByVal value As String)
            mPatientRelationshipToInsured = value
        End Set
    End Property
    Public Property InsuredAddress() As String
        Get
            Return mInsuredAddress
        End Get
        Set(ByVal value As String)
            mInsuredAddress = value
        End Set
    End Property
    Public Property InsuredCity() As String
        Get
            Return mInsuredCity
        End Get
        Set(ByVal value As String)
            mInsuredCity = value
        End Set
    End Property
    Public Property InsuredState() As String
        Get
            Return mInsuredState
        End Get
        Set(ByVal value As String)
            mInsuredState = value
        End Set
    End Property
    Public Property InsuredZipCode() As String
        Get
            Return mInsuredZipCode
        End Get
        Set(ByVal value As String)
            mInsuredZipCode = value
        End Set
    End Property
    Public Property InsuredTelephone() As String
        Get
            Return mInsuredTelephone
        End Get
        Set(ByVal value As String)
            mInsuredTelephone = value
        End Set
    End Property
    Public Property PatientMaritalStatus() As String
        Get
            Return mPatientMaritalStatus
        End Get
        Set(ByVal value As String)
            mPatientMaritalStatus = value
        End Set
    End Property
    Public Property PatientEmploymentInfo() As String
        Get
            Return mPatientEmploymentInfo
        End Get
        Set(ByVal value As String)
            mPatientEmploymentInfo = value
        End Set
    End Property
    Public Property OtherInsuredName() As String
        Get
            Return mOtherInsuredName
        End Get
        Set(ByVal value As String)
            mOtherInsuredName = value
        End Set
    End Property
    Public Property OtherInsuredPolicy() As String
        Get
            Return mOtherInsuredPolicy
        End Get
        Set(ByVal value As String)
            mOtherInsuredPolicy = value
        End Set
    End Property
    Public Property OtherInsuredDOB() As String
        Get
            Return mOtherInsuredDOB
        End Get
        Set(ByVal value As String)
            mOtherInsuredDOB = value
        End Set
    End Property
    Public Property OtherInsuredGender() As String
        Get
            Return mOtherInsuredGender
        End Get
        Set(ByVal value As String)
            mOtherInsuredGender = value
        End Set
    End Property
    Public Property OtherInsuredEmployer() As String
        Get
            Return mOtherInsuredEmployer
        End Get
        Set(ByVal value As String)
            mOtherInsuredEmployer = value
        End Set
    End Property
    Public Property SecondaryInsurancePlan() As String
        Get
            Return mSecondaryInsurancePlan
        End Get
        Set(ByVal value As String)
            mSecondaryInsurancePlan = value
        End Set
    End Property
    Public Property IsEmploymentRelated() As String
        Get
            Return mIsEmploymentRelated
        End Get
        Set(ByVal value As String)
            mIsEmploymentRelated = value
        End Set
    End Property
    Public Property IsAutoAccidentRelated() As String
        Get
            Return mIsAutoAccidentRelated
        End Get
        Set(ByVal value As String)
            mIsAutoAccidentRelated = value
        End Set
    End Property
    Public Property IsOtherAccidentRelated() As String
        Get
            Return mIsOtherAccidentRelated
        End Get
        Set(ByVal value As String)
            mIsOtherAccidentRelated = value
        End Set
    End Property
    Public Property ReservedBlock10D() As String
        Get
            Return mReservedBlock10D
        End Get
        Set(ByVal value As String)
            mReservedBlock10D = value
        End Set
    End Property
    Public Property AnotherInsuredPolicy() As String
        Get
            Return mAnotherInsuredPolicy
        End Get
        Set(ByVal value As String)
            mAnotherInsuredPolicy = value
        End Set
    End Property
    Public Property AnotherInsuredDOB() As String
        Get
            Return mAnotherInsuredDOB
        End Get
        Set(ByVal value As String)
            mAnotherInsuredDOB = value
        End Set
    End Property
    Public Property AnotherInsuredGender() As String
        Get
            Return mAnotherInsuredGender
        End Get
        Set(ByVal value As String)
            mAnotherInsuredGender = value
        End Set
    End Property
    Public Property AnotherInsuredEmployerName() As String
        Get
            Return mAnotherInsuredEmployerName
        End Get
        Set(ByVal value As String)
            mAnotherInsuredEmployerName = value
        End Set
    End Property
    Public Property AnotherInsuredInsurancePlan() As String
        Get
            Return mAnotherInsuredInsurancePlan
        End Get
        Set(ByVal value As String)
            mAnotherInsuredInsurancePlan = value
        End Set
    End Property
    Public Property IsAnotherPlan() As String
        Get
            Return mIsAnotherPlan
        End Get
        Set(ByVal value As String)
            mIsAnotherPlan = value
        End Set
    End Property
    Public Property ReleaseInfoSignature() As String
        Get
            Return mReleaseInfoSignature
        End Get
        Set(ByVal value As String)
            mReleaseInfoSignature = value
        End Set
    End Property
    Public Property ReleaseInfoDate() As String
        Get
            Return mReleaseInfoDate
        End Get
        Set(ByVal value As String)
            mReleaseInfoDate = value
        End Set
    End Property
    Public Property PaymentSignature() As String
        Get
            Return mPaymentSignature
        End Get
        Set(ByVal value As String)
            mPaymentSignature = value
        End Set
    End Property
    Public Property DateOfOccurance() As String
        Get
            Return mDateOfOccurance
        End Get
        Set(ByVal value As String)
            mDateOfOccurance = value
        End Set
    End Property
    Public Property PreviousOccuranceDate() As String
        Get
            Return mPreviousOccuranceDate
        End Get
        Set(ByVal value As String)
            mPreviousOccuranceDate = value
        End Set
    End Property
    Public Property UnableToWorkFrom() As String
        Get
            Return mUnableToWorkFrom
        End Get
        Set(ByVal value As String)
            mUnableToWorkFrom = value
        End Set
    End Property
    Public Property UnableToWorkTo() As String
        Get
            Return mUnableToWorkTo
        End Get
        Set(ByVal value As String)
            mUnableToWorkTo = value
        End Set
    End Property
    Public Property RefferingProviderName() As String
        Get
            Return mRefferingProviderName
        End Get
        Set(ByVal value As String)
            mRefferingProviderName = value
        End Set
    End Property
    Public Property RefferingProviderID() As String
        Get
            Return mRefferingProviderID
        End Get
        Set(ByVal value As String)
            mRefferingProviderID = value
        End Set
    End Property
    Public Property RefferingProviderNPI() As String
        Get
            Return mRefferingProviderNPI
        End Get
        Set(ByVal value As String)
            mRefferingProviderNPI = value
        End Set
    End Property
    Public Property HospitalizationDateFrom() As String
        Get
            Return mHospitalizationDateFrom
        End Get
        Set(ByVal value As String)
            mHospitalizationDateFrom = value
        End Set
    End Property
    Public Property ReservedBlock19() As String
        Get
            Return mReservedBlock19
        End Get
        Set(ByVal value As String)
            mReservedBlock19 = value
        End Set
    End Property
    Public Property HospitalizationDateTo() As String
        Get
            Return mHospitalizationDateTo
        End Get
        Set(ByVal value As String)
            mHospitalizationDateTo = value
        End Set
    End Property
    Public Property IsOutsideLab() As String
        Get
            Return mIsOutsideLab
        End Get
        Set(ByVal value As String)
            mIsOutsideLab = value
        End Set
    End Property
    Public Property OutsideLabCharges() As Double
        Get
            Return mOutsideLabCharges
        End Get
        Set(ByVal value As Double)
            mOutsideLabCharges = value
        End Set
    End Property
    Public Property ICD1() As String
        Get
            Return mICD1
        End Get
        Set(ByVal value As String)
            mICD1 = value
        End Set
    End Property
    Public Property ICD2() As String
        Get
            Return mICD2
        End Get
        Set(ByVal value As String)
            mICD2 = value
        End Set
    End Property
    Public Property ICD3() As String
        Get
            Return mICD3
        End Get
        Set(ByVal value As String)
            mICD3 = value
        End Set
    End Property
    Public Property ICD4() As String
        Get
            Return mICD4
        End Get
        Set(ByVal value As String)
            mICD4 = value
        End Set
    End Property
    Public Property MedicaidCode() As String
        Get
            Return mMedicaidCode
        End Get
        Set(ByVal value As String)
            mMedicaidCode = value
        End Set
    End Property
    Public Property OriginalRefrenceNumber() As String
        Get
            Return mOriginalRefrenceNumber
        End Get
        Set(ByVal value As String)
            mOriginalRefrenceNumber = value
        End Set
    End Property
    Public Property PriorAuthorizationNumber() As String
        Get
            Return mPriorAuthorizationNumber
        End Get
        Set(ByVal value As String)
            mPriorAuthorizationNumber = value
        End Set
    End Property
    Public Property FederalTaxID() As String
        Get
            Return mFederalTaxID
        End Get
        Set(ByVal value As String)
            mFederalTaxID = value
        End Set
    End Property
    Public Property IsSSN() As String
        Get
            Return mIsSSN
        End Get
        Set(ByVal value As String)
            mIsSSN = value
        End Set
    End Property
    Public Property PatientAccountNumber() As String
        Get
            Return mPatientAccountNumber
        End Get
        Set(ByVal value As String)
            mPatientAccountNumber = value
        End Set
    End Property
    Public Property IsAcceptAssignment() As String
        Get
            Return mIsAcceptAssignment
        End Get
        Set(ByVal value As String)
            mIsAcceptAssignment = value
        End Set
    End Property
    Public Property TotalCharge() As Double
        Get
            Return mTotalCharge
        End Get
        Set(ByVal value As Double)
            mTotalCharge = value
        End Set
    End Property
    Public Property AmountPaid() As Double
        Get
            Return mAmountPaid
        End Get
        Set(ByVal value As Double)
            mAmountPaid = value
        End Set
    End Property
    Public Property BalanceDue() As Double
        Get
            Return mBalanceDue
        End Get
        Set(ByVal value As Double)
            mBalanceDue = value
        End Set
    End Property
    Public Property ProviderName() As String
        Get
            Return mProviderName
        End Get
        Set(ByVal value As String)
            mProviderName = value
        End Set
    End Property
    Public Property HCFAPreparedDate() As String
        Get
            Return mHCFAPreparedDate
        End Get
        Set(ByVal value As String)
            mHCFAPreparedDate = value
        End Set
    End Property
    Public Property FacilityId() As String
        Get
            Return mFacilityId
        End Get
        Set(ByVal value As String)
            mFacilityId = value
        End Set
    End Property
    Public Property FacilityName() As String
        Get
            Return mFacilityName
        End Get
        Set(ByVal value As String)
            mFacilityName = value
        End Set
    End Property
    Public Property FacilityAddress() As String
        Get
            Return mFacilityAddress
        End Get
        Set(ByVal value As String)
            mFacilityAddress = value
        End Set
    End Property
    Public Property FacilityProvider() As String
        Get
            Return mFacilityProvider
        End Get
        Set(ByVal value As String)
            mFacilityProvider = value
        End Set
    End Property
    Public Property FacilityCode() As String
        Get
            Return mFacilityCode
        End Get
        Set(ByVal value As String)
            mFacilityCode = value
        End Set
    End Property
    Public Property ClinicName() As String
        Get
            Return mClinicName
        End Get
        Set(ByVal value As String)
            mClinicName = value
        End Set
    End Property
    Public Property ClinicAddress() As String
        Get
            Return mClinicAddress
        End Get
        Set(ByVal value As String)
            mClinicAddress = value
        End Set
    End Property
    Public Property ClinicCity() As String
        Get
            Return mClinicCity
        End Get
        Set(ByVal value As String)
            mClinicCity = value
        End Set
    End Property
    Public Property ClinicState() As String
        Get
            Return mClinicState
        End Get
        Set(ByVal value As String)
            mClinicState = value
        End Set
    End Property
    Public Property ClinicZip() As String
        Get
            Return mClinicZip
        End Get
        Set(ByVal value As String)
            mClinicZip = value
        End Set
    End Property
    Public Property ClinicPhoneNumber() As String
        Get
            Return mClinicPhoneNumber
        End Get
        Set(ByVal value As String)
            mClinicPhoneNumber = value
        End Set
    End Property
    Public Property ClinicPinNumber() As String
        Get
            Return mClinicPinNumber
        End Get
        Set(ByVal value As String)
            mClinicPinNumber = value
        End Set
    End Property
    Public Property ClinicGroupNumber() As String
        Get
            Return mClinicGroupNumber
        End Get
        Set(ByVal value As String)
            mClinicGroupNumber = value
        End Set
    End Property
    Public Property DoctorUserID() As String
        Get
            Return mDoctorUserID
        End Get
        Set(ByVal value As String)
            mDoctorUserID = value
        End Set
    End Property
    Public Property CreateByUserID() As String
        Get
            Return mCreateByUserID
        End Get
        Set(ByVal value As String)
            mCreateByUserID = value
        End Set
    End Property
    Public Property InsuranceNameHdr() As String
        Get
            Return mInsuranceNameHdr
        End Get
        Set(ByVal value As String)
            mInsuranceNameHdr = value
        End Set
    End Property
    Public Property InsuranceAddressHdr() As String
        Get
            Return mInsuranceAddressHdr
        End Get
        Set(ByVal value As String)
            mInsuranceAddressHdr = value
        End Set
    End Property



    Public Property PrimaryInsuranceZipCode() As String
        Get
            Return mPrimaryInsuranceZipCode
        End Get
        Set(ByVal value As String)
            mPrimaryInsuranceZipCode = value
        End Set
    End Property


    Public Property PrimaryInsuranceState() As String
        Get
            Return mPrimaryInsuranceState
        End Get
        Set(ByVal value As String)
            mPrimaryInsuranceState = value
        End Set
    End Property


    Public Property PrimaryInsuranceCity() As String
        Get
            Return mPrimaryInsuranceCity
        End Get
        Set(ByVal value As String)
            mPrimaryInsuranceCity = value
        End Set
    End Property


    Public Property PrimaryInsuranceAddress2() As String
        Get
            Return mPrimaryInsuranceAddress2
        End Get
        Set(ByVal value As String)
            mPrimaryInsuranceAddress2 = value
        End Set
    End Property


    Public Property PrimaryInsuranceAddress1() As String
        Get
            Return mPrimaryInsuranceAddress1
        End Get
        Set(ByVal value As String)
            mPrimaryInsuranceAddress1 = value
        End Set
    End Property

    Public Property FacilitySecondaryIdentificationQualifier() As String
        Get
            Return mFacilitySecondaryIdentificationQualifier
        End Get
        Set(ByVal value As String)
            mFacilitySecondaryIdentificationQualifier = value
        End Set
    End Property

    Public Property ClinicSecondaryIdentificationQualifier() As String
        Get
            Return mClinicSecondaryIdentificationQualifier
        End Get
        Set(ByVal value As String)
            mClinicSecondaryIdentificationQualifier = value
        End Set
    End Property
    Public Property InsuranceAddressLine1() As String
        Get
            Return mInsuranceAddressLine1
        End Get
        Set(ByVal value As String)
            mInsuranceAddressLine1 = value
        End Set
    End Property
    Public Property InsuranceAddressLine2() As String
        Get
            Return mInsuranceAddressLine2
        End Get
        Set(ByVal value As String)
            mInsuranceAddressLine2 = value
        End Set
    End Property
    Public Property RefferingProviderIDQualifier() As String
        Get
            Return mRefferingProviderIDQualifier
        End Get
        Set(ByVal value As String)
            mRefferingProviderIDQualifier = value
        End Set
    End Property
    Public Property IsSend() As String
        Get
            Return mIsSend
        End Get
        Set(ByVal value As String)
            mIsSend = value
        End Set
    End Property

    Public Property FacilityCity() As String
        Get
            Return mFacilityCity
        End Get
        Set(ByVal value As String)
            mFacilityCity = value
        End Set
    End Property

    Public Property FacilityState() As String
        Get
            Return mFacilityState
        End Get
        Set(ByVal value As String)
            mFacilityState = value
        End Set
    End Property

    Public Property FacilityZipCode() As String
        Get
            Return mFacilityZipCode
        End Get
        Set(ByVal value As String)
            mFacilityZipCode = value
        End Set
    End Property

    Public Property HCFAType() As String
        Get
            Return mHCFAType
        End Get
        Set(ByVal value As String)
            mHCFAType = value
        End Set
    End Property

    Public Property MainInsID() As String
        Get
            Return mMainInsID
        End Get
        Set(ByVal value As String)
            mMainInsID = value
        End Set
    End Property

    Public Property OtherInsID() As String
        Get
            Return mOtherInsID
        End Get
        Set(ByVal value As String)
            mOtherInsID = value
        End Set
    End Property


#End Region

End Class

Public Class HCFA
#Region "Fields"
    Private mConnection As Connection
    Private mConnectionString
    Private mHCFA As New HCFADB
#End Region

#Region "Property"
    Public ReadOnly Property Connection() As ElixirLibrary.Connection
        Get
            Return mConnection
        End Get
    End Property

    Public ReadOnly Property ConnectionString() As String
        Get
            Return mConnectionString
        End Get
    End Property
    Public Property HCFA() As HCFADB
        Get
            Return mHCFA
        End Get
        Set(ByVal value As HCFADB)
            mHCFA = value
        End Set
    End Property
#End Region

#Region "Constructor"
    ''' <summary>
    ''' Creates new Conection Object based on Given Connection String 
    ''' </summary>
    ''' <param name="pConnectionString">
    ''' Contains Connection String 
    ''' </param>
    ''' <remarks>
    ''' Use when not using transaction
    ''' Must Specify Connection String other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnectionString As String)
        If pConnectionString = "" Then
            Throw New ArgumentException("ConnectionString can not be empty")
        End If

        mConnectionString = pConnectionString
        mConnection = New Connection(mConnectionString)

    End Sub
    ''' <summary>
    ''' Assign given connection to the current Object
    ''' </summary>
    ''' <param name="pConnection">
    ''' Contains refrence to the connection object
    ''' </param>
    ''' <remarks>
    ''' Use when  using Transaction
    ''' Must Specify Connection other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnection As Connection)
        If pConnection Is Nothing Then
            Throw New ArgumentException("Connection can not be empty")
        End If

        mConnection = pConnection
    End Sub
#End Region

#Region "Method"
    Public Function GetRecordByPatientSuperBillID() As Boolean
        Dim lSpParameter(0) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@PatientSuperBillID"
        lSpParameter(0).ParameterType = ParameterType.BigInt
        lSpParameter(0).ParameterValue = Me.mHCFA.PatientSuperBillID

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("GetHCFAICDByPatientSuperBillID", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("GetHCFAICDByPatientSuperBillID", lSpParameter)
        End If


        With lDs.Tables(0)
            If .Rows.Count > 0 Then

                Me.mHCFA.PatientSuperBillID = .Rows(0)("PatientSuperBillID")
                'Me.mHCFA.DateOfService = .Rows(0)("DateOfService")
                'Me.mHCFA.SuperBillTemplateID = .Rows(0)("SuperBillTemplateID")
                'Me.mHCFA.PatientId = .Rows(0)("PatientId")
                Me.mHCFA.PatientName = .Rows(0)("PatientName")
                Me.mHCFA.PatientDOB = .Rows(0)("DOB")
                Me.mHCFA.PatientAddress = .Rows(0)("Address")
                Me.mHCFA.PatientCity = .Rows(0)("City")
                Me.mHCFA.PatientState = .Rows(0)("State")
                Me.mHCFA.PatientZipCode = .Rows(0)("ZipCode")
                'Me.mHCFA.PrimaryInsuranceCompanyId = .Rows(0)("PrimaryInsuranceCompanyId")
                'Me.mHCFA.PatientPrimaryInsuranceCompanyName = .Rows(0)("PrimaryInsuranceCompanyName")
                'Me.mHCFA.SecondryInsuranceCompanyId = .Rows(0)("SecondryInsuranceCompanyId")
                'Me.mHCFA.SecondryInsuranceCompanyName = .Rows(0)("SecondryInsuranceCompanyName")
                'Me.mHCFA.GuarantorName = .Rows(0)("GuarantorName")
                'Me.mHCFA.GuarantorID = .Rows(0)("GuarantorID")
                Me.mHCFA.BalanceDue = .Rows(0)("Balance")
                'Me.mHCFA.PrescriberID = .Rows(0)("PrescriberID")

                If (Not IsDBNull(.Rows(0)("ICD1"))) Then
                    Me.mHCFA.ICD1 = .Rows(0)("ICD1")
                Else
                    Me.mHCFA.ICD1 = ""
                End If

                If (Not IsDBNull(.Rows(0)("ICD2"))) Then
                    Me.mHCFA.ICD2 = .Rows(0)("ICD2")
                Else
                    Me.mHCFA.ICD2 = ""
                End If

                If (Not IsDBNull(.Rows(0)("ICD3"))) Then
                    Me.mHCFA.ICD3 = .Rows(0)("ICD3")
                Else
                    Me.mHCFA.ICD3 = ""
                End If

                If (Not IsDBNull(.Rows(0)("ICD4"))) Then
                    Me.mHCFA.ICD4 = .Rows(0)("ICD4")
                Else
                    Me.mHCFA.ICD4 = ""
                End If


                Return True
            End If
        End With

        Return False

    End Function


    Public Function GetAllRecords() As System.Data.DataSet
        Dim lCondition As String = ""
        Dim lDs As New DataSet()

        lDs = GetAllRecords(lCondition)

        Return lDs
    End Function

    Public Function GetAllRecords(ByVal lCondition As String) As System.Data.DataSet
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "HCFA"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = lCondition

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("SelectAllRecords", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
        End If

        Return lDs

    End Function



    Public Function GetPendingClaims(ByVal lCondition As String) As System.Data.DataSet
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@Cond"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = lCondition

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("GetPendingClaims", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("GetPendingClaims", lSpParameter)
        End If

        Return lDs

    End Function

    Public Function GetPendingClaimDetails(ByVal lCondition As String) As System.Data.DataSet
        Dim lSpParameter(0) As SpParameter
        Dim lDs As New DataSet()


        lSpParameter(0).ParameterName = "@Cond"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = lCondition


        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("GetPendingPaymentDetails", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("GetPendingPaymentDetails", lSpParameter)
        End If

        Return lDs

    End Function
    Public Function GetPendingClaimDetailsEdit(ByVal pPaymentId As Int32) As System.Data.DataSet
        Dim lSpParameter(0) As SpParameter
        Dim lDs As New DataSet()


        lSpParameter(0).ParameterName = "@PaymentId"
        lSpParameter(0).ParameterType = ParameterType.BigInt
        lSpParameter(0).ParameterValue = pPaymentId

        
        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("GetPendingPaymentDetailsEdit", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("GetPendingPaymentDetailsEdit", lSpParameter)
        End If

        Return lDs

    End Function



    Public Function GetRecordByID() As Boolean
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "HCFA"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = "And HCFAID = " & HCFA.HCFAID

        Try

            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery("SelectAllRecords", lSpParameter)
            Else
                lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
            End If


            With lDs.Tables(0)
                If .Rows.Count > 0 Then

                    Me.HCFA.HCFADisplayID = .Rows(0)("HCFADisplayID")
                    Me.HCFA.PatientSuperBillID = .Rows(0)("PatientSuperBillID")
                    '' case for Company type
                    Me.HCFA.Type1 = .Rows(0)("Type1")
                    Me.HCFA.Type2 = .Rows(0)("Type2")
                    '' case for Company type
                    Me.HCFA.InsuredIDNumber = .Rows(0)("InsuredIDNumber")
                    Me.HCFA.GroupNumber = .Rows(0)("GroupNumber")
                    Me.HCFA.PatientName = .Rows(0)("PatientName")
                    Me.HCFA.PatientDOB = .Rows(0)("PatientDOB")
                    Me.HCFA.PatientGender = .Rows(0)("PatientGender")
                    Me.HCFA.InsuredName = .Rows(0)("InsuredName")
                    Me.HCFA.PatientAddress = .Rows(0)("PatientAddress")
                    Me.HCFA.PatientCity = .Rows(0)("PatientCity")
                    Me.HCFA.PatientZipCode = .Rows(0)("PatientZipCode")
                    Me.HCFA.PatientState = .Rows(0)("PatientState")
                    Me.HCFA.PatientTelephone = .Rows(0)("PatientTelephone")
                    Me.HCFA.PatientRelationshipToInsured = .Rows(0)("PatientRelationshipToInsured")
                    Me.HCFA.InsuredAddress = .Rows(0)("InsuredAddress")
                    Me.HCFA.InsuredCity = .Rows(0)("InsuredCity")
                    Me.HCFA.InsuredState = .Rows(0)("InsuredState")
                    Me.HCFA.InsuredZipCode = .Rows(0)("InsuredZipCode")
                    Me.HCFA.InsuredTelephone = .Rows(0)("InsuredTelephone")
                    Me.HCFA.PatientMaritalStatus = .Rows(0)("PatientMaritalStatus")
                    Me.HCFA.PatientEmploymentInfo = .Rows(0)("PatientEmploymentInfo")
                    Me.HCFA.OtherInsuredName = .Rows(0)("OtherInsuredName")
                    Me.HCFA.OtherInsuredPolicy = .Rows(0)("OtherInsuredPolicy")
                    Me.HCFA.OtherInsuredDOB = .Rows(0)("OtherInsuredDOB")
                    Me.HCFA.OtherInsuredGender = .Rows(0)("OtherInsuredGender")
                    Me.HCFA.OtherInsuredEmployer = .Rows(0)("OtherInsuredEmployer")
                    Me.HCFA.SecondaryInsurancePlan = .Rows(0)("SecondaryInsurancePlan")
                    Me.HCFA.IsEmploymentRelated = .Rows(0)("IsEmploymentRelated")
                    Me.HCFA.IsAutoAccidentRelated = .Rows(0)("IsAutoAccidentRelated")
                    Me.HCFA.IsOtherAccidentRelated = .Rows(0)("IsOtherAccidentRelated")
                    Me.HCFA.ReservedBlock10D = .Rows(0)("ReservedBlock10D")
                    Me.HCFA.AnotherInsuredPolicy = .Rows(0)("AnotherInsuredPolicy")
                    Me.HCFA.AnotherInsuredDOB = .Rows(0)("AnotherInsuredDOB")
                    Me.HCFA.AnotherInsuredGender = .Rows(0)("AnotherInsuredGender")
                    Me.HCFA.AnotherInsuredEmployerName = .Rows(0)("AnotherInsuredEmployerName")
                    Me.HCFA.AnotherInsuredInsurancePlan = .Rows(0)("AnotherInsuredInsurancePlan")
                    Me.HCFA.IsAnotherPlan = .Rows(0)("IsAnotherPlan")
                    Me.HCFA.ReleaseInfoSignature = .Rows(0)("ReleaseInfoSignature")
                    Me.HCFA.ReleaseInfoDate = .Rows(0)("ReleaseInfoDate")
                    Me.HCFA.PaymentSignature = .Rows(0)("PaymentSignature")
                    Me.HCFA.DateOfOccurance = .Rows(0)("DateOfOccurance")
                    Me.HCFA.PreviousOccuranceDate = .Rows(0)("PreviousOccuranceDate")
                    Me.HCFA.UnableToWorkFrom = .Rows(0)("UnableToWorkFrom")
                    Me.HCFA.UnableToWorkTo = .Rows(0)("UnableToWorkTo")
                    Me.HCFA.RefferingProviderName = .Rows(0)("RefferingProviderName")
                    Me.HCFA.RefferingProviderID = .Rows(0)("RefferingProviderID")
                    Me.HCFA.RefferingProviderNPI = .Rows(0)("RefferingProviderNPI")
                    Me.HCFA.HospitalizationDateFrom = .Rows(0)("HospitalizationDateFrom")
                    Me.HCFA.HospitalizationDateTo = .Rows(0)("HospitalizationDateTo")
                    Me.HCFA.ReservedBlock19 = .Rows(0)("ReservedBlock19")
                    Me.HCFA.IsOutsideLab = .Rows(0)("IsOutsideLab")
                    Me.HCFA.OutsideLabCharges = .Rows(0)("OutsideLabCharges")
                    Me.HCFA.ICD1 = .Rows(0)("ICD1")
                    Me.HCFA.ICD2 = .Rows(0)("ICD2")
                    Me.HCFA.ICD3 = .Rows(0)("ICD3")
                    Me.HCFA.ICD4 = .Rows(0)("ICD4")
                    Me.HCFA.MedicaidCode = .Rows(0)("MedicaidCode")
                    Me.HCFA.OriginalRefrenceNumber = .Rows(0)("OriginalRefrenceNumber")
                    Me.HCFA.PriorAuthorizationNumber = .Rows(0)("PriorAuthorizationNumber")
                    Me.HCFA.FederalTaxID = .Rows(0)("FederalTaxID")
                    Me.HCFA.IsSSN = .Rows(0)("IsSSN")
                    Me.HCFA.PatientAccountNumber = .Rows(0)("PatientAccountNumber")
                    Me.HCFA.IsAcceptAssignment = .Rows(0)("IsAcceptAssignment")
                    Me.HCFA.TotalCharge = .Rows(0)("TotalCharge")
                    Me.HCFA.AmountPaid = .Rows(0)("AmountPaid")
                    Me.HCFA.BalanceDue = .Rows(0)("BalanceDue")
                    Me.HCFA.ProviderName = .Rows(0)("ProviderName")
                    Me.HCFA.HCFAPreparedDate = .Rows(0)("HCFAPreparedDate")
                    Me.HCFA.FacilityId = .Rows(0)("FacilityId")
                    Me.HCFA.FacilityName = .Rows(0)("FacilityName")
                    Me.HCFA.FacilityAddress = .Rows(0)("FacilityAddress")
                    Me.HCFA.FacilityProvider = .Rows(0)("FacilityProvider")
                    Me.HCFA.FacilityCode = .Rows(0)("FacilityCode")
                    Me.HCFA.ClinicName = .Rows(0)("ClinicName")
                    Me.HCFA.ClinicAddress = .Rows(0)("ClinicAddress")
                    Me.HCFA.ClinicCity = .Rows(0)("ClinicCity")
                    Me.HCFA.ClinicState = .Rows(0)("ClinicState")
                    Me.HCFA.ClinicZip = .Rows(0)("ClinicZip")
                    Me.HCFA.ClinicPhoneNumber = .Rows(0)("ClinicPhoneNumber")
                    Me.HCFA.ClinicPinNumber = .Rows(0)("ClinicPinNumber")
                    Me.HCFA.ClinicGroupNumber = .Rows(0)("ClinicGroupNumber")
                    Me.HCFA.DoctorUserID = .Rows(0)("DoctorUserID")
                    Me.HCFA.CreateByUserID = .Rows(0)("CreateByUserID")
                    Me.HCFA.InsuranceNameHdr = .Rows(0)("InsuranceNameHdr")
                    Me.HCFA.InsuranceAddressHdr = .Rows(0)("InsuranceAddressHdr")
                    Me.HCFA.FacilitySecondaryIdentificationQualifier = .Rows(0)("FacilitySecondaryIdentificationQualifier")
                    Me.HCFA.ClinicSecondaryIdentificationQualifier = .Rows(0)("ClinicSecondaryIdentificationQualifier")
                    Me.HCFA.InsuranceAddressLine1 = .Rows(0)("InsuranceAddressLine1")
                    Me.HCFA.InsuranceAddressLine2 = .Rows(0)("InsuranceAddressLine2")
                    Me.HCFA.RefferingProviderIDQualifier = .Rows(0)("RefferingProviderIDQualifier")
                    Me.HCFA.IsSend = .Rows(0)("IsSend")
                    Me.HCFA.FacilityCity = .Rows(0)("FacilityCity")
                    Me.HCFA.FacilityState = .Rows(0)("FacilityState")
                    Me.HCFA.FacilityZipCode = .Rows(0)("FacilityZipCode")

                    Me.HCFA.HCFAType = .Rows(0)("HCFAType")

                    Me.HCFA.PrimaryInsuranceAddress1 = .Rows(0)("InsuranceAddressLine1")
                    Me.HCFA.PrimaryInsuranceAddress2 = .Rows(0)("InsuranceAddressLine2")
                    Me.HCFA.PrimaryInsuranceCity = .Rows(0)("InsuranceCity")
                    Me.HCFA.PrimaryInsuranceState = .Rows(0)("InsuranceState")
                    Me.HCFA.PrimaryInsuranceZipCode = .Rows(0)("InsuranceZipCode")

                    Me.HCFA.MainInsID = .Rows(0)("MainInsID")
                    Me.HCFA.OtherInsID = .Rows(0)("OtherInsID")

                    Return True
                End If
            End With
        Catch ex As Exception
            Return False
        End Try
        Return False
    End Function
    Public Function GetRecordByCondition(ByVal pCond As String) As Boolean
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "HCFA"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = pCond

        Try

            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery("SelectAllRecords", lSpParameter)
            Else
                lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
            End If


            With lDs.Tables(0)
                If .Rows.Count > 0 Then

                    Me.HCFA.HCFADisplayID = .Rows(0)("HCFADisplayID")
                    Me.HCFA.PatientSuperBillID = .Rows(0)("PatientSuperBillID")
                    '' case for Company type
                    Me.HCFA.Type1 = .Rows(0)("Type1")
                    Me.HCFA.Type2 = .Rows(0)("Type2")
                    '' case for Company type
                    Me.HCFA.InsuredIDNumber = .Rows(0)("InsuredIDNumber")
                    Me.HCFA.GroupNumber = .Rows(0)("GroupNumber")
                    Me.HCFA.PatientName = .Rows(0)("PatientName")
                    Me.HCFA.PatientDOB = .Rows(0)("PatientDOB")
                    Me.HCFA.PatientGender = .Rows(0)("PatientGender")
                    Me.HCFA.InsuredName = .Rows(0)("InsuredName")
                    Me.HCFA.PatientAddress = .Rows(0)("PatientAddress")
                    Me.HCFA.PatientCity = .Rows(0)("PatientCity")
                    Me.HCFA.PatientZipCode = .Rows(0)("PatientZipCode")
                    Me.HCFA.PatientState = .Rows(0)("PatientState")
                    Me.HCFA.PatientTelephone = .Rows(0)("PatientTelephone")
                    Me.HCFA.PatientRelationshipToInsured = .Rows(0)("PatientRelationshipToInsured")
                    Me.HCFA.InsuredAddress = .Rows(0)("InsuredAddress")
                    Me.HCFA.InsuredCity = .Rows(0)("InsuredCity")
                    Me.HCFA.InsuredState = .Rows(0)("InsuredState")
                    Me.HCFA.InsuredZipCode = .Rows(0)("InsuredZipCode")
                    Me.HCFA.InsuredTelephone = .Rows(0)("InsuredTelephone")
                    Me.HCFA.PatientMaritalStatus = .Rows(0)("PatientMaritalStatus")
                    Me.HCFA.PatientEmploymentInfo = .Rows(0)("PatientEmploymentInfo")
                    Me.HCFA.OtherInsuredName = .Rows(0)("OtherInsuredName")
                    Me.HCFA.OtherInsuredPolicy = .Rows(0)("OtherInsuredPolicy")
                    Me.HCFA.OtherInsuredDOB = .Rows(0)("OtherInsuredDOB")
                    Me.HCFA.OtherInsuredGender = .Rows(0)("OtherInsuredGender")
                    Me.HCFA.OtherInsuredEmployer = .Rows(0)("OtherInsuredEmployer")
                    Me.HCFA.SecondaryInsurancePlan = .Rows(0)("SecondaryInsurancePlan")
                    Me.HCFA.IsEmploymentRelated = .Rows(0)("IsEmploymentRelated")
                    Me.HCFA.IsAutoAccidentRelated = .Rows(0)("IsAutoAccidentRelated")
                    Me.HCFA.IsOtherAccidentRelated = .Rows(0)("IsOtherAccidentRelated")
                    Me.HCFA.ReservedBlock10D = .Rows(0)("ReservedBlock10D")
                    Me.HCFA.AnotherInsuredPolicy = .Rows(0)("AnotherInsuredPolicy")
                    Me.HCFA.AnotherInsuredDOB = .Rows(0)("AnotherInsuredDOB")
                    Me.HCFA.AnotherInsuredGender = .Rows(0)("AnotherInsuredGender")
                    Me.HCFA.AnotherInsuredEmployerName = .Rows(0)("AnotherInsuredEmployerName")
                    Me.HCFA.AnotherInsuredInsurancePlan = .Rows(0)("AnotherInsuredInsurancePlan")
                    Me.HCFA.IsAnotherPlan = .Rows(0)("IsAnotherPlan")
                    Me.HCFA.ReleaseInfoSignature = .Rows(0)("ReleaseInfoSignature")
                    Me.HCFA.ReleaseInfoDate = .Rows(0)("ReleaseInfoDate")
                    Me.HCFA.PaymentSignature = .Rows(0)("PaymentSignature")
                    Me.HCFA.DateOfOccurance = .Rows(0)("DateOfOccurance")
                    Me.HCFA.PreviousOccuranceDate = .Rows(0)("PreviousOccuranceDate")
                    Me.HCFA.UnableToWorkFrom = .Rows(0)("UnableToWorkFrom")
                    Me.HCFA.UnableToWorkTo = .Rows(0)("UnableToWorkTo")
                    Me.HCFA.RefferingProviderName = .Rows(0)("RefferingProviderName")
                    Me.HCFA.RefferingProviderID = .Rows(0)("RefferingProviderID")
                    Me.HCFA.RefferingProviderNPI = .Rows(0)("RefferingProviderNPI")
                    Me.HCFA.HospitalizationDateFrom = .Rows(0)("HospitalizationDateFrom")
                    Me.HCFA.HospitalizationDateTo = .Rows(0)("HospitalizationDateTo")
                    Me.HCFA.ReservedBlock19 = .Rows(0)("ReservedBlock19")
                    Me.HCFA.IsOutsideLab = .Rows(0)("IsOutsideLab")
                    Me.HCFA.OutsideLabCharges = .Rows(0)("OutsideLabCharges")
                    Me.HCFA.ICD1 = .Rows(0)("ICD1")
                    Me.HCFA.ICD2 = .Rows(0)("ICD2")
                    Me.HCFA.ICD3 = .Rows(0)("ICD3")
                    Me.HCFA.ICD4 = .Rows(0)("ICD4")
                    Me.HCFA.MedicaidCode = .Rows(0)("MedicaidCode")
                    Me.HCFA.OriginalRefrenceNumber = .Rows(0)("OriginalRefrenceNumber")
                    Me.HCFA.PriorAuthorizationNumber = .Rows(0)("PriorAuthorizationNumber")
                    Me.HCFA.FederalTaxID = .Rows(0)("FederalTaxID")
                    Me.HCFA.IsSSN = .Rows(0)("IsSSN")
                    Me.HCFA.PatientAccountNumber = .Rows(0)("PatientAccountNumber")
                    Me.HCFA.IsAcceptAssignment = .Rows(0)("IsAcceptAssignment")
                    Me.HCFA.TotalCharge = .Rows(0)("TotalCharge")
                    Me.HCFA.AmountPaid = .Rows(0)("AmountPaid")
                    Me.HCFA.BalanceDue = .Rows(0)("BalanceDue")
                    Me.HCFA.ProviderName = .Rows(0)("ProviderName")
                    Me.HCFA.HCFAPreparedDate = .Rows(0)("HCFAPreparedDate")
                    Me.HCFA.FacilityId = .Rows(0)("FacilityId")
                    Me.HCFA.FacilityName = .Rows(0)("FacilityName")
                    Me.HCFA.FacilityAddress = .Rows(0)("FacilityAddress")
                    Me.HCFA.FacilityProvider = .Rows(0)("FacilityProvider")
                    Me.HCFA.FacilityCode = .Rows(0)("FacilityCode")
                    Me.HCFA.ClinicName = .Rows(0)("ClinicName")
                    Me.HCFA.ClinicAddress = .Rows(0)("ClinicAddress")
                    Me.HCFA.ClinicCity = .Rows(0)("ClinicCity")
                    Me.HCFA.ClinicState = .Rows(0)("ClinicState")
                    Me.HCFA.ClinicZip = .Rows(0)("ClinicZip")
                    Me.HCFA.ClinicPhoneNumber = .Rows(0)("ClinicPhoneNumber")
                    Me.HCFA.ClinicPinNumber = .Rows(0)("ClinicPinNumber")
                    Me.HCFA.ClinicGroupNumber = .Rows(0)("ClinicGroupNumber")
                    Me.HCFA.DoctorUserID = .Rows(0)("DoctorUserID")
                    Me.HCFA.CreateByUserID = .Rows(0)("CreateByUserID")
                    Me.HCFA.InsuranceNameHdr = .Rows(0)("InsuranceNameHdr")
                    Me.HCFA.InsuranceAddressHdr = .Rows(0)("InsuranceAddressHdr")
                    Me.HCFA.FacilitySecondaryIdentificationQualifier = .Rows(0)("FacilitySecondaryIdentificationQualifier")
                    Me.HCFA.ClinicSecondaryIdentificationQualifier = .Rows(0)("ClinicSecondaryIdentificationQualifier")
                    Me.HCFA.InsuranceAddressLine1 = .Rows(0)("InsuranceAddressLine1")
                    Me.HCFA.InsuranceAddressLine2 = .Rows(0)("InsuranceAddressLine2")
                    Me.HCFA.RefferingProviderIDQualifier = .Rows(0)("RefferingProviderIDQualifier")
                    Me.HCFA.IsSend = .Rows(0)("IsSend")
                    Me.HCFA.FacilityCity = .Rows(0)("FacilityCity")
                    Me.HCFA.FacilityState = .Rows(0)("FacilityState")
                    Me.HCFA.FacilityZipCode = .Rows(0)("FacilityZipCode")

                    Me.HCFA.HCFAType = .Rows(0)("HCFAType")

                    Me.HCFA.MainInsID = .Rows(0)("MainInsID")
                    Me.HCFA.OtherInsID = .Rows(0)("OtherInsID")

                    Return True
                End If
            End With
        Catch ex As Exception
            Return False
        End Try
        Return False
    End Function

    Public Function InsertRecord() As String
        Dim lXmlDocument As New XmlDocument
        Dim lXmlElement As XmlElement


        lXmlDocument.LoadXml("<HCFAS></HCFAS>")
        lXmlElement = lXmlDocument.CreateElement("HCFA")


        With lXmlElement
            .SetAttribute("HCFAID", HCFA.HCFAID)
            .SetAttribute("HCFADisplayID", HCFA.HCFADisplayID)
            .SetAttribute("PatientSuperBillID", HCFA.PatientSuperBillID)
            .SetAttribute("Type1", HCFA.Type1)
            .SetAttribute("Type2", HCFA.Type2)
            .SetAttribute("InsuredIDNumber", HCFA.InsuredIDNumber)
            .SetAttribute("GroupNumber", HCFA.GroupNumber)
            .SetAttribute("PatientName", HCFA.PatientName)
            .SetAttribute("PatientDOB", HCFA.PatientDOB)
            .SetAttribute("PatientGender", HCFA.PatientGender)
            .SetAttribute("InsuredName", HCFA.InsuredName)
            .SetAttribute("PatientAddress", HCFA.PatientAddress)
            .SetAttribute("PatientCity", HCFA.PatientCity)
            .SetAttribute("PatientZipCode", HCFA.PatientZipCode)
            .SetAttribute("PatientState", HCFA.PatientState)
            .SetAttribute("PatientTelephone", HCFA.PatientTelephone)
            .SetAttribute("PatientRelationshipToInsured", HCFA.PatientRelationshipToInsured)
            .SetAttribute("InsuredAddress", HCFA.InsuredAddress)
            .SetAttribute("InsuredCity", HCFA.InsuredCity)

            .SetAttribute("InsuredState", HCFA.InsuredState)
            .SetAttribute("InsuredZipCode", HCFA.InsuredZipCode)
            .SetAttribute("InsuredIDNumber", HCFA.InsuredIDNumber)
            .SetAttribute("InsuredTelephone", HCFA.InsuredTelephone)
            .SetAttribute("PatientMaritalStatus", HCFA.PatientMaritalStatus)

            .SetAttribute("PatientEmploymentInfo", HCFA.PatientEmploymentInfo)
            .SetAttribute("OtherInsuredName", HCFA.OtherInsuredName)
            .SetAttribute("OtherInsuredPolicy", HCFA.OtherInsuredPolicy)
            .SetAttribute("OtherInsuredDOB", HCFA.OtherInsuredDOB)
            .SetAttribute("OtherInsuredGender", HCFA.OtherInsuredGender)
            .SetAttribute("OtherInsuredEmployer", HCFA.OtherInsuredEmployer)

            .SetAttribute("SecondaryInsurancePlan", HCFA.SecondaryInsurancePlan)
            .SetAttribute("IsEmploymentRelated", HCFA.IsEmploymentRelated)
            .SetAttribute("IsAutoAccidentRelated", HCFA.IsAutoAccidentRelated)
            .SetAttribute("IsOtherAccidentRelated", HCFA.IsOtherAccidentRelated)
            .SetAttribute("ReservedBlock10D", HCFA.ReservedBlock10D)
            .SetAttribute("AnotherInsuredPolicy", HCFA.AnotherInsuredPolicy)
            .SetAttribute("AnotherInsuredDOB", HCFA.AnotherInsuredDOB)
            .SetAttribute("AnotherInsuredGender", HCFA.AnotherInsuredGender)
            .SetAttribute("AnotherInsuredEmployerName", HCFA.AnotherInsuredEmployerName)
            .SetAttribute("AnotherInsuredInsurancePlan", HCFA.AnotherInsuredInsurancePlan)

            .SetAttribute("IsAnotherPlan", HCFA.IsAnotherPlan)
            .SetAttribute("ReleaseInfoSignature", HCFA.ReleaseInfoSignature)
            .SetAttribute("ReleaseInfoDate", HCFA.ReleaseInfoDate)
            .SetAttribute("PaymentSignature", HCFA.PaymentSignature)
            .SetAttribute("DateOfOccurance", HCFA.DateOfOccurance)
            .SetAttribute("PreviousOccuranceDate", HCFA.PreviousOccuranceDate)
            .SetAttribute("UnableToWorkFrom", HCFA.UnableToWorkFrom)
            .SetAttribute("UnableToWorkTo", HCFA.UnableToWorkTo)
            .SetAttribute("RefferingProviderName", HCFA.RefferingProviderName)
            .SetAttribute("RefferingProviderID", HCFA.RefferingProviderID)
            .SetAttribute("RefferingProviderNPI", HCFA.RefferingProviderNPI)
            .SetAttribute("HospitalizationDateFrom", HCFA.HospitalizationDateFrom)
            .SetAttribute("HospitalizationDateTo", HCFA.HospitalizationDateTo)
            .SetAttribute("ReservedBlock19", HCFA.ReservedBlock19)
            .SetAttribute("IsOutsideLab", HCFA.IsOutsideLab)
            .SetAttribute("OutsideLabCharges", HCFA.OutsideLabCharges)

            .SetAttribute("ICD1", HCFA.ICD1)
            .SetAttribute("ICD2", HCFA.ICD2)
            .SetAttribute("ICD3", HCFA.ICD3)
            .SetAttribute("ICD4", HCFA.ICD4)

            .SetAttribute("MedicaidCode", HCFA.MedicaidCode)
            .SetAttribute("OriginalRefrenceNumber", HCFA.OriginalRefrenceNumber)
            .SetAttribute("PriorAuthorizationNumber", HCFA.PriorAuthorizationNumber)
            .SetAttribute("FederalTaxID", HCFA.FederalTaxID)
            .SetAttribute("IsSSN", HCFA.IsSSN)
            .SetAttribute("PatientAccountNumber", HCFA.PatientAccountNumber)
            .SetAttribute("IsAcceptAssignment", HCFA.IsAcceptAssignment)
            .SetAttribute("TotalCharge", HCFA.TotalCharge)
            .SetAttribute("AmountPaid", HCFA.AmountPaid)
            .SetAttribute("BalanceDue", HCFA.BalanceDue)
            .SetAttribute("ProviderName", HCFA.ProviderName)
            .SetAttribute("HCFAPreparedDate", HCFA.HCFAPreparedDate)

            .SetAttribute("FacilityId", HCFA.FacilityId)
            .SetAttribute("FacilityName", HCFA.FacilityName)
            .SetAttribute("FacilityAddress", HCFA.FacilityAddress)
            .SetAttribute("FacilityProvider", HCFA.FacilityProvider)
            .SetAttribute("FacilityCode", HCFA.FacilityCode)


            .SetAttribute("ClinicName", HCFA.ClinicName)
            .SetAttribute("ClinicAddress", HCFA.ClinicAddress)
            .SetAttribute("ClinicCity", HCFA.ClinicCity)
            .SetAttribute("ClinicState", HCFA.ClinicState)
            .SetAttribute("ClinicZip", HCFA.ClinicZip)
            .SetAttribute("ClinicPhoneNumber", HCFA.ClinicPhoneNumber)
            .SetAttribute("ClinicPinNumber", HCFA.ClinicPinNumber)
            .SetAttribute("ClinicGroupNumber", HCFA.ClinicGroupNumber)
            .SetAttribute("DoctorUserID", HCFA.DoctorUserID)
            .SetAttribute("CreateByUserID", HCFA.CreateByUserID)
            .SetAttribute("InsuranceNameHdr", HCFA.InsuranceNameHdr)
            .SetAttribute("InsuranceAddressHdr", HCFA.InsuranceAddressHdr)
            .SetAttribute("FacilitySecondaryIdentificationQualifier", HCFA.FacilitySecondaryIdentificationQualifier)
            .SetAttribute("ClinicSecondaryIdentificationQualifier", HCFA.ClinicSecondaryIdentificationQualifier)
            .SetAttribute("InsuranceAddressLine1", HCFA.InsuranceAddressLine1)
            .SetAttribute("InsuranceAddressLine2", HCFA.InsuranceAddressLine2)

            .SetAttribute("InsuranceCity", HCFA.PrimaryInsuranceCity)
            .SetAttribute("InsuranceState", HCFA.PrimaryInsuranceState)
            .SetAttribute("InsuranceZipCode", HCFA.PrimaryInsuranceZipCode)

            .SetAttribute("RefferingProviderIDQualifier", HCFA.RefferingProviderIDQualifier)
            .SetAttribute("IsSend", HCFA.IsSend)

            .SetAttribute("FacilityCity", HCFA.FacilityCity)
            .SetAttribute("FacilityState", HCFA.FacilityState)
            .SetAttribute("FacilityZipCode", HCFA.FacilityZipCode)

            .SetAttribute("IsBatch", "N")
            .SetAttribute("HCFAType", HCFA.HCFAType)

            .SetAttribute("MainInsID", HCFA.MainInsID)
            .SetAttribute("OtherInsID", HCFA.OtherInsID)
            


        End With

        lXmlDocument.DocumentElement.AppendChild(lXmlElement.CloneNode(True))


        If Connection.IsTransactionAlive() Then
            InsertRecord = Connection.ExecuteTransactionScalarCommand("InsertHCFA", lXmlDocument.InnerXml.ToString)
        Else
            InsertRecord = Connection.ExecuteScalarCommand("InsertHCFA", lXmlDocument.InnerXml.ToString)
        End If

    End Function
    Public Function GetUniqueId(ByVal lCondition As String) As Integer
        Dim lSpParameter(2) As SpParameter
        Dim lDs As New DataSet()
        Dim lID As Integer

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "HCFA"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = lCondition

        lSpParameter(2).ParameterName = "@Id"
        lSpParameter(2).ParameterType = ParameterType.Varchar
        lSpParameter(2).ParameterValue = "HCFAID"

        If Connection.IsTransactionAlive() Then
            lID = Connection.ExecuteTransactionScalarCommand("GetUniqueId", lSpParameter)
        Else
            lID = Connection.ExecuteScalarQuery("GetUniqueId", lSpParameter)
        End If

        Return lID

    End Function
    Public Function GetUniqueIdHCFA() As String
        Dim lDs As New DataSet()
        Dim lID As String = ""

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("Exec GetUniqueIdHCFA")
        Else
            lDs = Connection.ExecuteQuery("Exec GetUniqueIdHCFA")
        End If

        If (lDs.Tables(0).Rows.Count > 0) Then
            lID = lDs.Tables(0).Rows(0)("HCFAID") & "|" & lDs.Tables(0).Rows(0)("HCFADisplayID")
        Else
            lID = ""
        End If

        Return lID

    End Function

    Public Sub DeleteRecord(ByVal pCondition As String)
        Dim lSpParameter(1) As SpParameter

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "HCFA"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = pCondition

        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand("DeleteRecords", lSpParameter)
        Else
            Connection.ExecuteCommand("DeleteRecords", lSpParameter)
        End If
    End Sub
    Public Sub DeleteRecordByID()
        Dim lCondition As String

        lCondition = "And HCFAID = " & Me.HCFA.HCFAID
        DeleteRecord(lCondition)

    End Sub


    'This function updates the HCFA in the PatientCPT table
    Public Function UpdateCPT(ByVal pHCFAID As String, ByVal pPatientSuperBillId As String, ByVal pClaimNumber As String) As Boolean

        Dim lQuery As String = ""

        Try

            lQuery = "update PatientCPT" _
            & " set HCFAId = " & pHCFAID _
            & " where" _
            & " PatientSuperBillId = " & pPatientSuperBillId & " And" _
            & " LineNumber <= (6* " & pClaimNumber & ") And LineNumber > (6*(" & pClaimNumber & " -1))"


            If Connection.IsTransactionAlive() Then
                Connection.ExecuteTransactionCommand(lQuery)
            Else
                Connection.ExecuteCommand(lQuery)
            End If

            Return True

        Catch ex As Exception
            Return False
        End Try

    End Function



    'This function gets the information of the last filled row of the HCFA table And also updates PatientCPT table to the new HCFA IDs
    Public Function InsertIntoHCFA(ByVal pPatientSuperBillID As String, ByVal pCPTCount As Integer, ByVal pCreatedByUserID As Integer) As DataSet
        Dim lSpParameter(2) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@PatientSuperBillId"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = pPatientSuperBillID

        lSpParameter(1).ParameterName = "@CPTCount"
        lSpParameter(1).ParameterType = ParameterType.Int
        lSpParameter(1).ParameterValue = pCPTCount

        lSpParameter(2).ParameterName = "@CreatedByUserID"
        lSpParameter(2).ParameterType = ParameterType.Int
        lSpParameter(2).ParameterValue = pCreatedByUserID

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("InsertIntoHCFA", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("InsertIntoHCFA", lSpParameter)
        End If

        Return lDs

    End Function

    Public Function EditHCFA()

       Dim lQuery As String = ""

        Try

            lQuery = "Update HCFA " & _
          "set " & _
          "Type1 = '" & HCFA.Type1 & "', " & _
          "Type2 = '" & HCFA.Type2 & "', " & _
          "GroupNumber = '" & HCFA.GroupNumber & "', " & _
          "PatientName = '" & HCFA.PatientName & "', " & _
          "PatientDOB = '" & HCFA.PatientDOB & "', " & _
          "PatientGender = '" & HCFA.PatientGender & "', " & _
          "InsuredName = '" & HCFA.InsuredName & "', " & _
          "PatientAddress = '" & HCFA.PatientAddress & "', " & _
          "PatientCity = '" & HCFA.PatientCity & "', " & _
          "PatientZipCode = '" & HCFA.PatientZipCode & "', " & _
          "PatientState = '" & HCFA.PatientState & "', " & _
          "PatientTelephone = '" & HCFA.PatientTelephone & "', " & _
          "PatientRelationshipToInsured = '" & HCFA.PatientRelationshipToInsured & "', " & _
          "InsuredAddress = '" & HCFA.InsuredAddress & "', " & _
          "InsuredCity = '" & HCFA.InsuredCity & "', " & _
          "InsuredState = '" & HCFA.InsuredState & "', " & _
          "InsuredZipCode = '" & HCFA.InsuredZipCode & "', " & _
          "InsuredIDNumber = '" & HCFA.InsuredIDNumber & "', " & _
          "InsuredTelephone = '" & HCFA.InsuredTelephone & "', " & _
          "PatientMaritalStatus = '" & HCFA.PatientMaritalStatus & "', " & _
          "PatientEmploymentInfo = '" & HCFA.PatientEmploymentInfo & "', " & _
          "OtherInsuredName = '" & HCFA.OtherInsuredName & "', " & _
          "OtherInsuredPolicy = '" & HCFA.OtherInsuredPolicy & "', " & _
          "OtherInsuredDOB = '" & HCFA.OtherInsuredDOB & "', " & _
          "OtherInsuredGender = '" & HCFA.OtherInsuredGender & "', " & _
          "OtherInsuredEmployer = '" & HCFA.OtherInsuredEmployer & "', " & _
          "SecondaryInsurancePlan = '" & HCFA.SecondaryInsurancePlan & "', " & _
          "IsEmploymentRelated = '" & HCFA.IsEmploymentRelated & "', " & _
          "IsAutoAccidentRelated = '" & HCFA.IsAutoAccidentRelated & "', " & _
          "IsOtherAccidentRelated = '" & HCFA.IsOtherAccidentRelated & "', " & _
          "ReservedBlock10D = '" & HCFA.ReservedBlock10D & "', " & _
          "AnotherInsuredPolicy = '" & HCFA.AnotherInsuredPolicy & "', " & _
          "AnotherInsuredDOB = '" & HCFA.AnotherInsuredDOB & "', " & _
          "AnotherInsuredGender = '" & HCFA.AnotherInsuredGender & "', " & _
          "AnotherInsuredEmployerName = '" & HCFA.AnotherInsuredEmployerName & "', " & _
          "AnotherInsuredInsurancePlan = '" & HCFA.AnotherInsuredInsurancePlan & "', " & _
          "IsAnotherPlan = '" & HCFA.IsAnotherPlan & "', " & _
          "ReleaseInfoSignature = '" & HCFA.ReleaseInfoSignature & "', " & _
          "ReleaseInfoDate = '" & HCFA.ReleaseInfoDate & "', " & _
          "PaymentSignature = '" & HCFA.PaymentSignature & "', " & _
          "DateOfOccurance = '" & HCFA.DateOfOccurance & "', " & _
          "PreviousOccuranceDate = '" & HCFA.PreviousOccuranceDate & "', " & _
          "UnableToWorkFrom = '" & HCFA.UnableToWorkFrom & "', " & _
          "UnableToWorkTo = '" & HCFA.UnableToWorkTo & "', " & _
          "RefferingProviderName = '" & HCFA.RefferingProviderName & "', " & _
          "RefferingProviderID = '" & HCFA.RefferingProviderID & "', " & _
          "RefferingProviderNPI = '" & HCFA.RefferingProviderNPI & "', " & _
          "HospitalizationDateFrom = '" & HCFA.HospitalizationDateFrom & "', " & _
          "HospitalizationDateTo = '" & HCFA.HospitalizationDateTo & "', " & _
          "ReservedBlock19 = '" & HCFA.ReservedBlock19 & "', " & _
          "IsOutsideLab = '" & HCFA.IsOutsideLab & "', " & _
          "OutsideLabCharges = '" & HCFA.OutsideLabCharges & "', " & _
          "ICD1 = '" & HCFA.ICD1 & "', " & _
          "ICD2 = '" & HCFA.ICD2 & "', " & _
          "ICD3 = '" & HCFA.ICD3 & "', " & _
          "ICD4 = '" & HCFA.ICD4 & "', " & _
          "MedicaidCode = '" & HCFA.MedicaidCode & "', " & _
          "OriginalRefrenceNumber = '" & HCFA.OriginalRefrenceNumber & "', " & _
          "PriorAuthorizationNumber = '" & HCFA.PriorAuthorizationNumber & "', " & _
          "FederalTaxID = '" & HCFA.FederalTaxID & "', " & _
          "IsSSN = '" & HCFA.IsSSN & "', " & _
          "IsAcceptAssignment = '" & HCFA.IsAcceptAssignment & "', " & _
          "TotalCharge = '" & HCFA.TotalCharge & "', " & _
          "AmountPaid = '" & HCFA.AmountPaid & "', " & _
          "BalanceDue = '" & HCFA.BalanceDue & "', " & _
          "ProviderName = '" & HCFA.ProviderName & "', " & _
          "HCFAPreparedDate = '" & HCFA.HCFAPreparedDate & "', " & _
          "FacilityId = '" & HCFA.FacilityId & "', " & _
          "FacilityName = '" & HCFA.FacilityName & "', " & _
          "FacilityAddress = '" & HCFA.FacilityAddress & "', " & _
          "FacilityProvider = '" & HCFA.FacilityProvider & "', " & _
          "FacilityCode = '" & HCFA.FacilityCode & "', " & _
          "ClinicName = '" & HCFA.ClinicName & "', " & _
          "ClinicAddress = '" & HCFA.ClinicAddress & "', " & _
          "ClinicCity = '" & HCFA.ClinicCity & "', " & _
          "ClinicState = '" & HCFA.ClinicState & "', " & _
          "ClinicZip = '" & HCFA.ClinicZip & "', " & _
          "ClinicPhoneNumber = '" & HCFA.ClinicPhoneNumber & "', " & _
          "ClinicPinNumber = '" & HCFA.ClinicPinNumber & "', " & _
          "ClinicGroupNumber = '" & HCFA.ClinicGroupNumber & "', " & _
          "DoctorUserID = '" & HCFA.DoctorUserID & "', " & _
          "CreateByUserID = '" & HCFA.CreateByUserID & "', " & _
          "InsuranceNameHdr = '" & HCFA.InsuranceNameHdr & "', " & _
          "InsuranceAddressHdr ='" & HCFA.InsuranceAddressHdr & "', " & _
          "FacilitySecondaryIdentificationQualifier ='" & HCFA.FacilitySecondaryIdentificationQualifier & "'," & _
          "ClinicSecondaryIdentificationQualifier ='" & HCFA.ClinicSecondaryIdentificationQualifier & "'," & _
          "InsuranceAddressLine1 ='" & HCFA.InsuranceAddressLine1 & "'," & _
          "InsuranceAddressLine2 ='" & HCFA.InsuranceAddressLine2 & "'," & _
          "RefferingProviderIDQualifier ='" & HCFA.RefferingProviderIDQualifier & "'," & _
          "FacilityCity ='" & HCFA.FacilityCity & "'," & _
          "FacilityState ='" & HCFA.FacilityState & "'," & _
          "FacilityZipCode ='" & HCFA.FacilityZipCode & "'," & _
          "MainInsID ='" & HCFA.MainInsID & "'," & _
          "OtherInsID ='" & HCFA.OtherInsID & "'," & _
          "HCFAType='" & HCFA.HCFAType & "'" & _
          " where " & _
          "HCFAID = " & HCFA.HCFAID



            If Connection.IsTransactionAlive() Then
                Connection.ExecuteTransactionCommand(lQuery)
            Else
                Connection.ExecuteCommand(lQuery)
            End If

            Return True

        Catch ex As Exception
            Return False
        End Try
    End Function


#End Region
End Class
