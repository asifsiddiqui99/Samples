Imports Microsoft.VisualBasic

Public Class CPTDB

#Region "Fields"
    Private mLineId As String
    Private mSuperBillId As String
    Private mHeading As String
    Private mHeadingOrder As String
    Private mCode As String
    Private mShortDescription As String
    Private mFees As String
    Private mPatientSuperBillId As String ' Added By Faraz
    Private mIMO As String
#End Region

#Region "Properties"

    Public Property LineId() As String
        Get
            Return mLineId
        End Get
        Set(ByVal value As String)
            mLineId = value
        End Set
    End Property

    Public Property SuperBillId() As String
        Get
            Return mSuperBillId
        End Get
        Set(ByVal value As String)
            mSuperBillId = value
        End Set
    End Property

    Public Property Heading() As String
        Get
            Return mHeading
        End Get
        Set(ByVal value As String)
            mHeading = value
        End Set
    End Property

    Public Property HeadingOrder() As String
        Get
            Return mHeadingOrder
        End Get
        Set(ByVal value As String)
            mHeadingOrder = value
        End Set
    End Property

    Public Property Code() As String
        Get
            Return mCode
        End Get
        Set(ByVal value As String)
            mCode = value
        End Set
    End Property

    Public Property ShortDescription() As String
        Get
            Return mShortDescription
        End Get
        Set(ByVal value As String)
            mShortDescription = value
        End Set
    End Property

    Public Property Fees() As String
        Get
            Return mFees
        End Get
        Set(ByVal value As String)
            mFees = value
        End Set
    End Property


    Public Property PatientSuperBillId() As String
        Get
            Return mPatientSuperBillId
        End Get
        Set(ByVal value As String)
            mPatientSuperBillId = value
        End Set
    End Property

    Public Property IMO() As String
        Get
            Return mIMO
        End Get
        Set(ByVal value As String)
            mIMO = value
        End Set
    End Property

#End Region

End Class

Public Class CPT

#Region "Fields"
    Private mConnection As Connection
    Private mConnectionString
    Private mCPT As New CPTDB
#End Region

#Region "Property"
    Public ReadOnly Property Connection() As ElixirLibrary.Connection
        Get
            Return mConnection
        End Get
    End Property

    Public ReadOnly Property ConnectionString() As String
        Get
            Return mConnectionString
        End Get
    End Property
    Public Property CPT() As CPTDB
        Get
            Return mCPT
        End Get
        Set(ByVal value As CPTDB)
            mCPT = value
        End Set
    End Property
#End Region

#Region "Constructor"
    ''' <summary>
    ''' Creates new Conection Object based on Given Connection String 
    ''' </summary>
    ''' <param name="pConnectionString">
    ''' Contains Connection String 
    ''' </param>
    ''' <remarks>
    ''' Use when not using transaction
    ''' Must Specify Connection String other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnectionString As String)
        If pConnectionString = "" Then
            Throw New ArgumentException("ConnectionString can not be empty")
        End If

        mConnectionString = pConnectionString
        mConnection = New Connection(mConnectionString)
    End Sub

    Public Sub New()
        mConnection = New Connection()
    End Sub

    ''' <summary>
    ''' Assign given connection to the current Object
    ''' </summary>
    ''' <param name="pConnection">
    ''' Contains refrence to the connection object
    ''' </param>
    ''' <remarks>
    ''' Use when  using Transaction
    ''' Must Specify Connection other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnection As Connection)
        If pConnection Is Nothing Then
            Throw New ArgumentException("Connection can not be empty")
        End If

        mConnection = pConnection
    End Sub
#End Region

#Region "Method"

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="pCPTCode"></param>
    ''' <returns></returns>
    ''' <remarks>Affan Toor | 07-11-12</remarks>
    Public Function GetIMOCodeByCPT(ByVal pCPTCode As String) As System.Data.DataSet
        Dim lDs As DataSet = Nothing
        Dim lQuery As String = String.Empty

        Try
            Dim lSpParameter(0) As SpParameter

            lSpParameter(0).ParameterName = "@CPT"
            lSpParameter(0).ParameterType = ParameterType.Varchar
            lSpParameter(0).ParameterValue = pCPTCode

            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery("GetIMOCodeByCPT", lSpParameter)
            Else
                lDs = Connection.ExecuteQuery("GetIMOCodeByCPT", lSpParameter)
            End If

            Return lDs

        Catch ex As Exception
            Return Nothing
        End Try


    End Function

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="pDescription"></param>
    ''' <returns></returns>
    ''' <remarks>Affan Toor | 05-11-12</remarks>
    Public Function SearchCPT(ByVal pDescription As String) As System.Data.DataSet
        Dim lDs As DataSet = Nothing
        Dim lQuery As String = String.Empty

        Try
            Dim lSpParameter(0) As SpParameter

            lSpParameter(0).ParameterName = "@Description"
            lSpParameter(0).ParameterType = ParameterType.Varchar
            lSpParameter(0).ParameterValue = pDescription

            'lSpParameter(1).ParameterName = "@CPTCode"
            'lSpParameter(1).ParameterType = ParameterType.Varchar
            'lSpParameter(1).ParameterValue = pCPTCode

            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery("SearchProcedureCodes", lSpParameter)
            Else
                lDs = Connection.ExecuteQuery("SearchProcedureCodes", lSpParameter)
            End If

            Return lDs

        Catch ex As Exception
            Return Nothing
        End Try


    End Function

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="pDescription"></param>
    ''' <returns></returns>
    ''' <remarks>Author: Affan Toor | 03-01-13</remarks>
    Public Function SearchProcedureCodesByCPT(ByVal pCPTCode As String, ByVal pInsuranceCompanyID As String) As System.Data.DataSet
        Dim lDs As DataSet = Nothing
        Dim lQuery As String = String.Empty

        Try
            Dim lSpParameter(1) As SpParameter

            lSpParameter(0).ParameterName = "@CPTCode"
            lSpParameter(0).ParameterType = ParameterType.Varchar
            lSpParameter(0).ParameterValue = pCPTCode

            lSpParameter(1).ParameterName = "@InsuranceCompanyID"
            lSpParameter(1).ParameterType = ParameterType.Varchar
            lSpParameter(1).ParameterValue = pInsuranceCompanyID

            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery("SearchProcedureCodesByCPT", lSpParameter)
            Else
                lDs = Connection.ExecuteQuery("SearchProcedureCodesByCPT", lSpParameter)
            End If

            Return lDs

        Catch ex As Exception
            Return Nothing
        End Try


    End Function

    Public Function GetFeeByCPTAndInsuranceID(ByVal pCPTCode As String, ByVal pInsuranceCompanyID As String) As System.Data.DataSet
        Dim lDs As DataSet = Nothing
        Dim lQuery As String = String.Empty

        Try
            Dim lSpParameter(1) As SpParameter

            lSpParameter(0).ParameterName = "@CPTCode"
            lSpParameter(0).ParameterType = ParameterType.Varchar
            lSpParameter(0).ParameterValue = pCPTCode

            lSpParameter(1).ParameterName = "@InsuranceCompanyID"
            lSpParameter(1).ParameterType = ParameterType.Varchar
            lSpParameter(1).ParameterValue = pInsuranceCompanyID

            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery("GetFeeByCPTAndInsuranceID", lSpParameter)
            Else
                lDs = Connection.ExecuteQuery("GetFeeByCPTAndInsuranceID", lSpParameter)
            End If

            Return lDs

        Catch ex As Exception
            Return Nothing
        End Try


    End Function

    Public Function SearchProcedureCodesByCPT(ByVal pCPTCode As String) As System.Data.DataSet
        Dim lDs As DataSet = Nothing
        Dim lQuery As String = String.Empty

        Try
            Dim lSpParameter(0) As SpParameter

            lSpParameter(0).ParameterName = "@Description"
            lSpParameter(0).ParameterType = ParameterType.Varchar
            lSpParameter(0).ParameterValue = pCPTCode

            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery("SearchProcedureCodes", lSpParameter)
            Else
                lDs = Connection.ExecuteQuery("SearchProcedureCodes", lSpParameter)
            End If

            Return lDs

        Catch ex As Exception
            Return Nothing
        End Try


    End Function

    ''' <summary>
    ''' Delete Record Acoording to Given Condition
    ''' </summary>
    ''' <param name="lCondition"></param>
    ''' <remarks></remarks>
    Public Sub DeleteRecord(ByVal lCondition As String)

        Dim lSpParameter(1) As SpParameter

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = "SuperBillCPT"

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = lCondition

        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand("DeleteRecords", lSpParameter)
        Else
            Connection.ExecuteCommand("DeleteRecords", lSpParameter)
        End If

    End Sub

    Public Sub LogicalDelete(ByVal pCondition As String)
        Dim lQuery As String = String.Empty

        lQuery = "Update SuperBillCPT set IsDeleted = 'Y' where 1=1 " & pCondition


        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionQuery(lQuery)
        Else
            Connection.ExecuteQuery(lQuery)
        End If
    End Sub

    ''' <summary>
    ''' Delete Record on Primary Key
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub DeleteRecordByID()
        Dim lCondition As String

        lCondition = "AND SuperBillId= " & CPT.SuperBillId
        LogicalDelete(lCondition)

    End Sub
    ''' <summary>
    ''' Get All Records unconditional
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetAllRecords(ByVal lTable As String) As System.Data.DataSet
        Dim lCondition As String = ""
        Dim lDs As New DataSet()

        lDs = GetAllRecords(lCondition, lTable)

        Return lDs
    End Function
    ''' <summary>
    ''' Get  Records on specified Condition
    ''' </summary>
    ''' <param name="lCondition"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    ''' 
    Public Function GetAllRecords(ByVal lCondition As String, ByVal lTable As String) As System.Data.DataSet
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = lTable

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = lCondition

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("SelectAllRecords", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
        End If

        Return lDs

    End Function


    'THIS FUNCTION GETS THE TOP N RECORDS
    Public Function GetTopNRecords(ByVal pCondition As String, ByVal pTable As String, ByVal pSelectionCondition As String) As System.Data.DataSet
        Dim lSpParameter(2) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = pTable

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = pCondition

        lSpParameter(2).ParameterName = "@SelectionCond"
        lSpParameter(2).ParameterType = ParameterType.Varchar
        lSpParameter(2).ParameterValue = pSelectionCondition

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("SelectTopNRecords", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("SelectTopNRecords", lSpParameter)
        End If

        Return lDs

    End Function

    ''' <summary>
    ''' Insert record
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub InsertRecord()
        Dim lXmlDocument As New XmlDocument
        Dim lXmlElement As XmlElement

        lXmlDocument.LoadXml("<SuperBillCPTies></SuperBillCPTies>")
        lXmlElement = lXmlDocument.CreateElement("SuperBillCPT")


        With lXmlElement
            .SetAttribute("SuperBillId", CPT.SuperBillId)
            .SetAttribute("Heading", CPT.Heading)
            .SetAttribute("HeadingOrder", CPT.HeadingOrder)
            .SetAttribute("Code", CPT.Code)
            .SetAttribute("ShortDescription", CPT.ShortDescription)
            .SetAttribute("Fees", CPT.Fees)
            .SetAttribute("IsDeleted", "N")

            .SetAttribute("IMOCode", CPT.IMO)
        End With

        lXmlDocument.DocumentElement.AppendChild(lXmlElement.CloneNode(True))

        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand("InsertSuperBillCPT", lXmlDocument.InnerXml.ToString)
        Else
            Connection.ExecuteCommand("InsertSuperBillCPT", lXmlDocument.InnerXml.ToString)
        End If

    End Sub
    ''' <summary>
    ''' Update Record unconditional
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub UpdateRecord()
        Dim lCondition As String

        lCondition = "And SuperBillID = " & Me.CPT.SuperBillId
        UpdateRecord(lCondition)

    End Sub
    Public Sub UpdateRecord(ByVal lCondition As String)

        Dim lQuery As String

        With Me.CPT
            lQuery = "Update SuperBillCPT Set " _
                    & "SuperBillId =" & .SuperBillId & ", " _
                    & "Heading ='" & .Heading & "', " _
                    & "HeadingOrder =" & .HeadingOrder & ", " _
                    & "Code ='" & .Code & "', " _
                    & "ShortDescription ='" & .ShortDescription & "', " _
                    & "Fees ='" & .Fees & "' " _
                    & "Where 1 = 1 " _
                    & lCondition

        End With

        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand(lQuery)
        Else
            Connection.ExecuteCommand(lQuery)
        End If
    End Sub
    ''' <summary>
    ''' Get Single Record By Primary Key
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetRecordByID(ByVal lTable As String) As Boolean
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@Table"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = lTable

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = "And LineID = " & CPT.LineId

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("SelectAllRecords", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("SelectAllRecords", lSpParameter)
        End If


        With lDs.Tables(0)
            If .Rows.Count > 0 Then

                If lTable = "SuperBillCPT" Then
                    Me.CPT.LineId = .Rows(0)("LineId")
                    Me.CPT.SuperBillId = .Rows(0)("SuperBillId")
                    Me.CPT.Heading = .Rows(0)("Heading")
                    Me.CPT.HeadingOrder = .Rows(0)("HeadingOrder")
                    Me.CPT.Fees = .Rows(0)("Fees")
                Else
                    Me.CPT.LineId = ""
                    Me.CPT.SuperBillId = ""
                    Me.CPT.Heading = ""
                    Me.CPT.HeadingOrder = ""
                    Me.CPT.Fees = ""
                End If

                Me.CPT.Code = .Rows(0)("Code")
                Me.CPT.ShortDescription = .Rows(0)("ShortDescription")



                Return True
            End If
        End With

        Return False

    End Function

    Public Function GetCPTCollection(ByVal pCondition As String) As CPTColl
        Dim lCond As String
        Dim lDs As DataSet
        Dim lCPT As CPTDB
        Dim lCPTColl As New CPTColl()

        lCond = " And SuperBillId =" & Me.CPT.SuperBillId & " " & pCondition
        lDs = GetAllRecords(lCond, "SuperBillCPT")

        If lDs.Tables(0).Rows.Count > 0 Then

            For Each lRow As DataRow In lDs.Tables(0).Rows
                lCPT = New CPTDB()

                lCPT.Code = lRow("Code")
                lCPT.ShortDescription = lRow("ShortDescription")
                lCPT.Heading = lRow("Heading")
                lCPT.HeadingOrder = lRow("HeadingOrder")
                lCPT.Fees = lRow("Fees")
                lCPT.SuperBillId = lRow("SuperBillId")
                lCPT.LineId = lRow("LineId")
                lCPT.IMO = lRow("IMOCode")

                lCPTColl.Add(lCPT)
            Next
        End If

        Return lCPTColl
    End Function

    Public Function GetCPTForGenerate(ByVal pCond As String) As System.Data.DataSet
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@SuperBillId"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = Me.CPT.SuperBillId

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = pCond

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("GetCPTCodes", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("GetCPTCodes", lSpParameter)
        End If

        For lCounter As Integer = 0 To 2
            If lDs.Tables(0).Rows.Count < 10 Then
                AddRow(lDs.Tables(0))
            ElseIf lDs.Tables(0).Rows.Count < 10 Then
                AddRow(lDs.Tables(1))
            Else
                AddRow(lDs.Tables(2))
            End If
        Next


        Return lDs

    End Function

    Public Function GetICDForTemplatePrint(ByVal pCond As String, ByVal pTableName As String) As System.Data.DataSet
        Dim lSpParameter(1) As SpParameter
        Dim lDs As New DataSet()
        Dim lRecordCount As Int32 = 10

        lSpParameter(0).ParameterName = "@SuperBillId"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = Me.CPT.SuperBillId

        lSpParameter(1).ParameterName = "@Cond"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = pCond

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("GetCPTCodesDynamic", lSpParameter, pTableName)
        Else
            lDs = Connection.ExecuteQuery("GetCPTCodesDynamic", lSpParameter, pTableName)
        End If

        If (lDs.Tables(3).Rows.Count > 0) Then
            lRecordCount = lDs.Tables(3).Rows(0)("RecordCount")
        Else
            lRecordCount = 10
        End If

        For lCounter As Integer = 0 To 2
            If lDs.Tables(0).Rows.Count < lRecordCount Then
                AddRow(lDs.Tables(0))
            ElseIf lDs.Tables(1).Rows.Count < lRecordCount Then
                AddRow(lDs.Tables(1))
            Else
                AddRow(lDs.Tables(2))
            End If
        Next


        Return lDs

    End Function

    Public Function GetCPTForPreview(ByVal pCond As String) As System.Data.DataSet
        Dim lSpParameter(2) As SpParameter
        Dim lDs As New DataSet()

        lSpParameter(0).ParameterName = "@PatientSuperBillId"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = Me.CPT.PatientSuperBillId

        lSpParameter(1).ParameterName = "@SuperBillId"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = Me.CPT.SuperBillId

        lSpParameter(2).ParameterName = "@Cond"
        lSpParameter(2).ParameterType = ParameterType.Varchar
        lSpParameter(2).ParameterValue = pCond

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("GetCPTCodesForPreview", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("GetCPTCodesForPreview", lSpParameter)
        End If


        Dim lOthersCounter As Integer = lDs.Tables(2).Select("Heading like '%Others%'").Length

        For lCounter As Integer = 0 To 2
            If lDs.Tables(0).Rows.Count < 10 Then
                AddRowPreview(lDs.Tables(0))
            ElseIf lDs.Tables(0).Rows.Count < 10 Then
                AddRowPreview(lDs.Tables(1))
            Else
                If lOthersCounter + lCounter > 2 Then
                    Exit For
                End If
                AddRowPreview(lDs.Tables(2))
            End If
        Next


        Return lDs

    End Function

    Public Function GetCPTForPreviewPrint(ByVal pCond As String, ByVal pTableName As String) As System.Data.DataSet
        Dim lSpParameter(2) As SpParameter
        Dim lDs As New DataSet()
        Dim lRecordCount As Int32 = 10

        lSpParameter(0).ParameterName = "@PatientSuperBillId"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = Me.CPT.PatientSuperBillId

        lSpParameter(1).ParameterName = "@SuperBillId"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = Me.CPT.SuperBillId

        lSpParameter(2).ParameterName = "@Cond"
        lSpParameter(2).ParameterType = ParameterType.Varchar
        lSpParameter(2).ParameterValue = pCond

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("GetCPTCodesForPreview", lSpParameter, pTableName)
        Else
            lDs = Connection.ExecuteQuery("GetCPTCodesForPreview", lSpParameter, pTableName)
        End If


        Dim lOthersCounter As Integer = lDs.Tables(2).Select("Heading like '%Others%'").Length

        If (lDs.Tables(3).Rows.Count > 0) Then
            lRecordCount = lDs.Tables(3).Rows(0)("RecordCount")
        Else
            lRecordCount = 10
        End If

        For lCounter As Integer = 0 To 2
            If lDs.Tables(0).Rows.Count < lRecordCount Then
                AddRowPreview(lDs.Tables(0))
            ElseIf lDs.Tables(1).Rows.Count < lRecordCount Then
                AddRowPreview(lDs.Tables(1))
            Else
                If lOthersCounter + lCounter > 2 Then
                    Exit For
                End If
                AddRowPreview(lDs.Tables(2))
            End If
        Next


        Return lDs

    End Function


    Public Function GetCPTForClaim(ByVal pCond As String) As System.Data.DataSet
        Dim lSpParameter(2) As SpParameter
        Dim lDs As New DataSet()
        Dim lRecordCount As Int32 = 10

        lSpParameter(0).ParameterName = "@PatientSuperBillId"
        lSpParameter(0).ParameterType = ParameterType.Varchar
        lSpParameter(0).ParameterValue = Me.CPT.PatientSuperBillId

        lSpParameter(1).ParameterName = "@SuperBillId"
        lSpParameter(1).ParameterType = ParameterType.Varchar
        lSpParameter(1).ParameterValue = Me.CPT.SuperBillId

        lSpParameter(2).ParameterName = "@Cond"
        lSpParameter(2).ParameterType = ParameterType.Varchar
        lSpParameter(2).ParameterValue = pCond

        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery("GetCPTCodesForClaim", lSpParameter)
        Else
            lDs = Connection.ExecuteQuery("GetCPTCodesForClaim", lSpParameter)
        End If

        If (lDs.Tables(3).Rows.Count > 0) Then
            lRecordCount = lDs.Tables(3).Rows(0)("RecordCount")
        Else
            lRecordCount = 10
        End If

        'For lCounter As Integer = 0 To 2
        '    If lDs.Tables(0).Rows.Count < lRecordCount Then
        '        AddRowClaim(lDs.Tables(0))
        '    ElseIf lDs.Tables(1).Rows.Count < lRecordCount Then
        '        AddRowClaim(lDs.Tables(1))
        '    Else
        '        AddRowClaim(lDs.Tables(2))
        '    End If
        'Next


        Return lDs

    End Function


    Public Function GetCPTBySuperBillID(ByVal pPatientSuperBillID As String) As DataSet

        Dim lQuery As String = String.Empty


        Try

            lQuery = "select * from PatientCPT where PatientSuperBillID = " & pPatientSuperBillID & " and IsDeleted='N' Order By LineNumber "

            If Connection.IsTransactionAlive() Then
                GetCPTBySuperBillID = Connection.ExecuteTransactionQuery(lQuery)
            Else
                GetCPTBySuperBillID = Connection.ExecuteQuery(lQuery)
            End If



        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Private Sub AddRowPreview(ByRef pDataTable As DataTable)
        Dim lDr As DataRow

        lDr = pDataTable.NewRow()
        lDr(0) = 9999999 'Line number
        lDr(1) = "" ' Short Description
        lDr(2) = "N" 'IsSelected
        lDr(3) = "Others" 'Heading
        lDr(4) = 9999999 'HeadingOrder
        lDr(5) = "" ' Code
        lDr(6) = DBNull.Value 'Fees
        pDataTable.Rows.Add(lDr)

    End Sub



    Private Sub AddRowClaim(ByRef pDataTable As DataTable)
        Dim lDr As DataRow

        lDr = pDataTable.NewRow()
        lDr(0) = 9999999
        lDr(1) = ""
        lDr(2) = ""
        lDr(3) = "Others"
        lDr(4) = 9999999
        lDr(5) = ""
        lDr(6) = DBNull.Value
        pDataTable.Rows.Add(lDr)

    End Sub

    Private Sub AddRow(ByRef pDataTable As DataTable)
        Dim lDr As DataRow

        lDr = pDataTable.NewRow()
        lDr(0) = 9999999
        lDr(1) = 0
        lDr(2) = "Others"
        lDr(3) = 9999999
        lDr(4) = ""
        lDr(5) = ""
        lDr(6) = DBNull.Value
        pDataTable.Rows.Add(lDr)

    End Sub

    Public Function GetHeading() As DataSet
        Dim lQuery As String
        Dim lDs As DataSet

        lQuery = "SELECT DISTINCT Heading, HeadingOrder " _
                & "FROM SuperBillCPT " _
                & "WHERE SuperBillId =" & Me.CPT.SuperBillId & " " _
                & "ORDER BY HeadingOrder "


        If Connection.IsTransactionAlive() Then
            lDs = Connection.ExecuteTransactionQuery(lQuery)
        Else
            lDs = Connection.ExecuteQuery(lQuery)
        End If

        Return lDs

    End Function

#End Region

End Class

Public Class CPTColl
    Inherits CollectionBase

    Public Function Add(ByVal pCPT As CPTDB) As Integer
        Return List.Add(pCPT)
    End Function

    Public Sub Remove(ByVal pCPT As CPTDB)
        Dim lIndex As Integer

        lIndex = IndexOf(pCPT)

        If lIndex > -1 Then
            List.RemoveAt(lIndex)
        End If

    End Sub

    Default Public Property Item(ByVal Index As Integer) As CPTDB
        Get
            Return CType(List.Item(Index), CPTDB)
        End Get
        Set(ByVal Value As CPTDB)
            List.Item(Index) = Value
        End Set
    End Property

    Public Shadows Function Count() As Integer
        Return List.Count
    End Function

    Public Function IndexOf(ByVal obj As Object) As Integer
        Dim lIndex As Integer = 0
        Dim lFound As Integer = 0

        For Each lObj As Object In List
            lFound = CType(lObj, CPTDB).Code.CompareTo(CType(obj, CPTDB).Code)
            If lFound = 0 Then
                Return lIndex
            End If
            lIndex += 1
        Next
        Return -1

    End Function

    Public Function CheckHeadingExistance(ByVal obj As Object) As Boolean
        Dim lIndex As Integer = 0
        Dim lFound As Integer = 0

        For Each lObj As Object In List
            lFound = CType(lObj, CPTDB).Heading.ToUpper.CompareTo(CType(obj, CPTDB).Heading.ToUpper)
            If lFound = 0 Then
                Return True
            End If
            lIndex += 1
        Next
        Return False

    End Function

End Class