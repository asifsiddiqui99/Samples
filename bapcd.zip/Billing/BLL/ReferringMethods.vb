Imports Microsoft.VisualBasic

Public Class ReferringMethods

    Public Shared Function AddReferring(ByVal pReferringProviderDB As ReferringProviderDB) As String
        Dim lReferringProvider As ReferringProvider = Nothing
        Dim lUser As User = CType(HttpContext.Current.Session.Item("User"), User)
        Dim lResult As String

        Try
            lReferringProvider = New ReferringProvider(lUser.ConnectionString)
            lReferringProvider.ReferringProviderDB = pReferringProviderDB
            lResult = lReferringProvider.InsertReferringProvider()

            Return lResult

        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Shared Function GetAllRecords(ByVal pCondition As String) As DataSet

        Dim lUser As User = CType(HttpContext.Current.Session.Item("User"), User)

        Dim lReferringProvider As ReferringProvider = Nothing
        lReferringProvider = New ReferringProvider(lUser.ConnectionString)

        Dim lDs As DataSet

        Try
            lDs = lReferringProvider.GetAllRecords(lUser, pCondition)

            Return lDs

        Catch ex As Exception

        End Try

    End Function

    Public Shared Function GetReferringProvider(ByVal pCondition As String) As DataSet

        Dim lUser As User = CType(HttpContext.Current.Session.Item("User"), User)

        Dim lReferringProvider As ReferringProvider = Nothing
        lReferringProvider = New ReferringProvider(lUser.ConnectionString)

        Dim lDs As DataSet

        Try
            lDs = lReferringProvider.GetReferringProvider(lUser, pCondition)

            Return lDs

        Catch ex As Exception

        End Try

    End Function

    Public Shared Function EditReferringProvider(ByVal pReferringProviderDB As ReferringProviderDB) As Boolean
        Dim lReferringProvider As ReferringProvider = Nothing
        Dim lUser As User = CType(HttpContext.Current.Session.Item("User"), User)
        Try
            lReferringProvider = New ReferringProvider(lUser.ConnectionString)
            lReferringProvider.ReferringProviderDB = pReferringProviderDB
            Return lReferringProvider.UpdateReferringProvider()

        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Shared Function DeleteReferringProvider(ByVal pReferringProviderDB As ReferringProviderDB) As Boolean
        Dim lReferringProvider As ReferringProvider = Nothing
        Dim lUser As User = CType(HttpContext.Current.Session.Item("User"), User)
        Try
            lReferringProvider = New ReferringProvider(lUser.ConnectionString)
            lReferringProvider.ReferringProviderDB = pReferringProviderDB
            Return lReferringProvider.DeleteReferringProvider()

        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Shared Function CheckExistEdit(ByVal pNPI As String, ByVal pID As String) As Boolean
        Dim lReferringProvider As ReferringProvider = Nothing
        Dim lUser As User = CType(HttpContext.Current.Session.Item("User"), User)
        Dim lResultDS As New DataSet
        Try
            lReferringProvider = New ReferringProvider(lUser.ConnectionString)
            lResultDS = lReferringProvider.CheckNpiExistEdit(pNPI, pID)
            If (lResultDS.Tables(0).Rows.Count > 0) Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
        End Try
    End Function
    Public Shared Function CheckExist(ByVal pNPI As String) As Boolean
        Dim lReferringProvider As ReferringProvider = Nothing
        Dim lUser As User = CType(HttpContext.Current.Session.Item("User"), User)
        Dim lResultDS As New DataSet
        Try
            lReferringProvider = New ReferringProvider(lUser.ConnectionString)
            lResultDS = lReferringProvider.CheckNpiExist(pNPI)
            If (lResultDS.Tables(0).Rows.Count > 0) Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
        End Try
    End Function



    Public Shared Function GetSpeciality(ByVal pConnectionString As String) As DataSet
        Dim lReferringProvider As ReferringProvider = Nothing

        Dim lResultDS As New DataSet
        Try
            lReferringProvider = New ReferringProvider(pConnectionString)
            lResultDS = lReferringProvider.GetSpeciality()
            If (lResultDS.Tables(0).Rows.Count > 0) Then
                Return lResultDS
            Else
                Return Nothing
            End If
        Catch ex As Exception
            Return Nothing
        End Try
    End Function
End Class
