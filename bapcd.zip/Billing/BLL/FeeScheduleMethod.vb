Imports Microsoft.VisualBasic

Public Class FeeScheduleMethod
    Public Shared Function SearchFeeSchedule(ByVal pUser As User, ByVal pCond As Integer) As DataSet
        Dim lFeeScheduleDAL As New FeeSchedule(pUser.ConnectionString)
        Dim lDs As New DataSet
        Try
            lDs = lFeeScheduleDAL.SearchFeeSchedule(pCond)
            Return lDs
        Catch ex As Exception
            Return Nothing
        End Try

        Return lDs

    End Function

    'this method is for filling the Combo items'
    Public Shared Function GetFavInsurance(ByVal pUser As User) As DataSet
        Dim lFeeScheduleDAL As New FeeSchedule(pUser.ConnectionString)
        Dim lDs As New DataSet
        Try
            lDs = lFeeScheduleDAL.GetFavInsurance()
            Return lDs
        Catch ex As Exception
            Return Nothing
        End Try

        Return lDs

    End Function

    Public Shared Function GetAllFeeSchedule(ByVal pUser As User) As DataSet
        Dim lFeeScheduleDAL As New FeeSchedule(pUser.ConnectionString)
        Dim lDs As New DataSet
        Try
            lDs = lFeeScheduleDAL.GetAllFeeSchedule()
            Return lDs
        Catch ex As Exception
            Return Nothing
        End Try

        Return lDs

    End Function


    Public Shared Function DeleteFeeScheduleByHdrID(ByVal pUser As User, ByVal pCond As Integer) As Boolean
        Dim lFeeScheduleDAL As New FeeSchedule(pUser.ConnectionString)
        Dim lBoolean As Boolean
        Try
            lBoolean = lFeeScheduleDAL.DeleteFeeSchedule(pCond)
            Return lBoolean
        Catch ex As Exception
            Return Nothing
        End Try

        Return lBoolean

    End Function
    Public Shared Function DeleteFeeScheduleImport(ByVal pConn As Connection, ByVal pFavID As Integer) As Boolean
        Dim lFeeScheduleDAL As New FeeSchedule(pConn)
        Dim lBoolean As Boolean
        Try
            lBoolean = lFeeScheduleDAL.DeleteFeeScheduleImport(pFavID)
            Return lBoolean
        Catch ex As Exception
            Return Nothing
        End Try

        Return lBoolean

    End Function
    Public Shared Function AutocompeteQuery(ByVal pUser As User, ByVal pCond As String) As DataSet
        Dim lFeeScheduleDAL As New FeeSchedule(pUser.ConnectionString)
        Dim lDs As New DataSet
        Try
            lDs = lFeeScheduleDAL.AutocompeteQuery(pCond)
            Return lDs
        Catch ex As Exception
            Return Nothing
        End Try

        Return lDs

    End Function

    Public Shared Function AutocompeteQueryForAddFeeSch(ByVal pUser As User, ByVal pCond As String) As DataSet
        Dim lFeeScheduleDAL As New FeeSchedule(pUser.ConnectionString)
        Dim lDs As New DataSet
        Try
            lDs = lFeeScheduleDAL.AutocompeteQueryForAddFeeSch(pCond)
            Return lDs
        Catch ex As Exception
            Return Nothing
        End Try

        Return lDs

    End Function


    Public Shared Function GetCompanyName(ByVal pUser As User, ByVal pCond As Integer) As DataSet
        Dim lFeeScheduleDAL As New FeeSchedule(pUser.ConnectionString)
        Dim lDs As New DataSet
        Try
            lDs = lFeeScheduleDAL.GetCompanyName(pCond)
            Return lDs
        Catch ex As Exception
            Return Nothing
        End Try

        Return lDs

    End Function
    Public Shared Function FillSelectedGrid(ByVal pUser As User, ByVal pCond As Integer) As DataSet
        Dim lFeeScheduleDAL As New FeeSchedule(pUser.ConnectionString)
        Dim lDs As New DataSet
        Try
            lDs = lFeeScheduleDAL.FillSelectedGrid(pCond)
            Return lDs
        Catch ex As Exception
            Return Nothing
        End Try

        Return lDs

    End Function

    Public Shared Function GetSelectedCmpnyNames(ByVal pUser As User, ByVal pCond As Integer) As DataSet
        Dim lFeeScheduleDAL As New FeeSchedule(pUser.ConnectionString)
        Dim lDs As New DataSet
        Try
            lDs = lFeeScheduleDAL.GetSelectedCmpnyNames(pCond)
            Return lDs
        Catch ex As Exception
            Return Nothing
        End Try

        Return lDs

    End Function

    ''''''imrans method''''''''''''''''''''
    Public Shared Function SearchBillingProvider(ByVal pUser As User, ByVal pCond As String) As DataSet
        Dim lFeeScheduleDAL As New FeeSchedule(pUser.ConnectionString)
        Dim lDs As New DataSet
        Try
            lDs = lFeeScheduleDAL.SearchFeeSchedule(pCond)
            Return lDs
        Catch ex As Exception
            Return Nothing
        End Try

        Return lDs

    End Function

    Public Shared Function SaveFeeSchedules(ByVal pUser As User, ByVal pGridView As GridView, ByVal pFavID As Integer, ByVal pCampanyName As String, ByVal hdrID As Integer, ByVal pUpdate As String) As Boolean
        Dim lFeeScheduleDAL As New FeeSchedule(pUser.ConnectionString)
        Dim lDs As New DataSet
        Dim lBoolean As Boolean
        Try
            lBoolean = lFeeScheduleDAL.SaveFeeSchedule(pGridView, pFavID, pCampanyName, hdrID, pUpdate)
            Return lBoolean
        Catch ex As Exception

        End Try
    End Function

    Public Shared Function GetFavouriteInsurance(ByVal pUser As User) As DataSet
        Dim lFeeScheduleDAL As New FeeSchedule(pUser.ConnectionString)

        Try
            Dim lds As New DataSet
            lds = lFeeScheduleDAL.GetFavouriteInsurance()
            Return lds
        Catch ex As Exception
            Return Nothing
        End Try
    End Function
 

    Public Shared Function GetFeeSchedule(ByVal pUser As User, ByVal pFeeScduleID As Integer) As DataSet
        Dim lFeeScheduleDAL As New FeeSchedule(pUser.ConnectionString)
        Dim lDs As New DataSet
        Try
            lDs = lFeeScheduleDAL.GetFeeSchedule(pFeeScduleID)
            Return lDs
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Public Shared Function SaveFeeSchedules(ByVal pConn As Connection, ByVal pXmlDoc As String) As Boolean
        Dim lFeeScheduleDAL As New FeeSchedule(pConn)
        Dim lDs As New DataSet
        Dim lBoolean As Boolean
        Try
            lBoolean = lFeeScheduleDAL.SaveFeeSchedule(pXmlDoc)
            Return lBoolean
        Catch ex As Exception

        End Try
    End Function

    Public Shared Function GetModifiers(ByVal pUser As User, ByVal pCondition As String) As DataSet
        Dim lFeeScheduleDAL As New FeeSchedule(pUser.ConnectionString)
        Dim lDs As New DataSet
        Try
            Return lFeeScheduleDAL.GetModifiers(pCondition)

        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Public Shared Function DeleteFeeSchedule(ByVal pUser As User, ByVal pFavID As String) As Boolean
        Dim lFeeScheduleDAL As New FeeSchedule(pUser.ConnectionString)
        Dim lDs As New DataSet
        Dim lBoolean As Boolean
        Try
            lBoolean = lFeeScheduleDAL.DeleteFeeScheduleImport(pFavID)
            Return lBoolean
        Catch ex As Exception

        End Try
    End Function
    ''''''''''''''''''''''''''''''''''''''''
End Class
