Imports Microsoft.VisualBasic
Imports System.Xml
Imports ClaimLibrary
Imports Rebex
Imports Rebex.Net


Public Class ClaimEDI837Methods
    Public Shared mLastHL As Int32
    Public Shared mSubscriberHL As Int32
    Public Shared mParentHL As Int32
    Public Shared Function SaveToFile(ByVal pInformation As String, ByVal pFileName As String) As String
        Dim lFileStream As FileStream = Nothing
        Dim lUser As User
        Dim lStreamWriter As StreamWriter = Nothing
        Dim lDirectoryInfo As DirectoryInfo
        Dim lPath As String = ""
        'Dim lFileName As String = ""
        If (pFileName = "") Then
            pFileName = Date.Now.ToString("yyyyMMddTHHmmss") & ".txt"
        End If
        Dim lSavePath As String = ""


        lUser = CType(HttpContext.Current.Session.Item("User"), User)

        Try

            lPath = CType(ConfigurationManager.AppSettings("ClaimRquestPath"), String)
            lDirectoryInfo = New DirectoryInfo(lPath)
            If Not lDirectoryInfo.Exists Then
                lDirectoryInfo.Create()
            End If
            lPath = CType(ConfigurationManager.AppSettings("ClaimRquestPath"), String) + lUser.ClinicId
            lDirectoryInfo = New DirectoryInfo(lPath)
            If Not lDirectoryInfo.Exists Then
                lDirectoryInfo.Create()
            End If
            lPath = CType(ConfigurationManager.AppSettings("ClaimRquestPath"), String) + lUser.ClinicId + "\ClaimRequest837\"
            lDirectoryInfo = New DirectoryInfo(lPath)
            If Not lDirectoryInfo.Exists Then
                lDirectoryInfo.Create()
            End If
            'lFileName = Date.Now.ToString("yyyyMMddTHHmmss") & ".txt"

            'Dim pPath As String = "C:\ENS\ClaimRequest\" & Date.Now.ToString("yyyyMMddTHHmmss") & ".xml"
            ''Dim lSavePath As String = "C:\ENS\ClaimRequest\" & Date.Now.ToString("yyyyMMddTHHmmss") & ".txt"
            lSavePath = lPath & pFileName
            'Dim pECCPath As String = "C:\ENS\ClaimRequest\" & "ClaimRequestMapping" & ".ecc"




            'If File.Exists(pPath) Then                
            '    Throw New Exception("File already exists")
            'End If

            'lFileStream = New FileStream(lSavePath, FileMode.OpenOrCreate)
            If File.Exists(lSavePath) Then
                lFileStream = New FileStream(lSavePath, FileMode.Truncate)
            Else
                lFileStream = New FileStream(lSavePath, FileMode.Create)
            End If

            lStreamWriter = New StreamWriter(lFileStream)


            lStreamWriter.Write(pInformation.ToUpper())
            lStreamWriter.Flush()

        Catch ex As Exception
            Return ""
        Finally
            lStreamWriter.Close()
            lFileStream.Close()
        End Try
        Return lSavePath

    End Function

    ''***************** 21 Sep 2010 Done in refiling and adjustment Cycle 
#Region "Claim Batch Creation and Send"

    Public Shared Function Make837RequestBatchNew(ByVal pClaimId As Int32(), ByVal pBatchID As String, ByVal pBatchDisplayID As String) As String
        If (pClaimId.Length < 1) Then
            Return ""
        End If




        Dim pUser As User = CType(HttpContext.Current.Session("User"), User)
        Dim lClinic As Clinic = New Clinic(pUser.ConnectionString)
        Dim lEDIMessage As String = ""
        Dim lCurrentFilePath As String = ""
        Dim lGatewayFtpClaimRequestMode As String = CType(ConfigurationManager.AppSettings("GatewayFtpClaimRequestMode"), String).ToUpper

        'Dim lHcfa As New HCFAUpdated(pUser.ConnectionString)


        Dim lCurrentFileResult As Boolean = False
        Dim lSendGatewayResult As Boolean = False
        Dim lFileArchiveResult As Boolean = False

        ''Global Variable initialization
        mLastHL = 0
        mSubscriberHL = 0 'pClaimId.Length


        lClinic.Clinic.ClinicId = pUser.ClinicId
        lClinic.GetRecordByIdState()


        'lBillingProvider.GetRecordByID()
        'lBillingProvider.BillingProvider = lHcfa.HCFAUpdated.BillingPvd


        Dim lInterChange As New ClaimLibrary.MsgInterchange()
        Dim lGs As ClaimLibrary.GrpInterchangeFunctionalGroup
        Dim lTransaction As ClaimLibrary.Msg837_PRO

        Try

            With lInterChange.ISA
                .AuthorizationInformationQualifier.Value = "00"
                .AuthorizationInformation.Value = "          "
                .SecurityInformationQualifier.Value = "00"
                .SecurityInformation.Value = "          "
                .InterchangeIDQualifier1.Value = "ZZ"

                If lGatewayFtpClaimRequestMode = "P" Then
                    .InterchangeSenderID.Value = Left(lClinic.Clinic.GatewayFtpUserID + "               ", 15)
                Else
                    .InterchangeSenderID.Value = "TEST           "
                End If
                .InterchangeIDQualifier2.Value = "ZZ"
                .InterchangeReceiverID.Value = "431420764      "
                '.InterchangeDate.Value = Date.Now.ToString("yyyyMMdd")
                .InterchangeDate.Value = Format(Date.Now, "yyMMdd")
                .InterchangeTime.Value = Date.Now.ToString("HHmm")
                .InterchangeControlStandardsIdentifier.Value = "U"
                .InterchangeControlVersionNumber.Value = "00401"
                .InterchangeControlNumber.Value = "000000001"
                .AcknowledgmentRequested.Value = "1"
                '.UsageIndicator.Value = "P" 'Production
                .UsageIndicator.Value = lGatewayFtpClaimRequestMode '"T" 'Testing
                .ComponentElementSeparator.Value = ":"

                lGs = lInterChange.FunctionalGroup.Append()


            End With

            With lGs.GS
                .FunctionalIdentifierCode.Value = "HC"

                If lGatewayFtpClaimRequestMode = "P" Then
                    .ApplicationSendersCode.Value = lClinic.Clinic.GatewayFtpUserID
                Else
                    .ApplicationSendersCode.Value = "TEST"
                End If

                .ApplicationReceiversCode.Value = "431420764"
                .Date.Value = Date.Now.ToString("yyyyMMdd")
                .Time.Value = Date.Now.ToString("HHmm")
                .GroupControlNumber.Value = "123"
                .ResponsibleAgencyCode.Value = "X"
                .VersionReleaseIndustryIdentifierCode.Value = "004010X098A1"


            End With

            lTransaction = lGs.Transactions.Append("837_PRO")

            With lTransaction.ST
                .TransactionSetIdentifierCode.Value = "837"
                .TransactionSetControlNumber.Value = "000000001"
            End With

            With lTransaction.BHT
                .HierarchicalStructureCode.Value = "0019"
                .TransactionSetPurposeCode.Value = "00"
                .ReferenceIdentification.Value = pBatchID '"0123"
                .Date.Value = Date.Now.ToString("yyyyMMdd")
                .Time.Value = Date.Now.ToString("HHmm")
                .TransactionTypeCode.Value = "CH"
            End With

            With lTransaction.REF
                .ReferenceIdentificationQualifier.Value = "87"
                .ReferenceIdentification.Value = "004010X098A1"
            End With


            ''''''' Sender''''''''''''''''''
            With lTransaction.L1000A_837PRO.NM1
                .EntityIdentifierCode1.Value = "41"
                .EntityTypeQualifier.Value = "2"
                .NameLastOrOrganizationName.Value = "OA Systems"
                .NameFirst.Value = ""
                .NameMiddle.Value = ""
                .NamePrefix.Value = ""
                .NameSuffix.Value = ""
                .IdentificationCodeQualifier.Value = "46"
                .IdentificationCode.Value = "XOA00205"
                .EntityRelationshipCode.Value = ""
                .EntityIdentifierCode2.Value = ""
            End With

            Dim lPer As ClaimLibrary.SegPER
            lPer = lTransaction.L1000A_837PRO.PER.Append()



            With lPer
                .ContactFunctionCode.Value = "IC"
                .ContactName.Value = "Rifat Ali Syed"
                .CommunicationNumberQualifier1.Value = "TE"
                .CommunicationNumber1.Value = "9094661605" 'lClinic.Clinic.Phone1 '"XOA00205"
                .CommunicationNumberQualifier2.Value = ""
                .CommunicationNumber2.Value = ""
                .CommunicationNumberQualifier3.Value = ""
                .CommunicationNumber3.Value = ""
                .ContactInquiryReference.Value = ""
            End With

            ''''''''''''' Sender'''''''''''''''''

            ''''''''''''' receiver'''''''''''''''''
            With lTransaction.L1000B_837PRO.NM1
                .EntityIdentifierCode1.Value = "40"
                .EntityTypeQualifier.Value = "2"
                '.NameLastOrOrganizationName.Value = "Electronic Network Systems, Inc."
                .NameLastOrOrganizationName.Value = "Gateway EDI Inc"
                .NameFirst.Value = ""
                .NameMiddle.Value = ""
                .NamePrefix.Value = ""
                .NameSuffix.Value = ""
                .IdentificationCodeQualifier.Value = "46"
                .IdentificationCode.Value = "841162764"
                .EntityRelationshipCode.Value = ""
                .EntityIdentifierCode2.Value = ""
            End With
            ''''''''''''' Receiver'''''''''''''''''



            ''****************************************************
            ''****************************************************
            ''****************************************************
            ''*************************************** Loop WOrk STart Claim Batch ************************************
            For Each lHcfaID As Int32 In pClaimId
                mSubscriberHL = mSubscriberHL - 1
                'Dim lHcfa As New HCFA(pUser.ConnectionString)
                Dim lHcfa As New HCFAUpdated(pUser.ConnectionString)
                lHcfa.HCFAUpdated.HCFAID = lHcfaID
                lHcfa.GetRecordByID()

                Dim pHCFADB As New HCFADBUpdated
                pHCFADB = lHcfa.HCFAUpdated

                Dim lHcfaDtlCol As HCFADetailCollUpdated = LoadClaimCpt(pHCFADB.HCFAID)

                Dim lPrimaryInsuraneSelf As Boolean = False
                Dim lSecondaryInsuraneSelf As Boolean = False
                Dim lPrimaryInsuranceExist As Boolean = False
                Dim lSecondaryInsuranceExist As Boolean = False
                Dim lPrimaryInsuranceCompanyId As Int32 = 0
                Dim lSecondaryInsuranceCompanyId As Int32 = 0
                Dim lPatient As New PatientExtended(pUser.ConnectionString)

                ''lPatient.Patient.PatientID = pHCFADB.PatientAccountNumber
                ''lPatient.GetPatientWithDetailsByID()

                lPatient.Patient = lHcfa.HCFAUpdated.Patient

                Dim lPrimaryInsurerPatient As New PatientExtended(pUser.ConnectionString)
                Dim lPrimaryInsuranceCompany As New Insurance(pUser.ConnectionString)
                Dim lSecondaryInsurerPatient As New PatientExtended(pUser.ConnectionString)
                Dim lSecondaryInsuranceCompany As New Insurance(pUser.ConnectionString)
                Dim lBillingProvider As BillingProvider = New BillingProvider(pUser.ConnectionString)
                lBillingProvider.BillingProvider = lHcfa.HCFAUpdated.BillingPvd
                Dim lClaimId As String = ""

                Dim lMainInsurance As New PatientInsuranceDetail(pUser.ConnectionString)
                Dim lOtherInsurance As New PatientInsuranceDetail(pUser.ConnectionString)

                Dim lMainInsuranceSelf As Boolean = False
                Dim lOtherInsuranceSelf As Boolean = False
                Dim lMainInsuranceExist As Boolean = False
                Dim lOtherInsuranceExist As Boolean = False


                '''''''''''''' Main Insurance And Insurer Checking Logic

                '************* Loading Main Insurance with HCFA not from Parent Record ****************
                lMainInsurance.PatientInsuranceDetail.Insurer = lHcfa.HCFAUpdated.InsurerPatient
                lMainInsurance.PatientInsuranceDetail.InsuranceCompany = lHcfa.HCFAUpdated.MainInsuranceCompany
                lMainInsurance.PatientInsuranceDetail.PInsurance = lHcfa.HCFAUpdated.MainPatientInsurance
                '************* Loading Main Insurance with HCFA not from Parent Record ****************

                If (lMainInsurance.PatientInsuranceDetail.PInsurance.SubscriberID <> "" And lMainInsurance.PatientInsuranceDetail.PInsurance.SubscriberID <> "0") Then
                    lMainInsuranceExist = True
                Else
                    lMainInsuranceExist = False
                End If

                If (lMainInsuranceExist) Then
                    If (lMainInsurance.PatientInsuranceDetail.PInsurance.InsurerId <> 0) Then
                        lMainInsuranceSelf = False
                    Else
                        lMainInsuranceSelf = True
                    End If
                End If

                '''''''''''''' Main Insurance And Insurer Checking Logic

                '''''''''''''' Other Insurance And Insurer Checking Logic

                '************* Loading Other Insurance with HCFA not from Parent Record ****************
                lOtherInsurance.PatientInsuranceDetail.Insurer = lHcfa.HCFAUpdated.OtherInsurerPatient
                lOtherInsurance.PatientInsuranceDetail.InsuranceCompany = lHcfa.HCFAUpdated.OtherInsuranceCompany
                lOtherInsurance.PatientInsuranceDetail.PInsurance = lHcfa.HCFAUpdated.OtherPatientInsurance
                '************* Loading Other Insurance with HCFA not from Parent Record ****************

                If (lOtherInsurance.PatientInsuranceDetail.PInsurance.SubscriberID <> "" And lOtherInsurance.PatientInsuranceDetail.PInsurance.SubscriberID <> "0") Then
                    lOtherInsuranceExist = True
                Else
                    lOtherInsuranceExist = False
                End If

                If (lOtherInsuranceExist) Then
                    If (lOtherInsurance.PatientInsuranceDetail.PInsurance.InsurerId <> 0) Then
                        lOtherInsuranceSelf = False
                    Else
                        lOtherInsuranceSelf = True
                    End If
                End If

                '''''''''''''' Other Insurance And Insurer Checking Logic






                'Dim lConnection As New Connection(pUser.ConnectionString)

                'Dim lQuery As String
                'lQuery = "Exec GetMultipleTableForClaimEDI " & pUser.ClinicId & "," & IIf(pHCFADB.RefferingProviderID <> "", pHCFADB.RefferingProviderID, 0) & "," & pHCFADB.DoctorUserID & "," & lPrimaryInsuranceCompanyId & "," & lSecondaryInsuranceCompanyId & "," & pHCFADB.FacilityId


                'Dim lDs As New DataSet
                'lDs = lConnection.ExecuteQuery(lQuery)



                Dim lReferringProvider As New ReferringProvider(pUser.ConnectionString)
                'lReferringProvider.GetRecordByID(lDs.Tables(1))
                lReferringProvider.ReferringProviderDB = lHcfa.HCFAUpdated.ReferencePvd

                Dim lRenderingProvider As New Employee(pUser.ConnectionString)
                'lRenderingProvider.GetRecordByID(lDs.Tables(2))
                lRenderingProvider.Employee = lHcfa.HCFAUpdated.RenderingProvider




                Dim lFacility As New Facility(pUser.ConnectionString)
                'If (Not lDs.Tables(5) Is Nothing) Then
                '    lFacility.GetRecordById(lDs.Tables(5))
                'End If
                lFacility.FacilityDB = lHcfa.HCFAUpdated.ServiceFacility


                '''''''''''''''' 2000A Billing Provider Starts''''''''''
                Dim l2000A As Grp837_PROL2000A_837PRO
                l2000A = lTransaction.L2000A_837PRO.Append()

                With l2000A.HL_1
                    mLastHL = mLastHL + 1
                    mParentHL = mLastHL
                    .HierarchicalIdNumber.Value = mLastHL '"1"
                    .HierarchicalParentIdNumber.Value = ""
                    .HierarchicalLevelCode.Value = "20"
                    .HierarchicalChildCode.Value = "1"
                End With


                ''With l2000A.PRV
                ''    .ProviderCode.Value = "PT"
                ''    .ReferenceIdentificationQualifier.Value = "ZZ"
                ''    .ReferenceIdentification.Value = "213EP1101X"
                ''End With

                With l2000A.L2010AA_837PRO1.NM1
                    .EntityIdentifierCode1.Value = "85"
                    If (lBillingProvider.BillingProvider.FirstName <> "") Then
                        .EntityTypeQualifier.Value = "1"
                    Else
                        .EntityTypeQualifier.Value = "2"
                    End If
                    .NameLastOrOrganizationName.Value = lBillingProvider.BillingProvider.LastName  '"Palm Desert Urgent Care"
                    .NameFirst.Value = lBillingProvider.BillingProvider.FirstName
                    .NameMiddle.Value = lBillingProvider.BillingProvider.MiddleName
                    .NamePrefix.Value = ""
                    .NameSuffix.Value = ""
                    .IdentificationCodeQualifier.Value = "XX"
                    .IdentificationCode.Value = lBillingProvider.BillingProvider.NPI
                    .EntityRelationshipCode.Value = ""
                    .EntityIdentifierCode2.Value = ""
                End With

                With l2000A.L2010AA_837PRO1.N3
                    .AddressInformation1.Value = lBillingProvider.BillingProvider.AddressLine1 'lClinic.Clinic.AddressLine1  '"PO Box 1118"
                    .AddressInformation2.Value = lBillingProvider.BillingProvider.AddressLine2 'lClinic.Clinic.AddressLine2
                End With

                With l2000A.L2010AA_837PRO1.N4
                    .CityName.Value = lBillingProvider.BillingProvider.City 'lClinic.Clinic.City  '"Palm Desert"
                    .StateOrProvinceCode.Value = lBillingProvider.BillingProvider.State
                    .PostalCode.Value = lBillingProvider.BillingProvider.ZipCode
                    .CountryCode.Value = ""
                    .LocationQualifier.Value = ""
                    .LocationIdentifier.Value = ""
                End With

                Dim lRef As SegREF


                lRef = l2000A.L2010AA_837PRO1.REF1.Append
                With lRef

                    .ReferenceIdentificationQualifier.Value = "EI"
                    .ReferenceIdentification.Value = lBillingProvider.BillingProvider.TaxID  'lClinic.Clinic.FacilityCode '
                    .Description.Value = ""


                End With

                '************************ 2000A Billing Provider End


                '************************ 2000B Subscriber Starts 

                Dim l2000B As Grp837_PROL2000B_837PRO
                l2000B = l2000A.L2000B_837PRO.Append()


                With l2000B.HL_5
                    mLastHL = mLastHL + 1
                    .HierarchicalIdNumber.Value = mLastHL
                    mSubscriberHL = mLastHL
                    .HierarchicalParentIdNumber.Value = mParentHL '"1"
                    .HierarchicalLevelCode.Value = "22"
                    'If (lSubscriberHL > 0) Then
                    If (lMainInsuranceSelf) Then
                        .HierarchicalChildCode.Value = "0"
                    Else
                        .HierarchicalChildCode.Value = "1"
                    End If
                    'ElseIf (Not lMainInsuranceSelf) Then
                    '.HierarchicalChildCode.Value = "1"
                    'Else
                    '.HierarchicalChildCode.Value = "0"
                    'End If

                End With


                With l2000B.SBR
                    .PayerResponsibilitySequenceNumberCode.Value = "P"
                    If (lMainInsuranceSelf) Then
                        .IndividualRelationshipCode.Value = "18"
                    Else
                        .IndividualRelationshipCode.Value = ""
                        'Select Case lPatient.Patient.PrimaryInsurance.RelationshipToPrimaryInsurer.ToUpper
                        '    Case "SPOUSE"
                        '        .IndividualRelationshipCode.Value = "01"
                        '    Case "CHILD"
                        '        .IndividualRelationshipCode.Value = "19"
                        '    Case "OTHER"
                        '        .IndividualRelationshipCode.Value = "G8"
                        'End Select
                    End If
                    .ReferenceIdentification.Value = lMainInsurance.PatientInsuranceDetail.PInsurance.GroupNo
                    .SubscriberName.Value = lMainInsurance.PatientInsuranceDetail.PInsurance.PlanName  '""

                    If (.PayerResponsibilitySequenceNumberCode.Value <> "P" And pHCFADB.MainInsuranceCompany.Type.ToUpper = "MEDICARE") Then
                        .InsuranceTypeCode.Value = "" 'type of insurance policy within specified program
                    Else
                        .InsuranceTypeCode.Value = ""
                    End If
                    .CoordinationOfBenefitsCode.Value = ""
                    .YesNoConditionOrResponseCode.Value = ""
                    .EmploymentStatusCode.Value = ""
                    If (lMainInsurance.PatientInsuranceDetail.InsuranceCompany.CompanyName.ToUpper.Contains("BLUE CROSS") Or lMainInsurance.PatientInsuranceDetail.InsuranceCompany.CompanyName.ToUpper.Contains("BLUE SHIELD")) Then
                        .ClaimFilingIndicatorCode.Value = "BL"
                    Else
                        Select Case lMainInsurance.PatientInsuranceDetail.InsuranceCompany.CompanyName.ToUpper
                            Case "MEDICARE"
                                .ClaimFilingIndicatorCode.Value = "MB"
                            Case "MEDICAID"
                                .ClaimFilingIndicatorCode.Value = "MC"
                            Case "CHAMPUS"
                                .ClaimFilingIndicatorCode.Value = "CH"
                            Case "OTHER"
                                .ClaimFilingIndicatorCode.Value = "CI"
                            Case Else
                                .ClaimFilingIndicatorCode.Value = "CI"
                        End Select
                    End If
                End With

                ''''''''' Discussion Needed
                'Required if the subscriber is the same person as the patient (Loop ID- 
                '2000B SBR02=18), and information in this PAT segment (date of   
                'death, and/or patient weight) is necessary to file the claim/encounter
                '(see PAT05, 06, 07, and 08).

                '' '' ''If (pHCFADB.PatientRelationshipToInsured <> "SELF") Then
                '' '' ''    With l2000B.PAT

                '' '' ''    End With
                '' '' ''End If
                ''''''''' Discussion Needed


                '******************** Start 2010BA Subscriber Name
                If (lMainInsuranceSelf) Then ''''''''''MAIN IF
                    ''''''''' If Patient is Subscriber Fisrst Block'''''''''''''''
                    With l2000B.L2010BA_837PRO1.NM1
                        .EntityIdentifierCode1.Value = "IL"
                        .EntityTypeQualifier.Value = "1"
                        .NameLastOrOrganizationName.Value = lPatient.Patient.LastName  '"Benjamin"
                        .NameFirst.Value = lPatient.Patient.FirstName  '"Melva"
                        .NameMiddle.Value = lPatient.Patient.MiddleName  '"K"
                        .NamePrefix.Value = ""
                        .NameSuffix.Value = ""
                        .IdentificationCodeQualifier.Value = "MI"
                        .IdentificationCode.Value = lMainInsurance.PatientInsuranceDetail.PInsurance.SubscriberID  'pHCFADB.InsuredIDNumber '"488129918D"
                        .EntityRelationshipCode.Value = ""
                        .EntityIdentifierCode2.Value = ""
                    End With

                    With l2000B.L2010BA_837PRO1.N3
                        .AddressInformation1.Value = lPatient.Patient.AddressLine1  '"74551 Columbian Drive"
                        .AddressInformation2.Value = lPatient.Patient.AddressLine2  '"74551 Columbian Drive"
                    End With

                    With l2000B.L2010BA_837PRO1.N4
                        If (lPatient.Patient.City = "") Then
                            .CityName.Value = "Palm Desert"
                        Else
                            .CityName.Value = lPatient.Patient.City   '"Palm Desert"
                        End If
                        .StateOrProvinceCode.Value = lPatient.Patient.StateID   '"CA"
                        .PostalCode.Value = lPatient.Patient.ZipCode  '"92260"
                        .CountryCode.Value = ""
                        .LocationQualifier.Value = ""
                        .LocationIdentifier.Value = ""
                    End With

                    With l2000B.L2010BA_837PRO1.DMG
                        .DateTimePeriodFormatQualifier.Value = "D8"
                        .DateTimePeriod.Value = Convert.ToDateTime(lPatient.Patient.DOB).ToString("yyyyMMdd") '"19240131"
                        .GenderCode.Value = lPatient.Patient.Gender.Substring(0, 1)
                        .MaritalStatusCode.Value = ""
                        .RaceOrEthnicityCode.Value = ""
                        .CitizenshipStatusCode.Value = ""
                        .CountryCode.Value = ""
                        .BasisOfVerificationCode.Value = ""
                        '.Quantity.
                    End With
                    ''''''''' If first Block'''''''''''''''
                Else '''''''''''''Main IF
                    ''''''''' If Patient is Not Subscriber Second Block'''''''''''''''
                    With l2000B.L2010BA_837PRO1.NM1
                        .EntityIdentifierCode1.Value = "IL"
                        .EntityTypeQualifier.Value = "1"
                        .NameLastOrOrganizationName.Value = lMainInsurance.PatientInsuranceDetail.Insurer.LastName 'lPrimaryInsurerPatient.Patient.LastName  ''"Benjamin"
                        .NameFirst.Value = lMainInsurance.PatientInsuranceDetail.Insurer.FirstName   '"Melva"
                        .NameMiddle.Value = lMainInsurance.PatientInsuranceDetail.Insurer.MiddleName   '"K"
                        .NamePrefix.Value = ""
                        .NameSuffix.Value = ""
                        .IdentificationCodeQualifier.Value = "MI"
                        .IdentificationCode.Value = lMainInsurance.PatientInsuranceDetail.PInsurance.SubscriberID  ''"488129918D"
                        .EntityRelationshipCode.Value = ""
                        .EntityIdentifierCode2.Value = ""
                    End With

                    With l2000B.L2010BA_837PRO1.N3
                        .AddressInformation1.Value = lMainInsurance.PatientInsuranceDetail.Insurer.AddressLine1  '"74551 Columbian Drive"
                        .AddressInformation2.Value = lMainInsurance.PatientInsuranceDetail.Insurer.AddressLine2
                    End With

                    With l2000B.L2010BA_837PRO1.N4
                        If (lMainInsurance.PatientInsuranceDetail.Insurer.City = "") Then
                            .CityName.Value = "Palm Desert"
                        Else
                            .CityName.Value = lMainInsurance.PatientInsuranceDetail.Insurer.City  '"Palm Desert"
                        End If
                        .StateOrProvinceCode.Value = lMainInsurance.PatientInsuranceDetail.Insurer.StateID   '"CA"
                        .PostalCode.Value = lMainInsurance.PatientInsuranceDetail.Insurer.ZipCode  '"92260"
                        .CountryCode.Value = ""
                        .LocationQualifier.Value = ""
                        .LocationIdentifier.Value = ""
                    End With

                    ''''''''' If first Block'''''''''''''''
                End If
                '******************** End 2010BA Subscriber


                '******************** Start Payer Name 2010BB 
                With l2000B.L2010BB_837PRO.NM1
                    .EntityIdentifierCode1.Value = "PR"
                    .EntityTypeQualifier.Value = "2"

                    If (lMainInsurance.PatientInsuranceDetail.InsuranceCompany.CompanyName.Length > 35) Then
                        .NameLastOrOrganizationName.Value = lMainInsurance.PatientInsuranceDetail.InsuranceCompany.CompanyName.Substring(0, 34) '"MEDICARE"
                    Else
                        .NameLastOrOrganizationName.Value = lMainInsurance.PatientInsuranceDetail.InsuranceCompany.CompanyName '"MEDICARE"
                    End If

                    .NameFirst.Value = ""
                    .NameMiddle.Value = ""
                    .NamePrefix.Value = ""
                    .NameSuffix.Value = ""
                    .IdentificationCodeQualifier.Value = "PI"
                    .IdentificationCode.Value = lMainInsurance.PatientInsuranceDetail.InsuranceCompany.PayerID.PadLeft(5, "0") '"CMSEL"
                    .EntityRelationshipCode.Value = ""
                    .EntityIdentifierCode2.Value = ""
                End With

                With l2000B.L2010BB_837PRO.N3
                    .AddressInformation1.Value = lMainInsurance.PatientInsuranceDetail.InsuranceCompany.AddressLine1 '"PO Box 272852"
                    .AddressInformation2.Value = lMainInsurance.PatientInsuranceDetail.InsuranceCompany.AddressLine2 '""
                End With

                With l2000B.L2010BB_837PRO.N4
                    If (lMainInsurance.PatientInsuranceDetail.InsuranceCompany.City <> "") Then
                        .CityName.Value = lMainInsurance.PatientInsuranceDetail.InsuranceCompany.City
                    Else
                        .CityName.Value = "Chico"
                    End If
                    .StateOrProvinceCode.Value = lMainInsurance.PatientInsuranceDetail.InsuranceCompany.State '"CA"
                    .PostalCode.Value = lMainInsurance.PatientInsuranceDetail.InsuranceCompany.ZipCode '"95927"
                    .CountryCode.Value = ""
                    .LocationQualifier.Value = ""
                    .LocationIdentifier.Value = ""
                End With
                '******************** Start Payer Name 2010BB 
                '******************** END  Loop 2000B 

                If (lMainInsuranceSelf) Then
                    Dim l2300 As ClaimLibrary.Grp837_PROL2300_837PRO1
                    l2300 = l2000B.L2300_837PRO1.Append
                    'BuildClaim2300(l2000B.L2300_837PRO1.Append, pUser, pHCFADB, pPatientCPTCol, lReferringProvider, True)
                    BuildClaim2300New(l2300, pUser, pHCFADB, lHcfaDtlCol, lReferringProvider, lRenderingProvider, lClinic, lPatient, lFacility, lBillingProvider)
                Else
                    '******************** Start Patient Hierarchical Level 2000C 
                    Dim l2000C As Grp837_PROL2000C_837PRO
                    l2000C = l2000B.L2000C_837PRO.Append()

                    With l2000C.HL_3
                        mLastHL = mLastHL + 1
                        .HierarchicalIdNumber.Value = mLastHL
                        .HierarchicalParentIdNumber.Value = mSubscriberHL
                        .HierarchicalLevelCode.Value = "23"
                        .HierarchicalChildCode.Value = "0"
                    End With

                    With l2000C.PAT
                        Select Case pHCFADB.MainPatientInsurance.RelationshipToPrimaryInsurer.ToUpper
                            Case "SPOUSE"
                                .IndividualRelationshipCode.Value = "01"
                            Case "CHILD"
                                .IndividualRelationshipCode.Value = "19"
                            Case "OTHER"
                                .IndividualRelationshipCode.Value = "G8"
                            Case Else
                                .IndividualRelationshipCode.Value = "01"
                        End Select
                        '.PatientLocationCode = ""
                        '.EmploymentStatusCode = ""
                        '.StudentStatusCode = ""
                        '.DateTimePeriodFormatQualifier = ""
                        '.DateTimePeriod = ""
                        '.UnitOrBasisForMeasurementCode = ""
                        '.Weight = ""
                        '.YesNoConditionOrResponseCode = ""
                    End With

                    With l2000C.L2010CA_837PRO.NM1
                        .EntityIdentifierCode1.Value = "QC"
                        .EntityTypeQualifier.Value = "1"
                        .NameLastOrOrganizationName.Value = lPatient.Patient.LastName  '"Benjamin"
                        .NameFirst.Value = lPatient.Patient.FirstName  '"Melva"
                        .NameMiddle.Value = lPatient.Patient.MiddleName  '"K"
                        .NamePrefix.Value = ""
                        .NameSuffix.Value = ""
                        '.IdentificationCodeQualifier.Value = "MI"
                        '.IdentificationCode.Value = pHCFADB.InsuredIDNumber '"488129918D"
                        '.EntityRelationshipCode.Value = ""
                        '.EntityIdentifierCode2.Value = ""
                    End With

                    With l2000C.L2010CA_837PRO.N3
                        .AddressInformation1.Value = lPatient.Patient.AddressLine1  '"74551 Columbian Drive"
                        .AddressInformation2.Value = lPatient.Patient.AddressLine2  '"74551 Columbian Drive"
                    End With

                    With l2000C.L2010CA_837PRO.N4
                        If (lPatient.Patient.City = "") Then
                            .CityName.Value = "Palm Desert"
                        Else
                            .CityName.Value = lPatient.Patient.City   '"Palm Desert"
                        End If
                        .StateOrProvinceCode.Value = lPatient.Patient.IsDeleted  '"CA"
                        .PostalCode.Value = lPatient.Patient.ZipCode  '"92260"
                        .CountryCode.Value = ""
                        .LocationQualifier.Value = ""
                        .LocationIdentifier.Value = ""
                    End With

                    With l2000C.L2010CA_837PRO.DMG
                        .DateTimePeriodFormatQualifier.Value = "D8"
                        .DateTimePeriod.Value = Convert.ToDateTime(lPatient.Patient.DOB).ToString("yyyyMMdd") '"19240131"
                        .GenderCode.Value = lPatient.Patient.Gender.Substring(0, 1)
                        .MaritalStatusCode.Value = ""
                        .RaceOrEthnicityCode.Value = ""
                        .CitizenshipStatusCode.Value = ""
                        .CountryCode.Value = ""
                        .BasisOfVerificationCode.Value = ""
                        '.Quantity.
                    End With

                    '' '' ''lRef = l2000C.L2010CA_837PRO.REF1.Append
                    '' '' ''With lRef
                    '' '' ''    .ReferenceIdentification = ""
                    '' '' ''    .ReferenceIdentificationQualifier = ""
                    '' '' ''End With
                    '******************** END Patient Hierarchical Level 2000C 
                    Dim l2300 As ClaimLibrary.Grp837_PROL2300_837PRO2
                    l2300 = l2000C.L2300_837PRO2.Append
                    BuildClaim2300New(l2300, pUser, pHCFADB, lHcfaDtlCol, lReferringProvider, lRenderingProvider, lClinic, lPatient, lFacility, lBillingProvider)
                End If
            Next
            ''*************************************** Loop WOrk END Claim Batch
            ''****************************************************
            ''****************************************************
            ''****************************************************


            ''''''''' clm 2300 start

            ''''''''' clm 2300 start

            'lClaimId = "CL" & pUser.ClinicId & "H" & Convert.ToDateTime(pHCFADB.HCFAPreparedDate).Year & Convert.ToDateTime(pHCFADB.HCFAPreparedDate).ToString("MM") & pHCFADB.HCFADisplayID.PadLeft(5, "0")


            lEDIMessage = lInterChange.Parse()

            lCurrentFilePath = SaveToFile(lEDIMessage, pBatchDisplayID & ".txt")

            If (lCurrentFilePath <> "") Then
                lCurrentFileResult = True
            Else
                lCurrentFileResult = False
            End If

            If (lCurrentFileResult) Then
                lSendGatewayResult = SendToGatewayEDI(lCurrentFilePath)
            Else
                lCurrentFileResult = False
                lSendGatewayResult = False
            End If

            If (Not lSendGatewayResult) Then
                lEDIMessage = ""
            ElseIf (lSendGatewayResult) Then
                lFileArchiveResult = MoveToArchive(lCurrentFilePath)
            End If

            Return lEDIMessage
        Catch ex As Exception
            Return ""
        End Try


    End Function

    Public Shared Sub BuildClaim2300New(ByRef l2300 As Object, ByRef pUser As User, ByRef pHCFADB As HCFADBUpdated, ByRef pHcfaDtlCol As HCFADetailCollUpdated, ByRef lReferringProvider As ReferringProvider, ByRef lRenderingProvider As Employee, ByRef lClinic As Clinic, ByRef lPatient As PatientExtended, ByRef lfacility As Facility, ByRef pBillingProvider As BillingProvider)
        Dim lRef As SegREF



        Dim lOtherInsurance As New PatientInsuranceDetail(pUser.ConnectionString)


        Dim lOtherInsuranceSelf As Boolean = False
        Dim lOtherInsuranceExist As Boolean = False




        '''''''''''''' Other Insurance And Insurer Checking Logic

        '************* Loading Other Insurance with HCFA not from Parent Record ****************
        lOtherInsurance.PatientInsuranceDetail.Insurer = pHCFADB.OtherInsurerPatient
        lOtherInsurance.PatientInsuranceDetail.InsuranceCompany = pHCFADB.OtherInsuranceCompany
        lOtherInsurance.PatientInsuranceDetail.PInsurance = pHCFADB.OtherPatientInsurance
        '************* Loading Other Insurance with HCFA not from Parent Record ****************

        If (lOtherInsurance.PatientInsuranceDetail.PInsurance.SubscriberID <> "" And lOtherInsurance.PatientInsuranceDetail.PInsurance.SubscriberID <> "0") Then
            lOtherInsuranceExist = True
        Else
            lOtherInsuranceExist = False
        End If

        If (lOtherInsuranceExist) Then
            If (lOtherInsurance.PatientInsuranceDetail.PInsurance.InsurerId <> 0) Then
                lOtherInsuranceSelf = False
            Else
                lOtherInsuranceSelf = True
            End If
        End If
        '''''''''''''' Other Insurance And Insurer Checking Logic


        ''Dim lPRV As SegPRV
        'Dim l2300 As ClaimLibrary.Grp837_PROL2300_837PRO2
        'Dim test1 As ClaimLibrary.Grp837_PROL2300_837PRO2
        'l2300 = CType(l2300, ClaimLibrary..Grp837_PROL2300_837PRO2)
        'If (pPrimarySelf) Then

        '    l2300 = CType(p2300, ClaimLibrary.Grp837_PROL2300_837PRO1)
        'Else
        '    l2300 = CType(l2300, ClaimLibrary.Grp837_PROL2300_837PRO2)
        'End If


        With l2300.CLM
            '.ClaimSubmittersIdentifier.Value = pHCFADB.HCFADisplayID.PadLeft(6, "0")
            .ClaimSubmittersIdentifier.Value = "CL" & pUser.ClinicId & "H" & Convert.ToDateTime(pHCFADB.HCFAPreparedDate).Year & Convert.ToDateTime(pHCFADB.HCFAPreparedDate).ToString("MM") & pHCFADB.HCFADisplayID.PadLeft(5, "0")
            .MonetaryAmount.Value = pHCFADB.TotalCharges
            .ClaimFillingIndicatorCode.Value = ""
            .NonInstitutionalClaimTypeCode.Value = ""

            .HealthCareServiceLocationInformation.FacilityCodeValue.Value = lfacility.FacilityDB.FacilityCode '"11"
            .HealthCareServiceLocationInformation.FacilityCodeQualifier.Value = ""
            .HealthCareServiceLocationInformation.ClaimFrequencyTypeCode.Value = "1"

            .YesNoConditionOrResponseCode1.Value = "Y"
            .ProviderAcceptAssignmentCode.Value = "A"
            .YesNoConditionOrResponseCode2.Value = "Y"
            .ReleaseOfInformationCode.Value = "Y"
            .PatientSignatureSourceCode.Value = "B"

            'Block 10 a,b,c
            '.RelatedCausesInformation.RelatedCausesCode1.Value = ""
            '.RelatedCausesInformation.StateOrProvinceCode = ""
            '.SpecialProgramCode.Value = ""
            '.YesNoConditionOrResponseCode3.Value = ""
            '.LevelOfServiceCode.Value = ""
            '.YesNoConditionOrResponseCode4.Value = ""
            '.ProviderAgreementCode.Value = ""
            '.ClaimStatusCode.Value = ""
            '.YesNoConditionOrResponseCode5.Value = ""
            '.ClaimSubmissionReasonCode.Value = ""
            '.DelayReasonCode.Value = ""

        End With

        '' Hospitalization Date work block 18, 30 june 2011''
        If (pHCFADB.HospitalizationDateFrom <> "") Then
            With l2300.DTP14
                .DateTimeQualifier.Value = "435"
                .DateTimePeriodFormatQualifier.Value = "D8"
                .DateTimePeriod.Value = Convert.ToDateTime(pHCFADB.HospitalizationDateFrom).ToString("yyyyMMdd")
            End With
        End If

        If (pHCFADB.HospitalizationDateFrom <> "" AndAlso pHCFADB.HospitalizationDateTo <> "") Then
            With l2300.DTP15
                .DateTimeQualifier.Value = "096"
                .DateTimePeriodFormatQualifier.Value = "D8"
                .DateTimePeriod.Value = Convert.ToDateTime(pHCFADB.HospitalizationDateTo).ToString("yyyyMMdd")
            End With
        End If
        '' 
        '' Hospitalization Date work block 18, 30 june 2011''


        If (pHCFADB.ICD1 <> "") Then
            With l2300.HI.HealthCareCodeInformation1
                .CodeListQualifierCode.Value = "BK"
                If (pHCFADB.ICD1.Contains(".")) Then
                    .IndustryCode.Value = pHCFADB.ICD1.Remove(pHCFADB.ICD1.IndexOf("."), 1)
                Else
                    .IndustryCode.Value = pHCFADB.ICD1
                End If

                'DateTimePeriodFormatQualifier()
                'DateTimePeriod()
                'MonetaryAmount()
                'Quantity()
                'VersionIdentifier()
            End With
        End If


        If (pHCFADB.ICD2 <> "") Then
            With l2300.HI.HealthCareCodeInformation2
                .CodeListQualifierCode.Value = "BF"
                If (pHCFADB.ICD2.Contains(".")) Then
                    .IndustryCode.Value = pHCFADB.ICD2.Remove(pHCFADB.ICD2.IndexOf("."), 1)
                Else
                    .IndustryCode.Value = pHCFADB.ICD2
                End If
            End With
        End If

        If (pHCFADB.ICD3 <> "") Then
            With l2300.HI.HealthCareCodeInformation3
                .CodeListQualifierCode.Value = "BF"
                If (pHCFADB.ICD3.Contains(".")) Then
                    .IndustryCode.Value = pHCFADB.ICD3.Remove(pHCFADB.ICD3.IndexOf("."), 1)
                Else
                    .IndustryCode.Value = pHCFADB.ICD3
                End If
            End With
        End If

        If (pHCFADB.ICD4 <> "") Then
            With l2300.HI.HealthCareCodeInformation4
                .CodeListQualifierCode.Value = "BF"
                If (pHCFADB.ICD4.Contains(".")) Then
                    .IndustryCode.Value = pHCFADB.ICD4.Remove(pHCFADB.ICD4.IndexOf("."), 1)
                Else
                    .IndustryCode.Value = pHCFADB.ICD4
                End If
            End With
        End If



        ''***********Start REFERIING PROVIDER*****************''''''''''
        Dim l2310A As ClaimLibrary.Grp837_PROL2310A_837PRO
        If (pHCFADB.ReferencePvd IsNot Nothing AndAlso pHCFADB.ReferencePvd.ProviderID <> 0) Then
            l2310A = l2300.L2310A_837PRO.Append
            With l2310A.NM1
                .EntityIdentifierCode1.Value = "DN"
                .EntityTypeQualifier.Value = "1"
                .NameLastOrOrganizationName.Value = lReferringProvider.ReferringProviderDB.LastName  '."Kazi"
                .NameFirst.Value = lReferringProvider.ReferringProviderDB.FirstName   '"Manzoor"
                .NameMiddle.Value = lReferringProvider.ReferringProviderDB.MiddleName '"A"
                .NamePrefix.Value = ""
                .NameSuffix.Value = ""
                .IdentificationCodeQualifier.Value = "XX"
                .IdentificationCode.Value = lReferringProvider.ReferringProviderDB.NPI  '"1225032212"
                .EntityRelationshipCode.Value = ""
                .EntityIdentifierCode2.Value = ""
            End With


            With l2310A.PRV
                .ProviderCode.Value = "RF"
                .ReferenceIdentificationQualifier.Value = "ZZ"
                .ReferenceIdentification.Value = lReferringProvider.ReferringProviderDB.Speciality  '"213EP1101X"
            End With

            '' '' '' ''lRef = l2300.L2310A_837PRO.REF.Append
            '' '' '' ''With lRef
            '' '' '' ''    .ReferenceIdentificationQualifier.Value = "1C"
            '' '' '' ''    .ReferenceIdentification.Value = "ZZZ18991Z"
            '' '' '' ''    .Description.Value = ""
            '' '' '' ''End With
        End If
        ''***********End REFERIING PROVIDER*****************''''''''''


        ''***********RENDERING PROVIDER*****************''''''''''
        With l2300.L2310B_837PRO.NM1
            .EntityIdentifierCode1.Value = "82"
            .EntityTypeQualifier.Value = "1"
            .NameLastOrOrganizationName.Value = lRenderingProvider.Employee.LastName
            .NameFirst.Value = lRenderingProvider.Employee.FirstName
            .NameMiddle.Value = lRenderingProvider.Employee.MiddleName
            .NamePrefix.Value = ""
            .NameSuffix.Value = ""
            .IdentificationCodeQualifier.Value = "XX"
            .IdentificationCode.Value = lRenderingProvider.Employee.NPI '"1376629261"
            .EntityRelationshipCode.Value = ""
            .EntityIdentifierCode2.Value = ""
        End With

        With l2300.L2310B_837PRO.PRV
            .ProviderCode.Value = "PE"
            .ReferenceIdentificationQualifier.Value = "ZZ"
            .ReferenceIdentification.Value = lRenderingProvider.Employee.SpecialityCode '"213EP1101X"
        End With


        ''lRef = l2300.L2310B_837PRO.REF.Append
        ''With lRef
        ''    .ReferenceIdentificationQualifier.Value = "EI"
        ''    .ReferenceIdentification.Value = "330967624" 'lClinic.Clinic.FacilityCode '
        ''    .Description.Value = ""
        ''End With

        ''If (pPatientCPTCol.Item(0).COB <> "" And (pPatientCPTCol.Item(0).PrescriberLicenceID <> "")) Then
        ''    lRef = l2300.L2310B_837PRO.REF.Append
        ''    With lRef
        ''        .ReferenceIdentificationQualifier.Value = pPatientCPTCol.Item(0).COB
        ''        .ReferenceIdentification.Value = pPatientCPTCol.Item(0).PrescriberLicenceID
        ''        .Description.Value = ""
        ''    End With
        ''End If
        ''***********RENDERING PROVIDER*****************''''''''''


        ''***********Service facility*****************''''''''''
        If (pHCFADB.ServiceFacility IsNot Nothing AndAlso pHCFADB.ServiceFacility.NPI <> "") Then

            With l2300.L2310D_837PRO.NM1
                .EntityIdentifierCode1.Value = "FA"
                .EntityTypeQualifier.Value = "2"
                .NameLastOrOrganizationName.Value = lfacility.FacilityDB.FacilityName   '."Kazi"
                '.NameFirst.Value = lReferringProvider.ReferringProviderDB.FirstName   '"Manzoor"
                '.NameMiddle.Value = lReferringProvider.ReferringProviderDB.MiddleName '"A"
                '.NamePrefix.Value = ""
                '.NameSuffix.Value = ""
                .IdentificationCodeQualifier.Value = "XX"
                .IdentificationCode.Value = pHCFADB.ServiceFacility.NPI   '"1225032212"
                '.EntityRelationshipCode.Value = ""
                '.EntityIdentifierCode2.Value = ""
            End With

            With l2300.L2310D_837PRO.N3
                .AddressInformation1.Value = lfacility.FacilityDB.AddressLine1    '"74551 Columbian Drive"
                .AddressInformation2.Value = lfacility.FacilityDB.AddressLine2  '"74551 Columbian Drive"
            End With

            With l2300.L2310D_837PRO.N4
                If (lfacility.FacilityDB.City = "") Then
                    .CityName.Value = "Palm Desert"
                Else
                    .CityName.Value = lfacility.FacilityDB.City   '"Palm Desert"
                End If
                .StateOrProvinceCode.Value = lfacility.FacilityDB.State   '"CA"
                .PostalCode.Value = lfacility.FacilityDB.ZipCode   '"92260"
                '.CountryCode.Value = ""
                '.LocationQualifier.Value = ""
                '.LocationIdentifier.Value = ""
            End With

            ' '' ''If (pHCFADB.FacilitySecondaryIdentificationQualifier <> "" And pHCFADB.FacilityCode <> "") Then
            ' '' ''    lRef = l2300.L2310D_837PRO.REF.Append
            ' '' ''    With lRef
            ' '' ''        .ReferenceIdentificationQualifier.Value = pHCFADB.FacilitySecondaryIdentificationQualifier
            ' '' ''        .ReferenceIdentification.Value = pHCFADB.FacilityCode
            ' '' ''        '.Description.Value = ""
            ' '' ''    End With
            ' '' ''End If
        End If
        ''***********Service facility*****************''''''''''


        If (lOtherInsuranceExist) Then
            ''''''''''''' other insurance loop''''''''
            Dim l2320 As ClaimLibrary.Grp837_PROL2320_837PRO
            l2320 = l2300.L2320_837PRO.Append()
            BuildClaim2320New(l2320, pUser, pHCFADB, pHcfaDtlCol, lReferringProvider, lRenderingProvider, lClinic, lPatient, lOtherInsurance, lOtherInsuranceExist, lOtherInsuranceSelf, lfacility)
            ''''''''''''' other insurance loop''''''''
        End If



        Dim l2400 As Grp837_PROL2400_837PRO

        Dim i As Int32

        For i = 0 To pHcfaDtlCol.Count - 1
            l2400 = l2300.L2400_837PRO.Append

            With l2400.LX
                .AssignedNumber.Value = i + 1
            End With

            With l2400.SV1
                .CompositeMedicalProcedureIdentifier.ProductServiceIdQualifier.Value = "HC"
                .CompositeMedicalProcedureIdentifier.ProductServiceId.Value = pHcfaDtlCol.Item(i).CPTCode   '"94640"
                .CompositeMedicalProcedureIdentifier.ProcedureModifier1.Value = pHcfaDtlCol.Item(i).ModifierA
                .CompositeMedicalProcedureIdentifier.ProcedureModifier2.Value = pHcfaDtlCol.Item(i).ModifierB
                .CompositeMedicalProcedureIdentifier.ProcedureModifier3.Value = pHcfaDtlCol.Item(i).ModifierC
                .CompositeMedicalProcedureIdentifier.ProcedureModifier4.Value = pHcfaDtlCol.Item(i).ModifierD
                '.CopayStatusCode.Value = "Set"
                .CompositeMedicalProcedureIdentifier.Description.Value = ""


                Try
                    .MonetaryAmount1.Value = Convert.ToDouble(pHcfaDtlCol.Item(i).Charges) * Convert.ToInt32(pHcfaDtlCol.Item(i).Days) '97.16
                Catch ex As Exception
                    .MonetaryAmount1.Value = pHcfaDtlCol.Item(i).Charges
                End Try
                .UnitOrBasisForMeasurementCode.Value = "UN"
                .Quantity.Value = pHcfaDtlCol.Item(i).Days

                '' ********Change by Fareed on 8th june 2010*********
                '' Requirement of additional Facility codes other than 11 on service(CPT) level
                '' still 11(Office) is hard coded for facility type at CLM level as at claim level it should be picked from facility data where facility type code is not saved presently
                '' At service level this field in only populated if facility type code is other than 11
                If (pHcfaDtlCol.Item(i).PlaceOfService <> "11") Then
                    .FacilityCodeValue.Value = pHcfaDtlCol.Item(i).ServiceFacility.FacilityCode
                Else
                    .FacilityCodeValue.Value = ""
                End If
                '' ********END Change by Fareed on 8th june 2010*********

                .ServiceTypeCode.Value = ""


                If (pHcfaDtlCol.Item(i).DignosisPointer <> "") Then
                    Dim length As Int32 = pHcfaDtlCol.Item(i).DignosisPointer.Length
                    .CompositeDiagnosisCodePointer.DiagnosisCodePointer1.Value = pHcfaDtlCol.Item(i).DignosisPointer.Substring(0, 1)
                    length = length - 1
                    If (length > 0) Then
                        .CompositeDiagnosisCodePointer.DiagnosisCodePointer2.Value = pHcfaDtlCol.Item(i).DignosisPointer.Substring(1, 1)
                        length = length - 1
                    End If
                    If (length > 0) Then
                        .CompositeDiagnosisCodePointer.DiagnosisCodePointer3.Value = pHcfaDtlCol.Item(i).DignosisPointer.Substring(2, 1)
                        length = length - 1
                    End If
                    If (length > 0) Then
                        .CompositeDiagnosisCodePointer.DiagnosisCodePointer4.Value = pHcfaDtlCol.Item(i).DignosisPointer.Substring(3, 1)
                    End If
                End If


                'MonetaryAmount2()
                'YesNoConditionOrResponseCode1() used later
                'MultipleProcedureCode()
                'YesNoConditionOrResponseCode2() used later
                'YesNoConditionOrResponseCode3()
                'ReviewCode()
                'NationalOrLocalAssignedReviewValue()
                'CopayStatusCode()
                'HealthCareProfessionalShortageAreaCode()
                'ReferenceIdentification()
                'PostalCode()
                'MonetaryAmount3()
                'LevelOfCareCode()
                'ProviderAgreementCode()


            End With


            With l2400.DTP1
                .DateTimeQualifier.Value = "472"
                If (pHcfaDtlCol.Item(i).DateOfServiceFrom <> "" And pHcfaDtlCol.Item(i).DateOfServiceTo <> "") Then
                    .DateTimePeriodFormatQualifier.Value = "RD8"
                    .DateTimePeriod.Value = Convert.ToDateTime(pHcfaDtlCol.Item(i).DateOfServiceFrom).ToString("yyyyMMdd") & "-" & Convert.ToDateTime(pHcfaDtlCol.Item(i).DateOfServiceTo).ToString("yyyyMMdd")
                ElseIf (pHcfaDtlCol.Item(i).DateOfServiceFrom <> "" And pHcfaDtlCol.Item(i).DateOfServiceTo = "") Then
                    .DateTimePeriodFormatQualifier.Value = "D8"
                    .DateTimePeriod.Value = Convert.ToDateTime(pHcfaDtlCol.Item(i).DateOfServiceFrom).ToString("yyyyMMdd")
                ElseIf (pHcfaDtlCol.Item(i).DateOfServiceFrom = "" And pHcfaDtlCol.Item(i).DateOfServiceTo <> "") Then
                    .DateTimePeriodFormatQualifier.Value = "D8"
                    .DateTimePeriod.Value = Convert.ToDateTime(pHcfaDtlCol.Item(i).DateOfServiceTo).ToString("yyyyMMdd")
                End If

            End With



            '********************* CPT level Info if changed************ ''' 


            ''***********Start CPT LEVEL REFERING PROVIDER*****************''''''''''
            'Dim l2420A As ClaimLibrary.Grp837_PROL2310A_837PRO
            'If (pHCFADB.ReferencePvd IsNot Nothing AndAlso pHCFADB.ReferencePvd.ProviderID <> 0) Then
            'l2310A = l2300.L2310A_837PRO.Append
            If (pHcfaDtlCol.Item(i).RenderingProvider.NPI <> lRenderingProvider.Employee.NPI) Then

                With l2400.L2420A_837PRO.NM1
                    .EntityIdentifierCode1.Value = "82"
                    .EntityTypeQualifier.Value = "1"
                    .NameLastOrOrganizationName.Value = pHcfaDtlCol.Item(i).RenderingProvider.LastName  '."Kazi"
                    .NameFirst.Value = pHcfaDtlCol.Item(i).RenderingProvider.FirstName   '"Manzoor"
                    .NameMiddle.Value = pHcfaDtlCol.Item(i).RenderingProvider.MiddleName '"A"
                    .NamePrefix.Value = ""
                    .NameSuffix.Value = ""
                    .IdentificationCodeQualifier.Value = "XX"
                    .IdentificationCode.Value = pHcfaDtlCol.Item(i).RenderingProvider.NPI  '"1225032212"
                    .EntityRelationshipCode.Value = ""
                    .EntityIdentifierCode2.Value = ""
                End With


                With l2400.L2420A_837PRO.PRV
                    .ProviderCode.Value = "PE"
                    .ReferenceIdentificationQualifier.Value = "ZZ"
                    .ReferenceIdentification.Value = pHcfaDtlCol.Item(i).RenderingProvider.SpecialityCode   '"213EP1101X"
                End With
            End If

            '' '' '' ''lRef = l2400.L2420A_837PRO.REF.Append
            '' '' '' ''With lRef
            '' '' '' ''    .ReferenceIdentificationQualifier.Value = "1C"
            '' '' '' ''    .ReferenceIdentification.Value = "ZZZ18991Z"
            '' '' '' ''    .Description.Value = ""
            '' '' '' ''End With

            ''***********Start CPT LEVEL REFERING PROVIDER*****************''''''''''

            ''***********Start CPT LEVEL Facility *****************''''''''''
            ''***********Service facility*****************''''''''''
            If (pHcfaDtlCol.Item(i).ServiceFacility.NPI <> pHCFADB.ServiceFacility.NPI) Then

                With l2400.L2420C_837PRO.NM1
                    .EntityIdentifierCode1.Value = "FA"
                    .EntityTypeQualifier.Value = "2"
                    .NameLastOrOrganizationName.Value = pHcfaDtlCol.Item(i).ServiceFacility.FacilityName   '."Kazi"                    
                    .IdentificationCodeQualifier.Value = "XX"
                    .IdentificationCode.Value = pHcfaDtlCol.Item(i).ServiceFacility.NPI   '"1225032212"
                    '.EntityRelationshipCode.Value = ""
                    '.EntityIdentifierCode2.Value = ""
                End With

                With l2400.L2420C_837PRO.N3
                    .AddressInformation1.Value = pHcfaDtlCol.Item(i).ServiceFacility.AddressLine1    '"74551 Columbian Drive"
                    .AddressInformation2.Value = pHcfaDtlCol.Item(i).ServiceFacility.AddressLine2  '"74551 Columbian Drive"
                End With

                With l2400.L2420C_837PRO.N4
                    If (pHcfaDtlCol.Item(i).ServiceFacility.City = "") Then
                        .CityName.Value = "Palm Desert"
                    Else
                        .CityName.Value = pHcfaDtlCol.Item(i).ServiceFacility.City   '"Palm Desert"
                    End If
                    .StateOrProvinceCode.Value = pHcfaDtlCol.Item(i).ServiceFacility.State   '"CA"
                    .PostalCode.Value = pHcfaDtlCol.Item(i).ServiceFacility.ZipCode   '"92260"
                    '.CountryCode.Value = ""
                    '.LocationQualifier.Value = ""
                    '.LocationIdentifier.Value = ""
                End With

                ' '' ''If (pHCFADB.FacilitySecondaryIdentificationQualifier <> "" And pHCFADB.FacilityCode <> "") Then
                ' '' ''    lRef = l2300.L2310D_837PRO.REF.Append
                ' '' ''    With lRef
                ' '' ''        .ReferenceIdentificationQualifier.Value = pHCFADB.FacilitySecondaryIdentificationQualifier
                ' '' ''        .ReferenceIdentification.Value = pHCFADB.FacilityCode
                ' '' ''        '.Description.Value = ""
                ' '' ''    End With
                ' '' ''End If
            End If
            ''***********Service facility*****************''''''''''
            ''***********Start CPT LEVEL Facility *****************''''''''''


            '********************* CPT level Info if changed************ ''' 


        Next

        '''''''''loop work



    End Sub

    Public Shared Sub BuildClaim2320New(ByRef l2320 As ClaimLibrary.Grp837_PROL2320_837PRO, ByRef pUser As User, ByRef pHCFADB As HCFADBUpdated, ByRef pHcfaDtlCol As HCFADetailCollUpdated, ByRef lReferringProvider As ReferringProvider, ByRef lRenderingProvider As Employee, ByRef lClinic As Clinic, ByRef lPatient As PatientExtended, ByRef pOtherPatientInsDetail As PatientInsuranceDetail, ByVal pOtherInsuranceExist As Boolean, ByVal pOtherInsuranceSelf As Boolean, ByRef lFacility As Facility)
        With l2320.SBR
            .PayerResponsibilitySequenceNumberCode.Value = "S"
            Select Case pOtherPatientInsDetail.PatientInsuranceDetail.PInsurance.RelationshipToPrimaryInsurer.ToUpper
                Case "SELF"
                    .IndividualRelationshipCode.Value = "18"
                Case "SPOUSE"
                    .IndividualRelationshipCode.Value = "01"
                Case "CHILD"
                    .IndividualRelationshipCode.Value = "19"
                Case Else
                    .IndividualRelationshipCode.Value = "G8"
            End Select
            .ReferenceIdentification.Value = pOtherPatientInsDetail.PatientInsuranceDetail.PInsurance.GroupNo  '""
            .SubscriberName.Value = pOtherPatientInsDetail.PatientInsuranceDetail.PInsurance.PlanName  '""


            .InsuranceTypeCode.Value = "C1" 'type of insurance policy within specified program
            .CoordinationOfBenefitsCode.Value = ""
            .YesNoConditionOrResponseCode.Value = ""
            .EmploymentStatusCode.Value = ""
            If (pOtherPatientInsDetail.PatientInsuranceDetail.InsuranceCompany.CompanyName.ToUpper.Contains("BLUE CROSS") Or pOtherPatientInsDetail.PatientInsuranceDetail.InsuranceCompany.CompanyName.ToUpper.Contains("BLUE SHIELD")) Then
                .ClaimFilingIndicatorCode.Value = "BL"
            Else
                Select Case pOtherPatientInsDetail.PatientInsuranceDetail.InsuranceCompany.InsuranceType.ToUpper
                    Case "MEDICARE"
                        .ClaimFilingIndicatorCode.Value = "MB"
                    Case "MEDICAID"
                        .ClaimFilingIndicatorCode.Value = "MC"
                    Case "CHAMPUS"
                        .ClaimFilingIndicatorCode.Value = "CH"
                    Case "OTHER"
                        .ClaimFilingIndicatorCode.Value = "CI"
                    Case Else
                        .ClaimFilingIndicatorCode.Value = "CI"
                End Select
            End If
        End With

        If (pOtherInsuranceSelf) Then
            With l2320.DMG
                .DateTimePeriodFormatQualifier.Value = "D8"
                .DateTimePeriod.Value = Convert.ToDateTime(lPatient.Patient.DOB).ToString("yyyyMMdd") '"19240131"
                .GenderCode.Value = lPatient.Patient.Gender.Substring(0, 1)
                .MaritalStatusCode.Value = ""
                .RaceOrEthnicityCode.Value = ""
                .CitizenshipStatusCode.Value = ""
                .CountryCode.Value = ""
                .BasisOfVerificationCode.Value = ""
                '.Quantity.
            End With
        Else
            With l2320.DMG
                .DateTimePeriodFormatQualifier.Value = "D8"
                .DateTimePeriod.Value = Convert.ToDateTime(pOtherPatientInsDetail.PatientInsuranceDetail.Insurer.DOB).ToString("yyyyMMdd") '"19240131"
                .GenderCode.Value = pOtherPatientInsDetail.PatientInsuranceDetail.Insurer.Gender.Substring(0, 1).ToUpper
                .MaritalStatusCode.Value = ""
                .RaceOrEthnicityCode.Value = ""
                .CitizenshipStatusCode.Value = ""
                .CountryCode.Value = ""
                .BasisOfVerificationCode.Value = ""
                '.Quantity.
            End With
        End If

        With l2320.OI
            '.ClaimFilingIndicatorCode = ""
            '.ClaimSubmissionReasonCode = ""
            .YesNoConditionOrResponseCode.Value = "Y"
            .PatientSignatureSourceCode.Value = "B"
            '.ProviderAgreementCode = ""
            .ReleaseOfInformationCode.Value = "Y"
        End With

        If (pOtherInsuranceSelf) Then
            ' Patient information if secondary self
            With l2320.L2330A_837PRO.NM1
                .EntityIdentifierCode1.Value = "IL"
                .EntityTypeQualifier.Value = "1"
                .NameLastOrOrganizationName.Value = lPatient.Patient.LastName  '"Benjamin"
                .NameFirst.Value = lPatient.Patient.FirstName  '"Melva"
                .NameMiddle.Value = lPatient.Patient.MiddleName  '"K"
                .NamePrefix.Value = ""
                .NameSuffix.Value = ""
                .IdentificationCodeQualifier.Value = "MI"
                .IdentificationCode.Value = pOtherPatientInsDetail.PatientInsuranceDetail.PInsurance.SubscriberID 'pHCFADB.InsuredIDNumber '"488129918D"
                '.EntityRelationshipCode.Value = ""
                '.EntityIdentifierCode2.Value = ""
            End With

            With l2320.L2330A_837PRO.N3
                .AddressInformation1.Value = lPatient.Patient.AddressLine1  '"74551 Columbian Drive"
                .AddressInformation2.Value = lPatient.Patient.AddressLine2  '"74551 Columbian Drive"
            End With

            With l2320.L2330A_837PRO.N4
                .CityName.Value = lPatient.Patient.City   '"Palm Desert"
                .StateOrProvinceCode.Value = lPatient.Patient.StateID   '"CA"
                .PostalCode.Value = lPatient.Patient.ZipCode  '"92260"
                '.CountryCode.Value = ""
                '.LocationQualifier.Value = ""
                '.LocationIdentifier.Value = ""
            End With
        Else
            With l2320.L2330A_837PRO.NM1
                .EntityIdentifierCode1.Value = "IL"
                .EntityTypeQualifier.Value = "1"
                .NameLastOrOrganizationName.Value = pOtherPatientInsDetail.PatientInsuranceDetail.Insurer.LastName  ''"Benjamin"
                .NameFirst.Value = pOtherPatientInsDetail.PatientInsuranceDetail.Insurer.FirstName  '"Melva"
                .NameMiddle.Value = pOtherPatientInsDetail.PatientInsuranceDetail.Insurer.MiddleName  '"K"
                .NamePrefix.Value = ""
                .NameSuffix.Value = ""
                .IdentificationCodeQualifier.Value = "MI"
                .IdentificationCode.Value = pOtherPatientInsDetail.PatientInsuranceDetail.PInsurance.SubscriberID ''"488129918D"
                '.EntityRelationshipCode.Value = ""
                '.EntityIdentifierCode2.Value = ""
            End With

            With l2320.L2330A_837PRO.N3
                .AddressInformation1.Value = pOtherPatientInsDetail.PatientInsuranceDetail.Insurer.AddressLine1  '"74551 Columbian Drive"
                .AddressInformation2.Value = pOtherPatientInsDetail.PatientInsuranceDetail.Insurer.AddressLine2
            End With

            With l2320.L2330A_837PRO.N4
                .CityName.Value = pOtherPatientInsDetail.PatientInsuranceDetail.Insurer.City  '"Palm Desert"
                .StateOrProvinceCode.Value = pOtherPatientInsDetail.PatientInsuranceDetail.Insurer.StateID   '"CA"
                .PostalCode.Value = pOtherPatientInsDetail.PatientInsuranceDetail.Insurer.ZipCode  '"92260"
                '.CountryCode.Value = ""
                '.LocationQualifier.Value = ""
                '.LocationIdentifier.Value = ""
            End With
        End If

        ' Secondary Payer
        With l2320.L2330B_837PRO.NM1
            .EntityIdentifierCode1.Value = "PR"
            .EntityTypeQualifier.Value = "2"
            If (pOtherPatientInsDetail.PatientInsuranceDetail.InsuranceCompany.CompanyName.Length > 35) Then
                .NameLastOrOrganizationName.Value = pOtherPatientInsDetail.PatientInsuranceDetail.InsuranceCompany.CompanyName.Substring(0, 34) '"MEDICARE"
            Else
                .NameLastOrOrganizationName.Value = pOtherPatientInsDetail.PatientInsuranceDetail.InsuranceCompany.CompanyName '"MEDICARE"
            End If
            .NameFirst.Value = ""
            .NameMiddle.Value = ""
            .NamePrefix.Value = ""
            .NameSuffix.Value = ""
            .IdentificationCodeQualifier.Value = "PI"
            .IdentificationCode.Value = pOtherPatientInsDetail.PatientInsuranceDetail.InsuranceCompany.PayerID '"CMSEL"
            '.EntityRelationshipCode.Value = ""
            '.EntityIdentifierCode2.Value = ""
        End With
    End Sub

    Public Shared Function LoadClaimCpt(ByVal pHcfaId As Int32) As HCFADetailCollUpdated
        Dim lUser As User = CType(HttpContext.Current.Session("User"), User)

        Dim lHcfaDtl As HCFADetailUpdated = Nothing
        Dim lHcfaDtlCol As New HCFADetailCollUpdated

        Try
            lHcfaDtl = New HCFADetailUpdated(lUser.ConnectionString)
            lHcfaDtl.HCFADetailUpdated.HCFAID = pHcfaId
            lHcfaDtlCol = lHcfaDtl.GetRecordsByID

        Catch ex As Exception
            lHcfaDtlCol = Nothing
        End Try

        Return lHcfaDtlCol

        
    End Function

    Public Shared Function SendToGatewayEDI(ByVal pFileToUploadPath As String) As Boolean
        Dim lGatewayFtpLink As String = ""
        Dim lGatewayFtpUserID As String = ""
        Dim lGatewayFtpPassword As String = ""
        Dim lGatewayFtpClaimRequestPath As String = ""
        Dim lClient As Sftp
        Dim lClinic As Clinic
        Dim lUser As User

        Try

            lUser = CType(HttpContext.Current.Session("User"), User)

            lClinic = New Clinic(lUser.ConnectionString)
            lClinic.Clinic.ClinicId = lUser.ClinicId
            lClinic.GetRecordByID()

            lGatewayFtpUserID = lClinic.Clinic.GatewayFtpUserID
            lGatewayFtpPassword = lClinic.Clinic.GatewayFtpPassword

            'lGatewayFtpUserID = CType(ConfigurationManager.AppSettings("GatewayFtpUserID"), String)
            'lGatewayFtpPassword = CType(ConfigurationManager.AppSettings("GatewayFtpPassword"), String)
            'lGatewayFtpClaimRequestPath = CType(ConfigurationManager.AppSettings("GatewayFtpClaimRequestPath"), String)

            lGatewayFtpLink = CType(ConfigurationManager.AppSettings("GatewayFtpLink"), String)
            lGatewayFtpClaimRequestPath = "/claims"

            lClient = New Sftp
            lClient.Connect(lGatewayFtpLink)
            lClient.Login(lGatewayFtpUserID, lGatewayFtpPassword)
            lClient.PutFiles(pFileToUploadPath, lGatewayFtpClaimRequestPath, SftpBatchTransferOptions.Recursive)

            Return True
        Catch ex As Exception
            Return False
        Finally
            If (lClient.State = SftpState.Connected) Then
                lClient.Disconnect()
                lClient.Dispose()
            End If
        End Try
    End Function
    Public Shared Function MoveToArchive(ByVal pCurrentFilePath As String) As Boolean
        Dim lUser As User
        Dim lDirectoryInfo As DirectoryInfo
        Dim lPath As String = ""
        Dim lFileName As String = ""

        Dim lArchivePath As String = ""




        Try
            lUser = CType(HttpContext.Current.Session.Item("User"), User)

            lFileName = pCurrentFilePath.Substring(pCurrentFilePath.LastIndexOf("\") + 1)

            lPath = CType(ConfigurationManager.AppSettings("ClaimRquestPath"), String)
            lDirectoryInfo = New DirectoryInfo(lPath)
            If Not lDirectoryInfo.Exists Then
                lDirectoryInfo.Create()
            End If
            lPath = CType(ConfigurationManager.AppSettings("ClaimRquestPath"), String) + lUser.ClinicId
            lDirectoryInfo = New DirectoryInfo(lPath)
            If Not lDirectoryInfo.Exists Then
                lDirectoryInfo.Create()
            End If
            lPath = CType(ConfigurationManager.AppSettings("ClaimRquestPath"), String) + lUser.ClinicId + "\ClaimRequest837Archive\"
            lDirectoryInfo = New DirectoryInfo(lPath)
            If Not lDirectoryInfo.Exists Then
                lDirectoryInfo.Create()
            End If



            lArchivePath = lPath & lFileName
            File.Move(pCurrentFilePath, lArchivePath)
            Return True
        Catch
            Return False
        End Try




    End Function

#End Region

End Class

