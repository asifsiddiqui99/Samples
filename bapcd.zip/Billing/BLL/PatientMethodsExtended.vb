Imports Microsoft.VisualBasic

Public Class PatientMethodsExtended
    Inherits PatientMethods

    Public Overloads Shared Function AddPatientForSchedular(ByRef pPatientDB As PatientDBExtended, ByRef pUser As User) As Int32
        Dim lConnection As Connection
        Dim lPatient As PatientExtended
        Dim mPatientId As Int32 = 0
        Dim FinalXml As String
        Dim lFinalPatientNotesXml As String
        Dim lEventLog As New EHREventLog()


        Try
            lConnection = New Connection(pUser.ConnectionString)
            lPatient = New PatientExtended(lConnection)
            lPatient.Patient = pPatientDB
            'lPatientinsurance.PatientInsurance = pPatientInsuranceDbPrimary
            lConnection.BeginTrans()
            mPatientId = lPatient.GetUniqueId("")
            lPatient.Patient.PatientID = mPatientId
            lPatient.InsertRecord()

            lPatient.Connection.CommitTrans()

            'Try
            '    ''section of event log...............
            '    lEventLog.EventLog.EventTypeID = 3
            '    lEventLog.EventLog.PatientID = lPatient.Patient.PatientID
            '    lEventLog.EventLog.OCcurTime = Date.Now()
            '    lEventLog.EventLog.UserID = pUser.UserId
            '    lEventLog.EventLog.EventDescription = pUser.LastName & ", " & pUser.FirstName & " created " & lPatient.Patient.LastName & ", " & lPatient.Patient.FirstName & " as a new patient"
            '    lEventLog.HandleEvent()
            '    ''section of event log ends here..............
            'Catch ex As Exception
            'End Try

            Return mPatientId
        Catch ex As Exception
            lConnection.RollBackTrans()
            'Throw New Exception(ex.Message & " : BLL\PatientMethodsExtended.AddPatient(ByRef pPatientDB As PatientDBExtended, ByRef pPatientInsuranceDbPrimary As PatientInsuranceDB, ByRef pPatientInsuranceDbSecondary As PatientInsuranceDB, ByRef pUser='" & pUser.UserId & "' As User, ByVal pPageURL='" & pPageURL & "' As String, ByVal pTempXml As String) ")
            Return mPatientId
        End Try

    End Function

    Public Overloads Shared Function AddPatient(ByRef pPatientDB As PatientDBExtended, ByRef pPatientInsuranceDbPrimary As PatientInsuranceDB, ByRef pPatientInsuranceDbSecondary As PatientInsuranceDB, ByRef pPatientInsuranceDbTertiary As PatientInsuranceDB, ByRef pUser As User, ByVal pPageURL As String, ByVal pTempXml As String, ByVal pNotesXml As String) As Boolean
        Dim lConnection As Connection
        Dim lPatient As PatientExtended
        Dim lPatientAllergy As PatientAllergy
        Dim lPatientNotes As PatientNotes
        Dim lPatientinsurance As PatientInsurance
        Dim mPatientId As Int32
        Dim FinalXml As String
        Dim lFinalPatientNotesXml As String
        Dim lEventLog As New EHREventLog()


        Try
            lConnection = New Connection(pUser.ConnectionString)
            lPatient = New PatientExtended(lConnection)
            lPatientAllergy = New PatientAllergy(lConnection)
            lPatientNotes = New PatientNotes(lConnection)
            lPatientinsurance = New PatientInsurance(lConnection)
            lPatient.Patient = pPatientDB
            lPatientinsurance.PatientInsurance = pPatientInsuranceDbPrimary
            lConnection.BeginTrans()
            mPatientId = lPatient.GetUniqueId("")
            lPatient.Patient.PatientID = mPatientId
            lPatientinsurance.PatientInsurance.PatientID = mPatientId
            lPatient.InsertRecord()

            ''Allergy Insert
            FinalXml = PatientMethods.LoadFinalXmlAllergy(mPatientId, pTempXml)
            If FinalXml <> "" Then
                lPatientAllergy.InsertRecord(FinalXml)
            End If

            ''Notes Insert
            lFinalPatientNotesXml = PatientMethodsExtended.LoadFinalXmlPatientNotes(mPatientId, pNotesXml)
            If lFinalPatientNotesXml <> "" Then
                lPatientNotes.InsertRecord(lFinalPatientNotesXml)
            End If

            If (pPatientInsuranceDbPrimary.InsuranceCompanyID <> 0 Or pPatientInsuranceDbPrimary.InsurerId <> 0) Then
                lPatientinsurance.InsertRecord()
            End If
            If (pPatientInsuranceDbSecondary.InsuranceCompanyID <> 0 Or pPatientInsuranceDbSecondary.InsurerId <> 0) Then
                lPatientinsurance.PatientInsurance = pPatientInsuranceDbSecondary
                lPatientinsurance.PatientInsurance.PatientID = mPatientId
                lPatientinsurance.InsertRecord()
            End If
            If (pPatientInsuranceDbTertiary.InsuranceCompanyID <> 0 Or pPatientInsuranceDbTertiary.InsurerId <> 0) Then
                lPatientinsurance.PatientInsurance = pPatientInsuranceDbTertiary
                lPatientinsurance.PatientInsurance.PatientID = mPatientId
                lPatientinsurance.InsertRecord()
            End If

            lPatient.Connection.CommitTrans()

            Try
                ''section of event log...............
                lEventLog.EventLog.EventTypeID = 3
                lEventLog.EventLog.PatientID = lPatient.Patient.PatientID
                lEventLog.EventLog.OCcurTime = Date.Now()
                lEventLog.EventLog.UserID = pUser.UserId
                lEventLog.EventLog.EventDescription = pUser.LastName & ", " & pUser.FirstName & " created " & lPatient.Patient.LastName & ", " & lPatient.Patient.FirstName & " as a new patient"
                lEventLog.HandleEvent()
                ''section of event log ends here..............
            Catch ex As Exception
            End Try

            Return True
        Catch ex As Exception
            lConnection.RollBackTrans()
            Throw New Exception(ex.Message & " : BLL\PatientMethodsExtended.AddPatient(ByRef pPatientDB As PatientDBExtended, ByRef pPatientInsuranceDbPrimary As PatientInsuranceDB, ByRef pPatientInsuranceDbSecondary As PatientInsuranceDB, ByRef pUser='" & pUser.UserId & "' As User, ByVal pPageURL='" & pPageURL & "' As String, ByVal pTempXml As String) ")
        End Try

    End Function
    Public Shared Function LoadFinalXmlPatientNotes(ByVal pPatientId As Integer, ByVal pTempXml As String) As String
        ' Loading Values in PatientAllergy Object
        Dim doc As XmlDocument = New XmlDocument()
        Dim nodelist As XmlNodeList
        If pTempXml <> "" Then
            doc.LoadXml(pTempXml)
            nodelist = doc.SelectNodes("PatientNotes/PatientNote")
            For Each node As XmlNode In nodelist
                node.Attributes.GetNamedItem("PatientId").Value = pPatientId.ToString
            Next
            Return doc.InnerXml.ToString
        Else
            Return ""
        End If

    End Function
    Public Overloads Shared Function UpdatePatientOld(ByRef pPatientDB As PatientDBExtended, ByRef pPatientInsuranceDbPrimary As PatientInsuranceDB, ByRef pPatientInsuranceDbSecondary As PatientInsuranceDB, ByRef pUser As User, ByVal pUpdateXml As String, ByVal pPageURL As String) As Boolean
        Dim lConnection As New Connection(pUser.ConnectionString)
        Dim lPatient As New PatientExtended(lConnection)
        Dim lPatientAllergy As New PatientAllergy(lConnection)
        Dim lPatientinsurance As New PatientInsurance(lConnection)
        Dim lEventLog As New EventLog
        'Dim lErrorLog As New ErrorLog()
        'Dim lEventLog As New EventLog()
        'Dim lResult As Boolean
        'Dim lCond As String

        lPatient.Patient = pPatientDB
        lPatientAllergy.PatientAllergy.PatientID = lPatient.Patient.PatientID
        lPatientinsurance.PatientInsurance = pPatientInsuranceDbPrimary
        lPatientinsurance.PatientInsurance.PatientID = lPatient.Patient.PatientID
        Try
            lConnection.BeginTrans()
            lPatient.UpdateRecord()
            If (pUpdateXml <> "") Then
                lPatientAllergy.DeleteRecordByID()
                lPatientAllergy.InsertRecord(pUpdateXml)
            End If
            If ((pPatientInsuranceDbPrimary.InsuranceCompanyName <> "" And pPatientInsuranceDbPrimary.InsuranceCompanyID <> 0) Or pPatientInsuranceDbPrimary.InsurerId <> 0) Then
                If (lPatientinsurance.CheckInsurance) Then
                    lPatientinsurance.InsertRecord()
                End If
            End If
            If ((pPatientInsuranceDbSecondary.InsuranceCompanyName <> "" And pPatientInsuranceDbSecondary.InsuranceCompanyID <> 0) Or pPatientInsuranceDbSecondary.InsurerId <> 0) Then
                lPatientinsurance.PatientInsurance = pPatientInsuranceDbSecondary
                lPatientinsurance.PatientInsurance.PatientID = lPatient.Patient.PatientID
                If (lPatientinsurance.CheckInsurance) Then
                    lPatientinsurance.InsertRecord()
                End If
            End If
            lConnection.CommitTrans()

            Try
                ''section of event log...............
                lEventLog.EventLog.ClinicID = pUser.ClinicId
                lEventLog.EventLog.EventTypeID = EventType.UpdatePatient
                lEventLog.EventLog.ExtraID = lPatient.Patient.PatientID
                lEventLog.EventLog.OCcurTime = Date.Now()
                lEventLog.EventLog.UserID = pUser.UserId
                lEventLog.EventLog.EventDescription = "A Patient of ID '" + lPatient.Patient.PatientID.ToString + "' has been Updated of the clinic having ClinicID '" + pUser.ClinicId + "' on '" + lEventLog.EventLog.OCcurTime + "' by the loginID '" + pUser.LoginId + "'"
                lEventLog.HandleEvent()
                ''section of event log ends here...............
            Catch ex As Exception
            End Try

        Catch ex As Exception
            lConnection.RollBackTrans()
            'lErrorLog.HandleError(ex, pUser, pPageURL)
            Return False
        End Try

        Return True
    End Function
    Public Overloads Shared Function UpdatePatient(ByRef pPatientDB As PatientDBExtended, ByRef pPatientInsuranceDbPrimary As PatientInsuranceDB, ByRef pPatientInsuranceDbSecondary As PatientInsuranceDB, ByRef pPatientInsuranceDbTertiary As PatientInsuranceDB, ByRef pUser As User, ByVal pUpdateXml As String, ByVal pPageURL As String, ByVal pNotesXml As String) As Boolean
        Dim lConnection As Connection
        Dim lPatient As PatientExtended
        Dim lPatientAllergy As PatientAllergy
        Dim lPatientNotes As PatientNotes
        Dim lPatientinsurance As PatientInsurance
        Dim lFinalPatientNotesXml As String
        'Dim lErrorLog As New ErrorLog()
        Dim lEventLog As New EHREventLog()
        'Dim lResult As Boolean
        'Dim lCond As String

        Try
            lConnection = New Connection(pUser.ConnectionString)
            lPatient = New PatientExtended(lConnection)
            lPatientAllergy = New PatientAllergy(lConnection)
            lPatientinsurance = New PatientInsurance(lConnection)
            lPatientNotes = New PatientNotes(lConnection)


            lPatient.Patient = pPatientDB
            lPatientAllergy.PatientAllergy.PatientID = lPatient.Patient.PatientID
            lPatientinsurance.PatientInsurance = pPatientInsuranceDbPrimary
            lPatientinsurance.PatientInsurance.PatientID = lPatient.Patient.PatientID
            lPatientNotes.PatientNotes.PatientId = lPatient.Patient.PatientID

            
            

            lConnection.BeginTrans()
            lPatient.UpdateRecord()

            ''Patient Allergy
            If (pUpdateXml <> "") Then
                lPatientAllergy.DeleteRecordByID()
                lPatientAllergy.InsertRecord(pUpdateXml)
            End If

            ''Notes Insert
            If (pNotesXml IsNot Nothing AndAlso pNotesXml <> "") Then
                lFinalPatientNotesXml = PatientMethodsExtended.LoadFinalXmlPatientNotes(lPatient.Patient.PatientID, pNotesXml)
                If lFinalPatientNotesXml <> "" Then
                    lPatientNotes.DeleteRecordByID()
                    lPatientNotes.InsertRecord(lFinalPatientNotesXml)
                End If
            End If

            ''Patient Insurance

            ''Primary Insurance
            If (pPatientInsuranceDbPrimary.Active = "N") Then
                lPatientinsurance.SetRemovedInsuranceInActive(lPatient.Patient.PatientID, "P")
            Else
                If ((pPatientInsuranceDbPrimary.InsuranceCompanyName <> "" And pPatientInsuranceDbPrimary.InsuranceCompanyID <> 0) Or pPatientInsuranceDbPrimary.InsurerId <> 0) Then
                    If (lPatientinsurance.CheckInsurance() = "1") Then
                        lPatientinsurance.SetDependentsInsuranceInActive()
                        lPatientinsurance.InsertRecord()
                    Else
                        lPatientinsurance.UpdateRecord()
                    End If
                ElseIf (pPatientInsuranceDbPrimary.RelationshipToPrimaryInsurer.ToUpper = "SELF") Then
                    lPatientinsurance.CheckInsurance()
                End If
            End If

            ''Secondary Insurance
            If (pPatientInsuranceDbSecondary.Active = "N") Then
                lPatientinsurance.SetRemovedInsuranceInActive(lPatient.Patient.PatientID, "S")
            Else
                If ((pPatientInsuranceDbSecondary.InsuranceCompanyName <> "" And pPatientInsuranceDbSecondary.InsuranceCompanyID <> 0) Or pPatientInsuranceDbSecondary.InsurerId <> 0) Then
                    lPatientinsurance.PatientInsurance = pPatientInsuranceDbSecondary
                    lPatientinsurance.PatientInsurance.PatientID = lPatient.Patient.PatientID
                    If (lPatientinsurance.CheckInsurance = "1") Then
                        lPatientinsurance.SetDependentsInsuranceInActive()
                        lPatientinsurance.InsertRecord()
                    Else
                        lPatientinsurance.UpdateRecord()
                    End If
                ElseIf (pPatientInsuranceDbSecondary.RelationshipToPrimaryInsurer.ToUpper = "SELF") Then
                    lPatientinsurance.CheckInsurance()
                End If
            End If
            
            ''Tertiary Insurance
            If (pPatientInsuranceDbTertiary.Active = "N") Then
                lPatientinsurance.SetRemovedInsuranceInActive(lPatient.Patient.PatientID, "T")
            Else
                If ((pPatientInsuranceDbTertiary.InsuranceCompanyName <> "" And pPatientInsuranceDbTertiary.InsuranceCompanyID <> 0) Or pPatientInsuranceDbTertiary.InsurerId <> 0) Then
                    lPatientinsurance.PatientInsurance = pPatientInsuranceDbTertiary
                    lPatientinsurance.PatientInsurance.PatientID = lPatient.Patient.PatientID
                    If (lPatientinsurance.CheckInsurance = "1") Then
                        lPatientinsurance.SetDependentsInsuranceInActive()
                        lPatientinsurance.InsertRecord()
                    Else
                        lPatientinsurance.UpdateRecord()
                    End If
                ElseIf (pPatientInsuranceDbTertiary.RelationshipToPrimaryInsurer.ToUpper = "SELF") Then
                    lPatientinsurance.CheckInsurance()
                End If
            End If

            lConnection.CommitTrans()

            Try
                ''section of event log...............
                lEventLog.EventLog.EventTypeID = 4
                lEventLog.EventLog.PatientID = lPatient.Patient.PatientID
                lEventLog.EventLog.OCcurTime = Date.Now()
                lEventLog.EventLog.UserID = pUser.UserId
                lEventLog.EventLog.EventDescription = pUser.LastName & ", " & pUser.FirstName & " updated patient record of " & lPatient.Patient.LastName & ", " & lPatient.Patient.FirstName
                lEventLog.HandleEvent()
                ''section of event log ends here..............
            Catch ex As Exception
            End Try

        Catch ex As Exception
            lConnection.RollBackTrans()
            Throw New Exception(ex.Message & " : BLL\PatientMethodsExtended.UpdatePatient(ByRef pPatientDB As PatientDBExtended, ByRef pPatientInsuranceDbPrimary As PatientInsuranceDB, ByRef pPatientInsuranceDbSecondary As PatientInsuranceDB, ByRef pUser='" & pUser.UserId & "' As User, ByVal pUpdateXml As String, ByVal pPageURL='" & pPageURL & "' As String) ")
            'Return False
        End Try

        Return True
    End Function
    '' Added For Asif Bhai use 
    Public Shared Function GetPatient(ByVal pPatientID As String) As PatientDB
        Dim lPatient As Patient
        Dim lUser As User

        

        Try
            lUser = CType(HttpContext.Current.Session("User"), User)
            lPatient = New Patient(lUser.ConnectionString)

            lPatient.Patient.PatientID = pPatientID
            lPatient.GetRecordByID()
        Catch ex As Exception
            Throw New Exception(ex.Message & " : BLL\PatientMethodsExtended.GetPatient(ByVal pPatientID As String) ")
        End Try

        Return lPatient.Patient

    End Function
    '' Added For Asif Bhai use  
    Public Shared Function GetPatientDetails(ByVal pPatientID As String) As PatientDBExtended
        Dim lPatient As PatientExtended
        Dim lUser As User
        Try
            lUser = CType(HttpContext.Current.Session("User"), User)
            lPatient = New PatientExtended(lUser.ConnectionString)

            lPatient.Patient.PatientID = pPatientID
            lPatient.GetPatientWithDetailsByID()
        Catch ex As Exception
            Throw New Exception(ex.Message & " : BLL\PatientMethodsExtended.GetPatientDetails(ByVal pPatientID As String) ")
        End Try

        Return lPatient.Patient

    End Function

    Public Shared Function GetPatientDetails(ByVal pConnectionString As String, ByVal pPatientID As String) As PatientDBExtended
        Dim lPatient As PatientExtended
        Dim lUser As User
        Try

            lPatient = New PatientExtended(pConnectionString)

            lPatient.Patient.PatientID = pPatientID
            lPatient.GetPatientWithDetailsByID()
        Catch ex As Exception
            Throw New Exception(ex.Message & " : BLL\PatientMethodsExtended.GetPatientDetails(ByVal pPatientID As String) ")
        End Try

        Return lPatient.Patient

    End Function

    Public Overloads Shared Function UpdatePatientPreviewOld(ByRef pPatientDB As PatientDBExtended, ByRef pPatientInsuranceDbPrimary As PatientInsuranceDB, ByRef pPatientInsuranceDbSecondary As PatientInsuranceDB, ByRef pUser As User, ByVal pPageURL As String) As Boolean
        Dim lConnection As New Connection(pUser.ConnectionString)
        Dim lPatient As New PatientExtended(lConnection)
        Dim lPatientAllergy As New PatientAllergy(lConnection)
        Dim lPatientinsurance As New PatientInsurance(lConnection)
        'Dim lErrorLog As New ErrorLog()
        'Dim lEventLog As New EventLog()
        'Dim lResult As Boolean
        'Dim lCond As String

        lPatient.Patient = pPatientDB
        lPatientinsurance.PatientInsurance = pPatientInsuranceDbPrimary
        lPatientinsurance.PatientInsurance.PatientID = lPatient.Patient.PatientID
        Try
            lConnection.BeginTrans()
            lPatient.UpdateRecordPreview()
            If ((pPatientInsuranceDbPrimary.InsuranceCompanyName <> "" And pPatientInsuranceDbPrimary.InsuranceCompanyID <> 0) Or pPatientInsuranceDbPrimary.InsurerId <> 0) Then
                If (lPatientinsurance.CheckInsurance) Then
                    lPatientinsurance.InsertRecord()
                End If
            End If
            If ((pPatientInsuranceDbSecondary.InsuranceCompanyName <> "" And pPatientInsuranceDbSecondary.InsuranceCompanyID <> 0) Or pPatientInsuranceDbSecondary.InsurerId <> 0) Then
                lPatientinsurance.PatientInsurance = pPatientInsuranceDbSecondary
                lPatientinsurance.PatientInsurance.PatientID = lPatient.Patient.PatientID
                If (lPatientinsurance.CheckInsurance) Then
                    lPatientinsurance.InsertRecord()
                End If
            End If
            lConnection.CommitTrans()
        Catch ex As Exception
            lConnection.RollBackTrans()
            'lErrorLog.HandleError(ex, pUser, pPageURL)
            Return False
        End Try

        Return True
    End Function
    Public Overloads Shared Function UpdatePatientPreview(ByRef pPatientDB As PatientDBExtended, ByRef pPatientInsuranceDbPrimary As PatientInsuranceDB, ByRef pPatientInsuranceDbSecondary As PatientInsuranceDB, ByRef pUser As User, ByVal pPageURL As String) As Boolean
        Dim lConnection As Connection
        Dim lPatient As PatientExtended
        Dim lPatientAllergy As PatientAllergy
        Dim lPatientinsurance As PatientInsurance
        'Dim lErrorLog As New ErrorLog()
        'Dim lEventLog As New EventLog()
        'Dim lResult As Boolean
        'Dim lCond As String

        
        Try
            lConnection = New Connection(pUser.ConnectionString)
            lPatient = New PatientExtended(lConnection)
            lPatientAllergy = New PatientAllergy(lConnection)
            lPatientinsurance = New PatientInsurance(lConnection)

            lPatient.Patient = pPatientDB
            lPatientinsurance.PatientInsurance = pPatientInsuranceDbPrimary
            lPatientinsurance.PatientInsurance.PatientID = lPatient.Patient.PatientID

            lConnection.BeginTrans()
            lPatient.UpdateRecordPreview()
            If ((pPatientInsuranceDbPrimary.InsuranceCompanyName <> "" And pPatientInsuranceDbPrimary.InsuranceCompanyID <> 0) Or pPatientInsuranceDbPrimary.InsurerId <> 0) Then
                If (lPatientinsurance.CheckInsurance) Then
                    lPatientinsurance.InsertRecord()
                Else
                    lPatientinsurance.UpdateRecord()
                End If
            End If
            If ((pPatientInsuranceDbSecondary.InsuranceCompanyName <> "" And pPatientInsuranceDbSecondary.InsuranceCompanyID <> 0) Or pPatientInsuranceDbSecondary.InsurerId <> 0) Then
                lPatientinsurance.PatientInsurance = pPatientInsuranceDbSecondary
                lPatientinsurance.PatientInsurance.PatientID = lPatient.Patient.PatientID
                If (lPatientinsurance.CheckInsurance) Then
                    lPatientinsurance.InsertRecord()
                Else
                    lPatientinsurance.UpdateRecord()
                End If
            End If
            lConnection.CommitTrans()
        Catch ex As Exception
            lConnection.RollBackTrans()
            Throw New Exception(ex.Message & " : BLL\PatientMethodsExtended.UpdatePatientPreview(ByRef pPatientDB As PatientDBExtended, ByRef pPatientInsuranceDbPrimary As PatientInsuranceDB, ByRef pPatientInsuranceDbSecondary As PatientInsuranceDB, ByRef pUser As User, ByVal pPageURL As String) ")
        End Try

        Return True
    End Function

    Public Overloads Shared Function SearchPatient(ByVal pSearchString As String, ByVal pUser As User) As DataSet
        Dim lPatient As New Patient(pUser.ConnectionString)
        Dim lDS As DataSet = Nothing

        Try
            lDS = lPatient.GetPatients(pSearchString)
        Catch ex As Exception

        End Try
        Return lDS
    End Function

    Public Overloads Shared Function GetPatientEncounters(ByVal PatientID As Integer) As DataSet
        Dim lUser As User = CType(HttpContext.Current.Session("User"), User)
        Dim lPatient As New PatientExtended(lUser.ConnectionString)
        Dim lDS As DataSet = Nothing

        Try
            lDS = lPatient.GetPatientEncounters(PatientID)
        Catch ex As Exception

        End Try
        Return lDS
    End Function
    Public Overloads Shared Function GetPatientEncountersByID(ByVal PatientID As Integer, ByVal EncounterID As Integer) As DataSet
        Dim lUser As User = CType(HttpContext.Current.Session("User"), User)
        Dim lPatient As New PatientExtended(lUser.ConnectionString)
        Dim lDS As DataSet = Nothing

        Try
            lDS = lPatient.GetPatientEncountersByID(PatientID, EncounterID)
        Catch ex As Exception

        End Try
        Return lDS
    End Function

    Public Overloads Shared Function GetPatientEncountersByID(ByVal pUser As User, ByVal PatientID As Integer, ByVal EncounterID As Integer) As DataSet
        Dim lUser As User = pUser
        Dim lPatient As New PatientExtended(lUser.ConnectionString)
        Dim lDS As DataSet = Nothing

        Try
            lDS = lPatient.GetPatientEncountersByID(PatientID, EncounterID)
        Catch ex As Exception

        End Try
        Return lDS
    End Function

    Public Overloads Shared Function GetProceduresByPatientID(ByVal PatientID As Integer) As DataSet
        Dim lUser As User = CType(HttpContext.Current.Session("User"), User)
        Dim lPatient As New PatientExtended(lUser.ConnectionString)
        Dim lDS As DataSet = Nothing

        Try
            lDS = lPatient.GetProceduresByPatientID(PatientID)
        Catch ex As Exception

        End Try
        Return lDS
    End Function

    'add note be: Kanwal Jeet
    'Public Overloads Shared Function AddNotes(ByVal pNotesXml As String) As Boolean
    '    Dim lConnection As Connection
    '    Dim lPatient As PatientExtended

    '    Dim lPatientNotes As PatientNotes

    '    Dim lAddPatientNotesXml As String
    '    'Dim lErrorLog As New ErrorLog()
    '    Dim lEventLog As New EventLog()
    '    'Dim lResult As Boolean
    '    'Dim lCond As String

    '    Try
    '        'lConnection = New Connection(pUser.ConnectionString)
    '        'lPatient = New PatientExtended(lConnection)

    '        lPatientNotes = New PatientNotes(lConnection)



    '        lConnection.BeginTrans()
    '        lPatient.UpdateRecord()

    '        ''Patient Allergy

    '        ''Notes Insert
    '        If (pNotesXml IsNot Nothing AndAlso pNotesXml <> "") Then
    '            lAddPatientNotesXml = PatientMethodsExtended.AddNotes(pNotesXml)
    '            If lAddPatientNotesXml <> "" Then
    '                lPatientNotes.DeleteRecordByID()
    '                lPatientNotes.InsertRecord(lAddPatientNotesXml)
    '            End If
    '        End If


    '        lConnection.CommitTrans()

    '        Try
    '            ''section of event log...............
    '        Catch ex As Exception
    '        End Try

    '    Catch ex As Exception
    '        lConnection.RollBackTrans()
    '        Throw New Exception(ex.Message & " : BLL\PatientMethodsExtended.UpdatePatient(ByRef pPatientDB As PatientDBExtended, ByRef pPatientInsuranceDbPrimary As PatientInsuranceDB, ByRef pPatientInsuranceDbSecondary As PatientInsuranceDB, ByRef pUser='" & pUser.UserId & "' As User, ByVal pUpdateXml As String, ByVal pPageURL='" & pPageURL & "' As String) ")
    '        'Return False
    '    End Try

    '    Return True
    'End Function
    


    Public Shared Function GetPatientStatement(ByVal pCOndition As String, ByVal pOrderby As String) As DataSet
        Dim lPatient As PatientExtended
        Dim lUser As User
        Dim lds As DataSet


        Try
            lUser = CType(HttpContext.Current.Session("User"), User)
            lPatient = New PatientExtended(lUser.ConnectionString)


            lds = lPatient.GetPatientStatement(pCOndition, pOrderby)
        Catch ex As Exception
            Throw New Exception(ex.Message & " : BLL\PatientMethodsExtended.GetPatientDetails(ByVal pPatientID As String) ")
        End Try

        Return lds

    End Function

    Public Shared Function GetPatientStatementinfo(ByVal pPatientID As String) As DataSet
        Dim lPatient As PatientExtended
        Dim lUser As User
        Dim lds As DataSet


        Try
            lUser = CType(HttpContext.Current.Session("User"), User)
            lPatient = New PatientExtended(lUser.ConnectionString)


            lds = lPatient.GetPatientStatementinfo(pPatientID)
        Catch ex As Exception
            Throw New Exception(ex.Message & " : BLL\PatientMethodsExtended.GetPatientDetails(ByVal pPatientID As String) ")
        End Try

        Return lds

    End Function
    Public Shared Function GetPatientStatementView(ByVal pPatientID As Integer) As DataSet
        Dim lPatient As PatientExtended
        Dim lUser As User
        Dim lds As DataSet


        Try
            lUser = CType(HttpContext.Current.Session("User"), User)
            lPatient = New PatientExtended(lUser.ConnectionString)


            lds = lPatient.GetPatientStatementView(pPatientID)
        Catch ex As Exception
            Throw New Exception(ex.Message & " : BLL\PatientMethodsExtended.GetPatientDetails(ByVal pPatientID As String) ")
        End Try

        Return lds

    End Function

    Public Shared Function GetPatientState(ByVal pstateid As String) As String
        Dim lPatient As PatientExtended
        Dim lUser As User
        Dim lState As String = String.Empty

        Try
            lUser = CType(HttpContext.Current.Session("User"), User)
            lPatient = New PatientExtended(lUser.ConnectionString)


            lState = lPatient.GetPatientState(pstateid)

            Return lState

        Catch ex As Exception
            Return ""
        End Try



    End Function

End Class
