Imports Microsoft.VisualBasic
Imports Telerik.WebControls

Public Class SuperBillMethods
    Public Shared Sub LoadICD9Grid(ByRef pGrid As RadGrid, ByVal pCode As String)
        Dim lICD As New ICD9(ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString())

        pGrid.DataSource = lICD.GetAllRecords("And Code like '" & pCode & "%' ", "ICD9")

    End Sub

    Public Shared Sub LoadICDGridByDescription(ByRef pGrid As RadGrid, ByVal pDescription As String, ByVal pCode As String)
        Dim lCPT As New CPT(ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString())

        pGrid.DataSource = lCPT.GetAllRecords("And Description like '" & Utility.AdjustApostrophie(pDescription) & "%'   And Code Like '" & Utility.AdjustApostrophie(pCode) & "%' ", "ICD9")

    End Sub


    'THIS IS FOR LOADING THE ICDs IN THE COMBO BOX
    Public Shared Sub LoadICDForCombo(ByRef pCombo As RadComboBox, ByVal pCode As String)
        Dim lICD As New ICD9(ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString())

        pCombo.DataSource = lICD.GetTopNRecords("And Code like '" & pCode & "%' ", "ICD9", "Top(5) ")
        pCombo.DataBind()

    End Sub


    'THIS IS FOR LOADING THE CPTs IN THE COMBO BOX
    Public Shared Sub LoadCPTForCombo(ByRef pCombo As RadComboBox, ByVal pCode As String)
        Dim lCPT As New CPT(ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString())

        pCombo.DataSource = lCPT.GetTopNRecords("And Code like '" & pCode & "%' ", "CPT", "Top(5) ")
        pCombo.DataBind()

    End Sub


    'THIS FUNCTION CHECKS WHETHER THE GIVEN CODE EXISTS IN THE DATABASE OR NOT
    Public Shared Function CPTCodeExists(ByVal pCode As String) As String

        Try


            Dim lCPT As New CPT(ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString())
            Dim lDataSet As DataSet = Nothing

            lDataSet = lCPT.GetAllRecords("And Code like '" & pCode & "' ", "CPT")

            If lDataSet.Tables(0).Rows.Count > 0 Then
                Return lDataSet.Tables(0).Rows(0).Item("SHORTDESCRIPTION")
            Else
                Return String.Empty
            End If

        Catch ex As Exception
            Return String.Empty
        End Try

    End Function


    Public Shared Sub LoadCPTGrid(ByRef pGrid As RadGrid, ByVal pCode As String)
        Dim lCPT As New CPT(ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString())

        pGrid.DataSource = lCPT.GetAllRecords("And Code like '" & pCode & "%' ", "CPT")

    End Sub

    Public Shared Sub LoadCPTGridByDescription(ByRef pGrid As RadGrid, ByVal pDescription As String, ByVal pCode As String)
        Dim lCPT As New CPT(ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString())

        pGrid.DataSource = lCPT.GetAllRecords("And ShortDescription like '" & Utility.AdjustApostrophie(pDescription) & "%'  And Code Like '" & Utility.AdjustApostrophie(pCode) & "%' ", "CPT")

    End Sub


    Public Shared Sub AddHeading(ByVal pHeading As String, ByRef pListBox As ListBox)
        For Each lItem As ListItem In pListBox.Items
            If lItem.Text.ToUpper = pHeading.ToUpper Then
                Return
            End If
        Next
        pListBox.Items.Add(pHeading)
    End Sub

    Public Shared Sub LoadHeadingListBox(ByVal pSuperBillId As String, ByRef pListBox As ListBox)
        Dim lCPT As CPT
        Dim lUser As User
        Dim lDs As DataSet

        lUser = CType(HttpContext.Current.Session.Item("User"), User)
        lCPT = New CPT(lUser.ConnectionString)

        lCPT.CPT.SuperBillId = pSuperBillId
        lDs = lCPT.GetHeading()

        For Each lRow As DataRow In lDs.Tables(0).Rows
            pListBox.Items.Add(lRow("Heading"))
        Next

    End Sub
    Public Shared Function LoadSuperBillSession(ByVal pSuperBillId As String, ByVal pSortingOption As String) As Boolean
        'ICDSortBy + Order + CPTSortBy + Order 

        'ByVal pICDOrderBy As String, ByVal pCPTOrderBy As String
        Dim lUser As User
        Dim lCPT As CPT
        Dim lICD As ICD9
        Dim lICDColl As ICD9Coll
        Dim lCPTColl As CPTColl
        Dim lICDOrderBy As String = ""
        Dim lCPTOrderBy As String = ""

        lUser = CType(HttpContext.Current.Session("User"), User)

        lCPT = New CPT(lUser.ConnectionString)
        lICD = New ICD9(lUser.ConnectionString)

        Try
            If pSortingOption.Length = 4 Then
                lICDOrderBy = " Order By " & IIf(Left(pSortingOption, 1) = "C", "Code", "Description") _
                               & " " & IIf(Mid(pSortingOption, 2, 1) = "A", " ", "Desc")

                lCPTOrderBy = " Order By HeadingOrder," & IIf(Mid(pSortingOption, 3, 1) = "C", "Code", "ShortDescription") _
                               & " " & IIf(Mid(pSortingOption, 4, 1) = "A", " ", "Desc")
            End If

            lICD.ICD9.SuperBillId = pSuperBillId
            lICDColl = lICD.GetICDCollection(lICDOrderBy)

            lCPT.CPT.SuperBillId = pSuperBillId
            lCPTColl = lCPT.GetCPTCollection(lCPTOrderBy)

            HttpContext.Current.Session.Add("ICD9Coll", lICDColl)
            HttpContext.Current.Session.Add("CPTColl", lCPTColl)

        Catch ex As Exception
            Return False
        End Try

        Return True

    End Function

    
    Public Shared Function AddSuperBill(ByRef pSuperBillDB As SuperBillDB, ByRef pCPTItems As GridItemCollection, ByRef pICDItems As GridItemCollection, ByRef lListBox As ListBox, ByVal pPageURL As String) As Boolean

        Dim lUser As User
        Dim lConnection As Connection
        Dim lSuperBillId As String
        Dim lErrorLog As New ErrorLog()
        Dim lEventLog As New EventLog()

        lUser = CType(HttpContext.Current.Session("User"), User)

        lConnection = New Connection(lUser.ConnectionString)

        Dim lSuperBill As New SuperBill(lConnection)
        Dim lSuperBillCPT As New CPT(lConnection)
        Dim lSuperBillICD9 As New ICD9(lConnection)
        Dim lListItem As ListItem



        Try
            lConnection.BeginTrans()


            lSuperBillId = lSuperBill.GetUniqueId("")

            lSuperBill.SuperBill = pSuperBillDB
            lSuperBill.SuperBill.SuperBillId = lSuperBillId


            lSuperBill.InsertRecord()

            With lSuperBillCPT.CPT
                .SuperBillId = lSuperBillId

                For Each lItem As GridItem In pCPTItems
                    .Code = Utility.AdjustApostrophie(lItem.Cells(6).Text) 'Code
                    .ShortDescription = Utility.AdjustApostrophie(lItem.Cells(7).Text) 'Description
                    .Heading = Utility.AdjustApostrophie(lItem.Cells(4).Text) 'Description
                    .Fees = lItem.Cells(8).Text 'Fees
                    .IMO = lItem.Cells(5).Text 'IMO

                    lListItem = lListBox.Items.FindByText(lItem.Cells(4).Text)
                    If lListItem IsNot Nothing Then
                        .HeadingOrder = IIf(lListBox.Items.IndexOf(lListItem) = -1, "0", lListBox.Items.IndexOf(lListItem))
                    Else
                        .HeadingOrder = "0"
                    End If
                    lSuperBillCPT.InsertRecord()
                Next
            End With

            With lSuperBillICD9.ICD9
                .SuperBillId = lSuperBillId

                For Each lItem As GridItem In pICDItems
                    .Code = Utility.AdjustApostrophie(lItem.Cells(4).Text) 'Code
                    .Description = Utility.AdjustApostrophie(lItem.Cells(5).Text) 'Description
                    .IMOCode = Utility.AdjustApostrophie(lItem.Cells(3).Text) 'IMO Code

                    lSuperBillICD9.InsertRecord()
                Next
            End With

            lEventLog.EventLog.ClinicID = lUser.ClinicId
            lEventLog.EventLog.EventTypeID = 18 'EventType.CreateEmployee
            lEventLog.EventLog.ExtraID = lSuperBillId
            lEventLog.EventLog.OCcurTime = Date.Now()
            lEventLog.EventLog.UserID = lUser.UserId
            lEventLog.EventLog.EventDescription = "A SuperBill of ID '" + lSuperBillId.ToString() + "' is created of the clinic having ClinicID '" + lUser.ClinicId + "' on '" + lEventLog.EventLog.OCcurTime + "' by the loginID '" + lUser.LoginId + "'"
            lEventLog.HandleEvent()

            lConnection.CommitTrans()
        Catch ex As Exception
            lConnection.RollBackTrans()
            lErrorLog.HandleError(ex, lUser, pPageURL)
            Return False
        End Try

        Return True

    End Function


    Public Shared Function UpdateSuperBill(ByRef pSuperBillDB As SuperBillDB, ByRef pCPTItems As GridItemCollection, ByRef pICDItems As GridItemCollection, ByRef lListBox As ListBox, ByVal pPageURL As String) As Boolean


        Dim lUser As User

        lUser = CType(HttpContext.Current.Session("User"), User)

        Dim lConnection As New Connection(lUser.ConnectionString)
        Dim lSuperBill As New SuperBill(lConnection)
        Dim lSuperBillCPT As New CPT(lConnection)
        Dim lSuperBillICD9 As New ICD9(lConnection)

        'Dim lAuthorization As New Authorization(lConnection)
        Dim lErrorLog As New ErrorLog()
        Dim lEventLog As New EventLog()
        Dim lResult As Boolean
        Dim lCond As String
        Dim lListItem As ListItem

        Try
            lConnection.BeginTrans()

            lSuperBill.SuperBill = pSuperBillDB

            lSuperBill.UpdateRecord()


            With lSuperBillCPT.CPT

                lSuperBillCPT.DeleteRecord(" And SuperBillId =" & lSuperBill.SuperBill.SuperBillId)

                .SuperBillId = lSuperBill.SuperBill.SuperBillId
                For Each lItem As GridItem In pCPTItems
                    .Code = Utility.AdjustApostrophie(lItem.Cells(6).Text) 'Code
                    .ShortDescription = Utility.AdjustApostrophie(lItem.Cells(7).Text) 'Description
                    .Heading = Utility.AdjustApostrophie(lItem.Cells(4).Text) 'Description
                    .Fees = lItem.Cells(8).Text 'Fees
                    .IMO = lItem.Cells(5).Text

                    lListItem = lListBox.Items.FindByText(lItem.Cells(4).Text)
                    If lListItem IsNot Nothing Then
                        .HeadingOrder = IIf(lListBox.Items.IndexOf(lListItem) = -1, "0", lListBox.Items.IndexOf(lListItem))
                    Else
                        .HeadingOrder = "0"
                    End If

                    lSuperBillCPT.InsertRecord()
                Next

            End With

            With lSuperBillICD9.ICD9

                lSuperBillICD9.DeleteRecord(" And SuperBillId =" & lSuperBill.SuperBill.SuperBillId)

                .SuperBillId = lSuperBill.SuperBill.SuperBillId
                For Each lItem As GridItem In pICDItems
                    .Code = Utility.AdjustApostrophie(lItem.Cells(4).Text) 'Code
                    .Description = Utility.AdjustApostrophie(lItem.Cells(5).Text) 'Description
                    .IMOCode = Utility.AdjustApostrophie(lItem.Cells(3).Text) 'IMO Code

                    lSuperBillICD9.InsertRecord()
                Next

            End With


            lEventLog.EventLog.ClinicID = lUser.ClinicId
            lEventLog.EventLog.EventTypeID = EventType.UpdateSuperBill
            lEventLog.EventLog.ExtraID = lSuperBill.SuperBill.SuperBillId
            lEventLog.EventLog.OCcurTime = Date.Now()
            lEventLog.EventLog.UserID = lUser.UserId
            lEventLog.EventLog.EventDescription = "A SuperBill of ID '" + lSuperBill.SuperBill.SuperBillId.ToString() + "' has been Updated of the clinic having ClinicID '" + lUser.ClinicId + "' on '" + lEventLog.EventLog.OCcurTime + "' by the loginID '" + lUser.LoginId + "'"
            lEventLog.HandleEvent()

            lConnection.CommitTrans()
        Catch ex As Exception
            lConnection.RollBackTrans()
            lErrorLog.HandleError(ex, lUser, pPageURL)
            Return False
        End Try

        Return True

    End Function


    Public Shared Sub Load_SuperBillGrid(ByRef pGrid As RadGrid, ByVal pCond As String, ByRef pUser As User)

        Dim lSuperBill As New SuperBill(pUser.ConnectionString)
        Dim lDs As DataSet

        Try
            lDs = lSuperBill.GetAllRecords(pCond)
            pGrid.DataSource = lDs
        Catch ex As Exception

        End Try


    End Sub

    Public Shared Function DeleteSuperBill(ByVal pSuperBillId As String, ByRef pUser As User, ByVal pPageURL As String) As String
        Dim lConnection As New Connection(pUser.ConnectionString)
        Dim lSuperBill As New SuperBill(lConnection)
        Dim lCPT As New CPT(lConnection)
        Dim lICD As New ICD9(lConnection)

        Dim lErrorLog As New ErrorLog()
        Dim lEventLog As New EventLog()
        Dim lResult As Boolean

        lSuperBill.SuperBill.SuperBillId = pSuperBillId
        lCPT.CPT.SuperBillId = pSuperBillId
        lICD.ICD9.SuperBillId = pSuperBillId

        Try
            lConnection.BeginTrans()

            lSuperBill.DeleteRecordByID()

            lCPT.DeleteRecordByID()
            lICD.DeleteRecordByID()

            lEventLog.EventLog.ClinicID = pUser.ClinicId
            lEventLog.EventLog.EventTypeID = 20 'EventType.DeleteEmployee 
            lEventLog.EventLog.ExtraID = pSuperBillId
            lEventLog.EventLog.OCcurTime = Date.Now()
            lEventLog.EventLog.UserID = pUser.UserId
            lEventLog.EventLog.EventDescription = "A SuperBill of ID '" + pSuperBillId.ToString() + "' is deleted of the clinic having ClinicID '" + pUser.ClinicId + "' on '" + lEventLog.EventLog.OCcurTime + "' by the loginID '" + pUser.LoginId + "'"
            lEventLog.HandleEvent()

            lConnection.CommitTrans()

        Catch ex As Exception
            lConnection.RollBackTrans()
            lErrorLog.HandleError(ex, pUser, pPageURL)
            Return "Error Deleting SuperBill"
        End Try

        Return ""

    End Function


    Public Shared Sub MoveUp(ByRef pListBox As ListBox)
        For i As Integer = 0 To pListBox.Items.Count - 1
            If pListBox.Items(i).Selected Then
                If i > 0 AndAlso Not pListBox.Items(i - 1).Selected Then
                    Dim bottom As ListItem = pListBox.Items(i)
                    pListBox.Items.Remove(bottom)
                    pListBox.Items.Insert(i - 1, bottom)
                    pListBox.Items(i - 1).Selected = True
                End If
            End If
        Next
    End Sub

    Public Shared Sub MoveDown(ByRef pListBox As ListBox)
        Dim startindex As Integer = pListBox.Items.Count - 1
        For i As Integer = startindex To -1 + 1 Step -1
            If pListBox.Items(i).Selected Then
                If i < startindex AndAlso Not pListBox.Items(i + 1).Selected Then
                    Dim bottom As ListItem = pListBox.Items(i)
                    pListBox.Items.Remove(bottom)
                    pListBox.Items.Insert(i + 1, bottom)
                    pListBox.Items(i + 1).Selected = True
                End If
            End If
        Next
    End Sub
    'Public Shared Sub Load_PatientCPTGrid(ByRef pGrid As RadGrid, ByVal pCond As String, ByRef pUser As User)

    '    Dim lCPT As New CPT(pUser.ConnectionString)
    '    Dim lDs As DataSet

    '    Try
    '        lDs = lCPT.GetAllRecords(pCond, "SuperBillCPT")
    '        pGrid.DataSource = lDs
    '    Catch ex As Exception

    '    End Try

    'End Sub

    Public Shared Function GetPatientSuperBill(ByVal pPatientSuperBillID As String) As DataSet
        Dim lPatientSuperBill As PatientSuperBill = Nothing
        Dim lCondition As String = String.Empty
        Dim lUser As User = Nothing

        Try
            lUser = HttpContext.Current.Session.Item("User")
            lPatientSuperBill = New PatientSuperBill(lUser.ConnectionString)
            lCondition = " And PatientSuperBillID = " & pPatientSuperBillID

            Return lPatientSuperBill.GetAllRecords(lCondition)

        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Public Shared Function GetPatientSuperBillReport(ByVal pPatientSuperBillID As String) As DataSet
        Dim lPatientSuperBill As PatientSuperBill = Nothing
        Dim lCondition As String = String.Empty
        Dim lUser As User = Nothing

        Try
            lUser = HttpContext.Current.Session.Item("User")
            lPatientSuperBill = New PatientSuperBill(lUser.ConnectionString)
            lCondition = " And PatientSuperBillID = " & pPatientSuperBillID

            Return lPatientSuperBill.GetAllRecordsReport(lCondition)

        Catch ex As Exception
            Return Nothing
        End Try
    End Function



    Public Shared Function GetICD(ByVal pSuperBillId As String, ByVal pOrderBy As String, ByVal pTableName As String) As DataSet
        Dim lUser As User
        Dim lICD As ICD9
        Dim lArrOrderBy As String()
        Dim lOrderColumn As String = ""
        Dim lOrder As String = ""



        If pOrderBy <> "" Then
            lArrOrderBy = pOrderBy.Split("|")
            lOrderColumn = IIf(lArrOrderBy(0) = "C", "Code", "Description")
            lOrder = IIf(Left(lArrOrderBy(1), 1) = "A", " ", "Desc")
        End If

        lUser = CType(HttpContext.Current.Session("User"), User)
        lICD = New ICD9(lUser.ConnectionString)

        lICD.ICD9.SuperBillId = pSuperBillId
        Return lICD.GetICDForTemplatePrint("Order By " & lOrderColumn & " " & lOrder, pTableName)

    End Function
    Public Shared Function GetICDPreviewPrint(ByVal pPatientSuperBillId As String, ByVal pSuperBillId As String, ByVal pOrderBy As String, ByVal pTableName As String) As DataSet
        Dim lUser As User
        Dim lICD As ICD9
        Dim lArrOrderBy As String()
        Dim lOrderColumn As String = ""
        Dim lOrder As String = ""



        If pOrderBy <> "" Then
            lArrOrderBy = pOrderBy.Split("|")
            lOrderColumn = IIf(lArrOrderBy(0) = "C", "Code", "Description")
            lOrder = IIf(Left(lArrOrderBy(1), 1) = "A", " ", "Desc")
        End If

        lUser = CType(HttpContext.Current.Session("User"), User)
        lICD = New ICD9(lUser.ConnectionString)

        lICD.ICD9.SuperBillId = pSuperBillId
        lICD.ICD9.PatientSuperBillId = pPatientSuperBillId
        Return lICD.GetICDForPreviewPrint("Order By IsSelected Desc," & lOrderColumn & " " & lOrder, pTableName)

    End Function

    Public Shared Function GetCPT(ByVal pSuperBillId As String, ByVal pOrderBy As String, ByVal pTableName As String) As DataSet
        Dim lUser As User
        Dim lCPT As CPT
        Dim lArrOrderBy As String()
        Dim lOrderColumn As String = ""
        Dim lOrder As String = ""


        If pOrderBy <> "" Then
            lArrOrderBy = pOrderBy.Split("|")
            lOrderColumn = IIf(lArrOrderBy(2) = "C", "Code", "ShortDescription")
            lOrder = IIf(Left(lArrOrderBy(3), 1) = "A", " ", "Desc")
        End If

        lUser = CType(HttpContext.Current.Session("User"), User)
        lCPT = New CPT(lUser.ConnectionString)

        lCPT.CPT.SuperBillId = pSuperBillId
        Return lCPT.GetICDForTemplatePrint("Order By HeadingOrder," & lOrderColumn & " " & lOrder, pTableName)
    End Function
    Public Shared Function GetCPTPreviewPrint(ByVal pPatientSuperBillId As String, ByVal pSuperBillId As String, ByVal pOrderBy As String, ByVal pTableName As String) As DataSet
        Dim lUser As User
        Dim lCPT As CPT
        Dim lArrOrderBy As String()
        Dim lOrderColumn As String = ""
        Dim lOrder As String = ""


        If pOrderBy <> "" Then
            lArrOrderBy = pOrderBy.Split("|")
            lOrderColumn = IIf(lArrOrderBy(2) = "C", "Code", "ShortDescription")
            lOrder = IIf(Left(lArrOrderBy(3), 1) = "A", " ", "Desc")
        End If

        lUser = CType(HttpContext.Current.Session("User"), User)
        lCPT = New CPT(lUser.ConnectionString)

        lCPT.CPT.SuperBillId = pSuperBillId
        lCPT.CPT.PatientSuperBillId = pPatientSuperBillId
        Return lCPT.GetCPTForPreviewPrint("Order By IsSelected Desc,HeadingOrder," & lOrderColumn & " " & lOrder, pTableName)
        'Return lCPT.GetCPTForPreviewPrint("Order by IsSelected Desc", pTableName)

    End Function

    Public Shared Function LoadSuperBillOrderInformation(ByVal pSuperBillID As String) As String
        Dim lUser As User
        Dim lSuperBill As SuperBill
        Dim lResult As Boolean
        Dim lOrderBy As String = ""

        lUser = CType(HttpContext.Current.Session.Item("User"), User)


        lSuperBill = New SuperBill(lUser.ConnectionString)
        lSuperBill.SuperBill.SuperBillId = pSuperBillID
        lResult = lSuperBill.GetRecordByID()

        If Not lResult Then
            Return ""
        End If

        With lSuperBill.SuperBill
            'ICDSortBy + Order + CPTSortBy + Order 
            lOrderBy = lSuperBill.SuperBill.ICDSortBy & "|" & lSuperBill.SuperBill.ICDSortOrder & "|" & _
                                       lSuperBill.SuperBill.CPTSortBy & "|" & lSuperBill.SuperBill.CPTSortOrder
        End With

        Return lOrderBy
    End Function

    Public Shared Function GetVisitSummary(ByVal pPatientSuperBillID As String) As DataSet
        Dim lPatientSuperBill As PatientSuperBill = Nothing
        Dim lCondition As String = String.Empty
        Dim lUser As User = Nothing

        Try
            lUser = HttpContext.Current.Session.Item("User")
            lPatientSuperBill = New PatientSuperBill(lUser.ConnectionString)
            lCondition = pPatientSuperBillID
            Return lPatientSuperBill.GetVisitSummary(lCondition)

        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Public Shared Function GetVisitDetail(ByVal pPatientId As String, ByVal pDOSFrom As String, ByVal pDOSTo As String) As DataSet
        Dim lPatientSuperBill As PatientSuperBill
        Dim lUser As User = Nothing

        Try
            lUser = HttpContext.Current.Session.Item("User")
            lPatientSuperBill = New PatientSuperBill(lUser.ConnectionString)
            Return lPatientSuperBill.GetVisitDetail(pPatientId, pDOSFrom, pDOSTo)

        Catch ex As Exception
            Return Nothing
        End Try
    End Function
    Public Shared Function GetModifier() As System.Data.DataSet
        Dim lSuperBill As SuperBill
        Dim lUser As User = Nothing
        Try

      
            lUser = CType(HttpContext.Current.Session.Item("User"), User)


            lSuperBill = New SuperBill(lUser.ConnectionString)
            Return lSuperBill.GetModifiers()
        Catch ex As Exception

        End Try
    End Function


    Public Shared Function GetPatientSuperBillForApplyPayment(ByVal pCondition As String) As DataSet
        Dim lPatientSuperBill As PatientSuperBill = Nothing
        Dim lCondition As String = String.Empty
        Dim lUser As User = Nothing

        Try
            lUser = HttpContext.Current.Session.Item("User")
            lPatientSuperBill = New PatientSuperBill(lUser.ConnectionString)
            lCondition = pCondition

            Return lPatientSuperBill.GetPatientSuperBillForApplyPayment(lCondition)

        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Public Shared Function GetCPTFromDateRange(ByVal pCPTCode As String, ByVal pFrom As DateTime, ByVal pTo As DateTime) As DataSet
        Dim lPatientSuperBill As PatientSuperBill = Nothing
        Dim lCondition As String = String.Empty
        Dim lUser As User = Nothing

        Try
            lUser = HttpContext.Current.Session.Item("User")
            lPatientSuperBill = New PatientSuperBill(lUser.ConnectionString)

            Return lPatientSuperBill.GetCPTFromDateRange(pCPTCode, pFrom, pTo)

        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Public Shared Function GetICDFromDateRange(ByVal pICDCode As String, ByVal pFrom As DateTime, ByVal pTo As DateTime) As DataSet
        Dim lPatientSuperBill As PatientSuperBill = Nothing
        Dim lCondition As String = String.Empty
        Dim lUser As User = Nothing

        Try
            lUser = HttpContext.Current.Session.Item("User")
            lPatientSuperBill = New PatientSuperBill(lUser.ConnectionString)

            Return lPatientSuperBill.GetICDFromDateRange(pICDCode, pFrom, pTo)

        Catch ex As Exception
            Return Nothing
        End Try
    End Function

End Class
