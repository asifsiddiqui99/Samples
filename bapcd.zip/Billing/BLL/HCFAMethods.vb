Imports Microsoft.VisualBasic
Imports Telerik.WebControls
Imports System.Transactions
Imports System.Web.SessionState.HttpSessionState

Public Class HCFAMethods

    Public Shared Function GetHCFAByPSBHdr(ByRef pUser As User, ByVal pPSBID As String) As HCFADB
        Dim lHCFA As New HCFA(pUser.ConnectionString)
        lHCFA.HCFA.PatientSuperBillID = pPSBID

        If (lHCFA.GetRecordByPatientSuperBillID()) Then
            Return lHCFA.HCFA
        Else
            lHCFA.HCFA = Nothing
            Return lHCFA.HCFA
        End If
    End Function
    Public Shared Function GetHCFAByPSBDtl(ByRef pUser As User, ByVal pPSBID As String) As HCFADetailColl
        Dim lHCFADtl As New HCFADetail(pUser.ConnectionString)

        Return lHCFADtl.GetRecordsFromPatientCPT(pPSBID)

    End Function
    Public Shared Function GetHCFAByHCFAHdr(ByRef pUser As User, ByVal pHCFAID As String) As HCFADB
        Dim lHCFA As New HCFA(pUser.ConnectionString)
        lHCFA.HCFA.HCFAID = pHCFAID

        If (lHCFA.GetRecordByID()) Then
            Return lHCFA.HCFA
        Else
            lHCFA.HCFA = Nothing
            Return lHCFA.HCFA
        End If
    End Function
    Public Shared Function GetHCFAByHCFADtl(ByRef pUser As User, ByVal pHCFAID As String) As HCFADetailColl
        Dim lHCFADtl As New HCFADetail(pUser.ConnectionString)
        lHCFADtl.HCFADetail.HCFAID = pHCFAID
        Return lHCFADtl.GetRecordsByID()
    End Function

    Public Shared Function InsertHCFA(ByRef pUser As User, ByRef pHCFADB As HCFADB, ByRef pHCFADtlCol As HCFADetailColl) As String
        Dim lConnection As New Connection(pUser.ConnectionString)
        Dim lHCFA As New HCFA(lConnection)
        Dim lHCFADetail As New HCFADetail(lConnection)
        'Dim lErrorLog As New ErrorLog()
        'Dim lEventLog As New EventLog()
        'Dim lResult As Boolean
        'Dim lCond As String

        lHCFA.HCFA = pHCFADB
        lHCFADetail.HCFADetailCol = pHCFADtlCol

        Try
            lHCFA.Connection.BeginTrans()
            Dim mHCFAID As Int32
            Dim mHCFADisplayID As Int32
            Dim mReturnString As String = lHCFA.GetUniqueIdHCFA()
            If (mReturnString <> "") Then
                mHCFAID = mReturnString.Split("|")(0)
                mHCFADisplayID = mReturnString.Split("|")(1)
            End If
            lHCFA.HCFA.HCFAID = mHCFAID
            lHCFA.HCFA.HCFADisplayID = mHCFADisplayID
            Dim Index As Int32
            For Index = 0 To lHCFADetail.HCFADetailCol.Count - 1
                lHCFADetail.HCFADetailCol.Item(Index).HCFAID = mHCFAID
            Next
            lHCFA.InsertRecord()
            lHCFADetail.InsertRecord()

            lHCFA.Connection.CommitTrans()
            Return mHCFADisplayID.ToString.PadLeft(5, "0")
        Catch ex As Exception
            lHCFA.Connection.RollBackTrans()
            Return ""
        End Try

    End Function

    Public Shared Function InsertEditedHCFA(ByRef pUser As User, ByRef pHCFADB As HCFADB, ByRef pPatientCPTCol As PatientCPTColl, ByVal pSuperBillID As String, ByVal pPnlAjaxHCFA As RadAjaxManager) As String
        Dim lConnection As New Connection(pUser.ConnectionString)
        Dim lHCFA As New HCFA(lConnection)
        Dim lPatientCPT As New PatientCPT(lConnection)
        Dim lHCFADetail As New HCFADetail(lConnection)
        Dim lTextBox As New TextBox
        Dim lCounter As Integer = 1
        lHCFA.HCFA = pHCFADB
        Dim lHcfaDisplayId As String = Convert.ToDateTime(lHCFA.HCFA.HCFAPreparedDate).Year.ToString & "-" & Convert.ToDateTime(lHCFA.HCFA.HCFAPreparedDate).Month.ToString.PadLeft(2, "0") & "-" & lHCFA.HCFA.HCFADisplayID.ToString.PadLeft(5, "0")

        Try
            lHCFA.Connection.BeginTrans()
            'lHCFA.EditHCFA()
            'lPatientCPT.UpdateRecordForPatientCPT(pSuperBillID, pHCFADB.HCFAID)
            For Each PatientCPTDB As PatientCPTDB In pPatientCPTCol
                lPatientCPT.PatientCPT = PatientCPTDB
                lPatientCPT.PatientCPT.HCFAID = pHCFADB.HCFAID
                'lPatientCPT.UpdateRecord(" And PatientSuperBillID = " & pSuperBillID)
            Next
            lHCFA.Connection.CommitTrans()
            Return lHcfaDisplayId
        Catch ex As Exception
            lHCFA.Connection.RollBackTrans()
            Return ""
        End Try
    End Function

    Public Shared Function InsertEditedHCFAUpdated(ByRef pUser As User, ByRef pHCFADBUpdated As HCFADBUpdated, ByRef pPatientCPTCol As PatientCPTColl, ByVal pSuperBillID As String, ByVal pPnlAjaxHCFA As RadAjaxManager) As String
        Dim lConnection As New Connection(pUser.ConnectionString)
        Dim lHCFAUpdated As New HCFAUpdated(lConnection)
        Dim lPatientCPT As New PatientCPT(lConnection)
        Dim lHCFADetailUpdated As New HCFADetailUpdated(lConnection)
        Dim lTextBox As New TextBox
        Dim lCounter As Integer = 1
        lHCFAUpdated.HCFAUpdated = pHCFADBUpdated
        Dim lHcfaDisplayId As String = Convert.ToDateTime(lHCFAUpdated.HCFAUpdated.HCFAPreparedDate).Year.ToString & "-" & Convert.ToDateTime(lHCFAUpdated.HCFAUpdated.HCFAPreparedDate).Month.ToString.PadLeft(2, "0") & "-" & lHCFAUpdated.HCFAUpdated.HCFADisplayID.ToString.PadLeft(5, "0")

        Try
            lHCFAUpdated.Connection.BeginTrans()

            For Each PatientCPTDB As PatientCPTDB In pPatientCPTCol
                lPatientCPT.PatientCPT = PatientCPTDB
                lPatientCPT.PatientCPT.HCFAID = pHCFADBUpdated.HCFAID

            Next
            lHCFAUpdated.Connection.CommitTrans()
            Return lHcfaDisplayId
        Catch ex As Exception
            lHCFAUpdated.Connection.RollBackTrans()
            Return ""
        End Try
    End Function

    'This function adds the HCFA Id to the claims and returns something
    Public Function GenerateHCFA(ByVal pConnectionString As String, ByVal pPatientSuperBillId As String) As Boolean

        Dim lConnection As New Connection(pConnectionString)
        Dim lPatientCPT As PatientCPT = Nothing

        Try
            lPatientCPT = New PatientCPT(lConnection)
            GenerateHCFA = lPatientCPT.GenerateClaim(pPatientSuperBillId)

        Catch ex As Exception
            GenerateHCFA = False
        End Try

    End Function



    Public Function InsertHCFA(ByVal pConnection As Connection, ByVal pHCFADB As HCFADB) As String

        Dim lHCFA As HCFA
        Dim lHCFAID As String = ""


        Try
            lHCFA = New HCFA(pConnection)
            lHCFA.HCFA = pHCFADB
            lHCFAID = lHCFA.InsertRecord()

            Return lHCFAID

        Catch ex As Exception

            Return ""

        End Try
    End Function


    Public Function UpdateHCFAIdForPatientCPT(ByVal pConnection As Connection, ByVal pHCFAID As String, ByVal pPatientSuperBillId As String, ByVal pClaimNumber As String) As Boolean
        Dim lHCFA As HCFA = Nothing

        Try
            lHCFA = New HCFA(pConnection)
            Return lHCFA.UpdateCPT(pHCFAID, pPatientSuperBillId, pClaimNumber)
        Catch ex As Exception
            Return False
        End Try
    End Function

    '    Public Shared Function UpdateHCFAUpdated(ByVal pConnectionString As String, ByVal pHCFADBUpdated As HCFADBUpdated) As Boolean

    '        Dim lResult As Boolean
    '        Dim lHcfaUpdated = New HCFAUpdated(pConnectionString)

    '        Dim lQuery1 = "UPDATE [HCFAUpdated] SET [MainICInsuranceType] ='" & pHCFADBUpdated.MainInsuranceCompany.InsuranceType & _
    '"',[MainPISubscriberID] ='" & pHCFADBUpdated.MainPatientInsurance.SubscriberID & _
    ' "',[PatientFirstName] ='" & pHCFADBUpdated.Patient.FirstName & _
    '      "',[PatientMiddleName] ='" & pHCFADBUpdated.Patient.MiddleName & _
    '      "',[PatientLastName] ='" & pHCFADBUpdated.Patient.LastName & _
    '      "',[PatientAddressLine1] ='" & pHCFADBUpdated.Patient.AddressLine1 & _
    '      "',[PatientAddressLine2] ='" & pHCFADBUpdated.Patient.AddressLine2 & _
    '"',[PatientDOB] ='" & pHCFADBUpdated.Patient.DOB & _
    '"' ,[PatientCity] = '" & pHCFADBUpdated.Patient.City & _
    '     "' ,[PatientStateID] ='" & pHCFADBUpdated.Patient.StateID & _
    '     "' ,[PatientZipCode]  ='" & pHCFADBUpdated.Patient.ZipCode & _
    '     "' ,[PatientHousePhone] = '" & pHCFADBUpdated.Patient.HomePhone & _
    '     "' ,[PatientWorkPhone]  = '" & pHCFADBUpdated.Patient.WorkPhone & _
    '"',[PatientGender]='" & pHCFADBUpdated.Patient.Gender & _
    '"',[MainPIRelationshipToPrimaryInsurer]='" & pHCFADBUpdated.MainPatientInsurance.RelationshipToPrimaryInsurer & _
    '"',[PatientMartialStatus]='" & pHCFADBUpdated.Patient.MartialStatus & _
    '"',[PatientEmploymentStatus]='" & pHCFADBUpdated.Patient.EmploymentStatus & _
    '"',[PatientConditionEmployment]='" & pHCFADBUpdated.PatientConditionEmployment & _
    '"',[PatientConditionAutoAccident]='" & pHCFADBUpdated.PatientConditionAutoAccident & _
    '"',[PatientConditionAutoAccPlace]='" & pHCFADBUpdated.Patient.StateID & _
    '"',[PatientConditionOtherAccident]='" & pHCFADBUpdated.PatientConditionOtherAccident & _
    '"',[Field19]='" & pHCFADBUpdated.Field19 & _
    ' "',[iPatientFirstName] ='" & pHCFADBUpdated.InsurerPatient.FirstName & _
    '      "',[iPatientMiddleName] ='" & pHCFADBUpdated.InsurerPatient.MiddleName & _
    '      "',[iPatientLastName] ='" & pHCFADBUpdated.InsurerPatient.LastName & _
    '      "',[iPatientAddressLine1] ='" & pHCFADBUpdated.InsurerPatient.AddressLine1 & _
    '      "',[iPatientAddressLine2] ='" & pHCFADBUpdated.InsurerPatient.AddressLine2 & _
    '"',[iPatientDOB]='" & pHCFADBUpdated.InsurerPatient.DOB & _
    '"',[iPatientCity]='" & pHCFADBUpdated.InsurerPatient.City & _
    '"',[iPatientStateID]='" & pHCFADBUpdated.InsurerPatient.StateID & _
    '"',[iPatientZipCode]='" & pHCFADBUpdated.InsurerPatient.ZipCode & _
    '"',[iPatientHousePhone]='" & pHCFADBUpdated.InsurerPatient.HomePhone & _
    '"',[MainPIGroupNo]='" & pHCFADBUpdated.OtherPatientInsurance.GroupNo & _
    '"',[iPatientGender]='" & pHCFADBUpdated.InsurerPatient.Gender & _
    '"',[iPatientEmployerName]='" & pHCFADBUpdated.InsurerPatient.EmployerName & _
    '"',[iPatientInsuranceName]='" & pHCFADBUpdated.InsurerPatient.InsuranceName & _
    '"',[MainPIPlanName]='" & pHCFADBUpdated.MainPatientInsurance.PlanName & _
    ' "',[OtherIPFirstName] ='" & pHCFADBUpdated.OtherInsurerPatient.FirstName & _
    '      "',[OtherIPMiddleName] ='" & pHCFADBUpdated.OtherInsurerPatient.MiddleName & _
    '      "',[OtherIPLastName] ='" & pHCFADBUpdated.OtherInsurerPatient.LastName & _
    '      "',[OtherIPAddressLine1] ='" & pHCFADBUpdated.OtherInsurerPatient.AddressLine1 & _
    '      "',[OtherIPAddressLine2] ='" & pHCFADBUpdated.OtherInsurerPatient.AddressLine2 & _
    '"',[OtherIPDOB]='" & pHCFADBUpdated.OtherInsurerPatient.DOB & _
    '"',[OtherPIGroupNo]='" & pHCFADBUpdated.OtherPatientInsurance.GroupNo & _
    '"',[OtherIPGender]='" & pHCFADBUpdated.OtherInsurerPatient.Gender & _
    '"',[OtherIPEmployerName]='" & pHCFADBUpdated.OtherInsurerPatient.EmployerName & _
    '"',[OtherIPInsuranceName]='" & pHCFADBUpdated.OtherInsurerPatient.InsuranceName & _
    '"',[OtherPIPlanName]='" & pHCFADBUpdated.OtherPatientInsurance.PlanName & _
    '"',[MainPISignatureOfFile]='" & pHCFADBUpdated.MainPatientInsurance.SignatureOfFile & _
    '"',[MainPISignatureDate]='" & pHCFADBUpdated.MainPatientInsurance.SignatureDate & _
    '"',[SignOnFile]='" & pHCFADBUpdated.SignOnFile & _
    '"',[DateOfOccurance]='" & pHCFADBUpdated.DateOfOccurance & _
    '"',[PreviousOccuranceDate]='" & pHCFADBUpdated.PreviousOccuranceDate & _
    '"',[RefPVDFirstName]='" & pHCFADBUpdated.ReferencePvd.FirstName & _
    '      "',[RefPVDMiddleName]='" & pHCFADBUpdated.ReferencePvd.MiddleName & _
    '      "',[RefPVDLastName]='" & pHCFADBUpdated.ReferencePvd.LastName & _
    '      "',[RefPVDTitle]='" & pHCFADBUpdated.ReferencePvd.Title & _
    '      "',[RefPVDAddressLine1]='" & pHCFADBUpdated.ReferencePvd.AddressLine1 & _
    '      "',[RefPVDAddressLine2]='" & pHCFADBUpdated.ReferencePvd.AddressLine2 & _
    '      "',[RefPVDCity]='" & pHCFADBUpdated.ReferencePvd.City & _
    '      "',[RefPVDState]='" & pHCFADBUpdated.ReferencePvd.State & _
    '      "',[RefPVDZipCode]='" & pHCFADBUpdated.ReferencePvd.ZipCode & _
    '      "',[RefPVDWorkPhone]='" & pHCFADBUpdated.ReferencePvd.WorkPhone & _
    '      "',[RefPVDExt]='" & pHCFADBUpdated.ReferencePvd.Ext & _
    '      "',[RefPVDFax]='" & pHCFADBUpdated.ReferencePvd.Fax & _
    '      "',[RefPVDEmail]='" & pHCFADBUpdated.ReferencePvd.Email & _
    '      "',[RefPVDNPI]='" & pHCFADBUpdated.ReferencePvd.NPI & _
    '      "',[RefPVDSpeciality]='" & pHCFADBUpdated.ReferencePvd.Speciality & _
    '      "',[RefPVDFacilityID]='" & pHCFADBUpdated.ReferencePvd.Facility & _
    '"',[PatUnableToWorkFrom]='" & pHCFADBUpdated.PatUnableToWorkFrom & _
    '"',[PatUnableToWorkTo]='" & pHCFADBUpdated.PatUnableToWorkTo & _
    '"',[HospitalizationDateFrom]='" & pHCFADBUpdated.HospitalizationDateFrom & _
    '"',[HospitalizationDateTo]='" & pHCFADBUpdated.HospitalizationDateTo & _
    '"',[IsOutsideLab]='" & pHCFADBUpdated.IsOutsideLab & _
    '"',[OutSideLabCharges]='" & pHCFADBUpdated.OutsideLabCharges & _
    '"',[ICD1]='" & pHCFADBUpdated.ICD1 & _
    '"',[ICD2]='" & pHCFADBUpdated.ICD2 & _
    '"',[ICD3]='" & pHCFADBUpdated.ICD3 & _
    '"',[ICD4]='" & pHCFADBUpdated.ICD1 & _
    ' "',[ServFacFacilityName]='" & pHCFADBUpdated.ServiceFacility.FacilityName & _
    '      "',[ServFacNPI]='" & pHCFADBUpdated.ServiceFacility.NPI & _
    '      "',[ServFacAddressLine1]='" & pHCFADBUpdated.ServiceFacility.AddressLine1 & _
    '      "',[ServFacAddressLine2]='" & pHCFADBUpdated.ServiceFacility.AddressLine2 & _
    '      "',[ServFacCity]='" & pHCFADBUpdated.ServiceFacility.City & _
    '      "',[ServFacState]='" & pHCFADBUpdated.ServiceFacility.State & _
    '      "',[ServFacZipCode]='" & pHCFADBUpdated.ServiceFacility.ZipCode & _
    '      "',[ServFacPhone]='" & pHCFADBUpdated.ServiceFacility.Phone & _
    '       "',[ServFacFacilityCode]='" & pHCFADBUpdated.ServiceFacility.FacilityCode & _
    '   "',[BPvdFirstName]='" & pHCFADBUpdated.BillingPvd.FirstName & _
    '        "',[BPvdMiddleName]='" & pHCFADBUpdated.BillingPvd.MiddleName & _
    '        "',[BPvdLastName]='" & pHCFADBUpdated.BillingPvd.LastName & _
    '        "',[BPvdAddressLine1]='" & pHCFADBUpdated.BillingPvd.AddressLine1 & _
    '        "',[BPvdAddressLine2]='" & pHCFADBUpdated.BillingPvd.AddressLine2 & _
    '        "',[BPvdCity]='" & pHCFADBUpdated.BillingPvd.City & _
    '        "',[BPvdState]='" & pHCFADBUpdated.BillingPvd.State & _
    '        "',[BPvdZipCode]='" & pHCFADBUpdated.BillingPvd.ZipCode & _
    '        "',[BPvdPhone1]='" & pHCFADBUpdated.BillingPvd.Phone1 & _
    '        "',[BPvdPhone2]='" & pHCFADBUpdated.BillingPvd.Phone2 & _
    '        "',[BPvdFax]='" & pHCFADBUpdated.BillingPvd.Fax & _
    '        "',[BPvdEmail]='" & pHCFADBUpdated.BillingPvd.Email & _
    '        "',[BPvdNPI]='" & pHCFADBUpdated.BillingPvd.NPI & _
    '        "',[BPvdTaxID]='" & pHCFADBUpdated.BillingPvd.TaxID & _
    '        "',[BPvdSSN]='" & pHCFADBUpdated.BillingPvd.SSN & _
    '"',[MedicadReSubCode]='" & pHCFADBUpdated.MedicadReSubCode & _
    '"',[MedicadReSubNo]='" & pHCFADBUpdated.MedicadReSubNo & _
    '"',[MainPIAuthorizationNumber]='" & pHCFADBUpdated.MainPatientInsurance.AuthorizationNumber & _
    '"',[PatientACNo]='" & pHCFADBUpdated.PatientACNo & _
    '"',[AcceptAssignment]='" & pHCFADBUpdated.AcceptAssignment & _
    '"',[TotalCharges]='" & pHCFADBUpdated.TotalCharges & _
    '"',[AmountPaid]='" & pHCFADBUpdated.AmountPaid & _
    '"',[BalanceDue]='" & pHCFADBUpdated.BalanceDue & _
    '"'  Where HCFAUpdated.HcfaId ='" & pHCFADBUpdated.HCFAID & "'"


    '        Try

    '            lResult = lHcfaUpdated.EditHCFAUpdated(lQuery1)


    '            Return lResult

    '        Catch ex As Exception
    '            Return Nothing
    '        End Try

    '    End Function
    '    Public Shared Function UpdateHCFADetailUpdated(ByVal pConnectionString As String, ByVal pHCFADetailDBUpdated As HCFADetailDBUpdated) As Boolean

    '        Dim lResult As Boolean
    '        Dim lHcfaUpdated As HCFAUpdated
    '        lHcfaUpdated = New HCFAUpdated(pConnectionString)
    '        Dim lQuery2 = "UPDATE [HCFADetailUpdated]SET [DignosisPointer] ='" & pHCFADetailDBUpdated.DignosisPointer & _
    '        "', [FacFacilityCode] ='" & pHCFADetailDBUpdated.ServiceFacility.FacilityCode & _
    '         "',[RPNPI] ='" & pHCFADetailDBUpdated.RenderingProvider.NPI & _
    '         "' where CPTCode='" & pHCFADetailDBUpdated.CPTCode & "' and HcfaId='" & pHCFADetailDBUpdated.HCFAID & "'"

    '        Try

    '            lResult = lHcfaUpdated.EditHCFADetailUpdated(lQuery2)


    '            Return lResult

    '        Catch ex As Exception
    '            Return Nothing
    '        End Try

    '    End Function

    Public Shared Function UpdateHCFA_HCFADtl_PatCPT_PSB(ByVal pConnectionString As String, ByVal pHCFADBUpdated As HCFADBUpdated, ByVal pHCFADetailDBUpdatedColl As HCFADetailCollUpdated) As Boolean

        Dim lConnection As New Connection(pConnectionString)
        Dim lHCFAUpdated As New HCFAUpdated(lConnection)
        Dim lHCFADtlUpdated As New HCFADetailUpdated(lConnection)
        Dim lPatCPT As New PatientCPT(lConnection)
        Dim lPSB As New PatientSuperBill(lConnection)

        Try
            lPatCPT.PatientCPT.PatientSuperBillId = pHCFADBUpdated.PatientSuperBillID
            lPSB.PatientSuperBill.PatientSuperBillID = pHCFADBUpdated.PatientSuperBillID

            lConnection.BeginTrans()

            lHCFAUpdated.UpdateHCFAUpdated(pHCFADBUpdated)
            lHCFADtlUpdated.UpdateHCFADetailUpdated(pHCFADetailDBUpdatedColl)
            lPatCPT.UpdatePatCptColFromHcfaCptCol(pHCFADetailDBUpdatedColl)
            lPSB.UpdatePsbFromHcfa(pHCFADBUpdated)

            lConnection.CommitTrans()
            Return True
        Catch ex As Exception
            lConnection.RollBackTrans()
            Return False
        End Try



    End Function
    Public Shared Function GetCPTForHCFA(ByVal pConnectionString As String, ByVal pPatientSuperBillId As String) As DataSet
        Dim lPatientCPT As PatientCPT = Nothing
        Dim lDataSet As DataSet = Nothing

        Try
            lPatientCPT = New PatientCPT(pConnectionString)
            lDataSet = lPatientCPT.GetAllRecords(" And PatientSuperBillId = " & pPatientSuperBillId & " And LineNumber <= 6 Order By LineNumber", "PatientCPT")


            Return lDataSet

        Catch ex As Exception
            Return Nothing
        End Try

    End Function
    Public Shared Function GetHCFADetailForHCFA(ByVal pConnectionString As String, ByVal pHCFAId As String) As HCFADetailCollUpdated

        Dim lHCFADetailUpdated = New HCFADetailUpdated(pConnectionString)


        Try

            Dim lHCFADetailCollUpdated = lHCFADetailUpdated.GetRecordsByHCFAID(pHCFAId)


            Return lHCFADetailCollUpdated

        Catch ex As Exception
            Return Nothing
        End Try

    End Function


    Public Shared Function InsertIntoHCFA(ByVal pConnectionString As String, _
                                    ByVal pPatientSuperBillId As String, _
                                    ByVal pCPTCount As Integer, _
                                    ByVal pCreatedByUserID As Integer) As HCFADB



        Dim lHCFA As HCFA
        Dim lHCFADB As HCFADB = Nothing
        Dim lDataSet As DataSet = Nothing

        Try
            lHCFA = New HCFA(pConnectionString)
            lHCFADB = New HCFADB

            lDataSet = lHCFA.InsertIntoHCFA(pPatientSuperBillId, pCPTCount, pCreatedByUserID)

            If lDataSet.Tables(0).Rows.Count > 0 Then

                With lHCFADB
                    .HCFAID = lDataSet.Tables(0).Rows(0).Item("HCFAID").ToString
                    .HCFADisplayID = lDataSet.Tables(0).Rows(0).Item("HCFADisplayID").ToString
                    .PatientSuperBillID = lDataSet.Tables(0).Rows(0).Item("PatientSuperBillID").ToString
                    .Type1 = lDataSet.Tables(0).Rows(0).Item("Type1").ToString
                    .Type2 = lDataSet.Tables(0).Rows(0).Item("Type2").ToString
                    .InsuredIDNumber = lDataSet.Tables(0).Rows(0).Item("InsuredIDNumber").ToString
                    .GroupNumber = lDataSet.Tables(0).Rows(0).Item("GroupNumber").ToString
                    .PatientName = lDataSet.Tables(0).Rows(0).Item("PatientName").ToString
                    .PatientDOB = lDataSet.Tables(0).Rows(0).Item("PatientDOB").ToString
                    .PatientGender = lDataSet.Tables(0).Rows(0).Item("PatientGender").ToString
                    .InsuredName = lDataSet.Tables(0).Rows(0).Item("InsuredName").ToString
                    .PatientAddress = lDataSet.Tables(0).Rows(0).Item("PatientAddress").ToString
                    .PatientCity = lDataSet.Tables(0).Rows(0).Item("PatientCity").ToString
                    .PatientZipCode = lDataSet.Tables(0).Rows(0).Item("PatientZipCode").ToString
                    .PatientState = lDataSet.Tables(0).Rows(0).Item("PatientState").ToString
                    .PatientTelephone = lDataSet.Tables(0).Rows(0).Item("PatientTelephone").ToString
                    .PatientRelationshipToInsured = lDataSet.Tables(0).Rows(0).Item("PatientRelationshipToInsured").ToString
                    .InsuredAddress = lDataSet.Tables(0).Rows(0).Item("InsuredAddress").ToString
                    .InsuredCity = lDataSet.Tables(0).Rows(0).Item("InsuredCity").ToString
                    .InsuredState = lDataSet.Tables(0).Rows(0).Item("InsuredState").ToString
                    .InsuredZipCode = lDataSet.Tables(0).Rows(0).Item("InsuredZipCode").ToString
                    .InsuredTelephone = lDataSet.Tables(0).Rows(0).Item("InsuredTelephone").ToString
                    .PatientMaritalStatus = lDataSet.Tables(0).Rows(0).Item("PatientMaritalStatus").ToString
                    .PatientEmploymentInfo = lDataSet.Tables(0).Rows(0).Item("PatientEmploymentInfo").ToString
                    .OtherInsuredName = lDataSet.Tables(0).Rows(0).Item("OtherInsuredName").ToString
                    .OtherInsuredPolicy = lDataSet.Tables(0).Rows(0).Item("OtherInsuredPolicy").ToString
                    .OtherInsuredDOB = lDataSet.Tables(0).Rows(0).Item("OtherInsuredDOB").ToString
                    .OtherInsuredGender = lDataSet.Tables(0).Rows(0).Item("OtherInsuredGender").ToString
                    .OtherInsuredEmployer = lDataSet.Tables(0).Rows(0).Item("OtherInsuredEmployer").ToString
                    .SecondaryInsurancePlan = lDataSet.Tables(0).Rows(0).Item("SecondaryInsurancePlan").ToString
                    .AnotherInsuredPolicy = lDataSet.Tables(0).Rows(0).Item("AnotherInsuredPolicy").ToString
                    .AnotherInsuredDOB = lDataSet.Tables(0).Rows(0).Item("AnotherInsuredDOB").ToString
                    .AnotherInsuredGender = lDataSet.Tables(0).Rows(0).Item("AnotherInsuredGender").ToString
                    .AnotherInsuredEmployerName = lDataSet.Tables(0).Rows(0).Item("AnotherInsuredEmployerName").ToString
                    .AnotherInsuredInsurancePlan = lDataSet.Tables(0).Rows(0).Item("AnotherInsuredInsurancePlan").ToString
                    .IsAnotherPlan = lDataSet.Tables(0).Rows(0).Item("IsAnotherPlan").ToString
                    .ReleaseInfoSignature = lDataSet.Tables(0).Rows(0).Item("ReleaseInfoSignature").ToString
                    .ReleaseInfoDate = lDataSet.Tables(0).Rows(0).Item("ReleaseInfoDate").ToString
                    .PaymentSignature = lDataSet.Tables(0).Rows(0).Item("PaymentSignature").ToString
                    .DateOfOccurance = lDataSet.Tables(0).Rows(0).Item("DateOfOccurance").ToString
                    .PreviousOccuranceDate = lDataSet.Tables(0).Rows(0).Item("PreviousOccuranceDate").ToString
                    .UnableToWorkTo = lDataSet.Tables(0).Rows(0).Item("UnableToWorkTo").ToString
                    .UnableToWorkFrom = lDataSet.Tables(0).Rows(0).Item("UnableToWorkFrom").ToString
                    .ICD1 = lDataSet.Tables(0).Rows(0).Item("ICD1").ToString
                    .ICD2 = lDataSet.Tables(0).Rows(0).Item("ICD2").ToString
                    .ICD3 = lDataSet.Tables(0).Rows(0).Item("ICD3").ToString
                    .ICD4 = lDataSet.Tables(0).Rows(0).Item("ICD4").ToString
                    .FacilityId = lDataSet.Tables(0).Rows(0).Item("FacilityID").ToString
                    .FacilityName = lDataSet.Tables(0).Rows(0).Item("FacilityName").ToString
                    .FacilityAddress = lDataSet.Tables(0).Rows(0).Item("FacilityAddress").ToString
                    .FacilityProvider = lDataSet.Tables(0).Rows(0).Item("FacilityProvider").ToString
                    .FacilityCode = lDataSet.Tables(0).Rows(0).Item("FacilityCode").ToString
                    .ClinicName = lDataSet.Tables(0).Rows(0).Item("ClinicName").ToString
                    .ClinicAddress = lDataSet.Tables(0).Rows(0).Item("ClinicAddress").ToString
                    .ClinicCity = lDataSet.Tables(0).Rows(0).Item("ClinicCity").ToString
                    .ClinicState = lDataSet.Tables(0).Rows(0).Item("ClinicState").ToString
                    .ClinicZip = lDataSet.Tables(0).Rows(0).Item("ClinicZip").ToString
                    .ClinicPhoneNumber = lDataSet.Tables(0).Rows(0).Item("ClinicPhoneNumber").ToString
                    .ClinicPinNumber = lDataSet.Tables(0).Rows(0).Item("ClinicPinNumber").ToString
                    .ClinicGroupNumber = lDataSet.Tables(0).Rows(0).Item("ClinicGroupNumber").ToString
                    .ProviderName = lDataSet.Tables(0).Rows(0).Item("ProviderName").ToString
                    .InsuranceNameHdr = lDataSet.Tables(0).Rows(0).Item("InsuranceNameHdr").ToString
                    .PrimaryInsuranceAddress1 = lDataSet.Tables(0).Rows(0).Item("InsuranceAddressLine1").ToString
                    .PrimaryInsuranceAddress2 = lDataSet.Tables(0).Rows(0).Item("InsuranceAddressLine2").ToString
                    .PrimaryInsuranceCity = lDataSet.Tables(0).Rows(0).Item("InsuranceCity").ToString
                    .PrimaryInsuranceState = lDataSet.Tables(0).Rows(0).Item("InsuranceState").ToString
                    .PrimaryInsuranceZipCode = lDataSet.Tables(0).Rows(0).Item("InsuranceZipCode").ToString
                    .FederalTaxID = lDataSet.Tables(0).Rows(0).Item("FederalTaxID").ToString
                    .PatientAccountNumber = lDataSet.Tables(0).Rows(0).Item("PatientAccountNumber").ToString
                    .IsAcceptAssignment = lDataSet.Tables(0).Rows(0).Item("IsAcceptAssignment").ToString
                    .TotalCharge = lDataSet.Tables(0).Rows(0).Item("TotalCharge").ToString
                    .AmountPaid = lDataSet.Tables(0).Rows(0).Item("AmountPaid").ToString
                    .BalanceDue = lDataSet.Tables(0).Rows(0).Item("BalanceDue").ToString
                    .DoctorUserID = lDataSet.Tables(0).Rows(0).Item("DoctorUserID").ToString
                    If (lDataSet.Tables(0).Rows(0).Item("RefferingProviderID").ToString <> "") Then
                        .RefferingProviderID = lDataSet.Tables(0).Rows(0).Item("RefferingProviderID").ToString
                    Else
                        .RefferingProviderID = 0
                    End If
                    .HCFAPreparedDate = lDataSet.Tables(0).Rows(0).Item("HCFAPreparedDate").ToString
                    .FacilitySecondaryIdentificationQualifier = lDataSet.Tables(0).Rows(0).Item("FacilitySecondaryIdentificationQualifier").ToString
                    .ClinicSecondaryIdentificationQualifier = lDataSet.Tables(0).Rows(0).Item("ClinicSecondaryIdentificationQualifier").ToString
                    .RefferingProviderID = lDataSet.Tables(0).Rows(0).Item("RefferingProviderID").ToString
                    .RefferingProviderIDQualifier = lDataSet.Tables(0).Rows(0).Item("RefferingProviderIDQualifier").ToString
                    .RefferingProviderName = lDataSet.Tables(0).Rows(0).Item("RefferingProviderName").ToString
                    .RefferingProviderNPI = lDataSet.Tables(0).Rows(0).Item("RefferingProviderNPI").ToString
                    .InsuranceAddressLine1 = lDataSet.Tables(0).Rows(0).Item("InsuranceAddressLine1").ToString
                    .InsuranceAddressLine2 = lDataSet.Tables(0).Rows(0).Item("InsuranceAddressLine2").ToString

                    .FacilityCity = lDataSet.Tables(0).Rows(0).Item("FacilityCity").ToString
                    .FacilityState = lDataSet.Tables(0).Rows(0).Item("FacilityState").ToString
                    .FacilityZipCode = lDataSet.Tables(0).Rows(0).Item("FacilityZipCode").ToString
                    .HCFAType = lDataSet.Tables(0).Rows(0).Item("HCFAType").ToString

                End With

            End If



            Return lHCFADB
        Catch ex As Exception
            Return Nothing
        End Try


    End Function

    'Public Shared Function GenerateClaim(ByVal pPSBID As String, ByVal pClaimLevel As String) As Boolean

    '    Dim lUser As User
    '    Dim lCPT As HCFADetail
    '    Dim lCPTsColl As New HCFADetailColl()
    '    Dim lHCFADB As HCFADB
    '    Dim lHCFADetail As HCFADetail
    '    Dim lHCFA As HCFA
    '    Dim lHcfaUniqueId As String
    '    Dim lTotalCharges As Double = 0
    '    Dim lPatientCPT As PatientCPT
    '    Dim lPatientCPTColl As New PatientCPTColl()

    '    Try
    '        lUser = CType(HttpContext.Current.Session("User"), User)
    '        lCPT = New HCFADetail(lUser.ConnectionString)
    '        lHCFADB = New HCFADB()
    '        lHCFA = New HCFA(lUser.ConnectionString)
    '        lHCFADetail = New HCFADetail(lHCFA.Connection)
    '        lPatientCPT = New PatientCPT(lHCFA.Connection)

    '        lHCFADB = LoadHCFA(pPSBID, pClaimLevel)

    '        lCPTsColl = lCPT.GetRecordsFromPatientCPT(pPSBID)

    '        lHCFA.Connection.BeginTrans()

    '        lHcfaUniqueId = lHCFA.GetUniqueIdHCFA()

    '        For Each lCPTItem As HCFADetailDB In lCPTsColl
    '            lCPTItem.HCFAID = lHcfaUniqueId.Split("|")(0)
    '            lTotalCharges = lTotalCharges + (lCPTItem.Charges * lCPTItem.Days)
    '        Next

    '        lHCFADB.HCFAID = lHcfaUniqueId.Split("|")(0)
    '        lHCFADB.HCFADisplayID = lHcfaUniqueId.Split("|")(1)
    '        lHCFADB.TotalCharge = lTotalCharges
    '        lHCFADB.BalanceDue = lTotalCharges - lHCFADB.AmountPaid

    '        lHCFA.HCFA = lHCFADB
    '        lHCFA.InsertRecord()

    '        lHCFADetail.HCFADetailCol = lCPTsColl
    '        lHCFADetail.InsertRecord()

    '        'lPatientCPT.UpdateRecordForPatientCPT(pPSBID, lHCFA.HCFA.HCFAID)

    '        lHCFA.Connection.CommitTrans()
    '        Return True
    '    Catch ex As Exception
    '        lHCFA.Connection.RollBackTrans()
    '        Return False
    '    End Try
    'End Function


    Public Shared Function GenerateClaim(ByVal pPSBID As String, ByVal pClaimLevel As String) As Boolean

        Dim lUser As User
        Dim lCPT As HCFADetailUpdated
        Dim lCPTsColl As New HCFADetailCollUpdated()
        'Dim lCPTsColl As New HCFADetailColl()

        Dim lHCFAUpdated As HCFAUpdated
        Dim lHCFADetailUpdated As HCFADetailUpdated
        'Dim lHCFADetail As HCFADetail
        Dim lHcfaUniqueId As String
        Dim lTotalCharges As Double = 0
        Dim lPatientCPT As PatientCPT
        Dim lPatientCPTColl As New PatientCPTColl()
        lUser = CType(HttpContext.Current.Session("User"), User)

        Dim lRenderingPvd = New Employee(lUser.ConnectionString)
        Dim lFacility = New Facility(lUser.ConnectionString)
        Try

            lCPT = New HCFADetailUpdated(lUser.ConnectionString)

            lHCFAUpdated = New HCFAUpdated(lUser.ConnectionString)
            lHCFADetailUpdated = New HCFADetailUpdated(lHCFAUpdated.Connection)
            'lHCFADetail = New HCFADetail(lHCFAUpdated.Connection)
            lPatientCPT = New PatientCPT(lHCFAUpdated.Connection)

            ' lHCFADBUpdated = LoadHCFA(pPSBID, pClaimLevel)
            lHCFAUpdated.HCFAUpdated = LoadHCFAUpdated(pPSBID, pClaimLevel)
            ' lHCFADetailUpdated.HCFADetailUpdated = lCPT.GetRecordsFromPatientCPTUpdated(pPSBID)

            'lCPTsColl = lCPT.GetRecordsFromPatientCPT(pPSBID)

            lCPTsColl = lCPT.GetRecordsFromPatientCPTUpdated(pPSBID)
            lHCFAUpdated.Connection.BeginTrans()

            'lHcfaUniqueId = lHCFAUpdated.GetUniqueIdHCFA()
            lHcfaUniqueId = lHCFAUpdated.GetUniqueIdHCFAUpdated()

            For Each lCPTItem As HCFADetailDBUpdated In lCPTsColl
                lCPTItem.HCFAID = lHcfaUniqueId.Split("|")(0)
                lTotalCharges = lTotalCharges + (lCPTItem.Charges * lCPTItem.Days)
                lRenderingPvd.Employee.EmployeeID = lCPTItem.RenderingProvider.EmployeeID
                lRenderingPvd.GetRecordByID()
                lHCFADetailUpdated.HCFADetailUpdated.RenderingProvider = lRenderingPvd.Employee

                lFacility.GetFacilityById("FacilityId='" & lCPTItem.ServiceFacility.FacilityID & "'")
                lHCFADetailUpdated.HCFADetailUpdated.ServiceFacility = lFacility.FacilityDB


            Next

            lHCFAUpdated.HCFAUpdated.HCFAID = lHcfaUniqueId.Split("|")(0)
            lHCFAUpdated.HCFAUpdated.HCFADisplayID = lHcfaUniqueId.Split("|")(1)
            lHCFAUpdated.HCFAUpdated.PatientACNo = lUser.ClinicId & "H" & Convert.ToDateTime(lHCFAUpdated.HCFAUpdated.HCFAPreparedDate).Year.ToString.Substring(2) & Convert.ToDateTime(lHCFAUpdated.HCFAUpdated.HCFAPreparedDate).Month.ToString.PadLeft(2, "0") & lHCFAUpdated.HCFAUpdated.HCFADisplayID.ToString.PadLeft(5, "0")
            lHCFAUpdated.HCFAUpdated.TotalCharges = lTotalCharges
            lHCFAUpdated.HCFAUpdated.BalanceDue = lTotalCharges - lHCFAUpdated.HCFAUpdated.AmountPaid
            lHCFAUpdated.HCFAUpdated.IsActive = "Y"

            lHCFAUpdated.InsertRecord()

            lHCFADetailUpdated.HCFADetailColUpdated = lCPTsColl

            lHCFADetailUpdated.InsertRecord()


            'lHCFADetail.HCFADetailCol = lCPTsColl
            'lHCFADetail.InsertRecord()

            lHCFAUpdated.Connection.CommitTrans()



            Return True
        Catch ex As Exception
            lHCFAUpdated.Connection.RollBackTrans()
            Return False
        End Try
    End Function


    Public Shared Function LoadHCFA(ByVal pPSBID As String, ByVal pType As String) As HCFADB
        Dim lPSB As PatientSuperBill
        Dim lUser As User
        Dim lPriPatInsDtl As PatientInsuranceDetail
        Dim lSecPatInsDtl As PatientInsuranceDetail
        Dim lBillingProvider As BillingProvider
        Dim lReferringProvider As ReferringProvider
        Dim lClinic As Clinic
        Dim lFacility As Facility
        Dim lPatientICD As PatientICD
        Dim lPatientICDColl As New PatientICDColl()
        Dim lHCFADB As HCFADB
        Dim lPatientExtended As PatientExtended
        Dim lPriInsResult As Boolean
        Dim lSecInsResult As Boolean
        Dim lEmployee As Employee
        Dim lState As State

        Try
            lUser = CType(HttpContext.Current.Session("User"), User)

            lPSB = New PatientSuperBill(lUser.ConnectionString)
            lPriPatInsDtl = New PatientInsuranceDetail(lUser.ConnectionString)
            lSecPatInsDtl = New PatientInsuranceDetail(lUser.ConnectionString)
            lBillingProvider = New BillingProvider(lUser.ConnectionString)
            lReferringProvider = New ReferringProvider(lUser.ConnectionString)
            lClinic = New Clinic(lUser.ConnectionString)
            lFacility = New Facility(lUser.ConnectionString)
            lPatientICD = New PatientICD(lUser.ConnectionString)
            lPatientExtended = New PatientExtended(lUser.ConnectionString)
            lState = New State(lUser.ConnectionString)
            lHCFADB = New HCFADB()
            lEmployee = New Employee(lUser.ConnectionString)

            If (pPSBID <> "") Then
                lPSB.PatientSuperBill.PatientSuperBillID = pPSBID
                lPSB.GetRecordByID()

                lPatientExtended.Patient.PatientID = lPSB.PatientSuperBill.PatientId
                lPatientExtended.GetRecordByID()
                lState.State.StateID = lPatientExtended.Patient.StateID
                lState.GetRecordByID()
                lPatientExtended.Patient.StateID = lState.State.Abbr

                lEmployee.Employee.EmployeeID = lPSB.PatientSuperBill.PrescriberID
                lEmployee.GetRecordByID()

                lPriInsResult = lPriPatInsDtl.GetRecordByID(lPSB.PatientSuperBill.PatientId, "P")
                lSecInsResult = lSecPatInsDtl.GetRecordByID(lPSB.PatientSuperBill.PatientId, "S")

                lBillingProvider.BillingProvider.ProviderID = lPSB.PatientSuperBill.PrescriberID
                If (pType.ToUpper = "P") Then
                    lBillingProvider.BillingProvider.EntryInsuranceTypeValue = lPriPatInsDtl.PatientInsuranceDetail.InsuranceCompany.InsuranceType
                ElseIf (pType.ToUpper = "S") Then
                    lBillingProvider.BillingProvider.EntryInsuranceTypeValue = lSecPatInsDtl.PatientInsuranceDetail.InsuranceCompany.InsuranceType
                End If
                lBillingProvider.GetBillingProviderById()

                lReferringProvider.ReferringProviderDB.NPI = lPSB.PatientSuperBill.ReferringProviderNPI
                lReferringProvider.GetReferringProviderById()

                lClinic.Clinic.ClinicId = lUser.ClinicId
                lClinic.GetRecordByID()
                lState.State.StateID = lClinic.Clinic.StateId
                lState.GetRecordByID()
                lClinic.Clinic.StateId = lState.State.Abbr


                lFacility.GetFacilityById("FacilityCode='" & lClinic.Clinic.FacilityCode & "'")

                lPatientICD.PatientICD.PatientSuperBillId = lPSB.PatientSuperBill.PatientSuperBillID
                lPatientICDColl = lPatientICD.GetPatientICDCollection("")

                '*****************************************************************************************************************
                '                                ************** Filling HCFA DB **************
                '*****************************************************************************************************************
                lHCFADB.HCFADisplayID = "0"
                lHCFADB.PatientSuperBillID = lPSB.PatientSuperBill.PatientSuperBillID
                lHCFADB.GroupNumber = ""
                lHCFADB.DoctorUserID = lPSB.PatientSuperBill.PrescriberID
                lHCFADB.CreateByUserID = lUser.UserId
                'lHCFADB.CreateByUserID = lUser.UserId

                lHCFADB.ProviderName = lEmployee.Employee.LastName & "," & lEmployee.Employee.FirstName & " " & lEmployee.Employee.MiddleName
                lHCFADB.HCFAPreparedDate = Date.Now.Date

                If (pType.ToUpper = "P") Then

                    lHCFADB.InsuranceNameHdr = lPriPatInsDtl.PatientInsuranceDetail.InsuranceCompany.CompanyName
                    lHCFADB.InsuranceAddressHdr = lPriPatInsDtl.PatientInsuranceDetail.InsuranceCompany.City & " " & lPriPatInsDtl.PatientInsuranceDetail.InsuranceCompany.State & " " & lPriPatInsDtl.PatientInsuranceDetail.InsuranceCompany.ZipCode
                    lHCFADB.InsuranceAddressLine1 = lPriPatInsDtl.PatientInsuranceDetail.InsuranceCompany.AddressLine1
                    lHCFADB.InsuranceAddressLine2 = lPriPatInsDtl.PatientInsuranceDetail.InsuranceCompany.AddressLine2

                    lHCFADB.PrimaryInsuranceAddress1 = lPriPatInsDtl.PatientInsuranceDetail.InsuranceCompany.AddressLine1
                    lHCFADB.PrimaryInsuranceAddress2 = lPriPatInsDtl.PatientInsuranceDetail.InsuranceCompany.AddressLine2
                    lHCFADB.PrimaryInsuranceCity = lPriPatInsDtl.PatientInsuranceDetail.InsuranceCompany.City
                    lHCFADB.PrimaryInsuranceState = lPriPatInsDtl.PatientInsuranceDetail.InsuranceCompany.State
                    lHCFADB.PrimaryInsuranceZipCode = lPriPatInsDtl.PatientInsuranceDetail.InsuranceCompany.ZipCode

                    lHCFADB.Type1 = lPriPatInsDtl.PatientInsuranceDetail.InsuranceCompany.InsuranceType.ToUpper

                    If (lSecInsResult) Then
                        lHCFADB.Type2 = lSecPatInsDtl.PatientInsuranceDetail.InsuranceCompany.InsuranceType.ToUpper
                    Else
                        lHCFADB.Type2 = ""
                    End If


                    ' ******** 1(a) ********
                    lHCFADB.InsuredIDNumber = lPriPatInsDtl.PatientInsuranceDetail.PInsurance.SubscriberID
                    ' **********************

                    ' ********** 4 **********
                    lHCFADB.InsuredName = lPriPatInsDtl.PatientInsuranceDetail.Insurer.LastName & "," & lPriPatInsDtl.PatientInsuranceDetail.Insurer.FirstName & " " & lPriPatInsDtl.PatientInsuranceDetail.Insurer.MiddleName
                    ' ***********************

                    ' ********** 6 **********
                    lHCFADB.PatientRelationshipToInsured = lPriPatInsDtl.PatientInsuranceDetail.PInsurance.RelationshipToPrimaryInsurer
                    ' ***********************

                    ' ********** 7 **********
                    lHCFADB.InsuredAddress = lPriPatInsDtl.PatientInsuranceDetail.Insurer.AddressLine1 & " " & lPriPatInsDtl.PatientInsuranceDetail.Insurer.AddressLine2
                    lHCFADB.InsuredCity = lPriPatInsDtl.PatientInsuranceDetail.Insurer.City
                    lHCFADB.InsuredState = lPriPatInsDtl.PatientInsuranceDetail.Insurer.StateID
                    lHCFADB.InsuredZipCode = lPriPatInsDtl.PatientInsuranceDetail.Insurer.ZipCode
                    lHCFADB.InsuredTelephone = lPriPatInsDtl.PatientInsuranceDetail.Insurer.HomePhone
                    ' ***********************

                    ' ********** 9 **********
                    If (lSecInsResult) Then
                        lHCFADB.OtherInsuredName = lSecPatInsDtl.PatientInsuranceDetail.Insurer.LastName & "," & lSecPatInsDtl.PatientInsuranceDetail.Insurer.FirstName & " " & lSecPatInsDtl.PatientInsuranceDetail.Insurer.MiddleName
                        lHCFADB.OtherInsuredPolicy = lSecPatInsDtl.PatientInsuranceDetail.PInsurance.GroupNo
                        lHCFADB.OtherInsuredDOB = lSecPatInsDtl.PatientInsuranceDetail.Insurer.DOB
                        If (lSecPatInsDtl.PatientInsuranceDetail.Insurer.Gender.ToUpper = "MALE") Then
                            lHCFADB.OtherInsuredGender = "M"
                        ElseIf (lSecPatInsDtl.PatientInsuranceDetail.Insurer.Gender.ToUpper = "FEMALE") Then
                            lHCFADB.OtherInsuredGender = "F"
                        End If
                        lHCFADB.OtherInsuredEmployer = lSecPatInsDtl.PatientInsuranceDetail.Insurer.EmployerName
                        lHCFADB.SecondaryInsurancePlan = lSecPatInsDtl.PatientInsuranceDetail.PInsurance.PlanName
                    Else
                        lHCFADB.OtherInsuredName = ""
                        lHCFADB.OtherInsuredPolicy = ""
                        lHCFADB.OtherInsuredDOB = ""
                        lHCFADB.OtherInsuredGender = ""
                        lHCFADB.OtherInsuredEmployer = ""
                        lHCFADB.SecondaryInsurancePlan = ""
                    End If
                    ' ***********************

                    ' ******** 11 ********
                    lHCFADB.AnotherInsuredPolicy = lPriPatInsDtl.PatientInsuranceDetail.PInsurance.GroupNo
                    lHCFADB.AnotherInsuredDOB = lPriPatInsDtl.PatientInsuranceDetail.Insurer.DOB
                    If (lPriPatInsDtl.PatientInsuranceDetail.Insurer.Gender.ToUpper = "MALE") Then
                        lHCFADB.AnotherInsuredGender = "M"
                    ElseIf (lPriPatInsDtl.PatientInsuranceDetail.Insurer.Gender.ToUpper = "FEMALE") Then
                        lHCFADB.AnotherInsuredGender = "F"
                    End If
                    lHCFADB.AnotherInsuredEmployerName = lPriPatInsDtl.PatientInsuranceDetail.Insurer.EmployerName
                    lHCFADB.AnotherInsuredInsurancePlan = lPriPatInsDtl.PatientInsuranceDetail.PInsurance.PlanName
                    If (lSecInsResult) Then
                        lHCFADB.IsAnotherPlan = "Y"
                    Else
                        lHCFADB.IsAnotherPlan = "N"
                    End If
                    ' *********************

                    ' ********** 23 **********
                    lHCFADB.PriorAuthorizationNumber = lPriPatInsDtl.PatientInsuranceDetail.PInsurance.AuthorizationNumber
                    ' ************************

                    lHCFADB.HCFAType = "P"

                ElseIf (pType.ToUpper = "S") Then

                    lHCFADB.InsuranceNameHdr = lSecPatInsDtl.PatientInsuranceDetail.InsuranceCompany.CompanyName
                    lHCFADB.InsuranceAddressHdr = lSecPatInsDtl.PatientInsuranceDetail.InsuranceCompany.City & " " & lSecPatInsDtl.PatientInsuranceDetail.InsuranceCompany.State & " " & lSecPatInsDtl.PatientInsuranceDetail.InsuranceCompany.ZipCode
                    lHCFADB.InsuranceAddressLine1 = lSecPatInsDtl.PatientInsuranceDetail.InsuranceCompany.AddressLine1
                    lHCFADB.InsuranceAddressLine2 = lSecPatInsDtl.PatientInsuranceDetail.InsuranceCompany.AddressLine2

                    lHCFADB.PrimaryInsuranceAddress1 = lSecPatInsDtl.PatientInsuranceDetail.InsuranceCompany.AddressLine1
                    lHCFADB.PrimaryInsuranceAddress2 = lSecPatInsDtl.PatientInsuranceDetail.InsuranceCompany.AddressLine2
                    lHCFADB.PrimaryInsuranceCity = lSecPatInsDtl.PatientInsuranceDetail.InsuranceCompany.City
                    lHCFADB.PrimaryInsuranceState = lSecPatInsDtl.PatientInsuranceDetail.InsuranceCompany.State
                    lHCFADB.PrimaryInsuranceZipCode = lSecPatInsDtl.PatientInsuranceDetail.InsuranceCompany.ZipCode

                    lHCFADB.Type1 = lSecPatInsDtl.PatientInsuranceDetail.InsuranceCompany.InsuranceType.ToUpper
                    lHCFADB.Type2 = lPriPatInsDtl.PatientInsuranceDetail.InsuranceCompany.InsuranceType.ToUpper

                    ' ******** 1(a) ********
                    lHCFADB.InsuredIDNumber = lSecPatInsDtl.PatientInsuranceDetail.PInsurance.SubscriberID
                    ' **********************

                    ' ********** 4 **********
                    lHCFADB.InsuredName = lSecPatInsDtl.PatientInsuranceDetail.Insurer.LastName & "," & lSecPatInsDtl.PatientInsuranceDetail.Insurer.FirstName & " " & lSecPatInsDtl.PatientInsuranceDetail.Insurer.MiddleName
                    ' ***********************

                    ' ********** 6 **********
                    lHCFADB.PatientRelationshipToInsured = lSecPatInsDtl.PatientInsuranceDetail.PInsurance.RelationshipToPrimaryInsurer
                    ' ***********************

                    ' ********** 7 **********
                    lHCFADB.InsuredAddress = lSecPatInsDtl.PatientInsuranceDetail.Insurer.AddressLine1 & " " & lSecPatInsDtl.PatientInsuranceDetail.Insurer.AddressLine2
                    lHCFADB.InsuredCity = lSecPatInsDtl.PatientInsuranceDetail.Insurer.City
                    lHCFADB.InsuredState = lSecPatInsDtl.PatientInsuranceDetail.Insurer.StateID
                    lHCFADB.InsuredZipCode = lSecPatInsDtl.PatientInsuranceDetail.Insurer.ZipCode
                    lHCFADB.InsuredTelephone = lSecPatInsDtl.PatientInsuranceDetail.Insurer.HomePhone
                    ' ***********************

                    ' ********** 9 **********
                    If (lPriInsResult) Then
                        lHCFADB.OtherInsuredName = lPriPatInsDtl.PatientInsuranceDetail.Insurer.LastName & "," & lPriPatInsDtl.PatientInsuranceDetail.Insurer.FirstName & " " & lPriPatInsDtl.PatientInsuranceDetail.Insurer.MiddleName
                        lHCFADB.OtherInsuredPolicy = lPriPatInsDtl.PatientInsuranceDetail.PInsurance.GroupNo
                        lHCFADB.OtherInsuredDOB = lPriPatInsDtl.PatientInsuranceDetail.Insurer.DOB
                        If (lPriPatInsDtl.PatientInsuranceDetail.Insurer.Gender.ToUpper = "MALE") Then
                            lHCFADB.OtherInsuredGender = "M"
                        ElseIf (lPriPatInsDtl.PatientInsuranceDetail.Insurer.Gender.ToUpper = "FEMALE") Then
                            lHCFADB.OtherInsuredGender = "F"
                        End If
                        lHCFADB.OtherInsuredEmployer = lPriPatInsDtl.PatientInsuranceDetail.Insurer.EmployerName
                        lHCFADB.SecondaryInsurancePlan = lPriPatInsDtl.PatientInsuranceDetail.PInsurance.PlanName
                    End If
                    ' ***********************

                    ' ******** 11 ********
                    lHCFADB.AnotherInsuredPolicy = lSecPatInsDtl.PatientInsuranceDetail.PInsurance.GroupNo
                    lHCFADB.AnotherInsuredDOB = lSecPatInsDtl.PatientInsuranceDetail.Insurer.DOB
                    If (lSecPatInsDtl.PatientInsuranceDetail.Insurer.Gender.ToUpper = "MALE") Then
                        lHCFADB.AnotherInsuredGender = "M"
                    ElseIf (lSecPatInsDtl.PatientInsuranceDetail.Insurer.Gender.ToUpper = "FEMALE") Then
                        lHCFADB.AnotherInsuredGender = "F"
                    End If
                    lHCFADB.AnotherInsuredEmployerName = lSecPatInsDtl.PatientInsuranceDetail.Insurer.EmployerName
                    lHCFADB.AnotherInsuredInsurancePlan = lSecPatInsDtl.PatientInsuranceDetail.PInsurance.PlanName
                    If (lPriInsResult) Then
                        lHCFADB.IsAnotherPlan = "Y"
                    Else
                        lHCFADB.IsAnotherPlan = "N"
                    End If
                    ' *********************

                    ' ********** 23 **********
                    lHCFADB.PriorAuthorizationNumber = lSecPatInsDtl.PatientInsuranceDetail.PInsurance.AuthorizationNumber
                    ' ************************

                    lHCFADB.HCFAType = "S"
                End If

                ' ********** 2 **********
                lHCFADB.PatientName = lPatientExtended.Patient.LastName & "," & lPatientExtended.Patient.FirstName & " " & lPatientExtended.Patient.MiddleName
                ' ************************

                ' ********** 3 **********
                lHCFADB.PatientDOB = lPatientExtended.Patient.DOB
                If (lPatientExtended.Patient.Gender.ToUpper = "MALE") Then
                    lHCFADB.PatientGender = "M"
                ElseIf (lPatientExtended.Patient.Gender.ToUpper = "FEMALE") Then
                    lHCFADB.PatientGender = "F"
                End If
                ' ************************

                ' ********** 5 **********
                lHCFADB.PatientAddress = lPatientExtended.Patient.AddressLine1 & " " & lPatientExtended.Patient.AddressLine2
                lHCFADB.PatientCity = lPatientExtended.Patient.City
                lHCFADB.PatientZipCode = lPatientExtended.Patient.ZipCode
                lHCFADB.PatientState = lPatientExtended.Patient.StateID
                lHCFADB.PatientTelephone = lPatientExtended.Patient.HomePhone
                ' ************************

                ' ********** 8 **********
                lHCFADB.PatientMaritalStatus = lPatientExtended.Patient.MartialStatus
                lHCFADB.PatientEmploymentInfo = lPatientExtended.Patient.EmploymentStatus
                ' ************************

                ' ********** 10 **********
                lHCFADB.IsEmploymentRelated = "N"
                lHCFADB.IsAutoAccidentRelated = "N"
                lHCFADB.IsOtherAccidentRelated = "N"
                lHCFADB.ReservedBlock10D = ""
                ' ************************

                ' ********** 12 **********
                If (lPriPatInsDtl.PatientInsuranceDetail.PInsurance.SignatureOfFile.ToUpper = "YES") Then
                    lHCFADB.ReleaseInfoSignature = "SIGNATURE ON FILE"
                    lHCFADB.ReleaseInfoDate = lPriPatInsDtl.PatientInsuranceDetail.PInsurance.SignatureDate
                    ' ********** 13 **********
                    lHCFADB.PaymentSignature = "SIGNATURE ON FILE"
                    ' ************************
                Else
                    lHCFADB.ReleaseInfoSignature = ""
                    lHCFADB.ReleaseInfoDate = ""
                    ' ********** 13 **********
                    lHCFADB.PaymentSignature = ""
                    ' ************************
                End If
                ' ************************



                ' ********** 14 **********
                lHCFADB.DateOfOccurance = ""
                ' ************************

                ' ********** 15 **********
                lHCFADB.PreviousOccuranceDate = ""
                ' ************************

                ' ********** 16 **********
                lHCFADB.UnableToWorkFrom = ""
                lHCFADB.UnableToWorkTo = ""
                ' ************************

                ' ********** 17 **********
                lHCFADB.RefferingProviderName = lReferringProvider.ReferringProviderDB.FirstName & " " & lReferringProvider.ReferringProviderDB.MiddleName & " " & lReferringProvider.ReferringProviderDB.LastName & " " & lReferringProvider.ReferringProviderDB.Degree
                lHCFADB.RefferingProviderID = lReferringProvider.ReferringProviderDB.ProviderID
                lHCFADB.RefferingProviderNPI = lReferringProvider.ReferringProviderDB.NPI
                ' ************************

                ' ********** 18 **********
                lHCFADB.HospitalizationDateFrom = ""
                lHCFADB.HospitalizationDateTo = ""
                ' ************************

                ' ********** 19 **********
                lHCFADB.ReservedBlock19 = ""
                ' ************************

                ' ********** 20 **********
                lHCFADB.IsOutsideLab = "N"
                lHCFADB.OutsideLabCharges = "0"
                ' ************************

                ' ********** 21 **********
                If (lPatientICDColl.Count > 0 AndAlso lPatientICDColl.Item(0) IsNot Nothing) Then
                    lHCFADB.ICD1 = lPatientICDColl.Item(0).Code
                End If
                If (lPatientICDColl.Count > 1 AndAlso lPatientICDColl.Item(1) IsNot Nothing) Then
                    lHCFADB.ICD2 = lPatientICDColl.Item(1).Code
                End If
                If (lPatientICDColl.Count > 2 AndAlso lPatientICDColl.Item(2) IsNot Nothing) Then
                    lHCFADB.ICD3 = lPatientICDColl.Item(2).Code
                End If
                If (lPatientICDColl.Count > 3 AndAlso lPatientICDColl.Item(3) IsNot Nothing) Then
                    lHCFADB.ICD4 = lPatientICDColl.Item(3).Code
                End If
                ' ************************

                ' ********** 22 **********
                lHCFADB.MedicaidCode = ""
                lHCFADB.OriginalRefrenceNumber = ""
                ' ************************


                ' ********** 25 **********
                If (lEmployee.Employee.TaxID IsNot Nothing AndAlso lEmployee.Employee.TaxID <> "") Then
                    lHCFADB.FederalTaxID = lEmployee.Employee.TaxID
                    lHCFADB.IsSSN = "N"
                ElseIf (lEmployee.Employee.SSN IsNot Nothing AndAlso lEmployee.Employee.SSN <> "") Then
                    lHCFADB.FederalTaxID = lEmployee.Employee.SSN
                    lHCFADB.IsSSN = "Y"
                Else
                    lHCFADB.FederalTaxID = ""
                    lHCFADB.IsSSN = ""
                End If
                ' ************************

                ' ********** 26 **********
                lHCFADB.PatientAccountNumber = lPatientExtended.Patient.PatientID
                ' ************************

                ' ********** 27 **********
                lHCFADB.IsAcceptAssignment = "Y"
                ' ************************

                ' ********** 28 **********
                lHCFADB.TotalCharge = "0"
                ' ************************

                ' ********** 29 **********
                lHCFADB.AmountPaid = "0"
                ' ************************

                ' ********** 30 **********
                lHCFADB.BalanceDue = "0"
                ' ************************

                lHCFADB.FacilitySecondaryIdentificationQualifier = ""
                lHCFADB.ClinicSecondaryIdentificationQualifier = ""
                lHCFADB.RefferingProviderIDQualifier = ""
                lHCFADB.IsSend = "N"




                '**********   First it was filling by clinic Info 
                ' **********  Billing Provider 33 **********
                With lBillingProvider.BillingProvider
                    If (.FirstName.Trim = "") Then
                        lHCFADB.ClinicName = .LastName
                    Else
                        lHCFADB.ClinicName = .FirstName.Trim & " " & .LastName.Trim & " " & .MiddleName.Trim
                    End If
                    lHCFADB.ClinicAddress = .AddressLine1 & " " & .AddressLine2
                    lHCFADB.ClinicCity = .City
                    lHCFADB.ClinicState = .State
                    lHCFADB.ClinicZip = .ZipCode
                    lHCFADB.ClinicPhoneNumber = .Phone1
                    lHCFADB.ClinicPinNumber = .NPI
                    lHCFADB.ClinicGroupNumber = ""
                End With
                ' ************************

                lHCFADB.FacilityCity = lFacility.FacilityDB.City
                lHCFADB.FacilityState = lFacility.FacilityDB.State
                lHCFADB.FacilityZipCode = lFacility.FacilityDB.ZipCode
                lHCFADB.FacilityId = lFacility.FacilityDB.FacilityID
                lHCFADB.FacilityName = lFacility.FacilityDB.FacilityName
                lHCFADB.FacilityAddress = lFacility.FacilityDB.AddressLine1 & " " & lFacility.FacilityDB.AddressLine2
                lHCFADB.FacilityProvider = lFacility.FacilityDB.NPI
                lHCFADB.FacilityCode = lFacility.FacilityDB.FacilityCode

                lHCFADB.HCFAType = pType

                If (pType.ToUpper = "P") Then
                    lHCFADB.PrimaryInsuranceCity = lPriPatInsDtl.PatientInsuranceDetail.InsuranceCompany.City
                    lHCFADB.PrimaryInsuranceZipCode = lPriPatInsDtl.PatientInsuranceDetail.InsuranceCompany.ZipCode
                    lHCFADB.PrimaryInsuranceState = lPriPatInsDtl.PatientInsuranceDetail.InsuranceCompany.State
                    lHCFADB.MainInsID = lPriPatInsDtl.PatientInsuranceDetail.PInsurance.PatientInsID
                    lHCFADB.OtherInsID = lSecPatInsDtl.PatientInsuranceDetail.PInsurance.PatientInsID
                ElseIf (pType.ToUpper = "S") Then
                    lHCFADB.PrimaryInsuranceCity = lSecPatInsDtl.PatientInsuranceDetail.InsuranceCompany.City
                    lHCFADB.PrimaryInsuranceZipCode = lSecPatInsDtl.PatientInsuranceDetail.InsuranceCompany.ZipCode
                    lHCFADB.PrimaryInsuranceState = lSecPatInsDtl.PatientInsuranceDetail.InsuranceCompany.State
                    lHCFADB.MainInsID = lSecPatInsDtl.PatientInsuranceDetail.PInsurance.PatientInsID
                    lHCFADB.OtherInsID = lPriPatInsDtl.PatientInsuranceDetail.PInsurance.PatientInsID
                End If
            End If

            '*****************************************************************************************************************
            '                                ************** Filling HCFA DB End **************
            '*****************************************************************************************************************


            Return lHCFADB

        Catch ex As Exception
            Return Nothing
        End Try
    End Function
    Public Shared Function LoadHCFAUpdated(ByVal pPSBID As String, ByVal pType As String) As HCFADBUpdated
        Dim lPSB As PatientSuperBill
        Dim lUser As User
        Dim lPriPatInsDtl As PatientInsuranceDetail
        Dim lSecPatInsDtl As PatientInsuranceDetail
        Dim lBillingProvider As BillingProvider
        Dim lReferringProvider As ReferringProvider
        Dim lClinic As Clinic
        Dim lFacility As Facility
        Dim lPatientICD As PatientICD
        Dim lPatientICDColl As New PatientICDColl()
        Dim lHCFADBUpdated As HCFADBUpdated
        Dim lPatientExtended As PatientExtended
        Dim lPriInsResult As Boolean
        Dim lSecInsResult As Boolean
        Dim lRenderingPvd As Employee
        Dim lState As State

        Try
            lUser = CType(HttpContext.Current.Session("User"), User)

            lPSB = New PatientSuperBill(lUser.ConnectionString)
            lPriPatInsDtl = New PatientInsuranceDetail(lUser.ConnectionString)
            lSecPatInsDtl = New PatientInsuranceDetail(lUser.ConnectionString)
            lBillingProvider = New BillingProvider(lUser.ConnectionString)
            lReferringProvider = New ReferringProvider(lUser.ConnectionString)
            lClinic = New Clinic(lUser.ConnectionString)
            lFacility = New Facility(lUser.ConnectionString)
            lRenderingPvd = New Employee(lUser.ConnectionString)

            lPatientICD = New PatientICD(lUser.ConnectionString)
            lPatientExtended = New PatientExtended(lUser.ConnectionString)
            lState = New State(lUser.ConnectionString)
            lHCFADBUpdated = New HCFADBUpdated()

            If (pPSBID <> "") Then
                lPSB.PatientSuperBill.PatientSuperBillID = pPSBID
                lPSB.GetRecordByID()

                '' Load HCFA Patient'''''
                lPatientExtended.Patient.PatientID = lPSB.PatientSuperBill.PatientId
                lPatientExtended.GetRecordByID()
                lState.State.StateID = lPatientExtended.Patient.StateID
                lState.GetRecordByID()
                lPatientExtended.Patient.StateID = lState.State.Abbr
                lHCFADBUpdated.Patient = lPatientExtended.Patient
                '' Load HCFA Patient'''''


                '' Load HCFA Renderring Provider'''''
                lRenderingPvd.Employee.EmployeeID = lPSB.PatientSuperBill.PrescriberID
                lRenderingPvd.GetRecordByID()
                lState.State.StateID = lRenderingPvd.Employee.StateId
                lState.GetRecordByID()
                lRenderingPvd.Employee.StateId = lState.State.Abbr
                lHCFADBUpdated.RenderingProvider = lRenderingPvd.Employee
                '' Load HCFA Renderring Provider'''''


                lPriInsResult = lPriPatInsDtl.GetRecordByID(lPSB.PatientSuperBill.PatientId, "P")
                lSecInsResult = lSecPatInsDtl.GetRecordByID(lPSB.PatientSuperBill.PatientId, "S")

                ''This below change is done by zaigham on 10-30-2014 by Zaigham afer discussion with Ramzan
                ''Previously there was a mistake i.e. it was trying to fetch billing provider through provider id
                ''and wasn't able to find any billing provider so default billing provider was shown in Hcfa form
                ''Now it's fetching through billing provider ID

                '' Load HCFA Billing Provider'''''
                lBillingProvider.BillingProvider.BillingProviderId = lPSB.PatientSuperBill.BillingProviderId
                'If (pType.ToUpper = "P") Then
                '    lBillingProvider.BillingProvider.EntryInsuranceTypeValue = lPriPatInsDtl.PatientInsuranceDetail.InsuranceCompany.InsuranceType
                'ElseIf (pType.ToUpper = "S") Then
                '    lBillingProvider.BillingProvider.EntryInsuranceTypeValue = lSecPatInsDtl.PatientInsuranceDetail.InsuranceCompany.InsuranceType
                'End If
                lBillingProvider.GetBillingProviderByBillingProviderID()
                lHCFADBUpdated.BillingPvd = lBillingProvider.BillingProvider
                '' Load HCFA Billing Provider'''''


                '' Load HCFA Referring Provider'''''
                lReferringProvider.ReferringProviderDB.NPI = lPSB.PatientSuperBill.ReferringProviderNPI
                lReferringProvider.GetReferringProviderById()
                lHCFADBUpdated.ReferencePvd = lReferringProvider.ReferringProviderDB
                '' Load HCFA Referring Provider'''''


                lClinic.Clinic.ClinicId = lUser.ClinicId
                lClinic.GetRecordByID()
                lState.State.StateID = lClinic.Clinic.StateId
                lState.GetRecordByID()
                lClinic.Clinic.StateId = lState.State.Abbr


                '' Load HCFA Facility'''''
                lFacility.GetFacilityById("FacilityID='" & lPSB.PatientSuperBill.FacilityID & "'")
                lHCFADBUpdated.ServiceFacility = lFacility.FacilityDB
                '' Load HCFA Facility'''''

                lPatientICD.PatientICD.PatientSuperBillId = lPSB.PatientSuperBill.PatientSuperBillID
                lPatientICDColl = lPatientICD.GetPatientICDCollection("")

                '*****************************************************************************************************************
                '                                ************** Filling HCFA DB **************
                '*****************************************************************************************************************
                lHCFADBUpdated.HCFADisplayID = "0"
                lHCFADBUpdated.PatientSuperBillID = lPSB.PatientSuperBill.PatientSuperBillID
                lHCFADBUpdated.CreateByUserID = lUser.UserId
                lHCFADBUpdated.UpdateByUserID = lUser.UserId
                lHCFADBUpdated.HCFAPreparedDate = Date.Now.Date
                lHCFADBUpdated.IsSend = "N"
                lHCFADBUpdated.IsBatch = "N"
                lHCFADBUpdated.HCFANotes = ""
                ' HCFAGenerationSeqNo to maintain history
                lHCFADBUpdated.HCFAGenerationSeqNo = ""


                If (pType.ToUpper = "P") Then
                    lHCFADBUpdated.MainPatientInsurance = lPriPatInsDtl.PatientInsuranceDetail.PInsurance
                    lHCFADBUpdated.InsurerPatient = lPriPatInsDtl.PatientInsuranceDetail.Insurer
                    lHCFADBUpdated.MainInsuranceCompany = lPriPatInsDtl.PatientInsuranceDetail.InsuranceCompany
                    lHCFADBUpdated.HCFAType = "P"

                    '' For Prior Authorization Number i.e if not present in Patient insurance then set it from Insurance company
                    If (lHCFADBUpdated.MainPatientInsurance.AuthorizationNumber = "") Then
                        lHCFADBUpdated.MainPatientInsurance.AuthorizationNumber = lHCFADBUpdated.MainInsuranceCompany.PriorAuthorizationNumber
                    End If
                    ' ********************
                    If (lSecInsResult) Then

                        lHCFADBUpdated.OtherPatientInsurance = lSecPatInsDtl.PatientInsuranceDetail.PInsurance
                        'lHCFADBUpdated.InsurerPatient = lSecPatInsDtl.PatientInsuranceDetail.Insurer
                        lHCFADBUpdated.OtherInsurerPatient = lSecPatInsDtl.PatientInsuranceDetail.Insurer
                        lHCFADBUpdated.OtherInsuranceCompany = lSecPatInsDtl.PatientInsuranceDetail.InsuranceCompany

                    End If
                    ' ********************




                ElseIf (pType.ToUpper = "S") Then

                    lHCFADBUpdated.MainPatientInsurance = lSecPatInsDtl.PatientInsuranceDetail.PInsurance
                    'lHCFADBUpdated.InsurerPatient = lSecPatInsDtl.PatientInsuranceDetail.Insurer
                    lHCFADBUpdated.InsurerPatient = lSecPatInsDtl.PatientInsuranceDetail.Insurer
                    lHCFADBUpdated.MainInsuranceCompany = lSecPatInsDtl.PatientInsuranceDetail.InsuranceCompany
                    lHCFADBUpdated.HCFAType = "S"

                    '' For Prior Authorization Number i.e if not present in Patient insurance then set it from Insurance company
                    If (lHCFADBUpdated.MainPatientInsurance.AuthorizationNumber = "") Then
                        lHCFADBUpdated.MainPatientInsurance.AuthorizationNumber = lHCFADBUpdated.MainInsuranceCompany.PriorAuthorizationNumber
                    End If
                    ''***************

                    If (lPriInsResult) Then
                        lHCFADBUpdated.OtherPatientInsurance = lPriPatInsDtl.PatientInsuranceDetail.PInsurance
                        lHCFADBUpdated.OtherInsurerPatient = lPriPatInsDtl.PatientInsuranceDetail.Insurer
                        lHCFADBUpdated.OtherInsuranceCompany = lPriPatInsDtl.PatientInsuranceDetail.InsuranceCompany
                    End If

                End If

                ' ********** **********
                lHCFADBUpdated.PatientConditionAutoAccPlace = "N"
                lHCFADBUpdated.PatientConditionAutoAccident = "N"
                lHCFADBUpdated.PatientConditionOtherAccident = "N"
                lHCFADBUpdated.PatientConditionEmployment = "N"
                lHCFADBUpdated.Field19 = ""
                ' ************************

                ' ********** **********
                If (pType.ToUpper = "P" AndAlso lPriPatInsDtl.PatientInsuranceDetail.PInsurance.SignatureOfFile.ToUpper = "YES") Then
                    lHCFADBUpdated.SignOnFile = "SIGNATURE ON FILE"
                    lHCFADBUpdated.SignDate = lPriPatInsDtl.PatientInsuranceDetail.PInsurance.SignatureDate
                    lHCFADBUpdated.AuthorizedPersonSign = "SIGNATURE ON FILE"

                ElseIf (pType.ToUpper = "S" AndAlso lSecPatInsDtl.PatientInsuranceDetail.PInsurance.SignatureOfFile.ToUpper = "YES") Then
                    lHCFADBUpdated.SignOnFile = "SIGNATURE ON FILE"
                    lHCFADBUpdated.SignDate = lSecPatInsDtl.PatientInsuranceDetail.PInsurance.SignatureDate
                    lHCFADBUpdated.AuthorizedPersonSign = "SIGNATURE ON FILE"

                Else
                    lHCFADBUpdated.SignOnFile = ""
                    lHCFADBUpdated.SignDate = ""
                    lHCFADBUpdated.AuthorizedPersonSign = ""
                End If
                ' ************************



                ' ********** 14 **********
                lHCFADBUpdated.DateOfOccurance = ""
                ' ************************

                ' ********** 15 **********
                lHCFADBUpdated.PreviousOccuranceDate = ""
                ' ************************

                ' ********** 16 **********
                lHCFADBUpdated.PatUnableToWorkFrom = ""
                lHCFADBUpdated.PatUnableToWorkTo = ""
                ' ************************



                ' ********** 18 **********
                lHCFADBUpdated.HospitalizationDateFrom = ""
                lHCFADBUpdated.HospitalizationDateTo = ""
                ' ************************

                ' ********** 19 **********
                lHCFADBUpdated.Field19 = ""
                ' ************************

                ' ********** 20 **********
                lHCFADBUpdated.IsOutsideLab = "N"
                lHCFADBUpdated.OutsideLabCharges = 0
                ' ************************

                ' ********** 21 **********
                If (lPatientICDColl.Count > 0 AndAlso lPatientICDColl.Item(0) IsNot Nothing) Then
                    lHCFADBUpdated.ICD1 = lPatientICDColl.Item(0).Code
                End If
                If (lPatientICDColl.Count > 1 AndAlso lPatientICDColl.Item(1) IsNot Nothing) Then
                    lHCFADBUpdated.ICD2 = lPatientICDColl.Item(1).Code
                End If
                If (lPatientICDColl.Count > 2 AndAlso lPatientICDColl.Item(2) IsNot Nothing) Then
                    lHCFADBUpdated.ICD3 = lPatientICDColl.Item(2).Code
                End If
                If (lPatientICDColl.Count > 3 AndAlso lPatientICDColl.Item(3) IsNot Nothing) Then
                    lHCFADBUpdated.ICD4 = lPatientICDColl.Item(3).Code
                End If
                If (lPatientICDColl.Count > 4 AndAlso lPatientICDColl.Item(4) IsNot Nothing) Then
                    lHCFADBUpdated.ICD5 = lPatientICDColl.Item(4).Code
                End If
                If (lPatientICDColl.Count > 5 AndAlso lPatientICDColl.Item(5) IsNot Nothing) Then
                    lHCFADBUpdated.ICD6 = lPatientICDColl.Item(5).Code
                End If
                If (lPatientICDColl.Count > 6 AndAlso lPatientICDColl.Item(6) IsNot Nothing) Then
                    lHCFADBUpdated.ICD7 = lPatientICDColl.Item(6).Code
                End If
                If (lPatientICDColl.Count > 7 AndAlso lPatientICDColl.Item(7) IsNot Nothing) Then
                    lHCFADBUpdated.ICD8 = lPatientICDColl.Item(7).Code
                End If
                If (lPatientICDColl.Count > 8 AndAlso lPatientICDColl.Item(8) IsNot Nothing) Then
                    lHCFADBUpdated.ICD9 = lPatientICDColl.Item(8).Code
                End If
                If (lPatientICDColl.Count > 9 AndAlso lPatientICDColl.Item(9) IsNot Nothing) Then
                    lHCFADBUpdated.ICD10 = lPatientICDColl.Item(9).Code
                End If
                If (lPatientICDColl.Count > 10 AndAlso lPatientICDColl.Item(10) IsNot Nothing) Then
                    lHCFADBUpdated.ICD11 = lPatientICDColl.Item(10).Code
                End If
                If (lPatientICDColl.Count > 11 AndAlso lPatientICDColl.Item(11) IsNot Nothing) Then
                    lHCFADBUpdated.ICD12 = lPatientICDColl.Item(11).Code
                End If

                ' ************************

                ' ********** 22 **********
                lHCFADBUpdated.MedicadReSubCode = ""
                lHCFADBUpdated.MedicadReSubNo = ""
                ' ************************


                ' ********** 25 **********
                If (lRenderingPvd.Employee.TaxID IsNot Nothing AndAlso lRenderingPvd.Employee.TaxID <> "") Then
                    lHCFADBUpdated.FederalTaxNo = lRenderingPvd.Employee.TaxID
                    ' lHCFADBUpdated.IsSSN = "N"
                ElseIf (lRenderingPvd.Employee.SSN IsNot Nothing AndAlso lRenderingPvd.Employee.SSN <> "") Then
                    lHCFADBUpdated.FederalTaxNo = lRenderingPvd.Employee.SSN
                    '  lHCFADBUpdated.IsSSN = "Y"
                Else
                    lHCFADBUpdated.FederalTaxNo = ""
                    '  lHCFADBUpdated.IsSSN = ""
                End If
                ' ************************

                ' ********** 26 **********
                lHCFADBUpdated.PatientACNo = "" 'lUser.ClinicId & "H" & Convert.ToDateTime(lHCFADBUpdated.HCFAPreparedDate).Month.ToString.PadLeft(2, "0") & Convert.ToDateTime(lHCFADBUpdated.HCFAPreparedDate).Day.ToString.PadLeft(2, "0") & lHCFADBUpdated.HCFADisplayID.ToString.PadLeft(5, "0") 'lPatientExtended.Patient.PatientID
                ' ************************

                ' ********** 27 **********
                lHCFADBUpdated.AcceptAssignment = "Y"
                ' ************************

                ' ********** 28 **********
                lHCFADBUpdated.TotalCharges = "0"
                ' ************************

                ' ********** 29 **********
                lHCFADBUpdated.AmountPaid = "0"
                ' ************************

                ' ********** 30 **********
                lHCFADBUpdated.BalanceDue = "0"
                ' ************************

                ' lHCFADBUpdated.FacilitySecondaryIdentificationQualifie = ""
                'lHCFADBUpdated.ClinicSecondaryIdentificationQualifier = ""
                ' lHCFADBUpdated.RefferingProviderIDQualifier = ""

            End If

            '*****************************************************************************************************************
            '                                ************** Filling HCFA DB End **************
            '*****************************************************************************************************************


            Return lHCFADBUpdated

        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    'Public Shared Function LoadHCFADetailUpdated(ByVal pPSBID As String, ByVal pType As String) As HCFADetailDBUpdated
    '    Dim lPSB As PatientSuperBill
    '    Dim lUser As User
    '    Dim lPriPatInsDtl As PatientInsuranceDetail
    '    Dim lSecPatInsDtl As PatientInsuranceDetail
    '    Dim lClinic = New Clinic(lUser.ConnectionString)
    '    Dim lFacility As Facility
    '    Dim lState As State
    '    Dim lPriInsResult As Boolean
    '    Dim lSecInsResult As Boolean
    '    Dim lRenderingPvd As Employee
    '    Dim lHCFADetailDBUpdated = New HCFADetailDBUpdated

    '    Try
    '        lUser = CType(HttpContext.Current.Session("User"), User)

    '        lPSB = New PatientSuperBill(lUser.ConnectionString)
    '        lPriPatInsDtl = New PatientInsuranceDetail(lUser.ConnectionString)
    '        lSecPatInsDtl = New PatientInsuranceDetail(lUser.ConnectionString)

    '        lFacility = New Facility(lUser.ConnectionString)
    '        lRenderingPvd = New Employee(lUser.ConnectionString)
    '        lState = New State(lUser.ConnectionString)
    '        If (pPSBID <> "") Then
    '            lPSB.PatientSuperBill.PatientSuperBillID = pPSBID
    '            lPSB.GetRecordByID()

    '            lClinic.Clinic.ClinicId = lUser.ClinicId
    '            lClinic.GetRecordByID()

    '            lState.State.StateID = lClinic.Clinic.StateId
    '            lState.GetRecordByID()
    '            lClinic.Clinic.StateId = lState.State.Abbr


    '            lFacility.GetFacilityById("FacilityCode='" & lClinic.Clinic.FacilityCode & "'")
    '            lHCFADetailDBUpdated = lFacility.FacilityDB


    '            lRenderingPvd.Employee.EmployeeID = lPSB.PatientSuperBill.PrescriberID
    '            lRenderingPvd.GetRecordByID()

    '            lPriInsResult = lPriPatInsDtl.GetRecordByID(lPSB.PatientSuperBill.PatientId, "P")
    '            lSecInsResult = lSecPatInsDtl.GetRecordByID(lPSB.PatientSuperBill.PatientId, "S")


    '            lFacility.GetFacilityById("FacilityCode='" & lClinic.Clinic.FacilityCode & "'")


    '            '*****************************************************************************************************************
    '            '                                ************** Filling HCFA DB Detail **************
    '            '*****************************************************************************************************************
    '            lHCFADetailDBUpdated.HCFADisplayID = "0"
    '            lHCFADetailDBUpdated.PatientSuperBillID = lPSB.PatientSuperBill.PatientSuperBillID
    '        End If




    '        '*****************************************************************************************************************
    '        '                                ************** Filling HCFA DB End **************
    '        '*****************************************************************************************************************


    '        Return lHCFADetailDBUpdated

    '    Catch ex As Exception
    '        Return Nothing
    '    End Try
    'End Function


    'added by: Kanwal jeet

    Public Shared Function UpDateNotes(ByVal pHCFAUpdated As HCFADBUpdated) As Boolean

        Dim lHCFAUpdated As HCFAUpdated = Nothing
        Dim lResult As Boolean
        Dim lUser As User = CType(HttpContext.Current.Session.Item("User"), User)

        Try
            lHCFAUpdated = New HCFAUpdated(lUser.ConnectionString)
            lHCFAUpdated.HCFAUpdated = pHCFAUpdated
            lResult = lHCFAUpdated.UpdateNotes()
            Return True

        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Shared Function LoadNotes(ByVal pHCFAUpdatedDB As HCFADBUpdated, ByVal pHCFAId As Integer) As System.Data.DataSet

        Dim lHCFAUpdated As HCFAUpdated = Nothing
        Dim lUser As User = CType(HttpContext.Current.Session.Item("User"), User)
        Try
            lHCFAUpdated = New HCFAUpdated(lUser.ConnectionString)
            lHCFAUpdated.HCFAUpdated = pHCFAUpdatedDB

            Dim lResult = lHCFAUpdated.LoadNotes(pHCFAUpdatedDB, pHCFAId)
            Return lResult

        Catch ex As Exception
        End Try

    End Function

    Public Shared Function InsertNotes(ByVal pHCFAUpdatedDB As HCFADBUpdated) As Boolean

        Dim lHCFAUpdated As HCFAUpdated = Nothing
        Dim lResult As Boolean
        Dim lUser As User = CType(HttpContext.Current.Session.Item("User"), User)

        Try
            lHCFAUpdated = New HCFAUpdated(lUser.ConnectionString)
            lHCFAUpdated.HCFAUpdated = pHCFAUpdatedDB
            lResult = lHCFAUpdated.InsertNotes()
            Return True

        Catch ex As Exception
            Return False
        End Try

    End Function
End Class
