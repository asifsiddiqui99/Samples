Imports Microsoft.VisualBasic

Public Class AdjustmentScreenMethods
    Public Shared Function GetTypeCode(ByVal pUser As User) As DataSet
        Dim lAdjustmentScreenDAL As New AdjustmentScreen(pUser.ConnectionString)
        Dim lDs As New DataSet
        Try
            lDs = lAdjustmentScreenDAL.GetTypeCode()
            Return lDs
        Catch ex As Exception
            Return Nothing
        End Try

        Return lDs

    End Function
    Public Shared Function GetAdjReasonCode(ByVal pUser As User) As DataSet
        Dim lAdjustmentScreenDAL As New AdjustmentScreen(pUser.ConnectionString)
        Dim lDs As New DataSet
        Try
            lDs = lAdjustmentScreenDAL.GetAdjReasonCode()
            Return lDs
        Catch ex As Exception
            Return Nothing
        End Try

        Return lDs

    End Function
    Public Shared Function GetListRecord(ByVal pUser As User) As DataSet
        Dim lAdjustmentScreenDAL As New AdjustmentScreen(pUser.ConnectionString)
        Dim lDs As New DataSet
        Try
            lDs = lAdjustmentScreenDAL.GetListRecord()

            Return lDs
        Catch ex As Exception
            Return Nothing
        End Try

        Return lDs

    End Function
    Public Shared Function InsertListRecord(ByVal pUser As User, ByVal pAdjustmentScreenDB As AdjustmentScreenDB)
        Dim lAdjustmentScreenDAL As New AdjustmentScreen(pUser.ConnectionString)
        Dim lDs As New DataSet
        Try
            lDs = lAdjustmentScreenDAL.InsertListRecord(pAdjustmentScreenDB)
            Return lDs
        Catch ex As Exception
            Return Nothing
        End Try

        Return lDs

    End Function

    Public Shared Function GetAdjustmentByVisitID(ByVal pUser As User, ByVal pCondition As String) As DataSet
        Dim lAdjustmentScreenDAL As New AdjustmentScreen(pUser.ConnectionString)
        Dim lDs As New DataSet
        Try
            lDs = lAdjustmentScreenDAL.GetAdjustmentByVisitID(pCondition)
            Return lDs
        Catch ex As Exception
            Return Nothing
        End Try

        Return lDs

    End Function
End Class
