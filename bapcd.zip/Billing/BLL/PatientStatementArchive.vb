Imports Microsoft.VisualBasic

Public Class PatientStatementArchive
    Public Shared Function SearchRecords(ByVal pDateFrom As Date, ByVal pDateTo As Date, ByVal pPatientName As String, ByVal pGuarantorName As String) As DataSet
        Dim lConnection As Connection
        Dim lQuery As String
        Dim lUser As User
        Dim lResult As New DataSet
        Dim lCondition As String = ""
        Dim lPatientStatementDtlDB As PatientStatementDtlDB
        Dim lPatientStatementDtl As PatientStatementDtl
        Try

            lUser = CType(HttpContext.Current.Session("User"), User)
            lConnection = New Connection(lUser.ConnectionString)

            lPatientStatementDtlDB = New PatientStatementDtlDB
            lPatientStatementDtl = New PatientStatementDtl(lConnection)

            With lPatientStatementDtlDB
                If (pPatientName <> "") Then
                    .PatientLastName = pPatientName
                End If
                If (pGuarantorName <> "") Then
                    .GuarantorLastName = pGuarantorName
                End If
            End With

            lPatientStatementDtl.PatientStatementDtlDB = lPatientStatementDtlDB
            lResult = lPatientStatementDtl.SearchRecords(pDateFrom, pDateTo)

            Return lResult

        Catch ex As Exception
            Return Nothing
        End Try

    End Function
    Public Shared Function SearchRecords(ByVal pDateFrom As Date, ByVal pDateTo As Date, ByVal pPatientName As String, ByVal pGuarantorName As String, ByVal pPatientID As String) As DataSet
        Dim lConnection As Connection
        Dim lQuery As String
        Dim lUser As User
        Dim lResult As New DataSet
        Dim lCondition As String = ""
        Dim lPatientStatementDtlDB As PatientStatementDtlDB
        Dim lPatientStatementDtl As PatientStatementDtl
        Try

            lUser = CType(HttpContext.Current.Session("User"), User)
            lConnection = New Connection(lUser.ConnectionString)

            lPatientStatementDtlDB = New PatientStatementDtlDB
            lPatientStatementDtl = New PatientStatementDtl(lConnection)

            With lPatientStatementDtlDB
                If (pPatientName <> "") Then
                    .PatientLastName = pPatientName
                End If
                If (pGuarantorName <> "") Then
                    .GuarantorLastName = pGuarantorName
                End If
                If (pPatientID <> "") Then
                    .PatientID = pPatientID
                End If
            End With

            lPatientStatementDtl.PatientStatementDtlDB = lPatientStatementDtlDB
            lResult = lPatientStatementDtl.SearchRecords(pDateFrom, pDateTo)

            Return lResult

        Catch ex As Exception
            Return Nothing
        End Try

    End Function
End Class
