Imports Microsoft.VisualBasic
Imports Telerik.WebControls

Public Class InsuranceMethods


    Public Shared Sub LoadInsuranceListGridForPayment(ByVal pRadGrid As RadGrid, ByVal pInsuranceName As String, ByVal pState As String)
        Dim lInsurance As Insurance = Nothing

        Try

            lInsurance = New Insurance
            'pRadGrid.DataSource = lInsurance.GetInsuranceList("And PayerName like '" & pInsuranceName & "%'" _
            '& "And State like  '" & pState & "%'")
            pRadGrid.DataSource = lInsurance.GetInsuranceListNew("And PayerName like '" & pInsuranceName & "%'" _
            & "And State like  '" & pState & "%'")
            'pRadGrid.DataBind()

        Catch ex As Exception

        End Try

    End Sub

   

    Public Shared Function AddInsurance(ByVal pInsuranceDB As InsuranceDB) As String
        Dim lInsurance As Insurance = Nothing
        Dim lUser As User = CType(HttpContext.Current.Session.Item("User"), User)
        Dim lResult As String


        Try
            lInsurance = New Insurance(lUser.ConnectionString)
            lInsurance.InsuranceDB = pInsuranceDB
            lResult = lInsurance.InsertInsurance()

            If Not lResult.Equals(String.Empty) Then

                Dim lEventLog As New EHREventLog()
                lEventLog.EventLog.EventTypeID = 13
                lEventLog.EventLog.ExtraID = lResult
                lEventLog.EventLog.ExtraIDDescription = "Newly added insurance ID"
                lEventLog.EventLog.OCcurTime = Date.Now()
                lEventLog.EventLog.UserID = lUser.UserId
                lEventLog.EventLog.EventDescription = lUser.LastName & ", " & lUser.FirstName & " inserted insurance " & lInsurance.InsuranceDB.CompanyName & " to the insurance setup"
                lEventLog.HandleEvent()

                Return "Insurance added succesfully"

            End If

            Return "Insurance could not be added. Please try again"

        Catch ex As Exception
            Return "Insurance could not be added. Please try again"
        End Try
    End Function

    Public Shared Function GetCompanyName(ByVal pCombo As RadComboBox, ByVal pCondition As String) As Boolean
        Dim lInsurance As Insurance = Nothing
        Dim lds As New DataSet


        Try
            Dim lUser As User = CType(HttpContext.Current.Session.Item("User"), User)
            lInsurance = New Insurance(lUser.ConnectionString)
            lds = lInsurance.GetCompanyName(pCondition)

            pCombo.DataSource = lds
            pCombo.DataTextField = "CompanyName"
            pCombo.DataValueField = "CompanyName"
            pCombo.DataBind()


        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Shared Function GetInsuranceRecords(ByVal pwhere As String) As DataSet
        Dim lInsurance As Insurance = Nothing
        Dim lds As New DataSet


        Try
            Dim lUser As User = CType(HttpContext.Current.Session.Item("User"), User)
            lInsurance = New Insurance(lUser.ConnectionString)
            lds = lInsurance.GetAllRecords(pwhere)

            Return lds

        Catch ex As Exception

        End Try
    End Function

    Public Shared Function DeleteInsurance(ByVal pInsuraceDB As InsuranceDB) As Boolean
        Dim lInsurance As Insurance = Nothing
        Dim lUser As User = CType(HttpContext.Current.Session.Item("User"), User)
        Try
            lInsurance = New Insurance(lUser.ConnectionString)
            lInsurance.InsuranceDB = pInsuraceDB

            If lInsurance.DeleteInsurance() Then

                Dim lEventLog As New EHREventLog()
                lEventLog.EventLog.EventTypeID = 15
                lEventLog.EventLog.ExtraID = lInsurance.InsuranceDB.FavouriteInsuranceID
                lEventLog.EventLog.ExtraIDDescription = "Deleted insurance ID"
                lEventLog.EventLog.OCcurTime = Date.Now()
                lEventLog.EventLog.UserID = lUser.UserId
                lEventLog.EventLog.EventDescription = lUser.LastName & ", " & lUser.FirstName & " deleted insurance " & lInsurance.InsuranceDB.CompanyName & " from the insurance setup"
                lEventLog.HandleEvent()

                Return True

            End If

            Return False

        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Shared Function EditInsurance(ByVal pInsuranceDB As InsuranceDB) As Boolean
        Dim lInsurance As Insurance = Nothing
        Dim lUser As User = CType(HttpContext.Current.Session.Item("User"), User)
        Try
            lInsurance = New Insurance(lUser.ConnectionString)
            lInsurance.InsuranceDB = pInsuranceDB


            If lInsurance.UpdateInsurance() Then

                Dim lEventLog As New EHREventLog()
                lEventLog.EventLog.EventTypeID = 14
                lEventLog.EventLog.ExtraID = pInsuranceDB.FavouriteInsuranceID
                lEventLog.EventLog.ExtraIDDescription = "Updated insurance ID"
                lEventLog.EventLog.OCcurTime = Date.Now()
                lEventLog.EventLog.UserID = lUser.UserId
                lEventLog.EventLog.EventDescription = lUser.LastName & ", " & lUser.FirstName & " updated insurance " & lInsurance.InsuranceDB.CompanyName & " from the insurance setup"
                lEventLog.HandleEvent()

                Return True

            End If

            Return False

        Catch ex As Exception
            Return False
        End Try
    End Function
    '' By Fareed For Patient Setup Insurance Combo Binding
    Public Shared Function GetInsuranceForCombo(ByVal pSearchString As String, ByRef pUser As User) As DataSet


        Dim lDs As New DataSet
        Try
            Dim lInsurance As New Insurance(pUser.ConnectionString)
            lInsurance.InsuranceDB.CompanyName = pSearchString
            lDs = lInsurance.SelectTopTenRecords()
        Catch ex As Exception
            Throw New Exception(ex.Message & " : Billing\BLL\InsuranceMethods.GetInsuranceForCombo(ByVal pSearchString As String, ByRef pUser='" & pUser.UserId & "' As User)")
        End Try

        Return lDs
    End Function
    Public Shared Function GetInsuranceForCombo(ByVal pSearchString As String, ByRef pUser As User, ByVal pType As String) As DataSet


        Dim lDs As New DataSet
        Try
            Dim lInsurance As New Insurance(pUser.ConnectionString)
            lInsurance.InsuranceDB.CompanyName = pSearchString
            lDs = lInsurance.SelectTopTenRecordsByType(pType)
        Catch ex As Exception
            Throw New Exception(ex.Message & " : Billing\BLL\InsuranceMethods.GetInsuranceForCombo(ByVal pSearchString As String, ByRef pUser='" & pUser.UserId & "' As User)")
        End Try

        Return lDs
    End Function

    Public Shared Function GetCompanyList(ByVal pCondition As String) As DataSet
        Dim lInsurance As Insurance = Nothing
        Dim lds As New DataSet


        Try
            Dim lUser As User = CType(HttpContext.Current.Session.Item("User"), User)
            lInsurance = New Insurance(lUser.ConnectionString)
            lds = lInsurance.GetCompanyListForCombo(pCondition)

            Return lds

        Catch ex As Exception

        End Try
    End Function

    Public Shared Sub LoadInsuranceListGrid(ByVal pRadGrid As RadGrid, ByVal pInsuranceName As String)
        Dim lInsurance As Insurance = Nothing

        Try

            lInsurance = New Insurance
            pRadGrid.DataSource = lInsurance.GetInsuranceList("And PayerName like '" & pInsuranceName & "%'")

            pRadGrid.DataBind()

        Catch ex As Exception

        End Try

    End Sub
    Public Shared Function GetPatientRecordForPaymentSearch(ByVal pwhere As String, ByVal pUser As User) As DataSet
        Dim lInsurance As Insurance = Nothing
        Dim lds As DataSet = Nothing

        Try

            lInsurance = New Insurance(pUser.ConnectionString)
            lds = lInsurance.GetPatientRecordsForPaymentSearch(pwhere)

            Return lds



        Catch ex As Exception
            Return Nothing
        End Try

    End Function

    Public Shared Function GetAllRecordForPaymentSearch(ByVal pwhere As String, ByVal pUser As User) As DataSet
        Dim lInsurance As Insurance = Nothing
        Dim lds As DataSet = Nothing

        Try

            lInsurance = New Insurance(pUser.ConnectionString)
            lds = lInsurance.GetPatientRecordsForPaymentSearch(pwhere)

            Return lds



        Catch ex As Exception
            Return Nothing
        End Try

    End Function

    Public Shared Function GetInsuranceRecordForPaymentSearch(ByVal pwhere As String, ByVal pUser As User) As DataSet
        Dim lInsurance As Insurance = Nothing
        Dim lds As DataSet = Nothing

        Try

            lInsurance = New Insurance(pUser.ConnectionString)
            lds = lInsurance.GetInsuranceRecordsForPaymentSearch(pwhere)

            Return lds


        Catch ex As Exception
            Return Nothing
        End Try

    End Function

End Class
