Imports Microsoft.VisualBasic
Imports System.Xml
Imports ClaimLibrary
Imports Rebex
Imports Rebex.Net


Public Class ClaimRequest837Methods
    Public Shared lLastHL As Int32
    Public Shared lSubscriberHL As Int32
    Public Shared Function Make837RequestXML(ByRef pUser As User, ByRef pHCFADB As HCFADB, ByRef pHCFADtlCol As HCFADetailColl) As String


        Dim lXmlDocument As New XmlDocument
        Dim lRoot As XmlElement = Nothing
        Dim lISA As XmlElement = Nothing ''lXmlDocument.CreateElement("Temp")
        Dim lIEA As XmlElement = Nothing ''lXmlDocument.CreateElement("Temp1")
        Dim lFunctionalGroup As XmlElement = Nothing
        Dim lGS As XmlElement = Nothing
        Dim lST As XmlElement = Nothing
        Dim lBHT As XmlElement = Nothing
        Dim lREF As XmlElement = Nothing
        Dim lSE As XmlElement = Nothing
        Dim lTransactions As XmlElement = Nothing
        Dim lL1000_837PRO As XmlElement = Nothing
        'dim lL1000A_837PRO As XmlElement = lXmlDocument.CreateElement("L1000A_837PRO")
        'Dim lL1000A_837PRO As XmlElement = SubmitterName1000A(pUser, pHCFADB, pHCFADtlCol, lXmlDocument)
        'Dim lL1000B_837PRO As XmlElement = ReceiverName1000B(pUser, pHCFADB, pHCFADtlCol)
        Dim lL2000A_837PRO As XmlElement = Nothing
        Dim lGE As XmlElement = Nothing
        Dim lChildNodeLevel1 As XmlElement = Nothing
        Dim lChildNodeLevel2 As XmlElement = Nothing
        Dim lChildNodeLevel3 As XmlElement = Nothing
        Dim lChildNodeLevel6 As XmlElement = Nothing
        Dim lChildNodeLevel7 As XmlElement = Nothing
        Dim lChildNodeLevel8 As XmlElement = Nothing
        Dim lChildNodeLevel9 As XmlElement = Nothing
        Dim lChildNodeLevel10 As XmlElement = Nothing
        Dim lChildNodeLevel11 As XmlElement = Nothing
        Dim lChildNodeLevel12 As XmlElement = Nothing
        Dim lXml As String = ""


        Try

            lXmlDocument.LoadXml("<HealthCareClaimRequest xmlns='http://www.HealthCareClaimRequest.com' xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' xsi:schemaLocation='http://www.HealthCareClaimRequest.com HealthCareClaimRequest.xsd'></HealthCareClaimRequest>")
            'lXmlDocument.LoadXml("<HealthCareClaimRequest></HealthCareClaimRequest>")
            'lRoot = lXmlDocument.CreateElement("HealthCareClaimRequest")

            'lRoot = lXmlDocument.CreateElement("HealthCareClaimRequest", "xmlns='http://www.HealthCareClaimRequest.com'")

            ''Start of ISA
            lISA = lXmlDocument.CreateElement("ISA")

            lChildNodeLevel1 = lXmlDocument.CreateElement("AuthorizationInformationQualifier")
            lChildNodeLevel1.InnerText = "00" 'Indicates no information in the next field
            lISA.AppendChild(lChildNodeLevel1.CloneNode(True))

            lChildNodeLevel1 = lXmlDocument.CreateElement("AuthorizationInformation")
            lChildNodeLevel1.InnerText = "0123456789"
            lISA.AppendChild(lChildNodeLevel1.CloneNode(True))

            lChildNodeLevel1 = lXmlDocument.CreateElement("SecurityInformationQualifier")
            lChildNodeLevel1.InnerText = "00" 'Indicates no information in the next field
            lISA.AppendChild(lChildNodeLevel1.CloneNode(True))

            lChildNodeLevel1 = lXmlDocument.CreateElement("SecurityInformation")
            lChildNodeLevel1.InnerText = "0123456789"
            lISA.AppendChild(lChildNodeLevel1.CloneNode(True))

            lChildNodeLevel1 = lXmlDocument.CreateElement("InterchangeIDQualifier1")
            lChildNodeLevel1.InnerText = "ZZ" 'Mutually Defined
            lISA.AppendChild(lChildNodeLevel1.CloneNode(True))

            lChildNodeLevel1 = lXmlDocument.CreateElement("InterchangeSenderID")
            lChildNodeLevel1.InnerText = "012345678987654"   ' This is our ENS organization ID
            lISA.AppendChild(lChildNodeLevel1.CloneNode(True))

            lChildNodeLevel1 = lXmlDocument.CreateElement("InterchangeIDQualifier2")
            lChildNodeLevel1.InnerText = "ZZ" 'Mutually Defined
            lISA.AppendChild(lChildNodeLevel1.CloneNode(True))

            lChildNodeLevel1 = lXmlDocument.CreateElement("InterchangeReceiverID")
            lChildNodeLevel1.InnerText = "012345678987654" 'This is ENS's taxpayer ID
            lISA.AppendChild(lChildNodeLevel1.CloneNode(True))

            lChildNodeLevel1 = lXmlDocument.CreateElement("InterchangeDate")
            lChildNodeLevel1.InnerText = Date.Now.ToString("yyMMdd")
            lISA.AppendChild(lChildNodeLevel1.CloneNode(True))

            lChildNodeLevel1 = lXmlDocument.CreateElement("InterchangeTime")
            lChildNodeLevel1.InnerText = Date.Now.ToString("HHmm")
            lISA.AppendChild(lChildNodeLevel1.CloneNode(True))

            lChildNodeLevel1 = lXmlDocument.CreateElement("InterchangeControlStandardsIdentifier")
            lChildNodeLevel1.InnerText = "U"
            lISA.AppendChild(lChildNodeLevel1.CloneNode(True))

            lChildNodeLevel1 = lXmlDocument.CreateElement("InterchangeControlVersionNumber")
            lChildNodeLevel1.InnerText = "00401"
            lISA.AppendChild(lChildNodeLevel1.CloneNode(True))

            lChildNodeLevel1 = lXmlDocument.CreateElement("InterchangeControlNumber")
            lChildNodeLevel1.InnerText = "0000000001" 'TODO
            lISA.AppendChild(lChildNodeLevel1.CloneNode(True))

            lChildNodeLevel1 = lXmlDocument.CreateElement("AcknowledgementRequested")
            lChildNodeLevel1.InnerText = "1"
            lISA.AppendChild(lChildNodeLevel1.CloneNode(True))

            lChildNodeLevel1 = lXmlDocument.CreateElement("UsageIndicator")
            lChildNodeLevel1.InnerText = "T" ''System.Configuration.ConfigurationManager.AppSettings("UsageIndicator")
            lISA.AppendChild(lChildNodeLevel1.CloneNode(True))

            lChildNodeLevel1 = lXmlDocument.CreateElement("ComponentElementSeparator")
            lChildNodeLevel1.InnerText = ":" 'This is hard coded intentionally and should not be changed
            lISA.AppendChild(lChildNodeLevel1.CloneNode(True))

            lXmlDocument.DocumentElement.AppendChild(lISA.CloneNode(True))

            ''End of ISA

            ''Start  of Functional group
            lFunctionalGroup = lXmlDocument.CreateElement("FunctionalGroup")

            ''Start GS
            lGS = lXmlDocument.CreateElement("GS")

            lChildNodeLevel1 = lXmlDocument.CreateElement("FunctionalIdentifierCode")
            lChildNodeLevel1.InnerText = "HC"
            lGS.AppendChild(lChildNodeLevel1.CloneNode(True))

            lChildNodeLevel1 = lXmlDocument.CreateElement("ApplicationSendersCode")
            lChildNodeLevel1.InnerText = "123456789"
            lGS.AppendChild(lChildNodeLevel1.CloneNode(True))

            lChildNodeLevel1 = lXmlDocument.CreateElement("ApplicationRecieversCode")
            lChildNodeLevel1.InnerText = "987654321"
            lGS.AppendChild(lChildNodeLevel1.CloneNode(True))

            lChildNodeLevel1 = lXmlDocument.CreateElement("Date")
            lChildNodeLevel1.InnerText = Date.Now.ToString("yyyyMMdd")
            lGS.AppendChild(lChildNodeLevel1.CloneNode(True))

            lChildNodeLevel1 = lXmlDocument.CreateElement("Time")
            lChildNodeLevel1.InnerText = Date.Now.ToString("HHmm")
            lGS.AppendChild(lChildNodeLevel1.CloneNode(True))

            lChildNodeLevel1 = lXmlDocument.CreateElement("GroupControlNumber")
            lChildNodeLevel1.InnerText = "123"
            lGS.AppendChild(lChildNodeLevel1.CloneNode(True))


            lChildNodeLevel1 = lXmlDocument.CreateElement("ResponsibleAgencyCode")
            lChildNodeLevel1.InnerText = "X"
            lGS.AppendChild(lChildNodeLevel1.CloneNode(True))

            lChildNodeLevel1 = lXmlDocument.CreateElement("VersionReleaseIndustryIdentifierCode")
            lChildNodeLevel1.InnerText = "004010X098A1"
            lGS.AppendChild(lChildNodeLevel1.CloneNode(True))

            ''End of GS
            lFunctionalGroup.AppendChild(lGS.CloneNode(True))

            '********************************************'
            '*           Transactions                   *' 
            '********************************************'

            lTransactions = lXmlDocument.CreateElement("Transactions")

            ''Start OF ST
            lST = lXmlDocument.CreateElement("ST")

            lChildNodeLevel1 = lXmlDocument.CreateElement("TransactionSetCode")
            lChildNodeLevel1.InnerText = "837"
            lST.AppendChild(lChildNodeLevel1.CloneNode(True))

            lChildNodeLevel1 = lXmlDocument.CreateElement("TransactionSetControlNumber")
            lChildNodeLevel1.InnerText = "00001"
            lST.AppendChild(lChildNodeLevel1.CloneNode(True))
            ''End OF ST
            lTransactions.AppendChild(lST.CloneNode(True))

            ''Start OF BHT
            lBHT = lXmlDocument.CreateElement("BHT")

            lChildNodeLevel1 = lXmlDocument.CreateElement("HierarchialStructuralCode")
            lChildNodeLevel1.InnerText = "0019"
            lBHT.AppendChild(lChildNodeLevel1.CloneNode(True))

            lChildNodeLevel1 = lXmlDocument.CreateElement("transactionSetPurposeCode")
            lChildNodeLevel1.InnerText = "00"
            lBHT.AppendChild(lChildNodeLevel1.CloneNode(True))

            lChildNodeLevel1 = lXmlDocument.CreateElement("ReferenceIdentification")
            lChildNodeLevel1.InnerText = "0123"
            lBHT.AppendChild(lChildNodeLevel1.CloneNode(True))

            lChildNodeLevel1 = lXmlDocument.CreateElement("Date")
            lChildNodeLevel1.InnerText = Date.Now.ToString("yyyyMMdd")
            lBHT.AppendChild(lChildNodeLevel1.CloneNode(True))

            lChildNodeLevel1 = lXmlDocument.CreateElement("Time")
            lChildNodeLevel1.InnerText = Date.Now.ToString("HHmm")
            lBHT.AppendChild(lChildNodeLevel1.CloneNode(True))

            lChildNodeLevel1 = lXmlDocument.CreateElement("TransactionTypeCode")
            lChildNodeLevel1.InnerText = "CH"
            lBHT.AppendChild(lChildNodeLevel1.CloneNode(True))
            ''End OF BHT
            lTransactions.AppendChild(lBHT.CloneNode(True))

            ''Start OF REF
            lREF = lXmlDocument.CreateElement("REF")

            lChildNodeLevel1 = lXmlDocument.CreateElement("ReferenceIdentificationQualifier")
            lChildNodeLevel1.InnerText = "87"
            lREF.AppendChild(lChildNodeLevel1.CloneNode(True))

            lChildNodeLevel1 = lXmlDocument.CreateElement("ReferenceIdentification")
            lChildNodeLevel1.InnerText = "004010X098A1"
            lREF.AppendChild(lChildNodeLevel1.CloneNode(True))
            '' ENd REF
            lTransactions.AppendChild(lREF.CloneNode(True))

            lL1000_837PRO = lXmlDocument.CreateElement("L1000_837PRO")
            SubmitterName1000A(pUser, pHCFADB, pHCFADtlCol, lXmlDocument, lL1000_837PRO)
            ReceiverName1000B(pUser, pHCFADB, pHCFADtlCol, lXmlDocument, lL1000_837PRO)

            lTransactions.AppendChild(lL1000_837PRO.CloneNode(True))

            BillingProviderHierarchicalLevel2000A(pUser, pHCFADB, pHCFADtlCol, lXmlDocument, lTransactions)

            'lL2000A_837PRO = lXmlDocument.CreateElement("L2000A_837PRO")
            'lTransactions.AppendChild(lL2000A_837PRO.CloneNode(True))

            ''Start OF SE
            lSE = lXmlDocument.CreateElement("SE")

            lChildNodeLevel1 = lXmlDocument.CreateElement("SegmentCount")
            lChildNodeLevel1.InnerText = "10"
            lSE.AppendChild(lChildNodeLevel1.CloneNode(True))

            lChildNodeLevel1 = lXmlDocument.CreateElement("TransactionSetControlNumber")
            lChildNodeLevel1.InnerText = "00001"
            lSE.AppendChild(lChildNodeLevel1.CloneNode(True))
            '' ENd REF
            lTransactions.AppendChild(lSE.CloneNode(True))


            lFunctionalGroup.AppendChild(lTransactions.CloneNode(True))
            '********************************************'

            ''Start GE
            lGE = lXmlDocument.CreateElement("GE")

            lChildNodeLevel1 = lXmlDocument.CreateElement("TransactionSetCount")
            lChildNodeLevel1.InnerText = "1"
            lGE.AppendChild(lChildNodeLevel1.CloneNode(True))

            lChildNodeLevel1 = lXmlDocument.CreateElement("GroupControlNumber")
            lChildNodeLevel1.InnerText = "123"
            lGE.AppendChild(lChildNodeLevel1.CloneNode(True))
            'End GE
            lFunctionalGroup.AppendChild(lGE.CloneNode(True))
            ''ENd  of Functional group

            lXmlDocument.DocumentElement.AppendChild(lFunctionalGroup.CloneNode(True))


            ''Start of IEA
            lIEA = lXmlDocument.CreateElement("IEA")

            lChildNodeLevel1 = lXmlDocument.CreateElement("FunctionalGroupCount")
            lChildNodeLevel1.InnerText = "1"
            lIEA.AppendChild(lChildNodeLevel1.CloneNode(True))

            lChildNodeLevel1 = lXmlDocument.CreateElement("InterchangeControlNumber")
            lChildNodeLevel1.InnerText = "0000000001"
            lIEA.AppendChild(lChildNodeLevel1.CloneNode(True))

            ''End of IEA

            lXmlDocument.DocumentElement.AppendChild(lIEA.CloneNode(True))
            lXml = lXmlDocument.InnerXml.Replace(" xmlns=""""", "")
            'lXml = lXmlDocument.InnerXml

            SaveToFile(lXml, "")
            Return "11223344"
        Catch ex As Exception
            Throw New Exception("Error Creating 837 Request XML")
        End Try



    End Function


    Public Shared Function SaveToFile(ByVal pInformation As String, ByVal pFileName As String) As String
        Dim lFileStream As FileStream = Nothing
        Dim lUser As User
        Dim lStreamWriter As StreamWriter = Nothing
        Dim lDirectoryInfo As DirectoryInfo
        Dim lPath As String = ""
        'Dim lFileName As String = ""
        If (pFileName = "") Then
            pFileName = Date.Now.ToString("yyyyMMddTHHmmss") & ".txt"
        End If
        Dim lSavePath As String = ""


        lUser = CType(HttpContext.Current.Session.Item("User"), User)

        Try

            lPath = CType(ConfigurationManager.AppSettings("ClaimRquestPath"), String)
            lDirectoryInfo = New DirectoryInfo(lPath)
            If Not lDirectoryInfo.Exists Then
                lDirectoryInfo.Create()
            End If
            lPath = CType(ConfigurationManager.AppSettings("ClaimRquestPath"), String) + lUser.ClinicId
            lDirectoryInfo = New DirectoryInfo(lPath)
            If Not lDirectoryInfo.Exists Then
                lDirectoryInfo.Create()
            End If
            lPath = CType(ConfigurationManager.AppSettings("ClaimRquestPath"), String) + lUser.ClinicId + "\ClaimRequest837\"
            lDirectoryInfo = New DirectoryInfo(lPath)
            If Not lDirectoryInfo.Exists Then
                lDirectoryInfo.Create()
            End If
            'lFileName = Date.Now.ToString("yyyyMMddTHHmmss") & ".txt"

            'Dim pPath As String = "C:\ENS\ClaimRequest\" & Date.Now.ToString("yyyyMMddTHHmmss") & ".xml"
            ''Dim lSavePath As String = "C:\ENS\ClaimRequest\" & Date.Now.ToString("yyyyMMddTHHmmss") & ".txt"
            lSavePath = lPath & pFileName
            'Dim pECCPath As String = "C:\ENS\ClaimRequest\" & "ClaimRequestMapping" & ".ecc"




            'If File.Exists(pPath) Then                
            '    Throw New Exception("File already exists")
            'End If

            'lFileStream = New FileStream(lSavePath, FileMode.OpenOrCreate)
            If File.Exists(lSavePath) Then
                lFileStream = New FileStream(lSavePath, FileMode.Truncate)
            Else
                lFileStream = New FileStream(lSavePath, FileMode.Create)
            End If

            lStreamWriter = New StreamWriter(lFileStream)


            lStreamWriter.Write(pInformation.ToUpper())
            lStreamWriter.Flush()

        Catch ex As Exception
            Return ""
        Finally
            lStreamWriter.Close()
            lFileStream.Close()
        End Try
        Return lSavePath

    End Function

    Public Shared Function SubmitterName1000A(ByRef pUser As User, ByRef pHCFADB As HCFADB, ByRef pHCFADtlCol As HCFADetailColl, ByRef lXmlDocument As XmlDocument, ByRef pXmlElement As XmlElement) As XmlElement
        'Dim lXmlDocument As New XmlDocument
        Dim lRoot As XmlElement = Nothing
        Dim lNM1 As XmlElement = Nothing
        Dim lPER As XmlElement = Nothing
        Dim lChildNodeLevel1 As XmlElement = Nothing
        Dim lChildNodeLevel2 As XmlElement = Nothing

        lRoot = lXmlDocument.CreateElement("L1000A_837PRO")

        lNM1 = lXmlDocument.CreateElement("NM1")

        lChildNodeLevel1 = lXmlDocument.CreateElement("EntityIdentifierCode")
        lChildNodeLevel1.InnerText = "41"
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("EntityTypeQualifier")
        lChildNodeLevel1.InnerText = "2"
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("NameLastOrOrganisationName")
        lChildNodeLevel1.InnerText = "OA Systems"
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("NameFirst")
        lChildNodeLevel1.InnerText = ""
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("NameMiddle")
        lChildNodeLevel1.InnerText = ""
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("NamePrefix")
        lChildNodeLevel1.InnerText = ""
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("NameSuffix")
        lChildNodeLevel1.InnerText = ""
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("IdentificationCodeQualifier")
        lChildNodeLevel1.InnerText = "46"
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("IdentificationCode")
        lChildNodeLevel1.InnerText = "XOA00205"
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))


        ''End Of NM1
        lRoot.AppendChild(lNM1.CloneNode(True))

        ''Start Of PER... SUBMITTER EDI Contact Information
        lPER = lXmlDocument.CreateElement("PER")

        lChildNodeLevel1 = lXmlDocument.CreateElement("ContactFunctionCode")
        lChildNodeLevel1.InnerText = "IC"
        lPER.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("ContactName")
        lChildNodeLevel1.InnerText = "Salman Ali"
        lPER.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("CommunicationNumberQualifier1")
        lChildNodeLevel1.InnerText = "ED"
        lPER.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("CommunicationNumber1")
        lChildNodeLevel1.InnerText = "XOA00205"
        lPER.AppendChild(lChildNodeLevel1.CloneNode(True))

        ''End Of PER
        lRoot.AppendChild(lPER.CloneNode(True))

        pXmlElement.AppendChild(lRoot.CloneNode(True))

        Return lRoot

    End Function

    Public Shared Function ReceiverName1000B(ByRef pUser As User, ByRef pHCFADB As HCFADB, ByRef pHCFADtlCol As HCFADetailColl, ByRef lXmlDocument As XmlDocument, ByRef pXmlElement As XmlElement) As XmlElement
        'Dim lXmlDocument As New XmlDocument
        Dim lRoot As XmlElement = Nothing
        Dim lNM1 As XmlElement = Nothing
        Dim lChildNodeLevel1 As XmlElement = Nothing


        lRoot = lXmlDocument.CreateElement("L1000B_837PRO")

        ''Start Of NMI
        lNM1 = lXmlDocument.CreateElement("NM1")

        lChildNodeLevel1 = lXmlDocument.CreateElement("EntityIdentifierCode")
        lChildNodeLevel1.InnerText = "40"
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("EntityTypeQualifier")
        lChildNodeLevel1.InnerText = "2"
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("NameLastOrOrganisationName")
        lChildNodeLevel1.InnerText = "Electronic Network Systems, Inc."
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("NameFirst")
        lChildNodeLevel1.InnerText = ""
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("NameMiddle")
        lChildNodeLevel1.InnerText = ""
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("NamePrefix")
        lChildNodeLevel1.InnerText = ""
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("NameSuffix")
        lChildNodeLevel1.InnerText = ""
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("IdentificationCodeQualifier")
        lChildNodeLevel1.InnerText = "46"
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("IdentificationCode")
        lChildNodeLevel1.InnerText = "841162764"
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        ''End Of NM1
        lRoot.AppendChild(lNM1.CloneNode(True))

        pXmlElement.AppendChild(lRoot.CloneNode(True))

        Return lXmlDocument.DocumentElement

    End Function

    Public Shared Function BillingProviderHierarchicalLevel2000A(ByRef pUser As User, ByRef pHCFADB As HCFADB, ByRef pHCFADtlCol As HCFADetailColl, ByRef lXmlDocument As XmlDocument, ByRef pXmlElement As XmlElement) As XmlElement
        'Dim lXmlDocument As New XmlDocument
        Dim lRoot As XmlElement = Nothing
        Dim lHL As XmlElement = Nothing
        Dim lL2010A_837PRO As XmlElement = Nothing
        Dim lL2000B_837PRO As XmlElement = Nothing
        'Dim lBillingProvidername As XmlElement = Nothing
        Dim lChildNodeLevel1 As XmlElement = Nothing

        lRoot = lXmlDocument.CreateElement("L2000A_837PRO")
        'lL2010A_837PRO = lXmlDocument.CreateElement("L2010A_837PRO")


        lHL = lXmlDocument.CreateElement("HL_1")

        lChildNodeLevel1 = lXmlDocument.CreateElement("HierarchicalIdNumber")
        lChildNodeLevel1.InnerText = "1"
        lHL.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("HierarchicalParentID")
        lChildNodeLevel1.InnerText = ""
        lHL.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("HierarchicalLevelCode")
        lChildNodeLevel1.InnerText = "20"
        lHL.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("HierarchicalChildCode")
        lChildNodeLevel1.InnerText = "1"
        lHL.AppendChild(lChildNodeLevel1.CloneNode(True))

        ''End Of HL_1

        lRoot.AppendChild(lHL.CloneNode(True))

        lL2010A_837PRO = lXmlDocument.CreateElement("L2010A_837PRO")

        BillingProviderName2010AA(pUser, pHCFADB, pHCFADtlCol, lXmlDocument, lL2010A_837PRO)

        lRoot.AppendChild(lL2010A_837PRO.CloneNode(True))

        '*********************************** Start L2000B_837PRO *****************
        SubscriberHierarchicalLevel2000B(pUser, pHCFADB, pHCFADtlCol, lXmlDocument, lRoot)
        '*********************************** End L2000B_837PRO *****************

        pXmlElement.AppendChild(lRoot.CloneNode(True))

        Return lRoot

    End Function

    Public Shared Function BillingProviderName2010AA(ByRef pUser As User, ByRef pHCFADB As HCFADB, ByRef pHCFADtlCol As HCFADetailColl, ByRef lXmldocument As XmlDocument, ByRef pXmlElement As XmlElement) As XmlElement

        'Dim lXmlDocument As New XmlDocument
        Dim lRoot As XmlElement = Nothing
        Dim lNM1 As XmlElement = Nothing
        Dim lN3 As XmlElement = Nothing
        Dim lN4 As XmlElement = Nothing
        Dim lL2010AA_837 As XmlElement = Nothing
        Dim lREF As XmlElement = Nothing
        Dim lPER As XmlElement = Nothing
        Dim lChildNodeLevel1 As XmlElement = Nothing
        Dim lChildNodeLevel2 As XmlElement = Nothing
        Dim lChildNodeLevel3 As XmlElement = Nothing


        lRoot = lXmldocument.CreateElement("L2010AA_837PRO")

        ''Start Of NM1... Billing Provider Name
        lNM1 = lXmldocument.CreateElement("NM1")

        lChildNodeLevel1 = lXmldocument.CreateElement("EntityIdentifierCode1")
        lChildNodeLevel1.InnerText = "85"
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmldocument.CreateElement("EntityTypeQualifier")
        lChildNodeLevel1.InnerText = "2"
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmldocument.CreateElement("NameLastOrOrganizationName")
        lChildNodeLevel1.InnerText = "PALM DESERT URGENT CARE"
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmldocument.CreateElement("NameFirst")
        lChildNodeLevel1.InnerText = ""
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmldocument.CreateElement("NameMiddle")
        lChildNodeLevel1.InnerText = ""
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmldocument.CreateElement("NamePrefix")
        lChildNodeLevel1.InnerText = ""
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmldocument.CreateElement("NameSuffix")
        lChildNodeLevel1.InnerText = ""
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmldocument.CreateElement("IdentificationCodeQualifier")
        lChildNodeLevel1.InnerText = "XX"
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmldocument.CreateElement("IdentificationCode")
        lChildNodeLevel1.InnerText = "1003849621"
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))


        lRoot.AppendChild(lNM1.CloneNode(True))

        ''Start Of N3... Billing Provider Address
        lN3 = lXmldocument.CreateElement("N3")

        lChildNodeLevel1 = lXmldocument.CreateElement("AddressInformation1")
        lChildNodeLevel1.InnerText = "PO BOX 1118"
        lN3.AppendChild(lChildNodeLevel1.CloneNode(True))


        lRoot.AppendChild(lN3.CloneNode(True))

        ''Start Of N4... Billing Provider CIty State Zip
        lN4 = lXmldocument.CreateElement("N4")

        lChildNodeLevel1 = lXmldocument.CreateElement("CityName")
        lChildNodeLevel1.InnerText = "PALM DESERT"
        lN4.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmldocument.CreateElement("StateOrProvinceCode")
        lChildNodeLevel1.InnerText = "CA"
        lN4.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmldocument.CreateElement("PostalCode")
        lChildNodeLevel1.InnerText = "92260"
        lN4.AppendChild(lChildNodeLevel1.CloneNode(True))



        lRoot.AppendChild(lN4.CloneNode(True))

        'lL2010AA_837 = lXmldocument.CreateElement("L2010AA_837")

        lREF = lXmldocument.CreateElement("REF")

        lChildNodeLevel1 = lXmldocument.CreateElement("ReferenceIdentificationQualifier")
        lChildNodeLevel1.InnerText = "EI"
        lREF.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmldocument.CreateElement("ReferenceIdentification")
        lChildNodeLevel1.InnerText = "330866905"
        lREF.AppendChild(lChildNodeLevel1.CloneNode(True))


        ' ''End Of REF

        lRoot.AppendChild(lREF.CloneNode(True))

        'lRoot.AppendChild(lL2010AA_837.CloneNode(True))
        pXmlElement.AppendChild(lRoot.CloneNode(True))
        Return lRoot



    End Function

    Public Shared Function SubscriberHierarchicalLevel2000B(ByRef pUser As User, ByRef pHCFADB As HCFADB, ByRef pHCFADtlCol As HCFADetailColl, ByRef lXmlDOcument As XmlDocument, ByRef pXmlElementr As XmlElement) As XmlElement
        'Dim lXmlDocument As New XmlDocument
        Dim lRoot As XmlElement = Nothing
        Dim lHL As XmlElement = Nothing
        Dim lSBR As XmlElement = Nothing
        Dim lPAT As XmlElement = Nothing
        Dim lL2010B_837PRO As XmlElement = Nothing
        Dim lL2000C_837PRO As XmlElement = Nothing
        Dim lHL3 As XmlElement = Nothing
        'Dim mPAT As XmlElement = Nothing
        Dim lL2010CA_837PRO As XmlElement = Nothing
        Dim lWeight As XmlElement = Nothing
        Dim lQuantity As XmlElement = Nothing
        Dim lDMG As XmlElement = Nothing

        'Dim lSubscriberName As XmlElement = SubscriberName2010BA(pUser, pHCFADB, pHCFADtlCol)
        'Dim lPayerName As XmlElement = PayerName2010BB(pUser, pHCFADB, pHCFADtlCol)
        Dim lChildNodeLevel1 As XmlElement = Nothing

        lRoot = lXmlDOcument.CreateElement("L2000B_837PRO")

        ''Start Of HL_5 SUBSCRIBER HIERARCHICAL LEVEL
        lHL = lXmlDOcument.CreateElement("HL_5")

        lChildNodeLevel1 = lXmlDOcument.CreateElement("HierarchicalIdNumber")
        lChildNodeLevel1.InnerText = "2"
        lHL.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDOcument.CreateElement("HierarchicalParentIdNumber")
        lChildNodeLevel1.InnerText = "1"
        lHL.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDOcument.CreateElement("HierarchicalLevelCode")
        lChildNodeLevel1.InnerText = "22"
        lHL.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDOcument.CreateElement("HierarchicalChildCode")
        lChildNodeLevel1.InnerText = "0"
        lHL.AppendChild(lChildNodeLevel1.CloneNode(True))
        ''End Of HL_5

        lRoot.AppendChild(lHL.CloneNode(True))


        ''Start Of SBR SUBSCRIBER
        lSBR = lXmlDOcument.CreateElement("SBR")

        lChildNodeLevel1 = lXmlDOcument.CreateElement("PayerResponsibilitySequenceNumberCode")
        lChildNodeLevel1.InnerText = "P"
        lSBR.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDOcument.CreateElement("IndividualRelationshipCode")
        lChildNodeLevel1.InnerText = "18"
        lSBR.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDOcument.CreateElement("ReferenceIdentification")
        lChildNodeLevel1.InnerText = ""
        lSBR.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDOcument.CreateElement("SubscriberName")
        lChildNodeLevel1.InnerText = ""
        lSBR.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDOcument.CreateElement("InsuranceTypeCode")
        lChildNodeLevel1.InnerText = ""
        lSBR.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDOcument.CreateElement("CoordinationOfBenefitsCode")
        lChildNodeLevel1.InnerText = ""
        lSBR.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDOcument.CreateElement("YesNoConditionOrResponseCode")
        lChildNodeLevel1.InnerText = ""
        lSBR.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDOcument.CreateElement("EmploymentStatusCode")
        lChildNodeLevel1.InnerText = ""
        lSBR.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDOcument.CreateElement("ClaimFilingIndicatorCode")
        lChildNodeLevel1.InnerText = "13"
        lSBR.AppendChild(lChildNodeLevel1.CloneNode(True))

        ''End Of SBR
        lRoot.AppendChild(lSBR.CloneNode(True))

        ''Start Of PAT 
        'lChildNodeLevel5 = lXmlDocument.CreateElement("PAT")

        '  lChildNodeLevel6 = lXmlDocument.CreateElement("IndividualRelationShipCode")
        '  lChildNodeLevel6.InnerText = ""
        '  lChildNodeLevel5.AppendChild(lChildNodeLevel6.CloneNode(True))

        '  lChildNodeLevel6 = lXmlDocument.CreateElement("PatientLocationCode")
        '  lChildNodeLevel6.InnerText = ""
        '  lChildNodeLevel5.AppendChild(lChildNodeLevel6.CloneNode(True))

        '  lChildNodeLevel6 = lXmlDocument.CreateElement("EmploymentStatusCode")
        '  lChildNodeLevel6.InnerText = ""
        '  lChildNodeLevel5.AppendChild(lChildNodeLevel6.CloneNode(True))

        '  lChildNodeLevel6 = lXmlDocument.CreateElement("StudentStatusCode")
        '  lChildNodeLevel6.InnerText = ""
        '  lChildNodeLevel5.AppendChild(lChildNodeLevel6.CloneNode(True))

        '  lChildNodeLevel6 = lXmlDocument.CreateElement("DateTimePeriodFormatQualifier")
        '  lChildNodeLevel6.InnerText = ""
        '  lChildNodeLevel5.AppendChild(lChildNodeLevel6.CloneNode(True))

        '  lChildNodeLevel6 = lXmlDocument.CreateElement("DateTimePeriod")
        '  lChildNodeLevel6.InnerText = ""
        '  lChildNodeLevel5.AppendChild(lChildNodeLevel6.CloneNode(True))

        '  lChildNodeLevel6 = lXmlDocument.CreateElement("UnitOrBasisForMeasurementCode")
        '  lChildNodeLevel6.InnerText = ""
        '  lChildNodeLevel5.AppendChild(lChildNodeLevel6.CloneNode(True))

        '  lChildNodeLevel6 = lXmlDocument.CreateElement("Weight")
        '  lChildNodeLevel6.InnerText = ""
        '  lChildNodeLevel5.AppendChild(lChildNodeLevel6.CloneNode(True))

        '  lChildNodeLevel6 = lXmlDocument.CreateElement("YesNoConditionOrResponseCode")
        '  lChildNodeLevel6.InnerText = ""
        '  lChildNodeLevel5.AppendChild(lChildNodeLevel6.CloneNode(True))

        ' ''End Of PAT
        ' lRoot.AppendChild(lPAT.CloneNode(True))

        '************************ L2010B_837PRO ********************
        lL2010B_837PRO = lXmlDOcument.CreateElement("L2010B_837PRO")
        SubscriberName2010BA(pUser, pHCFADB, pHCFADtlCol, lXmlDOcument, lL2010B_837PRO)
        PayerName2010BB(pUser, pHCFADB, pHCFADtlCol, lXmlDOcument, lL2010B_837PRO)
        lRoot.AppendChild(lL2010B_837PRO.CloneNode(True))
        '************************ L2010B_837PRO ********************

        '************************ L2000C_837PRO ********************
        lL2000C_837PRO = lXmlDOcument.CreateElement("L2000C_837PRO")
        lHL3 = lXmlDOcument.CreateElement("HL_3")
        lL2000C_837PRO.AppendChild(lHL3.CloneNode(True))
        lPAT = lXmlDOcument.CreateElement("PAT")
        lWeight = lXmlDOcument.CreateElement("Weight")
        lPAT.AppendChild(lWeight.CloneNode(True))
        lL2000C_837PRO.AppendChild(lPAT.CloneNode(True))

        lL2010CA_837PRO = lXmlDOcument.CreateElement("L2010CA_837PRO")
        lDMG = lXmlDOcument.CreateElement("DMG")
        lQuantity = lXmlDOcument.CreateElement("Quantity")
        lDMG.AppendChild(lQuantity.CloneNode(True))
        lL2010CA_837PRO.AppendChild(lDMG.CloneNode(True))
        lL2000C_837PRO.AppendChild(lL2010CA_837PRO.CloneNode(True))


        ClaimInformation2300(pUser, pHCFADB, pHCFADtlCol, lXmlDOcument, lL2000C_837PRO)
        lRoot.AppendChild(lL2000C_837PRO.CloneNode(True))
        '************************ L2000C_837PRO ********************

        'lRoot.AppendChild(lSubscriberName.CloneNode(True))
        'lRoot.AppendChild(lPayerName.CloneNode(True))


        pXmlElementr.AppendChild(lRoot.CloneNode(True))

        Return lRoot


    End Function

    Public Shared Function SubscriberName2010BA(ByRef pUser As User, ByRef pHCFADB As HCFADB, ByRef pHCFADtlCol As HCFADetailColl, ByRef lXmlDocument As XmlDocument, ByRef pXmlElement As XmlElement) As XmlElement
        'Dim lXmlDocument As New XmlDocument
        Dim lRoot As XmlElement = Nothing
        Dim lNM1 As XmlElement = Nothing
        Dim lN3 As XmlElement = Nothing
        Dim lN4 As XmlElement = Nothing
        Dim lDMG As XmlElement = Nothing
        Dim lChildNodeLevel1 As XmlElement = Nothing
        Dim lChildNodeLevel2 As XmlElement = Nothing
        Dim lChildNodeLevel3 As XmlElement = Nothing


        lRoot = lXmlDocument.CreateElement("L2010BA_837PRO")

        ''Start Of NM1 SUBSCRIBER NAME
        lNM1 = lXmlDocument.CreateElement("NM1")

        lChildNodeLevel1 = lXmlDocument.CreateElement("EntityIdentifierCode1")
        lChildNodeLevel1.InnerText = "IL"
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("EntityTypeQualifier")
        lChildNodeLevel1.InnerText = "1"
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("NameLastOrOrganizationName")
        lChildNodeLevel1.InnerText = "BENJAMIN"
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("NameFirst")
        lChildNodeLevel1.InnerText = "MELVA"
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("NameMiddle")
        lChildNodeLevel1.InnerText = "K"
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("NamePrefix")
        lChildNodeLevel1.InnerText = ""
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("NameSuffix")
        lChildNodeLevel1.InnerText = ""
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("IdentificationCodeQualifier")
        lChildNodeLevel1.InnerText = "MI"
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("IdentificationCode")
        lChildNodeLevel1.InnerText = "488129918D"
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))


        ''End Of NM1
        lRoot.AppendChild(lNM1.CloneNode(True))

        ''Start Of N3 SUBSCRIBER ADDRESS 
        lN3 = lXmlDocument.CreateElement("N3")

        lChildNodeLevel1 = lXmlDocument.CreateElement("AddressInformation1")
        lChildNodeLevel1.InnerText = "74551 COLUMBINE DRIVE"
        lN3.AppendChild(lChildNodeLevel1.CloneNode(True))


        ''End Of N3
        lRoot.AppendChild(lN3.CloneNode(True))

        ''Start Of N4
        lN4 = lXmlDocument.CreateElement("N4")

        lChildNodeLevel1 = lXmlDocument.CreateElement("CityName")
        lChildNodeLevel1.InnerText = "PALM DESERT"
        lN4.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("StateOrProvinceCode")
        lChildNodeLevel1.InnerText = "CA"
        lN4.AppendChild(lChildNodeLevel1.CloneNode(True))


        lChildNodeLevel1 = lXmlDocument.CreateElement("PostalCode")
        lChildNodeLevel1.InnerText = "92260"
        lN4.AppendChild(lChildNodeLevel1.CloneNode(True))

        ''End Of N4
        lRoot.AppendChild(lN4.CloneNode(True))

        ''Start Of DMG
        lDMG = lXmlDocument.CreateElement("DMG")

        lChildNodeLevel1 = lXmlDocument.CreateElement("DateTimePeriodFormatQualifier")
        lChildNodeLevel1.InnerText = "D8"
        lDMG.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("DateTimePeriod")
        lChildNodeLevel1.InnerText = "19920726"
        lDMG.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("GenderCode")
        lChildNodeLevel1.InnerText = "M"
        lDMG.AppendChild(lChildNodeLevel1.CloneNode(True))

        ''End Of DMG
        lRoot.AppendChild(lDMG.CloneNode(True))

        pXmlElement.AppendChild(lRoot.CloneNode(True))

        Return lRoot

    End Function

    Public Shared Function PayerName2010BB(ByRef pUser As User, ByRef pHCFADB As HCFADB, ByRef pHCFADtlCol As HCFADetailColl, ByRef lXmlDocument As XmlDocument, ByRef pXmlElement As XmlElement) As XmlElement
        'Dim lXmlDocument As New XmlDocument
        Dim lRoot As XmlElement = Nothing
        Dim lNM1 As XmlElement = Nothing
        Dim lN3 As XmlElement = Nothing
        Dim lN4 As XmlElement = Nothing
        Dim lDMG As XmlElement = Nothing
        Dim lChildNodeLevel1 As XmlElement = Nothing
        Dim lChildNodeLevel2 As XmlElement = Nothing
        Dim lChildNodeLevel3 As XmlElement = Nothing

        ''Start Of L2010BB_837PRO PRIMARY PAYER
        lRoot = lXmlDocument.CreateElement("L2010BB_837PRO")

        ''Start Of NM1 PRIMARY PAYER NAME
        lNM1 = lXmlDocument.CreateElement("NM1")

        lChildNodeLevel1 = lXmlDocument.CreateElement("EntityIdentifierCode1")
        lChildNodeLevel1.InnerText = "PR"
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("EntityTypeQualifier")
        lChildNodeLevel1.InnerText = "2"
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("NameLastOrOrganisationName")
        lChildNodeLevel1.InnerText = "MEDICARE"
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("NameFirst")
        lChildNodeLevel1.InnerText = ""
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("NameMiddle")
        lChildNodeLevel1.InnerText = ""
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("NamePrefix")
        lChildNodeLevel1.InnerText = ""
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("NameSuffix")
        lChildNodeLevel1.InnerText = ""
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("IdentificationCodeQualifier")
        lChildNodeLevel1.InnerText = "PI"
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("IdentificationCode")
        lChildNodeLevel1.InnerText = "CMSEL"
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))


        ''End Of NM1
        lRoot.AppendChild(lNM1.CloneNode(True))

        ' ''Start Of N3... PRIMARY PAYER ADDRESS
        lN3 = lXmlDocument.CreateElement("N3")

        lChildNodeLevel1 = lXmlDocument.CreateElement("AddressInformation1")
        lChildNodeLevel1.InnerText = "PO BOX 272852"
        lN3.AppendChild(lChildNodeLevel1.CloneNode(True))

        ' ''End Of N3...                              

        lRoot.AppendChild(lN3.CloneNode(True))

        ''Start Of N4... PRIMARY PAYER CITY/STATE/ZIP
        lN4 = lXmlDocument.CreateElement("N4")

        lChildNodeLevel1 = lXmlDocument.CreateElement("CityName")
        lChildNodeLevel1.InnerText = "CHICO"
        lN4.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("StateOrProvinceCode")
        lChildNodeLevel1.InnerText = "CA"
        lN4.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("PostalCode")
        lChildNodeLevel1.InnerText = "95927"
        lN4.AppendChild(lChildNodeLevel1.CloneNode(True))

        '    ''End Of N4...

        lRoot.AppendChild(lN4.CloneNode(True))

        pXmlElement.AppendChild(lRoot.CloneNode(True))



        Return lRoot



    End Function

    Public Shared Function ClaimInformation2300(ByRef pUser As User, ByRef pHCFADB As HCFADB, ByRef pHCFADtlCol As HCFADetailColl, ByRef lXmlDocument As XmlDocument, ByRef pXmlElement As XmlElement) As XmlElement
        'Dim lXmlDocument As XmlDocument
        Dim lRoot As XmlElement = Nothing
        Dim lCLM As XmlElement = Nothing
        Dim lL2300_837PRO_DTP As XmlElement = Nothing
        Dim lL2300_837PRO_AMT As XmlElement = Nothing
        Dim lL2300_837PRO_REF As XmlElement = Nothing
        Dim lL2300_837PRO_CRC As XmlElement = Nothing
        Dim lHI As XmlElement = Nothing
        Dim lL2305_837PRO As XmlElement = Nothing
        Dim lL2310_837PRO As XmlElement = Nothing
        Dim lL2320_837PRO As XmlElement = Nothing
        Dim lL2400_837PRO As XmlElement = Nothing
        'Dim lServiceLine2400 As XmlElement = ServiceLine2400(pUser, pHCFADB, pHCFADtlCol)
        Dim lChildNodeLevel1 As XmlElement = Nothing
        Dim lChildNodeLevel2 As XmlElement = Nothing
        Dim lChildNodeLevel3 As XmlElement = Nothing

        lRoot = lXmlDocument.CreateElement("L2300_837PRO")

        ''Start Of CLM
        lCLM = lXmlDocument.CreateElement("CLM")

        lChildNodeLevel1 = lXmlDocument.CreateElement("ClaimSubmittersIdentifier")
        lChildNodeLevel1.InnerText = "675381"
        lCLM.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("MonetaryAmount")
        lChildNodeLevel1.InnerText = "97.16"
        lCLM.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("ClaimFillingIndicatorCode")
        lChildNodeLevel1.InnerText = ""
        lCLM.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("NonInstitutionalClaimTypeCode")
        lChildNodeLevel1.InnerText = ""
        lCLM.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("HealthCareServiceLocationInformation")

        lChildNodeLevel2 = lXmlDocument.CreateElement("FacilityCodeValue")
        lChildNodeLevel2.InnerText = "11"
        lChildNodeLevel1.AppendChild(lChildNodeLevel2.CloneNode(True))

        lChildNodeLevel2 = lXmlDocument.CreateElement("FacilityCodeQualifier")
        lChildNodeLevel2.InnerText = ""
        lChildNodeLevel1.AppendChild(lChildNodeLevel2.CloneNode(True))

        lChildNodeLevel2 = lXmlDocument.CreateElement("ClaimFrequencyTypeCode")
        lChildNodeLevel2.InnerText = "1"
        lChildNodeLevel1.AppendChild(lChildNodeLevel2.CloneNode(True))

        'End Of HealthCareServiceLocationInformation
        lCLM.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("YesNoConditionOrResponseCode1")
        lChildNodeLevel1.InnerText = "Y"
        lCLM.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("ProviderAcceptAssignmentCode")
        lChildNodeLevel1.InnerText = "A"
        lCLM.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("YesNoConditionOrResponseCode2")
        lChildNodeLevel1.InnerText = "Y"
        lCLM.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("ReleaseOfInformationCode")
        lChildNodeLevel1.InnerText = "Y"
        lCLM.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("PatientSignatureSourceCode")
        lChildNodeLevel1.InnerText = "B"
        lCLM.AppendChild(lChildNodeLevel1.CloneNode(True))

        '' ''lChildNodeLevel9 = lXmlDocument.CreateElement("RelatedCausesInformation")

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("RelatedCausesCode1")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("RelatedCausesCode2")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("RelatedCausesCode3")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("StateOrProvinceCode")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("CountryCode")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))
        ' '' ''End Of RelatedCausesInformation
        '' ''lCLM.AppendChild(lChildNodeLevel9.CloneNode(True))

        '' ''lChildNodeLevel9 = lXmlDocument.CreateElement("SpecialProgramCode")
        '' ''lChildNodeLevel9.InnerText = ""
        '' ''lCLM.AppendChild(lChildNodeLevel9.CloneNode(True))

        '' ''lChildNodeLevel9 = lXmlDocument.CreateElement("YesNoConditionOrResponseCode3")
        '' ''lChildNodeLevel9.InnerText = ""
        '' ''lCLM.AppendChild(lChildNodeLevel9.CloneNode(True))

        '' ''lChildNodeLevel9 = lXmlDocument.CreateElement("LevelOfServiceCode")
        '' ''lChildNodeLevel9.InnerText = ""
        '' ''lCLM.AppendChild(lChildNodeLevel9.CloneNode(True))

        '' ''lChildNodeLevel9 = lXmlDocument.CreateElement("YesNoConditionOrResponseCode4")
        '' ''lChildNodeLevel9.InnerText = ""
        '' ''lCLM.AppendChild(lChildNodeLevel9.CloneNode(True))

        '' ''lChildNodeLevel9 = lXmlDocument.CreateElement("ProviderAgreementCode")
        '' ''lChildNodeLevel9.InnerText = ""
        '' ''lCLM.AppendChild(lChildNodeLevel9.CloneNode(True))

        '' ''lChildNodeLevel9 = lXmlDocument.CreateElement("ClaimStatusCode")
        '' ''lChildNodeLevel9.InnerText = ""
        '' ''lCLM.AppendChild(lChildNodeLevel9.CloneNode(True))
        ''End Of CLM
        lRoot.AppendChild(lCLM.CloneNode(True))

        ''Start Of HI.....
        lHI = lXmlDocument.CreateElement("HI")

        ''Start Of HealthCareCodeInformation1....
        lChildNodeLevel1 = lXmlDocument.CreateElement("HealthCareCodeInformation1")

        lChildNodeLevel2 = lXmlDocument.CreateElement("CodeListQualifierCode")
        lChildNodeLevel2.InnerText = "BK"
        lChildNodeLevel1.AppendChild(lChildNodeLevel2.CloneNode(True))

        lChildNodeLevel2 = lXmlDocument.CreateElement("IndustryCode")
        lChildNodeLevel2.InnerText = "7804"
        lChildNodeLevel1.AppendChild(lChildNodeLevel2.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("DateTimePeriodFormatQualifier")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("DateTimePeriod")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("MonetaryAmount")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("Quantity")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("VersionIdentifier")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))


        ''End Of HealthCareCodeInformation1....
        lHI.AppendChild(lChildNodeLevel1.CloneNode(True))

        ''Start Of HealthCareCodeInformation2....
        lChildNodeLevel1 = lXmlDocument.CreateElement("HealthCareCodeInformation2")

        lChildNodeLevel2 = lXmlDocument.CreateElement("CodeListQualifierCode")
        lChildNodeLevel2.InnerText = "BF"
        lChildNodeLevel1.AppendChild(lChildNodeLevel2.CloneNode(True))

        lChildNodeLevel2 = lXmlDocument.CreateElement("IndustryCode")
        lChildNodeLevel2.InnerText = "38901"
        lChildNodeLevel1.AppendChild(lChildNodeLevel2.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("DateTimePeriodFormatQualifier")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("DateTimePeriod")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("MonetaryAmount")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("Quantity")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("VersionIdentifier")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        ''End Of HealthCareCodeInformation2....
        lHI.AppendChild(lChildNodeLevel1.CloneNode(True))

        ''Start Of HealthCareCodeInformation3....
        lChildNodeLevel1 = lXmlDocument.CreateElement("HealthCareCodeInformation3")

        lChildNodeLevel2 = lXmlDocument.CreateElement("CodeListQualifierCode")
        lChildNodeLevel2.InnerText = "BF"
        lChildNodeLevel1.AppendChild(lChildNodeLevel2.CloneNode(True))

        lChildNodeLevel2 = lXmlDocument.CreateElement("IndustryCode")
        lChildNodeLevel2.InnerText = "4010"
        lChildNodeLevel1.AppendChild(lChildNodeLevel2.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("DateTimePeriodFormatQualifier")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("DateTimePeriod")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("MonetaryAmount")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("Quantity")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("VersionIdentifier")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        ''End Of HealthCareCodeInformation3....
        lHI.AppendChild(lChildNodeLevel1.CloneNode(True))

        ''Start Of HealthCareCodeInformation4....
        lChildNodeLevel1 = lXmlDocument.CreateElement("HealthCareCodeInformation4")

        lChildNodeLevel2 = lXmlDocument.CreateElement("CodeListQualifierCode")
        lChildNodeLevel2.InnerText = "BF"
        lChildNodeLevel1.AppendChild(lChildNodeLevel2.CloneNode(True))

        lChildNodeLevel2 = lXmlDocument.CreateElement("IndustryCode")
        lChildNodeLevel2.InnerText = "4010"
        lChildNodeLevel1.AppendChild(lChildNodeLevel2.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("DateTimePeriodFormatQualifier")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("DateTimePeriod")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("MonetaryAmount")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("Quantity")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("VersionIdentifier")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        ''End Of HealthCareCodeInformation4....
        lHI.AppendChild(lChildNodeLevel1.CloneNode(True))

        ''Start Of HealthCareCodeInformation5....
        '' ''lChildNodeLevel9 = lXmlDocument.CreateElement("HealthCareCodeInformation5")

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("CodeListQualifierCode")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("IndustryCode")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("DateTimePeriodFormatQualifier")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("DateTimePeriod")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("MonetaryAmount")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("Quantity")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("VersionIdentifier")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' '' ''End Of HealthCareCodeInformation5....
        '' ''lChildNodeLevel8.AppendChild(lChildNodeLevel9.CloneNode(True))

        '' '' ''Start Of HealthCareCodeInformation6....
        '' ''lChildNodeLevel9 = lXmlDocument.CreateElement("HealthCareCodeInformation6")

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("CodeListQualifierCode")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("IndustryCode")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("DateTimePeriodFormatQualifier")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("DateTimePeriod")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("MonetaryAmount")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("Quantity")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("VersionIdentifier")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' '' ''End Of HealthCareCodeInformation6....
        '' ''lChildNodeLevel8.AppendChild(lChildNodeLevel9.CloneNode(True))

        '' '' ''Start Of HealthCareCodeInformation7....
        '' ''lChildNodeLevel9 = lXmlDocument.CreateElement("HealthCareCodeInformation7")

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("CodeListQualifierCode")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("IndustryCode")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("DateTimePeriodFormatQualifier")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("DateTimePeriod")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("MonetaryAmount")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("Quantity")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("VersionIdentifier")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' '' ''End Of HealthCareCodeInformation7....
        '' ''lChildNodeLevel8.AppendChild(lChildNodeLevel9.CloneNode(True))

        '' '' ''Start Of HealthCareCodeInformation8....
        '' ''lChildNodeLevel9 = lXmlDocument.CreateElement("HealthCareCodeInformation8")

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("CodeListQualifierCode")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("IndustryCode")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("DateTimePeriodFormatQualifier")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("DateTimePeriod")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("MonetaryAmount")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("Quantity")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("VersionIdentifier")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' '' ''End Of HealthCareCodeInformation8....
        '' ''lChildNodeLevel8.AppendChild(lChildNodeLevel9.CloneNode(True))

        '' '' ''Start Of HealthCareCodeInformation9....
        '' ''lChildNodeLevel9 = lXmlDocument.CreateElement("HealthCareCodeInformation9")

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("CodeListQualifierCode")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("IndustryCode")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("DateTimePeriodFormatQualifier")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("DateTimePeriod")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("MonetaryAmount")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("Quantity")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("VersionIdentifier")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' '' ''End Of HealthCareCodeInformation9....
        '' ''lChildNodeLevel8.AppendChild(lChildNodeLevel9.CloneNode(True))

        '' '' ''Start Of HealthCareCodeInformation10....
        '' ''lChildNodeLevel9 = lXmlDocument.CreateElement("HealthCareCodeInformation10")

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("CodeListQualifierCode")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("IndustryCode")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("DateTimePeriodFormatQualifier")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("DateTimePeriod")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("MonetaryAmount")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("Quantity")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("VersionIdentifier")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' '' ''End Of HealthCareCodeInformation10....
        '' ''lChildNodeLevel8.AppendChild(lChildNodeLevel9.CloneNode(True))

        '' '' ''Start Of HealthCareCodeInformation11....
        '' ''lChildNodeLevel9 = lXmlDocument.CreateElement("HealthCareCodeInformation11")

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("CodeListQualifierCode")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("IndustryCode")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("DateTimePeriodFormatQualifier")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("DateTimePeriod")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("MonetaryAmount")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("Quantity")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("VersionIdentifier")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' '' ''End Of HealthCareCodeInformation10....
        '' ''lChildNodeLevel8.AppendChild(lChildNodeLevel9.CloneNode(True))

        '' '' ''Start Of HealthCareCodeInformation12....
        '' ''lChildNodeLevel9 = lXmlDocument.CreateElement("HealthCareCodeInformation12")
        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("CodeListQualifierCode")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("IndustryCode")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("DateTimePeriodFormatQualifier")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("DateTimePeriod")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("MonetaryAmount")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("Quantity")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' ''lChildNodeLevel10 = lXmlDocument.CreateElement("VersionIdentifier")
        '' ''lChildNodeLevel10.InnerText = ""
        '' ''lChildNodeLevel9.AppendChild(lChildNodeLevel10.CloneNode(True))

        '' '' ''End Of HealthCareCodeInformation10....
        '' ''lChildNodeLevel8.AppendChild(lChildNodeLevel9.CloneNode(True))

        ''End Of HI...
        lRoot.AppendChild(lHI.CloneNode(True))

        '********************* L2310_837PRO *********************************
        lL2310_837PRO = lXmlDocument.CreateElement("L2310_837PRO")
        RenderingProviderName2310B(pUser, pHCFADB, pHCFADtlCol, lXmlDocument, lL2310_837PRO)
        ServiceFacilityLocation2310D(pUser, pHCFADB, pHCFADtlCol, lXmlDocument, lL2310_837PRO)
        lRoot.AppendChild(lL2310_837PRO.CloneNode(True))
        '********************* L2310_837PRO *********************************

        '********************* L2320_837PRO *********************************
        ''''''''''''''''' Filled later
        '********************* L2320_837PRO *********************************


        '********************* L2400_837PRO *********************************
        ServiceLine2400(pUser, pHCFADB, pHCFADtlCol, lXmlDocument, lRoot)
        '********************* L2400_837PRO *********************************


        pXmlElement.AppendChild(lRoot.CloneNode(True))
        Return lRoot

    End Function

    Public Shared Function RenderingProviderName2310B(ByRef pUser As User, ByRef pHCFADB As HCFADB, ByRef pHCFADtlCol As HCFADetailColl, ByRef lXmlDocument As XmlDocument, ByRef pXmlElement As XmlElement) As XmlElement
        'Dim lXmlDocument As New XmlDocument
        Dim lRoot As XmlElement = Nothing
        Dim lNM1 As XmlElement = Nothing
        Dim lPRV As XmlElement = Nothing
        Dim lREF As XmlElement = Nothing
        Dim lChildNodeLevel1 As XmlElement = Nothing
        Dim lChildNodeLevel2 As XmlElement = Nothing
        Dim lChildNodeLevel3 As XmlElement = Nothing

        lRoot = lXmlDocument.CreateElement("L2310B_837PRO")


        ''Start OF NM1...
        lNM1 = lXmlDocument.CreateElement("NM1")

        lChildNodeLevel1 = lXmlDocument.CreateElement("EntityIdentifierCode1")
        lChildNodeLevel1.InnerText = "82"
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("EntityTypeQualifier")
        lChildNodeLevel1.InnerText = "1"
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("NameLastOrOrganizationName")
        lChildNodeLevel1.InnerText = "KAZI"
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("NameFirst")
        lChildNodeLevel1.InnerText = "MANZOOR"
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("NameMiddle")
        lChildNodeLevel1.InnerText = "A"
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("NamePrefix")
        lChildNodeLevel1.InnerText = ""
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("NameSuffix")
        lChildNodeLevel1.InnerText = ""
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("IdentificationCodeQualifier")
        lChildNodeLevel1.InnerText = "XX"
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("IdentificationCode")
        lChildNodeLevel1.InnerText = "1225032212"
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        '' ''lChildNodeLevel11 = lXmlDocument.CreateElement("IdentificationCode")
        '' ''lChildNodeLevel11.InnerText = ""
        '' ''lChildNodeLevel10.AppendChild(lChildNodeLevel11.CloneNode(True))

        '' ''lChildNodeLevel11 = lXmlDocument.CreateElement("IdentificationCode")
        '' ''lChildNodeLevel11.InnerText = ""
        '' ''lChildNodeLevel10.AppendChild(lChildNodeLevel11.CloneNode(True))
        ''End Of NM1 
        lRoot.AppendChild(lNM1.CloneNode(True))
        pXmlElement.AppendChild(lRoot.CloneNode(True))
        Return lRoot
    End Function
    Public Shared Function ServiceFacilityLocation2310D(ByRef pUser As User, ByRef pHCFADB As HCFADB, ByRef pHCFADtlCol As HCFADetailColl, ByRef lXmlDocument As XmlDocument, ByRef pXmlElement As XmlElement) As XmlElement
        'Dim lXmlDocument As New XmlDocument
        Dim lRoot As XmlElement = Nothing
        Dim lNM1 As XmlElement = Nothing
        Dim lN3 As XmlElement = Nothing
        Dim lN4 As XmlElement = Nothing
        Dim lChildNodeLevel1 As XmlElement = Nothing
        Dim lChildNodeLevel2 As XmlElement = Nothing
        Dim lChildNodeLevel3 As XmlElement = Nothing

        ''Start Of L2310D_837PRO SERVICE FACILITY LOCATION
        lRoot = lXmlDocument.CreateElement("L2310D_837PRO")

        ''Start OF NM1...
        lNM1 = lXmlDocument.CreateElement("NM1")

        lChildNodeLevel1 = lXmlDocument.CreateElement("EntityIdentifierCode1")
        lChildNodeLevel1.InnerText = "FA"
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("EntityTypeQualifier")
        lChildNodeLevel1.InnerText = "2"
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("NameLastOrOrganizationName")
        lChildNodeLevel1.InnerText = "PALM DESERT URGENT CARE ME"
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("NameFirst")
        lChildNodeLevel1.InnerText = ""
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("NameMiddle")
        lChildNodeLevel1.InnerText = ""
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("NamePrefix")
        lChildNodeLevel1.InnerText = ""
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("NameSuffix")
        lChildNodeLevel1.InnerText = ""
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("IdentificationCodeQualifier")
        lChildNodeLevel1.InnerText = "XX"
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("IdentificationCode")
        lChildNodeLevel1.InnerText = "1003849621"
        lNM1.AppendChild(lChildNodeLevel1.CloneNode(True))

        ''End Of NM1 
        lRoot.AppendChild(lNM1.CloneNode(True))

        ''Start OF N3...
        lN3 = lXmlDocument.CreateElement("N3")

        lChildNodeLevel1 = lXmlDocument.CreateElement("AddressInformation1")
        lChildNodeLevel1.InnerText = "73345 HWY 111 STE 101"
        lN3.AppendChild(lChildNodeLevel1.CloneNode(True))


        ''End Of N3
        lRoot.AppendChild(lN3.CloneNode(True))

        ''Start Of N4
        lN4 = lXmlDocument.CreateElement("N4")

        lChildNodeLevel1 = lXmlDocument.CreateElement("CityName")
        lChildNodeLevel1.InnerText = "PALM DESERT"
        lN4.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("StateOrProvinceCode")
        lChildNodeLevel1.InnerText = "CA"
        lN4.AppendChild(lChildNodeLevel1.CloneNode(True))


        lChildNodeLevel1 = lXmlDocument.CreateElement("PostalCode")
        lChildNodeLevel1.InnerText = "92260"
        lN4.AppendChild(lChildNodeLevel1.CloneNode(True))


        ''End Of N4
        lRoot.AppendChild(lN4.CloneNode(True))

        ''End Of L2310B_837PRO

        pXmlElement.AppendChild(lRoot.CloneNode(True))

        Return lRoot

    End Function
    Public Shared Function ServiceLine2400(ByRef pUser As User, ByRef pHCFADB As HCFADB, ByRef pHCFADtlCol As HCFADetailColl, ByRef lXmlDocument As XmlDocument, ByRef pXmlElement As XmlElement) As XmlElement
        'Dim lXmlDocument As New XmlDocument
        Dim lRoot As XmlElement = Nothing
        Dim lLX As XmlElement = Nothing
        Dim lSV1 As XmlElement = Nothing
        Dim lDTP As XmlElement = Nothing
        Dim lDMG As XmlElement = Nothing
        Dim lChildNodeLevel1 As XmlElement = Nothing
        Dim lChildNodeLevel2 As XmlElement = Nothing
        Dim lChildNodeLevel3 As XmlElement = Nothing

        lRoot = lXmlDocument.CreateElement("L2400_837PRO")

        ''Start Of LX SERVICE LINE
        lLX = lXmlDocument.CreateElement("LX")
        lLX.InnerText = "1"
        'lChildNodeLevel1 = lXmlDocument.CreateElement("LocationIdentifier")

        'lLX.AppendChild(lChildNodeLevel1.CloneNode(True))

        ''End Of LX
        lRoot.AppendChild(lLX.CloneNode(True))

        ''Start Of SV1 PROFESSIONAL SERVICE
        lSV1 = lXmlDocument.CreateElement("SV1")

        lChildNodeLevel1 = lXmlDocument.CreateElement("CompositeMedicalProcedureIdentifier")

        lChildNodeLevel2 = lXmlDocument.CreateElement("ProductServiceIdQualifier")
        lChildNodeLevel2.InnerText = "HC"
        lChildNodeLevel1.AppendChild(lChildNodeLevel2.CloneNode(True))

        lChildNodeLevel2 = lXmlDocument.CreateElement("ProductServiceId")
        lChildNodeLevel2.InnerText = "99214"
        lChildNodeLevel1.AppendChild(lChildNodeLevel2.CloneNode(True))

        lSV1.AppendChild(lChildNodeLevel1.CloneNode(True))


        lChildNodeLevel1 = lXmlDocument.CreateElement("MonetaryAmount1")
        lChildNodeLevel1.InnerText = "97.16"
        lSV1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("UnitOrBasisForMeasurementCode")
        lChildNodeLevel1.InnerText = "UN"
        lSV1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("Quantity")
        lChildNodeLevel1.InnerText = "1"
        lSV1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("FacilityCodeValue")
        lChildNodeLevel1.InnerText = ""
        lSV1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("ServiceTypeCode")
        lChildNodeLevel1.InnerText = ""
        lSV1.AppendChild(lChildNodeLevel1.CloneNode(True))

        lChildNodeLevel1 = lXmlDocument.CreateElement("CompositeDiagnosisCodePointer")

        lChildNodeLevel2 = lXmlDocument.CreateElement("DiagnosisCodePointer1")
        lChildNodeLevel2.InnerText = "1"
        lChildNodeLevel1.AppendChild(lChildNodeLevel2.CloneNode(True))

        lChildNodeLevel2 = lXmlDocument.CreateElement("DiagnosisCodePointer2")
        lChildNodeLevel2.InnerText = "2"
        lChildNodeLevel1.AppendChild(lChildNodeLevel2.CloneNode(True))

        lChildNodeLevel2 = lXmlDocument.CreateElement("DiagnosisCodePointer3")
        lChildNodeLevel2.InnerText = "3"
        lChildNodeLevel1.AppendChild(lChildNodeLevel2.CloneNode(True))

        lChildNodeLevel2 = lXmlDocument.CreateElement("DiagnosisCodePointer4")
        lChildNodeLevel2.InnerText = "4"
        lChildNodeLevel1.AppendChild(lChildNodeLevel2.CloneNode(True))

        lSV1.AppendChild(lChildNodeLevel1.CloneNode(True))


        ''End Of SV1
        lRoot.AppendChild(lSV1.CloneNode(True))

        ''Start Of L2400_837PRO_DTP
        lChildNodeLevel1 = lXmlDocument.CreateElement("L2400_837PRO_DTP")

        '' SERVICE DATE
        lDTP = lXmlDocument.CreateElement("DTP")

        lChildNodeLevel2 = lXmlDocument.CreateElement("DateTimeQualifier")
        lChildNodeLevel2.InnerText = "472"
        lDTP.AppendChild(lChildNodeLevel2.CloneNode(True))

        lChildNodeLevel2 = lXmlDocument.CreateElement("DateTimePeriodFormatQualifier")
        lChildNodeLevel2.InnerText = "D8"
        lDTP.AppendChild(lChildNodeLevel2.CloneNode(True))

        lChildNodeLevel2 = lXmlDocument.CreateElement("DateTimePeriod")
        lChildNodeLevel2.InnerText = "20070810"
        lDTP.AppendChild(lChildNodeLevel2.CloneNode(True))

        ''End Of L2400_837PRO_DTP
        lChildNodeLevel1.AppendChild(lDTP.CloneNode(True))

        lRoot.AppendChild(lChildNodeLevel1.CloneNode(True))

        pXmlElement.AppendChild(lRoot.CloneNode(True))

        Return lRoot

    End Function

    'Public Shared Function MapFile(ByVal pSourcePath As String, ByVal pDestinationPath As String, ByVal pECCPath As String) As Boolean
    '    Dim lMapper As New MAPPERLib.EncoreMapper

    '    Try
    '        lMapper.LoadDefinition(pECCPath)
    '        If Not File.Exists(pSourcePath) Then
    '            Throw New Exception("Source File does not exist")
    '        End If

    '        lMapper.MapFiles(pSourcePath, pDestinationPath)
    '        Return True
    '    Catch ex As Exception
    '        Throw ex
    '    End Try
    'End Function

    Public Shared Function Make837Request(ByRef pUser As User, ByRef pHCFADB As HCFADB, ByRef pPatientCPTCol As PatientCPTColl) As String
        Dim lPrimaryInsuraneSelf As Boolean = False
        Dim lSecondaryInsuraneSelf As Boolean = False
        Dim lPrimaryInsuranceExist As Boolean = False
        Dim lSecondaryInsuranceExist As Boolean = False
        Dim lPrimaryInsuranceCompanyId As Int32 = 0
        Dim lSecondaryInsuranceCompanyId As Int32 = 0
        Dim lPatient As New PatientExtended(pUser.ConnectionString)
        lPatient.Patient.PatientID = pHCFADB.PatientAccountNumber
        lPatient.GetPatientWithDetailsByID()
        Dim lPrimaryInsurerPatient As New PatientExtended(pUser.ConnectionString)
        Dim lPrimaryInsuranceCompany As New Insurance(pUser.ConnectionString)
        Dim lSecondaryInsurerPatient As New PatientExtended(pUser.ConnectionString)
        Dim lSecondaryInsuranceCompany As New Insurance(pUser.ConnectionString)
        Dim lClaimId As String = ""
        Dim lBillingProvider As BillingProvider


        '''''''''''''' Primary Insurance And Insurer Checking Logic
        If (lPatient.Patient.PrimaryInsurance.Active = "Y" And (lPatient.Patient.PrimaryInsurance.InsuranceCompanyID <> 0 Or lPatient.Patient.PrimaryInsurance.InsurerId <> 0)) Then
            lPrimaryInsuranceExist = True
            If (lPatient.Patient.PrimaryInsurance.InsurerId <> 0) Then
                lPrimaryInsuraneSelf = False
                lPrimaryInsurerPatient.Patient.PatientID = lPatient.Patient.PrimaryInsurance.InsurerId
                lPrimaryInsurerPatient.GetPatientWithDetailsByID()
                'lPrimaryInsuranceCompany.InsuranceDB.FavouriteInsuranceID = lPrimaryInsurerPatient.Patient.PrimaryInsurance.InsuranceCompanyID
                'lPrimaryInsuranceCompany.GetRecordById()
            Else
                lPrimaryInsuraneSelf = True
            End If
        Else
            lPrimaryInsuranceExist = False
        End If
        '''''''''''''' Primary Insurance And Insurer Checking Logic

        '''''''''''''' Secondary Insurance And Insurer Checking Logic
        If (lPatient.Patient.SecondaryInsurance.Active = "Y" And (lPatient.Patient.SecondaryInsurance.InsuranceCompanyID <> 0 Or lPatient.Patient.SecondaryInsurance.InsurerId <> 0)) Then
            lSecondaryInsuranceExist = True
            If (lPatient.Patient.SecondaryInsurance.InsurerId <> 0) Then
                lSecondaryInsuraneSelf = False
                lSecondaryInsurerPatient.Patient.PatientID = lPatient.Patient.SecondaryInsurance.InsurerId
                lSecondaryInsurerPatient.GetPatientWithDetailsByID()
                'lSecondaryInsuranceCompany.InsuranceDB.FavouriteInsuranceID = lSecondaryInsurerPatient.Patient.SecondaryInsurance.InsuranceCompanyID
                'lSecondaryInsuranceCompany.GetRecordById()
            Else
                lSecondaryInsuraneSelf = True
            End If
        Else
            lSecondaryInsuranceExist = False
        End If
        '''''''''''''' Secondary Insurance And Insurer Checking Logic

        Dim lConnection As New Connection(pUser.ConnectionString)

        Dim lQuery As String

        If (lPrimaryInsuranceExist) Then
            If (lPrimaryInsuraneSelf) Then
                lPrimaryInsuranceCompanyId = lPatient.Patient.PrimaryInsurance.InsuranceCompanyID
            Else
                lPrimaryInsuranceCompanyId = lPrimaryInsurerPatient.Patient.PrimaryInsurance.InsuranceCompanyID
            End If
        Else
            lPrimaryInsuranceCompanyId = 0
        End If

        If (lSecondaryInsuranceExist) Then
            If (lSecondaryInsuraneSelf) Then
                lSecondaryInsuranceCompanyId = lPatient.Patient.SecondaryInsurance.InsuranceCompanyID
            Else
                lSecondaryInsuranceCompanyId = lSecondaryInsurerPatient.Patient.SecondaryInsurance.InsuranceCompanyID
            End If
        Else
            lSecondaryInsuranceCompanyId = 0
        End If



        lQuery = "Exec GetMultipleTableForClaimEDI " & pUser.ClinicId & "," & IIf(pHCFADB.RefferingProviderID <> "", pHCFADB.RefferingProviderID, 0) & "," & pHCFADB.DoctorUserID & "," & lPrimaryInsuranceCompanyId & "," & lSecondaryInsuranceCompanyId & "," & pHCFADB.FacilityId


        Dim lDs As New DataSet
        lDs = lConnection.ExecuteQuery(lQuery)

        Dim lClinic As New Clinic(pUser.ConnectionString)
        lClinic.Clinic.ClinicId = pUser.ClinicId
        lClinic.GetRecordByID(lDs.Tables(0))

        Dim lReferringProvider As New ReferringProvider(pUser.ConnectionString)
        'lReferringProvider.ReferringProviderDB.ProviderID = pHCFADB.DoctorUserID
        lReferringProvider.GetRecordByID(lDs.Tables(1))

        Dim lRenderingProvider As New Employee(pUser.ConnectionString)
        'lRenderingProvider.Employee.EmployeeID = pHCFADB.DoctorUserID
        lRenderingProvider.GetRecordByID(lDs.Tables(2))

        If (lPrimaryInsuranceExist) Then
            lPrimaryInsuranceCompany.GetRecordById(lDs.Tables(3))
        End If

        If (lSecondaryInsuranceExist) Then
            lSecondaryInsuranceCompany.GetRecordById(lDs.Tables(4))
        End If

        Dim lFacility As New Facility(pUser.ConnectionString)
        If (Not lDs.Tables(5) Is Nothing) Then
            lFacility.GetRecordById(lDs.Tables(5))
        End If



        Dim lInterChange As New ClaimLibrary.MsgInterchange()
        Dim lGs As ClaimLibrary.GrpInterchangeFunctionalGroup
        Dim lTransaction As ClaimLibrary.Msg837_PRO




        With lInterChange.ISA
            .AuthorizationInformationQualifier.Value = "00"
            .AuthorizationInformation.Value = "123456789"
            .SecurityInformationQualifier.Value = "00"
            .SecurityInformation.Value = "123456789"
            .InterchangeIDQualifier1.Value = "ZZ"
            .InterchangeSenderID.Value = "12345678987654"
            .InterchangeIDQualifier2.Value = "ZZ"
            .InterchangeReceiverID.Value = "12345678987654"
            .InterchangeDate.Value = Date.Now.ToString("yyyyMMdd")
            .InterchangeTime.Value = Date.Now.ToString("HHmm")
            .InterchangeControlStandardsIdentifier.Value = "U"
            .InterchangeControlVersionNumber.Value = "00401"
            .InterchangeControlNumber.Value = "000000001"
            .AcknowledgmentRequested.Value = "1"
            .UsageIndicator.Value = "P"
            .ComponentElementSeparator.Value = ":"

            lGs = lInterChange.FunctionalGroup.Append()


        End With

        With lGs.GS
            .FunctionalIdentifierCode.Value = "HC"
            .ApplicationSendersCode.Value = "123456789"
            .ApplicationReceiversCode.Value = "987654321"
            .Date.Value = Date.Now.ToString("yyyyMMdd")
            .Time.Value = Date.Now.ToString("HHmm")
            .GroupControlNumber.Value = "123"
            .ResponsibleAgencyCode.Value = "X"
            .VersionReleaseIndustryIdentifierCode.Value = "004010X098A1"


        End With

        lTransaction = lGs.Transactions.Append("837_PRO")

        With lTransaction.ST
            .TransactionSetIdentifierCode.Value = "837"
            .TransactionSetControlNumber.Value = "000000001"
        End With

        With lTransaction.BHT
            .HierarchicalStructureCode.Value = "0019"
            .TransactionSetPurposeCode.Value = "00"
            .ReferenceIdentification.Value = "0123"
            .Date.Value = Date.Now.ToString("yyyyMMdd")
            .Time.Value = Date.Now.ToString("HHmm")
            .TransactionTypeCode.Value = "CH"
        End With

        With lTransaction.REF
            .ReferenceIdentificationQualifier.Value = "87"
            .ReferenceIdentification.Value = "004010X098A1"
        End With


        ''''''' Sender''''''''''''''''''
        With lTransaction.L1000A_837PRO.NM1
            .EntityIdentifierCode1.Value = "41"
            .EntityTypeQualifier.Value = "2"
            .NameLastOrOrganizationName.Value = "OA Systems"
            .NameFirst.Value = ""
            .NameMiddle.Value = ""
            .NamePrefix.Value = ""
            .NameSuffix.Value = ""
            .IdentificationCodeQualifier.Value = "46"
            .IdentificationCode.Value = "XOA00205"
            .EntityRelationshipCode.Value = ""
            .EntityIdentifierCode2.Value = ""
        End With

        Dim lPer As ClaimLibrary.SegPER
        lPer = lTransaction.L1000A_837PRO.PER.Append()



        With lPer
            .ContactFunctionCode.Value = "IC"
            .ContactName.Value = "Salman Ali"
            .CommunicationNumberQualifier1.Value = "TE"
            .CommunicationNumber1.Value = lClinic.Clinic.Phone1 '"XOA00205"
            .CommunicationNumberQualifier2.Value = ""
            .CommunicationNumber2.Value = ""
            .CommunicationNumberQualifier3.Value = ""
            .CommunicationNumber3.Value = ""
            .ContactInquiryReference.Value = ""
        End With

        ''''''''''''' Sender'''''''''''''''''

        ''''''''''''' receiver'''''''''''''''''
        With lTransaction.L1000B_837PRO.NM1
            .EntityIdentifierCode1.Value = "40"
            .EntityTypeQualifier.Value = "2"
            .NameLastOrOrganizationName.Value = "Electronic Network Systems, Inc."
            .NameFirst.Value = ""
            .NameMiddle.Value = ""
            .NamePrefix.Value = ""
            .NameSuffix.Value = ""
            .IdentificationCodeQualifier.Value = "46"
            .IdentificationCode.Value = "841162764"
            .EntityRelationshipCode.Value = ""
            .EntityIdentifierCode2.Value = ""
        End With
        ''''''''''''' Receiver'''''''''''''''''

        '''''''''''''''' 2000A Billing Provider Starts''''''''''
        Dim l2000A As Grp837_PROL2000A_837PRO
        l2000A = lTransaction.L2000A_837PRO.Append()

        With l2000A.HL_1
            .HierarchicalIdNumber.Value = "1"
            .HierarchicalParentIdNumber.Value = ""
            .HierarchicalLevelCode.Value = "20"
            'If (lPrimaryInsuraneSelf) Then
            .HierarchicalChildCode.Value = "1"
            ' Else
            '.HierarchicalChildCode.Value = "2"
            'End If
        End With

        With l2000A.L2010AA_837PRO1.NM1
            .EntityIdentifierCode1.Value = "85"
            .EntityTypeQualifier.Value = "1"
            .NameLastOrOrganizationName.Value = lClinic.Clinic.ClinicName '"Palm Desert Urgent Care"
            .NameFirst.Value = "Uzma"
            .NameMiddle.Value = "Ali"
            .NamePrefix.Value = ""
            .NameSuffix.Value = ""
            .IdentificationCodeQualifier.Value = "XX"
            .IdentificationCode.Value = pHCFADB.ClinicPinNumber ''lClinic.Clinic.NPI    '"1003849621"
            .EntityRelationshipCode.Value = ""
            .EntityIdentifierCode2.Value = ""
        End With

        With l2000A.L2010AA_837PRO1.N3
            .AddressInformation1.Value = lClinic.Clinic.AddressLine1  '"PO Box 1118"
            .AddressInformation2.Value = lClinic.Clinic.AddressLine2
        End With

        With l2000A.L2010AA_837PRO1.N4
            .CityName.Value = lClinic.Clinic.City  '"Palm Desert"
            .StateOrProvinceCode.Value = lClinic.Clinic.StateId
            .PostalCode.Value = lClinic.Clinic.ZipCode  '"92260"
            .CountryCode.Value = ""
            .LocationQualifier.Value = ""
            .LocationIdentifier.Value = ""
        End With

        Dim lRef As SegREF

        If (lClinic.Clinic.FacilityCode <> "") Then
            lRef = l2000A.L2010AA_837PRO1.REF1.Append
            With lRef
                If (pHCFADB.ClinicSecondaryIdentificationQualifier <> "" And pHCFADB.ClinicGroupNumber <> "") Then
                    .ReferenceIdentificationQualifier.Value = pHCFADB.ClinicSecondaryIdentificationQualifier
                    .ReferenceIdentification.Value = pHCFADB.ClinicGroupNumber
                    .Description.Value = ""
                Else
                    .ReferenceIdentificationQualifier.Value = "EI"
                    .ReferenceIdentification.Value = "330866905" 'lClinic.Clinic.FacilityCode '
                    .Description.Value = ""
                End If

            End With
        End If
        '************************ 2000A Billing Provider End 

        '************************ 2000B Subscriber Starts 

        Dim l2000B As Grp837_PROL2000B_837PRO
        l2000B = l2000A.L2000B_837PRO.Append()


        With l2000B.HL_5
            .HierarchicalIdNumber.Value = "2"
            .HierarchicalParentIdNumber.Value = "1"
            .HierarchicalLevelCode.Value = "22"
            If (lPrimaryInsuraneSelf) Then
                .HierarchicalChildCode.Value = "0"
            Else
                .HierarchicalChildCode.Value = "1"
            End If

        End With


        With l2000B.SBR
            .PayerResponsibilitySequenceNumberCode.Value = "P"
            If (lPrimaryInsuraneSelf) Then
                .IndividualRelationshipCode.Value = "18"
            Else
                .IndividualRelationshipCode.Value = ""
            End If
            'lPatient.Patient.PrimaryInsurance.RelationshipToPrimaryInsurer
            '    Case "Self"
            '.IndividualRelationshipCode.Value = "18"
            '    Case "Souse"
            '.IndividualRelationshipCode.Value = "01"
            '    Case "Child"
            '.IndividualRelationshipCode.Value = "19"
            '    Case "Other"
            '.IndividualRelationshipCode.Value = "G8"
            'End Select
            .ReferenceIdentification.Value = pHCFADB.AnotherInsuredPolicy '""
            .SubscriberName.Value = pHCFADB.AnotherInsuredInsurancePlan '""

            If (.PayerResponsibilitySequenceNumberCode.Value <> "P" And pHCFADB.Type1 = "MEDICARE") Then
                .InsuranceTypeCode.Value = "" 'type of insurance policy within specified program
            Else
                .InsuranceTypeCode.Value = ""
            End If
            .CoordinationOfBenefitsCode.Value = ""
            .YesNoConditionOrResponseCode.Value = ""
            .EmploymentStatusCode.Value = ""
            Select Case pHCFADB.Type1.ToUpper
                Case "MEDICARE"
                    .ClaimFilingIndicatorCode.Value = "MB"
                Case "MEDICAID"
                    .ClaimFilingIndicatorCode.Value = "MC"
                Case "CHAMPUS"
                    .ClaimFilingIndicatorCode.Value = "CH"
                Case "OTHER"
                    .ClaimFilingIndicatorCode.Value = "CI"
                Case Else
                    .ClaimFilingIndicatorCode.Value = "CI"
            End Select
        End With

        ''''''''' Discussion Needed
        'Required if the subscriber is the same person as the patient (Loop ID- 
        '2000B SBR02=18), and information in this PAT segment (date of   
        'death, and/or patient weight) is necessary to file the claim/encounter
        '(see PAT05, 06, 07, and 08).

        '' '' ''If (pHCFADB.PatientRelationshipToInsured <> "SELF") Then
        '' '' ''    With l2000B.PAT

        '' '' ''    End With
        '' '' ''End If
        ''''''''' Discussion Needed


        '******************** Start 2010BA Subscriber
        If (lPrimaryInsuraneSelf) Then ''''''''''MAIN IF
            ''''''''' If Patient is Subscriber Fisrst Block'''''''''''''''
            With l2000B.L2010BA_837PRO1.NM1
                .EntityIdentifierCode1.Value = "IL"
                .EntityTypeQualifier.Value = "1"
                .NameLastOrOrganizationName.Value = lPatient.Patient.LastName  '"Benjamin"
                .NameFirst.Value = lPatient.Patient.FirstName  '"Melva"
                .NameMiddle.Value = lPatient.Patient.MiddleName  '"K"
                .NamePrefix.Value = ""
                .NameSuffix.Value = ""
                .IdentificationCodeQualifier.Value = "MI"
                .IdentificationCode.Value = lPatient.Patient.PrimaryInsurance.SubscriberID 'pHCFADB.InsuredIDNumber '"488129918D"
                .EntityRelationshipCode.Value = ""
                .EntityIdentifierCode2.Value = ""
            End With

            With l2000B.L2010BA_837PRO1.N3
                .AddressInformation1.Value = lPatient.Patient.AddressLine1  '"74551 Columbian Drive"
                .AddressInformation2.Value = lPatient.Patient.AddressLine2  '"74551 Columbian Drive"
            End With

            With l2000B.L2010BA_837PRO1.N4
                If (lPatient.Patient.City = "") Then
                    .CityName.Value = "Palm Desert"
                Else
                    .CityName.Value = lPatient.Patient.City   '"Palm Desert"
                End If
                .StateOrProvinceCode.Value = lPatient.Patient.IsDeleted  '"CA"
                .PostalCode.Value = lPatient.Patient.ZipCode  '"92260"
                .CountryCode.Value = ""
                .LocationQualifier.Value = ""
                .LocationIdentifier.Value = ""
            End With

            With l2000B.L2010BA_837PRO1.DMG
                .DateTimePeriodFormatQualifier.Value = "D8"
                .DateTimePeriod.Value = Convert.ToDateTime(lPatient.Patient.DOB).ToString("yyyyMMdd") '"19240131"
                .GenderCode.Value = lPatient.Patient.Gender.Substring(0, 1)
                .MaritalStatusCode.Value = ""
                .RaceOrEthnicityCode.Value = ""
                .CitizenshipStatusCode.Value = ""
                .CountryCode.Value = ""
                .BasisOfVerificationCode.Value = ""
                '.Quantity.
            End With
            ''''''''' If first Block'''''''''''''''
        Else '''''''''''''Main IF
            ''''''''' If Patient is Not Subscriber Second Block'''''''''''''''
            With l2000B.L2010BA_837PRO1.NM1
                .EntityIdentifierCode1.Value = "IL"
                .EntityTypeQualifier.Value = "1"
                .NameLastOrOrganizationName.Value = lPrimaryInsurerPatient.Patient.LastName  ''"Benjamin"
                .NameFirst.Value = lPrimaryInsurerPatient.Patient.FirstName  '"Melva"
                .NameMiddle.Value = lPrimaryInsurerPatient.Patient.MiddleName  '"K"
                .NamePrefix.Value = ""
                .NameSuffix.Value = ""
                .IdentificationCodeQualifier.Value = "MI"
                .IdentificationCode.Value = lPrimaryInsurerPatient.Patient.PrimaryInsurance.SubscriberID ''"488129918D"
                .EntityRelationshipCode.Value = ""
                .EntityIdentifierCode2.Value = ""
            End With

            With l2000B.L2010BA_837PRO1.N3
                .AddressInformation1.Value = lPrimaryInsurerPatient.Patient.AddressLine1  '"74551 Columbian Drive"
                .AddressInformation2.Value = lPrimaryInsurerPatient.Patient.AddressLine2
            End With

            With l2000B.L2010BA_837PRO1.N4
                If (lPrimaryInsurerPatient.Patient.City = "") Then
                    .CityName.Value = "Palm Desert"
                Else
                    .CityName.Value = lPrimaryInsurerPatient.Patient.City  '"Palm Desert"
                End If
                .StateOrProvinceCode.Value = lPrimaryInsurerPatient.Patient.IsDeleted  '"CA"
                .PostalCode.Value = lPrimaryInsurerPatient.Patient.ZipCode  '"92260"
                .CountryCode.Value = ""
                .LocationQualifier.Value = ""
                .LocationIdentifier.Value = ""
            End With

            ''''''''' If first Block'''''''''''''''
        End If
        '******************** End 2010BA Subscriber


        '******************** Start Payer Name 2010BB 
        With l2000B.L2010BB_837PRO.NM1
            .EntityIdentifierCode1.Value = "PR"
            .EntityTypeQualifier.Value = "2"

            If (lPrimaryInsuranceCompany.InsuranceDB.CompanyName.Length > 35) Then
                .NameLastOrOrganizationName.Value = lPrimaryInsuranceCompany.InsuranceDB.CompanyName.Substring(0, 34) '"MEDICARE"
            Else
                .NameLastOrOrganizationName.Value = lPrimaryInsuranceCompany.InsuranceDB.CompanyName '"MEDICARE"
            End If

            .NameFirst.Value = ""
            .NameMiddle.Value = ""
            .NamePrefix.Value = ""
            .NameSuffix.Value = ""
            .IdentificationCodeQualifier.Value = "PI"
            .IdentificationCode.Value = lPrimaryInsuranceCompany.InsuranceDB.PayerID.PadLeft(5, "0") '"CMSEL"
            .EntityRelationshipCode.Value = ""
            .EntityIdentifierCode2.Value = ""
        End With

        With l2000B.L2010BB_837PRO.N3
            .AddressInformation1.Value = lPrimaryInsuranceCompany.InsuranceDB.AddressLine1 '"PO Box 272852"
            .AddressInformation2.Value = lPrimaryInsuranceCompany.InsuranceDB.AddressLine2 '""
        End With

        With l2000B.L2010BB_837PRO.N4
            If (lPrimaryInsuranceCompany.InsuranceDB.City <> "") Then
                .CityName.Value = lPrimaryInsuranceCompany.InsuranceDB.City
            Else
                .CityName.Value = "Chico"
            End If
            .StateOrProvinceCode.Value = lPrimaryInsuranceCompany.InsuranceDB.State '"CA"
            .PostalCode.Value = lPrimaryInsuranceCompany.InsuranceDB.ZipCode '"95927"
            .CountryCode.Value = ""
            .LocationQualifier.Value = ""
            .LocationIdentifier.Value = ""
        End With
        '******************** Start Payer Name 2010BB 
        '******************** END  Loop 2000B 

        If (lPrimaryInsuraneSelf) Then
            Dim l2300 As ClaimLibrary.Grp837_PROL2300_837PRO1
            l2300 = l2000B.L2300_837PRO1.Append
            'BuildClaim2300(l2000B.L2300_837PRO1.Append, pUser, pHCFADB, pPatientCPTCol, lReferringProvider, True)
            BuildClaim2300(l2300, pUser, pHCFADB, pPatientCPTCol, lReferringProvider, lRenderingProvider, lClinic, lPatient, lSecondaryInsurerPatient, lSecondaryInsuranceCompany, lSecondaryInsuranceExist, lSecondaryInsuraneSelf, lFacility, lBillingProvider)
        Else
            '******************** Start Patient Hierarchical Level 2000C 
            Dim l2000C As Grp837_PROL2000C_837PRO
            l2000C = l2000B.L2000C_837PRO.Append()

            With l2000C.HL_3
                .HierarchicalIdNumber.Value = "3"
                .HierarchicalParentIdNumber.Value = "2"
                .HierarchicalLevelCode.Value = "23"
                .HierarchicalChildCode.Value = "0"
            End With

            With l2000C.PAT
                Select Case pHCFADB.PatientRelationshipToInsured
                    Case "Spouse"
                        .IndividualRelationshipCode.Value = "01"
                    Case "Child"
                        .IndividualRelationshipCode.Value = "19"
                    Case "Other"
                        .IndividualRelationshipCode.Value = "G8"
                End Select
                '.PatientLocationCode = ""
                '.EmploymentStatusCode = ""
                '.StudentStatusCode = ""
                '.DateTimePeriodFormatQualifier = ""
                '.DateTimePeriod = ""
                '.UnitOrBasisForMeasurementCode = ""
                '.Weight = ""
                '.YesNoConditionOrResponseCode = ""
            End With

            With l2000C.L2010CA_837PRO.NM1
                .EntityIdentifierCode1.Value = "QC"
                .EntityTypeQualifier.Value = "1"
                .NameLastOrOrganizationName.Value = lPatient.Patient.LastName  '"Benjamin"
                .NameFirst.Value = lPatient.Patient.FirstName  '"Melva"
                .NameMiddle.Value = lPatient.Patient.MiddleName  '"K"
                .NamePrefix.Value = ""
                .NameSuffix.Value = ""
                '.IdentificationCodeQualifier.Value = "MI"
                '.IdentificationCode.Value = pHCFADB.InsuredIDNumber '"488129918D"
                '.EntityRelationshipCode.Value = ""
                '.EntityIdentifierCode2.Value = ""
            End With

            With l2000C.L2010CA_837PRO.N3
                .AddressInformation1.Value = lPatient.Patient.AddressLine1  '"74551 Columbian Drive"
                .AddressInformation2.Value = lPatient.Patient.AddressLine2  '"74551 Columbian Drive"
            End With

            With l2000C.L2010CA_837PRO.N4
                If (lPatient.Patient.City = "") Then
                    .CityName.Value = "Palm Desert"
                Else
                    .CityName.Value = lPatient.Patient.City   '"Palm Desert"
                End If
                .StateOrProvinceCode.Value = lPatient.Patient.IsDeleted  '"CA"
                .PostalCode.Value = lPatient.Patient.ZipCode  '"92260"
                .CountryCode.Value = ""
                .LocationQualifier.Value = ""
                .LocationIdentifier.Value = ""
            End With

            With l2000C.L2010CA_837PRO.DMG
                .DateTimePeriodFormatQualifier.Value = "D8"
                .DateTimePeriod.Value = Convert.ToDateTime(lPatient.Patient.DOB).ToString("yyyyMMdd") '"19240131"
                .GenderCode.Value = lPatient.Patient.Gender.Substring(0, 1)
                .MaritalStatusCode.Value = ""
                .RaceOrEthnicityCode.Value = ""
                .CitizenshipStatusCode.Value = ""
                .CountryCode.Value = ""
                .BasisOfVerificationCode.Value = ""
                '.Quantity.
            End With

            '' '' ''lRef = l2000C.L2010CA_837PRO.REF1.Append
            '' '' ''With lRef
            '' '' ''    .ReferenceIdentification = ""
            '' '' ''    .ReferenceIdentificationQualifier = ""
            '' '' ''End With
            '******************** END Patient Hierarchical Level 2000C 
            Dim l2300 As ClaimLibrary.Grp837_PROL2300_837PRO2
            l2300 = l2000C.L2300_837PRO2.Append
            BuildClaim2300(l2300, pUser, pHCFADB, pPatientCPTCol, lReferringProvider, lRenderingProvider, lClinic, lPatient, lSecondaryInsurerPatient, lSecondaryInsuranceCompany, lSecondaryInsuranceExist, lSecondaryInsuraneSelf, lFacility, lBillingProvider)
        End If




        ''''''''' clm 2300 start

        ''''''''' clm 2300 start

        lClaimId = "CL" & pUser.ClinicId & "H" & Convert.ToDateTime(pHCFADB.HCFAPreparedDate).Year & Convert.ToDateTime(pHCFADB.HCFAPreparedDate).ToString("MM") & pHCFADB.HCFADisplayID.PadLeft(5, "0")
        Dim lMessage As String = lInterChange.Parse()
        Dim lFilePath As String = SaveToFile(lMessage, lClaimId & ".txt")
        Return lFilePath



    End Function

    'Public Shared Function Make837RequestUpdated(ByRef pUser As User, ByRef pHCFADB As HCFADBUpdated, ByRef pPatientCPTCol As PatientCPTColl) As String
    '    Dim lPrimaryInsuraneSelf As Boolean = False
    '    Dim lSecondaryInsuraneSelf As Boolean = False
    '    Dim lPrimaryInsuranceExist As Boolean = False
    '    Dim lSecondaryInsuranceExist As Boolean = False
    '    Dim lPrimaryInsuranceCompanyId As Int32 = 0
    '    Dim lSecondaryInsuranceCompanyId As Int32 = 0
    '    Dim lPatient As New PatientExtended(pUser.ConnectionString)
    '    lPatient.Patient.PatientID = pHCFADB.Patient.PatientID
    '    lPatient.GetPatientWithDetailsByID()
    '    Dim lPrimaryInsurerPatient As New PatientExtended(pUser.ConnectionString)
    '    Dim lPrimaryInsuranceCompany As New Insurance(pUser.ConnectionString)
    '    Dim lSecondaryInsurerPatient As New PatientExtended(pUser.ConnectionString)
    '    Dim lSecondaryInsuranceCompany As New Insurance(pUser.ConnectionString)
    '    Dim lClaimId As String = ""
    '    Dim lBillingProvider As BillingProvider


    '    '''''''''''''' Primary Insurance And Insurer Checking Logic
    '    If (lPatient.Patient.PrimaryInsurance.Active = "Y" And (lPatient.Patient.PrimaryInsurance.InsuranceCompanyID <> 0 Or lPatient.Patient.PrimaryInsurance.InsurerId <> 0)) Then
    '        lPrimaryInsuranceExist = True
    '        If (lPatient.Patient.PrimaryInsurance.InsurerId <> 0) Then
    '            lPrimaryInsuraneSelf = False
    '            lPrimaryInsurerPatient.Patient.PatientID = lPatient.Patient.PrimaryInsurance.InsurerId
    '            lPrimaryInsurerPatient.GetPatientWithDetailsByID()

    '        Else
    '            lPrimaryInsuraneSelf = True
    '        End If
    '    Else
    '        lPrimaryInsuranceExist = False
    '    End If
    '    '''''''''''''' Primary Insurance And Insurer Checking Logic

    '    '''''''''''''' Secondary Insurance And Insurer Checking Logic
    '    If (lPatient.Patient.SecondaryInsurance.Active = "Y" And (lPatient.Patient.SecondaryInsurance.InsuranceCompanyID <> 0 Or lPatient.Patient.SecondaryInsurance.InsurerId <> 0)) Then
    '        lSecondaryInsuranceExist = True
    '        If (lPatient.Patient.SecondaryInsurance.InsurerId <> 0) Then
    '            lSecondaryInsuraneSelf = False
    '            lSecondaryInsurerPatient.Patient.PatientID = lPatient.Patient.SecondaryInsurance.InsurerId
    '            lSecondaryInsurerPatient.GetPatientWithDetailsByID()
    '            'lSecondaryInsuranceCompany.InsuranceDB.FavouriteInsuranceID = lSecondaryInsurerPatient.Patient.SecondaryInsurance.InsuranceCompanyID
    '            'lSecondaryInsuranceCompany.GetRecordById()
    '        Else
    '            lSecondaryInsuraneSelf = True
    '        End If
    '    Else
    '        lSecondaryInsuranceExist = False
    '    End If
    '    '''''''''''''' Secondary Insurance And Insurer Checking Logic

    '    Dim lConnection As New Connection(pUser.ConnectionString)

    '    Dim lQuery As String

    '    If (lPrimaryInsuranceExist) Then
    '        If (lPrimaryInsuraneSelf) Then
    '            lPrimaryInsuranceCompanyId = lPatient.Patient.PrimaryInsurance.InsuranceCompanyID
    '        Else
    '            lPrimaryInsuranceCompanyId = lPrimaryInsurerPatient.Patient.PrimaryInsurance.InsuranceCompanyID
    '        End If
    '    Else
    '        lPrimaryInsuranceCompanyId = 0
    '    End If

    '    If (lSecondaryInsuranceExist) Then
    '        If (lSecondaryInsuraneSelf) Then
    '            lSecondaryInsuranceCompanyId = lPatient.Patient.SecondaryInsurance.InsuranceCompanyID
    '        Else
    '            lSecondaryInsuranceCompanyId = lSecondaryInsurerPatient.Patient.SecondaryInsurance.InsuranceCompanyID
    '        End If
    '    Else
    '        lSecondaryInsuranceCompanyId = 0
    '    End If


    '    'CreateUserId=DocUserId
    '    lQuery = "Exec GetMultipleTableForClaimEDI " & pUser.ClinicId & "," & IIf(pHCFADB.ReferencePvd.ProviderID <> "", pHCFADB.ReferencePvd.ProviderID, 0) & "," & pHCFADB.CreateByUserID & "," & lPrimaryInsuranceCompanyId & "," & lSecondaryInsuranceCompanyId & "," & pHCFADB.ServiceFacility.FacilityID


    '    Dim lDs As New DataSet
    '    lDs = lConnection.ExecuteQuery(lQuery)

    '    Dim lClinic As New Clinic(pUser.ConnectionString)
    '    lClinic.Clinic.ClinicId = pUser.ClinicId
    '    lClinic.GetRecordByID(lDs.Tables(0))

    '    Dim lReferringProvider As New ReferringProvider(pUser.ConnectionString)
    '    'lReferringProvider.ReferringProviderDB.ProviderID = pHCFADB.DoctorUserID
    '    lReferringProvider.GetRecordByID(lDs.Tables(1))

    '    Dim lRenderingProvider As New Employee(pUser.ConnectionString)
    '    'lRenderingProvider.Employee.EmployeeID = pHCFADB.DoctorUserID
    '    lRenderingProvider.GetRecordByID(lDs.Tables(2))

    '    If (lPrimaryInsuranceExist) Then
    '        lPrimaryInsuranceCompany.GetRecordById(lDs.Tables(3))
    '    End If

    '    If (lSecondaryInsuranceExist) Then
    '        lSecondaryInsuranceCompany.GetRecordById(lDs.Tables(4))
    '    End If

    '    Dim lFacility As New Facility(pUser.ConnectionString)
    '    If (Not lDs.Tables(5) Is Nothing) Then
    '        lFacility.GetRecordById(lDs.Tables(5))
    '    End If



    '    Dim lInterChange As New ClaimLibrary.MsgInterchange()
    '    Dim lGs As ClaimLibrary.GrpInterchangeFunctionalGroup
    '    Dim lTransaction As ClaimLibrary.Msg837_PRO




    '    With lInterChange.ISA
    '        .AuthorizationInformationQualifier.Value = "00"
    '        .AuthorizationInformation.Value = "123456789"
    '        .SecurityInformationQualifier.Value = "00"
    '        .SecurityInformation.Value = "123456789"
    '        .InterchangeIDQualifier1.Value = "ZZ"
    '        .InterchangeSenderID.Value = "12345678987654"
    '        .InterchangeIDQualifier2.Value = "ZZ"
    '        .InterchangeReceiverID.Value = "12345678987654"
    '        .InterchangeDate.Value = Date.Now.ToString("yyyyMMdd")
    '        .InterchangeTime.Value = Date.Now.ToString("HHmm")
    '        .InterchangeControlStandardsIdentifier.Value = "U"
    '        .InterchangeControlVersionNumber.Value = "00401"
    '        .InterchangeControlNumber.Value = "000000001"
    '        .AcknowledgmentRequested.Value = "1"
    '        .UsageIndicator.Value = "P"
    '        .ComponentElementSeparator.Value = ":"

    '        lGs = lInterChange.FunctionalGroup.Append()


    '    End With

    '    With lGs.GS
    '        .FunctionalIdentifierCode.Value = "HC"
    '        .ApplicationSendersCode.Value = "123456789"
    '        .ApplicationReceiversCode.Value = "987654321"
    '        .Date.Value = Date.Now.ToString("yyyyMMdd")
    '        .Time.Value = Date.Now.ToString("HHmm")
    '        .GroupControlNumber.Value = "123"
    '        .ResponsibleAgencyCode.Value = "X"
    '        .VersionReleaseIndustryIdentifierCode.Value = "004010X098A1"


    '    End With

    '    lTransaction = lGs.Transactions.Append("837_PRO")

    '    With lTransaction.ST
    '        .TransactionSetIdentifierCode.Value = "837"
    '        .TransactionSetControlNumber.Value = "000000001"
    '    End With

    '    With lTransaction.BHT
    '        .HierarchicalStructureCode.Value = "0019"
    '        .TransactionSetPurposeCode.Value = "00"
    '        .ReferenceIdentification.Value = "0123"
    '        .Date.Value = Date.Now.ToString("yyyyMMdd")
    '        .Time.Value = Date.Now.ToString("HHmm")
    '        .TransactionTypeCode.Value = "CH"
    '    End With

    '    With lTransaction.REF
    '        .ReferenceIdentificationQualifier.Value = "87"
    '        .ReferenceIdentification.Value = "004010X098A1"
    '    End With


    '    ''''''' Sender''''''''''''''''''
    '    With lTransaction.L1000A_837PRO.NM1
    '        .EntityIdentifierCode1.Value = "41"
    '        .EntityTypeQualifier.Value = "2"
    '        .NameLastOrOrganizationName.Value = "OA Systems"
    '        .NameFirst.Value = ""
    '        .NameMiddle.Value = ""
    '        .NamePrefix.Value = ""
    '        .NameSuffix.Value = ""
    '        .IdentificationCodeQualifier.Value = "46"
    '        .IdentificationCode.Value = "XOA00205"
    '        .EntityRelationshipCode.Value = ""
    '        .EntityIdentifierCode2.Value = ""
    '    End With

    '    Dim lPer As ClaimLibrary.SegPER
    '    lPer = lTransaction.L1000A_837PRO.PER.Append()



    '    With lPer
    '        .ContactFunctionCode.Value = "IC"
    '        .ContactName.Value = "Salman Ali"
    '        .CommunicationNumberQualifier1.Value = "TE"
    '        .CommunicationNumber1.Value = lClinic.Clinic.Phone1 '"XOA00205"
    '        .CommunicationNumberQualifier2.Value = ""
    '        .CommunicationNumber2.Value = ""
    '        .CommunicationNumberQualifier3.Value = ""
    '        .CommunicationNumber3.Value = ""
    '        .ContactInquiryReference.Value = ""
    '    End With

    '    ''''''''''''' Sender'''''''''''''''''

    '    ''''''''''''' receiver'''''''''''''''''
    '    With lTransaction.L1000B_837PRO.NM1
    '        .EntityIdentifierCode1.Value = "40"
    '        .EntityTypeQualifier.Value = "2"
    '        .NameLastOrOrganizationName.Value = "Electronic Network Systems, Inc."
    '        .NameFirst.Value = ""
    '        .NameMiddle.Value = ""
    '        .NamePrefix.Value = ""
    '        .NameSuffix.Value = ""
    '        .IdentificationCodeQualifier.Value = "46"
    '        .IdentificationCode.Value = "841162764"
    '        .EntityRelationshipCode.Value = ""
    '        .EntityIdentifierCode2.Value = ""
    '    End With
    '    ''''''''''''' Receiver'''''''''''''''''

    '    '''''''''''''''' 2000A Billing Provider Starts''''''''''
    '    Dim l2000A As Grp837_PROL2000A_837PRO
    '    l2000A = lTransaction.L2000A_837PRO.Append()

    '    With l2000A.HL_1
    '        .HierarchicalIdNumber.Value = "1"
    '        .HierarchicalParentIdNumber.Value = ""
    '        .HierarchicalLevelCode.Value = "20"
    '        'If (lPrimaryInsuraneSelf) Then
    '        .HierarchicalChildCode.Value = "1"
    '        ' Else
    '        '.HierarchicalChildCode.Value = "2"
    '        'End If
    '    End With

    '    With l2000A.L2010AA_837PRO1.NM1
    '        .EntityIdentifierCode1.Value = "85"
    '        .EntityTypeQualifier.Value = "1"
    '        .NameLastOrOrganizationName.Value = lClinic.Clinic.ClinicName '"Palm Desert Urgent Care"
    '        .NameFirst.Value = "Uzma"
    '        .NameMiddle.Value = "Ali"
    '        .NamePrefix.Value = ""
    '        .NameSuffix.Value = ""
    '        .IdentificationCodeQualifier.Value = "XX"
    '        '****
    '        .IdentificationCode.Value = pHCFADB.ServiceFacility.NPI  ''lClinic.Clinic.NPI    '"1003849621"
    '        '*******
    '        .EntityRelationshipCode.Value = ""
    '        .EntityIdentifierCode2.Value = ""
    '    End With

    '    With l2000A.L2010AA_837PRO1.N3
    '        .AddressInformation1.Value = lClinic.Clinic.AddressLine1  '"PO Box 1118"
    '        .AddressInformation2.Value = lClinic.Clinic.AddressLine2
    '    End With

    '    With l2000A.L2010AA_837PRO1.N4
    '        .CityName.Value = lClinic.Clinic.City  '"Palm Desert"
    '        .StateOrProvinceCode.Value = lClinic.Clinic.StateId
    '        .PostalCode.Value = lClinic.Clinic.ZipCode  '"92260"
    '        .CountryCode.Value = ""
    '        .LocationQualifier.Value = ""
    '        .LocationIdentifier.Value = ""
    '    End With

    '    Dim lRef As SegREF

    '    If (lClinic.Clinic.FacilityCode <> "") Then
    '        lRef = l2000A.L2010AA_837PRO1.REF1.Append
    '        With lRef
    '            'pHCFADB.ClinicSecondaryIdentificationQualifier <> ""
    '            If (pHCFADB.MainPatientInsurance.GroupNo <> "") Then
    '                .ReferenceIdentificationQualifier.Value = "" ' pHCFADB.ClinicSecondaryIdentificationQualifier
    '                '***
    '                .ReferenceIdentification.Value = pHCFADB.MainPatientInsurance.GroupNo
    '                '***
    '                .Description.Value = ""
    '            Else
    '                .ReferenceIdentificationQualifier.Value = "EI"
    '                .ReferenceIdentification.Value = "330866905" 'lClinic.Clinic.FacilityCode '
    '                .Description.Value = ""
    '            End If

    '        End With
    '    End If
    '    '************************ 2000A Billing Provider End 

    '    '************************ 2000B Subscriber Starts 

    '    Dim l2000B As Grp837_PROL2000B_837PRO
    '    l2000B = l2000A.L2000B_837PRO.Append()


    '    With l2000B.HL_5
    '        .HierarchicalIdNumber.Value = "2"
    '        .HierarchicalParentIdNumber.Value = "1"
    '        .HierarchicalLevelCode.Value = "22"
    '        If (lPrimaryInsuraneSelf) Then
    '            .HierarchicalChildCode.Value = "0"
    '        Else
    '            .HierarchicalChildCode.Value = "1"
    '        End If

    '    End With


    '    With l2000B.SBR
    '        .PayerResponsibilitySequenceNumberCode.Value = "P"
    '        If (lPrimaryInsuraneSelf) Then
    '            .IndividualRelationshipCode.Value = "18"
    '        Else
    '            .IndividualRelationshipCode.Value = ""
    '        End If
    '        'lPatient.Patient.PrimaryInsurance.RelationshipToPrimaryInsurer
    '        '    Case "Self"
    '        '.IndividualRelationshipCode.Value = "18"
    '        '    Case "Souse"
    '        '.IndividualRelationshipCode.Value = "01"
    '        '    Case "Child"
    '        '.IndividualRelationshipCode.Value = "19"
    '        '    Case "Other"
    '        '.IndividualRelationshipCode.Value = "G8"
    '        'End Select
    '        .ReferenceIdentification.Value = pHCFADB.ReferencePvd.ProviderID 'AnotherInsuredPolicy '""
    '        .SubscriberName.Value = pHCFADB.MainPatientInsurance.SubscriberID '.AnotherInsuredInsurancePlan '""

    '        If (.PayerResponsibilitySequenceNumberCode.Value <> "P" And pHCFADB.MainPatientInsurance.Type = "MEDICARE") Then
    '            .InsuranceTypeCode.Value = "" 'type of insurance policy within specified program
    '        Else
    '            .InsuranceTypeCode.Value = ""
    '        End If
    '        .CoordinationOfBenefitsCode.Value = ""
    '        .YesNoConditionOrResponseCode.Value = ""
    '        .EmploymentStatusCode.Value = ""
    '        Select Case pHCFADB.MainPatientInsurance.Type.ToUpper
    '            Case "MEDICARE"
    '                .ClaimFilingIndicatorCode.Value = "MB"
    '            Case "MEDICAID"
    '                .ClaimFilingIndicatorCode.Value = "MC"
    '            Case "CHAMPUS"
    '                .ClaimFilingIndicatorCode.Value = "CH"
    '            Case "OTHER"
    '                .ClaimFilingIndicatorCode.Value = "CI"
    '            Case Else
    '                .ClaimFilingIndicatorCode.Value = "CI"
    '        End Select
    '    End With

    '    ''''''''' Discussion Needed
    '    'Required if the subscriber is the same person as the patient (Loop ID- 
    '    '2000B SBR02=18), and information in this PAT segment (date of   
    '    'death, and/or patient weight) is necessary to file the claim/encounter
    '    '(see PAT05, 06, 07, and 08).

    '    '' '' ''If (pHCFADB.PatientRelationshipToInsured <> "SELF") Then
    '    '' '' ''    With l2000B.PAT

    '    '' '' ''    End With
    '    '' '' ''End If
    '    ''''''''' Discussion Needed


    '    '******************** Start 2010BA Subscriber
    '    If (lPrimaryInsuraneSelf) Then ''''''''''MAIN IF
    '        ''''''''' If Patient is Subscriber Fisrst Block'''''''''''''''
    '        With l2000B.L2010BA_837PRO1.NM1
    '            .EntityIdentifierCode1.Value = "IL"
    '            .EntityTypeQualifier.Value = "1"
    '            .NameLastOrOrganizationName.Value = lPatient.Patient.LastName  '"Benjamin"
    '            .NameFirst.Value = lPatient.Patient.FirstName  '"Melva"
    '            .NameMiddle.Value = lPatient.Patient.MiddleName  '"K"
    '            .NamePrefix.Value = ""
    '            .NameSuffix.Value = ""
    '            .IdentificationCodeQualifier.Value = "MI"
    '            .IdentificationCode.Value = lPatient.Patient.PrimaryInsurance.SubscriberID 'pHCFADB.InsuredIDNumber '"488129918D"
    '            .EntityRelationshipCode.Value = ""
    '            .EntityIdentifierCode2.Value = ""
    '        End With

    '        With l2000B.L2010BA_837PRO1.N3
    '            .AddressInformation1.Value = lPatient.Patient.AddressLine1  '"74551 Columbian Drive"
    '            .AddressInformation2.Value = lPatient.Patient.AddressLine2  '"74551 Columbian Drive"
    '        End With

    '        With l2000B.L2010BA_837PRO1.N4
    '            If (lPatient.Patient.City = "") Then
    '                .CityName.Value = "Palm Desert"
    '            Else
    '                .CityName.Value = lPatient.Patient.City   '"Palm Desert"
    '            End If
    '            .StateOrProvinceCode.Value = lPatient.Patient.IsDeleted  '"CA"
    '            .PostalCode.Value = lPatient.Patient.ZipCode  '"92260"
    '            .CountryCode.Value = ""
    '            .LocationQualifier.Value = ""
    '            .LocationIdentifier.Value = ""
    '        End With

    '        With l2000B.L2010BA_837PRO1.DMG
    '            .DateTimePeriodFormatQualifier.Value = "D8"
    '            .DateTimePeriod.Value = Convert.ToDateTime(lPatient.Patient.DOB).ToString("yyyyMMdd") '"19240131"
    '            .GenderCode.Value = lPatient.Patient.Gender.Substring(0, 1)
    '            .MaritalStatusCode.Value = ""
    '            .RaceOrEthnicityCode.Value = ""
    '            .CitizenshipStatusCode.Value = ""
    '            .CountryCode.Value = ""
    '            .BasisOfVerificationCode.Value = ""
    '            '.Quantity.
    '        End With
    '        ''''''''' If first Block'''''''''''''''
    '    Else '''''''''''''Main IF
    '        ''''''''' If Patient is Not Subscriber Second Block'''''''''''''''
    '        With l2000B.L2010BA_837PRO1.NM1
    '            .EntityIdentifierCode1.Value = "IL"
    '            .EntityTypeQualifier.Value = "1"
    '            .NameLastOrOrganizationName.Value = lPrimaryInsurerPatient.Patient.LastName  ''"Benjamin"
    '            .NameFirst.Value = lPrimaryInsurerPatient.Patient.FirstName  '"Melva"
    '            .NameMiddle.Value = lPrimaryInsurerPatient.Patient.MiddleName  '"K"
    '            .NamePrefix.Value = ""
    '            .NameSuffix.Value = ""
    '            .IdentificationCodeQualifier.Value = "MI"
    '            .IdentificationCode.Value = lPrimaryInsurerPatient.Patient.PrimaryInsurance.SubscriberID ''"488129918D"
    '            .EntityRelationshipCode.Value = ""
    '            .EntityIdentifierCode2.Value = ""
    '        End With

    '        With l2000B.L2010BA_837PRO1.N3
    '            .AddressInformation1.Value = lPrimaryInsurerPatient.Patient.AddressLine1  '"74551 Columbian Drive"
    '            .AddressInformation2.Value = lPrimaryInsurerPatient.Patient.AddressLine2
    '        End With

    '        With l2000B.L2010BA_837PRO1.N4
    '            If (lPrimaryInsurerPatient.Patient.City = "") Then
    '                .CityName.Value = "Palm Desert"
    '            Else
    '                .CityName.Value = lPrimaryInsurerPatient.Patient.City  '"Palm Desert"
    '            End If
    '            .StateOrProvinceCode.Value = lPrimaryInsurerPatient.Patient.IsDeleted  '"CA"
    '            .PostalCode.Value = lPrimaryInsurerPatient.Patient.ZipCode  '"92260"
    '            .CountryCode.Value = ""
    '            .LocationQualifier.Value = ""
    '            .LocationIdentifier.Value = ""
    '        End With

    '        ''''''''' If first Block'''''''''''''''
    '    End If
    '    '******************** End 2010BA Subscriber


    '    '******************** Start Payer Name 2010BB 
    '    With l2000B.L2010BB_837PRO.NM1
    '        .EntityIdentifierCode1.Value = "PR"
    '        .EntityTypeQualifier.Value = "2"

    '        If (lPrimaryInsuranceCompany.InsuranceDB.CompanyName.Length > 35) Then
    '            .NameLastOrOrganizationName.Value = lPrimaryInsuranceCompany.InsuranceDB.CompanyName.Substring(0, 34) '"MEDICARE"
    '        Else
    '            .NameLastOrOrganizationName.Value = lPrimaryInsuranceCompany.InsuranceDB.CompanyName '"MEDICARE"
    '        End If

    '        .NameFirst.Value = ""
    '        .NameMiddle.Value = ""
    '        .NamePrefix.Value = ""
    '        .NameSuffix.Value = ""
    '        .IdentificationCodeQualifier.Value = "PI"
    '        .IdentificationCode.Value = lPrimaryInsuranceCompany.InsuranceDB.PayerID.PadLeft(5, "0") '"CMSEL"
    '        .EntityRelationshipCode.Value = ""
    '        .EntityIdentifierCode2.Value = ""
    '    End With

    '    With l2000B.L2010BB_837PRO.N3
    '        .AddressInformation1.Value = lPrimaryInsuranceCompany.InsuranceDB.AddressLine1 '"PO Box 272852"
    '        .AddressInformation2.Value = lPrimaryInsuranceCompany.InsuranceDB.AddressLine2 '""
    '    End With

    '    With l2000B.L2010BB_837PRO.N4
    '        If (lPrimaryInsuranceCompany.InsuranceDB.City <> "") Then
    '            .CityName.Value = lPrimaryInsuranceCompany.InsuranceDB.City
    '        Else
    '            .CityName.Value = "Chico"
    '        End If
    '        .StateOrProvinceCode.Value = lPrimaryInsuranceCompany.InsuranceDB.State '"CA"
    '        .PostalCode.Value = lPrimaryInsuranceCompany.InsuranceDB.ZipCode '"95927"
    '        .CountryCode.Value = ""
    '        .LocationQualifier.Value = ""
    '        .LocationIdentifier.Value = ""
    '    End With
    '    '******************** Start Payer Name 2010BB 
    '    '******************** END  Loop 2000B 

    '    If (lPrimaryInsuraneSelf) Then
    '        Dim l2300 As ClaimLibrary.Grp837_PROL2300_837PRO1
    '        l2300 = l2000B.L2300_837PRO1.Append
    '        'BuildClaim2300(l2000B.L2300_837PRO1.Append, pUser, pHCFADB, pPatientCPTCol, lReferringProvider, True)
    '        BuildClaim2300(l2300, pUser, pHCFADB, pPatientCPTCol, lReferringProvider, lRenderingProvider, lClinic, lPatient, lSecondaryInsurerPatient, lSecondaryInsuranceCompany, lSecondaryInsuranceExist, lSecondaryInsuraneSelf, lFacility, lBillingProvider)
    '    Else
    '        '******************** Start Patient Hierarchical Level 2000C 
    '        Dim l2000C As Grp837_PROL2000C_837PRO
    '        l2000C = l2000B.L2000C_837PRO.Append()

    '        With l2000C.HL_3
    '            .HierarchicalIdNumber.Value = "3"
    '            .HierarchicalParentIdNumber.Value = "2"
    '            .HierarchicalLevelCode.Value = "23"
    '            .HierarchicalChildCode.Value = "0"
    '        End With

    '        With l2000C.PAT
    '            Select Case pHCFADB.MainPatientInsurance.RelationshipToPrimaryInsurer
    '                Case "Spouse"
    '                    .IndividualRelationshipCode.Value = "01"
    '                Case "Child"
    '                    .IndividualRelationshipCode.Value = "19"
    '                Case "Other"
    '                    .IndividualRelationshipCode.Value = "G8"
    '            End Select
    '            '.PatientLocationCode = ""
    '            '.EmploymentStatusCode = ""
    '            '.StudentStatusCode = ""
    '            '.DateTimePeriodFormatQualifier = ""
    '            '.DateTimePeriod = ""
    '            '.UnitOrBasisForMeasurementCode = ""
    '            '.Weight = ""
    '            '.YesNoConditionOrResponseCode = ""
    '        End With

    '        With l2000C.L2010CA_837PRO.NM1
    '            .EntityIdentifierCode1.Value = "QC"
    '            .EntityTypeQualifier.Value = "1"
    '            .NameLastOrOrganizationName.Value = lPatient.Patient.LastName  '"Benjamin"
    '            .NameFirst.Value = lPatient.Patient.FirstName  '"Melva"
    '            .NameMiddle.Value = lPatient.Patient.MiddleName  '"K"
    '            .NamePrefix.Value = ""
    '            .NameSuffix.Value = ""
    '            '.IdentificationCodeQualifier.Value = "MI"
    '            '.IdentificationCode.Value = pHCFADB.InsuredIDNumber '"488129918D"
    '            '.EntityRelationshipCode.Value = ""
    '            '.EntityIdentifierCode2.Value = ""
    '        End With

    '        With l2000C.L2010CA_837PRO.N3
    '            .AddressInformation1.Value = lPatient.Patient.AddressLine1  '"74551 Columbian Drive"
    '            .AddressInformation2.Value = lPatient.Patient.AddressLine2  '"74551 Columbian Drive"
    '        End With

    '        With l2000C.L2010CA_837PRO.N4
    '            If (lPatient.Patient.City = "") Then
    '                .CityName.Value = "Palm Desert"
    '            Else
    '                .CityName.Value = lPatient.Patient.City   '"Palm Desert"
    '            End If
    '            .StateOrProvinceCode.Value = lPatient.Patient.IsDeleted  '"CA"
    '            .PostalCode.Value = lPatient.Patient.ZipCode  '"92260"
    '            .CountryCode.Value = ""
    '            .LocationQualifier.Value = ""
    '            .LocationIdentifier.Value = ""
    '        End With

    '        With l2000C.L2010CA_837PRO.DMG
    '            .DateTimePeriodFormatQualifier.Value = "D8"
    '            .DateTimePeriod.Value = Convert.ToDateTime(lPatient.Patient.DOB).ToString("yyyyMMdd") '"19240131"
    '            .GenderCode.Value = lPatient.Patient.Gender.Substring(0, 1)
    '            .MaritalStatusCode.Value = ""
    '            .RaceOrEthnicityCode.Value = ""
    '            .CitizenshipStatusCode.Value = ""
    '            .CountryCode.Value = ""
    '            .BasisOfVerificationCode.Value = ""
    '            '.Quantity.
    '        End With

    '        '' '' ''lRef = l2000C.L2010CA_837PRO.REF1.Append
    '        '' '' ''With lRef
    '        '' '' ''    .ReferenceIdentification = ""
    '        '' '' ''    .ReferenceIdentificationQualifier = ""
    '        '' '' ''End With
    '        '******************** END Patient Hierarchical Level 2000C 
    '        Dim l2300 As ClaimLibrary.Grp837_PROL2300_837PRO2
    '        l2300 = l2000C.L2300_837PRO2.Append
    '        BuildClaim2300(l2300, pUser, pHCFADB, pPatientCPTCol, lReferringProvider, lRenderingProvider, lClinic, lPatient, lSecondaryInsurerPatient, lSecondaryInsuranceCompany, lSecondaryInsuranceExist, lSecondaryInsuraneSelf, lFacility, lBillingProvider)
    '    End If




    '    ''''''''' clm 2300 start

    '    ''''''''' clm 2300 start

    '    lClaimId = "CL" & pUser.ClinicId & "H" & Convert.ToDateTime(pHCFADB.HCFAPreparedDate).Year & Convert.ToDateTime(pHCFADB.HCFAPreparedDate).ToString("MM") & pHCFADB.HCFADisplayID.PadLeft(5, "0")
    '    Dim lMessage As String = lInterChange.Parse()
    '    Dim lFilePath As String = SaveToFile(lMessage, lClaimId & ".txt")
    '    Return lFilePath



    'End Function


    Public Shared Sub BuildClaim2300(ByRef l2300 As Object, ByRef pUser As User, ByRef pHCFADB As HCFADB, ByRef pPatientCPTCol As PatientCPTColl, ByRef lReferringProvider As ReferringProvider, ByRef lRenderingProvider As Employee, ByRef lClinic As Clinic, ByRef lPatient As PatientExtended, ByRef lSecondaryInsurerPatient As PatientExtended, ByRef lSecondaryInsuranceCompany As Insurance, ByVal lSecondaryInsuranceExist As Boolean, ByVal lSecondaryInsuraneSelf As Boolean, ByRef lfacility As Facility, ByRef pBillingProvider As BillingProvider)
        Dim lRef As SegREF
        Dim lRenderringProvider As Employee = New Employee(pUser.ConnectionString)
        lRenderringProvider.Employee.EmployeeID = pHCFADB.DoctorUserID
        lRenderringProvider.GetRecordByID()
        ''Dim lPRV As SegPRV
        'Dim l2300 As ClaimLibrary.Grp837_PROL2300_837PRO2
        'Dim test1 As ClaimLibrary.Grp837_PROL2300_837PRO2
        'l2300 = CType(l2300, ClaimLibrary..Grp837_PROL2300_837PRO2)
        'If (pPrimarySelf) Then

        '    l2300 = CType(p2300, ClaimLibrary.Grp837_PROL2300_837PRO1)
        'Else
        '    l2300 = CType(l2300, ClaimLibrary.Grp837_PROL2300_837PRO2)
        'End If


        With l2300.CLM
            '.ClaimSubmittersIdentifier.Value = pHCFADB.HCFADisplayID.PadLeft(6, "0")
            .ClaimSubmittersIdentifier.Value = "CL" & pUser.ClinicId & "H" & Convert.ToDateTime(pHCFADB.HCFAPreparedDate).Year & Convert.ToDateTime(pHCFADB.HCFAPreparedDate).ToString("MM") & pHCFADB.HCFADisplayID.PadLeft(5, "0")
            .MonetaryAmount.Value = pHCFADB.TotalCharge
            .ClaimFillingIndicatorCode.Value = ""
            .NonInstitutionalClaimTypeCode.Value = ""

            .HealthCareServiceLocationInformation.FacilityCodeValue.Value = "11"
            .HealthCareServiceLocationInformation.FacilityCodeQualifier.Value = ""
            .HealthCareServiceLocationInformation.ClaimFrequencyTypeCode.Value = "1"

            .YesNoConditionOrResponseCode1.Value = "Y"
            .ProviderAcceptAssignmentCode.Value = "A"
            .YesNoConditionOrResponseCode2.Value = "Y"
            .ReleaseOfInformationCode.Value = "Y"
            .PatientSignatureSourceCode.Value = "B"

            'Block 10 a,b,c
            '.RelatedCausesInformation.RelatedCausesCode1.Value = ""
            '.RelatedCausesInformation.StateOrProvinceCode = ""
            '.SpecialProgramCode.Value = ""
            '.YesNoConditionOrResponseCode3.Value = ""
            '.LevelOfServiceCode.Value = ""
            '.YesNoConditionOrResponseCode4.Value = ""
            '.ProviderAgreementCode.Value = ""
            '.ClaimStatusCode.Value = ""
            '.YesNoConditionOrResponseCode5.Value = ""
            '.ClaimSubmissionReasonCode.Value = ""
            '.DelayReasonCode.Value = ""

        End With

        If (pHCFADB.ICD1 <> "") Then
            With l2300.HI.HealthCareCodeInformation1
                .CodeListQualifierCode.Value = "BK"
                .IndustryCode.Value = pHCFADB.ICD1
                'DateTimePeriodFormatQualifier()
                'DateTimePeriod()
                'MonetaryAmount()
                'Quantity()
                'VersionIdentifier()
            End With
        End If


        If (pHCFADB.ICD2 <> "") Then
            With l2300.HI.HealthCareCodeInformation2
                .CodeListQualifierCode.Value = "BF"
                .IndustryCode.Value = pHCFADB.ICD2
            End With
        End If

        If (pHCFADB.ICD3 <> "") Then
            With l2300.HI.HealthCareCodeInformation3
                .CodeListQualifierCode.Value = "BF"
                .IndustryCode.Value = pHCFADB.ICD3
            End With
        End If

        If (pHCFADB.ICD4 <> "") Then
            With l2300.HI.HealthCareCodeInformation4
                .CodeListQualifierCode.Value = "BF"
                .IndustryCode.Value = pHCFADB.ICD4
            End With
        End If



        ''***********Start REFERIING PROVIDER*****************''''''''''
        Dim l2310A As ClaimLibrary.Grp837_PROL2310A_837PRO
        If (Not IsDBNull(pHCFADB.RefferingProviderID) AndAlso pHCFADB.RefferingProviderID <> "0" AndAlso pHCFADB.RefferingProviderID <> "") Then
            l2310A = l2300.L2310A_837PRO.Append
            With l2310A.NM1
                .EntityIdentifierCode1.Value = "DN"
                .EntityTypeQualifier.Value = "1"
                .NameLastOrOrganizationName.Value = lReferringProvider.ReferringProviderDB.LastName  '."Kazi"
                .NameFirst.Value = lReferringProvider.ReferringProviderDB.FirstName   '"Manzoor"
                .NameMiddle.Value = lReferringProvider.ReferringProviderDB.MiddleName '"A"
                .NamePrefix.Value = ""
                .NameSuffix.Value = ""
                .IdentificationCodeQualifier.Value = "XX"
                .IdentificationCode.Value = lReferringProvider.ReferringProviderDB.NPI  '"1225032212"
                .EntityRelationshipCode.Value = ""
                .EntityIdentifierCode2.Value = ""
            End With


            With l2310A.PRV
                .ProviderCode.Value = "RF"
                .ReferenceIdentificationQualifier.Value = "ZZ"
                .ReferenceIdentification.Value = lReferringProvider.ReferringProviderDB.Speciality  '"213EP1101X"
            End With

            '' '' '' ''lRef = l2300.L2310A_837PRO.REF.Append
            '' '' '' ''With lRef
            '' '' '' ''    .ReferenceIdentificationQualifier.Value = "1C"
            '' '' '' ''    .ReferenceIdentification.Value = "ZZZ18991Z"
            '' '' '' ''    .Description.Value = ""
            '' '' '' ''End With
        End If
        ''***********End REFERIING PROVIDER*****************''''''''''


        ''***********RENDERING PROVIDER*****************''''''''''
        With l2300.L2310B_837PRO.NM1
            .EntityIdentifierCode1.Value = "82"
            .EntityTypeQualifier.Value = "1"
            .NameLastOrOrganizationName.Value = lRenderingProvider.Employee.LastName
            .NameFirst.Value = lRenderingProvider.Employee.FirstName
            .NameMiddle.Value = lRenderingProvider.Employee.MiddleName
            .NamePrefix.Value = ""
            .NameSuffix.Value = ""
            .IdentificationCodeQualifier.Value = "XX"
            .IdentificationCode.Value = lRenderringProvider.Employee.NPI '"1376629261"
            .EntityRelationshipCode.Value = ""
            .EntityIdentifierCode2.Value = ""
        End With

        With l2300.L2310B_837PRO.PRV
            .ProviderCode.Value = "PE"
            .ReferenceIdentificationQualifier.Value = "ZZ"
            .ReferenceIdentification.Value = lRenderringProvider.Employee.SpecialityCode '"213EP1101X"
        End With


        ''lRef = l2300.L2310B_837PRO.REF.Append
        ''With lRef
        ''    .ReferenceIdentificationQualifier.Value = "EI"
        ''    .ReferenceIdentification.Value = "330967624" 'lClinic.Clinic.FacilityCode '
        ''    .Description.Value = ""
        ''End With

        ''If (pPatientCPTCol.Item(0).COB <> "" And (pPatientCPTCol.Item(0).PrescriberLicenceID <> "")) Then
        ''    lRef = l2300.L2310B_837PRO.REF.Append
        ''    With lRef
        ''        .ReferenceIdentificationQualifier.Value = pPatientCPTCol.Item(0).COB
        ''        .ReferenceIdentification.Value = pPatientCPTCol.Item(0).PrescriberLicenceID
        ''        .Description.Value = ""
        ''    End With
        ''End If
        ''***********RENDERING PROVIDER*****************''''''''''

        'If (pHCFADB.FacilityProvider <> pHCFADB.ClinicPinNumber And pHCFADB.FacilityProvider <> "") Then
        If (pHCFADB.FacilityProvider <> pBillingProvider.BillingProvider.NPI And pHCFADB.FacilityProvider <> "") Then
            ''***********Service facility*****************''''''''''
            With l2300.L2310D_837PRO.NM1
                .EntityIdentifierCode1.Value = "FA"
                .EntityTypeQualifier.Value = "2"
                .NameLastOrOrganizationName.Value = lfacility.FacilityDB.FacilityName   '."Kazi"
                '.NameFirst.Value = lReferringProvider.ReferringProviderDB.FirstName   '"Manzoor"
                '.NameMiddle.Value = lReferringProvider.ReferringProviderDB.MiddleName '"A"
                '.NamePrefix.Value = ""
                '.NameSuffix.Value = ""
                .IdentificationCodeQualifier.Value = "XX"
                .IdentificationCode.Value = pHCFADB.FacilityProvider  '"1225032212"
                '.EntityRelationshipCode.Value = ""
                '.EntityIdentifierCode2.Value = ""
            End With

            With l2300.L2310D_837PRO.N3
                .AddressInformation1.Value = lfacility.FacilityDB.AddressLine1    '"74551 Columbian Drive"
                .AddressInformation2.Value = lfacility.FacilityDB.AddressLine2  '"74551 Columbian Drive"
            End With

            With l2300.L2310D_837PRO.N4
                If (lfacility.FacilityDB.City = "") Then
                    .CityName.Value = "Palm Desert"
                Else
                    .CityName.Value = lfacility.FacilityDB.City   '"Palm Desert"
                End If
                .StateOrProvinceCode.Value = lfacility.FacilityDB.State   '"CA"
                .PostalCode.Value = lfacility.FacilityDB.ZipCode   '"92260"
                '.CountryCode.Value = ""
                '.LocationQualifier.Value = ""
                '.LocationIdentifier.Value = ""
            End With

            If (pHCFADB.FacilitySecondaryIdentificationQualifier <> "" And pHCFADB.FacilityCode <> "") Then
                lRef = l2300.L2310D_837PRO.REF.Append
                With lRef
                    .ReferenceIdentificationQualifier.Value = pHCFADB.FacilitySecondaryIdentificationQualifier
                    .ReferenceIdentification.Value = pHCFADB.FacilityCode
                    '.Description.Value = ""
                End With
            End If
            ''***********Service facility*****************''''''''''
        End If


        If (lSecondaryInsuranceExist) Then
            ''''''''''''' other insurance loop''''''''
            Dim l2320 As ClaimLibrary.Grp837_PROL2320_837PRO
            l2320 = l2300.L2320_837PRO.Append()
            BuildClaim2320(l2320, pUser, pHCFADB, pPatientCPTCol, lReferringProvider, lRenderingProvider, lClinic, lPatient, lSecondaryInsurerPatient, lSecondaryInsuranceCompany, lSecondaryInsuranceExist, lSecondaryInsuraneSelf, lfacility)
            ''''''''''''' other insurance loop''''''''
        End If



        Dim l2400 As Grp837_PROL2400_837PRO

        Dim i As Int32

        For i = 0 To pPatientCPTCol.Count - 1
            l2400 = l2300.L2400_837PRO.Append

            With l2400.LX
                .AssignedNumber.Value = i + 1
            End With

            With l2400.SV1
                .CompositeMedicalProcedureIdentifier.ProductServiceIdQualifier.Value = "HC"
                .CompositeMedicalProcedureIdentifier.ProductServiceId.Value = pPatientCPTCol.Item(i).Code  '"94640"
                .CompositeMedicalProcedureIdentifier.ProcedureModifier1.Value = pPatientCPTCol.Item(i).ModifierA
                .CompositeMedicalProcedureIdentifier.ProcedureModifier2.Value = pPatientCPTCol.Item(i).ModifierB
                .CompositeMedicalProcedureIdentifier.ProcedureModifier3.Value = pPatientCPTCol.Item(i).ModifierC
                .CompositeMedicalProcedureIdentifier.ProcedureModifier4.Value = pPatientCPTCol.Item(i).ModifierD
                .CompositeMedicalProcedureIdentifier.Description.Value = ""



                .MonetaryAmount1.Value = pPatientCPTCol.Item(i).Charges '97.16
                .UnitOrBasisForMeasurementCode.Value = "UN"
                .Quantity.Value = pPatientCPTCol.Item(i).Days
                .FacilityCodeValue.Value = ""
                .ServiceTypeCode.Value = ""


                If (pPatientCPTCol.Item(i).Pointer <> "") Then
                    Dim length As Int32 = pPatientCPTCol.Item(i).Pointer.Length
                    .CompositeDiagnosisCodePointer.DiagnosisCodePointer1.Value = pPatientCPTCol.Item(i).Pointer.Substring(0, 1)
                    length = length - 1
                    If (length > 0) Then
                        .CompositeDiagnosisCodePointer.DiagnosisCodePointer2.Value = pPatientCPTCol.Item(i).Pointer.Substring(1, 1)
                        length = length - 1
                    End If
                    If (length > 0) Then
                        .CompositeDiagnosisCodePointer.DiagnosisCodePointer3.Value = pPatientCPTCol.Item(i).Pointer.Substring(2, 1)
                        length = length - 1
                    End If
                    If (length > 0) Then
                        .CompositeDiagnosisCodePointer.DiagnosisCodePointer4.Value = pPatientCPTCol.Item(i).Pointer.Substring(3, 1)
                    End If
                End If


                'MonetaryAmount2()
                'YesNoConditionOrResponseCode1() used later
                'MultipleProcedureCode()
                'YesNoConditionOrResponseCode2() used later
                'YesNoConditionOrResponseCode3()
                'ReviewCode()
                'NationalOrLocalAssignedReviewValue()
                'CopayStatusCode()
                'HealthCareProfessionalShortageAreaCode()
                'ReferenceIdentification()
                'PostalCode()
                'MonetaryAmount3()
                'LevelOfCareCode()
                'ProviderAgreementCode()


            End With


            With l2400.DTP1
                .DateTimeQualifier.Value = "472"
                If (pPatientCPTCol.Item(i).DateOfServiceFrom <> "" And pPatientCPTCol.Item(i).DateOfServiceTo <> "") Then
                    .DateTimePeriodFormatQualifier.Value = "RD8"
                    .DateTimePeriod.Value = Convert.ToDateTime(pPatientCPTCol.Item(i).DateOfServiceFrom).ToString("yyyyMMdd") & "-" & Convert.ToDateTime(pPatientCPTCol.Item(i).DateOfServiceTo).ToString("yyyyMMdd")
                ElseIf (pPatientCPTCol.Item(i).DateOfServiceFrom <> "" And pPatientCPTCol.Item(i).DateOfServiceTo = "") Then
                    .DateTimePeriodFormatQualifier.Value = "D8"
                    .DateTimePeriod.Value = Convert.ToDateTime(pPatientCPTCol.Item(i).DateOfServiceFrom).ToString("yyyyMMdd")
                ElseIf (pPatientCPTCol.Item(i).DateOfServiceFrom = "" And pPatientCPTCol.Item(i).DateOfServiceTo <> "") Then
                    .DateTimePeriodFormatQualifier.Value = "D8"
                    .DateTimePeriod.Value = Convert.ToDateTime(pPatientCPTCol.Item(i).DateOfServiceTo).ToString("yyyyMMdd")
                End If

            End With
        Next

        '''''''''loop work



    End Sub

    Public Shared Sub BuildClaim2320(ByRef l2320 As ClaimLibrary.Grp837_PROL2320_837PRO, ByRef pUser As User, ByRef pHCFADB As HCFADB, ByRef pPatientCPTCol As PatientCPTColl, ByRef lReferringProvider As ReferringProvider, ByRef lRenderingProvider As Employee, ByRef lClinic As Clinic, ByRef lPatient As PatientExtended, ByRef lSecondaryInsurerPatient As PatientExtended, ByRef lSecondaryInsuranceCompany As Insurance, ByVal lSecondaryInsuranceExist As Boolean, ByVal lSecondaryInsuraneSelf As Boolean, ByRef lFacility As Facility)
        With l2320.SBR
            .PayerResponsibilitySequenceNumberCode.Value = "S"
            Select Case lPatient.Patient.SecondaryInsurance.RelationshipToPrimaryInsurer
                Case "Self"
                    .IndividualRelationshipCode.Value = "18"
                Case "Souse"
                    .IndividualRelationshipCode.Value = "01"
                Case "Child"
                    .IndividualRelationshipCode.Value = "19"
                Case Else
                    .IndividualRelationshipCode.Value = "G8"
            End Select
            .ReferenceIdentification.Value = lPatient.Patient.SecondaryInsurance.GroupNo  '""
            .SubscriberName.Value = lPatient.Patient.SecondaryInsurance.PlanName  '""


            .InsuranceTypeCode.Value = "C1" 'type of insurance policy within specified program
            .CoordinationOfBenefitsCode.Value = ""
            .YesNoConditionOrResponseCode.Value = ""
            .EmploymentStatusCode.Value = ""
            If (lSecondaryInsuranceCompany.InsuranceDB.CompanyName.ToUpper.Contains("BLUE CROSS") Or lSecondaryInsuranceCompany.InsuranceDB.CompanyName.ToUpper.Contains("BLUE SHIELD")) Then
                .ClaimFilingIndicatorCode.Value = "BL"
            Else
                Select Case lSecondaryInsuranceCompany.InsuranceDB.InsuranceType.ToUpper
                    Case "MEDICARE"
                        .ClaimFilingIndicatorCode.Value = "MB"
                    Case "MEDICAID"
                        .ClaimFilingIndicatorCode.Value = "MC"
                    Case "CHAMPUS"
                        .ClaimFilingIndicatorCode.Value = "CH"
                    Case "OTHER"
                        .ClaimFilingIndicatorCode.Value = "CI"
                    Case Else
                        .ClaimFilingIndicatorCode.Value = "CI"
                End Select
            End If
        End With

        If (lSecondaryInsuraneSelf) Then
            With l2320.DMG
                .DateTimePeriodFormatQualifier.Value = "D8"
                .DateTimePeriod.Value = Convert.ToDateTime(lPatient.Patient.DOB).ToString("yyyyMMdd") '"19240131"
                .GenderCode.Value = lPatient.Patient.Gender.Substring(0, 1)
                .MaritalStatusCode.Value = ""
                .RaceOrEthnicityCode.Value = ""
                .CitizenshipStatusCode.Value = ""
                .CountryCode.Value = ""
                .BasisOfVerificationCode.Value = ""
                '.Quantity.
            End With
        Else
            With l2320.DMG
                .DateTimePeriodFormatQualifier.Value = "D8"
                .DateTimePeriod.Value = Convert.ToDateTime(lSecondaryInsurerPatient.Patient.DOB).ToString("yyyyMMdd") '"19240131"
                .GenderCode.Value = lSecondaryInsurerPatient.Patient.Gender.Substring(0, 1)
                .MaritalStatusCode.Value = ""
                .RaceOrEthnicityCode.Value = ""
                .CitizenshipStatusCode.Value = ""
                .CountryCode.Value = ""
                .BasisOfVerificationCode.Value = ""
                '.Quantity.
            End With
        End If

        With l2320.OI
            '.ClaimFilingIndicatorCode = ""
            '.ClaimSubmissionReasonCode = ""
            .YesNoConditionOrResponseCode.Value = "Y"
            .PatientSignatureSourceCode.Value = "B"
            '.ProviderAgreementCode = ""
            .ReleaseOfInformationCode.Value = "Y"
        End With

        If (lSecondaryInsuraneSelf) Then
            ' Patient information if secondary self
            With l2320.L2330A_837PRO.NM1
                .EntityIdentifierCode1.Value = "IL"
                .EntityTypeQualifier.Value = "1"
                .NameLastOrOrganizationName.Value = lPatient.Patient.LastName  '"Benjamin"
                .NameFirst.Value = lPatient.Patient.FirstName  '"Melva"
                .NameMiddle.Value = lPatient.Patient.MiddleName  '"K"
                .NamePrefix.Value = ""
                .NameSuffix.Value = ""
                .IdentificationCodeQualifier.Value = "MI"
                .IdentificationCode.Value = lPatient.Patient.SecondaryInsurance.SubscriberID 'pHCFADB.InsuredIDNumber '"488129918D"
                '.EntityRelationshipCode.Value = ""
                '.EntityIdentifierCode2.Value = ""
            End With

            With l2320.L2330A_837PRO.N3
                .AddressInformation1.Value = lPatient.Patient.AddressLine1  '"74551 Columbian Drive"
                .AddressInformation2.Value = lPatient.Patient.AddressLine2  '"74551 Columbian Drive"
            End With

            With l2320.L2330A_837PRO.N4
                .CityName.Value = lPatient.Patient.City   '"Palm Desert"
                .StateOrProvinceCode.Value = lPatient.Patient.IsDeleted  '"CA"
                .PostalCode.Value = lPatient.Patient.ZipCode  '"92260"
                '.CountryCode.Value = ""
                '.LocationQualifier.Value = ""
                '.LocationIdentifier.Value = ""
            End With
        Else
            With l2320.L2330A_837PRO.NM1
                .EntityIdentifierCode1.Value = "IL"
                .EntityTypeQualifier.Value = "1"
                .NameLastOrOrganizationName.Value = lSecondaryInsurerPatient.Patient.LastName  ''"Benjamin"
                .NameFirst.Value = lSecondaryInsurerPatient.Patient.FirstName  '"Melva"
                .NameMiddle.Value = lSecondaryInsurerPatient.Patient.MiddleName  '"K"
                .NamePrefix.Value = ""
                .NameSuffix.Value = ""
                .IdentificationCodeQualifier.Value = "MI"
                .IdentificationCode.Value = lSecondaryInsurerPatient.Patient.SecondaryInsurance.SubscriberID ''"488129918D"
                '.EntityRelationshipCode.Value = ""
                '.EntityIdentifierCode2.Value = ""
            End With

            With l2320.L2330A_837PRO.N3
                .AddressInformation1.Value = lSecondaryInsurerPatient.Patient.AddressLine1  '"74551 Columbian Drive"
                .AddressInformation2.Value = lSecondaryInsurerPatient.Patient.AddressLine2
            End With

            With l2320.L2330A_837PRO.N4
                .CityName.Value = lSecondaryInsurerPatient.Patient.City  '"Palm Desert"
                .StateOrProvinceCode.Value = lSecondaryInsurerPatient.Patient.IsDeleted  '"CA"
                .PostalCode.Value = lSecondaryInsurerPatient.Patient.ZipCode  '"92260"
                '.CountryCode.Value = ""
                '.LocationQualifier.Value = ""
                '.LocationIdentifier.Value = ""
            End With
        End If

        ' Secondary Payer
        With l2320.L2330B_837PRO.NM1
            .EntityIdentifierCode1.Value = "PR"
            .EntityTypeQualifier.Value = "2"
            .NameLastOrOrganizationName.Value = lSecondaryInsuranceCompany.InsuranceDB.CompanyName '"MEDICARE"
            .NameFirst.Value = ""
            .NameMiddle.Value = ""
            .NamePrefix.Value = ""
            .NameSuffix.Value = ""
            .IdentificationCodeQualifier.Value = "PI"
            .IdentificationCode.Value = lSecondaryInsuranceCompany.InsuranceDB.PayerID '"CMSEL"
            '.EntityRelationshipCode.Value = ""
            '.EntityIdentifierCode2.Value = ""
        End With
    End Sub

    Public Shared Function Make837RequestBatch(ByVal pClaimId As Int32(), ByVal pBatchID As String, ByVal pBatchDisplayID As String) As String
        If (pClaimId.Length < 1) Then
            Return ""
        End If
        lLastHL = 1
        lSubscriberHL = pClaimId.Length
        Dim pUser As User = CType(HttpContext.Current.Session("User"), User)
        Dim lClinic As Clinic = New Clinic(pUser.ConnectionString)
        Dim lBillingProvider As BillingProvider = New BillingProvider(pUser.ConnectionString)
        lClinic.Clinic.ClinicId = pUser.ClinicId
        lClinic.GetRecordByIdState()
        lBillingProvider.GetRecordByID()


        Dim lInterChange As New ClaimLibrary.MsgInterchange()
        Dim lGs As ClaimLibrary.GrpInterchangeFunctionalGroup
        Dim lTransaction As ClaimLibrary.Msg837_PRO




        With lInterChange.ISA
            .AuthorizationInformationQualifier.Value = "00"
            .AuthorizationInformation.Value = "0123456789"
            .SecurityInformationQualifier.Value = "00"
            .SecurityInformation.Value = "0123456789"
            .InterchangeIDQualifier1.Value = "ZZ"
            .InterchangeSenderID.Value = "123456789876543"
            .InterchangeIDQualifier2.Value = "ZZ"
            .InterchangeReceiverID.Value = "431420764000000"
            '.InterchangeDate.Value = Date.Now.ToString("yyyyMMdd")
            .InterchangeDate.Value = Format(Date.Now, "yyMMdd")
            .InterchangeTime.Value = Date.Now.ToString("HHmm")
            .InterchangeControlStandardsIdentifier.Value = "U"
            .InterchangeControlVersionNumber.Value = "00401"
            .InterchangeControlNumber.Value = "000000001"
            .AcknowledgmentRequested.Value = "1"
            .UsageIndicator.Value = "P"
            .ComponentElementSeparator.Value = ":"

            lGs = lInterChange.FunctionalGroup.Append()


        End With

        With lGs.GS
            .FunctionalIdentifierCode.Value = "HC"
            .ApplicationSendersCode.Value = "123456789"
            .ApplicationReceiversCode.Value = "431420764"
            .Date.Value = Date.Now.ToString("yyyyMMdd")
            .Time.Value = Date.Now.ToString("HHmm")
            .GroupControlNumber.Value = "123"
            .ResponsibleAgencyCode.Value = "X"
            .VersionReleaseIndustryIdentifierCode.Value = "004010X098A1"


        End With

        lTransaction = lGs.Transactions.Append("837_PRO")

        With lTransaction.ST
            .TransactionSetIdentifierCode.Value = "837"
            .TransactionSetControlNumber.Value = "000000001"
        End With

        With lTransaction.BHT
            .HierarchicalStructureCode.Value = "0019"
            .TransactionSetPurposeCode.Value = "00"
            .ReferenceIdentification.Value = pBatchID '"0123"
            .Date.Value = Date.Now.ToString("yyyyMMdd")
            .Time.Value = Date.Now.ToString("HHmm")
            .TransactionTypeCode.Value = "CH"
        End With

        With lTransaction.REF
            .ReferenceIdentificationQualifier.Value = "87"
            .ReferenceIdentification.Value = "004010X098A1"
        End With


        ''''''' Sender''''''''''''''''''
        With lTransaction.L1000A_837PRO.NM1
            .EntityIdentifierCode1.Value = "41"
            .EntityTypeQualifier.Value = "2"
            .NameLastOrOrganizationName.Value = "OA Systems"
            .NameFirst.Value = ""
            .NameMiddle.Value = ""
            .NamePrefix.Value = ""
            .NameSuffix.Value = ""
            .IdentificationCodeQualifier.Value = "46"
            .IdentificationCode.Value = "XOA00205"
            .EntityRelationshipCode.Value = ""
            .EntityIdentifierCode2.Value = ""
        End With

        Dim lPer As ClaimLibrary.SegPER
        lPer = lTransaction.L1000A_837PRO.PER.Append()



        With lPer
            .ContactFunctionCode.Value = "IC"
            .ContactName.Value = "Rifat Ali Syed"
            .CommunicationNumberQualifier1.Value = "TE"
            .CommunicationNumber1.Value = "9094661605" 'lClinic.Clinic.Phone1 '"XOA00205"
            .CommunicationNumberQualifier2.Value = ""
            .CommunicationNumber2.Value = ""
            .CommunicationNumberQualifier3.Value = ""
            .CommunicationNumber3.Value = ""
            .ContactInquiryReference.Value = ""
        End With

        ''''''''''''' Sender'''''''''''''''''

        ''''''''''''' receiver'''''''''''''''''
        With lTransaction.L1000B_837PRO.NM1
            .EntityIdentifierCode1.Value = "40"
            .EntityTypeQualifier.Value = "2"
            '.NameLastOrOrganizationName.Value = "Electronic Network Systems, Inc."
            .NameLastOrOrganizationName.Value = "Gateway EDI Inc"
            .NameFirst.Value = ""
            .NameMiddle.Value = ""
            .NamePrefix.Value = ""
            .NameSuffix.Value = ""
            .IdentificationCodeQualifier.Value = "46"
            .IdentificationCode.Value = "841162764"
            .EntityRelationshipCode.Value = ""
            .EntityIdentifierCode2.Value = ""
        End With
        ''''''''''''' Receiver'''''''''''''''''


        '''''''''''''''' 2000A Billing Provider Starts''''''''''
        Dim l2000A As Grp837_PROL2000A_837PRO
        l2000A = lTransaction.L2000A_837PRO.Append()

        With l2000A.HL_1
            .HierarchicalIdNumber.Value = "1"
            .HierarchicalParentIdNumber.Value = ""
            .HierarchicalLevelCode.Value = "20"
            'If (lPrimaryInsuraneSelf) Then
            .HierarchicalChildCode.Value = "1"
            ' Else
            '.HierarchicalChildCode.Value = "2"
            'End If
        End With


        ''With l2000A.PRV
        ''    .ProviderCode.Value = "PT"
        ''    .ReferenceIdentificationQualifier.Value = "ZZ"
        ''    .ReferenceIdentification.Value = "213EP1101X"
        ''End With

        With l2000A.L2010AA_837PRO1.NM1
            .EntityIdentifierCode1.Value = "85"
            If (lBillingProvider.BillingProvider.FirstName <> "") Then
                .EntityTypeQualifier.Value = "1"
            Else
                .EntityTypeQualifier.Value = "2"
            End If
            '.NameLastOrOrganizationName.Value = lClinic.Clinic.ClinicName '"Palm Desert Urgent Care"
            .NameLastOrOrganizationName.Value = lBillingProvider.BillingProvider.LastName  '"Palm Desert Urgent Care"
            .NameFirst.Value = lBillingProvider.BillingProvider.FirstName
            .NameMiddle.Value = lBillingProvider.BillingProvider.MiddleName
            .NamePrefix.Value = ""
            .NameSuffix.Value = ""
            .IdentificationCodeQualifier.Value = "XX"
            '.IdentificationCode.Value = lClinic.Clinic.NPI ''lClinic.Clinic.NPI    '"1003849621"
            .IdentificationCode.Value = lBillingProvider.BillingProvider.NPI
            .EntityRelationshipCode.Value = ""
            .EntityIdentifierCode2.Value = ""
        End With

        With l2000A.L2010AA_837PRO1.N3
            .AddressInformation1.Value = lBillingProvider.BillingProvider.AddressLine1 'lClinic.Clinic.AddressLine1  '"PO Box 1118"
            .AddressInformation2.Value = lBillingProvider.BillingProvider.AddressLine2 'lClinic.Clinic.AddressLine2
        End With

        With l2000A.L2010AA_837PRO1.N4
            .CityName.Value = lBillingProvider.BillingProvider.City 'lClinic.Clinic.City  '"Palm Desert"
            .StateOrProvinceCode.Value = lBillingProvider.BillingProvider.State
            .PostalCode.Value = lBillingProvider.BillingProvider.ZipCode
            .CountryCode.Value = ""
            .LocationQualifier.Value = ""
            .LocationIdentifier.Value = ""
        End With

        Dim lRef As SegREF

        'If (lClinic.Clinic.FacilityCode <> "") Then
        lRef = l2000A.L2010AA_837PRO1.REF1.Append
        With lRef
            'If (pHCFADB.ClinicSecondaryIdentificationQualifier <> "" And pHCFADB.ClinicGroupNumber <> "") Then
            '.ReferenceIdentificationQualifier.Value = pHCFADB.ClinicSecondaryIdentificationQualifier
            '.ReferenceIdentification.Value = pHCFADB.ClinicGroupNumber
            '.Description.Value = ""
            'Else
            .ReferenceIdentificationQualifier.Value = "EI"
            .ReferenceIdentification.Value = lBillingProvider.BillingProvider.TaxID  'lClinic.Clinic.FacilityCode '
            .Description.Value = ""
            'End If

        End With
        'End If
        '************************ 2000A Billing Provider End






        ''****************************************************
        ''****************************************************
        ''****************************************************
        ''*************************************** Loop WOrk STart Claim Batch ************************************
        For Each lHcfaID As Int32 In pClaimId
            lSubscriberHL = lSubscriberHL - 1
            Dim lHcfa As New HCFA(pUser.ConnectionString)
            lHcfa.HCFA.HCFAID = lHcfaID
            lHcfa.GetRecordByID()

            Dim pHCFADB As New HCFADB
            pHCFADB = lHcfa.HCFA

            Dim pPatientCPTCol As PatientCPTColl = LoadClaimCpt(pHCFADB.PatientSuperBillID)

            Dim lPrimaryInsuraneSelf As Boolean = False
            Dim lSecondaryInsuraneSelf As Boolean = False
            Dim lPrimaryInsuranceExist As Boolean = False
            Dim lSecondaryInsuranceExist As Boolean = False
            Dim lPrimaryInsuranceCompanyId As Int32 = 0
            Dim lSecondaryInsuranceCompanyId As Int32 = 0
            Dim lPatient As New PatientExtended(pUser.ConnectionString)
            lPatient.Patient.PatientID = pHCFADB.PatientAccountNumber
            lPatient.GetPatientWithDetailsByID()
            Dim lPrimaryInsurerPatient As New PatientExtended(pUser.ConnectionString)
            Dim lPrimaryInsuranceCompany As New Insurance(pUser.ConnectionString)
            Dim lSecondaryInsurerPatient As New PatientExtended(pUser.ConnectionString)
            Dim lSecondaryInsuranceCompany As New Insurance(pUser.ConnectionString)
            Dim lClaimId As String = ""


            '''''''''''''' Primary Insurance And Insurer Checking Logic
            If (lPatient.Patient.PrimaryInsurance.Active = "Y" And (lPatient.Patient.PrimaryInsurance.InsuranceCompanyID <> 0 Or lPatient.Patient.PrimaryInsurance.InsurerId <> 0)) Then
                lPrimaryInsuranceExist = True
                If (lPatient.Patient.PrimaryInsurance.InsurerId <> 0) Then
                    lPrimaryInsuraneSelf = False
                    lPrimaryInsurerPatient.Patient.PatientID = lPatient.Patient.PrimaryInsurance.InsurerId
                    lPrimaryInsurerPatient.GetPatientWithDetailsByID()
                    'lPrimaryInsuranceCompany.InsuranceDB.FavouriteInsuranceID = lPrimaryInsurerPatient.Patient.PrimaryInsurance.InsuranceCompanyID
                    'lPrimaryInsuranceCompany.GetRecordById()
                Else
                    lPrimaryInsuraneSelf = True
                End If
            Else
                lPrimaryInsuranceExist = False
            End If
            '''''''''''''' Primary Insurance And Insurer Checking Logic

            '''''''''''''' Secondary Insurance And Insurer Checking Logic
            If (lPatient.Patient.SecondaryInsurance.Active = "Y" And (lPatient.Patient.SecondaryInsurance.InsuranceCompanyID <> 0 Or lPatient.Patient.SecondaryInsurance.InsurerId <> 0)) Then
                lSecondaryInsuranceExist = True
                If (lPatient.Patient.SecondaryInsurance.InsurerId <> 0) Then
                    lSecondaryInsuraneSelf = False
                    lSecondaryInsurerPatient.Patient.PatientID = lPatient.Patient.SecondaryInsurance.InsurerId
                    lSecondaryInsurerPatient.GetPatientWithDetailsByID()
                    'lSecondaryInsuranceCompany.InsuranceDB.FavouriteInsuranceID = lSecondaryInsurerPatient.Patient.SecondaryInsurance.InsuranceCompanyID
                    'lSecondaryInsuranceCompany.GetRecordById()
                Else
                    lSecondaryInsuraneSelf = True
                End If
            Else
                lSecondaryInsuranceExist = False
            End If
            '''''''''''''' Secondary Insurance And Insurer Checking Logic

            Dim lConnection As New Connection(pUser.ConnectionString)

            Dim lQuery As String

            If (lPrimaryInsuranceExist) Then
                If (lPrimaryInsuraneSelf) Then
                    lPrimaryInsuranceCompanyId = lPatient.Patient.PrimaryInsurance.InsuranceCompanyID
                Else
                    lPrimaryInsuranceCompanyId = lPrimaryInsurerPatient.Patient.PrimaryInsurance.InsuranceCompanyID
                End If
            Else
                lPrimaryInsuranceCompanyId = 0
            End If

            If (lSecondaryInsuranceExist) Then
                If (lSecondaryInsuraneSelf) Then
                    lSecondaryInsuranceCompanyId = lPatient.Patient.SecondaryInsurance.InsuranceCompanyID
                Else
                    lSecondaryInsuranceCompanyId = lSecondaryInsurerPatient.Patient.SecondaryInsurance.InsuranceCompanyID
                End If
            Else
                lSecondaryInsuranceCompanyId = 0
            End If



            lQuery = "Exec GetMultipleTableForClaimEDI " & pUser.ClinicId & "," & IIf(pHCFADB.RefferingProviderID <> "", pHCFADB.RefferingProviderID, 0) & "," & pHCFADB.DoctorUserID & "," & lPrimaryInsuranceCompanyId & "," & lSecondaryInsuranceCompanyId & "," & pHCFADB.FacilityId


            Dim lDs As New DataSet
            lDs = lConnection.ExecuteQuery(lQuery)

            ''''Dim lClinic As New Clinic(pUser.ConnectionString)
            ''''lClinic.Clinic.ClinicId = pUser.ClinicId
            ''''lClinic.GetRecordByID(lDs.Tables(0))

            Dim lReferringProvider As New ReferringProvider(pUser.ConnectionString)
            'lReferringProvider.ReferringProviderDB.ProviderID = pHCFADB.DoctorUserID
            lReferringProvider.GetRecordByID(lDs.Tables(1))

            Dim lRenderingProvider As New Employee(pUser.ConnectionString)
            'lRenderingProvider.Employee.EmployeeID = pHCFADB.DoctorUserID
            lRenderingProvider.GetRecordByID(lDs.Tables(2))

            If (lPrimaryInsuranceExist) Then
                lPrimaryInsuranceCompany.GetRecordById(lDs.Tables(3))
            End If

            If (lSecondaryInsuranceExist) Then
                lSecondaryInsuranceCompany.GetRecordById(lDs.Tables(4))
            End If

            Dim lFacility As New Facility(pUser.ConnectionString)
            If (Not lDs.Tables(5) Is Nothing) Then
                lFacility.GetRecordById(lDs.Tables(5))
            End If


            '************************ 2000B Subscriber Starts 

            Dim l2000B As Grp837_PROL2000B_837PRO
            l2000B = l2000A.L2000B_837PRO.Append()


            With l2000B.HL_5
                lLastHL = lLastHL + 1
                .HierarchicalIdNumber.Value = lLastHL
                .HierarchicalParentIdNumber.Value = "1"
                .HierarchicalLevelCode.Value = "22"
                If (lSubscriberHL > 0) Then
                    '.HierarchicalChildCode.Value = "0"
                    If (lPrimaryInsuraneSelf) Then
                        .HierarchicalChildCode.Value = "0"
                    Else
                        .HierarchicalChildCode.Value = "1"
                    End If
                ElseIf (Not lPrimaryInsuraneSelf) Then
                    .HierarchicalChildCode.Value = "1"
                Else
                    .HierarchicalChildCode.Value = "0"
                End If

            End With


            With l2000B.SBR
                .PayerResponsibilitySequenceNumberCode.Value = "P"
                If (lPrimaryInsuraneSelf) Then
                    .IndividualRelationshipCode.Value = "18"
                Else
                    .IndividualRelationshipCode.Value = ""
                    'Select Case lPatient.Patient.PrimaryInsurance.RelationshipToPrimaryInsurer.ToUpper
                    '    Case "SPOUSE"
                    '        .IndividualRelationshipCode.Value = "01"
                    '    Case "CHILD"
                    '        .IndividualRelationshipCode.Value = "19"
                    '    Case "OTHER"
                    '        .IndividualRelationshipCode.Value = "G8"
                    'End Select
                End If
                .ReferenceIdentification.Value = pHCFADB.AnotherInsuredPolicy '""
                .SubscriberName.Value = pHCFADB.AnotherInsuredInsurancePlan '""

                If (.PayerResponsibilitySequenceNumberCode.Value <> "P" And pHCFADB.Type1 = "MEDICARE") Then
                    .InsuranceTypeCode.Value = "" 'type of insurance policy within specified program
                Else
                    .InsuranceTypeCode.Value = ""
                End If
                .CoordinationOfBenefitsCode.Value = ""
                .YesNoConditionOrResponseCode.Value = ""
                .EmploymentStatusCode.Value = ""
                If (lPrimaryInsuranceCompany.InsuranceDB.CompanyName.ToUpper.Contains("BLUE CROSS") Or lPrimaryInsuranceCompany.InsuranceDB.CompanyName.ToUpper.Contains("BLUE SHIELD")) Then
                    .ClaimFilingIndicatorCode.Value = "BL"
                Else
                    Select Case pHCFADB.Type1.ToUpper
                        Case "MEDICARE"
                            .ClaimFilingIndicatorCode.Value = "MB"
                        Case "MEDICAID"
                            .ClaimFilingIndicatorCode.Value = "MC"
                        Case "CHAMPUS"
                            .ClaimFilingIndicatorCode.Value = "CH"
                        Case "OTHER"
                            .ClaimFilingIndicatorCode.Value = "CI"
                        Case Else
                            .ClaimFilingIndicatorCode.Value = "CI"
                    End Select
                End If
            End With

            ''''''''' Discussion Needed
            'Required if the subscriber is the same person as the patient (Loop ID- 
            '2000B SBR02=18), and information in this PAT segment (date of   
            'death, and/or patient weight) is necessary to file the claim/encounter
            '(see PAT05, 06, 07, and 08).

            '' '' ''If (pHCFADB.PatientRelationshipToInsured <> "SELF") Then
            '' '' ''    With l2000B.PAT

            '' '' ''    End With
            '' '' ''End If
            ''''''''' Discussion Needed


            '******************** Start 2010BA Subscriber
            If (lPrimaryInsuraneSelf) Then ''''''''''MAIN IF
                ''''''''' If Patient is Subscriber Fisrst Block'''''''''''''''
                With l2000B.L2010BA_837PRO1.NM1
                    .EntityIdentifierCode1.Value = "IL"
                    .EntityTypeQualifier.Value = "1"
                    .NameLastOrOrganizationName.Value = lPatient.Patient.LastName  '"Benjamin"
                    .NameFirst.Value = lPatient.Patient.FirstName  '"Melva"
                    .NameMiddle.Value = lPatient.Patient.MiddleName  '"K"
                    .NamePrefix.Value = ""
                    .NameSuffix.Value = ""
                    .IdentificationCodeQualifier.Value = "MI"
                    .IdentificationCode.Value = lPatient.Patient.PrimaryInsurance.SubscriberID 'pHCFADB.InsuredIDNumber '"488129918D"
                    .EntityRelationshipCode.Value = ""
                    .EntityIdentifierCode2.Value = ""
                End With

                With l2000B.L2010BA_837PRO1.N3
                    .AddressInformation1.Value = lPatient.Patient.AddressLine1  '"74551 Columbian Drive"
                    .AddressInformation2.Value = lPatient.Patient.AddressLine2  '"74551 Columbian Drive"
                End With

                With l2000B.L2010BA_837PRO1.N4
                    If (lPatient.Patient.City = "") Then
                        .CityName.Value = "Palm Desert"
                    Else
                        .CityName.Value = lPatient.Patient.City   '"Palm Desert"
                    End If
                    .StateOrProvinceCode.Value = lPatient.Patient.IsDeleted  '"CA"
                    .PostalCode.Value = lPatient.Patient.ZipCode  '"92260"
                    .CountryCode.Value = ""
                    .LocationQualifier.Value = ""
                    .LocationIdentifier.Value = ""
                End With

                With l2000B.L2010BA_837PRO1.DMG
                    .DateTimePeriodFormatQualifier.Value = "D8"
                    .DateTimePeriod.Value = Convert.ToDateTime(lPatient.Patient.DOB).ToString("yyyyMMdd") '"19240131"
                    .GenderCode.Value = lPatient.Patient.Gender.Substring(0, 1)
                    .MaritalStatusCode.Value = ""
                    .RaceOrEthnicityCode.Value = ""
                    .CitizenshipStatusCode.Value = ""
                    .CountryCode.Value = ""
                    .BasisOfVerificationCode.Value = ""
                    '.Quantity.
                End With
                ''''''''' If first Block'''''''''''''''
            Else '''''''''''''Main IF
                ''''''''' If Patient is Not Subscriber Second Block'''''''''''''''
                With l2000B.L2010BA_837PRO1.NM1
                    .EntityIdentifierCode1.Value = "IL"
                    .EntityTypeQualifier.Value = "1"
                    .NameLastOrOrganizationName.Value = lPrimaryInsurerPatient.Patient.LastName  ''"Benjamin"
                    .NameFirst.Value = lPrimaryInsurerPatient.Patient.FirstName  '"Melva"
                    .NameMiddle.Value = lPrimaryInsurerPatient.Patient.MiddleName  '"K"
                    .NamePrefix.Value = ""
                    .NameSuffix.Value = ""
                    .IdentificationCodeQualifier.Value = "MI"
                    .IdentificationCode.Value = lPrimaryInsurerPatient.Patient.PrimaryInsurance.SubscriberID ''"488129918D"
                    .EntityRelationshipCode.Value = ""
                    .EntityIdentifierCode2.Value = ""
                End With

                With l2000B.L2010BA_837PRO1.N3
                    .AddressInformation1.Value = lPrimaryInsurerPatient.Patient.AddressLine1  '"74551 Columbian Drive"
                    .AddressInformation2.Value = lPrimaryInsurerPatient.Patient.AddressLine2
                End With

                With l2000B.L2010BA_837PRO1.N4
                    If (lPrimaryInsurerPatient.Patient.City = "") Then
                        .CityName.Value = "Palm Desert"
                    Else
                        .CityName.Value = lPrimaryInsurerPatient.Patient.City  '"Palm Desert"
                    End If
                    .StateOrProvinceCode.Value = lPrimaryInsurerPatient.Patient.IsDeleted  '"CA"
                    .PostalCode.Value = lPrimaryInsurerPatient.Patient.ZipCode  '"92260"
                    .CountryCode.Value = ""
                    .LocationQualifier.Value = ""
                    .LocationIdentifier.Value = ""
                End With

                ''''''''' If first Block'''''''''''''''
            End If
            '******************** End 2010BA Subscriber


            '******************** Start Payer Name 2010BB 
            With l2000B.L2010BB_837PRO.NM1
                .EntityIdentifierCode1.Value = "PR"
                .EntityTypeQualifier.Value = "2"

                If (lPrimaryInsuranceCompany.InsuranceDB.CompanyName.Length > 35) Then
                    .NameLastOrOrganizationName.Value = lPrimaryInsuranceCompany.InsuranceDB.CompanyName.Substring(0, 34) '"MEDICARE"
                Else
                    .NameLastOrOrganizationName.Value = lPrimaryInsuranceCompany.InsuranceDB.CompanyName '"MEDICARE"
                End If

                .NameFirst.Value = ""
                .NameMiddle.Value = ""
                .NamePrefix.Value = ""
                .NameSuffix.Value = ""
                .IdentificationCodeQualifier.Value = "PI"
                .IdentificationCode.Value = lPrimaryInsuranceCompany.InsuranceDB.PayerID.PadLeft(5, "0") '"CMSEL"
                .EntityRelationshipCode.Value = ""
                .EntityIdentifierCode2.Value = ""
            End With

            With l2000B.L2010BB_837PRO.N3
                .AddressInformation1.Value = lPrimaryInsuranceCompany.InsuranceDB.AddressLine1 '"PO Box 272852"
                .AddressInformation2.Value = lPrimaryInsuranceCompany.InsuranceDB.AddressLine2 '""
            End With

            With l2000B.L2010BB_837PRO.N4
                If (lPrimaryInsuranceCompany.InsuranceDB.City <> "") Then
                    .CityName.Value = lPrimaryInsuranceCompany.InsuranceDB.City
                Else
                    .CityName.Value = "Chico"
                End If
                .StateOrProvinceCode.Value = lPrimaryInsuranceCompany.InsuranceDB.State '"CA"
                .PostalCode.Value = lPrimaryInsuranceCompany.InsuranceDB.ZipCode '"95927"
                .CountryCode.Value = ""
                .LocationQualifier.Value = ""
                .LocationIdentifier.Value = ""
            End With
            '******************** Start Payer Name 2010BB 
            '******************** END  Loop 2000B 

            If (lPrimaryInsuraneSelf) Then
                Dim l2300 As ClaimLibrary.Grp837_PROL2300_837PRO1
                l2300 = l2000B.L2300_837PRO1.Append
                'BuildClaim2300(l2000B.L2300_837PRO1.Append, pUser, pHCFADB, pPatientCPTCol, lReferringProvider, True)
                BuildClaim2300(l2300, pUser, pHCFADB, pPatientCPTCol, lReferringProvider, lRenderingProvider, lClinic, lPatient, lSecondaryInsurerPatient, lSecondaryInsuranceCompany, lSecondaryInsuranceExist, lSecondaryInsuraneSelf, lFacility, lBillingProvider)
            Else
                '******************** Start Patient Hierarchical Level 2000C 
                Dim l2000C As Grp837_PROL2000C_837PRO
                l2000C = l2000B.L2000C_837PRO.Append()

                With l2000C.HL_3
                    lLastHL = lLastHL + 1
                    .HierarchicalIdNumber.Value = lLastHL
                    .HierarchicalParentIdNumber.Value = lLastHL - 1
                    .HierarchicalLevelCode.Value = "23"
                    .HierarchicalChildCode.Value = "0"
                End With

                With l2000C.PAT
                    Select Case pHCFADB.PatientRelationshipToInsured
                        Case "Spouse"
                            .IndividualRelationshipCode.Value = "01"
                        Case "Child"
                            .IndividualRelationshipCode.Value = "19"
                        Case "Other"
                            .IndividualRelationshipCode.Value = "G8"
                    End Select
                    '.PatientLocationCode = ""
                    '.EmploymentStatusCode = ""
                    '.StudentStatusCode = ""
                    '.DateTimePeriodFormatQualifier = ""
                    '.DateTimePeriod = ""
                    '.UnitOrBasisForMeasurementCode = ""
                    '.Weight = ""
                    '.YesNoConditionOrResponseCode = ""
                End With

                With l2000C.L2010CA_837PRO.NM1
                    .EntityIdentifierCode1.Value = "QC"
                    .EntityTypeQualifier.Value = "1"
                    .NameLastOrOrganizationName.Value = lPatient.Patient.LastName  '"Benjamin"
                    .NameFirst.Value = lPatient.Patient.FirstName  '"Melva"
                    .NameMiddle.Value = lPatient.Patient.MiddleName  '"K"
                    .NamePrefix.Value = ""
                    .NameSuffix.Value = ""
                    '.IdentificationCodeQualifier.Value = "MI"
                    '.IdentificationCode.Value = pHCFADB.InsuredIDNumber '"488129918D"
                    '.EntityRelationshipCode.Value = ""
                    '.EntityIdentifierCode2.Value = ""
                End With

                With l2000C.L2010CA_837PRO.N3
                    .AddressInformation1.Value = lPatient.Patient.AddressLine1  '"74551 Columbian Drive"
                    .AddressInformation2.Value = lPatient.Patient.AddressLine2  '"74551 Columbian Drive"
                End With

                With l2000C.L2010CA_837PRO.N4
                    If (lPatient.Patient.City = "") Then
                        .CityName.Value = "Palm Desert"
                    Else
                        .CityName.Value = lPatient.Patient.City   '"Palm Desert"
                    End If
                    .StateOrProvinceCode.Value = lPatient.Patient.IsDeleted  '"CA"
                    .PostalCode.Value = lPatient.Patient.ZipCode  '"92260"
                    .CountryCode.Value = ""
                    .LocationQualifier.Value = ""
                    .LocationIdentifier.Value = ""
                End With

                With l2000C.L2010CA_837PRO.DMG
                    .DateTimePeriodFormatQualifier.Value = "D8"
                    .DateTimePeriod.Value = Convert.ToDateTime(lPatient.Patient.DOB).ToString("yyyyMMdd") '"19240131"
                    .GenderCode.Value = lPatient.Patient.Gender.Substring(0, 1)
                    .MaritalStatusCode.Value = ""
                    .RaceOrEthnicityCode.Value = ""
                    .CitizenshipStatusCode.Value = ""
                    .CountryCode.Value = ""
                    .BasisOfVerificationCode.Value = ""
                    '.Quantity.
                End With

                '' '' ''lRef = l2000C.L2010CA_837PRO.REF1.Append
                '' '' ''With lRef
                '' '' ''    .ReferenceIdentification = ""
                '' '' ''    .ReferenceIdentificationQualifier = ""
                '' '' ''End With
                '******************** END Patient Hierarchical Level 2000C 
                Dim l2300 As ClaimLibrary.Grp837_PROL2300_837PRO2
                l2300 = l2000C.L2300_837PRO2.Append
                BuildClaim2300(l2300, pUser, pHCFADB, pPatientCPTCol, lReferringProvider, lRenderingProvider, lClinic, lPatient, lSecondaryInsurerPatient, lSecondaryInsuranceCompany, lSecondaryInsuranceExist, lSecondaryInsuraneSelf, lFacility, lBillingProvider)
            End If
        Next
        ''*************************************** Loop WOrk END Claim Batch
        ''****************************************************
        ''****************************************************
        ''****************************************************


        ''''''''' clm 2300 start

        ''''''''' clm 2300 start

        'lClaimId = "CL" & pUser.ClinicId & "H" & Convert.ToDateTime(pHCFADB.HCFAPreparedDate).Year & Convert.ToDateTime(pHCFADB.HCFAPreparedDate).ToString("MM") & pHCFADB.HCFADisplayID.PadLeft(5, "0")
        Dim lMessage As String = lInterChange.Parse()
        Dim lFilePath As String = SaveToFile(lMessage, pBatchDisplayID & ".txt")
        Return lMessage
        'Return ""

    End Function

    Public Shared Function LoadClaimCpt(ByVal pPatientSuperBillID As Int32) As PatientCPTColl
        Dim lUser As User = CType(HttpContext.Current.Session("User"), User)

        Dim lPatientCPT As PatientCPT = Nothing
        Dim lDataSet As DataSet = Nothing

        Dim lPatientCPTDB As PatientCPTDB
        Dim lPatientCPTCol As New PatientCPTColl

        Try
            lPatientCPT = New PatientCPT(lUser.ConnectionString)
            lDataSet = lPatientCPT.GetAllRecords(" And PatientSuperBillId = " & pPatientSuperBillID & " And LineNumber <= 6 Order By LineNumber", "PatientCPT")
        Catch ex As Exception
            Return Nothing
        End Try



        For Each Row As DataRow In lDataSet.Tables(0).Rows

            lPatientCPTDB = New PatientCPTDB()

            With lPatientCPTDB
                .HCFAID = Row.Item("HCFAID")
                .Code = Row.Item("Code")
                .LineId = Row.Item("LineId")
                .DateOfServiceFrom = Row.Item("DateOfServiceFrom")
                .DateOfServiceTo = Row.Item("DateOfServiceTo")
                .POS = Row.Item("POS")
                .ModifierA = Row.Item("ModifierA")
                .ModifierB = Row.Item("ModifierB")
                .ModifierC = Row.Item("ModifierC")
                .ModifierD = Row.Item("ModifierD")
                .Pointer = Row.Item("Pointer")

                Try
                    .Charges = CType(Row.Item("Charges"), Double)
                Catch ex As Exception
                    .Charges = 0.0
                End Try


                .Days = Row.Item("Days")
                .EPSDT = Row.Item("EPSDT")
                .EMG = Row.Item("Emergency")
                .COB = Row.Item("COB")
                .NPI = Row.Item("NPI")
                .PrescriberLicenceID = Row.Item("PrescriberLicenceID") 'Field To Be added In DB & Classes

            End With

            lPatientCPTCol.Add(lPatientCPTDB)

        Next

        Return lPatientCPTCol
    End Function

    Public Shared Function Make837RequestBatchNew(ByVal pClaimId As Int32(), ByVal pBatchID As String, ByVal pBatchDisplayID As String) As String
        If (pClaimId.Length < 1) Then
            Return ""
        End If
        
        Dim pUser As User = CType(HttpContext.Current.Session("User"), User)
        Dim lClinic As Clinic = New Clinic(pUser.ConnectionString)
        Dim lBillingProvider As BillingProvider = New BillingProvider(pUser.ConnectionString)
        Dim lEDIMessage As String = ""
        Dim lCurrentFilePath As String = ""
        Dim lGatewayFtpClaimRequestMode As String = CType(ConfigurationManager.AppSettings("GatewayFtpClaimRequestMode"), String).ToUpper


        Dim lCurrentFileResult As Boolean = False
        Dim lSendGatewayResult As Boolean = False
        Dim lFileArchiveResult As Boolean = False

        ''Global Variable initialization
        lLastHL = 1
        lSubscriberHL = pClaimId.Length


        lClinic.Clinic.ClinicId = pUser.ClinicId
        lClinic.GetRecordByIdState()
        lBillingProvider.GetRecordByID()


        Dim lInterChange As New ClaimLibrary.MsgInterchange()
        Dim lGs As ClaimLibrary.GrpInterchangeFunctionalGroup
        Dim lTransaction As ClaimLibrary.Msg837_PRO

        Try

            With lInterChange.ISA
                .AuthorizationInformationQualifier.Value = "00"
                .AuthorizationInformation.Value = "          "
                .SecurityInformationQualifier.Value = "00"
                .SecurityInformation.Value = "          "
                .InterchangeIDQualifier1.Value = "ZZ"

                If lGatewayFtpClaimRequestMode = "P" Then
                    .InterchangeSenderID.Value = Left(lClinic.Clinic.GatewayFtpUserID + "               ", 15)
                Else
                    .InterchangeSenderID.Value = "TEST           "
                End If
                .InterchangeIDQualifier2.Value = "ZZ"
                .InterchangeReceiverID.Value = "431420764      "
                '.InterchangeDate.Value = Date.Now.ToString("yyyyMMdd")
                .InterchangeDate.Value = Format(Date.Now, "yyMMdd")
                .InterchangeTime.Value = Date.Now.ToString("HHmm")
                .InterchangeControlStandardsIdentifier.Value = "U"
                .InterchangeControlVersionNumber.Value = "00401"
                .InterchangeControlNumber.Value = "000000001"
                .AcknowledgmentRequested.Value = "1"
                '.UsageIndicator.Value = "P" 'Production
                .UsageIndicator.Value = lGatewayFtpClaimRequestMode '"T" 'Testing
                .ComponentElementSeparator.Value = ":"

                lGs = lInterChange.FunctionalGroup.Append()


            End With

            With lGs.GS
                .FunctionalIdentifierCode.Value = "HC"

                If lGatewayFtpClaimRequestMode = "P" Then
                    .ApplicationSendersCode.Value = lClinic.Clinic.GatewayFtpUserID
                Else
                    .ApplicationSendersCode.Value = "TEST"
                End If

                .ApplicationReceiversCode.Value = "431420764"
                .Date.Value = Date.Now.ToString("yyyyMMdd")
                .Time.Value = Date.Now.ToString("HHmm")
                .GroupControlNumber.Value = "123"
                .ResponsibleAgencyCode.Value = "X"
                .VersionReleaseIndustryIdentifierCode.Value = "004010X098A1"


            End With

            lTransaction = lGs.Transactions.Append("837_PRO")

            With lTransaction.ST
                .TransactionSetIdentifierCode.Value = "837"
                .TransactionSetControlNumber.Value = "000000001"
            End With

            With lTransaction.BHT
                .HierarchicalStructureCode.Value = "0019"
                .TransactionSetPurposeCode.Value = "00"
                .ReferenceIdentification.Value = pBatchID '"0123"
                .Date.Value = Date.Now.ToString("yyyyMMdd")
                .Time.Value = Date.Now.ToString("HHmm")
                .TransactionTypeCode.Value = "CH"
            End With

            With lTransaction.REF
                .ReferenceIdentificationQualifier.Value = "87"
                .ReferenceIdentification.Value = "004010X098A1"
            End With


            ''''''' Sender''''''''''''''''''
            With lTransaction.L1000A_837PRO.NM1
                .EntityIdentifierCode1.Value = "41"
                .EntityTypeQualifier.Value = "2"
                .NameLastOrOrganizationName.Value = "OA Systems"
                .NameFirst.Value = ""
                .NameMiddle.Value = ""
                .NamePrefix.Value = ""
                .NameSuffix.Value = ""
                .IdentificationCodeQualifier.Value = "46"
                .IdentificationCode.Value = "XOA00205"
                .EntityRelationshipCode.Value = ""
                .EntityIdentifierCode2.Value = ""
            End With

            Dim lPer As ClaimLibrary.SegPER
            lPer = lTransaction.L1000A_837PRO.PER.Append()



            With lPer
                .ContactFunctionCode.Value = "IC"
                .ContactName.Value = "Rifat Ali Syed"
                .CommunicationNumberQualifier1.Value = "TE"
                .CommunicationNumber1.Value = "9094661605" 'lClinic.Clinic.Phone1 '"XOA00205"
                .CommunicationNumberQualifier2.Value = ""
                .CommunicationNumber2.Value = ""
                .CommunicationNumberQualifier3.Value = ""
                .CommunicationNumber3.Value = ""
                .ContactInquiryReference.Value = ""
            End With

            ''''''''''''' Sender'''''''''''''''''

            ''''''''''''' receiver'''''''''''''''''
            With lTransaction.L1000B_837PRO.NM1
                .EntityIdentifierCode1.Value = "40"
                .EntityTypeQualifier.Value = "2"
                '.NameLastOrOrganizationName.Value = "Electronic Network Systems, Inc."
                .NameLastOrOrganizationName.Value = "Gateway EDI Inc"
                .NameFirst.Value = ""
                .NameMiddle.Value = ""
                .NamePrefix.Value = ""
                .NameSuffix.Value = ""
                .IdentificationCodeQualifier.Value = "46"
                .IdentificationCode.Value = "841162764"
                .EntityRelationshipCode.Value = ""
                .EntityIdentifierCode2.Value = ""
            End With
            ''''''''''''' Receiver'''''''''''''''''

            '''''''''''''''' 2000A Billing Provider Starts''''''''''
            Dim l2000A As Grp837_PROL2000A_837PRO
            l2000A = lTransaction.L2000A_837PRO.Append()

            'Dim l2000B As Grp837_PROL2000B_837PRO
            'l2000B = lTransaction.L2000B_837PRO.Append()



            'Dim lTest As Grp837_PROL2000B_837PRO = l2000B.L2000B_837PRO.Append '.L2300_837PRO1.REF1.Append
            'lTest.cl()


            'Dim lRef As Grp837_PROL2300_837PRO1 = l2000B.L2300_837PRO1.Append






            With l2000A.HL_1
                .HierarchicalIdNumber.Value = "1"
                .HierarchicalParentIdNumber.Value = ""
                .HierarchicalLevelCode.Value = "20"
                .HierarchicalChildCode.Value = "1"
            End With


            ''With l2000A.PRV
            ''    .ProviderCode.Value = "PT"
            ''    .ReferenceIdentificationQualifier.Value = "ZZ"
            ''    .ReferenceIdentification.Value = "213EP1101X"
            ''End With

            With l2000A.L2010AA_837PRO1.NM1
                .EntityIdentifierCode1.Value = "85"
                If (lBillingProvider.BillingProvider.FirstName <> "") Then
                    .EntityTypeQualifier.Value = "1"
                Else
                    .EntityTypeQualifier.Value = "2"
                End If
                .NameLastOrOrganizationName.Value = lBillingProvider.BillingProvider.LastName  '"Palm Desert Urgent Care"
                .NameFirst.Value = lBillingProvider.BillingProvider.FirstName
                .NameMiddle.Value = lBillingProvider.BillingProvider.MiddleName
                .NamePrefix.Value = ""
                .NameSuffix.Value = ""
                .IdentificationCodeQualifier.Value = "XX"
                .IdentificationCode.Value = lBillingProvider.BillingProvider.NPI
                .EntityRelationshipCode.Value = ""
                .EntityIdentifierCode2.Value = ""
            End With

            With l2000A.L2010AA_837PRO1.N3
                .AddressInformation1.Value = lBillingProvider.BillingProvider.AddressLine1 'lClinic.Clinic.AddressLine1  '"PO Box 1118"
                .AddressInformation2.Value = lBillingProvider.BillingProvider.AddressLine2 'lClinic.Clinic.AddressLine2
            End With

            With l2000A.L2010AA_837PRO1.N4
                .CityName.Value = lBillingProvider.BillingProvider.City 'lClinic.Clinic.City  '"Palm Desert"
                .StateOrProvinceCode.Value = lBillingProvider.BillingProvider.State
                .PostalCode.Value = lBillingProvider.BillingProvider.ZipCode
                .CountryCode.Value = ""
                .LocationQualifier.Value = ""
                .LocationIdentifier.Value = ""
            End With

            Dim lRef As SegREF


            lRef = l2000A.L2010AA_837PRO1.REF1.Append
            With lRef

                .ReferenceIdentificationQualifier.Value = "EI"
                .ReferenceIdentification.Value = lBillingProvider.BillingProvider.TaxID  'lClinic.Clinic.FacilityCode '
                .Description.Value = ""


            End With

            '************************ 2000A Billing Provider End






            ''****************************************************
            ''****************************************************
            ''****************************************************
            ''*************************************** Loop WOrk STart Claim Batch ************************************
            For Each lHcfaID As Int32 In pClaimId
                lSubscriberHL = lSubscriberHL - 1
                Dim lHcfa As New HCFA(pUser.ConnectionString)
                lHcfa.HCFA.HCFAID = lHcfaID
                lHcfa.GetRecordByID()

                Dim pHCFADB As New HCFADB
                pHCFADB = lHcfa.HCFA

                Dim pPatientCPTCol As PatientCPTColl = LoadClaimCpt(pHCFADB.PatientSuperBillID)

                Dim lPrimaryInsuraneSelf As Boolean = False
                Dim lSecondaryInsuraneSelf As Boolean = False
                Dim lPrimaryInsuranceExist As Boolean = False
                Dim lSecondaryInsuranceExist As Boolean = False
                Dim lPrimaryInsuranceCompanyId As Int32 = 0
                Dim lSecondaryInsuranceCompanyId As Int32 = 0
                Dim lPatient As New PatientExtended(pUser.ConnectionString)
                lPatient.Patient.PatientID = pHCFADB.PatientAccountNumber
                lPatient.GetPatientWithDetailsByID()
                Dim lPrimaryInsurerPatient As New PatientExtended(pUser.ConnectionString)
                Dim lPrimaryInsuranceCompany As New Insurance(pUser.ConnectionString)
                Dim lSecondaryInsurerPatient As New PatientExtended(pUser.ConnectionString)
                Dim lSecondaryInsuranceCompany As New Insurance(pUser.ConnectionString)
                Dim lClaimId As String = ""

                Dim lMainInsurance As New PatientInsuranceDetail(pUser.ConnectionString)
                Dim lOtherInsurance As New PatientInsuranceDetail(pUser.ConnectionString)

                Dim lMainInsuranceSelf As Boolean = False
                Dim lOtherInsuranceSelf As Boolean = False
                Dim lMainInsuranceExist As Boolean = False
                Dim lOtherInsuranceExist As Boolean = False


                '''''''''''''' Main Insurance And Insurer Checking Logic
                If (lMainInsurance.GetRecordForEDI(pHCFADB.MainInsID)) Then
                    lMainInsuranceExist = True
                Else
                    lMainInsuranceExist = False
                End If

                If (lMainInsuranceExist) Then
                    If (lMainInsurance.PatientInsuranceDetail.PInsurance.InsurerId <> 0) Then
                        lMainInsuranceSelf = False
                    Else
                        lMainInsuranceSelf = True
                    End If
                End If

                '''''''''''''' Main Insurance And Insurer Checking Logic

                '''''''''''''' Other Insurance And Insurer Checking Logic
                If (lOtherInsurance.GetRecordForEDI(pHCFADB.OtherInsID)) Then
                    lOtherInsuranceExist = True
                Else
                    lOtherInsuranceExist = False
                End If

                If (lOtherInsuranceExist) Then
                    If (lOtherInsurance.PatientInsuranceDetail.PInsurance.InsurerId <> 0) Then
                        lOtherInsuranceSelf = False
                    Else
                        lOtherInsuranceSelf = True
                    End If
                End If

                '''''''''''''' Other Insurance And Insurer Checking Logic






                Dim lConnection As New Connection(pUser.ConnectionString)

                Dim lQuery As String
                lQuery = "Exec GetMultipleTableForClaimEDI " & pUser.ClinicId & "," & IIf(pHCFADB.RefferingProviderID <> "", pHCFADB.RefferingProviderID, 0) & "," & pHCFADB.DoctorUserID & "," & lPrimaryInsuranceCompanyId & "," & lSecondaryInsuranceCompanyId & "," & pHCFADB.FacilityId


                Dim lDs As New DataSet
                lDs = lConnection.ExecuteQuery(lQuery)



                Dim lReferringProvider As New ReferringProvider(pUser.ConnectionString)
                lReferringProvider.GetRecordByID(lDs.Tables(1))

                Dim lRenderingProvider As New Employee(pUser.ConnectionString)
                lRenderingProvider.GetRecordByID(lDs.Tables(2))




                Dim lFacility As New Facility(pUser.ConnectionString)
                If (Not lDs.Tables(5) Is Nothing) Then
                    lFacility.GetRecordById(lDs.Tables(5))
                End If


                '************************ 2000B Subscriber Starts 

                Dim l2000B As Grp837_PROL2000B_837PRO
                l2000B = l2000A.L2000B_837PRO.Append()


                With l2000B.HL_5
                    lLastHL = lLastHL + 1
                    .HierarchicalIdNumber.Value = lLastHL
                    .HierarchicalParentIdNumber.Value = "1"
                    .HierarchicalLevelCode.Value = "22"
                    If (lSubscriberHL > 0) Then
                        If (lMainInsuranceSelf) Then
                            .HierarchicalChildCode.Value = "0"
                        Else
                            .HierarchicalChildCode.Value = "1"
                        End If
                    ElseIf (Not lMainInsuranceSelf) Then
                        .HierarchicalChildCode.Value = "1"
                    Else
                        .HierarchicalChildCode.Value = "0"
                    End If

                End With


                With l2000B.SBR
                    .PayerResponsibilitySequenceNumberCode.Value = "P"
                    If (lMainInsuranceSelf) Then
                        .IndividualRelationshipCode.Value = "18"
                    Else
                        .IndividualRelationshipCode.Value = ""
                        'Select Case lPatient.Patient.PrimaryInsurance.RelationshipToPrimaryInsurer.ToUpper
                        '    Case "SPOUSE"
                        '        .IndividualRelationshipCode.Value = "01"
                        '    Case "CHILD"
                        '        .IndividualRelationshipCode.Value = "19"
                        '    Case "OTHER"
                        '        .IndividualRelationshipCode.Value = "G8"
                        'End Select
                    End If
                    .ReferenceIdentification.Value = lMainInsurance.PatientInsuranceDetail.PInsurance.GroupNo
                    .SubscriberName.Value = lMainInsurance.PatientInsuranceDetail.PInsurance.PlanName  '""

                    If (.PayerResponsibilitySequenceNumberCode.Value <> "P" And pHCFADB.Type1.ToUpper = "MEDICARE") Then
                        .InsuranceTypeCode.Value = "" 'type of insurance policy within specified program
                    Else
                        .InsuranceTypeCode.Value = ""
                    End If
                    .CoordinationOfBenefitsCode.Value = ""
                    .YesNoConditionOrResponseCode.Value = ""
                    .EmploymentStatusCode.Value = ""
                    If (lMainInsurance.PatientInsuranceDetail.InsuranceCompany.CompanyName.ToUpper.Contains("BLUE CROSS") Or lMainInsurance.PatientInsuranceDetail.InsuranceCompany.CompanyName.ToUpper.Contains("BLUE SHIELD")) Then
                        .ClaimFilingIndicatorCode.Value = "BL"
                    Else
                        Select Case lMainInsurance.PatientInsuranceDetail.InsuranceCompany.CompanyName.ToUpper
                            Case "MEDICARE"
                                .ClaimFilingIndicatorCode.Value = "MB"
                            Case "MEDICAID"
                                .ClaimFilingIndicatorCode.Value = "MC"
                            Case "CHAMPUS"
                                .ClaimFilingIndicatorCode.Value = "CH"
                            Case "OTHER"
                                .ClaimFilingIndicatorCode.Value = "CI"
                            Case Else
                                .ClaimFilingIndicatorCode.Value = "CI"
                        End Select
                    End If
                End With

                ''''''''' Discussion Needed
                'Required if the subscriber is the same person as the patient (Loop ID- 
                '2000B SBR02=18), and information in this PAT segment (date of   
                'death, and/or patient weight) is necessary to file the claim/encounter
                '(see PAT05, 06, 07, and 08).

                '' '' ''If (pHCFADB.PatientRelationshipToInsured <> "SELF") Then
                '' '' ''    With l2000B.PAT

                '' '' ''    End With
                '' '' ''End If
                ''''''''' Discussion Needed


                '******************** Start 2010BA Subscriber Name
                If (lMainInsuranceSelf) Then ''''''''''MAIN IF
                    ''''''''' If Patient is Subscriber Fisrst Block'''''''''''''''
                    With l2000B.L2010BA_837PRO1.NM1
                        .EntityIdentifierCode1.Value = "IL"
                        .EntityTypeQualifier.Value = "1"
                        .NameLastOrOrganizationName.Value = lPatient.Patient.LastName  '"Benjamin"
                        .NameFirst.Value = lPatient.Patient.FirstName  '"Melva"
                        .NameMiddle.Value = lPatient.Patient.MiddleName  '"K"
                        .NamePrefix.Value = ""
                        .NameSuffix.Value = ""
                        .IdentificationCodeQualifier.Value = "MI"
                        .IdentificationCode.Value = lMainInsurance.PatientInsuranceDetail.PInsurance.SubscriberID  'pHCFADB.InsuredIDNumber '"488129918D"
                        .EntityRelationshipCode.Value = ""
                        .EntityIdentifierCode2.Value = ""
                    End With

                    With l2000B.L2010BA_837PRO1.N3
                        .AddressInformation1.Value = lPatient.Patient.AddressLine1  '"74551 Columbian Drive"
                        .AddressInformation2.Value = lPatient.Patient.AddressLine2  '"74551 Columbian Drive"
                    End With

                    With l2000B.L2010BA_837PRO1.N4
                        If (lPatient.Patient.City = "") Then
                            .CityName.Value = "Palm Desert"
                        Else
                            .CityName.Value = lPatient.Patient.City   '"Palm Desert"
                        End If
                        .StateOrProvinceCode.Value = lPatient.Patient.IsDeleted  '"CA"
                        .PostalCode.Value = lPatient.Patient.ZipCode  '"92260"
                        .CountryCode.Value = ""
                        .LocationQualifier.Value = ""
                        .LocationIdentifier.Value = ""
                    End With

                    With l2000B.L2010BA_837PRO1.DMG
                        .DateTimePeriodFormatQualifier.Value = "D8"
                        .DateTimePeriod.Value = Convert.ToDateTime(lPatient.Patient.DOB).ToString("yyyyMMdd") '"19240131"
                        .GenderCode.Value = lPatient.Patient.Gender.Substring(0, 1)
                        .MaritalStatusCode.Value = ""
                        .RaceOrEthnicityCode.Value = ""
                        .CitizenshipStatusCode.Value = ""
                        .CountryCode.Value = ""
                        .BasisOfVerificationCode.Value = ""
                        '.Quantity.
                    End With
                    ''''''''' If first Block'''''''''''''''
                Else '''''''''''''Main IF
                    ''''''''' If Patient is Not Subscriber Second Block'''''''''''''''
                    With l2000B.L2010BA_837PRO1.NM1
                        .EntityIdentifierCode1.Value = "IL"
                        .EntityTypeQualifier.Value = "1"
                        .NameLastOrOrganizationName.Value = lMainInsurance.PatientInsuranceDetail.Insurer.LastName 'lPrimaryInsurerPatient.Patient.LastName  ''"Benjamin"
                        .NameFirst.Value = lMainInsurance.PatientInsuranceDetail.Insurer.FirstName   '"Melva"
                        .NameMiddle.Value = lMainInsurance.PatientInsuranceDetail.Insurer.MiddleName   '"K"
                        .NamePrefix.Value = ""
                        .NameSuffix.Value = ""
                        .IdentificationCodeQualifier.Value = "MI"
                        .IdentificationCode.Value = lMainInsurance.PatientInsuranceDetail.PInsurance.SubscriberID  ''"488129918D"
                        .EntityRelationshipCode.Value = ""
                        .EntityIdentifierCode2.Value = ""
                    End With

                    With l2000B.L2010BA_837PRO1.N3
                        .AddressInformation1.Value = lMainInsurance.PatientInsuranceDetail.Insurer.AddressLine1  '"74551 Columbian Drive"
                        .AddressInformation2.Value = lMainInsurance.PatientInsuranceDetail.Insurer.AddressLine2
                    End With

                    With l2000B.L2010BA_837PRO1.N4
                        If (lMainInsurance.PatientInsuranceDetail.Insurer.City = "") Then
                            .CityName.Value = "Palm Desert"
                        Else
                            .CityName.Value = lMainInsurance.PatientInsuranceDetail.Insurer.City  '"Palm Desert"
                        End If
                        .StateOrProvinceCode.Value = lMainInsurance.PatientInsuranceDetail.Insurer.StateID   '"CA"
                        .PostalCode.Value = lMainInsurance.PatientInsuranceDetail.Insurer.ZipCode  '"92260"
                        .CountryCode.Value = ""
                        .LocationQualifier.Value = ""
                        .LocationIdentifier.Value = ""
                    End With

                    ''''''''' If first Block'''''''''''''''
                End If
                '******************** End 2010BA Subscriber


                '******************** Start Payer Name 2010BB 
                With l2000B.L2010BB_837PRO.NM1
                    .EntityIdentifierCode1.Value = "PR"
                    .EntityTypeQualifier.Value = "2"

                    If (lMainInsurance.PatientInsuranceDetail.InsuranceCompany.CompanyName.Length > 35) Then
                        .NameLastOrOrganizationName.Value = lMainInsurance.PatientInsuranceDetail.InsuranceCompany.CompanyName.Substring(0, 34) '"MEDICARE"
                    Else
                        .NameLastOrOrganizationName.Value = lMainInsurance.PatientInsuranceDetail.InsuranceCompany.CompanyName '"MEDICARE"
                    End If

                    .NameFirst.Value = ""
                    .NameMiddle.Value = ""
                    .NamePrefix.Value = ""
                    .NameSuffix.Value = ""
                    .IdentificationCodeQualifier.Value = "PI"
                    .IdentificationCode.Value = lMainInsurance.PatientInsuranceDetail.InsuranceCompany.PayerID.PadLeft(5, "0") '"CMSEL"
                    .EntityRelationshipCode.Value = ""
                    .EntityIdentifierCode2.Value = ""
                End With

                With l2000B.L2010BB_837PRO.N3
                    .AddressInformation1.Value = lMainInsurance.PatientInsuranceDetail.InsuranceCompany.AddressLine1 '"PO Box 272852"
                    .AddressInformation2.Value = lMainInsurance.PatientInsuranceDetail.InsuranceCompany.AddressLine2 '""
                End With

                With l2000B.L2010BB_837PRO.N4
                    If (lMainInsurance.PatientInsuranceDetail.InsuranceCompany.City <> "") Then
                        .CityName.Value = lMainInsurance.PatientInsuranceDetail.InsuranceCompany.City
                    Else
                        .CityName.Value = "Chico"
                    End If
                    .StateOrProvinceCode.Value = lMainInsurance.PatientInsuranceDetail.InsuranceCompany.State '"CA"
                    .PostalCode.Value = lMainInsurance.PatientInsuranceDetail.InsuranceCompany.ZipCode '"95927"
                    .CountryCode.Value = ""
                    .LocationQualifier.Value = ""
                    .LocationIdentifier.Value = ""
                End With
                '******************** Start Payer Name 2010BB 
                '******************** END  Loop 2000B 

                If (lMainInsuranceSelf) Then
                    Dim l2300 As ClaimLibrary.Grp837_PROL2300_837PRO1
                    l2300 = l2000B.L2300_837PRO1.Append

                    'BuildClaim2300(l2000B.L2300_837PRO1.Append, pUser, pHCFADB, pPatientCPTCol, lReferringProvider, True)
                    BuildClaim2300New(l2300, pUser, pHCFADB, pPatientCPTCol, lReferringProvider, lRenderingProvider, lClinic, lPatient, lFacility, lBillingProvider, lMainInsurance)
                Else
                    '******************** Start Patient Hierarchical Level 2000C 
                    Dim l2000C As Grp837_PROL2000C_837PRO
                    l2000C = l2000B.L2000C_837PRO.Append()

                    With l2000C.HL_3
                        lLastHL = lLastHL + 1
                        .HierarchicalIdNumber.Value = lLastHL
                        .HierarchicalParentIdNumber.Value = lLastHL - 1
                        .HierarchicalLevelCode.Value = "23"
                        .HierarchicalChildCode.Value = "0"
                    End With

                    With l2000C.PAT
                        Select Case pHCFADB.PatientRelationshipToInsured.ToUpper
                            Case "SPOUSE"
                                .IndividualRelationshipCode.Value = "01"
                            Case "CHILD"
                                .IndividualRelationshipCode.Value = "19"
                            Case "OTHER"
                                .IndividualRelationshipCode.Value = "G8"
                            Case Else
                                .IndividualRelationshipCode.Value = "01"
                        End Select
                        '.PatientLocationCode = ""
                        '.EmploymentStatusCode = ""
                        '.StudentStatusCode = ""
                        '.DateTimePeriodFormatQualifier = ""
                        '.DateTimePeriod = ""
                        '.UnitOrBasisForMeasurementCode = ""
                        '.Weight = ""
                        '.YesNoConditionOrResponseCode = ""
                    End With

                    With l2000C.L2010CA_837PRO.NM1
                        .EntityIdentifierCode1.Value = "QC"
                        .EntityTypeQualifier.Value = "1"
                        .NameLastOrOrganizationName.Value = lPatient.Patient.LastName  '"Benjamin"
                        .NameFirst.Value = lPatient.Patient.FirstName  '"Melva"
                        .NameMiddle.Value = lPatient.Patient.MiddleName  '"K"
                        .NamePrefix.Value = ""
                        .NameSuffix.Value = ""
                        '.IdentificationCodeQualifier.Value = "MI"
                        '.IdentificationCode.Value = pHCFADB.InsuredIDNumber '"488129918D"
                        '.EntityRelationshipCode.Value = ""
                        '.EntityIdentifierCode2.Value = ""
                    End With

                    With l2000C.L2010CA_837PRO.N3
                        .AddressInformation1.Value = lPatient.Patient.AddressLine1  '"74551 Columbian Drive"
                        .AddressInformation2.Value = lPatient.Patient.AddressLine2  '"74551 Columbian Drive"
                    End With

                    With l2000C.L2010CA_837PRO.N4
                        If (lPatient.Patient.City = "") Then
                            .CityName.Value = "Palm Desert"
                        Else
                            .CityName.Value = lPatient.Patient.City   '"Palm Desert"
                        End If
                        .StateOrProvinceCode.Value = lPatient.Patient.IsDeleted  '"CA"
                        .PostalCode.Value = lPatient.Patient.ZipCode  '"92260"
                        .CountryCode.Value = ""
                        .LocationQualifier.Value = ""
                        .LocationIdentifier.Value = ""
                    End With

                    With l2000C.L2010CA_837PRO.DMG
                        .DateTimePeriodFormatQualifier.Value = "D8"
                        .DateTimePeriod.Value = Convert.ToDateTime(lPatient.Patient.DOB).ToString("yyyyMMdd") '"19240131"
                        .GenderCode.Value = lPatient.Patient.Gender.Substring(0, 1)
                        .MaritalStatusCode.Value = ""
                        .RaceOrEthnicityCode.Value = ""
                        .CitizenshipStatusCode.Value = ""
                        .CountryCode.Value = ""
                        .BasisOfVerificationCode.Value = ""
                        '.Quantity.
                    End With
                    'lRef = l2000B.L2300_837PRO1.REF
                    '' '' ''With lRef
                    '' '' ''    .ReferenceIdentification = ""
                    '' '' ''    .ReferenceIdentificationQualifier = ""
                    '' '' ''End With
                    '******************** END Patient Hierarchical Level 2000C 
                    Dim l2300 As ClaimLibrary.Grp837_PROL2300_837PRO2
                    l2300 = l2000C.L2300_837PRO2.Append
                    BuildClaim2300New(l2300, pUser, pHCFADB, pPatientCPTCol, lReferringProvider, lRenderingProvider, lClinic, lPatient, lFacility, lBillingProvider, lMainInsurance)
                End If
            Next
            ''*************************************** Loop WOrk END Claim Batch
            ''****************************************************
            ''****************************************************
            ''****************************************************


            ''''''''' clm 2300 start

            ''''''''' clm 2300 start

            'lClaimId = "CL" & pUser.ClinicId & "H" & Convert.ToDateTime(pHCFADB.HCFAPreparedDate).Year & Convert.ToDateTime(pHCFADB.HCFAPreparedDate).ToString("MM") & pHCFADB.HCFADisplayID.PadLeft(5, "0")


            lEDIMessage = lInterChange.Parse()

            lCurrentFilePath = SaveToFile(lEDIMessage, pBatchDisplayID & ".txt")

            If (lCurrentFilePath <> "") Then
                lCurrentFileResult = True
            Else
                lCurrentFileResult = False
            End If

            If (lCurrentFileResult) Then
                lSendGatewayResult = SendToGatewayEDI(lCurrentFilePath)
            Else
                lCurrentFileResult = False
                lSendGatewayResult = False
            End If

            If (Not lSendGatewayResult) Then
                lEDIMessage = ""
            ElseIf (lSendGatewayResult) Then
                lFileArchiveResult = MoveToArchive(lCurrentFilePath)
            End If

            Return lEDIMessage
        Catch ex As Exception
            Return ""
        End Try


    End Function

    Public Shared Sub BuildClaim2300New(ByRef l2300 As Object, ByRef pUser As User, ByRef pHCFADB As HCFADB, ByRef pPatientCPTCol As PatientCPTColl, ByRef lReferringProvider As ReferringProvider, ByRef lRenderingProvider As Employee, ByRef lClinic As Clinic, ByRef lPatient As PatientExtended, ByRef lfacility As Facility, ByRef pBillingProvider As BillingProvider, ByVal pMainInsurance As PatientInsuranceDetail)
        Dim lRef As SegREF



        Dim lOtherInsurance As New PatientInsuranceDetail(pUser.ConnectionString)


        Dim lOtherInsuranceSelf As Boolean = False
        Dim lOtherInsuranceExist As Boolean = False
        Dim lMainInsuranceSelf As Boolean = False

        If (pMainInsurance.PatientInsuranceDetail.PInsurance.InsurerId <> 0) Then
            lMainInsuranceSelf = False
        Else
            lMainInsuranceSelf = True
        End If


        '''''''''''''' Other Insurance And Insurer Checking Logic
        If (lOtherInsurance.GetRecordForEDI(pHCFADB.OtherInsID)) Then
            lOtherInsuranceExist = True
        Else
            lOtherInsuranceExist = False
        End If

        If (lOtherInsuranceExist) Then
            If (lOtherInsurance.PatientInsuranceDetail.PInsurance.InsurerId <> 0) Then
                lOtherInsuranceSelf = False
            Else
                lOtherInsuranceSelf = True
            End If
        End If
        '''''''''''''' Other Insurance And Insurer Checking Logic


        ''Dim lPRV As SegPRV
        'Dim l2300 As ClaimLibrary.Grp837_PROL2300_837PRO2
        'Dim test1 As ClaimLibrary.Grp837_PROL2300_837PRO2
        'l2300 = CType(l2300, ClaimLibrary..Grp837_PROL2300_837PRO2)
        'If (pPrimarySelf) Then

        '    l2300 = CType(p2300, ClaimLibrary.Grp837_PROL2300_837PRO1)
        'Else
        '    l2300 = CType(l2300, ClaimLibrary.Grp837_PROL2300_837PRO2)
        'End If


        With l2300.CLM
            '.ClaimSubmittersIdentifier.Value = pHCFADB.HCFADisplayID.PadLeft(6, "0")
            .ClaimSubmittersIdentifier.Value = "CL" & pUser.ClinicId & "H" & Convert.ToDateTime(pHCFADB.HCFAPreparedDate).Year & Convert.ToDateTime(pHCFADB.HCFAPreparedDate).ToString("MM") & pHCFADB.HCFADisplayID.PadLeft(5, "0")
            .MonetaryAmount.Value = pHCFADB.TotalCharge
            .ClaimFillingIndicatorCode.Value = ""
            .NonInstitutionalClaimTypeCode.Value = ""

            .HealthCareServiceLocationInformation.FacilityCodeValue.Value = "11"
            .HealthCareServiceLocationInformation.FacilityCodeQualifier.Value = ""
            .HealthCareServiceLocationInformation.ClaimFrequencyTypeCode.Value = "1"

            .YesNoConditionOrResponseCode1.Value = "Y"
            .ProviderAcceptAssignmentCode.Value = "A"
            .YesNoConditionOrResponseCode2.Value = "Y"
            .ReleaseOfInformationCode.Value = "Y"
            .PatientSignatureSourceCode.Value = "B"

            'Block 10 a,b,c
            '.RelatedCausesInformation.RelatedCausesCode1.Value = ""
            '.RelatedCausesInformation.StateOrProvinceCode = ""
            '.SpecialProgramCode.Value = ""
            '.YesNoConditionOrResponseCode3.Value = ""
            '.LevelOfServiceCode.Value = ""
            '.YesNoConditionOrResponseCode4.Value = ""
            '.ProviderAgreementCode.Value = ""
            '.ClaimStatusCode.Value = ""
            '.YesNoConditionOrResponseCode5.Value = ""
            '.ClaimSubmissionReasonCode.Value = ""
            '.DelayReasonCode.Value = ""

        End With

        ''**************************************************************************************
        '' **************** For authorization Number **************** 08-sept-2010 *** START ***
        Dim lRef4 As SegREF
        lRef4 = l2300.REF4.Append()

        If (lMainInsuranceSelf AndAlso pMainInsurance.PatientInsuranceDetail.PInsurance.AuthorizationNumber <> "") Then
            With lRef4
                .ReferenceIdentificationQualifier.Value = "G1"
                .ReferenceIdentification.Value = pMainInsurance.PatientInsuranceDetail.PInsurance.AuthorizationNumber
                .Description.Value = ""
            End With
        ElseIf Not (lMainInsuranceSelf AndAlso pMainInsurance.PatientInsuranceDetail.IInsurance.AuthorizationNumber <> "") Then
            With lRef4
                .ReferenceIdentificationQualifier.Value = "G1"
                .ReferenceIdentification.Value = pMainInsurance.PatientInsuranceDetail.IInsurance.AuthorizationNumber
                .Description.Value = ""
            End With
        End If
        '' **************** For authorization Number **************** 08-sept-2010 *** END *****
        ''**************************************************************************************

        If (pHCFADB.ICD1 <> "") Then
            With l2300.HI.HealthCareCodeInformation1
                .CodeListQualifierCode.Value = "BK"
                If (pHCFADB.ICD1.Contains(".")) Then
                    .IndustryCode.Value = pHCFADB.ICD1.Remove(pHCFADB.ICD1.IndexOf("."), 1)
                Else
                    .IndustryCode.Value = pHCFADB.ICD1
                End If

                'DateTimePeriodFormatQualifier()
                'DateTimePeriod()
                'MonetaryAmount()
                'Quantity()
                'VersionIdentifier()
            End With
        End If


        If (pHCFADB.ICD2 <> "") Then
            With l2300.HI.HealthCareCodeInformation2
                .CodeListQualifierCode.Value = "BF"
                If (pHCFADB.ICD2.Contains(".")) Then
                    .IndustryCode.Value = pHCFADB.ICD2.Remove(pHCFADB.ICD2.IndexOf("."), 1)
                Else
                    .IndustryCode.Value = pHCFADB.ICD2
                End If
            End With
        End If

        If (pHCFADB.ICD3 <> "") Then
            With l2300.HI.HealthCareCodeInformation3
                .CodeListQualifierCode.Value = "BF"
                If (pHCFADB.ICD3.Contains(".")) Then
                    .IndustryCode.Value = pHCFADB.ICD3.Remove(pHCFADB.ICD3.IndexOf("."), 1)
                Else
                    .IndustryCode.Value = pHCFADB.ICD3
                End If
            End With
        End If

        If (pHCFADB.ICD4 <> "") Then
            With l2300.HI.HealthCareCodeInformation4
                .CodeListQualifierCode.Value = "BF"
                If (pHCFADB.ICD4.Contains(".")) Then
                    .IndustryCode.Value = pHCFADB.ICD4.Remove(pHCFADB.ICD4.IndexOf("."), 1)
                Else
                    .IndustryCode.Value = pHCFADB.ICD4
                End If
            End With
        End If



        ''***********Start REFERIING PROVIDER*****************''''''''''
        Dim l2310A As ClaimLibrary.Grp837_PROL2310A_837PRO
        If (Not IsDBNull(pHCFADB.RefferingProviderID) AndAlso pHCFADB.RefferingProviderID <> "0" AndAlso pHCFADB.RefferingProviderID <> "") Then
            l2310A = l2300.L2310A_837PRO.Append
            With l2310A.NM1
                .EntityIdentifierCode1.Value = "DN"
                .EntityTypeQualifier.Value = "1"
                .NameLastOrOrganizationName.Value = lReferringProvider.ReferringProviderDB.LastName  '."Kazi"
                .NameFirst.Value = lReferringProvider.ReferringProviderDB.FirstName   '"Manzoor"
                .NameMiddle.Value = lReferringProvider.ReferringProviderDB.MiddleName '"A"
                .NamePrefix.Value = ""
                .NameSuffix.Value = ""
                .IdentificationCodeQualifier.Value = "XX"
                .IdentificationCode.Value = lReferringProvider.ReferringProviderDB.NPI  '"1225032212"
                .EntityRelationshipCode.Value = ""
                .EntityIdentifierCode2.Value = ""
            End With


            With l2310A.PRV
                .ProviderCode.Value = "RF"
                .ReferenceIdentificationQualifier.Value = "ZZ"
                .ReferenceIdentification.Value = lReferringProvider.ReferringProviderDB.Speciality  '"213EP1101X"
            End With

            '' '' '' ''lRef = l2300.L2310A_837PRO.REF.Append
            '' '' '' ''With lRef
            '' '' '' ''    .ReferenceIdentificationQualifier.Value = "1C"
            '' '' '' ''    .ReferenceIdentification.Value = "ZZZ18991Z"
            '' '' '' ''    .Description.Value = ""
            '' '' '' ''End With
        End If
        ''***********End REFERIING PROVIDER*****************''''''''''


        ''***********RENDERING PROVIDER*****************''''''''''
        With l2300.L2310B_837PRO.NM1
            .EntityIdentifierCode1.Value = "82"
            .EntityTypeQualifier.Value = "1"
            .NameLastOrOrganizationName.Value = lRenderingProvider.Employee.LastName
            .NameFirst.Value = lRenderingProvider.Employee.FirstName
            .NameMiddle.Value = lRenderingProvider.Employee.MiddleName
            .NamePrefix.Value = ""
            .NameSuffix.Value = ""
            .IdentificationCodeQualifier.Value = "XX"
            .IdentificationCode.Value = lRenderingProvider.Employee.NPI '"1376629261"
            .EntityRelationshipCode.Value = ""
            .EntityIdentifierCode2.Value = ""
        End With

        With l2300.L2310B_837PRO.PRV
            .ProviderCode.Value = "PE"
            .ReferenceIdentificationQualifier.Value = "ZZ"
            .ReferenceIdentification.Value = lRenderingProvider.Employee.SpecialityCode '"213EP1101X"
        End With


        ''lRef = l2300.L2310B_837PRO.REF.Append
        ''With lRef
        ''    .ReferenceIdentificationQualifier.Value = "EI"
        ''    .ReferenceIdentification.Value = "330967624" 'lClinic.Clinic.FacilityCode '
        ''    .Description.Value = ""
        ''End With

        ''If (pPatientCPTCol.Item(0).COB <> "" And (pPatientCPTCol.Item(0).PrescriberLicenceID <> "")) Then
        ''    lRef = l2300.L2310B_837PRO.REF.Append
        ''    With lRef
        ''        .ReferenceIdentificationQualifier.Value = pPatientCPTCol.Item(0).COB
        ''        .ReferenceIdentification.Value = pPatientCPTCol.Item(0).PrescriberLicenceID
        ''        .Description.Value = ""
        ''    End With
        ''End If
        ''***********RENDERING PROVIDER*****************''''''''''


        ''***********Service facility*****************''''''''''
        If (pHCFADB.FacilityProvider <> pBillingProvider.BillingProvider.NPI And pHCFADB.FacilityProvider <> "") Then

            With l2300.L2310D_837PRO.NM1
                .EntityIdentifierCode1.Value = "FA"
                .EntityTypeQualifier.Value = "2"
                .NameLastOrOrganizationName.Value = lfacility.FacilityDB.FacilityName   '."Kazi"
                '.NameFirst.Value = lReferringProvider.ReferringProviderDB.FirstName   '"Manzoor"
                '.NameMiddle.Value = lReferringProvider.ReferringProviderDB.MiddleName '"A"
                '.NamePrefix.Value = ""
                '.NameSuffix.Value = ""
                .IdentificationCodeQualifier.Value = "XX"
                .IdentificationCode.Value = pHCFADB.FacilityProvider  '"1225032212"
                '.EntityRelationshipCode.Value = ""
                '.EntityIdentifierCode2.Value = ""
            End With

            With l2300.L2310D_837PRO.N3
                .AddressInformation1.Value = lfacility.FacilityDB.AddressLine1    '"74551 Columbian Drive"
                .AddressInformation2.Value = lfacility.FacilityDB.AddressLine2  '"74551 Columbian Drive"
            End With

            With l2300.L2310D_837PRO.N4
                If (lfacility.FacilityDB.City = "") Then
                    .CityName.Value = "Palm Desert"
                Else
                    .CityName.Value = lfacility.FacilityDB.City   '"Palm Desert"
                End If
                .StateOrProvinceCode.Value = lfacility.FacilityDB.State   '"CA"
                .PostalCode.Value = lfacility.FacilityDB.ZipCode   '"92260"
                '.CountryCode.Value = ""
                '.LocationQualifier.Value = ""
                '.LocationIdentifier.Value = ""
            End With

            If (pHCFADB.FacilitySecondaryIdentificationQualifier <> "" And pHCFADB.FacilityCode <> "") Then
                lRef = l2300.L2310D_837PRO.REF.Append
                With lRef
                    .ReferenceIdentificationQualifier.Value = pHCFADB.FacilitySecondaryIdentificationQualifier
                    .ReferenceIdentification.Value = pHCFADB.FacilityCode
                    '.Description.Value = ""
                End With
            End If
        End If
        ''***********Service facility*****************''''''''''


        If (lOtherInsuranceExist) Then
            ''''''''''''' other insurance loop''''''''
            Dim l2320 As ClaimLibrary.Grp837_PROL2320_837PRO
            l2320 = l2300.L2320_837PRO.Append()
            BuildClaim2320New(l2320, pUser, pHCFADB, pPatientCPTCol, lReferringProvider, lRenderingProvider, lClinic, lPatient, lOtherInsurance, lOtherInsuranceExist, lOtherInsuranceSelf, lfacility)
            ''''''''''''' other insurance loop''''''''
        End If



        Dim l2400 As Grp837_PROL2400_837PRO

        Dim i As Int32

        For i = 0 To pPatientCPTCol.Count - 1
            l2400 = l2300.L2400_837PRO.Append

            With l2400.LX
                .AssignedNumber.Value = i + 1
            End With

            With l2400.SV1
                .CompositeMedicalProcedureIdentifier.ProductServiceIdQualifier.Value = "HC"
                .CompositeMedicalProcedureIdentifier.ProductServiceId.Value = pPatientCPTCol.Item(i).Code  '"94640"
                .CompositeMedicalProcedureIdentifier.ProcedureModifier1.Value = pPatientCPTCol.Item(i).ModifierA
                .CompositeMedicalProcedureIdentifier.ProcedureModifier2.Value = pPatientCPTCol.Item(i).ModifierB
                .CompositeMedicalProcedureIdentifier.ProcedureModifier3.Value = pPatientCPTCol.Item(i).ModifierC
                .CompositeMedicalProcedureIdentifier.ProcedureModifier4.Value = pPatientCPTCol.Item(i).ModifierD
                .CompositeMedicalProcedureIdentifier.Description.Value = ""


                Try
                    .MonetaryAmount1.Value = Convert.ToDouble(pPatientCPTCol.Item(i).Charges) * Convert.ToInt32(pPatientCPTCol.Item(i).Days) '97.16
                Catch ex As Exception
                    .MonetaryAmount1.Value = pPatientCPTCol.Item(i).Charges
                End Try
                .UnitOrBasisForMeasurementCode.Value = "UN"
                .Quantity.Value = pPatientCPTCol.Item(i).Days

                '' ********Change by Fareed on 8th june 2010*********
                '' Requirement of additional Facility codes other than 11 on service(CPT) level
                '' still 11(Office) is hard coded for facility type at CLM level as at claim level it should be picked from facility data where facility type code is not saved presently
                '' At service level this field in only populated if facility type code is other than 11
                If (pPatientCPTCol.Item(i).POS <> "11") Then
                    .FacilityCodeValue.Value = pPatientCPTCol.Item(i).POS
                Else
                    .FacilityCodeValue.Value = ""
                End If
                '' ********END Change by Fareed on 8th june 2010*********

                .ServiceTypeCode.Value = ""


                If (pPatientCPTCol.Item(i).Pointer <> "") Then
                    Dim length As Int32 = pPatientCPTCol.Item(i).Pointer.Length
                    .CompositeDiagnosisCodePointer.DiagnosisCodePointer1.Value = pPatientCPTCol.Item(i).Pointer.Substring(0, 1)
                    length = length - 1
                    If (length > 0) Then
                        .CompositeDiagnosisCodePointer.DiagnosisCodePointer2.Value = pPatientCPTCol.Item(i).Pointer.Substring(1, 1)
                        length = length - 1
                    End If
                    If (length > 0) Then
                        .CompositeDiagnosisCodePointer.DiagnosisCodePointer3.Value = pPatientCPTCol.Item(i).Pointer.Substring(2, 1)
                        length = length - 1
                    End If
                    If (length > 0) Then
                        .CompositeDiagnosisCodePointer.DiagnosisCodePointer4.Value = pPatientCPTCol.Item(i).Pointer.Substring(3, 1)
                    End If
                End If


                'MonetaryAmount2()
                'YesNoConditionOrResponseCode1() used later
                'MultipleProcedureCode()
                'YesNoConditionOrResponseCode2() used later
                'YesNoConditionOrResponseCode3()
                'ReviewCode()
                'NationalOrLocalAssignedReviewValue()
                'CopayStatusCode()
                'HealthCareProfessionalShortageAreaCode()
                'ReferenceIdentification()
                'PostalCode()
                'MonetaryAmount3()
                'LevelOfCareCode()
                'ProviderAgreementCode()


            End With


            With l2400.DTP1
                .DateTimeQualifier.Value = "472"
                If (pPatientCPTCol.Item(i).DateOfServiceFrom <> "" And pPatientCPTCol.Item(i).DateOfServiceTo <> "") Then
                    .DateTimePeriodFormatQualifier.Value = "RD8"
                    .DateTimePeriod.Value = Convert.ToDateTime(pPatientCPTCol.Item(i).DateOfServiceFrom).ToString("yyyyMMdd") & "-" & Convert.ToDateTime(pPatientCPTCol.Item(i).DateOfServiceTo).ToString("yyyyMMdd")
                ElseIf (pPatientCPTCol.Item(i).DateOfServiceFrom <> "" And pPatientCPTCol.Item(i).DateOfServiceTo = "") Then
                    .DateTimePeriodFormatQualifier.Value = "D8"
                    .DateTimePeriod.Value = Convert.ToDateTime(pPatientCPTCol.Item(i).DateOfServiceFrom).ToString("yyyyMMdd")
                ElseIf (pPatientCPTCol.Item(i).DateOfServiceFrom = "" And pPatientCPTCol.Item(i).DateOfServiceTo <> "") Then
                    .DateTimePeriodFormatQualifier.Value = "D8"
                    .DateTimePeriod.Value = Convert.ToDateTime(pPatientCPTCol.Item(i).DateOfServiceTo).ToString("yyyyMMdd")
                End If

            End With
        Next

        '''''''''loop work



    End Sub

    Public Shared Sub BuildClaim2320New(ByRef l2320 As ClaimLibrary.Grp837_PROL2320_837PRO, ByRef pUser As User, ByRef pHCFADB As HCFADB, ByRef pPatientCPTCol As PatientCPTColl, ByRef lReferringProvider As ReferringProvider, ByRef lRenderingProvider As Employee, ByRef lClinic As Clinic, ByRef lPatient As PatientExtended, ByRef pOtherPatientInsDetail As PatientInsuranceDetail, ByVal pOtherInsuranceExist As Boolean, ByVal pOtherInsuranceSelf As Boolean, ByRef lFacility As Facility)
        With l2320.SBR
            .PayerResponsibilitySequenceNumberCode.Value = "S"
            Select Case pOtherPatientInsDetail.PatientInsuranceDetail.PInsurance.RelationshipToPrimaryInsurer.ToUpper
                Case "SELF"
                    .IndividualRelationshipCode.Value = "18"
                Case "SPOUSE"
                    .IndividualRelationshipCode.Value = "01"
                Case "CHILD"
                    .IndividualRelationshipCode.Value = "19"
                Case Else
                    .IndividualRelationshipCode.Value = "G8"
            End Select
            .ReferenceIdentification.Value = pOtherPatientInsDetail.PatientInsuranceDetail.PInsurance.GroupNo  '""
            .SubscriberName.Value = pOtherPatientInsDetail.PatientInsuranceDetail.PInsurance.PlanName  '""


            .InsuranceTypeCode.Value = "C1" 'type of insurance policy within specified program
            .CoordinationOfBenefitsCode.Value = ""
            .YesNoConditionOrResponseCode.Value = ""
            .EmploymentStatusCode.Value = ""
            If (pOtherPatientInsDetail.PatientInsuranceDetail.InsuranceCompany.CompanyName.ToUpper.Contains("BLUE CROSS") Or pOtherPatientInsDetail.PatientInsuranceDetail.InsuranceCompany.CompanyName.ToUpper.Contains("BLUE SHIELD")) Then
                .ClaimFilingIndicatorCode.Value = "BL"
            Else
                Select Case pOtherPatientInsDetail.PatientInsuranceDetail.InsuranceCompany.InsuranceType.ToUpper
                    Case "MEDICARE"
                        .ClaimFilingIndicatorCode.Value = "MB"
                    Case "MEDICAID"
                        .ClaimFilingIndicatorCode.Value = "MC"
                    Case "CHAMPUS"
                        .ClaimFilingIndicatorCode.Value = "CH"
                    Case "OTHER"
                        .ClaimFilingIndicatorCode.Value = "CI"
                    Case Else
                        .ClaimFilingIndicatorCode.Value = "CI"
                End Select
            End If
        End With

        If (pOtherInsuranceSelf) Then
            With l2320.DMG
                .DateTimePeriodFormatQualifier.Value = "D8"
                .DateTimePeriod.Value = Convert.ToDateTime(lPatient.Patient.DOB).ToString("yyyyMMdd") '"19240131"
                .GenderCode.Value = lPatient.Patient.Gender.Substring(0, 1)
                .MaritalStatusCode.Value = ""
                .RaceOrEthnicityCode.Value = ""
                .CitizenshipStatusCode.Value = ""
                .CountryCode.Value = ""
                .BasisOfVerificationCode.Value = ""
                '.Quantity.
            End With
        Else
            With l2320.DMG
                .DateTimePeriodFormatQualifier.Value = "D8"
                .DateTimePeriod.Value = Convert.ToDateTime(pOtherPatientInsDetail.PatientInsuranceDetail.Insurer.DOB).ToString("yyyyMMdd") '"19240131"
                .GenderCode.Value = pOtherPatientInsDetail.PatientInsuranceDetail.Insurer.Gender.Substring(0, 1).ToUpper
                .MaritalStatusCode.Value = ""
                .RaceOrEthnicityCode.Value = ""
                .CitizenshipStatusCode.Value = ""
                .CountryCode.Value = ""
                .BasisOfVerificationCode.Value = ""
                '.Quantity.
            End With
        End If

        With l2320.OI
            '.ClaimFilingIndicatorCode = ""
            '.ClaimSubmissionReasonCode = ""
            .YesNoConditionOrResponseCode.Value = "Y"
            .PatientSignatureSourceCode.Value = "B"
            '.ProviderAgreementCode = ""
            .ReleaseOfInformationCode.Value = "Y"
        End With

        If (pOtherInsuranceSelf) Then
            ' Patient information if secondary self
            With l2320.L2330A_837PRO.NM1
                .EntityIdentifierCode1.Value = "IL"
                .EntityTypeQualifier.Value = "1"
                .NameLastOrOrganizationName.Value = lPatient.Patient.LastName  '"Benjamin"
                .NameFirst.Value = lPatient.Patient.FirstName  '"Melva"
                .NameMiddle.Value = lPatient.Patient.MiddleName  '"K"
                .NamePrefix.Value = ""
                .NameSuffix.Value = ""
                .IdentificationCodeQualifier.Value = "MI"
                .IdentificationCode.Value = pOtherPatientInsDetail.PatientInsuranceDetail.PInsurance.SubscriberID 'pHCFADB.InsuredIDNumber '"488129918D"
                '.EntityRelationshipCode.Value = ""
                '.EntityIdentifierCode2.Value = ""
            End With

            With l2320.L2330A_837PRO.N3
                .AddressInformation1.Value = lPatient.Patient.AddressLine1  '"74551 Columbian Drive"
                .AddressInformation2.Value = lPatient.Patient.AddressLine2  '"74551 Columbian Drive"
            End With

            With l2320.L2330A_837PRO.N4
                .CityName.Value = lPatient.Patient.City   '"Palm Desert"
                .StateOrProvinceCode.Value = lPatient.Patient.IsDeleted  '"CA"
                .PostalCode.Value = lPatient.Patient.ZipCode  '"92260"
                '.CountryCode.Value = ""
                '.LocationQualifier.Value = ""
                '.LocationIdentifier.Value = ""
            End With
        Else
            With l2320.L2330A_837PRO.NM1
                .EntityIdentifierCode1.Value = "IL"
                .EntityTypeQualifier.Value = "1"
                .NameLastOrOrganizationName.Value = pOtherPatientInsDetail.PatientInsuranceDetail.Insurer.LastName  ''"Benjamin"
                .NameFirst.Value = pOtherPatientInsDetail.PatientInsuranceDetail.Insurer.FirstName  '"Melva"
                .NameMiddle.Value = pOtherPatientInsDetail.PatientInsuranceDetail.Insurer.MiddleName  '"K"
                .NamePrefix.Value = ""
                .NameSuffix.Value = ""
                .IdentificationCodeQualifier.Value = "MI"
                .IdentificationCode.Value = pOtherPatientInsDetail.PatientInsuranceDetail.PInsurance.SubscriberID ''"488129918D"
                '.EntityRelationshipCode.Value = ""
                '.EntityIdentifierCode2.Value = ""
            End With

            With l2320.L2330A_837PRO.N3
                .AddressInformation1.Value = pOtherPatientInsDetail.PatientInsuranceDetail.Insurer.AddressLine1  '"74551 Columbian Drive"
                .AddressInformation2.Value = pOtherPatientInsDetail.PatientInsuranceDetail.Insurer.AddressLine2
            End With

            With l2320.L2330A_837PRO.N4
                .CityName.Value = pOtherPatientInsDetail.PatientInsuranceDetail.Insurer.City  '"Palm Desert"
                .StateOrProvinceCode.Value = pOtherPatientInsDetail.PatientInsuranceDetail.Insurer.StateID   '"CA"
                .PostalCode.Value = pOtherPatientInsDetail.PatientInsuranceDetail.Insurer.ZipCode  '"92260"
                '.CountryCode.Value = ""
                '.LocationQualifier.Value = ""
                '.LocationIdentifier.Value = ""
            End With
        End If

        ' Secondary Payer
        With l2320.L2330B_837PRO.NM1
            .EntityIdentifierCode1.Value = "PR"
            .EntityTypeQualifier.Value = "2"
            If (pOtherPatientInsDetail.PatientInsuranceDetail.InsuranceCompany.CompanyName.Length > 35) Then
                .NameLastOrOrganizationName.Value = pOtherPatientInsDetail.PatientInsuranceDetail.InsuranceCompany.CompanyName.Substring(0, 34) '"MEDICARE"
            Else
                .NameLastOrOrganizationName.Value = pOtherPatientInsDetail.PatientInsuranceDetail.InsuranceCompany.CompanyName '"MEDICARE"
            End If
            .NameFirst.Value = ""
            .NameMiddle.Value = ""
            .NamePrefix.Value = ""
            .NameSuffix.Value = ""
            .IdentificationCodeQualifier.Value = "PI"
            .IdentificationCode.Value = pOtherPatientInsDetail.PatientInsuranceDetail.InsuranceCompany.PayerID '"CMSEL"
            '.EntityRelationshipCode.Value = ""
            '.EntityIdentifierCode2.Value = ""
        End With
    End Sub

    Public Shared Function SendToGatewayEDI(ByVal pFileToUploadPath As String) As Boolean
        Dim lGatewayFtpLink As String = ""
        Dim lGatewayFtpUserID As String = ""
        Dim lGatewayFtpPassword As String = ""
        Dim lGatewayFtpClaimRequestPath As String = ""
        Dim lClient As Sftp
        Dim lClinic As Clinic
        Dim lUser As User

        Try

            lUser = CType(HttpContext.Current.Session("User"), User)

            lClinic = New Clinic(lUser.ConnectionString)
            lClinic.Clinic.ClinicId = lUser.ClinicId
            lClinic.GetRecordByID()

            lGatewayFtpUserID = lClinic.Clinic.GatewayFtpUserID
            lGatewayFtpPassword = lClinic.Clinic.GatewayFtpPassword

            'lGatewayFtpUserID = CType(ConfigurationManager.AppSettings("GatewayFtpUserID"), String)
            'lGatewayFtpPassword = CType(ConfigurationManager.AppSettings("GatewayFtpPassword"), String)
            'lGatewayFtpClaimRequestPath = CType(ConfigurationManager.AppSettings("GatewayFtpClaimRequestPath"), String)

            lGatewayFtpLink = CType(ConfigurationManager.AppSettings("GatewayFtpLink"), String)
            lGatewayFtpClaimRequestPath = "/claims"

            lClient = New Sftp
            lClient.Connect(lGatewayFtpLink)
            lClient.Login(lGatewayFtpUserID, lGatewayFtpPassword)
            lClient.PutFiles(pFileToUploadPath, lGatewayFtpClaimRequestPath, SftpBatchTransferOptions.Recursive)

            Return True
        Catch ex As Exception
            Return False
        Finally
            If (lClient.State = SftpState.Connected) Then
                lClient.Disconnect()
                lClient.Dispose()
            End If
        End Try
    End Function
    Public Shared Function MoveToArchive(ByVal pCurrentFilePath As String) As Boolean
        Dim lUser As User
        Dim lDirectoryInfo As DirectoryInfo
        Dim lPath As String = ""
        Dim lFileName As String = ""

        Dim lArchivePath As String = ""




        Try
            lUser = CType(HttpContext.Current.Session.Item("User"), User)

            lFileName = pCurrentFilePath.Substring(pCurrentFilePath.LastIndexOf("\") + 1)

            lPath = CType(ConfigurationManager.AppSettings("ClaimRquestPath"), String)
            lDirectoryInfo = New DirectoryInfo(lPath)
            If Not lDirectoryInfo.Exists Then
                lDirectoryInfo.Create()
            End If
            lPath = CType(ConfigurationManager.AppSettings("ClaimRquestPath"), String) + lUser.ClinicId
            lDirectoryInfo = New DirectoryInfo(lPath)
            If Not lDirectoryInfo.Exists Then
                lDirectoryInfo.Create()
            End If
            lPath = CType(ConfigurationManager.AppSettings("ClaimRquestPath"), String) + lUser.ClinicId + "\ClaimRequest837Archive\"
            lDirectoryInfo = New DirectoryInfo(lPath)
            If Not lDirectoryInfo.Exists Then
                lDirectoryInfo.Create()
            End If



            lArchivePath = lPath & lFileName
            File.Move(pCurrentFilePath, lArchivePath)
            Return True
        Catch
            Return False
        End Try




    End Function

    'Public Shared Function GetgatewayFTPLoginPassword() As DataSet
    '    Dim lResultDataSet As DataSet
    '    Dim lQuery As String
    '    Dim lUser As User
    '    Dim lConnection As Connection
    '    Dim lClinic As Clinic
    '        Dim lUser As User
    '    Try
    '        lUser = CType(HttpContext.Current.Session("User"), User)
    '        If (lUser IsNot Nothing) Then
    '            lClinic = New Clinic(lUser.ConnectionString)

    '            lClinic.Clinic.ClinicId = lUser.ClinicId
    '            lClinic.GetRecordByID()

    '            lConnection = New Connection(lUser.ConnectionString)
    '            lResultDataSet = New DataSet
    '            lQuery = "SELECT GatewayFtpUserID,GatewayFtpPassword FROM ClinicInfo where ClinicId='" & lUser.ClinicId & "'"
    '            lResultDataSet = lConnection.ExecuteQuery(lQuery)
    '            Return lResultDataSet
    '        End If
    '    Catch ex As Exception
    '        Return Nothing
    '    End Try
    'End Function

End Class
