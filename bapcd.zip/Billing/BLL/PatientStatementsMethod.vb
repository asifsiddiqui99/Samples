Imports Microsoft.VisualBasic
Imports ElixirLibrary
Imports system.Collections.Generic

Public Class PatientStatementsMethod
    Public Shared Function GenerateStatement(ByVal pPateintId As Integer, ByVal pGuarantorID As Integer, ByVal pPatientName As String, _
    ByVal pTotalAmount As Double, ByVal pInsurancePending As Double, _
     ByVal pTotalDue As Double, ByVal pCurrent As Double, _
    ByVal p30 As Double, ByVal p60 As Double, ByVal p90 As Double, ByVal pUser As User, ByVal lrecordcount As Integer, ByVal lselecteditemcount As Integer) As Boolean

        Try
            Dim lPatientStatementHdrDB As New PatientStatementHdrDB
            Dim lPatientStatementDtlDB As New PatientStatementDtlDB
            Dim lPatientStatementTransactionStlDB As New PatientStatementTransactionDtlDB
            Dim lPatientStatementTransactionDtl As New PatientStatementTransactionDtl(pUser.ConnectionString)
            Dim lPatientDB As PatientDB
            Dim lGuarantor As New Guarantor(pUser.ConnectionString)
            Dim lPatientStatementDtl As New PatientStatementDtl(pUser.ConnectionString)
            Dim lClinicDb As ClinicDB
            Dim lds As New DataSet
            Dim lresult As Boolean

            ''................Populating hdr
            lPatientStatementHdrDB.BatchSentDate = Now.Date
            lPatientStatementHdrDB.CreatedByUserID = pUser.UserId

            ''................Populating dtl
            lPatientDB = PatientMethodsExtended.GetPatient(pPateintId)

            lds = lGuarantor.GetAllRecords(" And GuarantorID=" & pGuarantorID)

            ''Guarantor's Portion
            If (lds.Tables(0).Rows.Count > 0) Then
                With lds.Tables(0).Rows(0)
                    lPatientStatementDtlDB.GuarantorLastName = .Item("LastName").ToString
                    lPatientStatementDtlDB.GuarantorMiddleName = .Item("MiddleName").ToString
                    lPatientStatementDtlDB.GuarantorFirstName = .Item("FirstName").ToString
                    lPatientStatementDtlDB.GuarantorAddressLine1 = .Item("AddressLine1").ToString
                    lPatientStatementDtlDB.GuarantorAddressLine2 = .Item("AddressLine2").ToString
                    lPatientStatementDtlDB.GuarantorCity = .Item("City").ToString
                    lPatientStatementDtlDB.GuarantorState = .Item("State").ToString
                    lPatientStatementDtlDB.GuarantorZip = .Item("ZipCode").ToString
                End With
            End If


            lPatientStatementDtlDB.StatementDate = Now.Date
            lPatientStatementDtlDB.PatientID = pPateintId

            ''Bill
            lPatientStatementDtlDB.BillToFirstName = lPatientDB.FirstName
            lPatientStatementDtlDB.BillToLastName = lPatientDB.LastName
            lPatientStatementDtlDB.BillToMiddleName = lPatientDB.MiddleName

            ''Patient's Portion
            lPatientStatementDtlDB.PatientLastName = lPatientDB.LastName
            lPatientStatementDtlDB.PatienFirstName = lPatientDB.FirstName
            lPatientStatementDtlDB.PatientMiddleName = lPatientDB.MiddleName
            lPatientStatementDtlDB.PatientAddressLine1 = lPatientDB.AddressLine1
            lPatientStatementDtlDB.PatientAddressLine2 = lPatientDB.AddressLine2
            lPatientStatementDtlDB.PatientCity = lPatientDB.City
            lPatientStatementDtlDB.PatientState = PatientMethodsExtended.GetPatientState(lPatientDB.StateID)
            lPatientStatementDtlDB.PatientZip = lPatientDB.ZipCode


            ''Referring Provider
            lPatientStatementDtlDB.ReferringProviderFirstName = ""
            lPatientStatementDtlDB.ReferringProviderLastName = ""
            lPatientStatementDtlDB.ReferringProviderMiddleName = ""

            lPatientStatementDtlDB.Message = ""
            lPatientStatementDtlDB.TotalAmount = pTotalAmount
            lPatientStatementDtlDB.InsurancePending = pInsurancePending
            lPatientStatementDtlDB.TotalDue = pTotalDue
            lPatientStatementDtlDB.Current = pCurrent

            lPatientStatementDtlDB.Days30 = p30
            lPatientStatementDtlDB.Days60 = p60
            lPatientStatementDtlDB.Days90 = p90


            lClinicDb = ClinicMethods.GetClinic(pUser)


            lPatientStatementDtlDB.ClinicName = lClinicDb.ClinicName
            lPatientStatementDtlDB.ClinicAddressLine1 = lClinicDb.AddressLine1
            lPatientStatementDtlDB.ClinicAddressLine2 = lClinicDb.AddressLine2
            lPatientStatementDtlDB.ClinicCity = lClinicDb.City
            lPatientStatementDtlDB.ClinicState = PatientMethodsExtended.GetPatientState(lClinicDb.StateId)
            lPatientStatementDtlDB.ClinicZip = lClinicDb.ZipCode
            lPatientStatementDtlDB.ClinicPhone = lClinicDb.Phone1
            lPatientStatementDtlDB.PlaceOfService = lClinicDb.ClinicName


            ''................Populating transaction

            lds = lPatientStatementTransactionDtl.GetInformationForPatientStatementTransactionDtl(pPateintId)




            lresult = InsertStatements(lPatientStatementHdrDB, lPatientStatementDtlDB, lPatientStatementTransactionStlDB, pUser, lrecordcount, lds, lselecteditemcount)

            Return lresult


        Catch ex As Exception
            Return False
        End Try


    End Function

    Public Shared Function InsertStatements(ByVal pStatementHdr As PatientStatementHdrDB, ByVal pstatementDtl As PatientStatementDtlDB, _
    ByVal pPatientTransaction As PatientStatementTransactionDtlDB, ByVal pUser As User, ByVal lrecordcount As Integer, ByVal lDataSetForTransactions As DataSet, ByVal lselecteditemcount As Integer)

        Dim lConnection As New Connection(pUser.ConnectionString)

        Try

            Dim lPatientStatementHdr As New PatientStatementHdr(lConnection)
            Dim lPatientStatementDtl As New PatientStatementDtl(lConnection)
            Dim lPatientStatementTransactionStl As New PatientStatementTransactionDtl(lConnection)
            Dim lMaximumStatementDetalID As Integer = 0
            Dim lMaximumStatementBatchID As Integer = 0
            Dim li As Integer = 0


            lPatientStatementHdr.PatientStatementHdr = pStatementHdr
            lPatientStatementDtl.PatientStatementDtlDB = pstatementDtl
            lPatientStatementTransactionStl.PatientStatementTransactionDtlDB = pPatientTransaction


            'Inserting in hdr
            lConnection.BeginTrans()

            If (lrecordcount = 1) Then
                lMaximumStatementBatchID = lPatientStatementHdr.InsertRecord()
            Else
                lMaximumStatementBatchID = lPatientStatementHdr.GetMaximumStatementBatchID()
            End If



            lPatientStatementDtl.PatientStatementDtlDB.StatementBatchID = lPatientStatementHdr.GetMaximumStatementBatchID

            lMaximumStatementDetalID = lPatientStatementDtl.InsertPatientStatementDtl()

            lPatientStatementTransactionStl.PatientStatementTransactionDtlDB.StatementID = lMaximumStatementDetalID


            If (lDataSetForTransactions.Tables(0).Rows.Count <> 0) Then
                For li = 0 To lDataSetForTransactions.Tables(0).Rows.Count - 1
                    With lDataSetForTransactions.Tables(0).Rows(li)
                        pPatientTransaction.VisitID = .Item("PatientSuperBillID").ToString
                        pPatientTransaction.ProviderFirstName = .Item("DoctorFirstName").ToString
                        pPatientTransaction.ProviderLastName = .Item("DoctorLastName").ToString
                        pPatientTransaction.ProviderMiddleName = .Item("DoctorMiddleName").ToString
                        pPatientTransaction.DOS = .Item("Date").ToString
                        pPatientTransaction.POS = .Item("POS").ToString
                        pPatientTransaction.CPTCode = .Item("Code").ToString
                        pPatientTransaction.Description = .Item("Description").ToString
                        pPatientTransaction.charges = .Item("charges").ToString
                        pPatientTransaction.Credit = .Item("Credit").ToString
                        pPatientTransaction.Balance = .Item("Balance").ToString
                    End With


                    lPatientStatementTransactionStl.InsertPatientStatementTransactionDtl()
                Next
            End If


            lConnection.CommitTrans()


            If (lrecordcount = lselecteditemcount) Then
               
                Dim lgeneratedxml As String = GenerateXml(lMaximumStatementBatchID, lDataSetForTransactions, pUser, lselecteditemcount)

                lPatientStatementHdr.UpdatePatientStatementHdr(lMaximumStatementBatchID, lgeneratedxml)
            End If

            Return True
        Catch ex As Exception
            lConnection.RollBackTrans()
            Return False
        End Try


    End Function

    Public Shared Function GenerateXml(ByVal pStatementHdr As PatientStatementHdr, ByVal pstatementDtl As PatientStatementDtl, _
    ByVal pPatientTransaction As PatientStatementTransactionDtl, ByVal pUser As User, ByVal lds As DataSet, ByVal lrecordcount As Integer)

        Dim lNode As XmlElement
        Dim lChildNode As XmlElement
        Dim lGrandChildNode As XmlElement

        Dim mXmlDocument As New XmlDataDocument
        mXmlDocument.LoadXml("<?xml version=""1.0"" encoding=""utf-8"" ?><abc></abc>")

        '''''''''''''''''''''''''''''Patient Statements''''''''''''''''''''''''''''''''''''''
        lNode = mXmlDocument.CreateElement("PatientStatements")

        lChildNode = mXmlDocument.CreateElement("TransactionID")
        lChildNode.InnerText = pStatementHdr.GetMaximumStatementBatchID
        lNode.AppendChild(lChildNode.CloneNode(True))

        lChildNode = mXmlDocument.CreateElement("SentTime")
        lChildNode.InnerText = pStatementHdr.PatientStatementHdr.BatchSentDate
        lNode.AppendChild(lChildNode.CloneNode(True))


        lChildNode = mXmlDocument.CreateElement("NumberofRecords")
        lChildNode.InnerText = lrecordcount
        lNode.AppendChild(lChildNode.CloneNode(True))

        lChildNode = mXmlDocument.CreateElement("PracticeName")
        lChildNode.InnerText = pstatementDtl.PatientStatementDtlDB.ClinicName
        lNode.AppendChild(lChildNode.CloneNode(True))

        lChildNode = mXmlDocument.CreateElement("BillingPhoneNumber")
        lChildNode.InnerText = pstatementDtl.PatientStatementDtlDB.ClinicPhone
        lNode.AppendChild(lChildNode.CloneNode(True))

        '''''''''''''''''''''''''''''Return Address''''''''''''''''''''''''''''''''''''''

        lChildNode = mXmlDocument.CreateElement("ReturnAddress")
       
        lGrandChildNode = mXmlDocument.CreateElement("AddressLine1")
        lGrandChildNode.InnerText = pstatementDtl.PatientStatementDtlDB.ClinicAddressLine1
        lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

        lGrandChildNode = mXmlDocument.CreateElement("AddressLine2")
        lGrandChildNode.InnerText = pstatementDtl.PatientStatementDtlDB.ClinicAddressLine2
        lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

        lGrandChildNode = mXmlDocument.CreateElement("City")
        lGrandChildNode.InnerText = pstatementDtl.PatientStatementDtlDB.ClinicCity
        lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

        lGrandChildNode = mXmlDocument.CreateElement("State")
        lGrandChildNode.InnerText = pstatementDtl.PatientStatementDtlDB.ClinicState
        lChildNode.AppendChild(lGrandChildNode.CloneNode(True))


        lGrandChildNode = mXmlDocument.CreateElement("Zip")
        lGrandChildNode.InnerText = pstatementDtl.PatientStatementDtlDB.ClinicZip
        lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

        lNode.AppendChild(lChildNode.CloneNode(True))


        '''''''''''''''''''''''''''''Remit To Address''''''''''''''''''''''''''''''''''''''

        lChildNode = mXmlDocument.CreateElement("RemitToAddress")

        lGrandChildNode = mXmlDocument.CreateElement("AddressLine1")
        lGrandChildNode.InnerText = pstatementDtl.PatientStatementDtlDB.ClinicAddressLine1
        lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

        lGrandChildNode = mXmlDocument.CreateElement("AddressLine2")
        lGrandChildNode.InnerText = pstatementDtl.PatientStatementDtlDB.ClinicAddressLine2
        lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

        lGrandChildNode = mXmlDocument.CreateElement("City")
        lGrandChildNode.InnerText = pstatementDtl.PatientStatementDtlDB.ClinicCity
        lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

        lGrandChildNode = mXmlDocument.CreateElement("State")
        lGrandChildNode.InnerText = pstatementDtl.PatientStatementDtlDB.ClinicState
        lChildNode.AppendChild(lGrandChildNode.CloneNode(True))


        lGrandChildNode = mXmlDocument.CreateElement("Zip")
        lGrandChildNode.InnerText = pstatementDtl.PatientStatementDtlDB.ClinicZip
        lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

        lNode.AppendChild(lChildNode.CloneNode(True))

        '''''''''''''''''''''''''''''Referring Provider''''''''''''''''''''''''''''''''''''''

        lChildNode = mXmlDocument.CreateElement("ReferringProvider")

        lGrandChildNode = mXmlDocument.CreateElement("LastName")
        lGrandChildNode.InnerText = ""
        lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

        lGrandChildNode = mXmlDocument.CreateElement("MiddleName")
        lGrandChildNode.InnerText = ""
        lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

        lGrandChildNode = mXmlDocument.CreateElement("FirstName")
        lGrandChildNode.InnerText = ""
        lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

        lGrandChildNode = mXmlDocument.CreateElement("Suffix")
        lGrandChildNode.InnerText = ""
        lChildNode.AppendChild(lGrandChildNode.CloneNode(True))












        mXmlDocument.DocumentElement.AppendChild(lNode.CloneNode(True))
















    End Function

    Public Shared Function Generatexml(ByVal pMaximumStatementBatchID As Integer, _
    ByVal pDataSetForTransactions As DataSet, ByVal pUser As User, ByVal pNumberOfRecords As Integer) As String


        Dim lDataSatForPatientStatementHdr As DataSet
        Dim lDataSetForPatientStatementDtl As DataSet

        Dim ldistinctDataTable As DataTable
        Dim lGenerateXml As String = String.Empty
        Dim li As Integer

        Try

            Dim lPatientStatementHdr As New PatientStatementHdr(pUser.ConnectionString)
            Dim lPatientStatementDtl As New PatientStatementDtl(pUser.ConnectionString)

            lDataSatForPatientStatementHdr = lPatientStatementHdr.GetAllRecords(pMaximumStatementBatchID)
            lDataSetForPatientStatementDtl = lPatientStatementDtl.GetAllRecords(pMaximumStatementBatchID)




            Dim lNode As XmlElement
            Dim lChildNode As XmlElement
            Dim lGrandChildNode As XmlElement
            Dim lGrandGrandChildNode As XmlElement
            Dim lpatientstatement As XmlElement

            Dim mXmlDocument As New XmlDataDocument
            mXmlDocument.LoadXml("<?xml version=""1.0"" encoding=""utf-8"" ?><PatientStatements></PatientStatements>")

            '''''''''''''''''''''''''''''Patient Statements''''''''''''''''''''''''''''''''''''''
            lNode = mXmlDocument.SelectSingleNode("/PatientStatements")

            lChildNode = mXmlDocument.CreateElement("TransactionID")
            lChildNode.InnerText = lDataSatForPatientStatementHdr.Tables(0).Rows(0).Item("StatementBatchID").ToString
            lNode.AppendChild(lChildNode.CloneNode(True))

            lChildNode = mXmlDocument.CreateElement("SentTime")
            lChildNode.InnerText = lDataSatForPatientStatementHdr.Tables(0).Rows(0).Item("BatchSentDate").ToString
            lNode.AppendChild(lChildNode.CloneNode(True))


            lChildNode = mXmlDocument.CreateElement("NumberofRecords")
            lChildNode.InnerText = pNumberOfRecords
            lNode.AppendChild(lChildNode.CloneNode(True))

            lChildNode = mXmlDocument.CreateElement("PracticeName")
            lChildNode.InnerText = lDataSetForPatientStatementDtl.Tables(0).Rows(0).Item("ClinicName").ToString
            lNode.AppendChild(lChildNode.CloneNode(True))

            lChildNode = mXmlDocument.CreateElement("BillingPhoneNumber")
            lChildNode.InnerText = lDataSetForPatientStatementDtl.Tables(0).Rows(0).Item("ClinicPhone").ToString
            lNode.AppendChild(lChildNode.CloneNode(True))

            '''''''''''''''''''''''''''''Return Address''''''''''''''''''''''''''''''''''''''

            lChildNode = mXmlDocument.CreateElement("ReturnAddress")

            lGrandChildNode = mXmlDocument.CreateElement("AddressLine1")
            lGrandChildNode.InnerText = lDataSetForPatientStatementDtl.Tables(0).Rows(0).Item("ClinicAddressLine1").ToString
            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

            lGrandChildNode = mXmlDocument.CreateElement("AddressLine2")
            lGrandChildNode.InnerText = lDataSetForPatientStatementDtl.Tables(0).Rows(0).Item("ClinicAddressLine2").ToString
            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

            lGrandChildNode = mXmlDocument.CreateElement("City")
            lGrandChildNode.InnerText = lDataSetForPatientStatementDtl.Tables(0).Rows(0).Item("ClinicCity").ToString
            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

            lGrandChildNode = mXmlDocument.CreateElement("State")
            lGrandChildNode.InnerText = lDataSetForPatientStatementDtl.Tables(0).Rows(0).Item("ClinicState").ToString
            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))


            lGrandChildNode = mXmlDocument.CreateElement("Zip")
            lGrandChildNode.InnerText = lDataSetForPatientStatementDtl.Tables(0).Rows(0).Item("ClinicZip").ToString
            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

            lNode.AppendChild(lChildNode.CloneNode(True))


            '''''''''''''''''''''''''''''Remit To Address''''''''''''''''''''''''''''''''''''''

            lChildNode = mXmlDocument.CreateElement("RemitToAddress")

            lGrandChildNode = mXmlDocument.CreateElement("AddressLine1")
            lGrandChildNode.InnerText = lDataSetForPatientStatementDtl.Tables(0).Rows(0).Item("ClinicAddressLine1").ToString
            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

            lGrandChildNode = mXmlDocument.CreateElement("AddressLine2")
            lGrandChildNode.InnerText = lDataSetForPatientStatementDtl.Tables(0).Rows(0).Item("ClinicAddressLine2").ToString
            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

            lGrandChildNode = mXmlDocument.CreateElement("City")
            lGrandChildNode.InnerText = lDataSetForPatientStatementDtl.Tables(0).Rows(0).Item("ClinicCity").ToString
            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

            lGrandChildNode = mXmlDocument.CreateElement("State")
            lGrandChildNode.InnerText = lDataSetForPatientStatementDtl.Tables(0).Rows(0).Item("ClinicState").ToString
            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))


            lGrandChildNode = mXmlDocument.CreateElement("Zip")
            lGrandChildNode.InnerText = lDataSetForPatientStatementDtl.Tables(0).Rows(0).Item("ClinicZip").ToString
            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

            lNode.AppendChild(lChildNode.CloneNode(True))

            '''''''''''''''''''''''''''''Referring Provider''''''''''''''''''''''''''''''''''''''

            lChildNode = mXmlDocument.CreateElement("ReferringProvider")

            lGrandChildNode = mXmlDocument.CreateElement("LastName")
            lGrandChildNode.InnerText = ""
            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

            lGrandChildNode = mXmlDocument.CreateElement("MiddleName")
            lGrandChildNode.InnerText = ""
            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

            lGrandChildNode = mXmlDocument.CreateElement("FirstName")
            lGrandChildNode.InnerText = ""
            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

            lGrandChildNode = mXmlDocument.CreateElement("Suffix")
            lGrandChildNode.InnerText = ""
            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

            lNode.AppendChild(lChildNode.CloneNode(True))



            'For li = 0 To lDataSetForPatientStatementDtl.Tables(0).Rows.Count - 1

            '    '''''''''''''''''''''''''''''Patient Statement''''''''''''''''''''''''''''''''''''''

            '    lChildNode = mXmlDocument.CreateElement("PatientStatement")

            '    lGrandChildNode = mXmlDocument.CreateElement("StatementID")
            '    lGrandChildNode.InnerText = lDataSetForPatientStatementDtl.Tables(0).Rows(li).Item("StatementId").ToString
            '    lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

            '    lGrandChildNode = mXmlDocument.CreateElement("StatementDate")
            '    lGrandChildNode.InnerText = lDataSetForPatientStatementDtl.Tables(0).Rows(li).Item("StatementDate").ToString
            '    lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

            '    lGrandChildNode = mXmlDocument.CreateElement("PlaceOfService")
            '    lGrandChildNode.InnerText = lDataSetForPatientStatementDtl.Tables(0).Rows(li).Item("ClinicName").ToString
            '    lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

            '    lGrandChildNode = mXmlDocument.CreateElement("AccountNumber")
            '    lGrandChildNode.InnerText = lDataSetForPatientStatementDtl.Tables(0).Rows(li).Item("PatientID").ToString
            '    lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

            '    'lGrandChildNode = mXmlDocument.CreateElement("BillTo")

            '    'lGrandGrandChildNode = mXmlDocument.CreateElement("LastName")
            '    'lGrandGrandChildNode.InnerText = lDataSetForPatientStatementDtl.Tables(0).Rows(li).Item("BillToLastName").ToString
            '    'lGrandChildNode.AppendChild(lGrandGrandChildNode.CloneNode(True))

            '    'lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

            '    'lGrandGrandChildNode = mXmlDocument.CreateElement("MiddleName")
            '    'lGrandGrandChildNode.InnerText = lDataSetForPatientStatementDtl.Tables(0).Rows(li).Item("BillToMiddleName").ToString
            '    'lGrandChildNode.AppendChild(lGrandGrandChildNode.CloneNode(True))

            '    'lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

            '    'lGrandGrandChildNode = mXmlDocument.CreateElement("FirstName")
            '    'lGrandGrandChildNode.InnerText = lDataSetForPatientStatementDtl.Tables(0).Rows(li).Item("BillToFirstName").ToString
            '    'lGrandChildNode.AppendChild(lGrandGrandChildNode.CloneNode(True))

            '    'lChildNode.AppendChild(lGrandChildNode.CloneNode(True))


            '    'lGrandChildNode = mXmlDocument.CreateElement("PatientName")

            '    'lGrandGrandChildNode = mXmlDocument.CreateElement("LastName")
            '    'lGrandGrandChildNode.InnerText = lDataSetForPatientStatementDtl.Tables(0).Rows(li).Item("PatientLastName").ToString
            '    'lGrandChildNode.AppendChild(lGrandGrandChildNode.CloneNode(True))

            '    'lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

            '    'lGrandGrandChildNode = mXmlDocument.CreateElement("MiddleName")
            '    'lGrandGrandChildNode.InnerText = lDataSetForPatientStatementDtl.Tables(0).Rows(li).Item("PatientMiddleName").ToString
            '    'lGrandChildNode.AppendChild(lGrandGrandChildNode.CloneNode(True))

            '    'lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

            '    'lGrandGrandChildNode = mXmlDocument.CreateElement("FirstName")
            '    'lGrandGrandChildNode.InnerText = lDataSetForPatientStatementDtl.Tables(0).Rows(li).Item("PatienFirstName").ToString
            '    'lGrandChildNode.AppendChild(lGrandGrandChildNode.CloneNode(True))

            '    lChildNode.AppendChild(lGrandChildNode.CloneNode(True))


            'Next
            For li = 0 To lDataSetForPatientStatementDtl.Tables(0).Rows.Count - 1

                lpatientstatement = CreatePatientStamtementElemant(mXmlDocument, lDataSetForPatientStatementDtl, li, _
                lDataSetForPatientStatementDtl.Tables(0).Rows(li).Item("PatientID").ToString)

                lNode.AppendChild(lpatientstatement.CloneNode(True))
            Next


            'mXmlDocument.DocumentElement.AppendChild(lNode.CloneNode(True))



            Return mXmlDocument.OuterXml

        Catch ex As Exception
            Return ""
        End Try

    End Function


    Public Shared Function CreatePatientStamtementElemant(ByVal mxmldocument As XmlDocument, ByVal pDataSetForPatientStatementDtl As DataSet, _
        ByVal li As Integer, ByVal pPatientId As Integer) As XmlElement

        

        Dim lPatientStatement As XmlElement
        Dim lStatementId As XmlElement
        Dim lStatementDate As XmlElement
        Dim lPlaceOfService As XmlElement
        Dim lAccountNumber As XmlElement
        Dim lBillTo As XmlElement
        Dim lPatientName As XmlElement
        Dim lPatientAddress As XmlElement
        Dim lGuarantorName As XmlElement
        Dim lGuarantorAddress As XmlElement
        Dim lVisitDetail As XmlElement
        Dim lTotal As XmlElement
        Dim lAging As XmlElement
        Dim lchildNode As XmlElement
        Dim lds As New DataSet
        Dim lUser As User
        Dim lPatientStatementTransactionDtl As PatientStatementTransactionDtl
        Dim lPatientRunningBalance As Double = 0.0



        Try
            lUser = CType(HttpContext.Current.Session("User"), User)

            lPatientStatementTransactionDtl = New PatientStatementTransactionDtl(lUser.ConnectionString)

            lds = lPatientStatementTransactionDtl.GetInformationForPatientStatementTransactionDtl(pPatientId)


        Catch ex As Exception

        End Try




        '''''''''''''''''''''''''''''Patient Statement''''''''''''''''''''''''''''''''''''''

        lPatientStatement = mxmldocument.CreateElement("PatientStatement")

        lStatementId = mxmldocument.CreateElement("StatementID")
        lStatementId.InnerText = pDataSetForPatientStatementDtl.Tables(0).Rows(li).Item("StatementId").ToString
        lPatientStatement.AppendChild(lStatementId.CloneNode(True))

        lStatementDate = mxmldocument.CreateElement("StatementDate")
        lStatementDate.InnerText = pDataSetForPatientStatementDtl.Tables(0).Rows(li).Item("StatementDate").ToString
        lPatientStatement.AppendChild(lStatementDate.CloneNode(True))

        lPlaceOfService = mxmldocument.CreateElement("PlaceOfService")
        lPlaceOfService.InnerText = pDataSetForPatientStatementDtl.Tables(0).Rows(li).Item("ClinicName").ToString
        lPatientStatement.AppendChild(lPlaceOfService.CloneNode(True))

        lAccountNumber = mxmldocument.CreateElement("AccountNumber")
        lAccountNumber.InnerText = pPatientId
        lPatientStatement.AppendChild(lAccountNumber.CloneNode(True))

        ''...............Bill To.............''''

        lBillTo = mxmldocument.CreateElement("BillTo")

        lchildNode = mxmldocument.CreateElement("LastName")
        lchildNode.InnerText = pDataSetForPatientStatementDtl.Tables(0).Rows(li).Item("BillToLastName").ToString
        lBillTo.AppendChild(lchildNode.CloneNode(True))


        lchildNode = mxmldocument.CreateElement("MiddleName")
        lchildNode.InnerText = pDataSetForPatientStatementDtl.Tables(0).Rows(li).Item("BillToMiddleName").ToString
        lBillTo.AppendChild(lchildNode.CloneNode(True))


        lchildNode = mxmldocument.CreateElement("FirstName")
        lchildNode.InnerText = pDataSetForPatientStatementDtl.Tables(0).Rows(li).Item("BillToFirstName").ToString
        lBillTo.AppendChild(lchildNode.CloneNode(True))


        lPatientStatement.AppendChild(lBillTo.CloneNode(True))

        ''...............Patient Name.............''''

        lPatientName = mxmldocument.CreateElement("PatientName")

        lchildNode = mxmldocument.CreateElement("LastName")
        lchildNode.InnerText = pDataSetForPatientStatementDtl.Tables(0).Rows(li).Item("PatientLastName").ToString
        lPatientName.AppendChild(lchildNode.CloneNode(True))


        lchildNode = mxmldocument.CreateElement("MiddleName")
        lchildNode.InnerText = pDataSetForPatientStatementDtl.Tables(0).Rows(li).Item("PatientMiddleName").ToString
        lPatientName.AppendChild(lchildNode.CloneNode(True))


        lchildNode = mxmldocument.CreateElement("FirstName")
        lchildNode.InnerText = pDataSetForPatientStatementDtl.Tables(0).Rows(li).Item("PatienFirstName").ToString
        lPatientName.AppendChild(lchildNode.CloneNode(True))


        lPatientStatement.AppendChild(lPatientName.CloneNode(True))


        ''...............Patient Address.............''''

        lPatientAddress = mxmldocument.CreateElement("PatientAddress")

        lchildNode = mxmldocument.CreateElement("AddressLine1")
        lchildNode.InnerText = pDataSetForPatientStatementDtl.Tables(0).Rows(li).Item("PatientAddressLine1").ToString
        lPatientAddress.AppendChild(lchildNode.CloneNode(True))

        lchildNode = mxmldocument.CreateElement("AddressLine2")
        lchildNode.InnerText = pDataSetForPatientStatementDtl.Tables(0).Rows(li).Item("PatientAddressLine2").ToString
        lPatientAddress.AppendChild(lchildNode.CloneNode(True))

        lchildNode = mxmldocument.CreateElement("City")
        lchildNode.InnerText = pDataSetForPatientStatementDtl.Tables(0).Rows(li).Item("PatientCity").ToString
        lPatientAddress.AppendChild(lchildNode.CloneNode(True))

        lchildNode = mxmldocument.CreateElement("State")
        lchildNode.InnerText = pDataSetForPatientStatementDtl.Tables(0).Rows(li).Item("PatientState").ToString
        lPatientAddress.AppendChild(lchildNode.CloneNode(True))

        lchildNode = mxmldocument.CreateElement("Zip")
        lchildNode.InnerText = pDataSetForPatientStatementDtl.Tables(0).Rows(li).Item("PatientZip").ToString
        lPatientAddress.AppendChild(lchildNode.CloneNode(True))


        lPatientStatement.AppendChild(lPatientAddress.CloneNode(True))



        ''...............Guarantor Name.............''''

        lGuarantorName = mxmldocument.CreateElement("GuarantorName")

        lchildNode = mxmldocument.CreateElement("LastName")
        lchildNode.InnerText = pDataSetForPatientStatementDtl.Tables(0).Rows(li).Item("GuarantorLastName").ToString
        lGuarantorName.AppendChild(lchildNode.CloneNode(True))

        lchildNode = mxmldocument.CreateElement("MiddleName")
        lchildNode.InnerText = pDataSetForPatientStatementDtl.Tables(0).Rows(li).Item("GuarantorMiddleName").ToString
        lGuarantorName.AppendChild(lchildNode.CloneNode(True))

        lchildNode = mxmldocument.CreateElement("FirstName")
        lchildNode.InnerText = pDataSetForPatientStatementDtl.Tables(0).Rows(li).Item("GuarantorFirstName").ToString
        lGuarantorName.AppendChild(lchildNode.CloneNode(True))


        lPatientStatement.AppendChild(lGuarantorName.CloneNode(True))

        ''...............Guarantor Address.............''''

        lGuarantorAddress = mxmldocument.CreateElement("GuarantorAddress")

        lchildNode = mxmldocument.CreateElement("AddressLine1")
        lchildNode.InnerText = pDataSetForPatientStatementDtl.Tables(0).Rows(li).Item("GuarantorAddressLine1").ToString
        lGuarantorAddress.AppendChild(lchildNode.CloneNode(True))

        lchildNode = mxmldocument.CreateElement("AddressLine2")
        lchildNode.InnerText = pDataSetForPatientStatementDtl.Tables(0).Rows(li).Item("GuarantorAddressLine2").ToString
        lGuarantorAddress.AppendChild(lchildNode.CloneNode(True))


        lchildNode = mxmldocument.CreateElement("City")
        lchildNode.InnerText = pDataSetForPatientStatementDtl.Tables(0).Rows(li).Item("GuarantorCity").ToString
        lGuarantorAddress.AppendChild(lchildNode.CloneNode(True))

        lchildNode = mxmldocument.CreateElement("State")
        lchildNode.InnerText = pDataSetForPatientStatementDtl.Tables(0).Rows(li).Item("GuarantorState").ToString
        lGuarantorAddress.AppendChild(lchildNode.CloneNode(True))

        lchildNode = mxmldocument.CreateElement("Zip")
        lchildNode.InnerText = pDataSetForPatientStatementDtl.Tables(0).Rows(li).Item("GuarantorZip").ToString
        lGuarantorAddress.AppendChild(lchildNode.CloneNode(True))


        lPatientStatement.AppendChild(lGuarantorAddress.CloneNode(True))

        ''..............Visit Detail..............'

        Dim ldistinctDataTable As DataTable = lds.Tables(0).DefaultView.ToTable(True, "PatientSuperBillId")

        For lIndex As Int32 = 0 To ldistinctDataTable.Rows.Count - 1
            Dim results As DataRow() = lds.Tables(0).[Select]("PatientSuperBillId=" & ldistinctDataTable.Rows(lIndex).Item("PatientSuperBillId"))
            lVisitDetail = CreateVisitDetailElement(mxmldocument, results, lPatientRunningBalance)
            lPatientStatement.AppendChild(lVisitDetail.CloneNode(True))
        Next







        ''...........Total................

        lTotal = mxmldocument.CreateElement("Total")

        lchildNode = mxmldocument.CreateElement("TotalAmount")
        lchildNode.InnerText = pDataSetForPatientStatementDtl.Tables(0).Rows(li).Item("TotalAmount").ToString
        lTotal.AppendChild(lchildNode.CloneNode(True))

        lchildNode = mxmldocument.CreateElement("InsurancePending")
        lchildNode.InnerText = pDataSetForPatientStatementDtl.Tables(0).Rows(li).Item("InsurancePending").ToString
        lTotal.AppendChild(lchildNode.CloneNode(True))

        lchildNode = mxmldocument.CreateElement("TotalDue")
        lchildNode.InnerText = pDataSetForPatientStatementDtl.Tables(0).Rows(li).Item("TotalDue").ToString
        lTotal.AppendChild(lchildNode.CloneNode(True))

        lPatientStatement.AppendChild(lTotal.CloneNode(True))


        ''...........Aging................

        lAging = mxmldocument.CreateElement("Aging")

        lchildNode = mxmldocument.CreateElement("Current")
        lchildNode.InnerText = pDataSetForPatientStatementDtl.Tables(0).Rows(li).Item("Current").ToString
        lAging.AppendChild(lchildNode.CloneNode(True))

        lchildNode = mxmldocument.CreateElement("Day30")
        lchildNode.InnerText = pDataSetForPatientStatementDtl.Tables(0).Rows(li).Item("Days30").ToString
        lAging.AppendChild(lchildNode.CloneNode(True))

        lchildNode = mxmldocument.CreateElement("Day60")
        lchildNode.InnerText = pDataSetForPatientStatementDtl.Tables(0).Rows(li).Item("Days60").ToString
        lAging.AppendChild(lchildNode.CloneNode(True))

        lchildNode = mxmldocument.CreateElement("Day90")
        lchildNode.InnerText = pDataSetForPatientStatementDtl.Tables(0).Rows(li).Item("Days90").ToString
        lAging.AppendChild(lchildNode.CloneNode(True))

        lPatientStatement.AppendChild(lAging.CloneNode(True))


        Return lPatientStatement




    End Function



    Public Shared Function CreateVisitDetailElement(ByVal pXmlDoc As XmlDocument, ByVal pVisitDS As DataRow(), ByRef lPreviousBalance As Double) As XmlElement

        Dim lVisitDetail As XmlElement
        Dim lVisitID As XmlElement
        Dim lProvider As XmlElement
        Dim lLineDetail As XmlElement
        Dim lChildNode As XmlElement
        'Dim lPreviousBalance As Double = 0.0



        Try

            If (pVisitDS IsNot Nothing AndAlso pVisitDS.Length > 0) Then

                lVisitDetail = pXmlDoc.CreateElement("VisitDetail")

                lVisitID = pXmlDoc.CreateElement("VisitID")
                lVisitID.InnerText = pVisitDS(0).Item("PatientSuperBillID").ToString  '"VisitID"
                lVisitDetail.AppendChild(lVisitID.CloneNode(True))


                '''' Provider''''
                lProvider = pXmlDoc.CreateElement("Provider")

                lChildNode = pXmlDoc.CreateElement("LastName")
                lChildNode.InnerText = pVisitDS(0).Item("DoctorLastName").ToString
                lProvider.AppendChild(lChildNode.CloneNode(True))

                lChildNode = pXmlDoc.CreateElement("FirstName")
                lChildNode.InnerText = pVisitDS(0).Item("DoctorFirstName").ToString
                lProvider.AppendChild(lChildNode.CloneNode(True))


                lChildNode = pXmlDoc.CreateElement("MiddleName")
                lChildNode.InnerText = pVisitDS(0).Item("DoctorMiddleName").ToString
                lProvider.AppendChild(lChildNode.CloneNode(True))

                lChildNode = pXmlDoc.CreateElement("Suffix")
                lChildNode.InnerText = pVisitDS(0).Item("Suffix").ToString '"Suffix"
                lProvider.AppendChild(lChildNode.CloneNode(True))

                lVisitDetail.AppendChild(lProvider.CloneNode(True))

                '''' End Provider''''



                For Each lRow As DataRow In pVisitDS

                    '''' Line detail''''
                    lLineDetail = pXmlDoc.CreateElement("LineDetail")

                    lChildNode = pXmlDoc.CreateElement("Date")
                    lChildNode.InnerText = lRow.Item("Date").ToString
                    lLineDetail.AppendChild(lChildNode.CloneNode(True))

                    lChildNode = pXmlDoc.CreateElement("POS")
                    lChildNode.InnerText = lRow.Item("POS").ToString
                    lLineDetail.AppendChild(lChildNode.CloneNode(True))


                    lChildNode = pXmlDoc.CreateElement("CPTCode")
                    lChildNode.InnerText = lRow.Item("Code").ToString
                    lLineDetail.AppendChild(lChildNode.CloneNode(True))

                    lChildNode = pXmlDoc.CreateElement("Description")
                    lChildNode.InnerText = lRow.Item("Description").ToString
                    lLineDetail.AppendChild(lChildNode.CloneNode(True))

                    lChildNode = pXmlDoc.CreateElement("Charges")
                    lChildNode.InnerText = lRow.Item("Charges").ToString
                    lLineDetail.AppendChild(lChildNode.CloneNode(True))

                    lChildNode = pXmlDoc.CreateElement("Credits")
                    lChildNode.InnerText = lRow.Item("Credit").ToString
                    lLineDetail.AppendChild(lChildNode.CloneNode(True))

                    Try
                        lPreviousBalance = (lPreviousBalance + CType(lRow.Item("Charges").ToString, Double)) - CType(lRow.Item("Credit").ToString, Double)
                    Catch ex As Exception
                        lPreviousBalance = 0.0
                    End Try


                    lChildNode = pXmlDoc.CreateElement("Balance")
                    lChildNode.InnerText = lPreviousBalance 'lRow.Item("Balance").ToString
                    lLineDetail.AppendChild(lChildNode.CloneNode(True))


                    lVisitDetail.AppendChild(lLineDetail.CloneNode(True))

                    '''' End Line Detail''''
                Next
            Else
                lVisitDetail = Nothing
            End If
        Catch ex As Exception
            lVisitDetail = Nothing
        End Try


        Return lVisitDetail



    End Function


End Class
