Imports Microsoft.VisualBasic
Imports ClaimResponse

Public Class RemittanceMethods
    Public Function loadGrid(ByVal pCondition As String) As DataSet
        Dim lUser As User
        Dim lConnection As Connection
        Dim lds As DataSet
        Dim lQuery As String = ""
        Try
            lUser = CType(HttpContext.Current.Session("User"), User)
            lConnection = New Connection(lUser.ConnectionString)
            lds = New DataSet
            'lQuery = "SELECT ViewReport='View Report',LineId,RemittanceId,ReassociationTraceNumber,PaymentId," & _
            '"RemittanceMessageReceiveDate,CheckAmount,CheckNumber,CheckDate,ProviderAdjustmentAmount,PrescriberNPI,ProviderReference," & _
            '"ProductionDate,PayerContactName,PayerCommunicationNumberQualifier,PayerCommunicationNumber,PayerName,PayerAddress,PayerCity," & _
            '"PayerState,PayerZip,AdditionalPayerIdentification,PayeeName,PayeeAddress,PayeeCity,PayeeState,PayeeZip,AdditionalPayeeIdentification," & _
            '"[FileName],IsPosted FROM [dbo].[RemittanceHdr] hdr where 1=1" + pCondition

            'lQuery = "SELECT ViewReport='View Report',hdr.LineId,hdr.RemittanceId,hdr.ReassociationTraceNumber,hdr.PaymentId," & _
            '"hdr.RemittanceMessageReceiveDate,hdr.CheckAmount,hdr.CheckNumber,hdr.CheckDate,hdr.ProviderAdjustmentAmount," & _
            '"hdr.PrescriberNPI,hdr.ProviderReference,hdr.ProductionDate,hdr.PayerContactName,hdr.PayerCommunicationNumberQualifier," & _
            '"hdr.PayerCommunicationNumber,hdr.PayerName,hdr.PayerAddress,hdr.PayerCity,hdr.PayerState,hdr.PayerZip," & _
            '"hdr.AdditionalPayerIdentification,hdr.PayeeName,hdr.PayeeAddress,hdr.PayeeCity,hdr.PayeeState," & _
            '"hdr.PayeeZip,hdr.AdditionalPayeeIdentification,hdr.[FileName],hdr.IsPosted," & _
            '"Cdtl.PatientLastName + ',' + Cdtl.PatientFirstName as [Full],Sdtl.RemittanceClaimId" & _
            '" FROM [dbo].[RemittanceHdr] hdr , [dbo].[RemittanceClaimDtl] Cdtl,[dbo].[RemittanceClaimServiceDtl] Sdtl" & _
            '" where(1 = 1) and hdr.RemittanceId= Cdtl.RemittanceId and Cdtl.RemittanceId=Sdtl.RemittanceId" + pCondition

            lQuery = "SELECT ViewReport='View Report',LineId,RemittanceId,ReassociationTraceNumber,PaymentId," & _
            "RemittanceMessageReceiveDate,CheckAmount,CheckNumber,CheckDate,ProviderAdjustmentAmount,PrescriberNPI,ProviderReference," & _
            "ProductionDate,PayerContactName,PayerCommunicationNumberQualifier,PayerCommunicationNumber,PayerName,PayerAddress,PayerCity," & _
            "PayerState,PayerZip,AdditionalPayerIdentification,PayeeName,PayeeAddress,PayeeCity,PayeeState,PayeeZip,AdditionalPayeeIdentification," & _
            "[FileName],IsPosted FROM [dbo].[RemittanceHdr] hdr where 1=1" + pCondition
            lds = lConnection.ExecuteQuery(lQuery)
        Catch ex As Exception
            lds = Nothing
        End Try
        Return lds
    End Function
    Public Function ReadFromFile(ByVal pPath As String) As String

        Dim lFileStream As FileStream = Nothing
        Dim lStreamReader As StreamReader = Nothing


        Try
            If Not File.Exists(pPath) Then
                Throw New Exception("File does not exist")
            End If


            File.GetCreationTime(pPath)


        Catch ex As Exception
            Return Nothing
        Finally
            lStreamReader.Close()
            lFileStream.Close()
        End Try
    End Function
    Public Function LoadReport(ByVal pTraceNo As String) As DataSet
        Dim lUser As User = CType(HttpContext.Current.Session("User"), User)
        Dim lConnection As New Connection(lUser.ConnectionString)
        Dim lds As New DataSet
        '  Dim lQuery As String = "select hdr.*,claim.RemittanceClaimId,claim.PatientFirstName,claim.PatientLastName,claim.PatientMiddleName,claim.InsuredFirstName,claim.InsuredLastName,claim.InsuredMiddleName,claim.ClaimStatus,claim.ClaimForwardTo,claim.ClaimPaymentAmount,claim.ClaimAdjustmentAmount,claim.ClaimAdjustmentCodes,claim.ClaimRemarkCodes,claim.HicNumber,claim.RenderingProviderFirstName,claim.RenderingProviderLastName,claim.RenderingProviderMiddleName,claim.RenderingProviderNpi,claim.PayerClaimControlOrIcnNumber,claim.PatientResponsibility,claim.PatientGroupNumber,claim.ClaimContactName,claim.ClaimCommunicationNumberQualifier,claim.ClaimCommunicationNumber,servicedtl.DateOfServiceFrom,servicedtl.DateOfServiceTo,servicedtl.Unit,servicedtl.CptCode,servicedtl.ChargedAmount,servicedtl.AllowedAmount,servicedtl.DeductibleAmount,servicedtl.CoInsuranceAmount,servicedtl.CoPayAmount,servicedtl.LateFillingRedAmount,servicedtl.OtherAdjustmentAmount,servicedtl.ServiceAdjustmentCodes,servicedtl.ProviderPaidAmount,servicedtl.RemarkCodes from [RxCureV3].[dbo].[RemittanceHdr] hdr,[RxCureV3].[dbo].[RemittanceClaimDtl] claim,[RxCureV3].[dbo].[RemittanceClaimServiceDtl] servicedtl where  hdr.RemittanceId=claim.RemittanceId and hdr.ReassociationTraceNumber=claim.ReassociationTraceNumber and claim.RemittanceClaimId=servicedtl.RemittanceClaimId and hdr.ReassociationTraceNumber='" + pTraceNo + "'"
        Try
            If lConnection.IsTransactionAlive() Then
                lds = lConnection.ExecuteTransactionQuery("exec RemittanceLoadReport " + pTraceNo)
            Else
                lds = lConnection.ExecuteReportQuery("exec RemittanceLoadReport " + pTraceNo, "RemittanceReport")
            End If
        Catch ex As Exception
            lds = Nothing
        End Try
        Return lds
    End Function
    Public Function PostRemittance(ByVal pStrFileNameAndPath As String, ByVal pStrEdi As String) As Boolean

        Dim lBoolResult As Boolean = False
        Dim lUser As User

        Try
            lUser = CType(HttpContext.Current.Session("User"), User)

            If pStrEdi.Equals("") Then
                Throw New Exception("No content")
            End If

            lBoolResult = ClaimResponse835.PostPayment(pStrEdi, lUser)
            If (lBoolResult) Then
                'MoveFiles(pStrFileNameAndPath, pStrFileNameAndPath.Replace("ClaimResponse835", "ClaimResponse835Archive"))
                Return True
            Else
                Return False
            End If

        Catch ex As Exception

        End Try

    End Function
    Public Function PostRemittance5010(ByVal pStrFileNameAndPath As String, ByVal pStrEdi As String, ByVal pIs5010 As Boolean) As Boolean
        Dim lBoolResult As Boolean = False
        Dim lUser As User
        Try
            lUser = CType(HttpContext.Current.Session("User"), User)
            If pStrEdi.Equals("") Then
                Throw New Exception("No content")
            End If
            lBoolResult = ClaimResponse835P5010.PostPayment5010(pStrEdi, lUser, True)
            If (lBoolResult) Then
                'MoveFiles(pStrFileNameAndPath, pStrFileNameAndPath.Replace("ClaimResponse835", "ClaimResponse835Archive"))
                Return True
            Else
                Return False
            End If
        Catch ex As Exception

        End Try
    End Function
    Public Sub MoveFiles(ByVal pStrSourceFilePathAndName As String, ByVal pStrDestinationFilePathAndName As String)

        Try
            If (Directory.Exists(pStrDestinationFilePathAndName.Substring(0, pStrDestinationFilePathAndName.LastIndexOf("\")))) Then
                If File.Exists(pStrSourceFilePathAndName) Then
                    If File.Exists(pStrDestinationFilePathAndName) Then
                        File.Delete(pStrDestinationFilePathAndName)
                        File.Move(pStrSourceFilePathAndName, pStrDestinationFilePathAndName)
                    Else
                        File.Move(pStrSourceFilePathAndName, pStrDestinationFilePathAndName)
                    End If
                End If
            Else
                Directory.CreateDirectory(pStrDestinationFilePathAndName.Substring(0, pStrDestinationFilePathAndName.LastIndexOf("\")))
                If File.Exists(pStrSourceFilePathAndName) Then
                    File.Move(pStrSourceFilePathAndName, pStrDestinationFilePathAndName)
                End If
            End If

        Catch ex As Exception

        End Try

    End Sub
    Public Function CheckIfExist(ByVal pReassociationTraceNumber As String) As Boolean
        Dim lUser As User
        Dim lConnection As Connection
        Dim lDS As DataSet
        Dim lQuery As String

        Try
            lUser = CType(HttpContext.Current.Session("User"), User)
            lConnection = New Connection(lUser.ConnectionString)
            lds = New DataSet
            lQuery = "Select * from RemittanceHdr where ReassociationTraceNumber='" & pReassociationTraceNumber & "'"

            lDS = lConnection.ExecuteQuery(lQuery)

            If (lDS.Tables(0).Rows.Count > 0) Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception

        End Try

    End Function
    Public Function IsContentExist(ByVal pNewContent As String) As Boolean
        Dim lUser As User
        Dim lConnection As Connection
        Dim lDS As DataSet
        Dim lQuery As String

        Try
            lUser = CType(HttpContext.Current.Session("User"), User)
            lConnection = New Connection(lUser.ConnectionString)
            lDS = New DataSet
            lQuery = "Select * from RemittanceHdr where FileContent='" & pNewContent & "'"

            lDS = lConnection.ExecuteQuery(lQuery)

            If (lDS.Tables(0).Rows.Count > 0) Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception

        End Try

    End Function
    Public Function GetRTN(ByVal pStrEdi As String) As String
        Dim lParser As InputParser
        Dim lResponse835EDI As MsgInterchange
        Dim lResponseEDI As String = pStrEdi
        Dim l835 As Msg835
        Dim lGeneric As IMessage
        Dim lStrRTN As String = ""
        Dim lTest As String
        Dim lFG As GrpInterchangeFunctionalGroup

        Try
            lParser = New InputParser

            If (lResponseEDI <> "") Then
                lResponse835EDI = lParser.Parse(lResponseEDI)
                lFG = lResponse835EDI.FunctionalGroup.Item(0)
                With lFG.GS
                    lTest = .GroupControlNumber.Value
                End With
                lGeneric = lFG.transactions.Item(0)
                lTest = lGeneric.GetName
                If (lTest = "835") Then
                    l835 = lGeneric
                    With l835.TRN
                        lStrRTN = .ReferenceIdentification1.Value
                    End With
                End If
            End If
            Return lStrRTN
        Catch ex As Exception
            Return ""
        End Try
    End Function
    Public Function GetRTN5010(ByVal pStrEdi As String) As String
        Dim lParser As Response835P5010.InputParser
        Dim lResponse835EDI As Response835P5010.MsgInterchange
        Dim lResponseEDI As String = pStrEdi
        Dim l835 As Response835P5010.Msg835_x221
        Dim lGeneric As Response835P5010.IMessage
        Dim lStrRTN As String = ""
        Dim lTest As String
        Dim lFG As Response835P5010.GrpInterchangeFunctionalGroup

        Try
            lParser = New Response835P5010.InputParser

            If (lResponseEDI <> "") Then
                lResponse835EDI = lParser.Parse(lResponseEDI)
                lFG = lResponse835EDI.FunctionalGroup.Item(0)
                With lFG.GS
                    lTest = .GroupControlNumber.Value
                End With
                lGeneric = lFG.Transactions.Item(0)
                lTest = lGeneric.GetName
                If (lTest = "835_x221") Then
                    l835 = lGeneric
                    With l835.TRN
                        lStrRTN = .ReferenceIdentification.Value
                    End With
                End If
            End If
            Return lStrRTN
        Catch ex As Exception
            Return ""
        End Try
    End Function
    Public Function GetHeader(ByVal pStrEdi As String) As RemittanceHdrDB
        Dim lParser As InputParser
        Dim lResponse835EDI As MsgInterchange
        Dim lResponseEDI As String = pStrEdi
        Dim l835 As Msg835
        Dim lGeneric As IMessage
        'Dim lStrRTN As String = ""
        Dim lTest As String
        Dim lFG As GrpInterchangeFunctionalGroup
        Dim lRemittanceHdrDB As RemittanceHdrDB
        Try
            lParser = New InputParser
            lRemittanceHdrDB = New RemittanceHdrDB()

            If (lResponseEDI <> "") Then
                lResponse835EDI = lParser.Parse(lResponseEDI)
                lFG = lResponse835EDI.FunctionalGroup.Item(0)
                With lFG.GS
                    lTest = .GroupControlNumber.Value
                End With
                lGeneric = lFG.transactions.Item(0)
                lTest = lGeneric.GetName
                If (lTest = "835") Then
                    With l835.BPR
                        lRemittanceHdrDB.CheckAmount = .MonetaryAmount.Value
                        lRemittanceHdrDB.CheckDate = .Date.Value.Substring(0, 4) & "/" & .Date.Value.Substring(4, 2) & "/" & .Date.Value.Substring(6, 2)
                    End With

                    With l835.TRN
                        lRemittanceHdrDB.CheckNumber = .ReferenceIdentification1.Value
                        lRemittanceHdrDB.ReassociationTraceNumber = .ReferenceIdentification1.Value
                    End With

                    With l835.REF1
                        If (.ReferenceIdentificationQualifier.Value = "1C") Then
                            lRemittanceHdrDB.ProviderReference = .ReferenceIdentification.Value
                        End If
                    End With

                    With l835.REF2
                        If (.ReferenceIdentificationQualifier.Value = "1C") Then
                            lRemittanceHdrDB.ProviderReference = .ReferenceIdentification.Value
                        End If
                    End With

                    With l835.DTM
                        If (.DateTimeQualifier.Value = "405") Then
                            lRemittanceHdrDB.ProductionDate = .Date.Value.Substring(0, 4) & "/" & .Date.Value.Substring(4, 2) & "/" & .Date.Value.Substring(6, 2)
                        End If
                    End With

                    With l835.L1000A_835 ''''' Payer Information
                        With .N1
                            lRemittanceHdrDB.PayerName = .EntityName.Value
                        End With

                        With .N3
                            lRemittanceHdrDB.PayerAddress = .AddressInformation1.Value & " " & .AddressInformation2.Value
                        End With

                        With .N4
                            lRemittanceHdrDB.PayerCity = .CityName.Value
                            lRemittanceHdrDB.PayerState = .StateOrProvinceCode.Value
                            lRemittanceHdrDB.PayerZip = .PostalCode.Value
                        End With

                        Dim lGrpREF As RepSegREF
                        lGrpREF = .REF
                        For Each lREF As SegREF In lGrpREF
                            With lREF
                                lRemittanceHdrDB.AdditionalPayerIdentification = .ReferenceIdentification.Value
                            End With
                        Next  '' Payer Ref

                        With .PER
                            lRemittanceHdrDB.PayerContactName = .ContactName.Value
                            lRemittanceHdrDB.PayerCommunicationNumberQualifier = .CommunicationNumberQualifier1.Value
                            lRemittanceHdrDB.PayerCommunicationNumber = .CommunicationNumber1.Value
                        End With
                    End With

                    With l835.L1000B_835 ''Payee Information
                        With .N1
                            lRemittanceHdrDB.PayeeName = .EntityName.Value
                        End With

                        With .N3
                            lRemittanceHdrDB.PayeeAddress = .AddressInformation1.Value & " " & .AddressInformation2.Value
                        End With

                        With .N4
                            lRemittanceHdrDB.PayeeCity = .CityName.Value
                            lRemittanceHdrDB.PayeeState = .StateOrProvinceCode.Value
                            lRemittanceHdrDB.PayeeZip = .PostalCode.Value
                        End With

                        Dim lGrpREF As RepSegREF
                        lGrpREF = .REF
                        For Each lREF As SegREF In lGrpREF 'Payee ref
                            With lREF
                                Select Case .ReferenceIdentificationQualifier.Value
                                    Case "1C"
                                        lRemittanceHdrDB.ProviderReference = .ReferenceIdentification.Value
                                    Case Else
                                        lRemittanceHdrDB.AdditionalPayeeIdentification = .ReferenceIdentification.Value
                                End Select
                            End With
                        Next
                    End With
                End If
            End If
            Return lRemittanceHdrDB
        Catch ex As Exception
            Return Nothing
        End Try
    End Function 
    '' Function to make entry in RemuittanceHdr,RemittanceClaimDtl and RemittanceClaimServiceDetail while
    '' downloading files from gateway FTP
    Public Function PostRemittanceHeaderOnly(ByVal pStrFileNameAndPath As String, ByVal pStrEdi As String) As Boolean

        Dim lBoolResult As Boolean = False
        Dim lResponsePaymentDetailColl As ResponsePaymentDetailColl
        Dim lClaimResponseDB As ClaimResponseDB
        Dim lResponsePaymentDetail As ResponsePaymentDetail
        Dim lStrPaymentDetailXml As String = ""
        Dim lStrPatientLedgerXml As String = ""
        Dim lStrRemittanceClaimDtlXml As String = ""
        Dim lStrRemittanceClaimServiceDtlXml As String = ""
        Dim lPaymentHdr As PaymentHdrDB
        Dim lRemittanceHdr As RemittanceHdrDB
        Dim lClinicConnection As Connection = Nothing
        Dim lFileName As String = ""
        Dim lTimeStampdFileName As String = ""
        Dim lDestnFileNmAndPth As String = ""

        Try
            lResponsePaymentDetailColl = New ResponsePaymentDetailColl
            lClaimResponseDB = New ClaimResponseDB
            lResponsePaymentDetail = New ResponsePaymentDetail
            lPaymentHdr = New PaymentHdrDB
            lRemittanceHdr = New RemittanceHdrDB

            lFileName = pStrFileNameAndPath.Substring(pStrFileNameAndPath.LastIndexOf("\") + 1)
            lTimeStampdFileName = ""
            lTimeStampdFileName = Date.Now.ToString("yyyyMMddTHHmmss") & lFileName
            lDestnFileNmAndPth = pStrFileNameAndPath.Replace("ClaimResponse835", "ClaimResponse835Archive")
            lDestnFileNmAndPth = lDestnFileNmAndPth.Replace(lFileName, lTimeStampdFileName)

            If pStrEdi.Equals("") Then
                Throw New Exception("No content")
            End If


            '' Function to parse 835 file and fill all objects
            lBoolResult = ClaimResponse835.PostRemittance(lStrRemittanceClaimDtlXml, lStrRemittanceClaimServiceDtlXml, lRemittanceHdr, pStrEdi, lClinicConnection)

            If (lBoolResult) Then
                lRemittanceHdr.FileName = lTimeStampdFileName 'lFileName
                lRemittanceHdr.FileContent = pStrEdi
                If (ClaimResponse835.AddRemittanceHdrOnly(lRemittanceHdr, lStrRemittanceClaimDtlXml, lStrRemittanceClaimServiceDtlXml, lClinicConnection)) Then
                    '' Move file from main folder to archive folder with new timestamped file name after sucessful entry in remittance tables
                    Try
                        MoveFiles(pStrFileNameAndPath, lDestnFileNmAndPth)
                    Catch ex As Exception
                    End Try
                    Return True
                    '' Move file from main folder to archive folder with new timestamped file name after sucessful entry in remittance tables
                Else
                    Return False
                End If
            Else
                Return False
            End If

        Catch ex As Exception
            Return False
        End Try

    End Function
    Public Function UpdateRemittanceHdr(ByVal pPaymentId As String, ByVal pReassociationTraceNumber As String) As Boolean
        Dim lUser As User
        Dim lConnection As Connection
        Dim lDS As DataSet
        Dim lQuery As String
        Try
            lUser = CType(HttpContext.Current.Session("User"), User)
            lConnection = New Connection(lUser.ConnectionString)
            lDS = New DataSet
            lQuery = "UPDATE RemittanceHdr SET PaymentId = '" & pPaymentId & "',IsPosted ='Y'  WHERE ReassociationTraceNumber = '" & pReassociationTraceNumber & "' "
            lDS = lConnection.ExecuteQuery(lQuery)
            Return True
        Catch ex As Exception
            Return False
        End Try

    End Function
    Public Function CheckIfAlreadyPosted(ByVal pPayerID As String, ByVal pChequeNo As String) As String
        Dim lUser As User
        Dim lConnection As Connection
        Dim lDS As DataSet
        Dim lQuery As String
        Try
            lUser = CType(HttpContext.Current.Session("User"), User)
            lConnection = New Connection(lUser.ConnectionString)
            lDS = New DataSet
            lQuery = "SELECT  * FROM PaymentHdr where CheckNumber='" & pChequeNo & "' and PayerId='" & pPayerID & "' "
            lDS = lConnection.ExecuteQuery(lQuery)
            If (lDS.Tables(0).Rows.Count > 0) Then
                Return lDS.Tables(0).Rows(0).Item("PaymentID").ToString
            Else
                Return "0"
            End If
        Catch ex As Exception
            Return "0"
        End Try
    End Function
    Public Function GetAlreadyDownloadedFiles() As ArrayList
        Dim lUser As User
        Dim lRemitanceHdr As RemittanceHdr
        Dim lDS As DataSet

        Dim lDownloadedFiles As New System.Collections.ArrayList
        Try
            lUser = CType(HttpContext.Current.Session("User"), User)
            lRemitanceHdr = New RemittanceHdr(lUser.ConnectionString)
            lDS = New DataSet
            lDS = lRemitanceHdr.GetAllRecords()
            If (lDS.Tables(0).Rows.Count > 0) Then
                For Each lItem As System.Data.DataRow In lDS.Tables(0).Rows
                    lDownloadedFiles.Add(lItem.Item("FileName").ToString)
                Next
            End If
        Catch ex As Exception

        End Try
        Return lDownloadedFiles
    End Function
    Public Function PostRemittanceHeaderOnly(ByVal pStrFileNameAndPath As String, ByVal pStrEdi As String, ByVal pIs5010 As Boolean) As Boolean

        Dim lBoolResult As Boolean = False
        Dim lResponsePaymentDetailColl As ResponsePaymentDetailColl
        Dim lClaimResponseDB As ClaimResponseDB
        Dim lResponsePaymentDetail As ResponsePaymentDetail
        Dim lStrPaymentDetailXml As String = ""
        Dim lStrPatientLedgerXml As String = ""
        Dim lStrRemittanceClaimDtlXml As String = ""
        Dim lStrRemittanceClaimServiceDtlXml As String = ""
        Dim lPaymentHdr As PaymentHdrDB
        Dim lRemittanceHdr As RemittanceHdrDB
        Dim lClinicConnection As Connection = Nothing
        Dim lFileName As String = ""
        Dim lTimeStampdFileName As String = ""
        Dim lDestnFileNmAndPth As String = ""

        Try
            lResponsePaymentDetailColl = New ResponsePaymentDetailColl
            lClaimResponseDB = New ClaimResponseDB
            lResponsePaymentDetail = New ResponsePaymentDetail
            lPaymentHdr = New PaymentHdrDB
            lRemittanceHdr = New RemittanceHdrDB

            lFileName = pStrFileNameAndPath.Substring(pStrFileNameAndPath.LastIndexOf("\") + 1)
            lTimeStampdFileName = ""
            lTimeStampdFileName = Date.Now.ToString("yyyyMMddTHHmmss") & lFileName
            lDestnFileNmAndPth = pStrFileNameAndPath.Replace("ClaimResponse835", "ClaimResponse835Archive")
            lDestnFileNmAndPth = lDestnFileNmAndPth.Replace(lFileName, lTimeStampdFileName)

            If pStrEdi.Equals("") Then
                Throw New Exception("No content")
            End If


            '' Function to parse 835 file and fill all objects
            If (pIs5010) Then
                lBoolResult = ClaimResponse835P5010.PostRemittance5010(lStrRemittanceClaimDtlXml, lStrRemittanceClaimServiceDtlXml, lRemittanceHdr, pStrEdi, lClinicConnection)
            Else
                lBoolResult = ClaimResponse835.PostRemittance(lStrRemittanceClaimDtlXml, lStrRemittanceClaimServiceDtlXml, lRemittanceHdr, pStrEdi, lClinicConnection)
            End If

            If (lBoolResult) Then
                lRemittanceHdr.FileName = lTimeStampdFileName 'lFileName
                lRemittanceHdr.FileContent = pStrEdi
                If (ClaimResponse835.AddRemittanceHdrOnly(lRemittanceHdr, lStrRemittanceClaimDtlXml, lStrRemittanceClaimServiceDtlXml, lClinicConnection)) Then
                    '' Move file from main folder to archive folder with new timestamped file name after sucessful entry in remittance tables
                    Try
                        MoveFiles(pStrFileNameAndPath, lDestnFileNmAndPth)
                    Catch ex As Exception
                    End Try
                    Return True
                    '' Move file from main folder to archive folder with new timestamped file name after sucessful entry in remittance tables
                Else
                    Return False
                End If
            Else
                Return False
            End If

        Catch ex As Exception
            Return False
        End Try

    End Function
    Public Function CheckVersion(ByVal pStrEdi As String) As String
        Dim lParser As ClaimResponse.InputParser
        Dim lResponse835EDI As ClaimResponse.MsgInterchange
        Dim lResponseEDI As String = pStrEdi
        Dim lStrVersion As String = ""
        Dim lGs As ClaimResponse.GrpInterchangeFunctionalGroup
        'Dim lTransaction As ClaimResponse.Msg835

        Try
            lParser = New ClaimResponse.InputParser
            If (lResponseEDI <> "") Then
                lResponse835EDI = lParser.Parse(lResponseEDI)
                lGs = lResponse835EDI.FunctionalGroup.Item(0)
                With lGs.GS
                    If (.VersionReleaseIndustryIdentifierCode.Value = "005010X221") Then
                        lStrVersion = "5010"
                    ElseIf (.VersionReleaseIndustryIdentifierCode.Value = "004010X091A1") Then
                        lStrVersion = "4010"
                    End If
                End With
            End If
            Return lStrVersion
        Catch ex As Exception
            Throw New Exception
        End Try
    End Function
End Class
