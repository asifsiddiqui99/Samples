Imports Microsoft.VisualBasic
Imports Telerik.WebControls


Public Class ClaimMethods

    Public Shared Sub LoadClaimGrid(ByRef pGrid As RadGrid, ByVal pCond As String, ByRef pUser As User)
        Dim lClaim As New Claim(pUser.ConnectionString)
        Dim lDs As DataSet

        Try
            lDs = lClaim.GetClaim(pCond)
            pGrid.DataSource = lDs
        Catch ex As Exception

        End Try

    End Sub
    Public Shared Function GetVisitByDate(ByVal pCond As String, ByRef pUser As User) As DataSet
        Dim lClaim As New Claim(pUser.ConnectionString)
        Dim lDs As DataSet

        Try
            lDs = lClaim.GetVisitByDate(pCond)
            Return lDs
        Catch ex As Exception

        End Try

    End Function
    Public Shared Sub LoadClaimGridNew(ByRef pGrid As RadGrid, ByVal pCond As String, ByRef pUser As User)
        Dim lClaim As New Claim(pUser.ConnectionString)
        Dim lDs As DataSet

        Try
            lDs = lClaim.GetClaimNew(pCond)
            pGrid.DataSource = lDs
        Catch ex As Exception

        End Try

    End Sub
    Public Shared Sub UpdateComment(ByRef pPSBID As String, ByVal pComment As String, ByRef pUser As User)
        Dim lClaim As New Claim(pUser.ConnectionString)

        Try
            lClaim.UpdateComment(pPSBID, pComment)

        Catch ex As Exception

        End Try

    End Sub

    Public Shared Function DeleteClaim(ByVal pUser As User, ByVal pPatientSuperBillId As String) As Boolean
        Dim lClaim As New Claim(pUser.ConnectionString)
        Dim lResult As Boolean
        Dim lEventLog As New EventLog()
        Dim lUser As User

        Try
            lUser = CType(HttpContext.Current.Session("User"), User)
            lResult = lClaim.DeleteClaim(pPatientSuperBillId)

            If (lResult) Then
                lEventLog.EventLog.ClinicID = lUser.ClinicId
                lEventLog.EventLog.OCcurTime = Date.Now()
                lEventLog.EventLog.EventTypeID = EventType.DeleteSuperBill
                lEventLog.EventLog.ExtraID = pPatientSuperBillId
                lEventLog.EventLog.UserID = lUser.UserId
                lEventLog.EventLog.EventDescription = "A SuperBill of ID '" + pPatientSuperBillId.ToString() + "' has been deleted of the clinic having ClinicID '" + lUser.ClinicId + "' on '" + lEventLog.EventLog.OCcurTime + "' by the loginID '" + lUser.LoginId + "'"
                lEventLog.HandleEvent()
            End If
            Return lResult
        Catch ex As Exception
            Return False
        End Try

    End Function

    Public Shared Sub LoadClaimCPTGrid(ByRef pGrid As RadGrid, ByVal pPatientSuperBillID As String, ByVal pSuperBillId As String, ByVal pOrderBy As String, ByVal pGridNo As Integer)
        Dim lUser As User
        Dim lCPT As CPT
        Dim lArrOrderBy As String()
        Dim lOrderColumn As String = ""
        Dim lOrder As String = ""


        If pOrderBy <> "" Then
            lArrOrderBy = pOrderBy.Split("|")
            lOrderColumn = IIf(lArrOrderBy(2) = "C", "Code", "ShortDescription")
            lOrder = IIf(Left(lArrOrderBy(3), 1) = "A", " ", "Desc")
        End If

        lUser = CType(HttpContext.Current.Session("User"), User)
        lCPT = New CPT(lUser.ConnectionString)

        lCPT.CPT.SuperBillId = pSuperBillId
        lCPT.CPT.PatientSuperBillId = pPatientSuperBillID

        Dim lDataSet As DataTable = Nothing
        lDataSet = lCPT.GetCPTForClaim("Order By HeadingOrder," & lOrderColumn & " " & lOrder).Tables(pGridNo)
        pGrid.DataSource = lDataSet

    End Sub

    Public Shared Sub LoadICDGridForClaim(ByRef pGrid As RadGrid, ByVal pPatientSuperBillID As String, ByVal pSuperBillId As String, ByVal pOrderBy As String, ByVal pGridNo As Integer)
        Dim lUser As User
        Dim lICD As ICD9
        Dim lArrOrderBy As String()
        Dim lOrderColumn As String = ""
        Dim lOrder As String = ""



        If pOrderBy <> "" Then
            lArrOrderBy = pOrderBy.Split("|")
            lOrderColumn = IIf(lArrOrderBy(0) = "C", "Code", "Description")
            lOrder = IIf(Left(lArrOrderBy(1), 1) = "A", " ", "Desc")
        End If

        lUser = CType(HttpContext.Current.Session("User"), User)
        lICD = New ICD9(lUser.ConnectionString)

        lICD.ICD9.SuperBillId = pSuperBillId
        lICD.ICD9.PatientSuperBillId = pPatientSuperBillID
        pGrid.DataSource = lICD.GetICDForClaim("Order By " & lOrderColumn & " " & lOrder).Tables(pGridNo)
    End Sub

    'This function returns the value of the ICD textboxes 
    Public Shared Function GetICDForBillingGrid( _
    ByVal pPatientSuperBillID As String _
    ) As DataSet

        Dim lICD As ICD9 = Nothing
        Dim lDS As DataSet = Nothing

        Try

            Dim lUser As User = CType(HttpContext.Current.Session("User"), User)
            lICD = New ICD9(lUser.ConnectionString)

            lDS = lICD.GetICDBySuperBillID(pPatientSuperBillID)
            Return lDS


        Catch ex As Exception
            Return Nothing
        End Try

    End Function


    'This function returns the value of the ICD textboxes 
    Public Shared Function GetCPTForBillingGrid( _
    ByVal pPatientSuperBillID As String _
    ) As DataSet

        Dim lCPT As CPT = Nothing
        Dim lDS As DataSet = Nothing

        Try

            Dim lUser As User = CType(HttpContext.Current.Session("User"), User)
            lCPT = New CPT(lUser.ConnectionString)

            lDS = lCPT.GetCPTBySuperBillID(pPatientSuperBillID)
            Return lDS


        Catch ex As Exception
            Return Nothing
        End Try

    End Function

    'This Function returnd HCHA send date 

    Public Shared Function GetClaimSendDate(ByVal pHCFAIDID As String) As String

        Dim lUser As User = CType(HttpContext.Current.Session("User"), User)

        Dim lClaimBatchHdr As New ClaimBatchHdr(lUser.ConnectionString)

        Dim lSendDate = lClaimBatchHdr.GetSendDate(pHCFAIDID)

        Return lSendDate

    End Function
    Public Shared Function GetOutstandingClaim(ByVal pCond As String, ByRef pUser As User) As DataSet
        Dim lClaim As New Claim(pUser.ConnectionString)

        Try
            Return lClaim.GetOutstandingClaim(pCond)

        Catch ex As Exception

        End Try

    End Function
End Class
