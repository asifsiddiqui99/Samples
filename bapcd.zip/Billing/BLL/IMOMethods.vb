Imports Microsoft.VisualBasic

Public Class IMOMethods
    'Public Shared Function SearchICD(ByVal pSearchCriteria As String) As String

    '    Dim lResultXml As String = String.Empty
    '    Dim lSearchCondition As String = String.Empty

    '    Try
    '        If (pSearchCriteria = "") Then
    '            Return ""
    '        End If
    '        lSearchCondition = "search^20|0|1^" & pSearchCriteria
    '        lResultXml = ServiceConnection.CallIMOProblemITService(lSearchCondition, "ICD")

    '    Catch ex As Exception
    '        lResultXml = ""
    '    End Try

    '    Return lResultXml

    'End Function

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="pSearchCriteria"></param>
    ''' <returns></returns>
    '''  <remarks>Affan Toor | 05-11-12</remarks>
    Public Shared Function SearchICD(ByVal pSearchCriteria As String) As DataSet

        'Dim lResultXml As String = String.Empty
        'Dim lSearchCondition As String = String.Empty

        'Try
        '    If (pSearchCriteria = "") Then
        '        Return ""
        '    End If
        '    lSearchCondition = "search^20|0|1^" & pSearchCriteria
        '    lResultXml = ServiceConnection.CallIMOProblemITService(lSearchCondition, "ICD")

        'Catch ex As Exception
        '    lResultXml = ""
        'End Try

        'Return lResultXml

        Dim lICD As New ICD9()
        Dim lDs As DataSet

        Try
            lDs = lICD.SearchICD9(pSearchCriteria)
            Return lDs
        Catch ex As Exception
            Return Nothing
        End Try

    End Function

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="pSearchCriteria"></param>
    ''' <returns></returns>
    '''  <remarks>Affan Toor | 05-11-12</remarks>
    Public Shared Function SearchICD9(ByVal pSearchCriteria As String) As DataSet

        'Dim lResultXml As String = String.Empty
        'Dim lSearchCondition As String = String.Empty

        'Try
        '    If (pSearchCriteria = "") Then
        '        Return ""
        '    End If
        '    lSearchCondition = "search^20|0|1^" & pSearchCriteria
        '    lResultXml = ServiceConnection.CallIMOProblemITService(lSearchCondition, "ICD")

        'Catch ex As Exception
        '    lResultXml = ""
        'End Try

        'Return lResultXml

        Dim lICD As New ICD9()
        Dim lDs As DataSet

        Try
            lDs = lICD.SearchICD9ByCode(pSearchCriteria)
            Return lDs
        Catch ex As Exception
            Return Nothing
        End Try

    End Function

    Public Shared Function ICDDescription(ByVal pICDCode As String) As String

        Dim lResultXml As String = String.Empty
        Dim lSearchCondition As String = String.Empty

        Try
            If (pICDCode = "") Then
                Return ""
            End If
            lSearchCondition = "detail^" & pICDCode
            lResultXml = ServiceConnection.CallIMOProblemITService(lSearchCondition, "ICDDESC")
        Catch ex As Exception
            lResultXml = ""
        End Try

        Return lResultXml

    End Function

    Public Shared Function CheckMedicalNecassity(ByVal pICDCodelist As String, ByVal pCPT As String, ByVal pContractor As String) As String
        Dim lResultXml As String = String.Empty
        Dim lSearchCondition As String = String.Empty

        Try
            If (pICDCodelist = "") Then
                Return ""
            End If

            lSearchCondition = "search^1^" & pContractor & "|" & pICDCodelist & "|" & pCPT
            lResultXml = ServiceConnection.CallIMOProblemITService(lSearchCondition, "MED")
        Catch ex As Exception
            lResultXml = ""
        End Try

        Return lResultXml

    End Function

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="pUser"></param>
    ''' <param name="pDescription"></param>
    ''' <returns></returns>
    '''  <remarks>Affan Toor | 05-11-12</remarks>
    Public Shared Function SearchCPT(ByRef pUser As User, ByVal pCPTCode As String, ByVal pInsuranceCompanyID As String) As DataSet

        Dim lCPT As New CPT(pUser.ConnectionString)
        Dim lDs As DataSet

        Try
            lDs = lCPT.SearchProcedureCodesByCPT(pCPTCode, pInsuranceCompanyID)
            Return lDs
        Catch ex As Exception
            Return Nothing
        End Try


        'Dim lResultXml As String = String.Empty
        'Dim lSearchCondition As String = String.Empty

        'Try
        '    If (pSearchCriteria = "") Then
        '        Return ""
        '    End If

        '    lSearchCondition = "search^20|0|1^" & pSearchCriteria
        '    lResultXml = ServiceConnection.CallIMOProblemITService(lSearchCondition, "CPT")
        'Catch ex As Exception
        '    lResultXml = ""
        'End Try

        'Return lResultXml

    End Function

    Public Shared Function GetFeeByCPTAndInsuranceID(ByRef pUser As User, ByVal pCPTCode As String, ByVal pInsuranceCompanyID As String) As String

        Dim lCPT As New CPT(pUser.ConnectionString)
        Dim lDs As DataSet
        Dim lFee As String = "0"

        Try
            lDs = lCPT.GetFeeByCPTAndInsuranceID(pCPTCode, pInsuranceCompanyID)

            If lDs IsNot Nothing Then
                lFee = lDs.Tables(0).Rows(0)(0).ToString()
            End If

            Return lFee
        Catch ex As Exception
            Return Nothing
        End Try

    End Function

    Public Shared Function SearchCPT(ByRef pUser As User, ByVal pCPTCode As String) As DataSet
        Dim lCPT As New CPT()
        Dim lDs As DataSet

        Try
            lDs = lCPT.SearchProcedureCodesByCPT(pCPTCode)
            Return lDs
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="pCPTCode"></param>
    ''' <returns></returns>
    ''' <remarks>Author: Affan Toor | 02-01-13</remarks>
    Public Shared Function GeDetailByCPTCode(ByRef pCPTCode As String) As DataSet

        Dim lCPT As New CPT()
        Dim lDs As DataSet

        Try
            lDs = lCPT.GetIMOCodeByCPT(pCPTCode)
            Return lDs
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="pICDCode"></param>
    ''' <returns></returns>
    ''' <remarks>Author: Affan Toor | 04-01-13</remarks>
    Public Shared Function GeDetailByICDCode(ByRef pICDCode As String) As DataSet

        Dim lICD As New ICD9()
        Dim lDs As DataSet

        Try
            lDs = lICD.GetIMOCodeByICD(pICDCode)
            Return lDs
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="pICDCode"></param>
    ''' <returns></returns>
    ''' <remarks>Affan Toor | 07-11-12</remarks>
    Public Shared Function GetIMOCodeByICD(ByVal pICDCode As String) As String

        Dim lICD As New ICD9()
        Dim lDs As DataSet
        Dim lIMOCode As String = ""

        Try
            lDs = lICD.GetIMOCodeByICD(pICDCode)

            If lDs IsNot Nothing Then
                lIMOCode = lDs.Tables(0).Rows(0)("ICD9CodeId").ToString()
            End If

            Return lIMOCode
        Catch ex As Exception
            Return Nothing
        End Try

    End Function

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="pCPTCode"></param>
    ''' <returns></returns>
    ''' <remarks>Affan Toor | 07-11-12</remarks>
    Public Shared Function GetIMOCodeByCPT(ByVal pCPTCode As String) As String

        Dim lCPT As New CPT()
        Dim lDs As DataSet
        Dim lIMOCode As String = ""

        Try
            lDs = lCPT.GetIMOCodeByCPT(pCPTCode)

            If lDs IsNot Nothing Then
                lIMOCode = lDs.Tables(0).Rows(0)("ProcedureCodeId").ToString()
            End If

            Return lIMOCode
        Catch ex As Exception
            Return Nothing
        End Try

    End Function

End Class

