Imports Microsoft.VisualBasic
Imports Telerik.WebControls

Public Class PatientLedgerMethods

    Public Shared Function SavePatientLedger(ByRef ppnlBillingInfo As Panel, ByVal pPatientSuperBill As PatientSuperBillDB) As Boolean

        Dim lLineNumber As Integer = 1
        Dim lUser As User
        Dim lConnection As Connection
        Dim lCharges As Double = 0.0
        Dim lCPTs As String = ""

        lUser = CType(HttpContext.Current.Session("User"), User)
        lConnection = New Connection(lUser.ConnectionString)

        Dim lPatientLedgerDB As PatientLedgerDB
        Dim lPatientLedger As New PatientLedger(lConnection)


        Try



            For lLineNumber = 1 To 6
                If CType(ppnlBillingInfo.FindControl("cmbCPT" & lLineNumber.ToString), RadComboBox).Text <> "" And CType(ppnlBillingInfo.FindControl("txtCharges" & lLineNumber.ToString), TextBox).Text <> "" Then
                    If (CType(ppnlBillingInfo.FindControl("txtLineId" & lLineNumber.ToString), TextBox).Text = "0") Then
                        lCharges = lCharges + (Convert.ToDouble(CType(ppnlBillingInfo.FindControl("txtCharges" & lLineNumber.ToString), TextBox).Text) * Convert.ToDouble(CType(ppnlBillingInfo.FindControl("txtDays" & lLineNumber.ToString), TextBox).Text))
                        lCPTs = lCPTs & "," & CType(ppnlBillingInfo.FindControl("cmbCPT" & lLineNumber.ToString), RadComboBox).Text
                    End If
                End If
            Next

            If (lCharges = 0.0 AndAlso lCPTs = "") Then
                Exit Function
            End If

            If (lCPTs <> "" AndAlso lCPTs.Substring(0, 1) = ",") Then
                lCPTs = lCPTs.Remove(0, 1)
            End If

            lCPTs = "CPT: " & lCPTs

            lPatientLedgerDB = New PatientLedgerDB()

            With lPatientLedgerDB

                .ReferenceID = pPatientSuperBill.PatientSuperBillID
                .ReferenceDate = pPatientSuperBill.VisitDisplayDATE
                .TransactionType = "V"
                .Reference = lCPTs
                '.Date1 = CType(ppnlBillingInfo.FindControl("dtDate" & lLineNumber.ToString & "1"), RadDatePicker).SelectedDate
                '.Debit = CType(ppnlBillingInfo.FindControl("txtCharges" & lLineNumber.ToString), TextBox).Text
                '.Description = CType(ppnlBillingInfo.FindControl("txtDescription" & lLineNumber.ToString), TextBox).Text
                .Date1 = pPatientSuperBill.DateOfService
                .Debit = lCharges
                .Description = "Patient Visit"
                .PatientID = pPatientSuperBill.PatientId
                .ReferenceDisplayID = pPatientSuperBill.PatientSuperBillDisplayID
                .ReferenceDate2 = ""
                .ReferenceDisplayDate = pPatientSuperBill.VisitDisplayDATE

                .ChequeNumber = "" 'pPatientSuperBill.ChequeNumber
                .ChequeDate = "" 'pPatientSuperBill.ChequeDate

            End With




            lPatientLedger.PatientLedger = lPatientLedgerDB
            lPatientLedger.InsertPatientLedger()





        Catch ex As Exception
            Return False
        End Try

        Return True

    End Function
    Public Shared Function SavePatientLedgerForHcFA(ByVal pDisplayID As String, ByVal pInsuranceName As String, ByVal pDate As String, ByVal pReferenceID As String, ByVal pPatientID As String) As Boolean


        Dim lUser As User
        Dim lConnection As Connection


        lUser = CType(HttpContext.Current.Session("User"), User)

        lConnection = New Connection(lUser.ConnectionString)
        Dim lPatientLedgerDB As PatientLedgerDB
        Dim lPatientLedger As New PatientLedger(lConnection)

        lPatientLedgerDB = New PatientLedgerDB()

        lPatientLedgerDB.Description = "Billed " & pInsuranceName
        lPatientLedgerDB.ReferenceDate = pDate
        lPatientLedgerDB.Reference = pDisplayID
        lPatientLedgerDB.ReferenceID = pReferenceID
        lPatientLedgerDB.PatientID = pPatientID




        lPatientLedger.PatientLedger = lPatientLedgerDB
        lPatientLedger.InsertPatientLedger()

        Return True

    End Function
    Public Shared Function SavePatientLedgerForPayment(ByVal pPaymentHdr As PaymentHdrDB, ByVal pSelectedItems As Hashtable) As Boolean

        Dim lUser As User
        Dim lConnection As Connection
        Dim lOrignalBalance As Double = 0.0
        Dim lBalance As Double = 0.0
        Dim lOrignalBalanceForCondition As Double = 0.0
        Dim lBalanceForCondition As Double = 0.0
        Dim lAdjustmentSum As Double = 0.0

        lUser = CType(HttpContext.Current.Session("User"), User)
        lConnection = New Connection(lUser.ConnectionString)

        Dim lPatientLedgerDB As PatientLedgerDB
        Dim lPatientLedger As New PatientLedger(lConnection)

        Dim lClaimDtlCPTCodes As String = ""
        Dim lClaimDtlVisitNumericID As String = ""
        Dim lClaimDtlAmountPaid As Double = 0.0
        Dim lAdjustments As Double = 0.0
        Dim lPaymentSum As Double = 0.0
        Dim lTotalPayment As Double = 0.0

        Dim lRemovedIDs As Hashtable
        Dim lPaymentSumOfRemovedIDs As Double = 0.0

        For Each lClaimHdr As ClaimHdrDB In pSelectedItems.Values
            lClaimDtlAmountPaid = 0.0
            lOrignalBalance = 0.0
            lBalance = 0.0
            lClaimDtlVisitNumericID = ""
            lAdjustments = 0.0
            lClaimDtlCPTCodes = ""
            For Each lClaimDtl As ClaimDtlDB In lClaimHdr.ClaimDtlColl
                lOrignalBalanceForCondition = CType(IIf(lClaimDtl.OrignalBalance = "", 0, lClaimDtl.OrignalBalance), Double)
                lBalanceForCondition = CType(IIf(lClaimDtl.Balance = "", 0, lClaimDtl.Balance), Double)
                If (lOrignalBalanceForCondition <> lBalanceForCondition) And (Not lClaimDtl.CPTCode.Equals("Total")) Then
                    lClaimDtlCPTCodes = lClaimDtlCPTCodes & "," & lClaimDtl.CPTCode
                    lOrignalBalance = lOrignalBalance + CType(IIf(lClaimDtl.OrignalBalance = "", 0, lClaimDtl.OrignalBalance), Double)
                    lBalance = lBalance + CType(IIf(lClaimDtl.Balance = "", 0, lClaimDtl.Balance), Double)
                End If
                If (Not lClaimDtl.CPTCode.Equals("Total")) Then
                    lClaimDtlVisitNumericID = lClaimDtl.VisitNumericID
                    lClaimDtlAmountPaid = lClaimDtlAmountPaid + Convert.ToDouble(lClaimDtl.AmountPaid)
                    lAdjustments = lAdjustments + Convert.ToDouble(lClaimDtl.Adjustment)
                End If
            Next

            If (lClaimDtlCPTCodes.Contains(",")) Then
                If (lClaimDtlCPTCodes.Substring(0, 1) = ",") Then
                    lClaimDtlCPTCodes = lClaimDtlCPTCodes.Remove(0, 1)
                End If
            End If

            lClaimDtlCPTCodes = "CPT: " & lClaimDtlCPTCodes

            'lOrignalBalance = CType(IIf(lClaimDtl.OrignalBalance = "", 0, lClaimDtl.OrignalBalance), Double)
            'lBalance = CType(IIf(lClaimDtl.Balance = "", 0, lClaimDtl.Balance), Double)

            'If (lOrignalBalance <> lBalance) And (Not lClaimDtl.CPTCode.Equals("Total")) Then

            lPatientLedgerDB = New PatientLedgerDB()

            With lPatientLedgerDB
                .Date1 = Date.Now.ToString("MM/dd/yyyy")
                '.ReferenceDate = pPaymentHdr.PaymentDate
                .ReferenceDate = pPaymentHdr.PaymentDispDate
                .ReferenceDate2 = lClaimHdr.HCFAPreparedDate 'This is basically the VisitDate; due to time constraints it has not been renamed
                If (pPaymentHdr.CheckDate = "1/1/1980") Then
                    '.Date1 = String.Empty
                    .ChequeDate = String.Empty
                Else
                    '.Date1 = pPaymentHdr.ChequeDate
                    .ChequeDate = pPaymentHdr.CheckDate
                End If
                '.Reference = lClaimDtl.CPTCode
                '.ReferenceID2 = lClaimDtl.VisitNumericID
                '.Adjustment = lClaimDtl.Adjustment
                '.Credit = lClaimDtl.AmountPaid
                .Reference = lClaimDtlCPTCodes
                .ReferenceID2 = lClaimDtlVisitNumericID
                .Adjustment = "0"
                '.Credit = lClaimDtlAmountPaid
                .TransactionType = "P"
                .ReferenceID = pPaymentHdr.PaymentID
                .PatientID = lClaimHdr.PatientId
                .Description = pPaymentHdr.Description
                .PaymentMethod = pPaymentHdr.PaymentMode
                .PayerName = pPaymentHdr.PayerName
                .PayerType = pPaymentHdr.PayerType
                .ReferenceDisplayID = CDate(pPaymentHdr.PaymentDate).Year.ToString().PadLeft(2, "0") & "-" & CDate(pPaymentHdr.PaymentDate).Month.ToString().PadLeft(2, "0") & "-" & pPaymentHdr.DisplayID.PadLeft(5, "0")
                .ReferenceDisplayID2 = lClaimHdr.VisitID
                .ReferenceDisplayDate = pPaymentHdr.PaymentDispDate
                .ChequeNumber = pPaymentHdr.CheckDate
                If (pPaymentHdr.PayerType.ToUpper = "P") Then
                    If (pPaymentHdr.PaymentMode.ToUpper = "CASH") Then
                        .Description = "Payment received from patient ( " & pPaymentHdr.PayerName & " ) by cash"
                    ElseIf (pPaymentHdr.PaymentMode.ToUpper = "CHECK") Then
                        If (pPaymentHdr.CheckDate <> "") Then
                            .Description = "Payment received from patient ( " & pPaymentHdr.PayerName & " ) by check no: " & pPaymentHdr.CheckNumber
                        Else
                            .Description = "Payment received from patient ( " & pPaymentHdr.PayerName & " ) by check."
                        End If
                    Else
                        .Description = "Payment received from patient ( " & pPaymentHdr.PayerName & " ) by credit card "
                    End If
                ElseIf (pPaymentHdr.PayerType.ToUpper = "I") Then
                    If (pPaymentHdr.PaymentMode.ToUpper = "CHECK") Then
                        If (pPaymentHdr.CheckNumber <> "") Then
                            .Description = "Payment received from Insurance Company ( " & pPaymentHdr.PayerName & " ) by check no: " & pPaymentHdr.CheckNumber
                        Else
                            .Description = "Payment received from Insurance Company ( " & pPaymentHdr.PayerName & " ) by check."
                        End If
                    ElseIf (pPaymentHdr.PaymentMode.ToUpper = "CASH") Then
                        .Description = "Payment received from Insurance Company ( " & pPaymentHdr.PayerName & " ) by cash."
                    Else
                        .Description = "Payment received from Insurance Company ( " & pPaymentHdr.PayerName & " )."
                    End If
                End If

                lPaymentSum = lPatientLedger.GetPreviousPaymentSum(lClaimDtlVisitNumericID, pPaymentHdr.PaymentID)
                lTotalPayment = lClaimDtlAmountPaid - lPaymentSum

                If (lTotalPayment <> 0) Then
                    If (lTotalPayment > 0) Then
                        .Credit = lTotalPayment
                        lPatientLedger.PatientLedger = lPatientLedgerDB
                        lPatientLedger.InsertPatientLedger()
                    ElseIf (lTotalPayment < 0) Then
                        .Reference = "Payment ID:" & CDate(pPaymentHdr.PaymentDate).Year.ToString().PadLeft(2, "0") & "-" & CDate(pPaymentHdr.PaymentDate).Month.ToString().PadLeft(2, "0") & "-" & pPaymentHdr.DisplayID.PadLeft(5, "0")
                        .Debit = lTotalPayment.ToString.Remove(0, 1)
                        .Description = "Payment reversal entry"
                        lPatientLedger.PatientLedger = lPatientLedgerDB
                        lPatientLedger.InsertPatientLedger()
                    End If
                End If

                lPatientLedger.PatientLedger.Credit = "0"
                lPatientLedger.PatientLedger.Debit = "0"
                lAdjustmentSum = lPatientLedger.GetPreviousAdjustmenstSum(lClaimDtlVisitNumericID)
                lAdjustments = lAdjustments - lAdjustmentSum
                If (lAdjustments > 0) Then
                    .Reference = lClaimDtlCPTCodes
                    lPatientLedger.PatientLedger.Adjustment = lAdjustments
                    lPatientLedger.PatientLedger.TransactionType = "A"
                    lPatientLedger.PatientLedger.Description = "Adjustment"
                    lPatientLedger.InsertPatientLedger()
                End If
            End With
            'End If
        Next

        If (HttpContext.Current.Session("RemovedIDs") IsNot Nothing) Then
            lRemovedIDs = HttpContext.Current.Session("RemovedIDs")
            For Each lID As DictionaryEntry In lRemovedIDs

                Dim lVisitID As String = lID.Value.ToString.Split(",")(0)
                Dim lPatientID As String = lID.Value.ToString.Split(",")(1)
                Dim lVisitdate As String = lID.Value.ToString.Split(",")(2)
                Dim lVisitDisplayID As String = lID.Value.ToString.Split(",")(3)

                lPaymentSumOfRemovedIDs = lPatientLedger.GetPreviousPaymentSum(lVisitID, pPaymentHdr.PaymentID)
                If (lPaymentSumOfRemovedIDs <> 0) Then

                    lPatientLedgerDB = New PatientLedgerDB()
                    With lPatientLedgerDB
                        .Date1 = Date.Now.ToString("MM/dd/yyyy")
                        '.ReferenceDate = pPaymentHdr.PaymentDate
                        .ReferenceDate = pPaymentHdr.PaymentDispDate
                        .ReferenceDate2 = lVisitdate
                        If (pPaymentHdr.CheckDate = "1/1/1980") Then
                            .ChequeDate = String.Empty
                        Else
                            .ChequeDate = pPaymentHdr.CheckDate
                        End If
                        .Reference = "Payment ID:" & CDate(pPaymentHdr.PaymentDate).Year.ToString().PadLeft(2, "0") & "-" & CDate(pPaymentHdr.PaymentDate).Month.ToString().PadLeft(2, "0") & "-" & pPaymentHdr.DisplayID.PadLeft(5, "0")
                        .ReferenceID2 = lVisitID
                        .Adjustment = "0"
                        .TransactionType = "P"
                        .ReferenceID = pPaymentHdr.PaymentID
                        .PatientID = lPatientID
                        .Description = pPaymentHdr.Description
                        .PaymentMethod = pPaymentHdr.PaymentMode
                        .PayerName = pPaymentHdr.PayerName
                        .PayerType = pPaymentHdr.PayerType
                        .ReferenceDisplayID = CDate(pPaymentHdr.PaymentDate).Year.ToString().PadLeft(2, "0") & "-" & CDate(pPaymentHdr.PaymentDate).Month.ToString().PadLeft(2, "0") & "-" & pPaymentHdr.DisplayID.PadLeft(6, "0")
                        .ReferenceDisplayID2 = lVisitDisplayID
                        .ReferenceDisplayDate = pPaymentHdr.PaymentDispDate
                        .ChequeNumber = pPaymentHdr.CheckNumber
                        .Debit = lPaymentSumOfRemovedIDs
                        .Description = "Reversal entry of payment '" & CDate(pPaymentHdr.PaymentDate).Year.ToString().PadLeft(2, "0") & "-" & CDate(pPaymentHdr.PaymentDate).Month.ToString().PadLeft(2, "0") & "-" & pPaymentHdr.DisplayID.PadLeft(5, "0") & "'"
                        .Credit = "0"
                        .Adjustment = "0"
                    End With
                    lPatientLedger.PatientLedger = lPatientLedgerDB
                    lPatientLedger.InsertPatientLedger()
                End If
            Next
            HttpContext.Current.Session.Remove("RemovedIDs")
        End If
        Return True
    End Function
    Public Shared Function GetPatientLedger(ByVal pPatientID As String, ByVal pDateFrom As Date, ByVal pDateTo As Date) As DataSet
        Dim lUser As User
        Dim lConnection As Connection
        Dim lDS As New DataSet
        'Dim lCondition As String = ""
        Try
            'lCondition = " PatientID='" & pPatientID & "' and Date Between '" & pDateFrom.Date & "' And '" & pDateTo.Date & ""
            lUser = CType(HttpContext.Current.Session("User"), User)
            lConnection = New Connection(lUser.ConnectionString)
            Dim lPatientLedger As New PatientLedger(lConnection)
            lDS = lPatientLedger.GetPatientLedger(pPatientID, pDateFrom, pDateTo)
            Return lDS
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Public Shared Function SaveVisitReversalEntry(ByVal pAdjustmentID As String, ByVal pCommentsAndCode As String, ByVal pPatientSuperBill As PatientSuperBillDB, ByVal pPatientLedger As PatientLedger) As Boolean
        Dim lLineNumber As Integer = 1
        Dim lCharges As Double = 0.0
        Dim lCPTs As String = ""
        Dim lPatientLedgerDB As PatientLedgerDB
        Dim lReversedRows() As String

        'Dim lPatientLedger As New PatientLedger(pConnection)
        'Dim lArrayList As New ArrayList

        Try
            'lArrayList = pPatientLedger.GetVisitReversalChargesSum(pLineIDs)
            'lCharges = lArrayList.Item(0)
            'lCPTs = lArrayList.Item(1)

            If (pCommentsAndCode.Contains("|")) Then
                lReversedRows = pCommentsAndCode.Split("|")
                For Each lChargesData As String In lReversedRows
                    If (lChargesData.Contains(";") AndAlso lChargesData.Contains(":")) Then
                        'lCharges = lCharges + lChargesData.Split(",")(1).ToString.Split(":")(1)
                        'lCPTs = lCPTs + lChargesData.Split(",")(0).ToString.Split(":")(1)
                        lPatientLedgerDB = New PatientLedgerDB()
                        With lPatientLedgerDB
                            .ReferenceID = pAdjustmentID
                            .ReferenceID2 = pPatientSuperBill.PatientSuperBillID
                            '.ReferenceDate = pPatientSuperBill.VisitDisplayDATE
                            .ReferenceDate = Date.Now.Date
                            .TransactionType = "A"
                            .Reference = lChargesData.Split(";")(0).ToString.Split(":")(1)
                            .Date1 = Date.Now.Date
                            .Debit = "0"
                            .Credit = lChargesData.Split(";")(1).ToString.Split(":")(1)
                            .Description = "Visit Reversal Entry for " & lChargesData.Split(";")(0).ToString & " , " & lChargesData.Split(";")(1).ToString & " , " & lChargesData.Split(";")(3).ToString
                            .PatientID = pPatientSuperBill.PatientId
                            .ReferenceDisplayID = pPatientSuperBill.PatientSuperBillDisplayID
                            .ReferenceDate2 = lChargesData.Split(";")(2).ToString.Split(":")(1)
                            .ReferenceDisplayDate = pPatientSuperBill.VisitDisplayDATE
                            .ChequeNumber = pPatientSuperBill.ChequeNumber
                            .ChequeDate = pPatientSuperBill.ChequeDate
                        End With
                        pPatientLedger.PatientLedger = lPatientLedgerDB
                        pPatientLedger.InsertPatientLedger()
                    End If
                Next
            End If



            'lPatientLedgerDB = New PatientLedgerDB()
            'With lPatientLedgerDB
            '    .ReferenceID = pAdjustmentID
            '    .ReferenceID2 = pPatientSuperBill.PatientSuperBillID
            '    .ReferenceDate = pPatientSuperBill.VisitDisplayDATE
            '    .TransactionType = "A"
            '    .Reference = lCPTs
            '    .Date1 = pPatientSuperBill.DateOfService
            '    .Debit = "0"
            '    .Credit = lCharges
            '    .Description = "Visit Reversal Entry:: " & pCommentsAndCode
            '    .PatientID = pPatientSuperBill.PatientId
            '    .ReferenceDisplayID = pPatientSuperBill.PatientSuperBillDisplayID
            '    .ReferenceDate2 = ""
            '    .ReferenceDisplayDate = pPatientSuperBill.VisitDisplayDATE
            '    .ChequeNumber = pPatientSuperBill.ChequeNumber
            '    .ChequeDate = pPatientSuperBill.ChequeDate
            'End With
            'pPatientLedger.PatientLedger = lPatientLedgerDB
            'pPatientLedger.InsertPatientLedger()

        Catch ex As Exception
            Return False
        End Try
        Return True
    End Function
    Public Shared Function CptLogicalDelete(ByVal pLineIds As String, ByVal pPatientLedger As PatientLedger) As Boolean
        'Dim lPatientLedger As PatientLedger
        Try
            'lPatientLedger = New PatientLedger(pConnection)
            pPatientLedger.CptLogicalDelete(pLineIds)
        Catch ex As Exception

        End Try
    End Function

    Public Shared Function SavePatientLedger(ByRef ppnlBillingInfo As Panel, ByVal pPatientSuperBill As PatientSuperBillDB, ByVal pPatientLedger As PatientLedger) As Boolean

        Dim lLineNumber As Integer = 1
        Dim lCharges As Double = 0.0
        Dim lCPTs As String = ""
        Dim lPatientLedgerDB As PatientLedgerDB
        'Dim lPatientLedger As New PatientLedger(pConnection)
        Try
            For lLineNumber = 1 To 6
                If CType(ppnlBillingInfo.FindControl("cmbCPT" & lLineNumber.ToString), RadComboBox).Text <> "" And CType(ppnlBillingInfo.FindControl("txtCharges" & lLineNumber.ToString), TextBox).Text <> "" Then
                    If (CType(ppnlBillingInfo.FindControl("cmbCPT" & lLineNumber.ToString), RadComboBox).Text <> "") Then
                        If (CType(ppnlBillingInfo.FindControl("txtLineId" & lLineNumber.ToString), TextBox).Text = "0") Then
                            'lCharges = lCharges + (Convert.ToDouble(CType(ppnlBillingInfo.FindControl("txtCharges" & lLineNumber.ToString), TextBox).Text) * Convert.ToDouble(CType(ppnlBillingInfo.FindControl("txtDays" & lLineNumber.ToString), TextBox).Text))
                            'lCPTs = lCPTs & "," & CType(ppnlBillingInfo.FindControl("cmbCPT" & lLineNumber.ToString), TextBox).Text
                            lPatientLedgerDB = New PatientLedgerDB()
                            With lPatientLedgerDB
                                .ReferenceID = pPatientSuperBill.PatientSuperBillID
                                .ReferenceDate = CType(ppnlBillingInfo.FindControl("dtDate" & lLineNumber.ToString & "1"), RadDatePicker).SelectedDate
                                .TransactionType = "V"
                                .Reference = CType(ppnlBillingInfo.FindControl("cmbCPT" & lLineNumber.ToString), RadComboBox).Text
                                '.Date1 = CType(ppnlBillingInfo.FindControl("dtDate" & lLineNumber.ToString & "1"), RadDatePicker).SelectedDate
                                '.Debit = CType(ppnlBillingInfo.FindControl("txtCharges" & lLineNumber.ToString), TextBox).Text
                                '.Description = CType(ppnlBillingInfo.FindControl("txtDescription" & lLineNumber.ToString), TextBox).Text
                                '.Date1 = pPatientSuperBill.DateOfService
                                .Date1 = Date.Now.Date
                                .Debit = Convert.ToDouble(CType(ppnlBillingInfo.FindControl("txtCharges" & lLineNumber.ToString), TextBox).Text) * Convert.ToDouble(CType(ppnlBillingInfo.FindControl("txtDays" & lLineNumber.ToString), TextBox).Text)
                                .Description = "Patient Visit"
                                .PatientID = pPatientSuperBill.PatientId
                                .ReferenceDisplayID = pPatientSuperBill.PatientSuperBillDisplayID
                                .ReferenceDate2 = ""
                                .ReferenceDisplayDate = CType(ppnlBillingInfo.FindControl("dtDate" & lLineNumber.ToString & "1"), RadDatePicker).SelectedDate
                                .ChequeNumber = pPatientSuperBill.ChequeNumber
                                .ChequeDate = pPatientSuperBill.ChequeDate
                            End With
                            pPatientLedger.PatientLedger = lPatientLedgerDB
                            pPatientLedger.InsertPatientLedger()
                        End If
                    End If
                End If
            Next

            'If (lCharges = 0.0 AndAlso lCPTs = "") Then
            '    Exit Function
            'End If

            'If (lCPTs <> "" AndAlso lCPTs.Substring(0, 1) = ",") Then
            '    lCPTs = lCPTs.Remove(0, 1)
            'End If

            'lCPTs = "CPT: " & lCPTs

            'lPatientLedgerDB = New PatientLedgerDB()

            'With lPatientLedgerDB

            '    .ReferenceID = pPatientSuperBill.PatientSuperBillID
            '    .ReferenceDate = pPatientSuperBill.VisitDisplayDATE
            '    .TransactionType = "V"
            '    .Reference = lCPTs
            '    '.Date1 = CType(ppnlBillingInfo.FindControl("dtDate" & lLineNumber.ToString & "1"), RadDatePicker).SelectedDate
            '    '.Debit = CType(ppnlBillingInfo.FindControl("txtCharges" & lLineNumber.ToString), TextBox).Text
            '    '.Description = CType(ppnlBillingInfo.FindControl("txtDescription" & lLineNumber.ToString), TextBox).Text
            '    .Date1 = pPatientSuperBill.DateOfService
            '    .Debit = lCharges
            '    .Description = "Patient Visit"
            '    .PatientID = pPatientSuperBill.PatientId
            '    .ReferenceDisplayID = pPatientSuperBill.PatientSuperBillDisplayID
            '    .ReferenceDate2 = ""
            '    .ReferenceDisplayDate = pPatientSuperBill.VisitDisplayDATE
            '    .ChequeNumber = pPatientSuperBill.ChequeNumber
            '    .ChequeDate = pPatientSuperBill.ChequeDate
            'End With
            'pPatientLedger.PatientLedger = lPatientLedgerDB
            'pPatientLedger.InsertPatientLedger()
        Catch ex As Exception
            Return False
        End Try

        Return True

    End Function
End Class
