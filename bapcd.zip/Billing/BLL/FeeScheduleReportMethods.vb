Imports Microsoft.VisualBasic

Public Class FeeScheduleReportMethods
    Public Shared Function GetFeeScheduleForReport(ByVal pCondition As String) As DataSet

        Dim lUser As User = CType(HttpContext.Current.Session("User"), User)
        Dim lConnection As New Connection(lUser.ConnectionString)
        Dim lDS As New DataSet
        Dim lQuery As String = String.Empty


        Try
            lQuery = "select CPTCode, [Description], CompanyName, Fee from FeeSchedulehdr FHdr inner join FeeScheduleDtl FDtl on FHdr.ID = FDtl.hdrID where 1=1 "
            lQuery &= pCondition
            lquery &= " Order By CompanyName asc"

            lDS = lConnection.ExecuteQuery(lQuery) '"select CPTCode, [Description], CompanyName, Fee from FeeSchedulehdr FHdr inner join FeeScheduleDtl FDtl on FHdr.ID = FDtl.hdrID where CompanyName like '%" & cmbPayer.Text & "%' and CPTCode between '" & txtCPTCodeFrom.Text & "' and '" & txtCPTCodeTo.Text & "'")
            lDS.Tables(0).TableName = "FeeScheduleHdr"

            Return lDS

        Catch ex As Exception
            Return Nothing
        End Try

    End Function

End Class
