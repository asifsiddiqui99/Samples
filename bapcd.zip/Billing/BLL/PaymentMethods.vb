Imports Microsoft.VisualBasic
Imports System.Collections.Generic
Imports System.Collections
Imports Telerik.WebControls

Public Class PaymentMethods

    Public Shared Function AddPayment(ByRef pPaymentHdr As PaymentHdrDB, ByRef pClaimCollection As Hashtable, ByVal pPageURL As String) As String

        Dim lUser As User = CType(HttpContext.Current.Session("User"), User)
        Dim lConnection As New Connection(lUser.ConnectionString)
        Dim lPaymentHdr As New PaymentHdr(lConnection)
        Dim lPaymentDtl As New PaymentDtl(lConnection)
        Dim lErrorLog As New ErrorLog()
        Dim lEventLog As New EventLog()
        Dim lResult As Boolean

        Try
            lConnection.BeginTrans()
            lPaymentHdr.PaymentHdr = pPaymentHdr
            lResult = lPaymentHdr.GetUniqueId() 'THIS ADDS THE UNIQUE ID TO THE PAYMENT HEADER

            If Not lResult Then
                Throw New Exception("Can't Get PaymentID")
            End If

            lPaymentHdr.InsertRecord()

            If pClaimCollection IsNot Nothing Then
                lPaymentDtl.PaymentDtl.PaymentId = lPaymentHdr.PaymentHdr.PaymentID
                'lPaymentDtl.InserRecordByClaim(pClaimCollection)
            End If

            


            'lEventLog.EventLog.ClinicID = lUser.ClinicId
            'lEventLog.EventLog.EventTypeID = EventType.CreateEmployee
            'lEventLog.EventLog.ExtraID = lPaymentHdr.PaymentHdr.PaymentID
            'lEventLog.EventLog.OCcurTime = Date.Now()
            'lEventLog.EventLog.UserID = lUser.UserId
            'lEventLog.EventLog.EventDescription = "A Payment of ID '" + lPaymentHdr.PaymentHdr.PaymentID + "' is created of the clinic having ClinicID '" + lUser.ClinicId + "' on '" + lEventLog.EventLog.OCcurTime + "' by the loginID '" + lUser.LoginId + "'"
            'lEventLog.HandleEvent()

            lConnection.CommitTrans()

        Catch ex As Exception
            lConnection.RollBackTrans()
            lErrorLog.HandleError(ex, lUser, pPageURL)
            Return ""
        End Try


        Return lPaymentHdr.PaymentHdr.PaymentDispId

    End Function

    Public Shared Function AddPayment(ByRef pPaymentHdr As PaymentHdrDB, ByVal pPageURL As String) As String

        Dim lUser As User = CType(HttpContext.Current.Session("User"), User)
        Dim lConnection As New Connection(lUser.ConnectionString)
        Dim lPaymentHdr As New PaymentHdr(lConnection)
        ' Dim lPaymentDtl As New PaymentDtl(lConnection)
        Dim lErrorLog As New ErrorLog()
        Dim lEventLog As New EventLog()
        Dim lResult As Boolean

        Try
            ' lConnection.BeginTrans()
            lPaymentHdr.PaymentHdr = pPaymentHdr
            lResult = lPaymentHdr.GetUniqueId()
            If Not lResult Then
                Throw New Exception("Can't Get PaymentID")
            End If

            lPaymentHdr.InsertRecord()
            '   lPaymentDtl.PaymentDtl.PaymentId = lPaymentHdr.PaymentHdr.PaymentID
            '   lPaymentDtl.InserRecordByClaim(pClaimCollection)


            lEventLog.EventLog.ClinicID = lUser.ClinicId
            lEventLog.EventLog.EventTypeID = EventType.CreateEmployee
            lEventLog.EventLog.ExtraID = lPaymentHdr.PaymentHdr.PaymentID
            lEventLog.EventLog.OCcurTime = Date.Now()
            lEventLog.EventLog.UserID = lUser.UserId
            lEventLog.EventLog.EventDescription = "A Payment of ID '" + lPaymentHdr.PaymentHdr.PaymentID + "' is created of the clinic having ClinicID '" + lUser.ClinicId + "' on '" + lEventLog.EventLog.OCcurTime + "' by the loginID '" + lUser.LoginId + "'"
            lEventLog.HandleEvent()

            'lConnection.CommitTrans()

        Catch ex As Exception
            lConnection.RollBackTrans()
            lErrorLog.HandleError(ex, lUser, pPageURL)
            Return ""
        End Try


        Return lPaymentHdr.PaymentHdr.PaymentDispId
    End Function

    
  
    Public Shared Function DeletePayment(ByVal pPaymentId As Int32, ByVal pPageURL As String) As Boolean

        Dim lUser As User = CType(HttpContext.Current.Session("User"), User)
        Dim lConnection As New Connection(lUser.ConnectionString)
        Dim lPaymentHdr As New PaymentHdr(lConnection)
        Dim lPaymentDtl As New PaymentDtl(lConnection)
        Dim lErrorLog As New ErrorLog()
        Dim lEventLog As New EventLog()

        Try
            lConnection.BeginTrans()
            lPaymentHdr.PaymentHdr.PaymentID = pPaymentId
            lPaymentDtl.PaymentDtl.PaymentId = pPaymentId


            lPaymentHdr.LogicalDelete()
            lPaymentDtl.DeleteRecordByID()


            lEventLog.EventLog.ClinicID = lUser.ClinicId
            lEventLog.EventLog.EventTypeID = EventType.CreateEmployee
            lEventLog.EventLog.ExtraID = lPaymentHdr.PaymentHdr.PaymentID
            lEventLog.EventLog.OCcurTime = Date.Now()
            lEventLog.EventLog.UserID = lUser.UserId
            lEventLog.EventLog.EventDescription = "A Payment of ID '" + lPaymentHdr.PaymentHdr.PaymentID + "' is created of the clinic having ClinicID '" + lUser.ClinicId + "' on '" + lEventLog.EventLog.OCcurTime + "' by the loginID '" + lUser.LoginId + "'"
            lEventLog.HandleEvent()

            lConnection.CommitTrans()

        Catch ex As Exception
            lConnection.RollBackTrans()
            lErrorLog.HandleError(ex, lUser, pPageURL)
            Return False
        End Try


        Return True

    End Function

    Public Shared Function GetPaymentHdr(ByRef pPaymentHdrDb As PaymentHdrDB) As Boolean
        Dim lUser As User = CType(HttpContext.Current.Session("User"), User)

        Dim lPaymentHdr As New PaymentHdr(lUser.ConnectionString)
        lPaymentHdr.PaymentHdr = pPaymentHdrDb

        Try

            lPaymentHdr.GetRecordByIDExtended()
            Return True

        Catch ex As Exception
            Throw New Exception("Unable to get Payment Header ")
            Return False
        End Try

        Return True

    End Function
    Public Shared Function EditPayment(ByRef pPaymentHdr As PaymentHdrDB, ByRef pClaimCollection As Hashtable, ByVal pPageURL As String) As String

        Dim lUser As User = CType(HttpContext.Current.Session("User"), User)
        Dim lConnection As New Connection(lUser.ConnectionString)
        Dim lPaymentHdr As New PaymentHdr(lConnection)
        Dim lPaymentDtl As New PaymentDtl(lConnection)

        Dim lErrorLog As New ErrorLog()
        Dim lEventLog As New EventLog()


        lPaymentHdr.PaymentHdr = pPaymentHdr
        lPaymentDtl.PaymentDtl.PaymentId = lPaymentHdr.PaymentHdr.PaymentID

        'Dim lSecondDeleteCondition As String = "AND Paymentid=" & lPaymentHdr.PaymentHdr.PaymentID & "" _
        '                                     & " AND Amountpaid=0"

        'HAVE COMMENTED THIS ABOVE LINE BECAUSE OF THE ADDITION OF DEDUCTABLE, THIS LINE WAS DELETING THE RECORDS WHERE THERE WAS NO AMOUNT PAID

        Try
            lConnection.BeginTrans()


            lPaymentHdr.UpdateRecord()
            lPaymentDtl.DeleteRecordByID()
            'lPaymentDtl.InserRecordByClaimEdit(pClaimCollection)
            'lPaymentDtl.DeleteRecord(lSecondDeleteCondition)


            lEventLog.EventLog.ClinicID = lUser.ClinicId
            lEventLog.EventLog.EventTypeID = EventType.CreateEmployee
            lEventLog.EventLog.ExtraID = lPaymentHdr.PaymentHdr.PaymentID
            lEventLog.EventLog.OCcurTime = Date.Now()
            lEventLog.EventLog.UserID = lUser.UserId
            lEventLog.EventLog.EventDescription = "A Payment of ID '" + lPaymentHdr.PaymentHdr.PaymentID + "' is updated of the clinic having ClinicID '" + lUser.ClinicId + "' on '" + lEventLog.EventLog.OCcurTime + "' by the loginID '" + lUser.LoginId + "'"
            lEventLog.HandleEvent()

            lConnection.CommitTrans()

        Catch ex As Exception
            lConnection.RollBackTrans()
            lErrorLog.HandleError(ex, lUser, pPageURL)
            Return ""
        End Try

        Return lPaymentHdr.PaymentHdr.PaymentDispId
    End Function
    Public Shared Function GetPayerType() As DataSet
        Dim lUser As User = CType(HttpContext.Current.Session("User"), User)

        Dim lPaymentHdr As New PaymentHdr(lUser.ConnectionString)

        Try


            Return PaymentHdr.GetPayerType(lUser.ConnectionString)

        Catch ex As Exception
            Throw New Exception("Unable to get Payment Header ")
            Return Nothing
        End Try


    End Function
    Public Shared Function GetPayerName(ByVal pType As String) As DataSet
        Dim lUser As User = CType(HttpContext.Current.Session("User"), User)

        Dim lPaymentHdr As New PaymentHdr(lUser.ConnectionString)

        Try


            Return PaymentHdr.GetPayerNameForInsurance(lUser.ConnectionString, pType)

        Catch ex As Exception
            Throw New Exception("Unable to get Payment Header ")
            Return Nothing
        End Try


    End Function
    Public Shared Function GetPaymentMode() As DataSet
        Dim lUser As User = CType(HttpContext.Current.Session("User"), User)

        Dim lPaymentHdr As New PaymentHdr(lUser.ConnectionString)

        Try


            Return PaymentHdr.GetPaymentMode(lUser.ConnectionString)

        Catch ex As Exception
            Throw New Exception("Unable to get Payment Header ")
            Return Nothing
        End Try


    End Function
    Public Shared Function GetTypeCode(ByVal pUser As User) As DataSet
        Dim lpaymenthdrDAL As New PaymentHdr(pUser.ConnectionString)
        Dim lDs As New DataSet
        Try
            lDs = lpaymenthdrDAL.GetTypeCode()
            Return lDs
        Catch ex As Exception
            Return Nothing
        End Try

        Return lDs

    End Function
    Public Shared Function GetAdjReasonCode(ByVal pUser As User) As DataSet
        Dim lpaymenthdrDAL As New PaymentHdr(pUser.ConnectionString)
        Dim lDs As New DataSet
        Try
            lDs = lpaymenthdrDAL.GetAdjReasonCode()
            Return lDs
        Catch ex As Exception
            Return Nothing
        End Try

        Return lDs

    End Function
    Public Shared Function GetListRecord(ByVal pUser As User) As DataSet
        Dim lpaymenthdrDAL As New PaymentHdr(pUser.ConnectionString)
        Dim lDs As New DataSet
        Try
            lDs = lpaymenthdrDAL.GetListRecord()
            Return lDs
        Catch ex As Exception
            Return Nothing
        End Try

        Return lDs

    End Function
    Public Shared Function InsertListRecord(ByVal pUser As User, ByRef pVisitID As Integer, ByVal pCPTCode As String, ByVal ApdjustmentDescription As String, ByVal pReasonCode As String, ByVal pAdjustmentTypeID As Integer, ByVal pAmount As Integer, ByVal pUserID As Integer, ByVal pPaymentDtlID As Integer, ByVal pPaymentID As Integer)
        Dim lpaymenthdrDAL As New PaymentHdr(pUser.ConnectionString)
        Dim lDs As New DataSet
        Try
            lDs = lpaymenthdrDAL.InsertListRecord(pVisitID, pCPTCode, ApdjustmentDescription, pReasonCode, pAdjustmentTypeID, pAmount, pUserID, pPaymentDtlID, pPaymentID)
            Return lDs
        Catch ex As Exception
            Return Nothing
        End Try

        Return lDs

    End Function
    Public Shared Function GetPaymentSearchNew(ByVal pCondition As String) As DataSet
        Dim lUser As User = CType(HttpContext.Current.Session("User"), User)



        Try
            Dim lPaymentHdr As New PaymentHdr(lUser.ConnectionString)
            Dim lds As DataSet

            lds = lPaymentHdr.GetPaymentList(lUser.ConnectionString, pCondition)

            Return lds


        Catch ex As Exception
            Return Nothing
        End Try

    End Function


    Public Shared Function DeletePaymentNew(ByVal pPaymentID As String) As Boolean
        Dim lUser As User = CType(HttpContext.Current.Session("User"), User)



        Try
            Dim lPaymentHdr As New PaymentHdr(lUser.ConnectionString)

            lPaymentHdr.DeletePaymentNew(pPaymentID)

            Return True


        Catch ex As Exception
            Return Nothing
        End Try

    End Function


    Public Shared Function GetForDetailApplyPaymentGrid(ByVal pPatientSuperBillID As String) As PaymentCPTDetailCollection
        Dim lUser As User = CType(HttpContext.Current.Session("User"), User)
        Dim lPaymentCPTDetailDB As PaymentCPTDetailDB = Nothing
        Dim lPaymentCPTDetailCollection As New PaymentCPTDetailCollection
        Dim li As Integer = 0
        Try
            Dim lPaymentHdr As New PaymentHdr(lUser.ConnectionString)
            Dim lds As DataSet

            lds = lPaymentHdr.GetForDetailApplyPaymentGrid(lUser.ConnectionString, pPatientSuperBillID)

            If lds.Tables(0).Rows.Count > 0 Then


                For li = 0 To lds.Tables(0).Rows.Count - 1
                    lPaymentCPTDetailDB = New PaymentCPTDetailDB
                    With lds.Tables(0).Rows(li)
                        lPaymentCPTDetailDB.CPTCode = .Item("Code")
                        lPaymentCPTDetailDB.Charges = .Item("Charges")
                        lPaymentCPTDetailDB.AllowedAmount = .Item("AllowedAmount")
                        lPaymentCPTDetailDB.Deductable = .Item("Deductable")
                        lPaymentCPTDetailDB.Copay = .Item("Copay")
                        lPaymentCPTDetailDB.PreviousInsurancePaymnent = .Item("PrvInsurancePayment")
                        lPaymentCPTDetailDB.PreviousPatientPaymnent = .Item("PrvPatientPayment")
                        lPaymentCPTDetailDB.Adjustment = .Item("Adjustment")
                        lPaymentCPTDetailDB.DateOfService = .Item("DateOfServiceFrom")
                        lPaymentCPTDetailDB.CPTBalance = .Item("CPTBalance")
                        lPaymentCPTDetailDB.CPTId = .Item("LineID")

                        lPaymentCPTDetailDB.PatientSuperBillID = pPatientSuperBillID

                    End With

                    lPaymentCPTDetailCollection.Add(lPaymentCPTDetailDB)






                Next

                Return lPaymentCPTDetailCollection




                'If (HttpContext.Current.Session("PaymentDetailCollectionForHeader") IsNot Nothing) Then
                '    lpaymentDtlCollection = HttpContext.Current.Session("PaymentDetailCollectionForHeader")
                '    lpaymentDtlCollection.Add(lPaymentdtl.PatientSuperBillID, lPaymentdtl)
                'End If
            End If

            'Return lPaymentdtl




        Catch ex As Exception
            Return Nothing
        End Try
    End Function


    Public Shared Function GetForMasterApplyPaymentGrid(ByVal pPatientSuperBillID As String) As PaymentDtlDB
        Dim lUser As User = CType(HttpContext.Current.Session("User"), User)

        Dim lpaymentDtlCollection As Hashtable
        Dim lPaymentdtl As PaymentDtlDB = Nothing
        Dim li As Integer = 0

        Try
            Dim lPaymentHdr As New PaymentHdr(lUser.ConnectionString)
            Dim lds As DataSet
            lds = lPaymentHdr.GetPaymentForMasterGrid(lUser.ConnectionString, pPatientSuperBillID)
            If lds.Tables(0).Rows.Count > 0 Then



                lPaymentdtl = New PaymentDtlDB

                'For li = 0 To lds.Tables(0).Rows.Count - 1
                lPaymentdtl.PatientName = lds.Tables(0).Rows(li).Item("PatientName").ToString
                lPaymentdtl.Adjustment = lds.Tables(0).Rows(li).Item("Adjustment").ToString
                lPaymentdtl.Balance = lds.Tables(0).Rows(li).Item("Balance").ToString
                lPaymentdtl.TotalCharges = lds.Tables(0).Rows(li).Item("TotalCharges").ToString
                lPaymentdtl.PatientSuperBillID = lds.Tables(0).Rows(li).Item("PatientSuperBillID").ToString
                lPaymentdtl.DOS = lds.Tables(0).Rows(li).Item("DOS").ToString
                lPaymentdtl.PrvInsurancePayment = lds.Tables(0).Rows(li).Item("PrvInsurancePayment").ToString
                lPaymentdtl.PrvPatientPayment = lds.Tables(0).Rows(li).Item("PrvPatientPayment").ToString
                lPaymentdtl.PatientID = lds.Tables(0).Rows(li).Item("PatientID").ToString
                lPaymentdtl.VisitDisplayID = lds.Tables(0).Rows(li).Item("VisitDisplayID").ToString
                lPaymentdtl.VisitDisplayDate = lds.Tables(0).Rows(li).Item("VisitDisplayDate").ToString

                'Next

                'If (HttpContext.Current.Session("PaymentDetailCollectionForHeader") IsNot Nothing) Then
                '    lpaymentDtlCollection = HttpContext.Current.Session("PaymentDetailCollectionForHeader")
                '    lpaymentDtlCollection.Add(lPaymentdtl.PatientSuperBillID, lPaymentdtl)
                'End If
            End If

            Return lPaymentdtl





        Catch ex As Exception
            Return Nothing
        End Try

    End Function

    Public Shared Function AddPaymentDtl(ByVal pPaymentDtl As PaymentDtlDB) As Integer
        Dim lUser As User = CType(HttpContext.Current.Session("User"), User)
        Try
            Dim lPaymentDTl As New PaymentDtl(lUser.ConnectionString)
            Dim lPaymentDtlID As Integer


            'lPaymentDtlID = lPaymentDTl.InsertRecordPaymentDtlNew(pPaymentDtl)

            Return lPaymentDtlID

        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Public Shared Function AddPaymentDtlCPT(ByVal pClaimDtl As List(Of ClaimDtlDB), ByVal pPaymentDtl As PaymentDtlDB) As Boolean
        Dim lUser As User = CType(HttpContext.Current.Session("User"), User)
        Try
            Dim lPaymentDTl As New PaymentDtl(lUser.ConnectionString)



            'lPaymentDTl.InsertRecordPaymentCPTDtlNew(pClaimDtl, pPaymentDtl)



        Catch ex As Exception
            Return Nothing
        End Try
    End Function


    Public Shared Function SearchPayment(ByVal lPaymentId As String, ByVal lDescription As String, ByVal lPayerType As String, ByVal lPaymentFromDate As String, ByVal lPaymentToDate As String, ByVal lPaymentMode As String, ByVal lPaymentStatus As String, ByVal lUser As User, ByVal pPayerName As String) As DataSet
        Dim lDs As New DataSet
        Dim lConnection As New Connection(lUser.ConnectionString)
        Dim lWhereCondition As String = ""
        'Dim lQuery As String = "select *," _
        '                       & " Case H.PayerType when 'I' then 'Insurance' else 'Patient' end as PayerTypeFull," _
        '                       & " 'PT-' + cast(Year(PaymentDate) as varchar) + '-' + cast(Month(PaymentDate) as varchar) + '-' + REPLICATE('0', (5 - LEN(CAST(PaymentDIspid as VARCHAR)))) + CAST(PaymentDIspid as  VARCHAR) as DisplayID," _
        '                       & " CASE (H.Amount-X.AppliedAmount) when 0 then 'Close' else 'Open' END as PaymentStatus " _
        '                       & " from PaymentHdr H ," _
        '                       & " (select H.PaymentID as ID,isNull(sum(D.amountpaid),0) as AppliedAmount from PaymentDTl D,PaymentHdr H where  H.PaymentId*=D.PaymentId" _
        '                       & " group by H.PaymentId)X" _
        '                       & " where H.PaymentId=X.ID" _
        '                       & " AND H.IsDeleted!='Y'" _
        '                       & " AND H.UserID= " & lUser.UserId & " "


        'Dim lQuery As String = "select *," _
        '                       & " Case H.PayerType when 'I' then 'Insurance' else 'Patient' end as PayerTypeFull, 'PT-' + cast(Year(PaymentDate) as varchar) + '-' + cast(Month(PaymentDate) as varchar) + '-' + REPLICATE('0', (5 - LEN(CAST(DisplayID as VARCHAR)))) + CAST(DisplayID as  VARCHAR) as DisplayID1," _
        '                       & "CASE (X.TotalCharges-X.AppliedAmount) when 0 then 'Fully Applied' else 'Pending' END as PaymentStatus  from PaymentHdr H , (select H.PaymentID as ID,isNull(sum(D.TotalCharges),0) as TotalCharges,isNull(sum(D.TotalAmount),0) as AppliedAmount, H.Notes PaymentHdr H, PaymentDtl D where  H.PaymentId*=D.PaymentId" _
        '                       & " group by H.PaymentId)X where H.PaymentId=X.ID AND H.UserID= " & lUser.UserId & " "

        Dim lQuery As String = "SELECT     H.PaymentID, H.PaymentDate, H.DisplayID, H.EntryDate, H.PayerType, H.PayerID, H.PayerName, H.PaymentMode, H.CheckNumber, H.CheckDate,  H.Amount, H.Description, H.UserID, H.Notes," _
& "ISNULL(X.AppliedAmount, 0) AS AppliedAmount, CASE H.PayerType WHEN 'I' THEN 'Insurance' ELSE 'Patient' END AS PayerTypeFull, 'PT-' + CAST(YEAR(H.PaymentDate) AS varchar)  + " _
& "'-' + CAST(MONTH(H.PaymentDate) AS varchar) + '-' + REPLICATE('0', 5 - LEN(CAST(H.DisplayID AS VARCHAR))) + CAST(H.DisplayID AS VARCHAR)  AS DisplayID1" _
& " , CASE WHEN (H.Amount - IsNUll(X.AppliedAmount, 0)) <= 0 THEN 'Fully Applied' ELSE 'Pending' END AS PaymentStatus,RemittanceId=isNull(RH.RemittanceId,0) FROM " _
& "PaymentHdr AS H LEFT OUTER JOIN  " _
& " (SELECT     SUM(DtlAmount) + SUM(CPTAmount) AS AppliedAmount, PaymentID " _
& "        FROM" _
& "  (SELECT     Dtl.PaymentID, Dtl.Amount AS DtlAmount, SUM(ISNULL(CPT.Amount, 0)) AS CPTAmount  " _
& "   FROM       PaymentDtl AS Dtl LEFT OUTER JOIN " _
& "   PaymentCPTDetail AS CPT ON Dtl.PaymentDtlID = CPT.PaymentDtlID  " _
& "   GROUP BY Dtl.PaymentID, Dtl.PaymentDtlID, Dtl.Amount) AS Y" _
& "   GROUP BY PaymentID) AS X " _
& "   ON H.PaymentID = X.PaymentID " _
& "   LEFT OUTER JOIN RemittanceHdr RH ON H.PaymentID=RH.PaymentID" _
& "  WHERE 1=1"

        'Dim lQuery As String = "SELECT     H.PaymentID, H.PaymentDate, H.DisplayID, H.EntryDate, H.PayerType, H.PayerID, H.PayerName, H.PaymentMode, H.CheckNumber, H.CheckDate,  " _
        '                     & "H.Amount, H.Description, H.UserID, H.Notes, ISNULL(X.AppliedAmount, 0) AS AppliedAmount, " _
        '                     & "CASE H.PayerType WHEN 'I' THEN 'Insurance' ELSE 'Patient' END AS PayerTypeFull, 'PT-' + CAST(YEAR(H.PaymentDate) AS varchar)  " _
        '                     & "+ '-' + CAST(MONTH(H.PaymentDate) AS varchar) + '-' + REPLICATE('0', 5 - LEN(CAST(H.DisplayID AS VARCHAR))) + CAST(H.DisplayID AS VARCHAR)  " _
        '                     & "AS DisplayID1, CASE WHEN (H.Amount - IsNUll(X.AppliedAmount, 0)) <= 0 THEN 'Fully Applied' ELSE 'Pending' END AS PaymentStatus " _
        '                     & "FROM         PaymentHdr AS H LEFT OUTER JOIN " _
        '                     & "                          (SELECT     SUM(DtlAmount) + SUM(CPTAmount) AS AppliedAmount, PaymentID " _
        '                     & "                            FROM          (SELECT     Dtl.PaymentID, Dtl.Amount AS DtlAmount, SUM(ISNULL(CPT.Amount, 0)) AS CPTAmount " _
        '                     & "                                           FROM       PaymentDtl AS Dtl LEFT OUTER JOIN " _
        '                     & "                                                      PaymentCPTDetail AS CPT ON Dtl.PaymentDtlID = CPT.PaymentDtlID " _
        '                     & "                                           GROUP BY Dtl.PaymentID, Dtl.PaymentDtlID, Dtl.Amount) AS Y " _
        '                     & "                            GROUP BY PaymentID) AS X ON H.PaymentID = X.PaymentID " _
        '                     & "WHERE 1=1 "
        'WHERE H.UserID=" & lUser.UserId




        'Dim lQuery As String = "select *, Case H.PayerType when 'I' then 'Insurance' else 'Patient' end as PayerTypeFull, 'PT-' + " _
        '                    & "cast(Year(PaymentDate) as varchar) + '-' + cast(Month(PaymentDate) as varchar) + '-' + REPLICATE('0', (5 - LEN(CAST(DisplayID as VARCHAR)))) " _
        '                    & "+ CAST(DisplayID as  VARCHAR) as DisplayID1," _
        '                    & "CASE  when (H.Amount-X.AppliedAmount) <= 0 then 'Fully Applied' else 'Pending' END as PaymentStatus  " _
        '                    & "from PaymentHdr H , " _
        '                    & "(select H.PaymentID as ID,isNull(sum(D.TotalCharges),0) as TotalCharges,isNull(sum(D.TotalAmount),0) as AppliedAmount from  PaymentHdr H left outer join PaymentDtl D " _
        '                    & "on H.PaymentId=D.PaymentId group by H.PaymentId)X " _
        '                    & "where H.PaymentId=X.ID AND H.UserID=" & lUser.UserId



        '''''''''''''''''''''''''''' PaymentId Check ''''''''''''''''''''''''
        If (lPaymentId <> "") Then
            lWhereCondition = lWhereCondition & " AND 'PT-' + cast(Year(H.PaymentDate) as varchar) + '-' + cast(Month(H.PaymentDate) as varchar) + '-' + REPLICATE('0', (5 - LEN(CAST(H.DisplayID as VARCHAR)))) + CAST(H.DisplayID as  VARCHAR) Like '%" & lPaymentId & "'"
        End If

        ''''''''''''''''''''''''''' Open/Close Check'''''''''''''''''

        If (lPaymentStatus <> "All") Then
            If (lPaymentStatus = "Pending") Then
                lWhereCondition = lWhereCondition & " AND (H.Amount-IsNull(X.AppliedAmount,0)) > 0"
            Else
                lWhereCondition = lWhereCondition & " AND (H.Amount-IsNull(X.AppliedAmount,0)) <= 0"
            End If
        End If


        ''''''''''''''''''''''''''' Payment Mode Check ''''''''''''''''''
        If (lPaymentMode <> "All") Then
            Select Case lPaymentMode
                Case "Check"
                    lWhereCondition = lWhereCondition & " AND H.PaymentMode='Check'"
                Case "Cash"
                    lWhereCondition = lWhereCondition & " AND H.PaymentMode='Cash'"
                Case "Credit Card"
                    lWhereCondition = lWhereCondition & " AND H.PaymentMode='Credit Card'"
                Case "EFT"
                    lWhereCondition = lWhereCondition & " AND H.PaymentMode='EFT'"
            End Select

            'If (lPaymentMode = "Check") Then
            '    lWhereCondition = lWhereCondition & " AND H.PaymentMode='Check'"
            'Else
            '    lWhereCondition = lWhereCondition & " AND H.PaymentMode='Cash'"
            'End If
        End If

        ''''''''''''''''''''''''''' Payer Type check ''''''''''''''''''''
        If (lPayerType <> "All") Then
            If (lPayerType = "I") Then
                lWhereCondition = lWhereCondition & " AND H.PayerType='I'"
            Else
                lWhereCondition = lWhereCondition & " AND H.PayerType='P'"
            End If
        End If

        ''''''''''''''''''''' Description Check'''''''''''''
        If (lDescription <> "") Then
            lWhereCondition = lWhereCondition & " AND H.Description = " & lDescription & ""
        End If

        '''''''''''''''''''''' Payment Date Check '''''''''''''''''''''
        If (lPaymentFromDate <> "" AndAlso lPaymentToDate <> "") Then
            lWhereCondition = lWhereCondition & " AND H.PaymentDate between cast ('" & lPaymentFromDate & "' as datetime) and cast('" & lPaymentToDate & "' as datetime)"
        End If


        ''''''''''''''''''''''''''Check the PayerName''''''''''''''''''''
        If (Not pPayerName.Equals("") AndAlso lPayerType.ToUpper <> "All") Then
            If (lPayerType.ToUpper = "P") Then
                Dim lPayerNameSpace As String = pPayerName.Replace(" ", "")
                If (lPayerNameSpace.Contains(",")) Then
                    lPayerNameSpace = lPayerNameSpace.Insert(lPayerNameSpace.IndexOf(",") + 1, " ")
                    lWhereCondition = lWhereCondition & " AND ( H.PayerName like '" & lPayerNameSpace & "%' " & " or H.PayerName like '" & pPayerName.Replace(" ", "") & "%' )"
                Else
                    lWhereCondition = lWhereCondition & " AND ( H.PayerName like '" & pPayerName & "%' )"
                End If
            Else
                lWhereCondition = lWhereCondition & " AND (H.PayerName like '" & pPayerName & "' )"
            End If

        End If



        lQuery = lQuery & "" & lWhereCondition & " Order By H.PaymentDate Desc, DisplayID Desc "



        Try
            lDs = lConnection.ExecuteQuery(lQuery)
        Catch ex As Exception
            lDs = Nothing
        End Try


        Return lDs
    End Function

    Public Shared Function SearchPayment(ByVal lPaymentId As String, ByVal lDescription As String, ByVal lPayerType As String, ByVal lPaymentFromDate As String, ByVal lPaymentToDate As String, ByVal lPaymentMode As String, ByVal lPaymentStatus As String, ByVal lUser As User, ByVal pPayerName As String, ByVal pCheckFromDate As String, ByVal pCheckToDate As String, ByVal pCheckNumber As String) As DataSet
        Dim lDs As New DataSet
        Dim lConnection As New Connection(lUser.ConnectionString)
        Dim lWhereCondition As String = ""
        'Dim lQuery As String = "select *," _
        '                       & " Case H.PayerType when 'I' then 'Insurance' else 'Patient' end as PayerTypeFull," _
        '                       & " 'PT-' + cast(Year(PaymentDate) as varchar) + '-' + cast(Month(PaymentDate) as varchar) + '-' + REPLICATE('0', (5 - LEN(CAST(PaymentDIspid as VARCHAR)))) + CAST(PaymentDIspid as  VARCHAR) as DisplayID," _
        '                       & " CASE (H.Amount-X.AppliedAmount) when 0 then 'Close' else 'Open' END as PaymentStatus " _
        '                       & " from PaymentHdr H ," _
        '                       & " (select H.PaymentID as ID,isNull(sum(D.amountpaid),0) as AppliedAmount from PaymentDTl D,PaymentHdr H where  H.PaymentId*=D.PaymentId" _
        '                       & " group by H.PaymentId)X" _
        '                       & " where H.PaymentId=X.ID" _
        '                       & " AND H.IsDeleted!='Y'" _
        '                       & " AND H.UserID= " & lUser.UserId & " "


        'Dim lQuery As String = "select *," _
        '                       & " Case H.PayerType when 'I' then 'Insurance' else 'Patient' end as PayerTypeFull, 'PT-' + cast(Year(PaymentDate) as varchar) + '-' + cast(Month(PaymentDate) as varchar) + '-' + REPLICATE('0', (5 - LEN(CAST(DisplayID as VARCHAR)))) + CAST(DisplayID as  VARCHAR) as DisplayID1," _
        '                       & "CASE (X.TotalCharges-X.AppliedAmount) when 0 then 'Fully Applied' else 'Pending' END as PaymentStatus  from PaymentHdr H , (select H.PaymentID as ID,isNull(sum(D.TotalCharges),0) as TotalCharges,isNull(sum(D.TotalAmount),0) as AppliedAmount, H.Notes PaymentHdr H, PaymentDtl D where  H.PaymentId*=D.PaymentId" _
        '                       & " group by H.PaymentId)X where H.PaymentId=X.ID AND H.UserID= " & lUser.UserId & " "

        Dim lQuery As String = "SELECT     H.PaymentID, H.PaymentDate, H.DisplayID, H.EntryDate, H.PayerType, H.PayerID, H.PayerName, H.PaymentMode, H.CheckNumber, H.CheckDate,  H.Amount, H.Description, H.UserID, H.Notes," _
& "ISNULL(X.AppliedAmount, 0) AS AppliedAmount, CASE H.PayerType WHEN 'I' THEN 'Insurance' ELSE 'Patient' END AS PayerTypeFull, 'PT-' + CAST(YEAR(H.PaymentDate) AS varchar)  + " _
& "'-' + CAST(MONTH(H.PaymentDate) AS varchar) + '-' + REPLICATE('0', 5 - LEN(CAST(H.DisplayID AS VARCHAR))) + CAST(H.DisplayID AS VARCHAR)  AS DisplayID1" _
& " , CASE WHEN (H.Amount - IsNUll(X.AppliedAmount, 0)) <= 0 THEN 'Fully Applied' ELSE 'Pending' END AS PaymentStatus,RemittanceId=isNull(RH.RemittanceId,0) FROM " _
& "PaymentHdr AS H LEFT OUTER JOIN  " _
& " (SELECT     SUM(DtlAmount) + SUM(CPTAmount) AS AppliedAmount, PaymentID " _
& "        FROM" _
& "  (SELECT     Dtl.PaymentID, Dtl.Amount AS DtlAmount, SUM(ISNULL(CPT.Amount, 0)) AS CPTAmount  " _
& "   FROM       PaymentDtl AS Dtl LEFT OUTER JOIN " _
& "   PaymentCPTDetail AS CPT ON Dtl.PaymentDtlID = CPT.PaymentDtlID  " _
& "   GROUP BY Dtl.PaymentID, Dtl.PaymentDtlID, Dtl.Amount) AS Y" _
& "   GROUP BY PaymentID) AS X " _
& "   ON H.PaymentID = X.PaymentID " _
& "   LEFT OUTER JOIN RemittanceHdr RH ON H.PaymentID=RH.PaymentID" _
& "  WHERE 1=1"

        'Dim lQuery As String = "SELECT     H.PaymentID, H.PaymentDate, H.DisplayID, H.EntryDate, H.PayerType, H.PayerID, H.PayerName, H.PaymentMode, H.CheckNumber, case H.CheckDate when '1900/01/01' then '' else cast(H.checkdate as varchar) end,  " _
        '                     & "H.Amount, H.Description, H.UserID, H.Notes, ISNULL(X.AppliedAmount, 0) AS AppliedAmount, " _
        '                     & "CASE H.PayerType WHEN 'I' THEN 'Insurance' ELSE 'Patient' END AS PayerTypeFull, 'PT-' + CAST(YEAR(H.PaymentDate) AS varchar)  " _
        '                     & "+ '-' + CAST(MONTH(H.PaymentDate) AS varchar) + '-' + REPLICATE('0', 5 - LEN(CAST(H.DisplayID AS VARCHAR))) + CAST(H.DisplayID AS VARCHAR)  " _
        '                     & "AS DisplayID1, CASE WHEN (H.Amount - IsNUll(X.AppliedAmount, 0)) <= 0 THEN 'Fully Applied' ELSE 'Pending' END AS PaymentStatus " _
        '                     & "FROM         PaymentHdr AS H LEFT OUTER JOIN " _
        '                     & "                          (SELECT     SUM(DtlAmount) + SUM(CPTAmount) AS AppliedAmount, PaymentID " _
        '                     & "                            FROM          (SELECT     Dtl.PaymentID, Dtl.Amount AS DtlAmount, SUM(ISNULL(CPT.Amount, 0)) AS CPTAmount " _
        '                     & "                                           FROM       PaymentDtl AS Dtl LEFT OUTER JOIN " _
        '                     & "                                                      PaymentCPTDetail AS CPT ON Dtl.PaymentDtlID = CPT.PaymentDtlID " _
        '                     & "                                           GROUP BY Dtl.PaymentID, Dtl.PaymentDtlID, Dtl.Amount) AS Y " _
        '                     & "                            GROUP BY PaymentID) AS X ON H.PaymentID = X.PaymentID " _
        '                     & "WHERE 1=1 "
        'WHERE H.UserID=" & lUser.UserId




        'Dim lQuery As String = "select *, Case H.PayerType when 'I' then 'Insurance' else 'Patient' end as PayerTypeFull, 'PT-' + " _
        '                    & "cast(Year(PaymentDate) as varchar) + '-' + cast(Month(PaymentDate) as varchar) + '-' + REPLICATE('0', (5 - LEN(CAST(DisplayID as VARCHAR)))) " _
        '                    & "+ CAST(DisplayID as  VARCHAR) as DisplayID1," _
        '                    & "CASE  when (H.Amount-X.AppliedAmount) <= 0 then 'Fully Applied' else 'Pending' END as PaymentStatus  " _
        '                    & "from PaymentHdr H , " _
        '                    & "(select H.PaymentID as ID,isNull(sum(D.TotalCharges),0) as TotalCharges,isNull(sum(D.TotalAmount),0) as AppliedAmount from  PaymentHdr H left outer join PaymentDtl D " _
        '                    & "on H.PaymentId=D.PaymentId group by H.PaymentId)X " _
        '                    & "where H.PaymentId=X.ID AND H.UserID=" & lUser.UserId



        '''''''''''''''''''''''''''' PaymentId Check ''''''''''''''''''''''''
        If (lPaymentId <> "") Then
            lWhereCondition = lWhereCondition & " AND 'PT-' + cast(Year(H.PaymentDate) as varchar) + '-' + cast(Month(H.PaymentDate) as varchar) + '-' + REPLICATE('0', (5 - LEN(CAST(H.DisplayID as VARCHAR)))) + CAST(H.DisplayID as  VARCHAR) Like '%" & lPaymentId & "'"
        End If

        ''''''''''''''''''''''''''' Open/Close Check'''''''''''''''''

        If (lPaymentStatus <> "All") Then
            If (lPaymentStatus = "Pending") Then
                lWhereCondition = lWhereCondition & " AND (H.Amount-IsNull(X.AppliedAmount,0)) > 0"
            Else
                lWhereCondition = lWhereCondition & " AND (H.Amount-IsNull(X.AppliedAmount,0)) <= 0"
            End If
        End If


        ''''''''''''''''''''''''''' Payment Mode Check ''''''''''''''''''
        If (lPaymentMode <> "All") Then
            Select Case lPaymentMode
                Case "Check"
                    lWhereCondition = lWhereCondition & " AND H.PaymentMode='Check'"
                Case "Cash"
                    lWhereCondition = lWhereCondition & " AND H.PaymentMode='Cash'"
                Case "Credit Card"
                    lWhereCondition = lWhereCondition & " AND H.PaymentMode='Credit Card'"
                Case "EFT"
                    lWhereCondition = lWhereCondition & " AND H.PaymentMode='EFT'"
            End Select

            'If (lPaymentMode = "Check") Then
            '    lWhereCondition = lWhereCondition & " AND H.PaymentMode='Check'"
            'Else
            '    lWhereCondition = lWhereCondition & " AND H.PaymentMode='Cash'"
            'End If
        End If

        ''''''''''''''''''''''''''' Payer Type check ''''''''''''''''''''
        If (lPayerType <> "All") Then
            If (lPayerType = "I") Then
                lWhereCondition = lWhereCondition & " AND H.PayerType='I'"
            Else
                lWhereCondition = lWhereCondition & " AND H.PayerType='P'"
            End If
        End If

        ''''''''''''''''''''' Description Check'''''''''''''
        If (lDescription <> "") Then
            lWhereCondition = lWhereCondition & " AND H.Description = " & lDescription & ""
        End If

        '''''''''''''''''''''' Payment Date Check '''''''''''''''''''''
        If (lPaymentFromDate <> "" AndAlso lPaymentToDate <> "") Then
            lWhereCondition = lWhereCondition & " AND H.PaymentDate between cast ('" & lPaymentFromDate & "' as datetime) and cast('" & lPaymentToDate & "' as datetime)"
        End If


        ''''''''''''''''''''''''''Check the PayerName''''''''''''''''''''
        If (Not pPayerName.Equals("") AndAlso lPayerType.ToUpper <> "All") Then
            If (lPayerType.ToUpper = "P") Then
                Dim lPayerNameSpace As String = pPayerName.Replace(" ", "")
                If (lPayerNameSpace.Contains(",")) Then
                    lPayerNameSpace = lPayerNameSpace.Insert(lPayerNameSpace.IndexOf(",") + 1, " ")
                    lWhereCondition = lWhereCondition & " AND ( H.PayerName like '" & lPayerNameSpace & "%' " & " or H.PayerName like '" & pPayerName.Replace(" ", "") & "%' )"
                Else
                    lWhereCondition = lWhereCondition & " AND ( H.PayerName like '" & pPayerName & "%' )"
                End If
            Else
                lWhereCondition = lWhereCondition & " AND (H.PayerName like '" & pPayerName & "' )"
            End If

        End If

        '''''''''''''''''''''''''''Check for CheckDate & CheckNumber ''''''''''''''''''''''''''

        'If pCheckDate <> "" Then
        '    lWhereCondition = lWhereCondition & " AND  H.CheckDate = cast ('" & pCheckDate & "' as datetime)"
        'End If

        If (pCheckFromDate <> "" AndAlso pCheckToDate <> "") Then
            lWhereCondition = lWhereCondition & " AND H.CheckDate between cast ('" & pCheckFromDate & "' as datetime) and cast('" & pCheckToDate & "' as datetime)"
        End If



        If pCheckNumber <> "" Then
            lWhereCondition = lWhereCondition & " AND  H.CheckNumber Like '" & pCheckNumber & "%'"
        End If


        lQuery = lQuery & "" & lWhereCondition & " Order By H.PaymentDate Desc, DisplayID Desc "



        Try
            lDs = lConnection.ExecuteQuery(lQuery)
        Catch ex As Exception
            lDs = Nothing
        End Try


        Return lDs
    End Function


    Public Shared Function SearchPayment(ByVal lPaymentId As String, ByVal lDescription As String, ByVal lPayerType As String, ByVal lPaymentFromDate As String, ByVal lPaymentToDate As String, ByVal lPaymentMode As String, ByVal lPaymentStatus As String, ByVal lUser As User, ByVal pPayerName As String, ByVal pCheckFromDate As String, ByVal pCheckToDate As String, ByVal pCheckNumber As String, ByVal pPayerID As String) As DataSet
        Dim lDs As New DataSet
        Dim lConnection As New Connection(lUser.ConnectionString)
        Dim lWhereCondition As String = ""
        'Dim lQuery As String = "select *," _
        '                       & " Case H.PayerType when 'I' then 'Insurance' else 'Patient' end as PayerTypeFull," _
        '                       & " 'PT-' + cast(Year(PaymentDate) as varchar) + '-' + cast(Month(PaymentDate) as varchar) + '-' + REPLICATE('0', (5 - LEN(CAST(PaymentDIspid as VARCHAR)))) + CAST(PaymentDIspid as  VARCHAR) as DisplayID," _
        '                       & " CASE (H.Amount-X.AppliedAmount) when 0 then 'Close' else 'Open' END as PaymentStatus " _
        '                       & " from PaymentHdr H ," _
        '                       & " (select H.PaymentID as ID,isNull(sum(D.amountpaid),0) as AppliedAmount from PaymentDTl D,PaymentHdr H where  H.PaymentId*=D.PaymentId" _
        '                       & " group by H.PaymentId)X" _
        '                       & " where H.PaymentId=X.ID" _
        '                       & " AND H.IsDeleted!='Y'" _
        '                       & " AND H.UserID= " & lUser.UserId & " "


        'Dim lQuery As String = "select *," _
        '                       & " Case H.PayerType when 'I' then 'Insurance' else 'Patient' end as PayerTypeFull, 'PT-' + cast(Year(PaymentDate) as varchar) + '-' + cast(Month(PaymentDate) as varchar) + '-' + REPLICATE('0', (5 - LEN(CAST(DisplayID as VARCHAR)))) + CAST(DisplayID as  VARCHAR) as DisplayID1," _
        '                       & "CASE (X.TotalCharges-X.AppliedAmount) when 0 then 'Fully Applied' else 'Pending' END as PaymentStatus  from PaymentHdr H , (select H.PaymentID as ID,isNull(sum(D.TotalCharges),0) as TotalCharges,isNull(sum(D.TotalAmount),0) as AppliedAmount, H.Notes PaymentHdr H, PaymentDtl D where  H.PaymentId*=D.PaymentId" _
        '                       & " group by H.PaymentId)X where H.PaymentId=X.ID AND H.UserID= " & lUser.UserId & " "

        Dim lQuery As String = "SELECT     H.PaymentID, H.PaymentDate, H.DisplayID, H.EntryDate, H.PayerType, H.PayerID, H.PayerName, H.PaymentMode, H.CheckNumber, H.CheckDate,  H.Amount, H.Description, H.UserID, H.Notes," _
& "ISNULL(X.AppliedAmount, 0) AS AppliedAmount, CASE H.PayerType WHEN 'I' THEN 'Insurance' ELSE 'Patient' END AS PayerTypeFull, 'PT-' + CAST(YEAR(H.PaymentDate) AS varchar)  + " _
& "'-' + CAST(MONTH(H.PaymentDate) AS varchar) + '-' + REPLICATE('0', 5 - LEN(CAST(H.DisplayID AS VARCHAR))) + CAST(H.DisplayID AS VARCHAR)  AS DisplayID1" _
& " , CASE WHEN (H.Amount - IsNUll(X.AppliedAmount, 0)) <= 0 THEN 'Fully Applied' ELSE 'Pending' END AS PaymentStatus,RemittanceId=isNull(RH.RemittanceId,0) FROM " _
& "PaymentHdr AS H LEFT OUTER JOIN  " _
& " (SELECT     SUM(DtlAmount) + SUM(CPTAmount) AS AppliedAmount, PaymentID " _
& "        FROM" _
& "  (SELECT     Dtl.PaymentID, Dtl.Amount AS DtlAmount, SUM(ISNULL(CPT.Amount, 0)) AS CPTAmount  " _
& "   FROM       PaymentDtl AS Dtl LEFT OUTER JOIN " _
& "   PaymentCPTDetail AS CPT ON Dtl.PaymentDtlID = CPT.PaymentDtlID  " _
& "   GROUP BY Dtl.PaymentID, Dtl.PaymentDtlID, Dtl.Amount) AS Y" _
& "   GROUP BY PaymentID) AS X " _
& "   ON H.PaymentID = X.PaymentID " _
& "   LEFT OUTER JOIN RemittanceHdr RH ON H.PaymentID=RH.PaymentID" _
& "  WHERE 1=1"

        If (pPayerID <> "") Then
            lWhereCondition = lWhereCondition & " and (H.PayerType='P' and  H.PayerID ='" & pPayerID & "') "
        End If

        '''''''''''''''''''''''''''' PaymentId Check ''''''''''''''''''''''''
        If (lPaymentId <> "") Then
            lWhereCondition = lWhereCondition & " AND 'PT-' + cast(Year(H.PaymentDate) as varchar) + '-' + cast(Month(H.PaymentDate) as varchar) + '-' + REPLICATE('0', (5 - LEN(CAST(H.DisplayID as VARCHAR)))) + CAST(H.DisplayID as  VARCHAR) Like '%" & lPaymentId & "'"
        End If

        ''''''''''''''''''''''''''' Open/Close Check'''''''''''''''''

        If (lPaymentStatus <> "All") Then
            If (lPaymentStatus = "Pending") Then
                lWhereCondition = lWhereCondition & " AND (H.Amount-IsNull(X.AppliedAmount,0)) > 0"
            Else
                lWhereCondition = lWhereCondition & " AND (H.Amount-IsNull(X.AppliedAmount,0)) <= 0"
            End If
        End If


        ''''''''''''''''''''''''''' Payment Mode Check ''''''''''''''''''
        If (lPaymentMode <> "All") Then
            Select Case lPaymentMode
                Case "Check"
                    lWhereCondition = lWhereCondition & " AND H.PaymentMode='Check'"
                Case "Cash"
                    lWhereCondition = lWhereCondition & " AND H.PaymentMode='Cash'"
                Case "Credit Card"
                    lWhereCondition = lWhereCondition & " AND H.PaymentMode='Credit Card'"
                Case "EFT"
                    lWhereCondition = lWhereCondition & " AND H.PaymentMode='EFT'"
            End Select

            'If (lPaymentMode = "Check") Then
            '    lWhereCondition = lWhereCondition & " AND H.PaymentMode='Check'"
            'Else
            '    lWhereCondition = lWhereCondition & " AND H.PaymentMode='Cash'"
            'End If
        End If

        ''''''''''''''''''''''''''' Payer Type check ''''''''''''''''''''
        If (lPayerType <> "All") Then
            If (lPayerType = "I") Then
                lWhereCondition = lWhereCondition & " AND H.PayerType='I'"
            Else
                lWhereCondition = lWhereCondition & " AND H.PayerType='P'"
            End If
        End If

        ''''''''''''''''''''' Description Check'''''''''''''
        If (lDescription <> "") Then
            lWhereCondition = lWhereCondition & " AND H.Description = " & lDescription & ""
        End If

        '''''''''''''''''''''' Payment Date Check '''''''''''''''''''''
        If (lPaymentFromDate <> "" AndAlso lPaymentToDate <> "") Then
            lWhereCondition = lWhereCondition & " AND H.PaymentDate between cast ('" & lPaymentFromDate & "' as datetime) and cast('" & lPaymentToDate & "' as datetime)"
        End If


        ''''''''''''''''''''''''''Check the PayerName''''''''''''''''''''
        If (Not pPayerName.Equals("") AndAlso lPayerType.ToUpper <> "All") Then
            If (lPayerType.ToUpper = "P") Then
                Dim lPayerNameSpace As String = pPayerName.Replace(" ", "")
                If (lPayerNameSpace.Contains(",")) Then
                    lPayerNameSpace = lPayerNameSpace.Insert(lPayerNameSpace.IndexOf(",") + 1, " ")
                    lWhereCondition = lWhereCondition & " AND ( H.PayerName like '" & lPayerNameSpace & "%' " & " or H.PayerName like '" & pPayerName.Replace(" ", "") & "%' )"
                Else
                    lWhereCondition = lWhereCondition & " AND ( H.PayerName like '" & pPayerName & "%' )"
                End If
            Else
                lWhereCondition = lWhereCondition & " AND (H.PayerName like '" & pPayerName & "' )"
            End If

        End If

        '''''''''''''''''''''''''''Check for CheckDate & CheckNumber ''''''''''''''''''''''''''

        'If pCheckDate <> "" Then
        '    lWhereCondition = lWhereCondition & " AND  H.CheckDate = cast ('" & pCheckDate & "' as datetime)"
        'End If

        If (pCheckFromDate <> "" AndAlso pCheckToDate <> "") Then
            lWhereCondition = lWhereCondition & " AND H.CheckDate between cast ('" & pCheckFromDate & "' as datetime) and cast('" & pCheckToDate & "' as datetime)"
        End If



        If pCheckNumber <> "" Then
            lWhereCondition = lWhereCondition & " AND  H.CheckNumber Like '" & pCheckNumber & "%'"
        End If


        lQuery = lQuery & "" & lWhereCondition & " Order By H.PaymentDate Desc, DisplayID Desc "



        Try
            lDs = lConnection.ExecuteQuery(lQuery)
        Catch ex As Exception
            lDs = Nothing
        End Try


        Return lDs
    End Function
End Class
