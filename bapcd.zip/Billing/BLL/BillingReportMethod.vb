Imports Microsoft.VisualBasic

Public Class BillingReportMethod
    Public Shared Function GetDailyRecap(ByVal pDate As Date) As DataSet
        Dim lSpParameter(0) As SpParameter
        Dim lUser As User
        Dim lConnection As Connection
        Dim lDS As New DataSet
        Try

            lUser = CType(HttpContext.Current.Session("User"), User)
            lConnection = New Connection(lUser.ConnectionString)

            lSpParameter(0).ParameterName = "@pDate"
            lSpParameter(0).ParameterType = ElixirLibrary.ParameterType.BigInt
            lSpParameter(0).ParameterValue = pDate

            If lConnection.IsTransactionAlive() Then
                lDS = lConnection.ExecuteTransactionQuery("GetRptDailyRecap", lSpParameter)
            Else
                lDS = lConnection.ExecuteQuery("GetRptDailyRecap", lSpParameter)
            End If

            Return lDS
        Catch ex As Exception
            Return Nothing
        End Try

    End Function
    
    Public Shared Function GetMonthlyTransDetail(ByVal pThisYear As String, ByVal pLastYear As String) As DataSet
        Dim lSpParameter(1) As SpParameter
        Dim lUser As User
        Dim lConnection As Connection
        Dim lDS As New DataSet
        Try

            lUser = CType(HttpContext.Current.Session("User"), User)
            lConnection = New Connection(lUser.ConnectionString)

            lSpParameter(0).ParameterName = "@pThisYear"
            lSpParameter(0).ParameterType = ElixirLibrary.ParameterType.Varchar
            lSpParameter(0).ParameterValue = pThisYear

            lSpParameter(1).ParameterName = "@pLastYear"
            lSpParameter(1).ParameterType = ElixirLibrary.ParameterType.Varchar
            lSpParameter(1).ParameterValue = pLastYear

            If lConnection.IsTransactionAlive() Then
                lDS = lConnection.ExecuteTransactionQuery("GetRptArYrsCmprsn", lSpParameter)
            Else
                lDS = lConnection.ExecuteQuery("GetRptArYrsCmprsn", lSpParameter)
            End If

            Return lDS
        Catch ex As Exception
            Return Nothing
        End Try

    End Function
    Public Shared Function GetDailyTransactionReport(ByVal pDate As Date) As DataSet
        Dim lSpParameter(0) As SpParameter
        Dim lUser As User
        Dim lConnection As Connection
        Dim lDS As New DataSet
        Try

            lUser = CType(HttpContext.Current.Session("User"), User)
            lConnection = New Connection(lUser.ConnectionString)
            lSpParameter(0).ParameterName = "@pDate"
            lSpParameter(0).ParameterType = ElixirLibrary.ParameterType.BigInt
            lSpParameter(0).ParameterValue = pDate

            If lConnection.IsTransactionAlive() Then
                lDS = lConnection.ExecuteTransactionQuery("GetDailyTransactionReport", lSpParameter)
            Else
                lDS = lConnection.ExecuteQuery("GetDailyTransactionReport", lSpParameter)
            End If
            Return lDS

        Catch ex As Exception
            Return Nothing
        End Try

    End Function




            


End Class
