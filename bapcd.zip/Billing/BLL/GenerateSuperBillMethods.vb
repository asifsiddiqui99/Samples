Imports Microsoft.VisualBasic
Imports Telerik.WebControls
Public Class GenerateSuperBillMethods
    Public Shared Sub LoadCPTGrid(ByRef pGrid As RadGrid, ByVal pSuperBillId As String, ByVal pOrderBy As String, ByVal pGridNo As Integer)
        Dim lUser As User
        Dim lCPT As CPT
        Dim lArrOrderBy As String()
        Dim lOrderColumn As String = ""
        Dim lOrder As String = ""
        Try
            If pOrderBy <> "" Then
                lArrOrderBy = pOrderBy.Split("|")
                lOrderColumn = IIf(lArrOrderBy(2) = "C", "Code", "ShortDescription")
                lOrder = IIf(Left(lArrOrderBy(3), 1) = "A", " ", "Desc")
            End If
            lUser = CType(HttpContext.Current.Session("User"), User)
            lCPT = New CPT(lUser.ConnectionString)
            lCPT.CPT.SuperBillId = pSuperBillId
            pGrid.DataSource = lCPT.GetCPTForGenerate("Order By HeadingOrder," & lOrderColumn & " " & lOrder).Tables(pGridNo)
        Catch ex As Exception

        End Try
    End Sub
    Public Shared Sub LoadPreviewCPTGrid(ByRef pGrid As RadGrid, ByVal pPatientSuperBillID As String, ByVal pSuperBillId As String, ByVal pOrderBy As String, ByVal pGridNo As Integer)
        Dim lUser As User
        Dim lCPT As CPT
        Dim lArrOrderBy As String()
        Dim lOrderColumn As String = ""
        Dim lOrder As String = ""
        Try
            If pOrderBy <> "" Then
                lArrOrderBy = pOrderBy.Split("|")
                lOrderColumn = IIf(lArrOrderBy(2) = "C", "Code", "ShortDescription")
                lOrder = IIf(Left(lArrOrderBy(3), 1) = "A", " ", "Desc")
            End If
            lUser = CType(HttpContext.Current.Session("User"), User)
            lCPT = New CPT(lUser.ConnectionString)
            lCPT.CPT.SuperBillId = pSuperBillId
            lCPT.CPT.PatientSuperBillId = pPatientSuperBillID
            pGrid.DataSource = lCPT.GetCPTForPreview("Order By HeadingOrder," & lOrderColumn & " " & lOrder).Tables(pGridNo)
        Catch ex As Exception

        End Try
    End Sub
    Public Shared Sub LoadICDGrid(ByRef pGrid As RadGrid, ByVal pSuperBillId As String, ByVal pOrderBy As String, ByVal pGridNo As Integer)
        Dim lUser As User
        Dim lICD As ICD9
        Dim lArrOrderBy As String()
        Dim lOrderColumn As String = ""
        Dim lOrder As String = ""
        Try
            If pOrderBy <> "" Then
                lArrOrderBy = pOrderBy.Split("|")
                lOrderColumn = IIf(lArrOrderBy(0) = "C", "Code", "Description")
                lOrder = IIf(Left(lArrOrderBy(1), 1) = "A", " ", "Desc")
            End If
            lUser = CType(HttpContext.Current.Session("User"), User)
            lICD = New ICD9(lUser.ConnectionString)
            lICD.ICD9.SuperBillId = pSuperBillId
            pGrid.DataSource = lICD.GetCPTForGenerate("Order By " & lOrderColumn & " " & lOrder).Tables(pGridNo)
        Catch ex As Exception

        End Try
    End Sub
    Public Shared Sub LoadICDGridForPreview(ByRef pGrid As RadGrid, ByVal pPatientSuperBillID As String, ByVal pSuperBillId As String, ByVal pOrderBy As String, ByVal pGridNo As Integer)
        Dim lUser As User
        Dim lICD As ICD9
        Dim lArrOrderBy As String()
        Dim lOrderColumn As String = ""
        Dim lOrder As String = ""
        Try
            If pOrderBy <> "" Then
                lArrOrderBy = pOrderBy.Split("|")
                lOrderColumn = IIf(lArrOrderBy(0) = "C", "Code", "Description")
                lOrder = IIf(Left(lArrOrderBy(1), 1) = "A", " ", "Desc")
            End If
            lUser = CType(HttpContext.Current.Session("User"), User)
            lICD = New ICD9(lUser.ConnectionString)
            lICD.ICD9.SuperBillId = pSuperBillId
            lICD.ICD9.PatientSuperBillId = pPatientSuperBillID
            pGrid.DataSource = lICD.GetICDForPreview("Order By " & lOrderColumn & " " & lOrder).Tables(pGridNo)
        Catch ex As Exception
        End Try
    End Sub
    Public Shared Function SavePatientCPT(ByRef pPatientCPT As PatientCPT, ByRef ppnlBillingInfo As Panel, ByVal pPatientSuperBillId As String) As Boolean
        Dim lLineNumber As Integer = 1
        Dim lPatientCPTDB As PatientCPTDB
        Dim lDescription As String = String.Empty
        Try
            For lLineNumber = 1 To 6
                If CType(ppnlBillingInfo.FindControl("cmbCPT" & lLineNumber.ToString), RadComboBox).Text <> "" Then
                    If CType(ppnlBillingInfo.FindControl("txtLineId" & lLineNumber.ToString), TextBox).Text <> "0" Then
                        If CType(ppnlBillingInfo.FindControl("hdIsDeleted" & lLineNumber.ToString), TextBox).Text <> "Y" Then
                            lPatientCPTDB = New PatientCPTDB()
                            lPatientCPTDB.Charges = CType(ppnlBillingInfo.FindControl("txtCharges" & lLineNumber.ToString), TextBox).Text
                            lPatientCPTDB.Fees = CType(ppnlBillingInfo.FindControl("txtCharges" & lLineNumber.ToString), TextBox).Text
                            lPatientCPTDB.Code = CType(ppnlBillingInfo.FindControl("cmbCPT" & lLineNumber.ToString), RadComboBox).Text
                            lPatientCPTDB.Days = CType(ppnlBillingInfo.FindControl("txtDays" & lLineNumber.ToString), TextBox).Text
                            lPatientCPTDB.Description = CType(ppnlBillingInfo.FindControl("txtDescription" & lLineNumber.ToString), TextBox).Text
                            lPatientCPTDB.ModifierA = CType(ppnlBillingInfo.FindControl("txtA" & lLineNumber.ToString), DropDownList).SelectedItem.Text
                            lPatientCPTDB.ModifierB = CType(ppnlBillingInfo.FindControl("txtB" & lLineNumber.ToString), DropDownList).SelectedItem.Text
                            lPatientCPTDB.ModifierC = CType(ppnlBillingInfo.FindControl("txtC" & lLineNumber.ToString), DropDownList).SelectedItem.Text
                            lPatientCPTDB.ModifierD = CType(ppnlBillingInfo.FindControl("txtD" & lLineNumber.ToString), DropDownList).SelectedItem.Text
                            lPatientCPTDB.Pointer = CType(ppnlBillingInfo.FindControl("txtPointer" & lLineNumber.ToString), TextBox).Text
                            lPatientCPTDB.POS = CType(ppnlBillingInfo.FindControl("cmbPOS" & lLineNumber.ToString), DropDownList).SelectedValue.ToString
                            lPatientCPTDB.DateOfServiceFrom = CType(ppnlBillingInfo.FindControl("dtDate" & lLineNumber.ToString & "1"), RadDatePicker).SelectedDate
                            lPatientCPTDB.DateOfServiceTo = CType(ppnlBillingInfo.FindControl("dtDate" & lLineNumber.ToString & "2"), RadDatePicker).SelectedDate
                            lPatientCPTDB.IsGridItem = CType(ppnlBillingInfo.FindControl("txtFromGrid" & lLineNumber.ToString), TextBox).Text
                            lPatientCPTDB.Heading = CType(ppnlBillingInfo.FindControl("txtHeading" & lLineNumber.ToString), TextBox).Text
                            lPatientCPTDB.IsSelected = "Y"
                            lPatientCPTDB.LineNumber = lLineNumber.ToString
                            lPatientCPTDB.NPI = pPatientCPT.PatientCPT.NPI
                            lPatientCPTDB.IMOCode = CType(ppnlBillingInfo.FindControl("cmbIMO" & lLineNumber.ToString), TextBox).Text
                            pPatientCPT.PatientCPT = lPatientCPTDB
                            pPatientCPT.PatientCPT.PatientSuperBillId = pPatientSuperBillId
                            pPatientCPT.PatientCPT.FacilityId = CType(ppnlBillingInfo.FindControl("cmbPOS" & lLineNumber.ToString), DropDownList).SelectedValue.ToString
                            pPatientCPT.PatientCPT.ProviderId = CType(ppnlBillingInfo.FindControl("cmbProvider" & lLineNumber.ToString), RadComboBox).SelectedValue.ToString
                            pPatientCPT.InsertRecord()
                        End If
                    Else
                        lPatientCPTDB = New PatientCPTDB()
                        lPatientCPTDB.Charges = CType(ppnlBillingInfo.FindControl("txtCharges" & lLineNumber.ToString), TextBox).Text
                        lPatientCPTDB.Fees = CType(ppnlBillingInfo.FindControl("txtCharges" & lLineNumber.ToString), TextBox).Text
                        lPatientCPTDB.Code = CType(ppnlBillingInfo.FindControl("cmbCPT" & lLineNumber.ToString), RadComboBox).Text
                        lPatientCPTDB.Days = CType(ppnlBillingInfo.FindControl("txtDays" & lLineNumber.ToString), TextBox).Text
                        lPatientCPTDB.Description = CType(ppnlBillingInfo.FindControl("txtDescription" & lLineNumber.ToString), TextBox).Text
                        lPatientCPTDB.ModifierA = CType(ppnlBillingInfo.FindControl("txtA" & lLineNumber.ToString), DropDownList).SelectedItem.Text
                        lPatientCPTDB.ModifierB = CType(ppnlBillingInfo.FindControl("txtB" & lLineNumber.ToString), DropDownList).SelectedItem.Text
                        lPatientCPTDB.ModifierC = CType(ppnlBillingInfo.FindControl("txtC" & lLineNumber.ToString), DropDownList).SelectedItem.Text
                        lPatientCPTDB.ModifierD = CType(ppnlBillingInfo.FindControl("txtD" & lLineNumber.ToString), DropDownList).SelectedItem.Text
                        lPatientCPTDB.Pointer = CType(ppnlBillingInfo.FindControl("txtPointer" & lLineNumber.ToString), TextBox).Text
                        lPatientCPTDB.POS = CType(ppnlBillingInfo.FindControl("cmbPOS" & lLineNumber.ToString), DropDownList).SelectedValue.ToString
                        lPatientCPTDB.DateOfServiceFrom = CType(ppnlBillingInfo.FindControl("dtDate" & lLineNumber.ToString & "1"), RadDatePicker).SelectedDate
                        lPatientCPTDB.DateOfServiceTo = CType(ppnlBillingInfo.FindControl("dtDate" & lLineNumber.ToString & "2"), RadDatePicker).SelectedDate
                        lPatientCPTDB.IsGridItem = CType(ppnlBillingInfo.FindControl("txtFromGrid" & lLineNumber.ToString), TextBox).Text
                        lPatientCPTDB.Heading = CType(ppnlBillingInfo.FindControl("txtHeading" & lLineNumber.ToString), TextBox).Text
                        lPatientCPTDB.IsSelected = "Y"
                        lPatientCPTDB.LineNumber = lLineNumber.ToString
                        lPatientCPTDB.NPI = pPatientCPT.PatientCPT.NPI
                        lPatientCPTDB.IMOCode = CType(ppnlBillingInfo.FindControl("cmbIMO" & lLineNumber.ToString), TextBox).Text
                        pPatientCPT.PatientCPT = lPatientCPTDB
                        pPatientCPT.PatientCPT.PatientSuperBillId = pPatientSuperBillId
                        pPatientCPT.PatientCPT.FacilityId = CType(ppnlBillingInfo.FindControl("cmbPOS" & lLineNumber.ToString), DropDownList).SelectedValue.ToString
                        pPatientCPT.PatientCPT.ProviderId = CType(ppnlBillingInfo.FindControl("cmbProvider" & lLineNumber.ToString), RadComboBox).SelectedValue.ToString
                        pPatientCPT.InsertRecord()
                    End If
                End If
            Next
        Catch ArgEx As ArgumentException
            Throw ArgEx
        Catch ex As Exception
            'Return False
            Throw ex
        End Try
        Return True
    End Function
    'Public Shared Function SavePatientCPT(ByRef pPatientCPT As PatientCPT, ByRef ppnlBillingInfo As Panel, ByVal pPatientSuperBillId As String) As Boolean
    '    Dim lLineNumber As Integer = 1
    '    'Dim lPatientCPTColl As New PatientCPTColl
    '    Dim lPatientCPTDB As PatientCPTDB
    '    For lLineNumber = 1 To 6
    '        If CType(ppnlBillingInfo.FindControl("txtCPT" & lLineNumber.ToString), TextBox).Text <> "" _
    '                And CType(ppnlBillingInfo.FindControl("txtDescription" & lLineNumber.ToString), TextBox).Text <> "" Then
    '            lPatientCPTDB = New PatientCPTDB()
    '            lPatientCPTDB.Charges = CType(ppnlBillingInfo.FindControl("txtCharges" & lLineNumber.ToString), TextBox).Text
    '            lPatientCPTDB.Fees = CType(ppnlBillingInfo.FindControl("txtCharges" & lLineNumber.ToString), TextBox).Text
    '            lPatientCPTDB.Code = CType(ppnlBillingInfo.FindControl("txtCPT" & lLineNumber.ToString), TextBox).Text
    '            lPatientCPTDB.Days = CType(ppnlBillingInfo.FindControl("txtDays" & lLineNumber.ToString), TextBox).Text
    '            lPatientCPTDB.Description = CType(ppnlBillingInfo.FindControl("txtDescription" & lLineNumber.ToString), TextBox).Text
    '            lPatientCPTDB.ModifierA = CType(ppnlBillingInfo.FindControl("txtA" & lLineNumber.ToString), TextBox).Text
    '            lPatientCPTDB.ModifierB = CType(ppnlBillingInfo.FindControl("txtB" & lLineNumber.ToString), TextBox).Text
    '            lPatientCPTDB.ModifierC = CType(ppnlBillingInfo.FindControl("txtC" & lLineNumber.ToString), TextBox).Text
    '            lPatientCPTDB.ModifierD = CType(ppnlBillingInfo.FindControl("txtD" & lLineNumber.ToString), TextBox).Text
    '            lPatientCPTDB.Pointer = CType(ppnlBillingInfo.FindControl("cmbPointer" & lLineNumber.ToString), RadComboBox).SelectedItem.Text
    '            lPatientCPTDB.POS = CType(ppnlBillingInfo.FindControl("cmbPOS" & lLineNumber.ToString), RadComboBox).SelectedItem.Text
    '            lPatientCPTDB.CPTDate = CType(ppnlBillingInfo.FindControl("dtDate" & lLineNumber.ToString), RadDatePicker).SelectedDate
    '            lPatientCPTDB.IsGridItem = IIf(CType(ppnlBillingInfo.FindControl("txtFromGrid" & lLineNumber.ToString), TextBox).Text = "Y", "Y", "N")
    '            lPatientCPTDB.Heading = IIf(lPatientCPTDB.IsGridItem = "Y", CType(ppnlBillingInfo.FindControl("txtHeading" & lLineNumber.ToString), TextBox).Text, "Others")
    '            lPatientCPTDB.IsSelected = "Y"
    '            lPatientCPTDB.LineNumber = lLineNumber.ToString
    '            'lPatientCPTColl.Add(lPatientCPTDB)
    '            pPatientCPT.PatientCPT = lPatientCPTDB
    '            pPatientCPT.PatientCPT.PatientSuperBillId = pPatientSuperBillId
    '            pPatientCPT.InsertRecord()
    '        End If
    '    Next
    '    Return True
    '    '    For Each lControl In ppnlBillingInfo.FindControl()
    '    '        If TypeOf lControl Is System.Web.UI.WebControls.TextBox Then
    '    '            Select Case lControl.ID
    '    '                Case "txtCharges" & lLineNumber.ToString
    '    '                    lPatientCPTDB.Charges = CType(lControl, TextBox).Text
    '    '                    lPatientCPTDB.Fees = CType(lControl, TextBox).Text
    '    '                Case "txtCPT" & lLineNumber.ToString
    '    '                    lPatientCPTDB.Code = CType(lControl, TextBox).Text
    '    '                Case "txtDays" & lLineNumber.ToString
    '    '                    lPatientCPTDB.Days = CType(lControl, TextBox).Text
    '    '                Case "txtDescription" & lLineNumber.ToString
    '    '                    lPatientCPTDB.Description = CType(lControl, TextBox).Text
    '    '                Case "txtA" & lLineNumber.ToString
    '    '                    lPatientCPTDB.ModifierA = CType(lControl, TextBox).Text
    '    '                Case "txtB" & lLineNumber.ToString
    '    '                    lPatientCPTDB.ModifierB = CType(lControl, TextBox).Text
    '    '                Case "txtC" & lLineNumber.ToString
    '    '                    lPatientCPTDB.ModifierC = CType(lControl, TextBox).Text
    '    '                Case "txtD" & lLineNumber.ToString
    '    '                    lPatientCPTDB.ModifierD = CType(lControl, TextBox).Text
    '    '            End Select
    '    '        ElseIf TypeOf lControl Is Telerik.WebControls.RadComboBox Then
    '    '            Select Case lControl.ID
    '    '                Case "cmbPointer" & lLineNumber.ToString
    '    '                    lPatientCPTDB.Pointer = CType(lControl, RadComboBox).SelectedItem.Text
    '    '                Case "cmbPOS" & lLineNumber.ToString
    '    '                    lPatientCPTDB.POS = CType(lControl, RadComboBox).SelectedItem.Text
    '    '            End Select
    '    '        ElseIf TypeOf lControl Is Telerik.WebControls.RadCalendar Then
    '    '            Select Case lControl.ID
    '    '                Case "dtDate" & lLineNumber.ToString
    '    '                    lPatientCPTDB.CPTDate = CType(lControl, RadCalendar).SelectedDate
    '    '            End Select
    '    '        End If
    '    '        lPatientCPTDB.Heading = "Others"
    '    '        lPatientCPTDB.IsGridItem = "N"
    '    '        lPatientCPTDB.IsSelected = "Y"
    '    '        lPatientCPTDB.LineNumber = lLineNumber.ToString
    '    '    Next
    '    '    lPatientCPTColl.Add(lPatientCPTDB)
    '    'Next
    'End Function
    Private Shared Function DeletePatientCPT(ByRef pPatientCPT As PatientCPT, ByVal pPatientSuperBillId As String) As Boolean
        'Dim lPatientCPT As PatientCPT
        Try
            'lPatientCPT = New PatientCPT(pConnectionString)
            pPatientCPT.DeleteRecord(" And PatientSuperBillId = " & pPatientSuperBillId)
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Shared Function SavePatientICD(ByRef pPatientICD As PatientICD, ByRef ppnlBillingInfo As Panel, ByVal pPatientSuperBillId As String) As Boolean
        Dim lLineNumber As Integer = 1
        'Dim lPatientICDColl As New PatientICDColl
        Dim lPatientICDDB As PatientICDDB
        Try
            For lLineNumber = 1 To 12
                If CType(ppnlBillingInfo.FindControl("cmbICD" & lLineNumber.ToString), RadComboBox).Text <> "" _
                        And CType(ppnlBillingInfo.FindControl("txtICDDescription" & lLineNumber.ToString), TextBox).Text <> "" Then
                    lPatientICDDB = New PatientICDDB()
                    lPatientICDDB.Code = CType(ppnlBillingInfo.FindControl("cmbICD" & lLineNumber.ToString), RadComboBox).Text
                    lPatientICDDB.Description = CType(ppnlBillingInfo.FindControl("txtICDDescription" & lLineNumber.ToString), TextBox).Text
                    lPatientICDDB.IsGridItem = IIf(CType(ppnlBillingInfo.FindControl("txtICDFromGrid" & lLineNumber.ToString), TextBox).Text = "Y", "Y", "N")
                    lPatientICDDB.IsSelected = "Y"
                    lPatientICDDB.LineNumber = lLineNumber
                    lPatientICDDB.IMOCode = CType(ppnlBillingInfo.FindControl("txtIMO" & lLineNumber.ToString), TextBox).Text
                    'lPatientICDColl.Add(lPatientICDDB)
                    pPatientICD.PatientICD = lPatientICDDB
                    pPatientICD.PatientICD.PatientSuperBillId = pPatientSuperBillId
                    pPatientICD.InsertRecord()
                End If
            Next
            Return True
        Catch ex As Exception

        End Try
    End Function
    Private Shared Function DeletePatientICD(ByRef pPatientICD As PatientICD, ByVal pPatientSuperBillId As String) As Boolean
        'Dim lPatientICD As PatientICD
        Try
            'lPatientICD = New PatientICD(pConnectionString)
            pPatientICD.DeleteRecord(" And PatientSuperBillId = " & pPatientSuperBillId)
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function
    ''''''''''''''''''''''''''''''''''''''''''''''''''Change Log''''''''''''''''''''''''''''''''''''''''''''''''
    'Date : 25th July 2007 
    'By : Faraz Ahmed
    'Description : Return type from Boolean to integer for returning the PAtientSuperBillID    
    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''    
    Public Shared Function AddPatientSuperBill(ByRef pPatientSuperBillDB As PatientSuperBillDB, ByRef pPnlBillingInfo As Panel, ByVal pPageURL As String, ByVal pRenderringProviderNPI As String) As Integer
        Dim lUser As User
        Dim lConnection As Connection
        Dim lPatientSuperBillId As String
        Dim lErrorLog As New ErrorLog()
        Dim lEventLog As New EventLog()
        Dim lPatientCPT As PatientCPT
        Dim lPatientICD As PatientICD
        Try
            lUser = CType(HttpContext.Current.Session("User"), User)
            lConnection = New Connection(lUser.ConnectionString)
            Dim lPatientSuperBill As New PatientSuperBill(lConnection)
            lConnection.BeginTrans()
            lPatientCPT = New PatientCPT(lConnection)
            lPatientCPT.PatientCPT.NPI = pRenderringProviderNPI
            lPatientICD = New PatientICD(lConnection)
            lPatientSuperBillId = lPatientSuperBill.GetUniqueId("")
            lPatientSuperBill.PatientSuperBill = pPatientSuperBillDB
            lPatientSuperBill.PatientSuperBill.PatientSuperBillID = lPatientSuperBillId
            lPatientSuperBill.InsertRecord()
            SavePatientCPT(lPatientCPT, pPnlBillingInfo, lPatientSuperBillId)
            SavePatientICD(lPatientICD, pPnlBillingInfo, lPatientSuperBillId)
            lEventLog.EventLog.ClinicID = lUser.ClinicId
            lEventLog.EventLog.EventTypeID = EventType.GenerateSuperBill
            lEventLog.EventLog.ExtraID = lPatientSuperBillId
            lEventLog.EventLog.OCcurTime = Date.Now()
            lEventLog.EventLog.UserID = lUser.UserId
            lEventLog.EventLog.EventDescription = "A SuperBill of ID '" + lPatientSuperBillId.ToString() + "' is Generated of the clinic having ClinicID '" + lUser.ClinicId + "' on '" + lEventLog.EventLog.OCcurTime + "' by the loginID '" + lUser.LoginId + "'"
            lEventLog.HandleEvent()
            lConnection.CommitTrans()
        Catch ex As Exception
            lConnection.RollBackTrans()
            lErrorLog.HandleError(ex, lUser, pPageURL)
            Return 0
        End Try
        Return lPatientSuperBillId
    End Function
    Public Shared Function AddPatientSuperBill(ByRef pPatientSuperBillDB As PatientSuperBillDB, ByRef pPaymentHdr As PaymentHdrDB, ByVal pPageURL As String, ByVal pRenderringProviderNPI As String) As Integer
        Dim lUser As User
        Dim lPaymentId As String = ""
        Dim lresult As Boolean
        Dim lConnection As Connection
        Dim lPatientSuperBillId As String
        Dim lPatientLedger As PatientLedger
        Dim lPatientLedgerDB As PatientLedgerDB
        Dim lErrorLog As New ErrorLog()
        Dim lEventLog As New EventLog()
        '  Dim lPatientCPT As PatientCPT
        '  Dim lPatientICD As PatientICD
        Try
            lUser = CType(HttpContext.Current.Session("User"), User)
            lConnection = New Connection(lUser.ConnectionString)
            Dim lPatientSuperBill As New PatientSuperBill(lConnection)
            Dim lpaymentHeader As New PaymentHdr(lConnection)
            lPatientLedger = New PatientLedger(lConnection)
            lPatientLedgerDB = New PatientLedgerDB()
            lConnection.BeginTrans()
            '     lPatientCPT = New PatientCPT(lConnection)
            '    lPatientCPT.PatientCPT.NPI = pRenderringProviderNPI
            '     lPatientICD = New PatientICD(lConnection)
            lPatientSuperBillId = lPatientSuperBill.GetUniqueId("")
            lPatientSuperBill.PatientSuperBill = pPatientSuperBillDB
            lPatientSuperBill.PatientSuperBill.PatientSuperBillID = lPatientSuperBillId
            lPatientSuperBill.InsertRecord()
            'saving copay in paymenrHDR
            If pPaymentHdr.Amount <> "" Then
                lpaymentHeader.PaymentHdr = pPaymentHdr
                lresult = lpaymentHeader.GetUniqueId()
                If Not lresult Then
                    Throw New Exception("Can't Get PaymentID")
                End If
                lpaymentHeader.InsertRecord()


                ''saving copay in patient ledger
                'With lPatientLedgerDB
                '    .ReferenceID = pPaymentHdr.PaymentID
                '    .ReferenceDate = pPaymentHdr.PaymentDate
                '    .ReferenceID2 = lPatientSuperBill.PatientSuperBill.PatientSuperBillID
                '    .ReferenceDate2 = lPatientSuperBill.PatientSuperBill.VisitDisplayDATE
                '    '.ReferenceDisplayID = pPaymentHdr.PaymentDispId
                '    .ReferenceDisplayID = CDate(pPaymentHdr.PaymentDate).Year.ToString().PadLeft(2, "0") & "-" & CDate(pPaymentHdr.PaymentDate).Month.ToString().PadLeft(2, "0") & "-00000"
                '    .ReferenceDisplayDate = pPaymentHdr.PaymentDispDate
                '    .ReferenceDisplayID2 = lPatientSuperBill.PatientSuperBill.PatientSuperBillDisplayID
                '    .TransactionType = "C"
                '    .PatientID = lPatientSuperBill.PatientSuperBill.PatientId
                '    .Reference = "Copay"
                '    .Date1 = Date.Now.Date
                '    .Description = "Patient Copay"
                '    .PayerName = lPatientSuperBill.PatientSuperBill.PatientName
                '    .PayerType = "P"
                '    .Debit = "0"
                '    .Credit = pPaymentHdr.Amount
                '    .Adjustment = "0"

                '    .ChequeNumber = "12345"
                '    .ChequeDate = "09/24/2010"
                'End With
                'lPatientLedger.PatientLedger = lPatientLedgerDB
                'lPatientLedger.InsertPatientLedger()


            End If
            '    SavePatientCPT(lPatientCPT, pPnlBillingInfo, lPatientSuperBillId)
            '    SavePatientICD(lPatientICD, pPnlBillingInfo, lPatientSuperBillId)
            lEventLog.EventLog.ClinicID = lUser.ClinicId
            lEventLog.EventLog.EventTypeID = 21 'EventType.GenerateSuperBill
            lEventLog.EventLog.ExtraID = lPatientSuperBillId
            lEventLog.EventLog.OCcurTime = Date.Now()
            lEventLog.EventLog.UserID = lUser.UserId
            lEventLog.EventLog.EventDescription = "A SuperBill of ID '" + lPatientSuperBillId.ToString() + "' is Generated of the clinic having ClinicID '" + lUser.ClinicId + "' on '" + lEventLog.EventLog.OCcurTime + "' by the loginID '" + lUser.LoginId + "'"
            lEventLog.HandleEvent()
            lEventLog.EventLog.ClinicID = lUser.ClinicId
            lEventLog.EventLog.EventTypeID = EventType.CreateEmployee
            lEventLog.EventLog.ExtraID = lpaymentHeader.PaymentHdr.PaymentID
            lEventLog.EventLog.OCcurTime = Date.Now()
            lEventLog.EventLog.UserID = lUser.UserId
            lEventLog.EventLog.EventDescription = "A Payment of ID '" + lpaymentHeader.PaymentHdr.PaymentID + "' is created of the clinic having ClinicID '" + lUser.ClinicId + "' on '" + lEventLog.EventLog.OCcurTime + "' by the loginID '" + lUser.LoginId + "'"
            lEventLog.HandleEvent()
            lConnection.CommitTrans()
        Catch ex As Exception
            lConnection.RollBackTrans()
            lErrorLog.HandleError(ex, lUser, pPageURL)
            Return 0
        End Try
        Return lPatientSuperBillId
    End Function
    Public Shared Function EditPatientSuperBill(ByRef pPatientSuperBillDB As PatientSuperBillDB, ByRef pPnlBillingInfo As Panel, ByVal pPageURL As String, ByVal pRenderringProviderNPI As String) As Boolean
        Dim lUser As User
        Dim lConnection As Connection
        Dim lErrorLog As New ErrorLog()
        Dim lEventLog As New EventLog()
        Dim lReversedRows As String = ""
        Dim lResult As String = ""
        Dim lAdjID As Int32
        Try

            lUser = CType(HttpContext.Current.Session("User"), User)
            lConnection = New Connection(lUser.ConnectionString)
            Dim lPatientSuperBill As New PatientSuperBill(lConnection)
            lPatientSuperBill.PatientSuperBill = pPatientSuperBillDB
            Dim lPatientCPT As New PatientCPT(lConnection)
            lPatientCPT.PatientCPT.NPI = pRenderringProviderNPI
            Dim lPatientICD As New PatientICD(lConnection)
            Dim lPatientLedger As New PatientLedger(lConnection)
            Dim lAdjustment As New Adjustment(lConnection)
            Dim lHCFAUpdated As New HCFAUpdated(lConnection)

            lReversedRows = CType(pPnlBillingInfo.FindControl("txtHdnCodes"), TextBox).Text

            lConnection.BeginTrans()
            'lPatientSuperBill.PatientSuperBill.Status = pStatus
            'lPatientSuperBill.PatientSuperBill.PatientSuperBillID = pPatientSuperBillID
            lPatientSuperBill.UpdateStatus(pPatientSuperBillDB.DateOfService.Split("|")(1))
            DeletePatientICD(lPatientICD, pPatientSuperBillDB.PatientSuperBillID)
            DeletePatientCPT(lPatientCPT, pPatientSuperBillDB.PatientSuperBillID)
            SavePatientCPT(lPatientCPT, pPnlBillingInfo, pPatientSuperBillDB.PatientSuperBillID)
            SavePatientICD(lPatientICD, pPnlBillingInfo, pPatientSuperBillDB.PatientSuperBillID)
            'lResult = lPatientSuperBill.InsertAdjustmentForVisit(lAdjustment, lUser.UserId, lPatientSuperBill.PatientSuperBill.PatientSuperBillID, lReversedRows)
            'If (lResult <> "") Then
            '    lAdjID = CType(lResult, Int32)
            'Else
            '    lAdjID = 0
            'End If

            lHCFAUpdated.UpdateHcfaStatus(pPatientSuperBillDB.PatientSuperBillID)

            If (pPatientSuperBillDB.Status = "Approved") Then
                'to include ledger entries in transaction 21st Sept 2010
                If (lReversedRows <> "") Then
                    'PatientLedgerMethods.SaveVisitReversalEntry(lAdjID, CType(pPnlBillingInfo.FindControl("txtHdnCodes"), TextBox).Text, pPatientSuperBillDB, lPatientLedger)
                    PatientLedgerMethods.SaveVisitReversalEntry(pPatientSuperBillDB.PatientSuperBillID, CType(pPnlBillingInfo.FindControl("txtHdnCodes"), TextBox).Text, pPatientSuperBillDB, lPatientLedger)
                    'PatientLedgerMethods.CptLogicalDelete(CType(pPnlBillingInfo.FindControl("txtHdnCodes"), TextBox).Text, lPatientLedger)
                End If
                PatientLedgerMethods.SavePatientLedger(pPnlBillingInfo, pPatientSuperBillDB, lPatientLedger)
            End If


            lEventLog.EventLog.ClinicID = lUser.ClinicId
            lEventLog.EventLog.EventTypeID = 21
            lEventLog.EventLog.ExtraID = pPatientSuperBillDB.PatientSuperBillID
            lEventLog.EventLog.OCcurTime = Date.Now()
            lEventLog.EventLog.UserID = lUser.UserId
            lEventLog.EventLog.EventDescription = "A PatientSuperBill of ID '" + pPatientSuperBillDB.PatientSuperBillID.ToString() + "' is Generated of the clinic having ClinicID '" + lUser.ClinicId + "' on '" + lEventLog.EventLog.OCcurTime + "' by the loginID '" + lUser.LoginId + "'"
            lEventLog.HandleEvent()
            lConnection.CommitTrans()
            Return True
        Catch ArgEx As ArgumentException
            lConnection.RollBackTrans()
            Throw ArgEx
        Catch ex As Exception
            lConnection.RollBackTrans()
            lErrorLog.HandleError(ex, lUser, pPageURL)
            Return False
        End Try
    End Function
    Public Shared Function GetPatientSuperBill(ByVal pPatientSuperBillID As String) As PatientSuperBillDB
        Dim lUser As User
        Dim lPatientSuperBill As PatientSuperBill
        Dim lResult As Boolean
        Try
            lUser = CType(HttpContext.Current.Session("User"), User)
            lPatientSuperBill = New PatientSuperBill(lUser.ConnectionString)
            lPatientSuperBill.PatientSuperBill.PatientSuperBillID = pPatientSuperBillID
            lResult = lPatientSuperBill.GetRecordByID()
            If lResult Then
                Return lPatientSuperBill.PatientSuperBill
            Else
                Return Nothing
            End If
        Catch ex As Exception
            Return Nothing
        End Try
    End Function
    Public Shared Function GetPatientCPT(ByVal pPatientSuperBillID As String) As PatientCPTColl
        Dim lUser As User
        Dim lPatientCPT As PatientCPT
        Try
            lUser = CType(HttpContext.Current.Session("User"), User)
            lPatientCPT = New PatientCPT(lUser.ConnectionString)
            lPatientCPT.PatientCPT.PatientSuperBillId = pPatientSuperBillID
            Return lPatientCPT.GetPatientCPTCollection("")
        Catch ex As Exception
            Return New PatientCPTColl()
        End Try
    End Function
    Public Shared Function GetPatientICD(ByVal pPatientSuperBillID As String) As PatientICDColl
        Dim lUser As User
        Dim lPatientICD As PatientICD
        Try
            lUser = CType(HttpContext.Current.Session("User"), User)
            lPatientICD = New PatientICD(lUser.ConnectionString)
            lPatientICD.PatientICD.PatientSuperBillId = pPatientSuperBillID
            Return lPatientICD.GetPatientICDCollection("")
        Catch ex As Exception
            Return New PatientICDColl()
        End Try
    End Function
    Public Shared Function GetLastVisitDate(ByVal pPatientID As String) As String
        Dim lPatientSuperBill As PatientSuperBill
        Dim lUser As User
        Try
            lUser = CType(HttpContext.Current.Session("User"), User)
            lPatientSuperBill = New PatientSuperBill(lUser.ConnectionString)
            Return lPatientSuperBill.GetLastVisitDate(pPatientID)
        Catch ex As Exception
            Return ""
        End Try
    End Function

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="pPatientSuperBillDB"></param>
    ''' <param name="pPaymentHdr"></param>
    ''' <param name="pPageURL"></param>
    ''' <param name="pRenderringProviderNPI"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Function AddPatientSuperBillWithEncounter(ByRef pPatientSuperBillDB As PatientSuperBillDB, ByRef pPaymentHdr As PaymentHdrDB, ByVal pPageURL As String, ByVal pRenderringProviderNPI As String, ByVal pCPTList As String, ByVal pICDList As String) As Integer
        Dim lUser As User
        Dim lPaymentId As String = ""
        Dim lresult As Boolean
        Dim lConnection As Connection
        Dim lPatientSuperBillId As String
        Dim lPatientLedger As PatientLedger
        Dim lPatientLedgerDB As PatientLedgerDB
        Dim lErrorLog As New ErrorLog()
        Dim lEventLog As New EventLog()
        '  Dim lPatientCPT As PatientCPT
        '  Dim lPatientICD As PatientICD
        Try
            lUser = CType(HttpContext.Current.Session("User"), User)
            lConnection = New Connection(lUser.ConnectionString)
            Dim lPatientSuperBill As New PatientSuperBill(lConnection)
            Dim lpaymentHeader As New PaymentHdr(lConnection)
            lPatientLedger = New PatientLedger(lConnection)
            lPatientLedgerDB = New PatientLedgerDB()
            lConnection.BeginTrans()
            'lPatientCPT = New PatientCPT(lConnection)
            '    lPatientCPT.PatientCPT.NPI = pRenderringProviderNPI
            'lPatientICD = New PatientICD(lConnection)
            lPatientSuperBillId = lPatientSuperBill.GetUniqueId("")
            lPatientSuperBill.PatientSuperBill = pPatientSuperBillDB
            lPatientSuperBill.PatientSuperBill.PatientSuperBillID = lPatientSuperBillId
            lPatientSuperBill.InsertRecord()

            SavePatientCPT(pCPTList.Replace("PatientSuperBillId=""""", "PatientSuperBillId=""" & lPatientSuperBillId & """"), pPatientSuperBillDB.PatientSuperBillID, lConnection)
            SavePatientICD(pICDList.Replace("PatientSuperBillId=""""", "PatientSuperBillId=""" & lPatientSuperBillId & """"), pPatientSuperBillDB.PatientSuperBillID, lConnection)


            'saving copay in paymenrHDR
            If pPaymentHdr.Amount <> "" Then
                lpaymentHeader.PaymentHdr = pPaymentHdr
                lresult = lpaymentHeader.GetUniqueId()
                If Not lresult Then
                    Throw New Exception("Can't Get PaymentID")
                End If
                lpaymentHeader.InsertRecord()


                ''saving copay in patient ledger
                'With lPatientLedgerDB
                '    .ReferenceID = pPaymentHdr.PaymentID
                '    .ReferenceDate = pPaymentHdr.PaymentDate
                '    .ReferenceID2 = lPatientSuperBill.PatientSuperBill.PatientSuperBillID
                '    .ReferenceDate2 = lPatientSuperBill.PatientSuperBill.VisitDisplayDATE
                '    '.ReferenceDisplayID = pPaymentHdr.PaymentDispId
                '    .ReferenceDisplayID = CDate(pPaymentHdr.PaymentDate).Year.ToString().PadLeft(2, "0") & "-" & CDate(pPaymentHdr.PaymentDate).Month.ToString().PadLeft(2, "0") & "-00000"
                '    .ReferenceDisplayDate = pPaymentHdr.PaymentDispDate
                '    .ReferenceDisplayID2 = lPatientSuperBill.PatientSuperBill.PatientSuperBillDisplayID
                '    .TransactionType = "C"
                '    .PatientID = lPatientSuperBill.PatientSuperBill.PatientId
                '    .Reference = "Copay"
                '    .Date1 = Date.Now.Date
                '    .Description = "Patient Copay"
                '    .PayerName = lPatientSuperBill.PatientSuperBill.PatientName
                '    .PayerType = "P"
                '    .Debit = "0"
                '    .Credit = pPaymentHdr.Amount
                '    .Adjustment = "0"

                '    .ChequeNumber = "12345"
                '    .ChequeDate = "09/24/2010"
                'End With
                'lPatientLedger.PatientLedger = lPatientLedgerDB
                'lPatientLedger.InsertPatientLedger()


            End If
            '    SavePatientCPT(lPatientCPT, pPnlBillingInfo, lPatientSuperBillId)
            '    SavePatientICD(lPatientICD, pPnlBillingInfo, lPatientSuperBillId)
            lEventLog.EventLog.ClinicID = lUser.ClinicId
            lEventLog.EventLog.EventTypeID = 21 'EventType.GenerateSuperBill
            lEventLog.EventLog.ExtraID = lPatientSuperBillId
            lEventLog.EventLog.OCcurTime = Date.Now()
            lEventLog.EventLog.UserID = lUser.UserId
            lEventLog.EventLog.EventDescription = "A SuperBill of ID '" + lPatientSuperBillId.ToString() + "' is Generated of the clinic having ClinicID '" + lUser.ClinicId + "' on '" + lEventLog.EventLog.OCcurTime + "' by the loginID '" + lUser.LoginId + "'"
            lEventLog.HandleEvent()
            lEventLog.EventLog.ClinicID = lUser.ClinicId
            lEventLog.EventLog.EventTypeID = EventType.CreateEmployee
            lEventLog.EventLog.ExtraID = lpaymentHeader.PaymentHdr.PaymentID
            lEventLog.EventLog.OCcurTime = Date.Now()
            lEventLog.EventLog.UserID = lUser.UserId
            lEventLog.EventLog.EventDescription = "A Payment of ID '" + lpaymentHeader.PaymentHdr.PaymentID + "' is created of the clinic having ClinicID '" + lUser.ClinicId + "' on '" + lEventLog.EventLog.OCcurTime + "' by the loginID '" + lUser.LoginId + "'"
            lEventLog.HandleEvent()
            lConnection.CommitTrans()
        Catch ex As Exception
            lConnection.RollBackTrans()
            lErrorLog.HandleError(ex, lUser, pPageURL)
            Return 0
        End Try
        Return lPatientSuperBillId
    End Function

    Public Shared Function SavePatientCPT(ByVal pCPTList As String, ByVal pSuperBillID As String, ByRef pConnection As Connection)
        Dim lPatientCPT As PatientCPT

        Try
            lPatientCPT = New PatientCPT(pConnection)
            lPatientCPT.InsertPatientCPT(pCPTList)

            Return True

        Catch ex As Exception
            Return False

        End Try
    End Function

    Public Shared Function SavePatientICD(ByVal pICDList As String, ByVal pSuperBillID As String, ByRef pConnection As Connection)
        Dim lPatientICD As PatientICD

        Try
            lPatientICD = New PatientICD(pConnection)
            lPatientICD.InsertPatientICD(pICDList)

            Return True

        Catch ex As Exception
            Return False

        End Try
    End Function
End Class


