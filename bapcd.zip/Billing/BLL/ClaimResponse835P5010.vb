Imports Microsoft.VisualBasic
Imports System.Xml
Imports Response835P5010
Public Class ClaimResponse835P5010
    Public Shared Function ParseResponse(ByRef pResponsePaymentDetailColl As ResponsePaymentDetailColl, ByRef pClaimResponseDB As ClaimResponseDB, ByVal pMessageFilePath As String) As Boolean
        Dim lParser As New InputParser
        Dim lResponse835EDI As MsgInterchange
        ''Dim lMessageFilePath As String = "C:\ENS\ClaimResponse\835 X12_NOPAY_AND_STATE_SUB_ADJUST.txt"
        If (pMessageFilePath = "") Then
            pMessageFilePath = "C:\ENS\ClaimResponse\835_X12_EFT_AND_STATE_SUB_ADJUST.txt"
        End If
        '''''''''''''''''''Dim pMessageFilePath As String = "C:\ENS\ClaimResponse\835_X12_EFT_AND_STATE_SUB_ADJUST.txt"
        ''Dim lMessageFilePath As String = "C:\ENS\ClaimResponse\835_X12_NOPAY_AND_STATE_SUB_VOID.txt"
        ''Dim lMessageFilePath As String = "C:\ENS\ClaimResponse\835_X12_NOPAY_WITH_RETROS_IN_PER.txt"
        ''Dim lMessageFilePath As String = "C:\ENS\ClaimResponse\835_X12_WITH_PAYMT_AND_RETROS_IN_PER.txt"
        ''Dim lMessageFilePath As String = "C:\ENS\ClaimResponse\835AllianceHealthManual.txt"
        ''Dim lMessageFilePath As String = "C:\ENS\ClaimResponse\BuisnessScenario1.txt"
        Dim lResponseEDI As String = ReadFromFile(pMessageFilePath)
        If (lResponseEDI <> "") Then
            lResponse835EDI = lParser.Parse(lResponseEDI)

            With lResponse835EDI.ISA

            End With

            For i As Int32 = 0 To lResponse835EDI.FunctionalGroup.Count - 1
                Dim lFG As GrpInterchangeFunctionalGroup
                lFG = lResponse835EDI.FunctionalGroup.Item(i)
                Dim lTest As String
                With lFG.GS
                    lTest = .GroupControlNumber.Value
                End With

                For j As Int32 = 0 To lFG.transactions.Count - 1
                    Dim l835 As Msg835_x221
                    Dim lGeneric As IMessage
                    lGeneric = lFG.transactions.Item(j)
                    lTest = lGeneric.GetName
                    If (lTest = "835") Then
                        l835 = lGeneric

                        With l835.ST

                        End With

                        With l835.BPR
                            pClaimResponseDB.PaymentAmount = .MonetaryAmount.Value
                            pClaimResponseDB.ClaimDate = .Date.Value.Substring(4, 2) & "/" & .Date.Value.Substring(6, 2) & "/" & .Date.Value.Substring(0, 4)
                        End With

                        With l835.TRN

                        End With

                        With l835.CUR

                        End With

                        With l835.REF1

                        End With

                        With l835.REF2

                        End With

                        With l835.DTM

                        End With

                        With l835.L1000A_835 ''''' Payer Information
                            With .N1
                                pClaimResponseDB.PayerName = .EntityName.Value
                            End With

                            With .N3
                                pClaimResponseDB.PayerAddress = .AddressInformation.Value & " " & .AddressInformation2.Value
                            End With

                            With .N4
                                pClaimResponseDB.PayerCityStateZip = .CityName.Value & " " & .StateOrProvinceCode.Value & " " & .PostalCode.Value
                            End With

                            Dim lGrpREF As RepSegREF
                            lGrpREF = .REF
                            For Each lREF As SegREF In lGrpREF
                                With lREF

                                End With
                            Next

                            With .PER

                            End With
                        End With

                        With l835.L1000B_835 ''Payee Information
                            With .N1
                                pClaimResponseDB.PayeeName = .Name.Value
                                pClaimResponseDB.PayTo = .Name.Value
                            End With

                            With .N3
                                pClaimResponseDB.PayeeAddress = .AddressInformation.Value & " " & .AddressInformation2.Value
                            End With

                            With .N4
                                pClaimResponseDB.PayeeCityStateZip = .CityName.Value & " " & .StateOrProvinceCode.Value & " " & .PostalCode.Value
                            End With

                            Dim lGrpREF As RepSegREF
                            lGrpREF = .REF
                            For Each lREF As SegREF In lGrpREF
                                With lREF

                                End With
                            Next

                        End With

                        Dim lRepGrp2000 As RepGrp835_x221L2000_835 'Grp835L2000_835
                        lRepGrp2000 = l835.L2000_835
                        For Each lGrp2000 As Grp835_x221L2000_835 In lRepGrp2000
                            'For k As Int32 = 0 To lGrp2000.Count - 1
                            'lGrp2100 = lGrp2000.Item(k).L2100_835.Append
                            With lGrp2000.LX

                            End With

                            With lGrp2000.TS3

                            End With

                            With lGrp2000.TS2

                            End With

                            Dim lRepGrp2100 As RepGrp835_x221L2100_835
                            lRepGrp2100 = lGrp2000.L2100_835
                            For Each lGrp2100 As Grp835_x221L2100_835 In lRepGrp2100

                                Dim lPaymentDetail1 As New ResponsePaymentDetail
                                'Dim lPaymentDetailPR As New ResponsePaymentDetail
                                With lGrp2100.CLP
                                    pClaimResponseDB.PatientControlNumber = .ClaimSubmittersIdentifier.Value
                                    pClaimResponseDB.PayerControlNumber = .ReferenceIdentification.Value
                                    lPaymentDetail1.Amount = .MonetaryAmount.Value
                                    'If (.MonetaryAmount2 <> "0" And .MonetaryAmount2 <> "") Then
                                    '    lPaymentDetailPR.Item = "Patient Responsibility"
                                    '    lPaymentDetailPR.Amount = ".MonetaryAmount2"
                                    '    pResponsePaymentDetailColl.Add(lPaymentDetailPR)
                                    'End If
                                    lPaymentDetail1.Item = "Claim " & .ClaimSubmittersIdentifier.Value
                                    Select Case .ClaimStatusCode.Value
                                        Case "1"
                                            lPaymentDetail1.Item = lPaymentDetail1.Item & " (Processed as Primary)"
                                        Case "22"
                                            lPaymentDetail1.Item = lPaymentDetail1.Item & " (Reversal of Previous Payment)"
                                    End Select
                                    pResponsePaymentDetailColl.Add(lPaymentDetail1)
                                End With



                                Dim lGrpCAS As RepSegCAS
                                lGrpCAS = lGrp2100.CAS
                                For Each lCAS As SegCAS In lGrpCAS
                                    Dim lPaymentDetail2 As New ResponsePaymentDetail
                                    With lCAS
                                        If (.MonetaryAmount1.Value <> 0.0) Then
                                            lPaymentDetail2.Amount = .MonetaryAmount.Value
                                            Select Case .ClaimAdjustmentGroupCode.Value
                                                Case "CO"
                                                    lPaymentDetail2.Item = "Contractual Obligations"
                                                Case "CR"
                                                    lPaymentDetail2.Item = "Correction and Reversals"
                                                Case "OA"
                                                    lPaymentDetail2.Item = "Other adjustments"
                                                Case "PI"
                                                    lPaymentDetail2.Item = "Payor Initiated Reductions"
                                                Case "PR"
                                                    lPaymentDetail2.Item = "Patient Responsibility"

                                            End Select

                                            pResponsePaymentDetailColl.Add(lPaymentDetail2)
                                        End If
                                    End With

                                Next

                                With lGrp2100.NM11

                                End With

                                With lGrp2100.NM12

                                End With

                                With lGrp2100.NM13

                                End With

                                With lGrp2100.NM14

                                End With

                                With lGrp2100.NM15

                                End With

                                Dim lGrpNM1 As RepSegNM1
                                lGrpNM1 = lGrp2100.NM16
                                For Each lNM1 As SegNM1 In lGrpNM1
                                    With lNM1

                                    End With
                                Next

                                With lGrp2100.MIA

                                End With

                                With lGrp2100.MOA

                                End With

                                Dim lGrpREF12100 As RepSegREF
                                lGrpREF12100 = lGrp2100.REF1
                                For Each lREF As SegREF In lGrpREF12100
                                    With lREF

                                    End With
                                Next

                                Dim lGrpREF22100 As RepSegREF
                                lGrpREF22100 = lGrp2100.REF2
                                For Each lREF As SegREF In lGrpREF22100
                                    With lREF

                                    End With
                                Next

                                Dim lGrpDTM2100 As RepSegDTM
                                lGrpDTM2100 = lGrp2100.DTM
                                For Each lDTM As SegDTM In lGrpDTM2100
                                    With lDTM
                                        Select Case .DateTimeQualifier.Value
                                            Case "050"
                                                If (pResponsePaymentDetailColl.Count > 0) Then
                                                    pResponsePaymentDetailColl.Item(0).ItemDate = .Date.Value.Substring(4, 2) & "/" & .Date.Value.Substring(6, 2) & "/" & .Date.Value.Substring(0, 4)
                                                End If
                                            Case "232"
                                                If (pResponsePaymentDetailColl.Count > 1) Then
                                                    pResponsePaymentDetailColl.Item(1).ItemDate = .Date.Value.Substring(4, 2) & "/" & .Date.Value.Substring(6, 2) & "/" & .Date.Value.Substring(0, 4)
                                                End If

                                            Case "233"
                                        End Select
                                    End With
                                Next

                                Dim lGrpPER As RepSegPER
                                lGrpPER = lGrp2100.PER
                                For Each lPER As SegPER In lGrpPER
                                    With lPER

                                    End With
                                Next

                                Dim lGrpAMT2100 As RepSegAMT
                                lGrpAMT2100 = lGrp2100.AMT
                                For Each lAMT As SegAMT In lGrpAMT2100
                                    With lAMT

                                    End With
                                Next


                                Dim lGrpQTY2100 As RepSegQTY
                                lGrpQTY2100 = lGrp2100.QTY
                                For Each lQTY As SegQTY In lGrpQTY2100
                                    With lQTY

                                    End With
                                Next

                                Dim lRepGrp2110 As RepGrp835_x221L2110_835
                                lRepGrp2110 = lGrp2100.L2110_835

                                For Each lGrp2110 As Grp835_x221L2110_835 In lRepGrp2110
                                    Dim lPaymentDetail3 As New ResponsePaymentDetail
                                    'pResponsePaymentDetailColl.Add(lPaymentDetail1)

                                    With lGrp2110.SVC
                                        lPaymentDetail3.Amount = .MonetaryAmount1.Value
                                        lPaymentDetail3.Item = "Service :" & .CompositeMedicalProcedureIdentifier1.ProductServiceId.Value
                                    End With

                                    Dim lGrpDTM2110 As RepSegDTM
                                    lGrpDTM2110 = lGrp2110.DTM
                                    For Each lDTM As SegDTM In lGrpDTM2110
                                        With lDTM
                                            Select Case .DateTimeQualifier.Value
                                                Case "472"
                                                    lPaymentDetail3.ItemDate = .Date.Value.Substring(4, 2) & "/" & .Date.Value.Substring(6, 2) & "/" & .Date.Value.Substring(0, 4)
                                            End Select

                                        End With
                                    Next
                                    pResponsePaymentDetailColl.Add(lPaymentDetail3)

                                    Dim lGrpCAS2110 As RepSegCAS
                                    lGrpCAS2110 = lGrp2110.CAS
                                    For Each lCAS As SegCAS In lGrpCAS2110
                                        Dim lPaymentDetail4 As New ResponsePaymentDetail
                                        With lCAS
                                            lPaymentDetail4.Amount = "(" & .MonetaryAmount1.Value & ")"
                                            Select Case .ClaimAdjustmentGroupCode.Value
                                                Case "CO"
                                                    lPaymentDetail4.Item = "Contractual Obligations"
                                                Case "CR"
                                                    lPaymentDetail4.Item = "Correction and Reversals"
                                                Case "OA"
                                                    lPaymentDetail4.Item = "Other adjustments"
                                                Case "PI"
                                                    lPaymentDetail4.Item = "Payor Initiated Reductions"
                                                Case "PR"
                                                    lPaymentDetail4.Item = "Patient Responsibility"
                                            End Select
                                            lPaymentDetail4.ItemDate = lPaymentDetail3.ItemDate
                                            pResponsePaymentDetailColl.Add(lPaymentDetail4)
                                        End With
                                    Next

                                    Dim lGrpREF12110 As RepSegREF
                                    lGrpREF12110 = lGrp2110.REF1
                                    For Each lREF As SegREF In lGrpREF12110
                                        With lREF

                                        End With
                                    Next

                                    Dim lGrpREF22110 As RepSegREF
                                    lGrpREF22110 = lGrp2110.REF2
                                    For Each lREF As SegREF In lGrpREF22110
                                        With lREF

                                        End With
                                    Next


                                    Dim lGrpAMT2110 As RepSegAMT
                                    lGrpAMT2110 = lGrp2110.AMT
                                    For Each lAMT As SegAMT In lGrpAMT2110
                                        With lAMT

                                        End With
                                    Next

                                    Dim lGrpQTY2110 As RepSegQTY
                                    lGrpQTY2110 = lGrp2110.QTY
                                    For Each lQTY As SegQTY In lGrpQTY2110
                                        With lQTY

                                        End With
                                    Next

                                    Dim lGrpLQ As RepSegLQ
                                    lGrpLQ = lGrp2110.LQ
                                    For Each lLQ As SegLQ In lGrpLQ
                                        With lLQ

                                        End With
                                    Next

                                Next ''2110  

                            Next '' 2100
                            Exit For
                        Next '' 2000

                        Dim lGrpPLB As RepSegPLB
                        lGrpPLB = l835.PLB
                        For Each lPLB As SegPLB In lGrpPLB
                            With lPLB
                                '********************************'''''''''''''''
                            End With
                        Next '' PLB

                        With l835.SE
                            '********************************'''''''''''''''
                        End With
                    End If



                Next ''Transaction

            Next 'Functional Group
        End If
        Return True
    End Function
    
    
    Public Shared Function ReadFromFile(ByVal pPath As String) As String

        Dim lFileStream As FileStream = Nothing
        Dim lStreamReader As StreamReader = Nothing


        Try
            If Not File.Exists(pPath) Then
                Throw New Exception("File does not exist")
            End If


            lFileStream = New FileStream(pPath, FileMode.Open)
            lStreamReader = New StreamReader(lFileStream)

            Return lStreamReader.ReadToEnd().ToString

        Catch ex As Exception
            Return Nothing
        Finally
            lStreamReader.Close()
            lFileStream.Close()
        End Try
    End Function
    
    
    Public Shared Function GetVisitRecord(ByRef pConnection As Connection, ByVal pClaimId As String) As HCFADBUpdated
        Dim lHcfa As New HCFAUpdated(pConnection)
        Dim lStatus As Boolean
        Dim lCodition As String = "AND Cast(Year(HcfaPreparedDate) as Varchar) + '' + Right(REPLICATE('0', 2) + Cast(Month(HcfaPreparedDate) as varchar),2) + '' + Right(REPLICATE('0', 5) + Cast(HcfaUpdated.HcfaDisplayId As Varchar),5)='" + pClaimId + "'"
        lStatus = lHcfa.GetRecordByCondition(lCodition)
        If lStatus Then
            Return lHcfa.HCFAUpdated
        Else
            Return Nothing
        End If

    End Function
    Public Shared Function GetClinic(ByVal pClinicCode As String) As Connection
        Dim lLogin As New Login
        Dim lConnectionString As String = ""
        Dim lConnection As Connection

        Try

            lConnectionString = lLogin.GetConnectionString(pClinicCode)
            If lConnectionString.Equals("") Then
                Throw New Exception("Error Getting Clinic Information to Process Claim")
            Else
                lConnection = New Connection(lConnectionString)
            End If
        Catch ex As Exception
            Throw ex
        End Try
        Return lConnection
    End Function
    Public Shared Function SavePatientLedgerForPayment(ByVal pPaymentHdr As PaymentHdrDB, ByVal pSelectedItems As Hashtable) As Boolean
        Dim lUser As User
        Dim lConnection As Connection
        Dim lOrignalBalance As Double = 0.0
        Dim lBalance As Double = 0.0
        lUser = CType(HttpContext.Current.Session("User"), User)
        lConnection = New Connection(lUser.ConnectionString)
        Dim lPatientLedgerDB As PatientLedgerDB
        Dim lPatientLedger As New PatientLedger(lConnection)
        For Each lClaimHdr As ClaimHdrDB In pSelectedItems.Values
            For Each lClaimDtl As ClaimDtlDB In lClaimHdr.ClaimDtlColl
                lOrignalBalance = CType(IIf(lClaimDtl.OrignalBalance = "", 0, lClaimDtl.OrignalBalance), Double)
                lBalance = CType(IIf(lClaimDtl.Balance = "", 0, lClaimDtl.Balance), Double)
                If (lOrignalBalance <> lBalance) And (Not lClaimDtl.CPTCode.Equals("Total")) Then
                    lPatientLedgerDB = New PatientLedgerDB()
                End If
            Next
        Next
        Return True
    End Function
    Public Shared Function CreateLedgerXml(ByVal lXmlString As String) As XmlDocument
        Try
            Dim lStrCPTs As String = ""
            Dim lIntPaymentSum As Double = 0.0
            Dim lIntAdjustmentSum As Double = 0.0
            'Dim lXmlStr As String = "<PatientLedgers><PatientLedger ReferenceID=""PAYMENTID"" Reference=""99204"" PatientID=""6506"" ReferenceDate=""04/21/2010"" Date=""2010/04/10"" Description=""Payment by Claim Response 835"" Debit=""0"" Credit=""142.19"" Adjustment=""47.81"" TransactionType=""P"" ReferenceDate2=""4/6/2010"" PaymentMethod=""Check"" PayerName=""CIGNA"" PayerType=""I"" ReferenceDisplayID=""PAYMENTDISPLAYID"" ReferenceDisplayID2=""2010-04-00001"" ReferenceDisplayDate=""2010/04/13"" ReferenceID2=""72"" ChequeNumber=""229283047"" ChequeDate=""2010/04/10"" /><PatientLedger ReferenceID=""PAYMENTID"" Reference=""99214"" PatientID=""6506"" ReferenceDate=""04/21/2010"" Date=""2010/04/10"" Description=""Payment by Claim Response 835"" Debit=""0"" Credit=""142.19"" Adjustment=""47.81"" TransactionType=""P"" ReferenceDate2=""4/6/2010"" PaymentMethod=""Check"" PayerName=""CIGNA"" PayerType=""I"" ReferenceDisplayID=""PAYMENTDISPLAYID"" ReferenceDisplayID2=""2010-04-00001"" ReferenceDisplayDate=""2010/04/13"" ReferenceID2=""72"" ChequeNumber=""229283047"" ChequeDate=""2010/04/10"" /></PatientLedgers>"
            Dim lXmlElementLedger As XmlElement
            Dim lXmlDoc As New XmlDocument
            lXmlDoc.LoadXml(lXmlString)
            Dim lXmlDocumentLedger As New XmlDocument
            lXmlDocumentLedger.LoadXml("<PatientLedgers></PatientLedgers>")
            Dim lXmlNodeList As XmlNodeList = lXmlDoc.SelectNodes("PatientLedgers/PatientLedger")
            If (lXmlNodeList.Item(0).Attributes("PatientID").Value <> "") Then
                For Each lXmlNode As XmlNode In lXmlNodeList
                    lStrCPTs = lStrCPTs & "," & lXmlNode.Attributes("Reference").Value
                    lIntPaymentSum = lIntPaymentSum + lXmlNode.Attributes("Credit").Value
                    lIntAdjustmentSum = lIntAdjustmentSum + lXmlNode.Attributes("Adjustment").Value
                Next
                If (lStrCPTs.Substring(0, 1) = ",") Then
                    lStrCPTs = lStrCPTs.Remove(0, 1)
                End If
                'lXmlElementLedger = lXmlDocumentLedger.CreateElement("PatientLedger")
                Dim lXmlNodeLedger As XmlNode = lXmlNodeList.Item(0)
                'If credit or adjustment is zero
                If (lIntPaymentSum = "0" Or lIntAdjustmentSum = "0") Then
                    lXmlElementLedger = lXmlDocumentLedger.CreateElement("PatientLedger")
                    With lXmlElementLedger
                        .SetAttribute("ReferenceID", lXmlNodeLedger.Attributes("ReferenceID").Value)
                        .SetAttribute("Reference", lStrCPTs)
                        .SetAttribute("PatientID", lXmlNodeLedger.Attributes("PatientID").Value)
                        .SetAttribute("ReferenceDate", lXmlNodeLedger.Attributes("ReferenceDate").Value)
                        .SetAttribute("Date", lXmlNodeLedger.Attributes("Date").Value)
                        .SetAttribute("Description", lXmlNodeLedger.Attributes("Description").Value)
                        .SetAttribute("ReferenceDate2", lXmlNodeLedger.Attributes("ReferenceDate2").Value)
                        .SetAttribute("PaymentMethod", lXmlNodeLedger.Attributes("PaymentMethod").Value)
                        .SetAttribute("PayerName", lXmlNodeLedger.Attributes("PayerName").Value)
                        .SetAttribute("PayerType", lXmlNodeLedger.Attributes("PayerType").Value)
                        .SetAttribute("ReferenceDisplayID", lXmlNodeLedger.Attributes("ReferenceDisplayID").Value)
                        .SetAttribute("ReferenceDisplayID2", lXmlNodeLedger.Attributes("ReferenceDisplayID2").Value)
                        .SetAttribute("ReferenceDisplayDate", lXmlNodeLedger.Attributes("ReferenceDisplayDate").Value)
                        .SetAttribute("ReferenceID2", lXmlNodeLedger.Attributes("ReferenceID2").Value)
                        .SetAttribute("ChequeNumber", lXmlNodeLedger.Attributes("ChequeNumber").Value)
                        .SetAttribute("ChequeDate", lXmlNodeLedger.Attributes("ChequeDate").Value)
                        If (lIntPaymentSum <> "0") Then
                            .SetAttribute("Credit", lIntPaymentSum)
                            .SetAttribute("Debit", "0")
                            .SetAttribute("Adjustment", "0")
                            .SetAttribute("TransactionType", "P")
                        End If
                        If (lIntAdjustmentSum <> "0") Then
                            .SetAttribute("Adjustment", lIntAdjustmentSum)
                            .SetAttribute("Debit", "0")
                            .SetAttribute("Credit", "0")
                            .SetAttribute("TransactionType", "A")
                        End If
                    End With
                    lXmlDocumentLedger.DocumentElement.AppendChild(lXmlElementLedger.CloneNode(False))

                    '' two Ledger entry
                ElseIf (lIntPaymentSum <> "0" AndAlso lIntAdjustmentSum <> "0") Then
                    For lCount As Int16 = 0 To 1
                        lXmlElementLedger = lXmlDocumentLedger.CreateElement("PatientLedger")
                        With lXmlElementLedger
                            .SetAttribute("ReferenceID", lXmlNodeLedger.Attributes("ReferenceID").Value)
                            .SetAttribute("Reference", lStrCPTs)
                            .SetAttribute("PatientID", lXmlNodeLedger.Attributes("PatientID").Value)
                            .SetAttribute("ReferenceDate", lXmlNodeLedger.Attributes("ReferenceDate").Value)
                            .SetAttribute("Date", lXmlNodeLedger.Attributes("Date").Value)
                            .SetAttribute("Description", lXmlNodeLedger.Attributes("Description").Value)
                            .SetAttribute("ReferenceDate2", lXmlNodeLedger.Attributes("ReferenceDate2").Value)
                            .SetAttribute("PaymentMethod", lXmlNodeLedger.Attributes("PaymentMethod").Value)
                            .SetAttribute("PayerName", lXmlNodeLedger.Attributes("PayerName").Value)
                            .SetAttribute("PayerType", lXmlNodeLedger.Attributes("PayerType").Value)
                            .SetAttribute("ReferenceDisplayID", lXmlNodeLedger.Attributes("ReferenceDisplayID").Value)
                            .SetAttribute("ReferenceDisplayID2", lXmlNodeLedger.Attributes("ReferenceDisplayID2").Value)
                            .SetAttribute("ReferenceDisplayDate", lXmlNodeLedger.Attributes("ReferenceDisplayDate").Value)
                            .SetAttribute("ReferenceID2", lXmlNodeLedger.Attributes("ReferenceID2").Value)
                            .SetAttribute("ChequeNumber", lXmlNodeLedger.Attributes("ChequeNumber").Value)
                            .SetAttribute("ChequeDate", lXmlNodeLedger.Attributes("ChequeDate").Value)
                            If (lCount = 0) Then
                                If (lIntPaymentSum <> "0") Then
                                    .SetAttribute("Credit", lIntPaymentSum)
                                    .SetAttribute("Debit", "0")
                                    .SetAttribute("Adjustment", "0")
                                    .SetAttribute("TransactionType", "P")
                                End If
                            ElseIf (lCount = 1) Then
                                If (lIntAdjustmentSum <> "0") Then
                                    .SetAttribute("Adjustment", lIntAdjustmentSum)
                                    .SetAttribute("Debit", "0")
                                    .SetAttribute("Credit", "0")
                                    .SetAttribute("TransactionType", "A")
                                End If
                            End If
                        End With
                        lXmlDocumentLedger.DocumentElement.AppendChild(lXmlElementLedger.CloneNode(False))
                    Next
                End If

            End If

            Return lXmlDocumentLedger

        Catch ex As Exception

        End Try
    End Function
    Public Shared Function AddRemittanceHdrOnly(ByRef pRemittanceHdr As RemittanceHdrDB, ByVal pRemittanceClaimDtlXml As String, ByVal pRemittanceClaimServiceXml As String, ByRef pConnection As Connection) As Boolean
        If (pRemittanceClaimServiceXml = "" Or pRemittanceClaimDtlXml = "") Then
            Return False
        End If
        Dim lRemittanceHdr As New RemittanceHdr(pConnection)
        Dim lRemittanceClaimDtl As New RemittanceClaimDtl(pConnection)
        Dim lRemittanceClaimServiceDtl As New RemittanceClaimServiceDtl(pConnection)
        Dim lResult As Boolean
        Try
            pConnection.BeginTrans()
            lRemittanceHdr.RemittanceHdr = pRemittanceHdr
            lResult = lRemittanceHdr.GetUniqueId() 'THIS ADDS THE UNIQUE ID TO THE REMITTANCE HEADER
            lRemittanceHdr.RemittanceHdr.PaymentId = 0 'lPaymentHdr.PaymentHdr.PaymentID
            pRemittanceClaimDtlXml = pRemittanceClaimDtlXml.Replace("REMITTANCEID", lRemittanceHdr.RemittanceHdr.RemittanceId)
            pRemittanceClaimServiceXml = pRemittanceClaimServiceXml.Replace("REMITTANCEID", lRemittanceHdr.RemittanceHdr.RemittanceId)
            '' Remitance Entry
            lRemittanceHdr.InsertRecord()
            lRemittanceClaimDtl.InsertRecord(pRemittanceClaimDtlXml)
            lRemittanceClaimServiceDtl.InsertRecord(pRemittanceClaimServiceXml)
            pConnection.CommitTrans()
        Catch ex As Exception
            pConnection.RollBackTrans()
            Return False
        End Try
        Return True
    End Function
    Public Shared Function GetPaymentHeader5010(ByVal pMessage835 As Response835P5010.Msg835_x221, ByVal pUserId As String) As PaymentHdrDB
        Dim lPaymentHdr As PaymentHdrDB
        Try
            lPaymentHdr = New PaymentHdrDB
            With pMessage835.BPR
                lPaymentHdr.EntryDate = Date.Today
                lPaymentHdr.PayerType = "I"
                If (.PaymentMethodCode.Value = "CHK") Then
                    lPaymentHdr.PaymentMode = "Check"
                    lPaymentHdr.CheckDate = .Date.Value.Substring(0, 4) & "/" & .Date.Value.Substring(4, 2) & "/" & .Date.Value.Substring(6, 2)
                End If
                lPaymentHdr.CheckNumber = pMessage835.TRN.ReferenceIdentification.Value ' This field must be populated inorder to get payment id for reversal entry (ERA)
                lPaymentHdr.PaymentDate = IIf(lPaymentHdr.CheckDate <> "", lPaymentHdr.CheckDate, Date.Today)
                lPaymentHdr.Amount = .MonetaryAmount.Value
                lPaymentHdr.Description = "Payment Through Electronic Remittance Advice"
                lPaymentHdr.UserID = pUserId
                lPaymentHdr.PayerName = pMessage835.L1000A_835.N1.Name.Value
                lPaymentHdr.PayerID = pMessage835.L1000A_835.N1.IdentificationCode.Value 'Neet to check 
            End With
            Return lPaymentHdr
        Catch ex As Exception
            Return Nothing
        End Try
    End Function
    Public Shared Function GetPaymentDetail5010(ByVal pMessage835 As Response835P5010.Msg835_x221, ByRef pPaymentHdr As PaymentHdrDB, ByVal pUserId As String, ByVal pClinicConnection As Connection) As PaymentDtlCollection
        Dim lPaymentDtl As PaymentDtlDB
        Dim lPaymentDtlCollection As New PaymentDtlCollection
        Dim lHCFA As HCFADBUpdated
        Dim lReference As String = ""
        Dim lPatientSuperBill As PatientSuperBill
        Dim lResult As Boolean
        Dim lPaymentHdr As PaymentHdr
        Dim lPaymentId As Integer
        Dim lAdjustmentCollection As New AdjustmentCollection
        Dim lAdjustmentDB As AdjustmentDB
        Dim lClaimLevelAdjustmentCollection As New AdjustmentCollection
        Dim lAdjustment As Adjustment
        Dim CPTAdjustmentCollection As New AdjustmentCollection
        Try
            lPatientSuperBill = New PatientSuperBill(pClinicConnection)
            For Each lLX As Response835P5010.Grp835_x221L2000_835 In pMessage835.L2000_835 'LoopId 2000 - Header Number LX
                For Each lCLP As Response835P5010.Grp835_x221L2100_835 In lLX.L2100_835   'LoopId 2100 - Claim Payment Information CLP
                    If Not lCLP.CLP.ClaimSubmittersIdentifier.Value.ToUpper.Contains("CL") Then 'If Not Our Claim
                        Continue For
                    End If

                    '***********************************************************************
                    '********* Check Claim Status Code here. lCLP.CLP.ClaimStatusCode.Value
                    '***********************************************************************

                    lHCFA = GetVisitRecord(pClinicConnection, lCLP.CLP.ClaimSubmittersIdentifier.Value.Split("H")(1))
                    If lHCFA Is Nothing Then
                        Continue For
                    End If
                    lPatientSuperBill.PatientSuperBill.PatientSuperBillID = lHCFA.PatientSuperBillID
                    lResult = lPatientSuperBill.GetRecordByID()
                    If Not lResult Then
                        Continue For
                    End If
                    '=================
                    If Not lCLP.CLP.ClaimStatusCode.Value = "22" Then 'If Not the case of Reversal
                        '==========================
                        lPaymentDtl = New PaymentDtlDB
                        lPaymentDtl.PaymentID = pPaymentHdr.PaymentID
                        lPaymentDtl.VisitId = lHCFA.PatientSuperBillID
                        lPaymentDtl.TotalCharges = lCLP.CLP.MonetaryAmount.Value
                        lPaymentDtl.TotalAmount = lCLP.CLP.MonetaryAmount2.Value
                        lPaymentDtl.Amount = "0"
                        lPaymentDtl.EntryDate = Date.Today
                        lPaymentDtl.UserId = pUserId
                        ' Get PaymentDtlCpt collection
                        lPaymentDtl.PaymentCPTDetailCollection = GetPaymentCPTDetail5010(lCLP, lPaymentDtl.PaymentDtlID, lPaymentDtl.VisitId, pPaymentHdr.PaymentID, pUserId, pClinicConnection)
                        lPaymentDtl.AdjustmentCollection = GetAdjustment5010(lCLP.CAS, "", lPaymentDtl.VisitId, lPaymentDtl.PaymentDtlID, pPaymentHdr.PaymentID, pUserId, "0")
                        ''''''' Load Patient Ledger Object 
                        lPaymentDtl.PatientLedger = New PatientLedgerDB
                        With lPaymentDtl.PatientLedger
                            .ReferenceID = pPaymentHdr.PaymentID
                            .ReferenceDate = pPaymentHdr.PaymentDate
                            .ReferenceDisplayID = pPaymentHdr.DisplayID 'Populate it 
                            .ReferenceDisplayDate = pPaymentHdr.PaymentDate

                            .ReferenceID2 = lHCFA.PatientSuperBillID
                            .ReferenceDate2 = lPatientSuperBill.PatientSuperBill.VisitDisplayDATE
                            .ReferenceDisplayID2 = Year(CDate(.ReferenceDate2)) & "-" & Right("00" & Month(CDate(.ReferenceDate2)), 2) & "-" & Right("00000" & lPatientSuperBill.PatientSuperBill.PatientSuperBillDisplayID, 5)
                            .Adjustment = "0"
                            .ChequeDate = pPaymentHdr.CheckDate
                            .ChequeNumber = pPaymentHdr.CheckNumber
                            .Date1 = Date.Today
                            .Debit = "0"
                            .Credit = lPaymentDtl.TotalAmount
                            .Description = "Payment received from Insurance Company ( " & pPaymentHdr.PayerName & " )."
                            .PatientID = lPatientSuperBill.PatientSuperBill.PatientId
                            .PayerName = pPaymentHdr.PayerName
                            .PayerType = pPaymentHdr.PayerType
                            .PaymentMethod = pPaymentHdr.PaymentMode
                            .TransactionType = "P"

                            For Each lPaymentCPT As PaymentCPTDetailDB In lPaymentDtl.PaymentCPTDetailCollection
                                lReference = lReference & lPaymentCPT.CPTCode & ","
                            Next
                            .Reference = "CPT: " & Left(lReference, Len(lReference) - 1)

                        End With

                        ''''''' End Load Patient Ledger Object 

                        lPaymentDtlCollection.Add(lPaymentDtl)

                    Else

                        ''================ Reversal

                        lPaymentHdr = New PaymentHdr(pClinicConnection)
                        lPaymentHdr.PaymentHdr.PayerID = pMessage835.L1000A_835.N1.IdentificationCode.Value
                        lPaymentId = lPaymentHdr.GetPaymentId(lHCFA.PatientSuperBillID)
                        If lPaymentId = 0 Then  ' If this Payment is not present in our database then dont post reversal entry
                            Continue For
                        End If
                        For Each lServicePaymentInformation As Response835P5010.Grp835_x221L2110_835 In lCLP.L2110_835  'LoopId 2110 - Service Payment Information - Service Level Adjustments
                            CPTAdjustmentCollection = GetAdjustment5010(lServicePaymentInformation.CAS, lServicePaymentInformation.SVC.CompositeMedicalProcedureIdentifier1.ProductServiceId.Value, lHCFA.PatientSuperBillID, "0", lPaymentId, pUserId, "0") ' Get Collection 
                            For Each lAdjustmentItem As AdjustmentDB In CPTAdjustmentCollection
                                lAdjustmentCollection.Add(lAdjustmentItem)
                            Next
                        Next

                        For Each lServicePaymentInformation As Response835P5010.Grp835_x221L2110_835 In lCLP.L2110_835  'LoopId 2110 - Service Payment Information - Payments

                            lAdjustmentDB = New AdjustmentDB()

                            lAdjustmentDB.AdjustmentDate = Date.Today
                            lAdjustmentDB.PaymentDtlID = "0"
                            lAdjustmentDB.PaymentID = lPaymentId
                            lAdjustmentDB.VisitID = lHCFA.PatientSuperBillID
                            lAdjustmentDB.UserID = pUserId
                            lAdjustmentDB.ReasonCode = "" 'Need to be discussed
                            lAdjustmentDB.CPTCode = lServicePaymentInformation.SVC.CompositeMedicalProcedureIdentifier.ProductServiceId.Value
                            If lServicePaymentInformation.SVC.MonetaryAmount2.Value < 0 Then
                                lAdjustmentDB.AdjustmentType = "DR"
                                lAdjustmentDB.Amount = Math.Abs(lServicePaymentInformation.SVC.MonetaryAmount2.Value)
                            Else
                                lAdjustmentDB.AdjustmentType = "CR"
                                lAdjustmentDB.Amount = lServicePaymentInformation.SVC.MonetaryAmount2.Value
                            End If
                            lAdjustmentDB.AdjustmentDescription = "Reversal of Previous Payment "

                            lAdjustmentCollection.Add(lAdjustmentDB)


                        Next


                        For Each lCAS As SegCAS In lCLP.CAS 'Reversal Of Claim Level Adjustments
                            lClaimLevelAdjustmentCollection = GetAdjustment5010(lCLP.CAS, "", lHCFA.PatientSuperBillID, "0", lPaymentId, pUserId, "0") ' Get Collection 
                        Next


                        ''=========== End Reversal


                    End If ' End If Not the case of Reversal

                Next 'End LoopId 2100 - Claim Payment Information CLP

            Next 'End LoopId 2000 - Header Number LX


            '''''For Reversal 
            If lAdjustmentCollection.Count > 0 Or lClaimLevelAdjustmentCollection.Count > 0 Then
                pClinicConnection.BeginTrans()

                lAdjustment = New Adjustment(pClinicConnection)
                For Each lAdjustmentItem As AdjustmentDB In lAdjustmentCollection
                    lAdjustment.Adjustment = lAdjustmentItem
                    lAdjustment.InsertRecord()
                Next

                For Each lAdjustmentItem As AdjustmentDB In lClaimLevelAdjustmentCollection
                    lAdjustment.Adjustment = lAdjustmentItem
                    lAdjustment.InsertRecord()
                Next

                pClinicConnection.CommitTrans()
            End If

            '''''End For Reversal


            Return lPaymentDtlCollection
        Catch ex As Exception
            If pClinicConnection.IsTransactionAlive Then
                pClinicConnection.RollBackTrans()
            End If
            Throw
        End Try

    End Function
    Public Shared Function GetAdjustment5010(ByVal pAdjustment As Response835P5010.RepSegCAS, ByVal pCPT As String, ByVal pVisitID As String, ByVal pPaymentDtlId As String, ByVal pPaymentId As String, ByVal pUserId As String, ByVal pCptID As String) As AdjustmentCollection
        Dim lAdjustmentCollection As New AdjustmentCollection
        Dim lAdjustment As AdjustmentDB
        Dim lAdjustmentAmount As Double
        Dim lDescription As String = ""


        Try
            For Each lCAS As Response835P5010.SegCAS In pAdjustment
                '*******************************************************************************************
                '**************************Match Adjustment code and effect from AdjustmentEffectSheet here.
                '*******************************************************************************************
                If lCAS.ClaimAdjustmentGroupCode.Value = "CO" Or lCAS.ClaimAdjustmentGroupCode.Value = "OA" Or lCAS.ClaimAdjustmentGroupCode.Value = "PR" Then

                    lAdjustment = New AdjustmentDB
                    lAdjustment.AdjustmentDate = Date.Today
                    lAdjustment.PaymentDtlID = pPaymentDtlId
                    lAdjustment.PaymentID = pPaymentId
                    lAdjustment.VisitID = pVisitID
                    lAdjustment.UserID = pUserId
                    lAdjustment.ReasonCode = lCAS.ClaimAdjustmentReasonCode.Value   'lCAS.ClaimAdjustmentGroupCode.Value 'Need to be discussed
                    lAdjustment.CPTCode = pCPT
                    lAdjustment.IsPrevious = "No"
                    lAdjustment.CPTID = pCptID

                    If (lCAS.ClaimAdjustmentGroupCode.Value <> "CO") Or (lCAS.ClaimAdjustmentGroupCode.Value = "CO" And lCAS.ClaimAdjustmentReasonCode.Value <> "23") Then
                        If (lCAS.MonetaryAmount.Value <> 0.0) Then
                            lAdjustmentAmount = lAdjustmentAmount + lCAS.MonetaryAmount.Value
                        End If
                    End If

                    If (lCAS.ClaimAdjustmentGroupCode.Value <> "CO") Or (lCAS.ClaimAdjustmentGroupCode.Value = "CO" And lCAS.ClaimAdjustmentReasonCode2.Value <> "23") Then
                        If (lCAS.MonetaryAmount2.Value <> 0.0) Then
                            lAdjustmentAmount = lAdjustmentAmount + lCAS.MonetaryAmount2.Value
                        End If
                    End If
                    If (lCAS.ClaimAdjustmentGroupCode.Value <> "CO") Or (lCAS.ClaimAdjustmentGroupCode.Value = "CO" And lCAS.ClaimAdjustmentReasonCode3.Value <> "23") Then
                        If (lCAS.MonetaryAmount3.Value <> 0.0) Then
                            lAdjustmentAmount = lAdjustmentAmount + lCAS.MonetaryAmount3.Value
                        End If
                    End If
                    If (lCAS.ClaimAdjustmentGroupCode.Value <> "CO") Or (lCAS.ClaimAdjustmentGroupCode.Value = "CO" And lCAS.ClaimAdjustmentReasonCode4.Value <> "23") Then
                        If (lCAS.MonetaryAmount4.Value <> 0.0) Then
                            lAdjustmentAmount = lAdjustmentAmount + lCAS.MonetaryAmount4.Value
                        End If
                    End If
                    If (lCAS.ClaimAdjustmentGroupCode.Value <> "CO") Or (lCAS.ClaimAdjustmentGroupCode.Value = "CO" And lCAS.ClaimAdjustmentReasonCode5.Value <> "23") Then
                        If (lCAS.MonetaryAmount5.Value <> 0.0) Then
                            lAdjustmentAmount = lAdjustmentAmount + lCAS.MonetaryAmount5.Value
                        End If
                    End If

                    If (lCAS.ClaimAdjustmentGroupCode.Value <> "CO") Or (lCAS.ClaimAdjustmentGroupCode.Value = "CO" And lCAS.ClaimAdjustmentReasonCode6.Value <> "23") Then
                        If (lCAS.MonetaryAmount6.Value <> 0.0) Then
                            lAdjustmentAmount = lAdjustmentAmount + lCAS.MonetaryAmount6.Value
                        End If
                    End If

                    Select Case lCAS.ClaimAdjustmentGroupCode.Value
                        Case "CO"
                            lDescription = "Contractual Obligation-" & lCAS.ClaimAdjustmentGroupCode.Value & "-CR"
                        Case "OA"
                            lDescription = "Other Adjustments-" & lCAS.ClaimAdjustmentGroupCode.Value & "-CR"
                        Case "PR"
                            lDescription = "Patient Responsibility-" & lCAS.ClaimAdjustmentGroupCode.Value & "-NA"
                    End Select

                    lAdjustment.AdjustmentDescription = lDescription

                    If lAdjustmentAmount < 0 Then
                        lAdjustment.AdjustmentType = "DR"
                        lAdjustment.Amount = Math.Abs(lAdjustmentAmount)
                    Else
                        lAdjustment.AdjustmentType = "CR"
                        lAdjustment.Amount = lAdjustmentAmount
                    End If

                    If lCAS.ClaimAdjustmentGroupCode.Value = "PR" Then
                        lAdjustment.AdjustmentType = "NA"
                    End If

                    lAdjustmentCollection.Add(lAdjustment)
                    lAdjustmentAmount = 0

                End If

            Next

            Return lAdjustmentCollection

        Catch ex As Exception
            Throw
        End Try


    End Function
    Public Shared Function GetPaymentCPTDetail5010(ByVal pCLP As Response835P5010.Grp835_x221L2100_835, ByVal pPaymentDtlId As String, ByVal pVisitId As String, ByVal pPaymentId As String, ByVal pUserId As String, ByVal pClinicConnection As Connection) As PaymentCPTDetailCollection
        Dim lPaymentCPTDetailDB As PaymentCPTDetailDB
        Dim lPaymentCPTDetailCollection As New PaymentCPTDetailCollection
        Dim lAllowedAmount As Double
        Dim lCopay As Double
        Dim lDeductible As Double
        Dim lCptDOSFrom As String = ""
        Dim lCptDOSTo As String = ""
        Dim lModifierA As String = ""
        Dim lModifierB As String = ""
        Dim lModifierC As String = ""
        Dim lModifierD As String = ""
        Dim lCptId As String = 0
        Try
            For Each lServicePaymentInformation As Response835P5010.Grp835_x221L2110_835 In pCLP.L2110_835  'LoopId 2110 - Service Payment Information 
                lPaymentCPTDetailDB = New PaymentCPTDetailDB
                lPaymentCPTDetailDB.PaymentDtlID = pPaymentDtlId
                lPaymentCPTDetailDB.Amount = lServicePaymentInformation.SVC.MonetaryAmount2.Value
                lPaymentCPTDetailDB.Charges = lServicePaymentInformation.SVC.MonetaryAmount.Value
                lPaymentCPTDetailDB.CPTCode = lServicePaymentInformation.SVC.CompositeMedicalProcedureIdentifier.ProductServiceId.Value
                Dim lGrpDTM2110 As Response835P5010.RepSegDTM
                lGrpDTM2110 = lServicePaymentInformation.DTM
                If (lGrpDTM2110.Count > 0) Then
                    For Each lDTM As Response835P5010.SegDTM In lGrpDTM2110 '' Service DTM
                        With lDTM
                            Select Case .DateTimeQualifier.Value
                                Case "472"
                                    lCptDOSFrom = .Date.Value.Substring(4, 2) & "/" & .Date.Value.Substring(6, 2) & "/" & .Date.Value.Substring(0, 4)
                                    lCptDOSTo = .Date.Value.Substring(4, 2) & "/" & .Date.Value.Substring(6, 2) & "/" & .Date.Value.Substring(0, 4)
                                Case "150"
                                    lCptDOSFrom = .Date.Value.Substring(4, 2) & "/" & .Date.Value.Substring(6, 2) & "/" & .Date.Value.Substring(0, 4)
                                Case "151"
                                    lCptDOSTo = .Date.Value.Substring(4, 2) & "/" & .Date.Value.Substring(6, 2) & "/" & .Date.Value.Substring(0, 4)
                            End Select

                        End With
                    Next '' Service DTM                
                End If

                lModifierA = lServicePaymentInformation.SVC.CompositeMedicalProcedureIdentifier.ProcedureModifier.Value
                lModifierB = lServicePaymentInformation.SVC.CompositeMedicalProcedureIdentifier.ProcedureModifier2.Value
                lModifierC = lServicePaymentInformation.SVC.CompositeMedicalProcedureIdentifier.ProcedureModifier3.Value
                lModifierD = lServicePaymentInformation.SVC.CompositeMedicalProcedureIdentifier.ProcedureModifier4.Value

                lCptId = GetCptId(pVisitId, lPaymentCPTDetailDB.CPTCode, lCptDOSFrom, lCptDOSTo, lModifierA, lModifierB, lModifierC, lModifierD, pClinicConnection.ConnectionString)
                lPaymentCPTDetailDB.CPTId = lCptId
                '' Added by Fareed:22 feb 2011 for hospital visit work 

                For Each lAmt As Response835P5010.SegAMT In lServicePaymentInformation.AMT
                    If lAmt.AmountQualifierCode.Value = "B6" Then
                        lAllowedAmount = lAllowedAmount + lAmt.MonetaryAmount.Value
                    End If
                Next
                lPaymentCPTDetailDB.AllowedAmount = lAllowedAmount
                lAllowedAmount = 0

                For Each lCAS As Response835P5010.SegCAS In lServicePaymentInformation.CAS   'Calculating Copay and Deductible
                    If lCAS.ClaimAdjustmentGroupCode.Value = "PR" Then
                        If (lCAS.MonetaryAmount.Value <> 0.0) Then
                            If (lCAS.ClaimAdjustmentReasonCode.Value = "1") Then
                                lDeductible = lDeductible + Convert.ToDouble(lCAS.MonetaryAmount.Value)
                            ElseIf (lCAS.ClaimAdjustmentReasonCode.Value = "3") Then
                                lCopay = lCopay + Convert.ToDouble(lCAS.MonetaryAmount.Value)
                            End If
                        End If
                        If (lCAS.MonetaryAmount2.Value <> 0.0) Then
                            If (lCAS.ClaimAdjustmentReasonCode2.Value = "1") Then
                                lDeductible = lDeductible + Convert.ToDouble(lCAS.MonetaryAmount2.Value)
                            ElseIf (lCAS.ClaimAdjustmentReasonCode2.Value = "3") Then
                                lCopay = lCopay + Convert.ToDouble(lCAS.MonetaryAmount2.Value)
                            End If
                        End If
                        If (lCAS.MonetaryAmount3.Value <> 0.0) Then
                            If (lCAS.ClaimAdjustmentReasonCode3.Value = "1") Then
                                lDeductible = lDeductible + Convert.ToDouble(lCAS.MonetaryAmount3.Value)
                            ElseIf (lCAS.ClaimAdjustmentReasonCode3.Value = "3") Then
                                lCopay = lCopay + Convert.ToDouble(lCAS.MonetaryAmount3.Value)
                            End If
                        End If
                        If (lCAS.MonetaryAmount4.Value <> 0.0) Then
                            If (lCAS.ClaimAdjustmentReasonCode4.Value = "1") Then
                                lDeductible = lDeductible + Convert.ToDouble(lCAS.MonetaryAmount4.Value)
                            ElseIf (lCAS.ClaimAdjustmentReasonCode4.Value = "3") Then
                                lCopay = lCopay + Convert.ToDouble(lCAS.MonetaryAmount4.Value)
                            End If
                        End If
                        If (lCAS.MonetaryAmount5.Value <> 0.0) Then
                            If (lCAS.ClaimAdjustmentReasonCode5.Value = "1") Then
                                lDeductible = lDeductible + Convert.ToDouble(lCAS.MonetaryAmount5.Value)
                            ElseIf (lCAS.ClaimAdjustmentReasonCode5.Value = "3") Then
                                lCopay = lCopay + Convert.ToDouble(lCAS.MonetaryAmount5.Value)
                            End If
                        End If
                        If (lCAS.MonetaryAmount6.Value <> 0.0) Then
                            If (lCAS.ClaimAdjustmentReasonCode6.Value = "1") Then
                                lDeductible = lDeductible + Convert.ToDouble(lCAS.MonetaryAmount6.Value)
                            ElseIf (lCAS.ClaimAdjustmentReasonCode6.Value = "3") Then
                                lCopay = lCopay + Convert.ToDouble(lCAS.MonetaryAmount6.Value)
                            End If
                        End If

                    End If
                Next 'End Calculating Copay and Deductible

                lPaymentCPTDetailDB.Copay = lCopay
                lPaymentCPTDetailDB.Deductable = lDeductible
                lCopay = 0
                lDeductible = 0

                lPaymentCPTDetailDB.AdjustmentCollection = GetAdjustment5010(lServicePaymentInformation.CAS, lPaymentCPTDetailDB.CPTCode, pVisitId, lPaymentCPTDetailDB.PaymentDtlID, pPaymentId, pUserId, lCptId)

                lPaymentCPTDetailCollection.Add(lPaymentCPTDetailDB)

            Next 'LoopId 2110 - Service Payment Information SVC

            Return lPaymentCPTDetailCollection

        Catch ex As Exception
            Throw
        End Try

    End Function
    Public Shared Function PostPayment5010(ByVal pEdi835 As String, ByVal pUser As User, ByVal pIs5010 As Boolean) As Boolean

        Dim lParser As New Response835P5010.InputParser
        Dim lResponse835EDI As Response835P5010.MsgInterchange
        Dim lFunctionalGroup As Response835P5010.GrpInterchangeFunctionalGroup
        Dim lMessage835 As Response835P5010.Msg835_x221
        Dim lPaymentHdr As PaymentHdr
        Dim lPaymentDetailCollection As PaymentDtlCollection
        Dim lConnection As Connection
        Dim lPaymentDtl As PaymentDtl
        Dim lResult As Boolean
        Dim lRemittanceHdr As RemittanceHdr


        Try

            If (pEdi835.Trim = "") Then
                Return False
            End If
            lConnection = New Connection(pUser.ConnectionString)
            lPaymentHdr = New PaymentHdr(lConnection)
            lRemittanceHdr = New RemittanceHdr(lConnection)

            lResponse835EDI = lParser.Parse(pEdi835)

            For lFunctionalGroupCount As Int32 = 0 To lResponse835EDI.FunctionalGroup.Count - 1 ' Functional Group Loop 
                lFunctionalGroup = lResponse835EDI.FunctionalGroup.Item(lFunctionalGroupCount)

                For lTransactionSetCount As Int32 = 0 To lFunctionalGroup.Transactions.Count - 1  'Transaction Set Loop

                    If lFunctionalGroup.Transactions.Item(lTransactionSetCount).GetName = "835_x221" Then    ' If Transaction is 835

                        lMessage835 = lFunctionalGroup.Transactions.Item(lTransactionSetCount)

                        '*************************************************
                        '******* Handle PLB Segment here. lMessage835.PLB 
                        '*************************************************

                        lPaymentHdr.PaymentHdr = GetPaymentHeader5010(lMessage835, pUser.UserId)    ''''' Load Payment Header Object
                        If lPaymentHdr.PaymentHdr Is Nothing Then
                            Return False
                        End If
                        'lResult = lPaymentHdr.AlreadyPosted()
                        'If lResult Then
                        '    Return True
                        'End If

                        lConnection.BeginTrans()

                        lPaymentHdr.InsertPayment()
                        lRemittanceHdr.RemittanceHdr.PaymentId = lPaymentHdr.PaymentHdr.PaymentID
                        lRemittanceHdr.RemittanceHdr.ReassociationTraceNumber = lPaymentHdr.PaymentHdr.CheckNumber
                        lRemittanceHdr.SetPosted()

                        lConnection.CommitTrans()



                        lPaymentDetailCollection = GetPaymentDetail5010(lMessage835, lPaymentHdr.PaymentHdr, pUser.UserId, lConnection)
                        lPaymentDtl = New PaymentDtl(lConnection)

                        For Each lPaymentDtlDB As PaymentDtlDB In lPaymentDetailCollection
                            lPaymentDtl.PaymentDtl = lPaymentDtlDB
                            lPaymentDtl.InsertPayment()
                        Next



                    Else    ' If Transaction is not 835
                        Return False
                    End If ' End If Transaction is 835

                Next 'Transaction Set Loop Ends Here
            Next 'Functional Group Loop Ends Here


            Return True

        Catch ex As Exception
            If lConnection.IsTransactionAlive Then
                lConnection.RollBackTrans()
            End If
            Return False
        End Try

    End Function
    Public Shared Function GetCptId(ByVal pVisitId As String, ByVal pCptCode As String, ByVal pCptDosFrom As String, ByVal pCptDosTo As String, ByVal pModifierA As String, ByVal pModifierB As String, ByVal pModifierC As String, ByVal pModifierD As String, ByVal pConnectionString As String) As String
        Dim lCptId As String = 0
        Dim lQuery As String = ""
        Dim lConnection As Connection
        Try
            lQuery = "select * from Patientcpt " & _
                     "where PatientSuperBilliD=" & pVisitId & " " & _
                     "AND dateofServicefrom='" & pCptDosFrom & "' " & _
                     "AND dateofServiceTo='" & pCptDosTo & "' " & _
                     "AND Code='" & pCptCode & "' " & _
                     "AND ModifierA='" & pModifierA & "' " & _
                     "AND ModifierB='" & pModifierB & "' " & _
                     "AND ModifierC='" & pModifierC & "' " & _
                     "AND ModifierD='" & pModifierD & "' "
            lConnection = New Connection(pConnectionString)
            lCptId = lConnection.ExecuteQuery(lQuery).Tables(0).Rows(0).Item(0)
        Catch ex As Exception
            lCptId = 0
        End Try
        Return lCptId
    End Function
    Public Shared Function PostRemittance5010(ByRef pStrRemittanceClaimDtlXml As String, ByRef pStrRemittanceClaimServiceDtlXml As String, ByRef pRemittanceHdrDB As RemittanceHdrDB, ByVal pEdi835 As String, ByRef pClinicConnection As Connection) As Boolean
        Dim lClinicCode As String = ""
        Dim lHcfaDB As HCFADB = Nothing
        Dim lPatientSuperBill As PatientSuperBill = Nothing
        Dim lRemittanceClaimDtl As RemittanceClaimDtlDB = Nothing
        Dim lRemittanceClaimServiceDtl As RemittanceClaimServiceDtlDB = Nothing
        Dim lXmlDocument As New XmlDocument
        Dim lXmlDocumentLedger As New XmlDocument
        Dim lXmlElement As XmlElement
        Dim lXmlElementLedger As XmlElement
        Dim lXmlDocumentRemittanceClaim As New XmlDocument
        Dim lXmlDocumentRemittanceClaimService As New XmlDocument
        Dim lXmlElementRemittanceClaim As XmlElement = Nothing
        Dim lXmlElementRemittanceClaimService As XmlElement = Nothing

        Try
            lXmlDocumentRemittanceClaim.LoadXml("<RemittanceClaimDtls></RemittanceClaimDtls>")
            lXmlDocumentRemittanceClaimService.LoadXml("<RemittanceClaimServiceDtls></RemittanceClaimServiceDtls>")
            Dim lUser As User = CType(HttpContext.Current.Session("User"), User)
            Dim lParser As New Response835P5010.InputParser
            Dim lResponse835EDI As Response835P5010.MsgInterchange
            Dim lResponseEDI As String = pEdi835
            If (lResponseEDI <> "") Then
                lResponse835EDI = lParser.Parse(lResponseEDI)
                For i As Int32 = 0 To lResponse835EDI.FunctionalGroup.Count - 1
                    Dim lFG As Response835P5010.GrpInterchangeFunctionalGroup
                    lFG = lResponse835EDI.FunctionalGroup.Item(i)
                    Dim lTest As String
                    With lFG.GS
                        lTest = .GroupControlNumber.Value
                    End With
                    For j As Int32 = 0 To lFG.Transactions.Count - 1  ''''''' Transaction Start Header
                        Dim l835 As Response835P5010.Msg835_x221
                        Dim lGeneric As Response835P5010.IMessage
                        lGeneric = lFG.Transactions.Item(j)
                        lTest = lGeneric.GetName
                        If (lTest = "835_x221") Then
                            l835 = lGeneric

                            With l835.BPR
                                pRemittanceHdrDB.CheckAmount = .MonetaryAmount.Value
                                pRemittanceHdrDB.CheckDate = .Date.Value.Substring(0, 4) & "/" & .Date.Value.Substring(4, 2) & "/" & .Date.Value.Substring(6, 2)
                            End With

                            With l835.TRN
                                pRemittanceHdrDB.CheckNumber = .ReferenceIdentification.Value
                                pRemittanceHdrDB.ReassociationTraceNumber = .ReferenceIdentification.Value
                            End With

                            With l835.REF1
                                If (.ReferenceIdentificationQualifier.Value = "1C") Then
                                    pRemittanceHdrDB.ProviderReference = .ReferenceIdentification.Value
                                End If
                            End With

                            With l835.REF2
                                If (.ReferenceIdentificationQualifier.Value = "1C") Then
                                    pRemittanceHdrDB.ProviderReference = .ReferenceIdentification.Value
                                End If
                            End With

                            With l835.DTM
                                If (.DateTimeQualifier.Value = "405") Then
                                    pRemittanceHdrDB.ProductionDate = .Date.Value.Substring(0, 4) & "/" & .Date.Value.Substring(4, 2) & "/" & .Date.Value.Substring(6, 2)
                                End If

                            End With

                            With l835.L1000A_835 ''''' Payer Information
                                With .N1
                                    pRemittanceHdrDB.PayerName = .Name.Value
                                    pRemittanceHdrDB.AdditionalPayerIdentification = .IdentificationCode.Value
                                End With

                                With .N3
                                    pRemittanceHdrDB.PayerAddress = .AddressInformation.Value & " " & .AddressInformation2.Value
                                End With

                                With .N4
                                    pRemittanceHdrDB.PayerCity = .CityName.Value
                                    pRemittanceHdrDB.PayerState = .StateOrProvinceCode.Value
                                    pRemittanceHdrDB.PayerZip = .PostalCode.Value
                                End With

                                Dim lGrpREF As Response835P5010.RepSegREF
                                lGrpREF = .REF
                                For Each lREF As Response835P5010.SegREF In lGrpREF
                                    With lREF
                                        pRemittanceHdrDB.AdditionalPayerIdentification = .ReferenceIdentification.Value
                                    End With
                                Next  '' Payer Ref

                                With .PER1
                                    pRemittanceHdrDB.PayerContactName = .Name.Value
                                    pRemittanceHdrDB.PayerCommunicationNumberQualifier = .CommunicationNumberQualifier.Value
                                    pRemittanceHdrDB.PayerCommunicationNumber = .CommunicationNumber.Value
                                End With
                            End With

                            With l835.L1000B_835 ''Payee Information
                                With .N1
                                    pRemittanceHdrDB.PayeeName = .Name.Value
                                End With

                                With .N3
                                    pRemittanceHdrDB.PayeeAddress = .AddressInformation.Value & " " & .AddressInformation2.Value
                                End With

                                With .N4
                                    pRemittanceHdrDB.PayeeCity = .CityName.Value
                                    pRemittanceHdrDB.PayeeState = .StateOrProvinceCode.Value
                                    pRemittanceHdrDB.PayeeZip = .PostalCode.Value
                                End With

                                Dim lGrpREF As Response835P5010.RepSegREF
                                lGrpREF = .REF
                                For Each lREF As Response835P5010.SegREF In lGrpREF 'Payee ref
                                    With lREF
                                        Select Case .ReferenceIdentificationQualifier.Value
                                            Case "1C"
                                                pRemittanceHdrDB.ProviderReference = .ReferenceIdentification.Value
                                            Case Else
                                                pRemittanceHdrDB.AdditionalPayeeIdentification = .ReferenceIdentification.Value
                                        End Select
                                    End With
                                Next '' Payee ref
                            End With

                            Dim lRepGrp2000 As Response835P5010.RepGrp835_x221L2000_835 'Grp835L2000_835 '''''Header Loop
                            lRepGrp2000 = l835.L2000_835
                            For Each lGrp2000 As Response835P5010.Grp835_x221L2000_835 In lRepGrp2000 'Grp835L2000_835 '''''Header Loop
                                Dim lRepGrp2100 As Response835P5010.RepGrp835_x221L2100_835  ' Claim Payment Information
                                lRepGrp2100 = lGrp2000.L2100_835
                                For Each lGrp2100 As Response835P5010.Grp835_x221L2100_835 In lRepGrp2100 ' Loop2100 Claim Payment Information
                                    Dim lPatientSuperbillid As String = ""
                                    Dim lPaymentDetail1 As New ResponsePaymentDetail
                                    lRemittanceClaimDtl = New RemittanceClaimDtlDB
                                    Dim lClaimDateOfServiceFrom = ""
                                    Dim lClaimDateOfServiceTo = ""
                                    With lGrp2100.CLP
                                        pClinicConnection = GetClinic(lUser.ClinicId)
                                        pRemittanceHdrDB.IsPosted = "N"
                                        lRemittanceClaimDtl.RemittanceId = "REMITTANCEID"
                                        lRemittanceClaimDtl.RemittanceClaimId = .ClaimSubmittersIdentifier.Value
                                        lRemittanceClaimDtl.ReassociationTraceNumber = pRemittanceHdrDB.ReassociationTraceNumber
                                        lRemittanceClaimDtl.ClaimPaymentAmount = .MonetaryAmount2.Value
                                        lRemittanceClaimDtl.PatientResponsibility = .MonetaryAmount3.Value
                                        lRemittanceClaimDtl.PayerClaimControlOrIcnNumber = .ReferenceIdentification.Value
                                        Select Case .ClaimStatusCode.Value
                                            Case "1"
                                                lRemittanceClaimDtl.ClaimStatus = "Processed as Primary"
                                            Case "2"
                                                lRemittanceClaimDtl.ClaimStatus = "Processed as Secondary"
                                            Case "3"
                                                lRemittanceClaimDtl.ClaimStatus = "Processed as Tertiary"
                                            Case "4"
                                                lRemittanceClaimDtl.ClaimStatus = "Denied"
                                            Case "19"
                                                lRemittanceClaimDtl.ClaimStatus = "Processed as Primary Forwarded to additional Payer(s)"
                                            Case "20"
                                                lRemittanceClaimDtl.ClaimStatus = "Processed as Secondary Forwarded to additional Payer(s)"
                                            Case "21"
                                                lRemittanceClaimDtl.ClaimStatus = "Processed as Tertiory Forwarded to additional Payer(s)"
                                            Case "22"
                                                lRemittanceClaimDtl.ClaimStatus = "Reversal of Previous Payment"
                                            Case "23"
                                                lRemittanceClaimDtl.ClaimStatus = "Not our Claim Forwarded to additional Payer(s)"
                                                'Case "25"
                                                '    lRemittanceClaimDtl.ClaimStatus = "Predetermination Pricing Only - No Payment"
                                        End Select
                                    End With

                                    Dim lGrpCAS As Response835P5010.RepSegCAS
                                    lGrpCAS = lGrp2100.CAS
                                    Dim lClaimAdjustmentAmount As Double = 0.0
                                    Dim lClaimAdjustmentCodes As String = ""
                                    For Each lCAS As Response835P5010.SegCAS In lGrpCAS   ' Claim Level Adjustments
                                        Dim lPaymentDetail2 As New ResponsePaymentDetail
                                        With lCAS
                                            If (.MonetaryAmount.Value <> 0.0) Then
                                                lPaymentDetail2.Amount = .MonetaryAmount.Value
                                                Select Case .ClaimAdjustmentGroupCode.Value
                                                    Case "CO"
                                                        If (.MonetaryAmount.Value <> 0.0) Then
                                                            lClaimAdjustmentAmount = lClaimAdjustmentAmount + Convert.ToDouble(.MonetaryAmount.Value)
                                                            lClaimAdjustmentCodes = lClaimAdjustmentCodes & " " & "CO-" & .ClaimAdjustmentReasonCode.Value
                                                        End If
                                                        If (.MonetaryAmount2.Value <> 0.0) Then
                                                            lClaimAdjustmentAmount = lClaimAdjustmentAmount + Convert.ToDouble(.MonetaryAmount2.Value)
                                                            lClaimAdjustmentCodes = lClaimAdjustmentCodes & " " & "CO-" & .ClaimAdjustmentReasonCode2.Value
                                                        End If
                                                        If (.MonetaryAmount3.Value <> 0.0) Then
                                                            lClaimAdjustmentAmount = lClaimAdjustmentAmount + Convert.ToDouble(.MonetaryAmount3.Value)
                                                            lClaimAdjustmentCodes = lClaimAdjustmentCodes & " " & "CO-" & .ClaimAdjustmentReasonCode3.Value
                                                        End If
                                                        If (.MonetaryAmount4.Value <> 0.0) Then
                                                            lClaimAdjustmentAmount = lClaimAdjustmentAmount + Convert.ToDouble(.MonetaryAmount4.Value)
                                                            lClaimAdjustmentCodes = lClaimAdjustmentCodes & " " & "CO-" & .ClaimAdjustmentReasonCode4.Value
                                                        End If
                                                        If (.MonetaryAmount5.Value <> 0.0) Then
                                                            lClaimAdjustmentAmount = lClaimAdjustmentAmount + Convert.ToDouble(.MonetaryAmount5.Value)
                                                            lClaimAdjustmentCodes = lClaimAdjustmentCodes & " " & "CO-" & .ClaimAdjustmentReasonCode5.Value
                                                        End If
                                                        If (.MonetaryAmount6.Value <> 0.0) Then
                                                            lClaimAdjustmentAmount = lClaimAdjustmentAmount + Convert.ToDouble(.MonetaryAmount6.Value)
                                                            lClaimAdjustmentCodes = lClaimAdjustmentCodes & " " & "CO-" & .ClaimAdjustmentReasonCode6.Value
                                                        End If
                                                        lPaymentDetail2.Item = "Contractual Obligations"
                                                        'Case "CR"
                                                        '    If (.MonetaryAmount1.Value <> 0.0) Then
                                                        '        lClaimAdjustmentAmount = lClaimAdjustmentAmount + Convert.ToDouble(.MonetaryAmount1.Value)
                                                        '        lClaimAdjustmentCodes = lClaimAdjustmentCodes & " " & "CR-" & .ClaimAdjustmentReasonCode1.Value
                                                        '    End If
                                                        '    If (.MonetaryAmount2.Value <> 0.0) Then
                                                        '        lClaimAdjustmentAmount = lClaimAdjustmentAmount + Convert.ToDouble(.MonetaryAmount2.Value)
                                                        '        lClaimAdjustmentCodes = lClaimAdjustmentCodes & " " & "CR-" & .ClaimAdjustmentReasonCode2.Value
                                                        '    End If
                                                        '    If (.MonetaryAmount3.Value <> 0.0) Then
                                                        '        lClaimAdjustmentAmount = lClaimAdjustmentAmount + Convert.ToDouble(.MonetaryAmount3.Value)
                                                        '        lClaimAdjustmentCodes = lClaimAdjustmentCodes & " " & "CR-" & .ClaimAdjustmentReasonCode3.Value
                                                        '    End If
                                                        '    If (.MonetaryAmount4.Value <> 0.0) Then
                                                        '        lClaimAdjustmentAmount = lClaimAdjustmentAmount + Convert.ToDouble(.MonetaryAmount4.Value)
                                                        '        lClaimAdjustmentCodes = lClaimAdjustmentCodes & " " & "CR-" & .ClaimAdjustmentReasonCode4.Value
                                                        '    End If
                                                        '    If (.MonetaryAmount5.Value <> 0.0) Then
                                                        '        lClaimAdjustmentAmount = lClaimAdjustmentAmount + Convert.ToDouble(.MonetaryAmount5.Value)
                                                        '        lClaimAdjustmentCodes = lClaimAdjustmentCodes & " " & "CR-" & .ClaimAdjustmentReasonCode5.Value
                                                        '    End If
                                                        '    If (.MonetaryAmount6.Value <> 0.0) Then
                                                        '        lClaimAdjustmentAmount = lClaimAdjustmentAmount + Convert.ToDouble(.MonetaryAmount6)
                                                        '        lClaimAdjustmentCodes = lClaimAdjustmentCodes & " " & "CR-" & .ClaimAdjustmentReasonCode6.Value
                                                        '    End If
                                                        '    lPaymentDetail2.Item = "Correction and Reversals"
                                                    Case "OA"
                                                        If (.MonetaryAmount.Value <> 0.0) Then
                                                            lClaimAdjustmentAmount = lClaimAdjustmentAmount + Convert.ToDouble(.MonetaryAmount.Value)
                                                            lClaimAdjustmentCodes = lClaimAdjustmentCodes & " " & "OA-" & .ClaimAdjustmentReasonCode.Value
                                                        End If
                                                        If (.MonetaryAmount2.Value <> 0.0) Then
                                                            lClaimAdjustmentAmount = lClaimAdjustmentAmount + Convert.ToDouble(.MonetaryAmount2.Value)
                                                            lClaimAdjustmentCodes = lClaimAdjustmentCodes & " " & "OA-" & .ClaimAdjustmentReasonCode2.Value
                                                        End If
                                                        If (.MonetaryAmount3.Value <> 0.0) Then
                                                            lClaimAdjustmentAmount = lClaimAdjustmentAmount + Convert.ToDouble(.MonetaryAmount3.Value)
                                                            lClaimAdjustmentCodes = lClaimAdjustmentCodes & " " & "OA-" & .ClaimAdjustmentReasonCode3.Value
                                                        End If
                                                        If (.MonetaryAmount4.Value <> 0.0) Then
                                                            lClaimAdjustmentAmount = lClaimAdjustmentAmount + Convert.ToDouble(.MonetaryAmount4.Value)
                                                            lClaimAdjustmentCodes = lClaimAdjustmentCodes & " " & "OA-" & .ClaimAdjustmentReasonCode4.Value
                                                        End If
                                                        If (.MonetaryAmount5.Value <> 0.0) Then
                                                            lClaimAdjustmentAmount = lClaimAdjustmentAmount + Convert.ToDouble(.MonetaryAmount5.Value)
                                                            lClaimAdjustmentCodes = lClaimAdjustmentCodes & " " & "OA-" & .ClaimAdjustmentReasonCode5.Value
                                                        End If
                                                        If (.MonetaryAmount6.Value <> 0.0) Then
                                                            lClaimAdjustmentAmount = lClaimAdjustmentAmount + Convert.ToDouble(.MonetaryAmount6.Value)
                                                            lClaimAdjustmentCodes = lClaimAdjustmentCodes & " " & "OA-" & .ClaimAdjustmentReasonCode6.Value
                                                        End If
                                                        lPaymentDetail2.Item = "Other adjustments"
                                                    Case "PI"
                                                        If (.MonetaryAmount.Value <> 0.0) Then
                                                            lClaimAdjustmentAmount = lClaimAdjustmentAmount + Convert.ToDouble(.MonetaryAmount.Value)
                                                            lClaimAdjustmentCodes = lClaimAdjustmentCodes & " " & "PI-" & .ClaimAdjustmentReasonCode.Value
                                                        End If
                                                        If (.MonetaryAmount2.Value <> 0.0) Then
                                                            lClaimAdjustmentAmount = lClaimAdjustmentAmount + Convert.ToDouble(.MonetaryAmount2.Value)
                                                            lClaimAdjustmentCodes = lClaimAdjustmentCodes & " " & "PI-" & .ClaimAdjustmentReasonCode2.Value
                                                        End If
                                                        If (.MonetaryAmount3.Value <> 0.0) Then
                                                            lClaimAdjustmentAmount = lClaimAdjustmentAmount + Convert.ToDouble(.MonetaryAmount3.Value)
                                                            lClaimAdjustmentCodes = lClaimAdjustmentCodes & " " & "PI-" & .ClaimAdjustmentReasonCode3.Value
                                                        End If
                                                        If (.MonetaryAmount4.Value <> 0.0) Then
                                                            lClaimAdjustmentAmount = lClaimAdjustmentAmount + Convert.ToDouble(.MonetaryAmount4.Value)
                                                            lClaimAdjustmentCodes = lClaimAdjustmentCodes & " " & "PI-" & .ClaimAdjustmentReasonCode4.Value
                                                        End If
                                                        If (.MonetaryAmount5.Value <> 0.0) Then
                                                            lClaimAdjustmentAmount = lClaimAdjustmentAmount + Convert.ToDouble(.MonetaryAmount5.Value)
                                                            lClaimAdjustmentCodes = lClaimAdjustmentCodes & " " & "PI-" & .ClaimAdjustmentReasonCode5.Value
                                                        End If
                                                        If (.MonetaryAmount6.Value <> 0.0) Then
                                                            lClaimAdjustmentAmount = lClaimAdjustmentAmount + Convert.ToDouble(.MonetaryAmount6.Value)
                                                            lClaimAdjustmentCodes = lClaimAdjustmentCodes & " " & "PI-" & .ClaimAdjustmentReasonCode6.Value
                                                        End If
                                                        lPaymentDetail2.Item = "Payer Initiated Reductions"
                                                    Case "PR"
                                                        lPaymentDetail2.Item = "Patient Responsibility"
                                                End Select

                                                'pResponsePaymentDetailColl.Add(lPaymentDetail2)
                                            End If
                                        End With

                                    Next ' Claim Level Adjustments
                                    lRemittanceClaimDtl.ClaimAdjustmentAmount = lClaimAdjustmentAmount
                                    lRemittanceClaimDtl.ClaimAdjustmentCodes = lClaimAdjustmentCodes.Trim().Replace(" ", ",")

                                    With lGrp2100.NM11  '' Patient QC
                                        lRemittanceClaimDtl.PatientFirstName = .NameFirst.Value
                                        lRemittanceClaimDtl.PatientLastName = .NameLastOrOrganizationName.Value
                                        lRemittanceClaimDtl.PatientMiddleName = .NameMiddle.Value
                                        If (.IdentificationCodeQualifier.Value = "HN") Then
                                            lRemittanceClaimDtl.HicNumber = .IdentificationCode.Value
                                        End If
                                    End With

                                    With lGrp2100.NM12 '' Insured or Subscriber IL
                                        lRemittanceClaimDtl.InsuredFirstName = .NameFirst.Value
                                        lRemittanceClaimDtl.InsuredLastName = .NameLastOrOrganizationName.Value
                                        lRemittanceClaimDtl.InsuredMiddleName = .NameMiddle.Value
                                    End With

                                    With lGrp2100.NM13 '' CorrectedPatient/Insured Name 74
                                        lRemittanceClaimDtl.InsuredFirstName = .NameFirst.Value
                                        lRemittanceClaimDtl.InsuredLastName = .NameLastOrOrganizationName.Value
                                        lRemittanceClaimDtl.InsuredMiddleName = .NameMiddle.Value
                                    End With

                                    With lGrp2100.NM14  '' Service Provider 82
                                        lRemittanceClaimDtl.RenderingProviderFirstName = .NameFirst.Value
                                        lRemittanceClaimDtl.RenderingProviderLastName = .NameLastOrOrganizationName.Value
                                        lRemittanceClaimDtl.RenderingProviderMiddleName = .NameMiddle.Value
                                        If (.IdentificationCodeQualifier.Value = "XX") Then
                                            lRemittanceClaimDtl.RenderingProviderNpi = .IdentificationCode.Value
                                        End If

                                    End With

                                    With lGrp2100.NM15 '' CrossOver Carrier Name TT
                                        lRemittanceClaimDtl.ClaimForwardTo = .NameLastOrOrganizationName.Value
                                    End With

                                    'Dim lGrpNM1 As Response835P5010.RepSegNM1
                                    'lGrpNM1 = lGrp2100.NM16
                                    'For Each lNM1 As Response835P5010.SegNM1 In lGrpNM1
                                    '    With lNM1

                                    '    End With
                                    'Next

                                    'With lGrp2100.MIA

                                    'End With

                                    Dim lClaimRemarkCode As String = ""
                                    With lGrp2100.MOA
                                        If (.ReferenceIdentification.Value <> "") Then
                                            lRemittanceClaimDtl.ClaimRemarkCodes = .ReferenceIdentification.Value
                                        End If
                                        If (.ReferenceIdentification2.Value <> "") Then
                                            lRemittanceClaimDtl.ClaimRemarkCodes = lRemittanceClaimDtl.ClaimRemarkCodes & "," & .ReferenceIdentification2.Value
                                        End If
                                        If (.ReferenceIdentification3.Value <> "") Then
                                            lRemittanceClaimDtl.ClaimRemarkCodes = lRemittanceClaimDtl.ClaimRemarkCodes & "," & .ReferenceIdentification3.Value
                                        End If
                                        If (.ReferenceIdentification4.Value <> "") Then
                                            lRemittanceClaimDtl.ClaimRemarkCodes = lRemittanceClaimDtl.ClaimRemarkCodes & "," & .ReferenceIdentification4.Value
                                        End If
                                        If (.ReferenceIdentification5.Value <> "") Then
                                            lRemittanceClaimDtl.ClaimRemarkCodes = lRemittanceClaimDtl.ClaimRemarkCodes & "," & .ReferenceIdentification5.Value
                                        End If
                                        'lRemittanceClaimDtl.ClaimRemarkCodes = .ReferenceIdentification1.Value & "," & .ReferenceIdentification2.Value & "," & .ReferenceIdentification3.Value & "," & .ReferenceIdentification4.Value & "," & .ReferenceIdentification5.Value
                                    End With

                                    Dim lGrpREF12100 As Response835P5010.RepSegREF
                                    lGrpREF12100 = lGrp2100.REF1
                                    For Each lREF As Response835P5010.SegREF In lGrpREF12100
                                        With lREF

                                        End With
                                    Next

                                    Dim lGrpREF22100 As Response835P5010.RepSegREF
                                    lGrpREF22100 = lGrp2100.REF2
                                    For Each lREF As Response835P5010.SegREF In lGrpREF22100
                                        With lREF

                                        End With
                                    Next

                                    'Dim lGrpDTM2100 As Response835P5010.RepSegDTM '' Claim date
                                    'lGrpDTM2100 = lGrp2100.DTM
                                    'For Each lDTM As Response835P5010.SegDTM In lGrpDTM2100
                                    '    With lDTM
                                    '        Select Case .DateTimeQualifier.Value
                                    '            Case "050"
                                    '                lClaimDateOfServiceFrom = .Date.Value.Substring(4, 2) & "/" & .Date.Value.Substring(6, 2) & "/" & .Date.Value.Substring(0, 4)
                                    '                lClaimDateOfServiceTo = .Date.Value.Substring(4, 2) & "/" & .Date.Value.Substring(6, 2) & "/" & .Date.Value.Substring(0, 4)
                                    '            Case "232"
                                    '                lClaimDateOfServiceFrom = .Date.Value.Substring(4, 2) & "/" & .Date.Value.Substring(6, 2) & "/" & .Date.Value.Substring(0, 4)
                                    '            Case "233"
                                    '                lClaimDateOfServiceTo = .Date.Value.Substring(4, 2) & "/" & .Date.Value.Substring(6, 2) & "/" & .Date.Value.Substring(0, 4)
                                    '        End Select
                                    '    End With
                                    'Next '' Claim date

                                    Dim lGrpPER As Response835P5010.RepSegPER
                                    lGrpPER = lGrp2100.PER
                                    For Each lPER As Response835P5010.SegPER In lGrpPER '' Claim Contact PER
                                        With lPER
                                            lRemittanceClaimDtl.ClaimContactName = .Name.Value
                                            lRemittanceClaimDtl.ClaimCommunicationNumberQualifier = .CommunicationNumberQualifier.Value
                                            lRemittanceClaimDtl.ClaimCommunicationNumber = .CommunicationNumber.Value
                                            Exit For
                                        End With
                                    Next ''Claim Contact PER

                                    Dim lGrpAMT2100 As Response835P5010.RepSegAMT
                                    lGrpAMT2100 = lGrp2100.AMT
                                    For Each lAMT As Response835P5010.SegAMT In lGrpAMT2100
                                        With lAMT

                                        End With
                                    Next


                                    Dim lGrpQTY2100 As Response835P5010.RepSegQTY
                                    lGrpQTY2100 = lGrp2100.QTY
                                    For Each lQTY As Response835P5010.SegQTY In lGrpQTY2100 '' QTY
                                        With lQTY

                                        End With
                                    Next 'QTY

                                    Dim lRepGrp2110 As Response835P5010.RepGrp835_x221L2110_835
                                    lRepGrp2110 = lGrp2100.L2110_835

                                    For Each lGrp2110 As Response835P5010.Grp835_x221L2110_835 In lRepGrp2110  '' Loop 2100 SVC
                                        Dim lOtherAdjustments As Double = 0.0
                                        Dim lDeductible As Double = 0.0
                                        Dim lCoInsurance As Double = 0.0
                                        Dim lCoPay As Double = 0.0
                                        Dim lLateFiling As Double = 0.0
                                        Dim lServiceAdjutmentCodes As String = ""
                                        Dim lRemarkCodes As String = ""
                                        lRemittanceClaimServiceDtl = New RemittanceClaimServiceDtlDB

                                        With lGrp2110.SVC
                                            lRemittanceClaimServiceDtl.ChargedAmount = .MonetaryAmount.Value
                                            lRemittanceClaimServiceDtl.CptCode = .CompositeMedicalProcedureIdentifier.ProductServiceId.Value
                                            lRemittanceClaimServiceDtl.ProviderPaidAmount = .MonetaryAmount2.Value
                                            lRemittanceClaimServiceDtl.Unit = .Quantity.Value
                                            lRemittanceClaimServiceDtl.RemittanceClaimId = lRemittanceClaimDtl.RemittanceClaimId
                                            lRemittanceClaimServiceDtl.ModifierA = .CompositeMedicalProcedureIdentifier.ProcedureModifier.Value
                                            lRemittanceClaimServiceDtl.ModifierB = .CompositeMedicalProcedureIdentifier.ProcedureModifier2.Value
                                            lRemittanceClaimServiceDtl.ModifierC = .CompositeMedicalProcedureIdentifier.ProcedureModifier3.Value
                                            lRemittanceClaimServiceDtl.ModifierD = .CompositeMedicalProcedureIdentifier.ProcedureModifier4.Value
                                        End With

                                        Dim lGrpDTM2110 As Response835P5010.RepSegDTM
                                        lGrpDTM2110 = lGrp2110.DTM
                                        If (lGrpDTM2110.Count > 0) Then
                                            For Each lDTM As Response835P5010.SegDTM In lGrpDTM2110 '' Service DTM
                                                With lDTM
                                                    Select Case .DateTimeQualifier.Value
                                                        Case "472"
                                                            lRemittanceClaimServiceDtl.DateOfServiceFrom = .Date.Value.Substring(4, 2) & "/" & .Date.Value.Substring(6, 2) & "/" & .Date.Value.Substring(0, 4)
                                                            lRemittanceClaimServiceDtl.DateOfServiceTo = .Date.Value.Substring(4, 2) & "/" & .Date.Value.Substring(6, 2) & "/" & .Date.Value.Substring(0, 4)
                                                            'Case "150"
                                                            '    lRemittanceClaimServiceDtl.DateOfServiceFrom = .Date.Value.Substring(4, 2) & "/" & .Date.Value.Substring(6, 2) & "/" & .Date.Value.Substring(0, 4)
                                                            'Case "151"
                                                            '    lRemittanceClaimServiceDtl.DateOfServiceTo = .Date.Value.Substring(4, 2) & "/" & .Date.Value.Substring(6, 2) & "/" & .Date.Value.Substring(0, 4)
                                                    End Select

                                                End With
                                            Next '' Service DTM
                                        Else
                                            lRemittanceClaimServiceDtl.DateOfServiceFrom = lClaimDateOfServiceFrom
                                            lRemittanceClaimServiceDtl.DateOfServiceTo = lClaimDateOfServiceFrom
                                        End If


                                        Dim lGrpCAS2110 As Response835P5010.RepSegCAS
                                        lGrpCAS2110 = lGrp2110.CAS
                                        For Each lCAS As Response835P5010.SegCAS In lGrpCAS2110 '' Service Adjustments

                                            With lCAS

                                                Select Case .ClaimAdjustmentGroupCode.Value
                                                    Case "CO"
                                                        If (.MonetaryAmount.Value <> 0.0) Then
                                                            lOtherAdjustments = lOtherAdjustments + Convert.ToDouble(.MonetaryAmount.Value)
                                                            'lServiceAdjutmentCodes = ""
                                                            lServiceAdjutmentCodes = lServiceAdjutmentCodes & " " & "CO-" & .ClaimAdjustmentReasonCode.Value
                                                        End If
                                                        If (.MonetaryAmount2.Value <> 0.0) Then
                                                            lOtherAdjustments = lOtherAdjustments + Convert.ToDouble(.MonetaryAmount2.Value)
                                                            lServiceAdjutmentCodes = lServiceAdjutmentCodes & " " & "CO-" & .ClaimAdjustmentReasonCode2.Value
                                                        End If
                                                        If (.MonetaryAmount3.Value <> 0.0) Then
                                                            lOtherAdjustments = lOtherAdjustments + Convert.ToDouble(.MonetaryAmount3.Value)
                                                            lServiceAdjutmentCodes = lServiceAdjutmentCodes & " " & "CO-" & .ClaimAdjustmentReasonCode3.Value
                                                        End If
                                                        If (.MonetaryAmount4.Value <> 0.0) Then
                                                            lOtherAdjustments = lOtherAdjustments + Convert.ToDouble(.MonetaryAmount4.Value)
                                                            lServiceAdjutmentCodes = lServiceAdjutmentCodes & " " & "CO-" & .ClaimAdjustmentReasonCode4.Value
                                                        End If
                                                        If (.MonetaryAmount5.Value <> 0.0) Then
                                                            lOtherAdjustments = lOtherAdjustments + Convert.ToDouble(.MonetaryAmount5.Value)
                                                            lServiceAdjutmentCodes = lServiceAdjutmentCodes & " " & "CO-" & .ClaimAdjustmentReasonCode5.Value
                                                        End If
                                                        If (.MonetaryAmount6.Value <> 0.0) Then
                                                            lOtherAdjustments = lOtherAdjustments + Convert.ToDouble(.MonetaryAmount6.Value)
                                                            lServiceAdjutmentCodes = lServiceAdjutmentCodes & " " & "CO-" & .ClaimAdjustmentReasonCode6.Value
                                                        End If
                                                        'Case "CR"
                                                        '    If (.MonetaryAmount1.Value <> 0.0) Then
                                                        '        lOtherAdjustments = lOtherAdjustments + Convert.ToDouble(.MonetaryAmount1.Value)
                                                        '        lServiceAdjutmentCodes = lServiceAdjutmentCodes & " " & "CR-" & .ClaimAdjustmentReasonCode1.Value
                                                        '    End If
                                                        '    If (.MonetaryAmount2.Value <> 0.0) Then
                                                        '        lOtherAdjustments = lOtherAdjustments + Convert.ToDouble(.MonetaryAmount2.Value)
                                                        '        lServiceAdjutmentCodes = lServiceAdjutmentCodes & " " & "CR-" & .ClaimAdjustmentReasonCode2.Value
                                                        '    End If
                                                        '    If (.MonetaryAmount3.Value <> 0.0) Then
                                                        '        lOtherAdjustments = lOtherAdjustments + Convert.ToDouble(.MonetaryAmount3.Value)
                                                        '        lServiceAdjutmentCodes = lServiceAdjutmentCodes & " " & "CR-" & .ClaimAdjustmentReasonCode3.Value
                                                        '    End If
                                                        '    If (.MonetaryAmount4.Value <> 0.0) Then
                                                        '        lOtherAdjustments = lOtherAdjustments + Convert.ToDouble(.MonetaryAmount4.Value)
                                                        '        lServiceAdjutmentCodes = lServiceAdjutmentCodes & " " & "CR-" & .ClaimAdjustmentReasonCode4.Value
                                                        '    End If
                                                        '    If (.MonetaryAmount5.Value <> 0.0) Then
                                                        '        lOtherAdjustments = lOtherAdjustments + Convert.ToDouble(.MonetaryAmount5.Value)
                                                        '        lServiceAdjutmentCodes = lServiceAdjutmentCodes & " " & "CR-" & .ClaimAdjustmentReasonCode5.Value
                                                        '    End If
                                                        '    If (.MonetaryAmount6.Value <> 0.0) Then
                                                        '        lOtherAdjustments = lOtherAdjustments + Convert.ToDouble(.MonetaryAmount6.Value)
                                                        '        lServiceAdjutmentCodes = lServiceAdjutmentCodes & " " & "CR-" & .ClaimAdjustmentReasonCode6.Value
                                                        '    End If
                                                    Case "OA"
                                                        If (.MonetaryAmount.Value <> 0.0) Then
                                                            lOtherAdjustments = lClaimAdjustmentAmount + Convert.ToDouble(.MonetaryAmount.Value)
                                                            lServiceAdjutmentCodes = lServiceAdjutmentCodes & " " & "OA-" & .ClaimAdjustmentReasonCode.Value
                                                        End If
                                                        If (.MonetaryAmount2.Value <> 0.0) Then
                                                            lOtherAdjustments = lClaimAdjustmentAmount + Convert.ToDouble(.MonetaryAmount2.Value)
                                                            lServiceAdjutmentCodes = lServiceAdjutmentCodes & " " & "OA-" & .ClaimAdjustmentReasonCode2.Value
                                                        End If
                                                        If (.MonetaryAmount3.Value <> 0.0) Then
                                                            lOtherAdjustments = lOtherAdjustments + Convert.ToDouble(.MonetaryAmount3.Value)
                                                            lServiceAdjutmentCodes = lServiceAdjutmentCodes & " " & "OA-" & .ClaimAdjustmentReasonCode3.Value
                                                        End If
                                                        If (.MonetaryAmount4.Value <> 0.0) Then
                                                            lOtherAdjustments = lOtherAdjustments + Convert.ToDouble(.MonetaryAmount4.Value)
                                                            lServiceAdjutmentCodes = lServiceAdjutmentCodes & " " & "OA-" & .ClaimAdjustmentReasonCode4.Value
                                                        End If
                                                        If (.MonetaryAmount5.Value <> 0.0) Then
                                                            lOtherAdjustments = lOtherAdjustments + Convert.ToDouble(.MonetaryAmount5.Value)
                                                            lServiceAdjutmentCodes = lServiceAdjutmentCodes & " " & "OA-" & .ClaimAdjustmentReasonCode5.Value
                                                        End If
                                                        If (.MonetaryAmount6.Value <> 0.0) Then
                                                            lOtherAdjustments = lOtherAdjustments + Convert.ToDouble(.MonetaryAmount6.Value)
                                                            lServiceAdjutmentCodes = lServiceAdjutmentCodes & " " & "OA-" & .ClaimAdjustmentReasonCode6.Value
                                                        End If
                                                    Case "PI"
                                                        If (.MonetaryAmount.Value <> 0.0) Then
                                                            lOtherAdjustments = lOtherAdjustments + Convert.ToDouble(.MonetaryAmount.Value)
                                                            lServiceAdjutmentCodes = lServiceAdjutmentCodes & " " & "PI-" & .ClaimAdjustmentReasonCode.Value
                                                        End If
                                                        If (.MonetaryAmount2.Value <> 0.0) Then
                                                            lOtherAdjustments = lOtherAdjustments + Convert.ToDouble(.MonetaryAmount2.Value)
                                                            lServiceAdjutmentCodes = lServiceAdjutmentCodes & " " & "PI-" & .ClaimAdjustmentReasonCode2.Value
                                                        End If
                                                        If (.MonetaryAmount3.Value <> 0.0) Then
                                                            lOtherAdjustments = lOtherAdjustments + Convert.ToDouble(.MonetaryAmount3.Value)
                                                            lServiceAdjutmentCodes = lServiceAdjutmentCodes & " " & "PI-" & .ClaimAdjustmentReasonCode3.Value
                                                        End If
                                                        If (.MonetaryAmount4.Value <> 0.0) Then
                                                            lOtherAdjustments = lOtherAdjustments + Convert.ToDouble(.MonetaryAmount4.Value)
                                                            lServiceAdjutmentCodes = lServiceAdjutmentCodes & " " & "PI-" & .ClaimAdjustmentReasonCode4.Value
                                                        End If
                                                        If (.MonetaryAmount5.Value <> 0.0) Then
                                                            lOtherAdjustments = lOtherAdjustments + Convert.ToDouble(.MonetaryAmount5.Value)
                                                            lServiceAdjutmentCodes = lServiceAdjutmentCodes & " " & "PI-" & .ClaimAdjustmentReasonCode5.Value
                                                        End If
                                                        If (.MonetaryAmount6.Value <> 0.0) Then
                                                            lOtherAdjustments = lOtherAdjustments + Convert.ToDouble(.MonetaryAmount6.Value)
                                                            lServiceAdjutmentCodes = lServiceAdjutmentCodes & " " & "PI-" & .ClaimAdjustmentReasonCode6.Value
                                                        End If
                                                    Case "PR"
                                                        If (.MonetaryAmount.Value <> 0.0) Then
                                                            If (.ClaimAdjustmentReasonCode.Value = "1") Then
                                                                lDeductible = lDeductible + Convert.ToDouble(.MonetaryAmount.Value)
                                                            ElseIf (.ClaimAdjustmentReasonCode.Value = "2") Then
                                                                lCoInsurance = lCoInsurance + Convert.ToDouble(.MonetaryAmount.Value)
                                                            ElseIf (.ClaimAdjustmentReasonCode.Value = "3") Then
                                                                lCoPay = lCoPay + Convert.ToDouble(.MonetaryAmount.Value)
                                                            End If
                                                        End If
                                                        If (.MonetaryAmount2.Value <> 0.0) Then
                                                            If (.ClaimAdjustmentReasonCode2.Value = "1") Then
                                                                lDeductible = lDeductible + Convert.ToDouble(.MonetaryAmount2.Value)
                                                            ElseIf (.ClaimAdjustmentReasonCode2.Value = "2") Then
                                                                lCoInsurance = lCoInsurance + Convert.ToDouble(.MonetaryAmount2.Value)
                                                            ElseIf (.ClaimAdjustmentReasonCode2.Value = "3") Then
                                                                lCoPay = lCoPay + Convert.ToDouble(.MonetaryAmount2.Value)
                                                            End If
                                                        End If
                                                        If (.MonetaryAmount3.Value <> 0.0) Then
                                                            If (.ClaimAdjustmentReasonCode3.Value = "1") Then
                                                                lDeductible = lClaimAdjustmentAmount + Convert.ToDouble(.MonetaryAmount3.Value)
                                                            ElseIf (.ClaimAdjustmentReasonCode3.Value = "2") Then
                                                                lCoInsurance = lCoInsurance + Convert.ToDouble(.MonetaryAmount3.Value)
                                                            ElseIf (.ClaimAdjustmentReasonCode3.Value = "3") Then
                                                                lCoPay = lCoPay + Convert.ToDouble(.MonetaryAmount3.Value)
                                                            End If
                                                        End If
                                                        If (.MonetaryAmount4.Value <> 0.0) Then
                                                            If (.ClaimAdjustmentReasonCode4.Value = "1") Then
                                                                lDeductible = lDeductible + Convert.ToDouble(.MonetaryAmount4.Value)
                                                            ElseIf (.ClaimAdjustmentReasonCode4.Value = "2") Then
                                                                lCoInsurance = lCoInsurance + Convert.ToDouble(.MonetaryAmount4.Value)
                                                            ElseIf (.ClaimAdjustmentReasonCode4.Value = "3") Then
                                                                lCoPay = lCoPay + Convert.ToDouble(.MonetaryAmount4.Value)
                                                            End If
                                                        End If
                                                        If (.MonetaryAmount5.Value <> 0.0) Then
                                                            If (.ClaimAdjustmentReasonCode5.Value = "1") Then
                                                                lDeductible = lDeductible + Convert.ToDouble(.MonetaryAmount5.Value)
                                                            ElseIf (.ClaimAdjustmentReasonCode5.Value = "2") Then
                                                                lCoInsurance = lCoInsurance + Convert.ToDouble(.MonetaryAmount5.Value)
                                                            ElseIf (.ClaimAdjustmentReasonCode5.Value = "3") Then
                                                                lCoPay = lCoPay + Convert.ToDouble(.MonetaryAmount5.Value)
                                                            End If
                                                        End If
                                                        If (.MonetaryAmount6.Value <> 0.0) Then
                                                            If (.ClaimAdjustmentReasonCode6.Value = "1") Then
                                                                lDeductible = lDeductible + Convert.ToDouble(.MonetaryAmount6.Value)
                                                            ElseIf (.ClaimAdjustmentReasonCode6.Value = "2") Then
                                                                lCoInsurance = lCoInsurance + Convert.ToDouble(.MonetaryAmount6.Value)
                                                            ElseIf (.ClaimAdjustmentReasonCode6.Value = "3") Then
                                                                lCoPay = lCoPay + Convert.ToDouble(.MonetaryAmount6.Value)
                                                            End If
                                                        End If
                                                End Select

                                            End With
                                        Next '' Service Adjustments


                                        lRemittanceClaimServiceDtl.DeductibleAmount = lDeductible
                                        lRemittanceClaimServiceDtl.CoPayAmount = lCoPay
                                        lRemittanceClaimServiceDtl.CoInsuranceAmount = lCoInsurance
                                        lRemittanceClaimServiceDtl.OtherAdjustmentAmount = lOtherAdjustments
                                        lRemittanceClaimServiceDtl.ServiceAdjustmentCodes = lServiceAdjutmentCodes.Trim().Replace(" ", ",")
                                        lRemittanceClaimServiceDtl.RemarkCodes = lRemarkCodes


                                        'Dim lGrpREF12110 As Response835P5010.RepSegREF
                                        'lGrpREF12110 = lGrp2110.REF1
                                        'For Each lREF As Response835P5010.SegREF In lGrpREF12110
                                        '    With lREF

                                        '    End With
                                        'Next

                                        'Dim lGrpREF22110 As Response835P5010.RepSegREF
                                        'lGrpREF22110 = lGrp2110.REF2
                                        'For Each lREF As Response835P5010.SegREF In lGrpREF22110
                                        '    With lREF

                                        '    End With
                                        'Next


                                        Dim lGrpAMT2110 As Response835P5010.RepSegAMT
                                        lGrpAMT2110 = lGrp2110.AMT
                                        For Each lAMT As Response835P5010.SegAMT In lGrpAMT2110
                                            With lAMT
                                                Select Case .AmountQualifierCode.Value
                                                    Case "B6"
                                                        lRemittanceClaimServiceDtl.AllowedAmount = .MonetaryAmount.Value
                                                    Case "KH"
                                                        lRemittanceClaimServiceDtl.LateFillingRedAmount = .MonetaryAmount.Value
                                                End Select

                                            End With
                                        Next

                                        'Dim lGrpQTY2110 As Response835P5010.RepSegQTY
                                        'lGrpQTY2110 = lGrp2110.QTY
                                        'For Each lQTY As Response835P5010.SegQTY In lGrpQTY2110
                                        '    With lQTY

                                        '    End With
                                        'Next

                                        Dim lGrpLQ As Response835P5010.RepSegLQ
                                        lGrpLQ = lGrp2110.LQ
                                        For Each lLQ As Response835P5010.SegLQ In lGrpLQ '' LQ
                                            With lLQ
                                                If (.CodeListQualifierCode.Value <> "") Then
                                                    lRemarkCodes = lRemarkCodes & .CodeListQualifierCode.Value & "-" & .IndustryCode.Value & ","
                                                End If

                                            End With
                                        Next '' LQ
                                        If (lRemarkCodes.Length > 0) Then
                                            lRemarkCodes = lRemarkCodes.Substring(0, lRemarkCodes.Length - 1)
                                        End If

                                        lRemittanceClaimServiceDtl.RemarkCodes = lRemarkCodes

                                        lXmlElementRemittanceClaimService = lXmlDocumentRemittanceClaimService.CreateElement("RemittanceClaimServiceDtl")

                                        With lXmlElementRemittanceClaimService
                                            .SetAttribute("RemittanceClaimId", lRemittanceClaimServiceDtl.RemittanceClaimId)
                                            .SetAttribute("DateOfServiceFrom", lRemittanceClaimServiceDtl.DateOfServiceFrom)
                                            .SetAttribute("DateOfServiceTo", lRemittanceClaimServiceDtl.DateOfServiceTo)
                                            .SetAttribute("Unit", lRemittanceClaimServiceDtl.Unit)
                                            .SetAttribute("CptCode", lRemittanceClaimServiceDtl.CptCode)
                                            .SetAttribute("ChargedAmount", lRemittanceClaimServiceDtl.ChargedAmount)
                                            .SetAttribute("AllowedAmount", lRemittanceClaimServiceDtl.AllowedAmount)
                                            .SetAttribute("DeductibleAmount", lRemittanceClaimServiceDtl.DeductibleAmount)
                                            .SetAttribute("CoInsuranceAmount", lRemittanceClaimServiceDtl.CoInsuranceAmount)
                                            .SetAttribute("CoPayAmount", lRemittanceClaimServiceDtl.CoPayAmount)
                                            .SetAttribute("LateFillingRedAmount", lRemittanceClaimServiceDtl.LateFillingRedAmount)
                                            .SetAttribute("OtherAdjustmentAmount", lRemittanceClaimServiceDtl.OtherAdjustmentAmount)
                                            .SetAttribute("ServiceAdjustmentCodes", lRemittanceClaimServiceDtl.ServiceAdjustmentCodes)
                                            .SetAttribute(("ProviderPaidAmount"), lRemittanceClaimServiceDtl.ProviderPaidAmount)
                                            .SetAttribute(("RemarkCodes"), lRemittanceClaimServiceDtl.RemarkCodes)
                                            .SetAttribute(("ModifierA"), lRemittanceClaimServiceDtl.ModifierA)
                                            .SetAttribute(("ModifierB"), lRemittanceClaimServiceDtl.ModifierB)
                                            .SetAttribute(("ModifierC"), lRemittanceClaimServiceDtl.ModifierC)
                                            .SetAttribute(("ModifierD"), lRemittanceClaimServiceDtl.ModifierD)
                                            .SetAttribute(("RemittanceId"), "REMITTANCEID")

                                        End With

                                        lXmlDocumentRemittanceClaimService.DocumentElement.AppendChild(lXmlElementRemittanceClaimService.CloneNode(True))

                                        '' Remittance Service XML




                                    Next ''2110 Service Next

                                    '' RemittanceClaim XML here
                                    lXmlElementRemittanceClaim = lXmlDocumentRemittanceClaim.CreateElement("RemittanceClaimDtl")

                                    With lXmlElementRemittanceClaim
                                        .SetAttribute("RemittanceId", lRemittanceClaimDtl.RemittanceId)
                                        .SetAttribute("ReassociationTraceNumber", lRemittanceClaimDtl.ReassociationTraceNumber)
                                        .SetAttribute("RemittanceClaimId", lRemittanceClaimDtl.RemittanceClaimId)
                                        .SetAttribute("PatientFirstName", lRemittanceClaimDtl.PatientFirstName)
                                        .SetAttribute("PatientLastName", lRemittanceClaimDtl.PatientLastName)
                                        .SetAttribute("PatientMiddleName", lRemittanceClaimDtl.PatientMiddleName)
                                        .SetAttribute("InsuredFirstName", lRemittanceClaimDtl.InsuredFirstName)
                                        .SetAttribute("InsuredLastName", lRemittanceClaimDtl.InsuredLastName)
                                        .SetAttribute("InsuredMiddleName", lRemittanceClaimDtl.InsuredMiddleName)
                                        .SetAttribute("ClaimStatus", lRemittanceClaimDtl.ClaimStatus)
                                        .SetAttribute("ClaimForwardTo", lRemittanceClaimDtl.ClaimForwardTo)
                                        .SetAttribute("ClaimPaymentAmount", lRemittanceClaimDtl.ClaimPaymentAmount)
                                        .SetAttribute("ClaimAdjustmentAmount", lRemittanceClaimDtl.ClaimAdjustmentAmount)
                                        .SetAttribute(("ClaimAdjustmentCodes"), lRemittanceClaimDtl.ClaimAdjustmentCodes)
                                        .SetAttribute(("ClaimRemarkCodes"), lRemittanceClaimDtl.ClaimRemarkCodes)
                                        .SetAttribute(("HicNumber"), lRemittanceClaimDtl.HicNumber)
                                        .SetAttribute(("RenderingProviderFirstName"), lRemittanceClaimDtl.RenderingProviderFirstName)
                                        .SetAttribute(("RenderingProviderLastName"), lRemittanceClaimDtl.RenderingProviderLastName)
                                        .SetAttribute(("RenderingProviderMiddleName"), lRemittanceClaimDtl.RenderingProviderMiddleName)
                                        .SetAttribute(("RenderingProviderNpi"), lRemittanceClaimDtl.RenderingProviderNpi)
                                        .SetAttribute(("PayerClaimControlOrIcnNumber"), lRemittanceClaimDtl.PayerClaimControlOrIcnNumber)
                                        .SetAttribute(("PatientResponsibility"), lRemittanceClaimDtl.PatientResponsibility)
                                        .SetAttribute(("PatientGroupNumber"), lRemittanceClaimDtl.PatientGroupNumber)
                                        .SetAttribute(("ClaimContactName"), lRemittanceClaimDtl.ClaimContactName)
                                        .SetAttribute(("ClaimCommunicationNumberQualifier"), lRemittanceClaimDtl.ClaimCommunicationNumberQualifier)
                                        .SetAttribute(("ClaimCommunicationNumber"), lRemittanceClaimDtl.ClaimCommunicationNumber)
                                    End With

                                    lXmlDocumentRemittanceClaim.DocumentElement.AppendChild(lXmlElementRemittanceClaim.CloneNode(True))


                                    '' RemittanceClaim XML here

                                Next '' 2100 Claim Next
                                'Exit For
                            Next '' 2000

                            Dim lGrpPLB As Response835P5010.RepSegPLB
                            lGrpPLB = l835.PLB
                            For Each lPLB As Response835P5010.SegPLB In lGrpPLB
                                With lPLB
                                    '********************************'''''''''''''''
                                End With
                            Next '' PLB

                            With l835.SE
                                '********************************'''''''''''''''
                            End With
                        End If



                    Next ''Transaction

                Next 'Functional Group
            End If


            pStrRemittanceClaimDtlXml = lXmlDocumentRemittanceClaim.InnerXml.ToString
            pStrRemittanceClaimServiceDtlXml = lXmlDocumentRemittanceClaimService.InnerXml.ToString

            Return True

        Catch ex As Exception
            Return False
        End Try


    End Function
End Class
