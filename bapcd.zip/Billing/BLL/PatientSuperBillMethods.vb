Imports Microsoft.VisualBasic

Public Class PatientSuperBillMethods

   

    Public Shared Function UpDateComment(ByVal pPatientSuperBillDB As PatientSuperBillDB) As Boolean

        Dim lPatientSuperBill As PatientSuperBill = Nothing
        Dim lResult As Boolean
        Dim lUser As User = CType(HttpContext.Current.Session.Item("User"), User)

        Try
            lPatientSuperBill = New PatientSuperBill(lUser.ConnectionString)
            lPatientSuperBill.PatientSuperBill = pPatientSuperBillDB
            lResult = lPatientSuperBill.UpdateComments()
            Return True

        Catch ex As Exception
            Return False
        End Try

    End Function
    Public Shared Function LoadComment(ByVal pPatientSuperBillDB As PatientSuperBillDB, ByVal pPSbId As Integer) As System.Data.DataSet

        Dim lPatientSuperBill As PatientSuperBill = Nothing
        Dim lUser As User = CType(HttpContext.Current.Session.Item("User"), User)
        Try
            lPatientSuperBill = New PatientSuperBill(lUser.ConnectionString)
            'lPatientSuperBill.PatientSuperBill = pPatientSuperBillDB

            Dim lResult = lPatientSuperBill.LoadComments(pPatientSuperBillDB, pPSbId)
            Return lResult

        Catch ex As Exception
        End Try

    End Function

    Public Shared Function InsertComment(ByVal pPatientSuperBillDB As PatientSuperBillDB) As Boolean

        Dim lPatientSuperBill As PatientSuperBill = Nothing
        Dim lResult As Boolean
        Dim lUser As User = CType(HttpContext.Current.Session.Item("User"), User)

        Try
            lPatientSuperBill = New PatientSuperBill(lUser.ConnectionString)
            lPatientSuperBill.PatientSuperBill = pPatientSuperBillDB
            lResult = lPatientSuperBill.InsertComments()
            Return True

        Catch ex As Exception
            Return False
        End Try

    End Function

    Public Shared Function LoadVisitSummarySearch(ByVal pDateFrom As String, ByVal pDateTo As String, ByVal pPatientID As String, ByVal pFavInsID As String, ByVal pPvdID As String, ByVal pVisitStatus As String) As DataSet
        Dim lPatientSuperBill As PatientSuperBill = Nothing
        Dim lUser As User = CType(HttpContext.Current.Session.Item("User"), User)
        Dim lResult As New DataSet
        Try
            lPatientSuperBill = New PatientSuperBill(lUser.ConnectionString)
            lResult = lPatientSuperBill.GetVisitSummarySearchDS(pDateFrom, pDateTo, pPatientID, pFavInsID, pPvdID, pVisitStatus)
            Return lResult
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Public Shared Function GetFeesSchForCPT(ByVal pFavInsuranceId As String, ByVal pCPTCode As String) As DataSet
        Dim lSuperBill As SuperBill = Nothing
        Dim lUser As User = CType(HttpContext.Current.Session.Item("User"), User)
        Dim lResult As New DataSet
        Try
            lSuperBill = New SuperBill(lUser.ConnectionString)
            lResult = lSuperBill.GetFeesForCPT(pFavInsuranceId, pCPTCode)
            Return lResult
        Catch ex As Exception
            Return Nothing
        End Try
    End Function


End Class
