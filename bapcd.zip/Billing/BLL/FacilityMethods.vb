Imports Microsoft.VisualBasic
Imports Telerik.WebControls
Public Class FacilityMethods


    Public Shared Function AddFacility(ByVal pFacilityDB As FacilityDB) As Boolean
        Dim lFacility As Facility = Nothing
        Dim lUser As User = CType(HttpContext.Current.Session.Item("User"), User)


        Try
            lFacility = New Facility(lUser.ConnectionString)
            lFacility.FacilityDB = pFacilityDB
            Return lFacility.InsertFacility()

        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Shared Function LoadFacilityNameCombo(ByRef pCombo As RadComboBox, ByVal pCondition As String) As DataSet

        Dim lUser As User = CType(HttpContext.Current.Session.Item("User"), User)

        Dim lFacility As Facility = Nothing
        lFacility = New Facility(lUser.ConnectionString)

        Dim lDs As DataSet

        Try

            lDs = lFacility.GetFacilityName(lUser, " And IsDelete='N' " & pCondition)
            pCombo.DataSource = lDs
            pCombo.DataTextField = "FacilityName"
            pCombo.DataValueField = "FacilityID"
            pCombo.DataBind()





        Catch ex As Exception

        End Try

    End Function
    Public Shared Function GetAllRecords(ByVal pFacilityId As Integer) As DataSet

        Dim lUser As User = CType(HttpContext.Current.Session.Item("User"), User)


        Dim lFacility As Facility = Nothing
        lFacility = New Facility(lUser.ConnectionString)



        Dim lDs As DataSet

        Try
            If (pFacilityId = 0) Then
                lDs = lFacility.GetAllRecords(lUser, "And IsDelete='N'")
                Return lDs
            Else
                lDs = lFacility.GetAllRecords(lUser, " And IsDelete='N' And FacilityID=" & pFacilityId)
                Return lDs
            End If




        Catch ex As Exception

        End Try


    End Function


    Public Shared Function EditFacility(ByVal pFacilityDB As FacilityDB) As Boolean
        Dim lFacility As Facility = Nothing
        Dim lUser As User = CType(HttpContext.Current.Session.Item("User"), User)
        Try
            lFacility = New Facility(lUser.ConnectionString)
            lFacility.FacilityDB = pFacilityDB
            Return lFacility.UpdateFacility()

        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Shared Function DelteFacility(ByVal pFacilityDB As FacilityDB) As Boolean
        Dim lFacility As Facility = Nothing
        Dim lUser As User = CType(HttpContext.Current.Session.Item("User"), User)
        Try
            lFacility = New Facility(lUser.ConnectionString)
            lFacility.FacilityDB = pFacilityDB
            Return lFacility.DeleteFacility()

        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Shared Function GetAllRecordsforSearchWindow(ByVal pFacilityId As Integer) As DataSet

        Dim lUser As User = CType(HttpContext.Current.Session.Item("User"), User)


        Dim lFacility As Facility = Nothing
        lFacility = New Facility(lUser.ConnectionString)



        Dim lDs As DataSet

        Try
            If (pFacilityId = 0) Then
                lDs = lFacility.GetAllRecordsforSearchWindow(lUser, "And IsDelete='N'")
                Return lDs
            Else
                lDs = lFacility.GetAllRecordsforSearchWindow(lUser, " And IsDelete='N' And FacilityID=" & pFacilityId)
                Return lDs
            End If




        Catch ex As Exception

        End Try


    End Function


    '' Kanwal jeet
    Public Shared Function GetFacilityID(ByVal pFacilityDB As FacilityDB) As Integer
        Dim lFacility As Facility = Nothing
        Dim lUser As User = CType(HttpContext.Current.Session.Item("User"), User)
        Try
            lFacility = New Facility(lUser.ConnectionString)
            lFacility.FacilityDB = pFacilityDB
            Return lFacility.GetFacilityIDInClinic()

        Catch ex As Exception
            Return False
        End Try

    End Function

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="pConnectionString"></param>
    ''' <returns></returns>
    ''' <remarks>Author: Affan Toor | 07-11-12</remarks>
    Public Shared Function GetActiveFacilityID(ByVal pConnectionString As String) As String
        Dim lFacility As Facility = Nothing
        Dim lDS As New DataSet
        Dim lFacilityID As String = ""

        Try
            lFacility = New Facility(pConnectionString)
            lDS = lFacility.GetActiveFacilityList()

            If lDS IsNot Nothing Then
                lFacilityID = lDS.Tables(0).Rows(0)("FacilityId")
            End If

            Return lFacilityID
        Catch ex As Exception
            Return Nothing
        End Try

    End Function

End Class
