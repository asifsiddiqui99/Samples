Imports Microsoft.VisualBasic

Public Class ClaimBatchMethods

    Public Shared Function SearchClaimHdr() As DataSet
        Dim lUser As User = CType(HttpContext.Current.Session("User"), User)
        Dim lConnection As New Connection(lUser.ConnectionString)
        Dim lds As New DataSet
        Dim lQuery As String = "SELECT *,BatchStatus=case when status='N' then cast(0 as bit) Else cast(1 as bit) end FROM ClaimBatchHdr"
        Try
            lds = lConnection.ExecuteQuery(lQuery)
        Catch ex As Exception
            lds = Nothing
        End Try
        Return lds
    End Function

    Public Shared Function SearchClaimDtlByID(ByVal pBatchID As String) As DataSet
        Dim lUser As User = CType(HttpContext.Current.Session("User"), User)
        Dim lConnection As New Connection(lUser.ConnectionString)
        Dim lDs As New DataSet

        'Dim lQuery As String = "SELECT * FROM ClaimBatchDtl where BatchID=" & pBatchID.ToString() & " "
        Dim lQuery As String = "Exec GetClaimBatchDetail ' AND D.BatchID=" & pBatchID & "'"
        Try
            lds = lConnection.ExecuteQuery(lQuery)
        Catch ex As Exception
            lds = Nothing
        End Try
        Return lDs
    End Function

    Public Shared Function SearchBatch(ByVal pCondition As String) As DataSet
        Dim lUser As User = CType(HttpContext.Current.Session("User"), User)
        Dim lConnection As New Connection(lUser.ConnectionString)
        Dim lDs As New DataSet
        Dim lQuery As String = "Exec SearchClaimBatch '" & pCondition.Trim() & "'"
        Try
            lDs = lConnection.ExecuteQuery(lQuery)
        Catch ex As Exception
            lDs = Nothing
        End Try
        Return lDs
    End Function

    Public Shared Function InsertClaimBatch(ByVal pClaimBatchDtlXML As String, ByVal pClaimIds As String) As Boolean
        Dim lUser As User = CType(HttpContext.Current.Session("User"), User)
        Dim lConnection As New Connection(lUser.ConnectionString)
        Dim lClaimBatchHdr As New ClaimBatchHdr(lConnection)
        Dim lClaimBatchDtl As New ClaimBatchDetail(lConnection)
        Dim lDs As New DataSet
        Dim lBatchID As String = ""
        Dim lBatchDisplayId As String = ""
        Dim lClaimIds As String = ""
        Try

            If (pClaimIds.Contains(",")) Then
                lClaimIds = pClaimIds.Remove(pClaimIds.IndexOf(","), 1)
            Else
                Return False
            End If

            lConnection.BeginTrans()

            lDs = lConnection.ExecuteTransactionQuery("EXEC GetUniqueIdBatch")
            lBatchID = lDs.Tables(0).Rows(0).Item(0).ToString
            lBatchDisplayId = lDs.Tables(0).Rows(0).Item(1).ToString

            pClaimBatchDtlXML = pClaimBatchDtlXML.Replace("BATCHID", lBatchID)
            lClaimBatchDtl.InsertRecord(pClaimBatchDtlXML)

            lClaimBatchHdr.ClaimBatchHdr.BatchID = lBatchID
            lClaimBatchHdr.ClaimBatchHdr.BatchDisplayID = lBatchDisplayId
            lClaimBatchHdr.ClaimBatchHdr.CreateByUserID = lUser.UserId
            lClaimBatchHdr.ClaimBatchHdr.BatchEDI = ""
            lClaimBatchHdr.ClaimBatchHdr.CreationDate = Date.Now
            'lClaimBatchHdr.ClaimBatchHdr.SendDate = DBNull.Value
            lClaimBatchHdr.ClaimBatchHdr.Status = "N"
            lClaimBatchHdr.InsertRecord()

            lConnection.ExecuteTransactionQuery("UPDATE HCFAUpdated SET IsBatch ='Y' WHERE Hcfaid in (" & lClaimIds & ") ")

            lConnection.CommitTrans()
            Return True
        Catch ex As Exception
            lConnection.RollBackTrans()
            Return False
        End Try
    End Function

    Public Shared Function SendClaimBatch(ByVal pBatchID() As String, ByVal pBatchDisplayID() As String) As String
        If (pBatchID.Length < 1) Then
            Return False
        End If
        Dim lDs As DataSet = Nothing
        Dim lConnection As Connection
        Dim lResult As String = ""
        Dim lUpdateQuery As String = ""
        Dim lSucessCount As Int32 = 0
        Dim lFailureCount As Int32 = 0
        Dim lMessage As String = lSucessCount & " batch(es) send sucessfully, " & lFailureCount & " batch(es) failed to send. "

        'lDs = SearchClaimDtlByID("1")
        'If (lDs.Tables(0).Rows.Count > 0) Then
        '    Dim lClaim(lDs.Tables(0).Rows.Count - 1) As Int32
        '    For i As Int32 = 0 To lDs.Tables(0).Rows.Count - 1
        '        lClaim(i) = lDs.Tables(0).Rows(i).Item("ClaimID")
        '    Next
        '    lResult = ClaimRequest837Methods.Make837RequestBatch(lClaim, 1, "2008-11-00001")
        '    If (lResult = "") Then
        '        Return False
        '    Else
        '        Return True
        '    End If
        'Else
        '    Return False
        'End If


        Try
            lConnection = New Connection(CType(HttpContext.Current.Session("User"), User).ConnectionString)
            For i As Int32 = 0 To pBatchID.Length - 1

                lDs = SearchClaimDtlByID(pBatchID(i))
                If (lDs.Tables(0).Rows.Count > 0) Then
                    Dim lClaim(lDs.Tables(0).Rows.Count - 1) As Int32
                    For j As Int32 = 0 To lDs.Tables(0).Rows.Count - 1
                        lClaim(j) = lDs.Tables(0).Rows(j).Item("ClaimID")
                    Next
                    lResult = ClaimEDI837Methods.Make837RequestBatchNew(lClaim, pBatchID(i), pBatchDisplayID(i))
                    If (lResult <> "") Then
                        lUpdateQuery = "Update ClaimBatchHdr set SendDate=Getdate(),Status='Y',BatchEDI='" & lResult.Replace("'", "''") & "' where BatchId=" & pBatchID(i)
                        lConnection.ExecuteQuery(lUpdateQuery)
                        lSucessCount = lSucessCount + 1
                    Else
                        lFailureCount = lFailureCount + 1
                    End If
                End If

            Next
            lMessage = lSucessCount & " batch(es) send sucessfully, " & lFailureCount & " batch(es) failed to send. "
        Catch ex As Exception
            lMessage = lSucessCount & " batch(es) send sucessfully, " & lFailureCount & " batch(es) failed to send. "
            Return lMessage
        End Try

        Return lMessage


    End Function

    Public Shared Function SendClaimBatch(ByVal pBatchID() As String, ByVal pBatchDisplayID() As String, ByVal pIs5010 As Boolean) As String
        If (pBatchID.Length < 1) Then
            Return False
        End If
        Dim lDs As DataSet = Nothing
        Dim lConnection As Connection
        Dim lResult As String = ""
        Dim lUpdateQuery As String = ""
        Dim lSucessCount As Int32 = 0
        Dim lFailureCount As Int32 = 0
        Dim lMessage As String = lSucessCount & " batch(es) send sucessfully, " & lFailureCount & " batch(es) failed to send. "
        Try
            lConnection = New Connection(CType(HttpContext.Current.Session("User"), User).ConnectionString)
            For i As Int32 = 0 To pBatchID.Length - 1
                lDs = SearchClaimDtlByID(pBatchID(i))
                If (lDs.Tables(0).Rows.Count > 0) Then
                    Dim lClaim(lDs.Tables(0).Rows.Count - 1) As Int32
                    For j As Int32 = 0 To lDs.Tables(0).Rows.Count - 1
                        lClaim(j) = lDs.Tables(0).Rows(j).Item("ClaimID")
                    Next

                    If (pIs5010 = True) Then
                        lResult = ClaimEDI837P5010Methods.Make837RequestBatchNew(lClaim, pBatchID(i), pBatchDisplayID(i))
                    Else
                        lResult = ClaimEDI837Methods.Make837RequestBatchNew(lClaim, pBatchID(i), pBatchDisplayID(i))
                    End If

                    If (lResult <> "") Then
                        lUpdateQuery = "Update ClaimBatchHdr set SendDate=Getdate(),Status='Y',BatchEDI='" & lResult.Replace("'", "''") & "' where BatchId=" & pBatchID(i)
                        lConnection.ExecuteQuery(lUpdateQuery)
                        lSucessCount = lSucessCount + 1
                    Else
                        lFailureCount = lFailureCount + 1
                    End If
                End If
            Next
            lMessage = lSucessCount & " batch(es) send sucessfully, " & lFailureCount & " batch(es) failed to send. "
        Catch ex As Exception
            lMessage = lSucessCount & " batch(es) send sucessfully, " & lFailureCount & " batch(es) failed to send. "
            Return lMessage
        End Try
        Return lMessage
    End Function
End Class
