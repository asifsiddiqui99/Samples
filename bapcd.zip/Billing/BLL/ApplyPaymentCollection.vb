Imports Microsoft.VisualBasic

Public Class ClaimHdrDB

#Region "Fields"
    Private mLineId As String
    Private mPatientId As String
    Private mPatientName As String
    Private mHCFADisplayID As String
    Private mHCFAID As String
    Private mHCFAPreparedDate As String
    Private mTotalCharge As String
    Private mAmountPaid As String
    Private mTotalAmountAdjusted As String
    Private mTotalAmountDistributed As String
    Private mBalanceDue As String
    Private mCopayAmount As String

    Private mVisitID As String
    Private mVisitDate As String

   

    Private mClaimDtlColl As New ClaimDtlColl()
#End Region

#Region "Properties"

    Private Property VisitDate() As String
        Get
            Return mVisitDate
        End Get
        Set(ByVal value As String)
            mVisitDate = value
        End Set
    End Property

    Public Property VisitID() As String
        Get
            Return mVisitID
        End Get
        Set(ByVal value As String)
            mVisitID = value
        End Set
    End Property


    Public Property LineId() As String
        Get
            Return mLineId
        End Get
        Set(ByVal value As String)
            mLineId = value
        End Set
    End Property

    Public Property PatientId() As String
        Get
            Return mPatientId
        End Get
        Set(ByVal value As String)
            mPatientId = value
        End Set
    End Property

    Public Property PatientName() As String
        Get
            Return mPatientName
        End Get
        Set(ByVal value As String)
            mPatientName = value
        End Set
    End Property

    Public Property HCFADisplayID() As String
        Get
            Return mHCFADisplayID
        End Get
        Set(ByVal value As String)
            mHCFADisplayID = value
        End Set
    End Property

    Public Property HCFAID() As String
        Get
            Return mHCFAID
        End Get
        Set(ByVal value As String)
            mHCFAID = value
        End Set
    End Property

    Public Property HCFAPreparedDate() As String
        Get
            Return mHCFAPreparedDate
        End Get
        Set(ByVal value As String)
            mHCFAPreparedDate = value
        End Set
    End Property


    Public Property TotalCharge() As String
        Get
            Return mTotalCharge
        End Get
        Set(ByVal value As String)
            mTotalCharge = value
        End Set
    End Property

    Public Property AmountPaid() As String
        Get
            Return mAmountPaid
        End Get
        Set(ByVal value As String)
            mAmountPaid = value
        End Set
    End Property

    Public Property TotalAmountAdjusted() As String
        Get
            Return mTotalAmountAdjusted
        End Get
        Set(ByVal value As String)
            mTotalAmountAdjusted = value
        End Set
    End Property

    Public Property TotalAmountDistributed() As String
        Get
            Return mTotalAmountDistributed
        End Get
        Set(ByVal value As String)
            mTotalAmountDistributed = value
        End Set
    End Property


    Public Property BalanceDue() As String
        Get
            Return mBalanceDue
        End Get
        Set(ByVal value As String)
            mBalanceDue = value
        End Set
    End Property

    Public Property CopayAmount() As String
        Get
            Return mCopayAmount
        End Get
        Set(ByVal value As String)
            mCopayAmount = value
        End Set
    End Property




    Public Property ClaimDtlColl() As ClaimDtlColl
        Get
            Return mClaimDtlColl
        End Get
        Set(ByVal value As ClaimDtlColl)
            mClaimDtlColl = value
        End Set
    End Property

#End Region


End Class


Public Class ClaimHdr
#Region "Fields"
    Private mConnection As Connection
    Private mConnectionString
    Private mClaimHdr As New ClaimHdrDB
#End Region

#Region "Property"
    Public ReadOnly Property Connection() As ElixirLibrary.Connection
        Get
            Return mConnection
        End Get
    End Property

    Public ReadOnly Property ConnectionString() As String
        Get
            Return mConnectionString
        End Get
    End Property
    Public Property ClaimHdr() As ClaimHdrDB
        Get
            Return mClaimHdr
        End Get
        Set(ByVal value As ClaimHdrDB)
            mClaimHdr = value
        End Set
    End Property
#End Region


#Region "Constructor"
    ''' <summary>
    ''' Creates new Conection Object based on Given Connection String 
    ''' </summary>
    ''' <param name="pConnectionString">
    ''' Contains Connection String 
    ''' </param>
    ''' <remarks>
    ''' Use when not using transaction
    ''' Must Specify Connection String other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnectionString As String)
        If pConnectionString = "" Then
            Throw New ArgumentException("ConnectionString can not be empty")
        End If

        mConnectionString = pConnectionString
        mConnection = New Connection(mConnectionString)

    End Sub
    ''' <summary>
    ''' Assign given connection to the current Object
    ''' </summary>
    ''' <param name="pConnection">
    ''' Contains refrence to the connection object
    ''' </param>
    ''' <remarks>
    ''' Use when  using Transaction
    ''' Must Specify Connection other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnection As Connection)
        If pConnection Is Nothing Then
            Throw New ArgumentException("Connection can not be empty")
        End If

        mConnection = pConnection
    End Sub
#End Region

#Region "Method"



    Public Function LoadVisitsCollection(ByRef lSelectedVisits As Hashtable, ByVal lCond As String) As Boolean
        Dim lHcfa As New HCFA(ConnectionString)
        Dim lClaimDtl As ClaimDtlDB = Nothing
        Dim lClaimHdr As ClaimHdrDB = Nothing
        Dim lClaimDtlTotal As ClaimDtlDB
        Dim lDs As DataSet

        Dim lChargesTotal As Double = 0.0
        Dim lAllowedAmount As Double = 0.0
        Dim lPreviousInsurancePayment As Double = 0.0
        Dim lPreviousPatientPayment As Double = 0.0
        Dim lAdjustment As Double = 0.0
        Dim lBalance As Double = 0.0
        Dim lAmountPaid As Double = 0.0
        Dim lDeductable As Double = 0.0



        Try

            lDs = lHcfa.GetPendingClaimDetails(lCond)

            For Each lRow As DataRow In lDs.Tables(0).Rows

                If (lClaimHdr Is Nothing) OrElse (lClaimHdr.VisitID <> lRow("VisitID")) Then
                    If Not lSelectedVisits.ContainsKey(lRow("VisitID")) Then

                        If lClaimHdr IsNot Nothing Then

                            lClaimDtlTotal = New ClaimDtlDB()


                            lChargesTotal = 0.0
                            lAllowedAmount = 0.0
                            lPreviousInsurancePayment = 0.0
                            lPreviousPatientPayment = 0.0
                            lAdjustment = 0.0
                            lBalance = 0.0
                            lAmountPaid = 0.0
                            lDeductable = 0.0


                            With lClaimDtlTotal
                                .PatientID = lClaimDtl.PatientID
                                .VisitID = lClaimDtl.VisitID
                                '.HCFAID = lClaimDtl.HCFAID
                                .CPTCode = "Total"
                                .VisitDate = lClaimDtl.VisitDate

                                For x As Integer = 0 To lClaimHdr.ClaimDtlColl.Count - 1
                                    lChargesTotal += lClaimHdr.ClaimDtlColl.Item(x).Charges
                                    lAllowedAmount += IIf(lClaimHdr.ClaimDtlColl.Item(x).AmountAllowed.Equals(""), 0, lClaimHdr.ClaimDtlColl.Item(x).AmountAllowed)
                                    lPreviousInsurancePayment += lClaimHdr.ClaimDtlColl.Item(x).PreviousInsurancePayment
                                    lPreviousInsurancePayment = String.Format("{0:f2}", lPreviousInsurancePayment) 'for 2 digit after decimal.........
                                    lPreviousPatientPayment += lClaimHdr.ClaimDtlColl.Item(x).PreviousPatientPayment
                                    lPreviousPatientPayment = String.Format("{0:f2}", lPreviousPatientPayment) 'for 2 digit after decimal...
                                    lAdjustment += lClaimHdr.ClaimDtlColl.Item(x).Adjustment
                                    lAdjustment = String.Format("{0:f2}", lAdjustment) 'for 2 digit after decimal...
                                    lBalance += lClaimHdr.ClaimDtlColl.Item(x).Balance
                                    lBalance = String.Format("{0:f2}", lBalance) 'for 2 digit after decimal...
                                    lAmountPaid += lClaimHdr.ClaimDtlColl.Item(x).AmountPaid
                                    lAmountPaid = String.Format("{0:f2}", lAmountPaid) 'for 2 digit after decimal..
                                    lDeductable += lClaimHdr.ClaimDtlColl.Item(x).Deductable
                                    lDeductable = String.Format("{0:f2}", lDeductable) 'for 2 digit after decimal...

                                Next

                                ''changes made by talha for 2 digit after decimal.........
                                .Charges = String.Format("{0:f2}", lChargesTotal)
                                .AmountAllowed = IIf(lAllowedAmount = 0, "", lAllowedAmount)
                                If Not (.AmountAllowed = "") Then
                                    .AmountAllowed = String.Format("{0:f2}", lAllowedAmount)
                                End If
                                .AmountPaid = String.Format("{0:f2}", lAmountPaid)
                                .PatientPayment = String.Format("{0:f2}", lClaimDtl.PatientPayment)
                                .Adjustment = lAdjustment
                                .Balance = String.Format("{0:f2}", lBalance)
                                .OrignalBalance = String.Format("{0:f2}", lClaimDtl.OrignalBalance)
                                .PreviousInsurancePayment = String.Format("{0:f2}", lPreviousInsurancePayment)
                                .PreviousPatientPayment = String.Format("{0:f2}", lPreviousPatientPayment)
                                .OrignalAmountAllowed = String.Format("{0:f2}", lClaimDtl.OrignalAmountAllowed)
                                .OrignalCoPayment = String.Format("{0:f2}", lClaimDtl.OrignalCoPayment)
                                .Deductable = String.Format("{0:f2}", lDeductable)
                                .Status = lClaimDtl.Status
                                .VisitNumericID = lClaimDtl.VisitNumericID
                                .VisitDate = lClaimDtl.VisitDate



                            End With
                            lClaimHdr.ClaimDtlColl.Add(lClaimDtlTotal)


                        End If


                        lClaimHdr = New ClaimHdrDB
                        lSelectedVisits.Add(lRow("VisitID"), lClaimHdr)
                    Else
                        Continue For
                    End If
                End If



                With lClaimHdr

                    '.HCFAID = lRow("HCFAID")
                    .PatientId = lRow("PatientAccountNumber")
                    .PatientName = lRow("PatientName")
                    '.HCFADisplayID = lRow("HCFADisplayID")
                    .HCFAPreparedDate = lRow("VisitDate")
                    .VisitID = lRow("VisitID")

                    .CopayAmount = lRow("CopayAmount")
                    .TotalAmountDistributed = "0"


                End With




                lClaimDtl = New ClaimDtlDB()

                With lClaimDtl

                    .PatientID = lRow("PatientAccountNumber")
                    .VisitID = lRow("VisitID")
                    '.HCFAID = lRow("HCFAID")
                    .CPTCode = lRow("CPTCode")
                    .Charges = lRow("Charges")
                    .AmountAllowed = IIf(lRow("AmountAllowed") = "-1", "", lRow("AmountAllowed"))
                    .AmountPaid = "0.00"
                    .PatientPayment = lRow("Copayment") '"0"
                    .Adjustment = lRow("Adjustment")
                    .Balance = lRow("Balance").ToString
                    .OrignalBalance = lRow("Balance").ToString
                    .PreviousInsurancePayment = lRow("InsurancePayment")
                    .PreviousPatientPayment = lRow("PatientPayment")
                    .OrignalAmountAllowed = lRow("AmountAllowed").ToString
                    .OrignalCoPayment = lRow("Copayment")
                    .Deductable = lRow("Deductable")
                    .OriginalDeductable = lRow("Deductable")
                    .Status = lRow("Status")
                    .VisitNumericID = lRow("VisitNumericID")
                    .VisitDate = lRow("VisitDate")

                    .Days = lRow("Days")
                End With

                lClaimHdr.ClaimDtlColl.Add(lClaimDtl)

            Next
            If lClaimHdr Is Nothing Then
                Return False
            Else

                lClaimDtlTotal = New ClaimDtlDB()

                lChargesTotal = 0
                lAllowedAmount = 0
                lPreviousInsurancePayment = 0
                lPreviousPatientPayment = 0
                lAdjustment = 0
                lBalance = 0
                lAmountPaid = 0
                lDeductable = 0

                With lClaimDtlTotal


                    .PatientID = lClaimDtl.PatientID
                    .VisitID = lClaimDtl.VisitID
                    '.HCFAID = lClaimDtl.HCFAID
                    .CPTCode = "Total"

                    For x As Integer = 0 To lClaimHdr.ClaimDtlColl.Count - 1
                        lChargesTotal += lClaimHdr.ClaimDtlColl.Item(x).Charges
                        lAllowedAmount += IIf(lClaimHdr.ClaimDtlColl.Item(x).AmountAllowed.Equals(""), 0, lClaimHdr.ClaimDtlColl.Item(x).AmountAllowed)
                        lPreviousInsurancePayment += lClaimHdr.ClaimDtlColl.Item(x).PreviousInsurancePayment
                        lPreviousPatientPayment += lClaimHdr.ClaimDtlColl.Item(x).PreviousPatientPayment
                        lAdjustment += lClaimHdr.ClaimDtlColl.Item(x).Adjustment
                        lBalance += lClaimHdr.ClaimDtlColl.Item(x).Balance
                        lAmountPaid += lClaimHdr.ClaimDtlColl.Item(x).AmountPaid
                        lAmountPaid = String.Format("{0:f2}", lAmountPaid) 'for 2 digit after decimal..

                        lDeductable += lClaimHdr.ClaimDtlColl.Item(x).Deductable
                        lDeductable = String.Format("{0:f2}", lDeductable) 'for 2 digit after decimal..
                    Next

                    ''changes made by talha for 2 digit after decimal.........
                    .Charges = String.Format("{0:f2}", lChargesTotal)
                    .AmountAllowed = IIf(lAllowedAmount = 0, "", lAllowedAmount)
                    If Not (.AmountAllowed = "") Then
                        .AmountAllowed = String.Format("{0:f2}", lAllowedAmount)
                    End If
                    .AmountPaid = String.Format("{0:f2}", lAmountPaid)
                    .PatientPayment = String.Format("{0:f2}", lClaimDtl.PatientPayment)
                    .Adjustment = String.Format("{0:f2}", lAdjustment)
                    .Balance = String.Format("{0:f2}", lBalance)
                    .OrignalBalance = String.Format("{0:f2}", lClaimDtl.OrignalBalance)
                    .PreviousInsurancePayment = String.Format("{0:f2}", lPreviousInsurancePayment)
                    .PreviousPatientPayment = String.Format("{0:f2}", lPreviousPatientPayment)
                    .OrignalAmountAllowed = String.Format("{0:f2}", lClaimDtl.OrignalAmountAllowed)
                    .OrignalCoPayment = String.Format("{0:f2}", lClaimDtl.OrignalCoPayment)
                    .Deductable = String.Format("{0:f2}", lDeductable)
                    .Status = lClaimDtl.Status
                    .VisitNumericID = lClaimDtl.VisitNumericID
                    .VisitDate = lClaimDtl.VisitDate
                End With



                lClaimHdr.ClaimDtlColl.Add(lClaimDtlTotal)
                Return True
            End If


        Catch ex As Exception
            Return False
        End Try

    End Function


    Public Function LoadVisitsCollectionEdit(ByRef lSelectedVisits As Hashtable, ByVal pPaymentId As Int32) As Boolean
        Dim lHcfa As New HCFA(ConnectionString)
        Dim lClaimDtl As ClaimDtlDB = Nothing
        Dim lClaimHdr As ClaimHdrDB = Nothing
        Dim lClaimDtlTotal As ClaimDtlDB = Nothing
        Dim lDs As DataSet


        Dim lChargesTotal As Double = 0.0
        Dim lAllowedAmount As Double = 0.0
        Dim lPreviousInsurancePayment As Double = 0.0
        Dim lPreviousPatientPayment As Double = 0.0
        Dim lAdjustment As Double = 0.0
        Dim lBalance As Double = 0.0
        Dim lAmountPaid As Double = 0.0
        Dim lDeductable As Double = 0.0

        Try

            lDs = lHcfa.GetPendingClaimDetailsEdit(pPaymentId)

            For Each lRow As DataRow In lDs.Tables(0).Rows

                If (lClaimHdr Is Nothing) OrElse (lClaimHdr.VisitID <> lRow("VisitID")) Then
                    If Not lSelectedVisits.ContainsKey(lRow("VisitID")) Then


                        If lClaimHdr IsNot Nothing Then

                            lClaimDtlTotal = New ClaimDtlDB()


                            lChargesTotal = 0
                            lAllowedAmount = 0
                            lPreviousInsurancePayment = 0
                            lPreviousPatientPayment = 0
                            lAdjustment = 0
                            lBalance = 0
                            lAmountPaid = 0
                            lDeductable = 0

                            With lClaimDtlTotal
                                .PatientID = lClaimDtl.PatientID
                                .VisitID = lClaimDtl.VisitID
                                '.HCFAID = lClaimDtl.HCFAID
                                .CPTCode = "Total"

                                For x As Integer = 0 To lClaimHdr.ClaimDtlColl.Count - 1
                                    lChargesTotal += lClaimHdr.ClaimDtlColl.Item(x).Charges
                                    lAllowedAmount += IIf(lClaimHdr.ClaimDtlColl.Item(x).AmountAllowed.Equals(""), 0, lClaimHdr.ClaimDtlColl.Item(x).AmountAllowed)
                                    lPreviousInsurancePayment += lClaimHdr.ClaimDtlColl.Item(x).PreviousInsurancePayment
                                    lPreviousInsurancePayment = String.Format("{0:f2}", lPreviousInsurancePayment) 'for 2 digit after decimal.........
                                    lPreviousPatientPayment += lClaimHdr.ClaimDtlColl.Item(x).PreviousPatientPayment
                                    lPreviousPatientPayment = String.Format("{0:f2}", lPreviousPatientPayment) 'for 2 digit after decimal.........
                                    lAdjustment += lClaimHdr.ClaimDtlColl.Item(x).Adjustment
                                    lAdjustment = String.Format("{0:f2}", lAdjustment) 'for 2 digit after decimal...
                                    lBalance += lClaimHdr.ClaimDtlColl.Item(x).Balance
                                    lBalance = String.Format("{0:f2}", lBalance) 'for 2 digit after decimal...
                                    lAmountPaid += lClaimHdr.ClaimDtlColl.Item(x).AmountPaid
                                    lAmountPaid = String.Format("{0:f2}", lAmountPaid) 'for 2 digit after decimal..
                                    lDeductable += lClaimHdr.ClaimDtlColl.Item(x).Deductable
                                    lDeductable = String.Format("{0:f2}", lDeductable) 'for 2 digit after decimal..
                                Next

                                ''changes made by talha for 2 digit after decimal.........
                                .Charges = String.Format("{0:f2}", lChargesTotal)
                                .AmountAllowed = IIf(lAllowedAmount = 0, "", lAllowedAmount)
                                If Not (.AmountAllowed = "") Then
                                    .AmountAllowed = String.Format("{0:f2}", lAllowedAmount)
                                End If
                                .AmountPaid = String.Format("{0:f2}", lAmountPaid)
                                .PatientPayment = String.Format("{0:f2}", lClaimDtl.PatientPayment)
                                .Adjustment = String.Format("{0:f2}", lAdjustment)
                                .Balance = String.Format("{0:f2}", lBalance)
                                .OrignalBalance = String.Format("{0:f2}", lClaimDtl.OrignalBalance)
                                .PreviousInsurancePayment = String.Format("{0:f2}", lPreviousInsurancePayment)
                                .PreviousPatientPayment = String.Format("{0:f2}", lPreviousPatientPayment)
                                .OrignalAmountAllowed = String.Format("{0:f2}", lClaimDtl.OrignalAmountAllowed)
                                .OrignalCoPayment = String.Format("{0:f2}", lClaimDtl.OrignalCoPayment)
                                .Deductable = String.Format("{0:f2}", lDeductable)
                                .Status = lClaimDtl.Status
                                .VisitNumericID = lClaimDtl.VisitNumericID

                            End With
                            lClaimHdr.ClaimDtlColl.Add(lClaimDtlTotal)


                        End If



                        lClaimHdr = New ClaimHdrDB
                        lSelectedVisits.Add(lRow("VisitID"), lClaimHdr)
                    Else
                        Continue For
                    End If
                End If

                With lClaimHdr

                    '.HCFAID = lRow("HcfaId")
                    .PatientId = lRow("PatientAccountNumber")
                    .PatientName = lRow("PatientName")
                    '.HCFADisplayID = lRow("HCFADisplayID")
                    .HCFAPreparedDate = lRow("VisitDate")
                    .VisitID = lRow("VisitID")


                    .CopayAmount = lRow("CopayAmount")
                    .TotalAmountDistributed = lRow("SubPayment")

                End With


                lClaimDtl = New ClaimDtlDB()

                With lClaimDtl

                    '.HCFAID = lRow("HcfaId").ToString
                    .VisitID = lRow("VisitID")
                    .CPTCode = lRow("CPTCode").ToString

                    .Charges = String.Format("{0:f2}", lRow("Charges").ToString)
                    .AmountAllowed = IIf(lRow("AmountAllowed") = "-1", "", lRow("AmountAllowed"))
                    If Not (.AmountAllowed = "") Then
                        .AmountAllowed = String.Format("{0:f2}", .AmountAllowed)
                    End If
                    .AmountPaid = String.Format("{0:f2}", lRow("CurrentPayment").ToString)
                    .PatientPayment = String.Format("{0:f2}", lRow("Copayment").ToString.ToString) '"0"
                    .Adjustment = String.Format("{0:f2}", lRow("Adjustment").ToString)
                    .Balance = String.Format("{0:f2}", lRow("Balance").ToString)
                    .OrignalBalance = String.Format("{0:f2}", lRow("Balance").ToString)
                    .PreviousInsurancePayment = String.Format("{0:f2}", lRow("InsurancePayment").ToString)
                    .PreviousPatientPayment = String.Format("{0:f2}", lRow("PatientPayment").ToString)
                    .OrignalAmountAllowed = String.Format("{0:f2}", lRow("AmountAllowed").ToString)
                    .OrignalCoPayment = String.Format("{0:f2}", lRow("Copayment").ToString)
                    .Deductable = String.Format("{0:f2}", lRow("Deductable").ToString)
                    .OriginalDeductable = String.Format("{0:f2}", lRow("Deductable").ToString)
                    .Status = lRow("Status").ToString
                    .VisitNumericID = lRow("VisitNumericID")
                    .VisitDate = lRow("VisitDate")

                    .CoInsurance = lRow("CoInsurance")
                    .Comments = lRow("Comments")

                    If (lRow("AdjustmentCode") = "") Then
                        .AdjustmentCode = "Select"
                    Else
                        .AdjustmentCode = lRow("AdjustmentCode")
                    End If

                    If (lRow("ReasonCode") = "") Then
                        .ReasonCode = "Select"
                    Else
                        .ReasonCode = lRow("ReasonCode")
                    End If




                End With


                lClaimHdr.ClaimDtlColl.Add(lClaimDtl)

            Next
            If lClaimHdr Is Nothing Then
                Return False
            Else
                lClaimDtlTotal = New ClaimDtlDB()

                lChargesTotal = 0
                lAllowedAmount = 0
                lPreviousInsurancePayment = 0
                lPreviousPatientPayment = 0
                lAdjustment = 0
                lBalance = 0
                lAmountPaid = 0
                lDeductable = 0

                With lClaimDtlTotal


                    .PatientID = lClaimDtl.PatientID
                    .VisitID = lClaimDtl.VisitID
                    '.HCFAID = lClaimDtl.HCFAID
                    .CPTCode = "Total"

                    For x As Integer = 0 To lClaimHdr.ClaimDtlColl.Count - 1
                        lChargesTotal += lClaimHdr.ClaimDtlColl.Item(x).Charges
                        lAllowedAmount += IIf(lClaimHdr.ClaimDtlColl.Item(x).AmountAllowed.Equals(""), 0, lClaimHdr.ClaimDtlColl.Item(x).AmountAllowed)
                        lPreviousInsurancePayment += lClaimHdr.ClaimDtlColl.Item(x).PreviousInsurancePayment
                        lPreviousPatientPayment += lClaimHdr.ClaimDtlColl.Item(x).PreviousPatientPayment
                        lAdjustment += lClaimHdr.ClaimDtlColl.Item(x).Adjustment
                        lBalance += lClaimHdr.ClaimDtlColl.Item(x).Balance
                        lAmountPaid += lClaimHdr.ClaimDtlColl.Item(x).AmountPaid
                        lAmountPaid = String.Format("{0:f2}", lAmountPaid) 'for 2 digit after decimal..

                        lDeductable += lClaimHdr.ClaimDtlColl.Item(x).Deductable
                        lDeductable = String.Format("{0:f2}", lDeductable) 'for 2 digit after decimal..
                    Next

                    .Charges = String.Format("{0:f2}", lChargesTotal)
                    .AmountAllowed = IIf(lAllowedAmount = 0, "", lAllowedAmount)
                    If Not (.AmountAllowed = "") Then
                        .AmountAllowed = String.Format("{0:f2}", lAllowedAmount)
                    End If
                    .AmountPaid = String.Format("{0:f2}", lAmountPaid)
                    .PatientPayment = String.Format("{0:f2}", lClaimDtl.PatientPayment)
                    .Adjustment = String.Format("{0:f2}", lAdjustment)
                    .Balance = String.Format("{0:f2}", lBalance)
                    .OrignalBalance = String.Format("{0:f2}", lClaimDtl.OrignalBalance)
                    .PreviousInsurancePayment = String.Format("{0:f2}", lPreviousInsurancePayment)
                    .PreviousPatientPayment = String.Format("{0:f2}", lPreviousPatientPayment)
                    .OrignalAmountAllowed = String.Format("{0:f2}", lClaimDtl.OrignalAmountAllowed)
                    .OrignalCoPayment = String.Format("{0:f2}", lClaimDtl.OrignalCoPayment)
                    .Deductable = String.Format("{0:f2}", lDeductable)
                    .Status = lClaimDtl.Status
                    .VisitNumericID = lClaimDtl.VisitNumericID

                    .CoInsurance = lClaimDtl.CoInsurance
                    .Comments = lClaimDtl.Comments

                    If (lClaimDtl.AdjustmentCode = "") Then
                        .AdjustmentCode = "Select"
                    Else
                        .AdjustmentCode = lClaimDtl.AdjustmentCode
                    End If

                    If (lClaimDtl.ReasonCode = "") Then
                        .ReasonCode = "Select"
                    Else
                        .ReasonCode = lClaimDtl.ReasonCode
                    End If

                End With


                lClaimHdr.ClaimDtlColl.Add(lClaimDtlTotal)

                Return True
            End If


        Catch ex As Exception
            Return False
        End Try

    End Function



#End Region

End Class


Public Class ClaimDtlDB

#Region "Fields"
    Private mLineId As String
    Private mHCFAID As String
    Private mCPTCode As String
    Private mCharges As String
    Private mAmountAllowed As String
    Private mAmountPaid As String
    Private mPatientPayment As String
    Private mAdjustment As String
    Private mBalance As String
    Private mPreviousPatientPayment As String
    Private mPreviousInsurancePayment As String
    Private mOrignalBalance As String
    Private mOrignalAmountAllowed As String
    Private mOrignalCoPayment As String
    Private mDeductable As String
    Private mOriginalDeductable As String = String.Empty   'This is added later to also allow DB entry even if only deductable has changed
    Private mStatus As String


    Private mVisitID As String
    Private mPatientId As String
    Private mVisitNumericID As String
    Private mVisitDate As String

    Private mCoInsurance As String
    Private mComments As String

    Private mAdjustmentCode As String
    Private mReasonCode As String

    Private mDays As String
    Private mPaymentDtlID As String

#End Region

#Region "Properties"
    Public Property Days() As String
        Get
            Return mDays
        End Get
        Set(ByVal value As String)
            mDays = value
        End Set
    End Property
    Public Property OriginalDeductable() As String
        Get
            Return mOriginalDeductable
        End Get
        Set(ByVal value As String)
            mOriginalDeductable = value
        End Set
    End Property


    Public Property VisitNumericID() As String
        Get
            Return mVisitNumericID
        End Get
        Set(ByVal value As String)
            mVisitNumericID = value
        End Set
    End Property


    Public Property PatientID() As String
        Get
            Return mPatientId
        End Get
        Set(ByVal value As String)
            mPatientId = value
        End Set
    End Property


    Public Property VisitID() As String
        Get
            Return mVisitID
        End Get
        Set(ByVal value As String)
            mVisitID = value
        End Set
    End Property


    Public Property LineId() As String
        Get
            Return mLineId
        End Get
        Set(ByVal value As String)
            mLineId = value
        End Set
    End Property

    Public Property HCFAID() As String
        Get
            Return mHCFAID
        End Get
        Set(ByVal value As String)
            mHCFAID = value
        End Set
    End Property

    Public Property CPTCode() As String
        Get
            Return mCPTCode
        End Get
        Set(ByVal value As String)
            mCPTCode = value
        End Set
    End Property

    Public Property Charges() As String
        Get
            Return mCharges
        End Get
        Set(ByVal value As String)
            mCharges = value
        End Set
    End Property

    Public Property AmountAllowed() As String
        Get
            Return mAmountAllowed
        End Get
        Set(ByVal value As String)
            mAmountAllowed = value
        End Set
    End Property


    Public Property PatientPayment() As String
        Get
            Return mPatientPayment
        End Get
        Set(ByVal value As String)
            mPatientPayment = value
        End Set
    End Property

    Public Property AmountPaid() As String
        Get
            Return mAmountPaid
        End Get
        Set(ByVal value As String)
            mAmountPaid = value
        End Set
    End Property

    Public Property Adjustment() As String
        Get
            Return mAdjustment
        End Get
        Set(ByVal value As String)
            mAdjustment = value
        End Set
    End Property

    Public Property Balance() As String
        Get
            Return mBalance
        End Get
        Set(ByVal value As String)
            mBalance = value
        End Set
    End Property

    Public Property PreviousPatientPayment() As String
        Get
            Return mPreviousPatientPayment
        End Get
        Set(ByVal value As String)
            mPreviousPatientPayment = value
        End Set
    End Property

    Public Property PreviousInsurancePayment() As String
        Get
            Return mPreviousInsurancePayment
        End Get
        Set(ByVal value As String)
            mPreviousInsurancePayment = value
        End Set
    End Property

    Public Property OrignalBalance() As String
        Get
            Return mOrignalBalance
        End Get
        Set(ByVal value As String)
            mOrignalBalance = value
        End Set
    End Property

    Public Property OrignalCoPayment() As String
        Get
            Return mOrignalCoPayment
        End Get
        Set(ByVal value As String)
            mOrignalCoPayment = value
        End Set
    End Property

    Public Property OrignalAmountAllowed() As String
        Get
            Return mOrignalAmountAllowed
        End Get
        Set(ByVal value As String)
            mOrignalAmountAllowed = value
        End Set
    End Property

    Public Property Deductable() As String
        Get
            Return mDeductable
        End Get
        Set(ByVal value As String)
            mDeductable = value
        End Set
    End Property

    Public Property Status() As String
        Get
            Return mStatus
        End Get
        Set(ByVal value As String)
            mStatus = value
        End Set
    End Property

    Public Property VisitDate() As String
        Get
            Return mVisitDate
        End Get
        Set(ByVal value As String)
            mVisitDate = value
        End Set
    End Property

    Public Property CoInsurance() As String
        Get
            Return mCoInsurance
        End Get
        Set(ByVal value As String)
            mCoInsurance = value
        End Set
    End Property

    Public Property Comments() As String
        Get
            Return mComments
        End Get
        Set(ByVal value As String)
            mComments = value
        End Set
    End Property

    Public Property AdjustmentCode() As String
        Get
            Return mAdjustmentCode
        End Get
        Set(ByVal value As String)
            mAdjustmentCode = value
        End Set
    End Property

    Public Property ReasonCode() As String
        Get
            Return mReasonCode
        End Get
        Set(ByVal value As String)
            mReasonCode = value
        End Set
    End Property

    Public Property PaymentDtlID() As String
        Get
            Return mPaymentDtlID
        End Get
        Set(ByVal value As String)
            mPaymentDtlID = value
        End Set
    End Property


#End Region

End Class



Public Class ClaimDtlColl
    Inherits CollectionBase

    Public Function Add(ByVal pClaimDtl As ClaimDtlDB) As Integer
        Return List.Add(pClaimDtl)
    End Function

    Public Sub Remove(ByVal pClaimDtlDB As ClaimDtlDB)
        Dim lIndex As Integer

        lIndex = IndexOf(pClaimDtlDB)

        If lIndex > -1 Then
            List.RemoveAt(lIndex)
        End If

    End Sub

    Default Public Property Item(ByVal Index As Integer) As ClaimDtlDB
        Get
            Return CType(List.Item(Index), ClaimDtlDB)
        End Get
        Set(ByVal Value As ClaimDtlDB)
            List.Item(Index) = Value
        End Set
    End Property

    Public Shadows Function Count() As Integer
        Return List.Count
    End Function

    Public Function IndexOf(ByVal obj As Object) As Integer
        Dim lIndex As Integer = 0
        Dim lFound As Integer = 0

        For Each lObj As Object In List
            lFound = CType(lObj, ClaimDtlDB).CPTCode.CompareTo(CType(obj, ClaimDtlDB).CPTCode)
            If lFound = 0 Then
                Return lIndex
            End If
            lIndex += 1
        Next
        Return -1

    End Function

End Class



