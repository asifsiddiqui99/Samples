Imports Microsoft.VisualBasic

Public Class AgingReportMethods
    Private mConnection As Connection
    Public ReadOnly Property Connection() As ElixirLibrary.Connection
        Get
            Return mConnection
        End Get
    End Property
    Public Sub New(ByVal pConnection As Connection)
        If pConnection Is Nothing Then
            Throw New ArgumentException("Connection can not be empty")
        End If
        mConnection = pConnection
    End Sub
    Public Function GetReportByPayerDOS(ByVal pPayerName As String) As DataSet
        Dim lds As DataSet
        Dim lQuery As String = ""
        Try
            lds = New DataSet
            lQuery = "select VisitID=max(Final.VisitID),PayerName=Final.PrimaryInsuranceCompanyName,PayerID=max(Final.PrimaryInsuranceCompanyId)," _
             & "Days0to30=sum(Final.Thirty),Days31to60=sum(Final.Sixty),Days61to90=sum(Final.Ninty),Days91Plus=sum(Final.Above),DOS='1/1/1900',Extra1='',Extra2='',Extra3='',Extra4='',ClinicName='',ClinicaAddress=''  from(select VB.VisitID,VB.PrimaryInsuranceCompanyName," _
             & "VB.PrimaryInsuranceCompanyId,VB.DateOfService,Thirty=case  when datediff(day,VB.DateOfService,getdate()) <= 30 then VB.Balance else 0 end,Sixty=case when datediff(day,VB.DateOfService,getdate()) > 30 " _
             & "AND datediff(day,VB.DateOfService,getdate()) <= 60  then VB.Balance else 0 end,Ninty=case  when datediff(day,VB.DateOfService,getdate()) > 60 AND datediff(day,VB.DateOfService,getdate()) <= 90  then VB.Balance else 0 end," _
             & "Above=case  when datediff(day,VB.DateOfService,getdate()) > 90 then VB.Balance else 0 end from (select PV.VisitID,Balance=(sum(PV.debit)-sum(PV.credit)),PrimaryInsuranceCompanyName,PrimaryInsuranceCompanyId=max(PSB.PrimaryInsuranceCompanyId)," _
             & "DateOfService=Min(PSB.DateOfService) from(select VisitID=case  Transactiontype when 'V' then ReferenceId when 'P' then ReferenceId2  when 'A' then ReferenceId2 end,transactionType,debit,credit from Patientledger where " _
             & "case  Transactiontype when 'V' then ReferenceId when 'A' then ReferenceId2 when 'P' then ReferenceId2 end in  (select patientsuperbillid from Patientsuperbill where PrimaryInsuranceCompanyName like '" + pPayerName + "%' and status='Approved'  and PrimaryInsuranceCompanyId <> '' ) and PayerType <> 'P' " _
             & " union all select VisitID,transactionType='A',debit=0,credit=amount from adjustment where upper(AdjustmentType)='NA' AND VisitID in (select patientsuperbillid from Patientsuperbill " _
             & "where PrimaryInsuranceCompanyName like '" & pPayerName & "%' and status='Approved'  and PrimaryInsuranceCompanyId <> '' ) )PV,PatientSuperbill PSB " _
             & " where(PV.VisitID = PSB.PatientsuperbillID)" _
             & " group by PV.VisitID,PSB.PatientsuperbillID,PrimaryInsuranceCompanyName)VB )Final group by Final.PrimaryInsuranceCompanyId ,PrimaryInsuranceCompanyName  order by PrimaryInsuranceCompanyName asc"
            lds = Connection.ExecuteQuery(lQuery)
        Catch ex As Exception
            lds = Nothing
        End Try
        Return lds
    End Function
    Public Function GetReportByPayerFillingDate(ByVal pPayerName As String) As DataSet
        Dim lds As DataSet
        Dim lQuery As String = ""
        Try
            lds = New DataSet

            ''**************************************************************************************************************************************''''''''''''''''
            '' Query Before problem that charges associated with payer also shows amount associated with that payer after sending of claim in filing date criteria
            '' This problem require discussion as it has many variations for e.g in case of monetary changes claim is set to be inActive in this case what will be the
            '' result as you did not inform payer yet and right now you can make monetary changes or generate other claims from same visit without any response 
            '' from payer so payer still knows the amount you billed earlier.


            '            lQuery = "select VisitID=max(Final.VisitID),PayerName=Final.PrimaryInsuranceCompanyName,PayerID=max(Final.PrimaryInsuranceCompanyId), " _
            '& "Days0to30=sum(Final.Thirty),Days31to60=sum(Final.Sixty),Days61to90=sum(Final.Ninty),Days91Plus=sum(Final.Above),DOS='1/1/1900',Extra1='',Extra2='', " _
            '& "Extra3='',Extra4='',ClinicName='',ClinicaAddress='' from(select VB.VisitID,VB.PrimaryInsuranceCompanyName,VB.PrimaryInsuranceCompanyId, " _
            '& "VB.DateOfService,Thirty=case  when datediff(day,VB.DateOfService,getdate()) <= 30 then VB.Balance else 0 end,Sixty=case  " _
            '& "when datediff(day,VB.DateOfService,getdate()) > 30 AND datediff(day,VB.DateOfService,getdate()) <= 60  then VB.Balance else 0 end, " _
            '& "Ninty=case  when datediff(day,VB.DateOfService,getdate()) > 60 AND datediff(day,VB.DateOfService,getdate()) <= 90  then VB.Balance else 0 end, " _
            '& "Above=case  when datediff(day,VB.DateOfService,getdate()) > 90 then VB.Balance else 0 end from  " _
            '& "( " _
            '& "select PV.VisitID, " _
            '& "Balance=(sum(PV.debit)-sum(PV.credit)),PrimaryInsuranceCompanyName,PrimaryInsuranceCompanyId=max(PSB.PrimaryInsuranceCompanyId), " _
            '& "DateOfService=max(claim.HCFAPreparedDate) from  " _
            '& "( " _
            '& "select VisitID=PatientSuperBillID,transactionType='P',debit=TotalCharges,credit=0 from HCFAUpdated where PatientSuperBillID in " _
            '& "(select patientsuperbillid from Patientsuperbill where PrimaryInsuranceCompanyName like '" & pPayerName & "%' and status='Approved' AND " _
            '& "patientsuperbillid in (select D.VisitID from ClaimBatchHdr H , ClaimBatchDtl D where H.batchid=d.batchid AND upper(H.Status)='Y' group by D.VisitID) " _
            '& ") and IsActive='Y' " _
            '& "union all " _
            '& "select VisitID,transactionType='A',debit=0,credit=amount from adjustment where upper(AdjustmentType)='NA' AND " _
            '& "VisitID in (select patientsuperbillid from Patientsuperbill where PrimaryInsuranceCompanyName like '" & pPayerName & "%' and status='Approved' AND " _
            '& "patientsuperbillid in (select D.VisitID from ClaimBatchHdr H , ClaimBatchDtl D where H.batchid=d.batchid AND upper(H.Status)='Y' group by D.VisitID)) " _
            '& ")PV " _
            '& ",PatientSuperbill PSB,( select D.ClaimID,PatientSuperBillID=D.VisitID,HCFAPreparedDate=Min(H.SendDate),RefillingDate=Max(H.SendDate) from  " _
            '& "ClaimBatchHdr H , ClaimBatchDtl D where H.batchid=d.batchid AND upper(H.Status)='Y' group by D.ClaimID,D.VisitID )claim  " _
            '& "where PV.VisitID=PSB.PatientsuperbillID and PSB.PatientsuperbillID=claim.PatientSuperBillID  " _
            '& "group by PV.VisitID,PSB.PatientsuperbillID,PrimaryInsuranceCompanyName  " _
            '& ") " _
            '& "VB)Final group by  " _
            '& "Final.PrimaryInsuranceCompanyId ,PrimaryInsuranceCompanyName  order by PrimaryInsuranceCompanyName asc "
            ''**************************************************************************************************************************************''''''''''''''''

            lQuery = "select VisitID=max(Final.VisitID),PayerName=Final.PrimaryInsuranceCompanyName,PayerID=max(Final.PrimaryInsuranceCompanyId), " _
            & "Days0to30=sum(Final.Thirty),Days31to60=sum(Final.Sixty),Days61to90=sum(Final.Ninty),Days91Plus=sum(Final.Above),DOS='1/1/1900',Extra1='',Extra2='', " _
            & "Extra3='',Extra4='',ClinicName='',ClinicaAddress='' from(select VB.VisitID,VB.PrimaryInsuranceCompanyName,VB.PrimaryInsuranceCompanyId, " _
            & "VB.DateOfService,Thirty=case  when datediff(day,VB.DateOfService,getdate()) <= 30 then VB.Balance else 0 end,Sixty=case  " _
            & "when datediff(day,VB.DateOfService,getdate()) > 30 AND datediff(day,VB.DateOfService,getdate()) <= 60  then VB.Balance else 0 end, " _
            & "Ninty=case  when datediff(day,VB.DateOfService,getdate()) > 60 AND datediff(day,VB.DateOfService,getdate()) <= 90  then VB.Balance else 0 end, " _
            & "Above=case  when datediff(day,VB.DateOfService,getdate()) > 90 then VB.Balance else 0 end from  " _
            & "( " _
            & "select PV.VisitID, " _
            & "Balance=(sum(PV.debit)-sum(PV.credit)),PrimaryInsuranceCompanyName,PrimaryInsuranceCompanyId=max(PSB.PrimaryInsuranceCompanyId), " _
            & "DateOfService=max(claim.HCFAPreparedDate) from  " _
            & "( " _
            & "select VisitID=PatientSuperBillID,transactionType='P',debit=TotalCharges,credit=0 from HCFAUpdated where PatientSuperBillID in " _
            & "(select patientsuperbillid from Patientsuperbill where PrimaryInsuranceCompanyName like '" & pPayerName & "%' and status='Approved' AND " _
            & "patientsuperbillid in (select D.VisitID from ClaimBatchHdr H , ClaimBatchDtl D where H.batchid=d.batchid AND upper(H.Status)='Y' group by D.VisitID) " _
            & ") and IsActive='Y' " _
            & "union all " _
            & "select VisitID,transactionType='A',debit=0,credit=amount from adjustment where upper(AdjustmentType)='NA' AND " _
            & "VisitID in (select patientsuperbillid from Patientsuperbill where PrimaryInsuranceCompanyName like '" & pPayerName & "%' and status='Approved' AND " _
            & "patientsuperbillid in (select D.VisitID from ClaimBatchHdr H , ClaimBatchDtl D where H.batchid=d.batchid AND " _
            & "D.VisitID in (select distinct PatientSuperbillID from hcfaupdated where hcfatype='P' AND IsActive='Y') " _
            & "AND upper(H.Status)='Y' group by D.VisitID)) " _
            & "union all " _
            & "select Referenceid2,transactionType='A',debit=0,credit=sum(credit) from PatientLedger where TransactionType<>'V' AND Description not like '%Visit Reversal Entry%' AND " _
            & "case  TransactionType when 'P' then PayerType else 'I' end <> 'P' AND Referenceid2 in (select patientsuperbillid from Patientsuperbill " _
            & "where PrimaryInsuranceCompanyName like '" & pPayerName & "%' and status='Approved' AND patientsuperbillid in (select D.VisitID from ClaimBatchHdr H , ClaimBatchDtl D where H.batchid=d.batchid AND " _
            & "D.VisitID in (select distinct PatientSuperbillID from hcfaupdated where hcfatype='P' AND IsActive='Y') AND upper(H.Status)='Y' group by D.VisitID)) group by ReferenceId2 " _
            & ")PV " _
            & ",PatientSuperbill PSB,( select D.ClaimID,PatientSuperBillID=D.VisitID,HCFAPreparedDate=Min(H.SendDate),RefillingDate=Max(H.SendDate) from  " _
            & "ClaimBatchHdr H , ClaimBatchDtl D where H.batchid=d.batchid AND upper(H.Status)='Y' group by D.ClaimID,D.VisitID )claim  " _
            & "where PV.VisitID=PSB.PatientsuperbillID and PSB.PatientsuperbillID=claim.PatientSuperBillID  " _
            & "group by PV.VisitID,PSB.PatientsuperbillID,PrimaryInsuranceCompanyName  " _
            & ") " _
            & "VB)Final group by  " _
            & "Final.PrimaryInsuranceCompanyId ,PrimaryInsuranceCompanyName  order by PrimaryInsuranceCompanyName asc "


            lds = Connection.ExecuteQuery(lQuery)
        Catch ex As Exception
            lds = Nothing
        End Try
        Return lds
    End Function
    Public Function GetReportByDOS(ByVal pMainCond As String, ByVal pClPyCond As String) As DataSet
        Dim lQueryForReport As String = ""
        Dim lDs As DataSet
        Try
            lDs = New DataSet
            'lQueryForReport = "select top 1 ClaimID='CL 2010-10-00001',FillingDate='1/1/2010',ReFillingDate='2/2/2010',Notes='Notes goes here,Notes goes here-1',DOS='1/1/2010',PatientName='Patient1(a)',Charges='100',Days0to30=10,Days31to60=20,Days61to90=30,Days91plus=40,DaysTotal=91,Extra1='',Extra2='',Extra3='',Extra4='' from PatientLedger " _
            '& "union all select top 1 ClaimID='CL 2010-10-00002',FillingDate='2/2/2010',ReFillingDate='3/3/2010',Notes='Notes goes here,Notes goes here-2',DOS='1/1/2010',PatientName='Patient1(a)',Charges='100',Days0to30=10,Days31to60=20,Days61to90=30,Days91plus=40,DaysTotal=91,Extra1='',Extra2='',Extra3='',Extra4='' from PatientLedger " _
            '& "union all select top 1 ClaimID='CL 2010-10-00003',FillingDate='3/3/2010',ReFillingDate='4/4/2010',Notes='Notes goes here,Notes goes here-3',DOS='1/1/2010',PatientName='Patient1(b)',Charges='100',Days0to30=10,Days31to60=20,Days61to90=30,Days91plus=40,DaysTotal=91,Extra1='0010',Extra2='',Extra3='',Extra4='' from PatientLedger " _
            '& "union all select top 1 ClaimID='CL 2010-10-00004',FillingDate='4/4/2010',ReFillingDate='5/5/2010',Notes='Notes goes here,Notes goes here-4',DOS='2/2/2010',PatientName='Patient2(a)',Charges='100',Days0to30=-10,Days31to60=20,Days61to90=30,Days91plus=40,DaysTotal=90,Extra1='0010',Extra2='',Extra3='',Extra4='' from PatientLedger"

            lQueryForReport = "exec AgingReportByDOS '" & pMainCond & "','" & pClPyCond & "'"
            lDs = Connection.ExecuteQuery(lQueryForReport)
            Return lDs
        Catch ex As Exception
            Return Nothing
        End Try
    End Function
    Public Function GetReportByAccount(ByVal pRefDateInitial As String) As DataSet
        Dim lQueryForReport As String = ""
        Dim lDs As DataSet
        Try
            lDs = New DataSet
            If (pRefDateInitial = "D") Then
                lQueryForReport = "select AccountTYpe='Payers',Days0to30=isnull(sum(Final.Thirty),0),Days31to60=isnull(sum(Final.Sixty),0),Days61to90=isnull(sum(Final.Ninty),0),Days91Plus=isnull(sum(Final.Above),0),Extra1='',Extra2='',Extra3=''  " _
                & "from(select VB.VisitID,VB.DateOfService,Thirty=case  when datediff(day,VB.DateOfService,getdate()) <= 30 then VB.Balance else 0 end,Sixty=case when datediff(day,VB.DateOfService,getdate()) > 30  " _
                & "AND datediff(day,VB.DateOfService,getdate()) <= 60  then VB.Balance else 0 end,Ninty=case  when datediff(day,VB.DateOfService,getdate()) > 60 AND datediff(day,VB.DateOfService,getdate()) <= 90  then VB.Balance else 0 end, " _
                & "Above=case  when datediff(day,VB.DateOfService,getdate()) > 90 then VB.Balance else 0 end from (select PV.VisitID,Balance=(sum(PV.debit)-sum(PV.credit)), " _
                & "DateOfService=max(PSB.DateOfService) from(select VisitID=case  Transactiontype when 'V' then ReferenceId when 'P' then ReferenceId2  when 'A' then ReferenceId2 end,transactionType,debit,credit from Patientledger where  " _
                & "case  Transactiontype when 'V' then ReferenceId when 'A' then ReferenceId2 when 'P' then ReferenceId2 end in  (select patientsuperbillid from Patientsuperbill where status='Approved' and PrimaryInsuranceCompanyId <>'') and PayerType <> 'P'" _
                & "union all select VisitID,transactionType='A',debit=0,credit=amount from adjustment where upper(AdjustmentType)='NA' AND VisitID in (select patientsuperbillid from Patientsuperbill  where status='Approved' and PrimaryInsuranceCompanyId <>'') )PV,PatientSuperbill PSB  " _
                & "where(PV.VisitID = PSB.PatientsuperbillID) " _
                & "group by PV.VisitID,PSB.PatientsuperbillID)VB )Final  " _
                & "union all " _
                & "select AccountTYpe='Cash patients',Days0to30=isnull(sum(Final.Thirty),0),Days31to60=isnull(sum(Final.Sixty),0),Days61to90=isnull(sum(Final.Ninty),0),Days91Plus=isnull(sum(Final.Above),0),Extra1='', " _
                & "Extra2='',Extra3='' from(select VB.VisitID,VB.DateOfService,Thirty=case  when datediff(day,VB.DateOfService,getdate()) <= 30 then VB.Balance else 0 end,Sixty=case when datediff(day,VB.DateOfService,getdate()) > 30  " _
                & "AND datediff(day,VB.DateOfService,getdate()) <= 60  then VB.Balance else 0 end,Ninty=case  when datediff(day,VB.DateOfService,getdate()) > 60 AND datediff(day,VB.DateOfService,getdate()) <= 90  then VB.Balance else 0 end, " _
                & "Above=case  when datediff(day,VB.DateOfService,getdate()) > 90 then VB.Balance else 0 end from (select PV.VisitID,Balance=(sum(PV.debit)-sum(PV.credit)), " _
                & "DateOfService=max(PSB.DateOfService) from(select VisitID=case  Transactiontype when 'V' then ReferenceId when 'P' then ReferenceId2  when 'A' then ReferenceId2 end,transactionType,debit,credit from Patientledger where  " _
                & "case  Transactiontype when 'V' then ReferenceId when 'A' then ReferenceId2 when 'P' then ReferenceId2 end in  (select patientsuperbillid from Patientsuperbill where PrimaryInsuranceCompanyId ='' and status='Approved' ) " _
                & "union all select VisitID,transactionType='A',debit=0,credit=amount from adjustment where upper(AdjustmentType)='NA' AND VisitID in (select patientsuperbillid from Patientsuperbill where PrimaryInsuranceCompanyId ='' ) )PV,PatientSuperbill PSB  " _
                & "where(PV.VisitID = PSB.PatientsuperbillID) " _
                & "group by PV.VisitID,PSB.PatientsuperbillID)VB )Final  " _
                & "union all " _
                & "select AccountTYpe='Insurance patient',Days0to30=isnull(sum(Final.Thirty),0),Days31to60=isnull(sum(Final.Sixty),0),Days61to90=isnull(sum(Final.Ninty),0),Days91Plus=isnull(sum(Final.Above),0),Extra1='',Extra2='',Extra3=''  from " _
                & "( " _
                & "select InnerDS.DateOfService,InnerDS.VisitID, " _
                & "Thirty=case  when datediff(day,InnerDS.DateOfService,getdate()) <= 30 then InnerDS.Balance else 0 end, " _
                & "Sixty=case when datediff(day,InnerDS.DateOfService,getdate()) > 30 AND datediff(day,InnerDS.DateOfService,getdate()) <= 60  then InnerDS.Balance else 0 end, " _
                & "Ninty=case  when datediff(day,InnerDS.DateOfService,getdate()) > 60 AND datediff(day,InnerDS.DateOfService,getdate()) <= 90  then InnerDS.Balance else 0 end,  " _
                & "Above=case  when datediff(day,InnerDS.DateOfService,getdate()) > 90 then InnerDS.Balance else 0 end from  " _
                & "( " _
                & "select VisitID=AdjPart.VisitID,DateOfService=AdjPart.DateOfService,Balance=(isnull(AdjPart.debit,0)-isnull(LedgerPart.credit,0)) from " _
                & "( " _
                & "select VisitID,DateOfService=psb.DateOfService,debit=sum(amount),credit=0 from adjustment,patientsuperbill psb where adjustment.VisitID=psb.PatientSuperBillID and AdjustmentType='NA' and VisitID in (select patientsuperbillid from patientsuperbill where primaryinsurancecompanyid <> '' and status='Approved') group by VisitID ,psb.DateOfService" _
                & ")AdjPart, " _
                & "( " _
                & "select VisitID=ReferenceId2,DateOfService=max(date),debit=0,credit=sum(credit) from Patientledger where  PayerType='P' and transactionType in ('P','A') and ReferenceId2 in  (select patientsuperbillid from Patientsuperbill where PrimaryInsuranceCompanyId <> '' and status='Approved')  group by ReferenceId2 " _
                & ")LedgerPart " _
                & "where AdjPart.VisitID*=LedgerPart.VisitID " _
                & ")InnerDS " _
                & ")Final "
            ElseIf (pRefDateInitial = "F") Then
                '' Query showing change in charges after filing
                'lQueryForReport = "select AccountTYpe='Payers',Days0to30=isnull(sum(Final.Thirty),0),Days31to60=isnull(sum(Final.Sixty),0),Days61to90=isnull(sum(Final.Ninty),0),Days91Plus=isnull(sum(Final.Above),0),Extra1='',Extra2='',Extra3='' from(select VB.VisitID,VB.DateOfService,Thirty=case  when datediff(day,VB.DateOfService,getdate()) <= 30 then VB.Balance else 0 end, " _
                '& "Sixty=case  when datediff(day,VB.DateOfService,getdate()) > 30 AND datediff(day,VB.DateOfService,getdate()) <= 60  then VB.Balance else 0 end,Ninty=case  when datediff(day,VB.DateOfService,getdate()) > 60 AND datediff(day,VB.DateOfService,getdate()) <= 90  then VB.Balance else 0 end,Above=case  when datediff(day,VB.DateOfService,getdate()) > 90  " _
                '& "then VB.Balance else 0 end from (select PV.VisitID,Balance=(sum(PV.debit)-sum(PV.credit)),PrimaryInsuranceCompanyName,PrimaryInsuranceCompanyId=max(PSB.PrimaryInsuranceCompanyId),DateOfService=max(claim.HCFAPreparedDate) from (select VisitID=case  Transactiontype when 'V' then ReferenceId when 'P' then ReferenceId2  when 'A' then ReferenceId2 end, " _
                '& "transactionType,debit,credit from Patientledger where case  Transactiontype when 'V' then ReferenceId when 'A' then ReferenceId2 when 'P' then ReferenceId2 end in (select patientsuperbillid from Patientsuperbill where status='Approved' AND  PrimaryInsuranceCompanyId <> '' and  patientsuperbillid in (select D.VisitID from ClaimBatchHdr H ,  " _
                '& "ClaimBatchDtl D where H.batchid=d.batchid AND upper(H.Status)='Y' group by D.VisitID) and PayerType <> 'P')  union all select VisitID,transactionType='A',debit=0,credit=amount from adjustment where upper(AdjustmentType)='NA' AND VisitID in (select D.VisitID from ClaimBatchHdr H , ClaimBatchDtl D where H.batchid=d.batchid AND upper(H.Status)='Y' group by D.VisitID) ) " _
                '& "PV,PatientSuperbill PSB,( select D.ClaimID,PatientSuperBillID=D.VisitID,HCFAPreparedDate=Min(H.SendDate),RefillingDate=Max(H.SendDate) from ClaimBatchHdr H , ClaimBatchDtl D where H.batchid=d.batchid AND upper(H.Status)='Y' group by D.ClaimID,D.VisitID )claim where PV.VisitID=PSB.PatientsuperbillID and PSB.PatientsuperbillID=claim.PatientSuperBillID  " _
                '& "group by PV.VisitID,PSB.PatientsuperbillID,PrimaryInsuranceCompanyName )VB)Final  " _
                '& "union all " _
                '& "select top 1 AccountTYpe='Cash patients',Days0to30='0',Days31to60='0',Days61to90='0',Days91Plus='0',Extra1='NA', " _
                '& "Extra2='',Extra3='' from Patientsuperbill " _
                '& "union all " _
                '& "select top 1 AccountTYpe='Insurance patient',Day='0',Days31to60='0',Days61to90='0',Days91Plus='0',Extra1='NA', " _
                '& "Extra2='',Extra3='' from Patientsuperbill"
                lQueryForReport = "select AccountTYpe='Payers',Days0to30=isnull(sum(Final.Thirty),0),Days31to60=isnull(sum(Final.Sixty),0),Days61to90=isnull(sum(Final.Ninty),0),Days91Plus=isnull(sum(Final.Above),0),Extra1='',Extra2='',Extra3='' from(select VB.VisitID,VB.DateOfService,Thirty=case  when datediff(day,VB.DateOfService,getdate()) <= 30 then VB.Balance else 0 end, " _
                & "Sixty=case  when datediff(day,VB.DateOfService,getdate()) > 30 AND datediff(day,VB.DateOfService,getdate()) <= 60  then VB.Balance else 0 end,Ninty=case  when datediff(day,VB.DateOfService,getdate()) > 60 AND datediff(day,VB.DateOfService,getdate()) <= 90  then VB.Balance else 0 end,Above=case  when datediff(day,VB.DateOfService,getdate()) > 90  " _
                & "then VB.Balance else 0 end from " _
                & "( " _
                & "select PV.VisitID,Balance=(sum(PV.debit)-sum(PV.credit)),PrimaryInsuranceCompanyName,PrimaryInsuranceCompanyId=max(PSB.PrimaryInsuranceCompanyId),DateOfService=max(claim.HCFAPreparedDate) from " _
                & "( " _
                & "select VisitID=PatientSuperBillID,transactionType='P',debit=TotalCharges,credit=0 from HCFAUpdated where PatientSuperBillID in (select patientsuperbillid from Patientsuperbill where " _
                & "PrimaryInsuranceCompanyName <> '' and status='Approved' AND patientsuperbillid in (select D.VisitID from ClaimBatchHdr H , ClaimBatchDtl D   " _
                & "where H.batchid=d.batchid AND upper(H.Status)='Y' group by D.VisitID) )  and IsActive='Y' AND HcfaType='P' " _
                & "union all " _
                & "select VisitID=Referenceid2,transactionType='A',debit=0,credit=sum(credit) from PatientLedger where TransactionType<>'V' AND Description not like '%Visit Reversal Entry%' AND  " _
                & "case  TransactionType when 'P' then PayerType else 'I' end <> 'P' AND Referenceid2 in (select patientsuperbillid from Patientsuperbill where PrimaryInsuranceCompanyName <> '' and  " _
                & "status='Approved' AND patientsuperbillid in (select D.VisitID from ClaimBatchHdr H , ClaimBatchDtl D where H.batchid=d.batchid AND   " _
                & "D.VisitID in (select distinct PatientSuperbillID from hcfaupdated where hcfatype='P' AND IsActive='Y') AND upper(H.Status)='Y' group by D.VisitID)) group by ReferenceId2 " _
                & "union all " _
                & "select VisitID,transactionType='A',debit=0,credit=amount from adjustment where upper(AdjustmentType)='NA' AND VisitID in (select D.VisitID from ClaimBatchHdr H , ClaimBatchDtl D where H.batchid=d.batchid AND " _
                & "D.VisitID in (select distinct PatientSuperbillID from hcfaupdated where hcfatype='P' AND IsActive='Y') AND upper(H.Status)='Y' group by D.VisitID) ) PV,PatientSuperbill PSB,( select D.ClaimID,PatientSuperBillID=D.VisitID,HCFAPreparedDate=Min(H.SendDate),  " _
                & "RefillingDate=Max(H.SendDate) from ClaimBatchHdr H , ClaimBatchDtl D where H.batchid=d.batchid AND upper(H.Status)='Y' group by D.ClaimID,D.VisitID )claim where PV.VisitID=PSB.PatientsuperbillID and PSB.PatientsuperbillID=claim.PatientSuperBillID  group by PV.VisitID,PSB.PatientsuperbillID,PrimaryInsuranceCompanyName  " _
                & ") " _
                & "VB)Final  " _
                & "union all " _
                & "select top 1 AccountTYpe='Cash patients',Days0to30='0',Days31to60='0',Days61to90='0',Days91Plus='0',Extra1='NA', " _
                & "Extra2='',Extra3='' from Patientsuperbill " _
                & "union all " _
                & "select top 1 AccountTYpe='Insurance patient',Day='0',Days31to60='0',Days61to90='0',Days91Plus='0',Extra1='NA', " _
                & "Extra2='',Extra3='' from Patientsuperbill"
            ElseIf (pRefDateInitial = "S") Then
                lQueryForReport = "select top 1 AccountTYpe='Payers',Days0to30='0',Days31to60='0',Days61to90='0',Days91Plus='0',Extra1='NA', " _
                & "Extra2='',Extra3='' from Patientsuperbill " _
                & "union all " _
                & "select AccountTYpe='Cash patients',Days0to30=isnull(sum(Final.Thirty),0),Days31to60=isnull(sum(Final.Sixty),0),Days61to90=isnull(sum(Final.Ninty),0),Days91Plus=isnull(sum(Final.Above),0),Extra1='', " _
                & "Extra2='',Extra3='' from(select VB.VisitID,VB.DateOfService,Thirty=case  when datediff(day,VB.DateOfService,getdate()) <= 30 then VB.Balance else 0 end,Sixty=case when datediff(day,VB.DateOfService,getdate()) > 30  " _
                & "AND datediff(day,VB.DateOfService,getdate()) <= 60  then VB.Balance else 0 end,Ninty=case  when datediff(day,VB.DateOfService,getdate()) > 60 AND datediff(day,VB.DateOfService,getdate()) <= 90  then VB.Balance else 0 end, " _
                & "Above=case  when datediff(day,VB.DateOfService,getdate()) > 90 then VB.Balance else 0 end from (select PV.VisitID,Balance=(sum(PV.debit)-sum(PV.credit)), " _
                & "DateOfService=max(PSB.DateOfService) from(select VisitID=case  Transactiontype when 'V' then ReferenceId when 'P' then ReferenceId2  when 'A' then ReferenceId2 end,transactionType,debit,credit from Patientledger where  " _
                & "case  Transactiontype when 'V' then ReferenceId when 'A' then ReferenceId2 when 'P' then ReferenceId2 end in  (select patientsuperbillid from Patientsuperbill where PrimaryInsuranceCompanyId ='' and status='Approved' ) " _
                & "union all select VisitID,transactionType='A',debit=0,credit=amount from adjustment where upper(AdjustmentType)='NA' AND VisitID in (select patientsuperbillid from Patientsuperbill where PrimaryInsuranceCompanyId ='' ) )PV,PatientSuperbill PSB  " _
                & "where(PV.VisitID = PSB.PatientsuperbillID) " _
                & "group by PV.VisitID,PSB.PatientsuperbillID)VB )Final  " _
                & "union all " _
                & "select AccountTYpe='Insurance patient',Days0to30=isnull(sum(Final.Thirty),0),Days31to60=isnull(sum(Final.Sixty),0),Days61to90=isnull(sum(Final.Ninty),0),Days91Plus=isnull(sum(Final.Above),0),Extra1='',Extra2='',Extra3=''  from " _
                & "( " _
                & "select InnerDS.DateOfService,InnerDS.VisitID, " _
                & "Thirty=case  when datediff(day,InnerDS.DateOfService,getdate()) <= 30 then InnerDS.Balance else 0 end, " _
                & "Sixty=case when datediff(day,InnerDS.DateOfService,getdate()) > 30 AND datediff(day,InnerDS.DateOfService,getdate()) <= 60  then InnerDS.Balance else 0 end, " _
                & "Ninty=case  when datediff(day,InnerDS.DateOfService,getdate()) > 60 AND datediff(day,InnerDS.DateOfService,getdate()) <= 90  then InnerDS.Balance else 0 end,  " _
                & "Above=case  when datediff(day,InnerDS.DateOfService,getdate()) > 90 then InnerDS.Balance else 0 end from  " _
                & "( " _
                & "select VisitID=AdjPart.VisitID,DateOfService=AdjPart.DateOfService,Balance=(isnull(AdjPart.debit,0)-isnull(LedgerPart.credit,0)) from " _
                & "( " _
                & "select VisitID,DateOfService=max(adjustmentdate),debit=sum(amount),credit=0 from adjustment where AdjustmentType='NA' and VisitID in (select patientsuperbillid from patientsuperbill where primaryinsurancecompanyid <> '' and status='Approved') group by VisitID " _
                & ")AdjPart, " _
                & "( " _
                & "select VisitID=ReferenceId2,DateOfService=max(date),debit=0,credit=sum(credit) from Patientledger where  PayerType='P' and transactionType in ('P','A') and ReferenceId2 in  (select patientsuperbillid from Patientsuperbill where PrimaryInsuranceCompanyId <> '' and status='Approved')  group by ReferenceId2 " _
                & ")LedgerPart " _
                & "where AdjPart.VisitID*=LedgerPart.VisitID " _
                & ")InnerDS " _
                & ")Final "
            End If
            
            lDs = Connection.ExecuteQuery(lQueryForReport)
            Return lDs
        Catch ex As Exception
            Return Nothing
        End Try
    End Function


    Public Function GetReportByPatientDOS(ByVal pPatientName As String) As DataSet
        Dim lds As DataSet
        Dim lQuery As String = ""
        Dim lCondition As String = ""
        Dim lComaRplcdPatientNm As String = ""
        Try
            lds = New DataSet
            If pPatientName <> "" Then
                If (pPatientName.Contains(",")) Then
                    lComaRplcdPatientNm = pPatientName.Replace(" ", "")
                    lCondition = " and  (X.PatientName like '" & pPatientName & "%' OR X.PatientName like '" & lComaRplcdPatientNm & "%')"
                Else
                    lCondition = " and  X.PatientName like '" & pPatientName & "%'"
                End If
            End If

            lQuery = " Select PatientId=max(X.PatientId), PatientName=max(X.PatientName),   " & _
 " DOS=max(X.DateOfService) ,   " & _
 " Days0to30=sum(X.Thirty),Days31to60=sum(X.Sixty),   " & _
 " Days61to90=sum( X.Ninty),Days91Plus=sum(X.Above)   " & _
 " from  " & _
 "  (  " & _
 " select CASH.VisitID,CASH.PatientName,CASH.PatientId,   " & _
 " CASH.DateOfService,Thirty=case   " & _
 " when datediff(day,CASH.DateOfService,getdate()) <= 30   " & _
 " then CASH.Balance else 0 end,Sixty=case when   " & _
 " datediff(day,CASH.DateOfService,getdate()) > 30 AND  " & _
 " datediff(day,CASH.DateOfService,getdate()) <= 60   " & _
 " then CASH.Balance else 0 end,Ninty=case  when  datediff(day,CASH.DateOfService,getdate())  " & _
 " > 60 AND datediff(day,CASH.DateOfService,getdate()) <= 90    " & _
 " then CASH.Balance else 0 end,   " & _
 " Above=case when datediff(day,CASH.DateOfService,  " & _
 " getdate()) > 90   " & _
 " then CASH.Balance else 0 end from  " & _
 "  (  " & _
 " select VisitID=Max(PV.VisitID),   " & _
 " Balance=sum(PV.debit)-sum(PV.credit),PatientName,   " & _
 " PatientId=max(PSB.PatientId),DateOfService=PSB.DateOfService  " & _
 " from  " & _
 "  (select VisitID=case  Transactiontype   " & _
 " when 'V' then  ReferenceId   " & _
 " when 'P' then ReferenceId2   " & _
 " when 'A' then ReferenceId2 end,   " & _
 " transactionType,debit,credit   " & _
 " from Patientledger   " & _
 " where case  Transactiontype when 'V' then ReferenceId   " & _
 " when 'A' then ReferenceId2   " & _
 " when 'P' then ReferenceId2 end   " & _
 " in  (select patientsuperbillid from Patientsuperbill where status='Approved'  " & _
 " and PrimaryInsurancecompanyid='')   " & _
 " ) PV,   " & _
 " PatientSuperbill PSB  where(PV.VisitID = PSB.PatientsuperbillID)   " & _
 " group by PSB.PatientID,PSB.PatientName,PSB.DateOfService  " & _
 " )CASH  " & _
 " union ALL  " & _
 " select IP.VisitID,IP.PatientName,IP.PatientId,   " & _
 " IP.DateOfService,Thirty=case   " & _
 " when datediff(day,IP.DateOfService,getdate()) <= 30   " & _
 " then IP.Balance else 0 end,Sixty=case when   " & _
 " datediff(day,IP.DateOfService,getdate()) > 30 AND  " & _
 " datediff(day,IP.DateOfService,getdate()) <= 60   " & _
 " then IP.Balance else 0 end,Ninty=case   " & _
 " when datediff(day,IP.DateOfService,getdate())  " & _
 " > 60 AND datediff(day,IP.DateOfService,getdate()) <= 90  " & _
 " then IP.Balance else 0 end,   " & _
 " Above=case  when datediff(day,IP.DateOfService,getdate()) > 90  " & _
 " then IP.Balance else 0 end from  " & _
 "  (  " & _
 " Select VisitID=Max(ADJ.VisitID),Balance=sum(ADJ.Balance),   " & _
 " PSB.PatientName,PSB.PatientID,ADJ.DateOfService from  " & _
 "  (  " & _
 " select VisitID=AdjPart.VisitID,DateOfService=AdjPart.DateOfService,   " & _
 " Balance=(isnull(AdjPart.debit,0)-isnull(LedgerPart.credit,0)) from  " & _
 "  (  " & _
 " select A.VisitID,DateOfService=min(P.DateOfService),   " & _
 " debit=sum(A.amount),credit=0 from adjustment A,PatientSuperBill P where   " & _
 " A.VisitID=P.PatientSuperBillID  AND AdjustmentType='NA' and   " & _
 " A.VisitID in (select patientsuperbillid from patientsuperbill where   " & _
 " primaryinsurancecompanyid <> '' and status='Approved')   " & _
 " group by VisitID  " & _
 " )AdjPart,   " & _
 "  (  " & _
 " select VisitID=ReferenceId2,DateOfService=min(ReferenceDate2),debit=0,   " & _
 " credit=sum(credit) from Patientledger where  PayerType='P' and   " & _
 " transactionType in ('P','A') and ReferenceId2 in    " & _
 "  (select patientsuperbillid from Patientsuperbill where   " & _
 " PrimaryInsuranceCompanyId <> '' and status='Approved')   " & _
 " group by ReferenceId2  " & _
 " )LedgerPart  " & _
 " where AdjPart.VisitID*=LedgerPart.VisitID  " & _
 " )ADJ,PatientSuperBill PSB   " & _
 " where ADJ.VisitId=PSB.PatientSuperbillID  " & _
 " group by PSB.PatientID,PSB.PatientName,ADJ.DateOfService  " & _
 " )IP  " & _
 " )X  " & _
 " where 1=1 " & lCondition & _
 " group by X.PatientId  " & _
 " order by PatientName asc  "




            lds = Connection.ExecuteQuery(lQuery)
        Catch ex As Exception
            lds = Nothing
        End Try
        Return lds

    End Function
    Public Function GetReportByPatientStatementDate(ByVal pPatientId As String) As DataSet
        Dim lds As DataSet
        Dim lQuery As String = ""
        Try
            lds = New DataSet
            If pPatientId <> "" Then

                lQuery = ""
            Else

            End If
            lds = Connection.ExecuteQuery(lQuery)
        Catch ex As Exception
            lds = Nothing
        End Try
        Return lds
    End Function
End Class
