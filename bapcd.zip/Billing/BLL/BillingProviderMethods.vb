Imports Microsoft.VisualBasic

Public Class BillingProviderMethods
    Public Shared Function GetBillingProvider(ByVal pUser As User, ByVal pCond As String) As BillingProviderDB
        Dim lBillingProviderDAL As New BillingProvider(pUser.ConnectionString)

        Try
            lBillingProviderDAL.GetBillingProvider(pCond)
        Catch ex As Exception
            Throw New Exception(ex.Message + " : Biling\BLL\BillingProviderMethods.GetBillingProvider(ByVal pUser As User) As BillingProviderDB")
        End Try

        Return lBillingProviderDAL.BillingProvider

    End Function
    Public Shared Function AutocompeteQuery(ByVal pUser As User, ByVal pCond As String) As DataSet
        Dim lBillingProviderDAL As New BillingProvider(pUser.ConnectionString)
        Dim lDs As New DataSet
        Try
            lDs = lBillingProviderDAL.AutocompeteQuery(pCond)
            Return lDs
        Catch ex As Exception
            Return Nothing
        End Try

        Return lDs

    End Function

    Public Shared Function UpdateBillingProvider(ByVal pBillingProviderDB As BillingProviderDB, ByVal pUser As User) As Boolean
        Dim lBillingProviderDAL As New BillingProvider(pUser.ConnectionString)
        Try
            lBillingProviderDAL.BillingProvider = pBillingProviderDB
            If (lBillingProviderDAL.UpdateRecord()) Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            Throw New Exception(ex.Message + " : Biling\BLL\BillingProviderMethods.UpdateBillingProvider(ByVal pBillingProviderDB As BillingProviderDB, ByVal pUser As User) As Boolean ")
        End Try
    End Function

    Public Shared Function InsertBillingProvider(ByVal pBillingProviderDB As BillingProviderDB, ByVal pUser As User) As Boolean
        Dim lBillingProviderDAL As New BillingProvider(pUser.ConnectionString)
        Try
            lBillingProviderDAL.BillingProvider = pBillingProviderDB
            If (lBillingProviderDAL.InsertRecord()) Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            Throw New Exception(ex.Message + " : Biling\BLL\BillingProviderMethods.UpdateBillingProvider(ByVal pBillingProviderDB As BillingProviderDB, ByVal pUser As User) As Boolean ")
        End Try
    End Function

    Public Shared Function DeleteInsertBillingProvider(ByVal pBillingProviderDB As BillingProviderDB, ByVal pUser As User) As Boolean
        Dim lConnection As New Connection(pUser.ConnectionString)
        Dim lBillingProviderDAL As New BillingProvider(pUser.ConnectionString)
        Dim lResult As Boolean
        Try
            lConnection.BeginTrans()
            lBillingProviderDAL.BillingProvider = pBillingProviderDB
            lBillingProviderDAL.DeleteBillingProviedr(pBillingProviderDB.ProviderID, pBillingProviderDB.EntryInsuranceTypeCode)
            lResult = lBillingProviderDAL.InsertRecord()
            lConnection.CommitTrans()
            Return lResult
        Catch ex As Exception
            lConnection.RollBackTrans()
            Return False
        End Try
    End Function

    Public Shared Function LoadAllProviders(ByVal pUser As User) As DataSet
        Dim lBillingProviderDAL As New BillingProvider(pUser.ConnectionString)
        Dim lDs As New DataSet
        Try
            lDs = lBillingProviderDAL.LoadAllProvider()
            Return lDs
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Public Shared Function LoadAllProviders(ByVal pUser As User, ByVal pCon As String) As DataSet
        Dim lBillingProviderDAL As New BillingProvider(pUser.ConnectionString)
        Dim lDs As New DataSet
        Try
            lDs = lBillingProviderDAL.LoadAllProvider(pCon)
            Return lDs
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Public Shared Function InsertBillingProviderALL(ByVal pBillingProviderALL As String, ByVal pUser As User) As Boolean
        Dim lConnection As New Connection(pUser.ConnectionString)
        Dim lBillingProviderDAL As New BillingProvider(pUser.ConnectionString)

        Try
            lConnection.BeginTrans()

            lBillingProviderDAL.InsertRecordALL(pBillingProviderALL)

            lConnection.CommitTrans()
            Return True
        Catch ex As Exception
            lConnection.RollBackTrans()
            Return False
        End Try
    End Function

    Public Shared Function DeleteInsertBillingProviderALL(ByVal pBillingProviderALL As String, ByVal pUser As User, ByVal pInsuranceTypeIDs As String, ByVal pProviderID As String) As Boolean
        Dim lConnection As New Connection(pUser.ConnectionString)
        Dim lBillingProviderDAL As New BillingProvider(pUser.ConnectionString)

        Try
            lConnection.BeginTrans()
            lBillingProviderDAL.DeleteBillingProviedr(pProviderID, pInsuranceTypeIDs)
            lBillingProviderDAL.InsertRecordALL(pBillingProviderALL)
            lConnection.CommitTrans()
            Return True
        Catch ex As Exception
            lConnection.RollBackTrans()
            Return False
        End Try
    End Function

    Public Shared Function CheckBillingProvider(ByVal pUser As User, ByVal pProviderID As String, ByVal pInsuranceTypeID As String) As String
        Dim lBillingProviderDAL As New BillingProvider(pUser.ConnectionString)
        Dim lInsuranceType As String = ""
        Dim lDs As New DataSet
        Try
            lDs = lBillingProviderDAL.CheckRecord(pProviderID, pInsuranceTypeID)
            If (lDs.Tables(0).Rows.Count > 0) Then
                For Each lrow As DataRow In lDs.Tables(0).Rows
                    lInsuranceType = lInsuranceType & "|" & lrow.Item("EntryInsuranceTypeCode").ToString
                Next
            End If
            Return lInsuranceType
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Public Shared Function DeleteBillingProvider(ByVal pUser As User, ByVal pProviderId As String, ByVal pInsuranceTypeIDs As String) As Boolean
        Dim lBillingProviderDAL As New BillingProvider(pUser.ConnectionString)
        Dim lResult As Boolean
        Try
            lResult = lBillingProviderDAL.DeleteBillingProviedr(pProviderId, pInsuranceTypeIDs)
            Return lResult
        Catch ex As Exception
            Return False
        End Try

    End Function

    Public Shared Function SearchBillingProvider(ByVal pUser As User, ByVal pCond As String) As DataSet
        Dim lBillingProviderDAL As New BillingProvider(pUser.ConnectionString)
        Dim lDs As New DataSet
        Try
            lDs = lBillingProviderDAL.SearchBillingProvider(pCond)
            Return lDs
        Catch ex As Exception
            Return Nothing
        End Try

        Return lDs

    End Function

End Class

