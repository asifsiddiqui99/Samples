Imports ElixirLibrary
Imports Telerik.WebControls
Partial Class Billing_PatientStatementArchive
    Inherits System.Web.UI.Page

    Protected Sub btnsearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnsearch.Click
        Try
            'txtPatientID.Text = ""
            'btnBackPS.Visible = False
            grdSearch.Rebind()
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim queryString As NameValueCollection = Nothing
        Dim lPatientID As String
        Try
            If (Page.IsPostBack = False) Then
                dtStatementDateFrom.SelectedDate = Date.Now.AddMonths(-6)
                dtStatementDateFrom.MaxDate = Date.Now
                dtStatementDateTo.SelectedDate = Date.Now
                dtStatementDateTo.MaxDate = Date.Now
                pnlMain.Focus()

                If (Request.QueryString.Count > 0) Then
                    queryString = Encryption.DecryptQueryString(Request.QueryString.ToString())
                    If (queryString IsNot Nothing) Then
                        lPatientID = queryString("id").ToString
                        txtPatientID.Text = lPatientID
                        btnBackPS.Visible = True
                        Dim lPatient As New PatientDBExtended
                        Dim lUser As User
                        lUser = CType(Session.Item("User"), User)
                        lPatient = PatientMethods.LoadPatientsById(lPatientID, lUser)
                        cmbPatient.Text = lPatient.LastName & "," & lPatient.FirstName
                        grdSearch.Rebind()
                    End If
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub grdSearch_ItemDataBound(ByVal sender As Object, ByVal e As Telerik.WebControls.GridItemEventArgs) Handles grdSearch.ItemDataBound

        Try
            If (e.Item.ItemType = Telerik.WebControls.GridItemType.Item Or e.Item.ItemType = Telerik.WebControls.GridItemType.AlternatingItem) Then
                If (e.Item.Cells(4).Text = e.Item.Cells(5).Text) Then
                    e.Item.Cells(5).Text = "Self"
                End If
                e.Item.Cells(6).Text = CType(e.Item.Cells(6).Text, Date).Date.ToString("MM/dd/yyyy")
                e.Item.Cells(7).Text = "$ " & e.Item.Cells(7).Text


            End If
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub grdSearch_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdSearch.NeedDataSource
        Try
            'If Page.IsPostBack Then
            BindGrid()
            'End If
        Catch ex As Exception

        End Try
    End Sub

    Public Sub BindGrid()
        Dim lDS As DataSet
        Try

            If cmbPatient.Text.Trim <> "" Then

                If cmbPatient.Text.Contains(",") Then
                    Dim lPatientName As String() = cmbPatient.Text.Split(","c)
                    txtPatientName.Text = lPatientName(0) & ",%" & lPatientName(1)
                Else
                    txtPatientName.Text = cmbPatient.Text
                End If

            Else
                txtPatientName.Text = ""
            End If


            lDS = PatientStatementArchive.SearchRecords(dtStatementDateFrom.SelectedDate, dtStatementDateTo.SelectedDate, Utility.AdjustApostrophie(txtPatientName.Text), Utility.AdjustApostrophie(txtGuarantorName.Text))
            If (lDS.Tables.Count > 0) Then
                grdSearch.DataSource = lDS.Tables(0)
                grdSearch.DataBind()
            End If
        Catch ex As Exception

        End Try
    End Sub

    
    Protected Sub btnMirror_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnMirror.Click


        Dim newWindow As RadWindow
        Try
            newWindow = New RadWindow()
            If (cmbPatient.Text.ToString.Split(",").Length = 1) Then
                newWindow.NavigateUrl = "PatientSearch.aspx?srch=" & Utility.AdjustApostrophie(Me.cmbPatient.Text.ToString.Split(",")(0)) & "|" & "" & ""
            ElseIf (cmbPatient.Text.ToString.Split(",").Length > 1) Then
                newWindow.NavigateUrl = "PatientSearch.aspx?srch=" & Utility.AdjustApostrophie(Me.cmbPatient.Text.ToString.Split(",")(0)) & "|" & Me.cmbPatient.Text.ToString.Split(",")(1) & ""
            Else

            End If
            newWindow.ID = "rwPrimaryInsurer"
            newWindow.VisibleOnPageLoad = True
            newWindow.Top = 220
            newWindow.Left = 280
            newWindow.Width = Unit.Pixel(697)
            newWindow.Height = Unit.Pixel(400)
            newWindow.VisibleTitlebar = False
            newWindow.VisibleStatusbar = False
            newWindow.BorderStyle = BorderStyle.Solid
            newWindow.ReloadOnShow = True
            newWindow.BackColor = Drawing.Color.Transparent
            newWindow.ClientCallBackFunction = "PatientSearchCallBackFunction"
            newWindow.Enabled = True
            newWindow.Visible = True
            rwmSuperBill.Windows.Add(newWindow)

        Catch ex As Exception
            Dim lLogID As String = String.Empty
            lLogID = ErrorLogMethods.LogError(ex, " Billing_PatientLedgerPage.aspx\btnMirror_Click() ")
            Response.Redirect("~/ErrorPage.aspx?LogID=" & lLogID, False)
        End Try



    End Sub

    Protected Sub btnBackPS_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnBackPS.Click
        Dim lPatientID As String
        Try
            lPatientID = ElixirLibrary.Encryption.EncryptQueryString("id=" & txtPatientID.Text)
            Response.Redirect("selectpatient.aspx" & lPatientID)
        Catch ex As Exception

        End Try
    End Sub
End Class
