Imports System.net
Imports System.io
Imports System.Security.Cryptography.X509Certificates
Partial Class Billing_SendClaim
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ' Dim lFilePath As String = "C:\Documents and Settings\afshan\Desktop\textFile.txt"
        If (Not Request.QueryString("FilePath") Is Nothing) Then
            If (Request.QueryString("FilePath") <> "") Then
                Dim lFilePath As String = Utility.Decrypt(Request.QueryString("FilePath").Replace(" ", "+"), "!#$a54?3")
                If (lFilePath.ToUpper <> "ERROR" And lFilePath <> "") Then
                    Dim strReader As New StreamReader(lFilePath)
                    Dim lHeader As String = "version: 0.2 " + vbCrLf + "Username: XOA00205 " + vbCrLf + "Password: 2P32j8bm " + vbCrLf + "Organization: XOA00205 " + vbCrLf + "Message Format: X12 " + vbCrLf + "Message Type: ANSI " + vbCrLf + "Usage: TEST " + vbCrLf + "Body Length: 1000 "
                    Try
                        Dim data As String = lHeader + vbCrLf + vbCrLf + strReader.ReadToEnd()
                        Me.txtData.Value = data
                    Catch ex As Exception
                        Response.Write(ex.Message)
                    Finally
                        strReader.Close()
                    End Try
                Else
                    Response.Redirect("VisitSearch.aspx")
                End If

            Else
                Response.Redirect("VisitSearch.aspx")
            End If
        Else
            Response.Redirect("VisitSearch.aspx")
        End If
    End Sub

    Protected Sub btnSend_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSend.Click
        Me.txtData.Value = Send(Me.txtData.Value)
    End Sub
    Public Function Send(ByVal pClaimEdi As String) As String
        Dim lStatus As String
        Dim Url As String = System.Configuration.ConfigurationManager.AppSettings("ENS_URL")

        If Url = "" OrElse pClaimEdi = "" Then
            Return "Error"
        End If

        Dim headertext As String = ""
        Dim str As String = "UlhIVUI6Tk9QQVNT"
        Dim hwRequest As HttpWebRequest
        Dim hwResponse As HttpWebResponse
        Dim myWriter As StreamWriter
        Try
            hwRequest = CType(HttpWebRequest.Create(Url), HttpWebRequest)
            'headertext = "Authorization: Basic " + str
            'hwRequest.Headers.Add(headertext)
            hwRequest.Method = "POST"
            hwRequest.ContentType = "application/x-www-form-urlencoded"
            Try
                ServicePointManager.CertificatePolicy = New CertificateValidation
                myWriter = New StreamWriter(hwRequest.GetRequestStream)
                myWriter.Write(pClaimEdi)
                myWriter.Flush()
                myWriter.Close()
            Catch e1 As Exception
                lStatus = e1.Message
            End Try
            Try
                hwResponse = CType(hwRequest.GetResponse, HttpWebResponse)
                Dim stResponse As StreamReader = New StreamReader(hwResponse.GetResponseStream)
                lStatus = stResponse.ReadToEnd
            Catch ex As Exception
                lStatus = ex.Message
            End Try
        Catch ex As Exception
            lStatus = ex.Message
        End Try
        
        Return lStatus
    End Function

    Protected Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Response.Redirect("VisitSearch.aspx")
    End Sub
End Class
Public Class CertificateValidation
    Implements ICertificatePolicy

    Public Function CheckValidationResult(ByVal srvPoint As ServicePoint, _
    ByVal cert As X509Certificate, ByVal request As WebRequest, ByVal problem As Integer) As Boolean Implements ICertificatePolicy.CheckValidationResult
        'Return true to specify that certificate is always validated
        Return True
    End Function
End Class
