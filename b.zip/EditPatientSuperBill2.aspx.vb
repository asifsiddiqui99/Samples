Imports Telerik.WebControls


Partial Class Billing_EditPatientSuperBill2
    Inherits System.Web.UI.Page

    Shared lHeading As String
    Shared lRecordNo As Integer

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim lID As String = String.Empty


        








        If Request.QueryString("sid") Is Nothing Then
            Return
        Else : lID = Request.QueryString("sid").ToString
        End If

        txtPatientSuperBillId.Text = lID.Split("|")(0)
        txtSuperBillTemplateId.Text = lID.Split("|")(2)
        txtPatientID.Text = lID.Split("|")(1)


        If Not Page.IsPostBack Then
            LoadSuperBillOrderInformation()
            LoadClinic()
            EmployeeMethods.LoadDoctorsCombo(cmbProvider)
            LoadPatient(txtPatientSuperBillId.Text)
        End If

        ''Check if controls have to be disabled to make this page available for viewing only (in case of Approved Superbill) or for editing
        If ((lID.Split("|")(4)) = "A") Then
            DisableControls(SubPanel)
            DisableControls(btnSave)
            checkapprove.Checked = True
            txtApproved.Text = "A"
        Else
            txtApproved.Text = "U"
        End If


        If (Page.IsPostBack <> True) Then
            lblMessage.Text = "<script>display()</Script>"
        End If










        '**********

        Dim lUser As User
        Dim lCPT As CPT
        Dim lArrOrderBy As String()
        Dim lOrderColumn As String = ""
        Dim lOrder As String = ""




        lUser = CType(HttpContext.Current.Session("User"), User)
        lCPT = New CPT(lUser.ConnectionString)

        lCPT.CPT.SuperBillId = "1"
        lCPT.CPT.PatientSuperBillId = "56"

        Dim lDataSet As DataTable = Nothing
        lDataSet = lCPT.GetCPTForClaim("Order By HeadingOrder").Tables(0)
        dlCPT.DataSource = lDataSet
        dlCPT.DataBind()

        If lDataSet.Rows.Count > 20 Then
            dlCPT.RepeatColumns = 3
        ElseIf lDataSet.Rows.Count > 10 Then
            dlCPT.RepeatColumns = 2
        Else
            dlCPT.RepeatColumns = 3
        End If

        lRecordNo = 0


        tsGenerateSuperBill.SelectedIndex = 0
        mpGenerateSuperBill.SelectedIndex = 0
    End Sub

    Protected Sub dlCPT_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataListItemEventArgs) Handles dlCPT.ItemDataBound
        Dim lLabel As Label
        Dim lPanel As Panel

        If e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem Then

            lLabel = e.Item.FindControl("lblSubHeading")
            lPanel = e.Item.FindControl("pnlHeading")
            If lHeading = lLabel.Text Then
                lLabel.Text = ""
            Else
                lHeading = lLabel.Text
            End If

            If lRecordNo = 0 Or lRecordNo = 3 Then
                lPanel.Visible = True
            Else
                lPanel.Visible = False
            End If
            lRecordNo += 1
            'lLabel.Text = e.Item.DataItem( 
        End If
    End Sub


    Private Sub LoadModifier(ByVal pDS As DataSet)
        Dim i As Integer
        txtHidden.Text = pDS.Tables(0).Rows.Count - 1
        hdnText.Text = pDS.Tables(0).Rows.Count - 1


        For i = 1 To pDS.Tables(0).Rows.Count - 1
            CType(pnlBillingInfo.FindControl("txtCharges" & i), TextBox).Text = pDS.Tables(0).Rows(i - 1).Item("Charges")
            CType(pnlBillingInfo.FindControl("cmbCPT" & i), RadComboBox).Text = pDS.Tables(0).Rows(i - 1).Item("Code")
            CType(pnlBillingInfo.FindControl("cmbPOS" & i), DropDownList).SelectedValue = pDS.Tables(0).Rows(i - 1).Item("POS")
            CType(pnlBillingInfo.FindControl("dtDate" & i & "1"), RadDatePicker).SelectedDate = pDS.Tables(0).Rows(i - 1).Item("DateOfServiceFrom")
            CType(pnlBillingInfo.FindControl("dtDate" & i & "2"), RadDatePicker).SelectedDate = pDS.Tables(0).Rows(i - 1).Item("DateOfServiceTo")
            CType(pnlBillingInfo.FindControl("txtDescription" & i), TextBox).Text = pDS.Tables(0).Rows(i - 1).Item("Description")
            CType(pnlBillingInfo.FindControl("txtFromGrid" & i), TextBox).Text = pDS.Tables(0).Rows(i - 1).Item("IsGridItem")
            CType(pnlBillingInfo.FindControl("txtHeading" & i), TextBox).Text = pDS.Tables(0).Rows(i - 1).Item("Heading")
            CType(pnlBillingInfo.FindControl("txtDays" & i), TextBox).Text = pDS.Tables(0).Rows(i - 1).Item("Days")

            CType(pnlBillingInfo.FindControl("txtA" & i), TextBox).Text = pDS.Tables(0).Rows(i - 1).Item("ModifierA")
            CType(pnlBillingInfo.FindControl("txtB" & i), TextBox).Text = pDS.Tables(0).Rows(i - 1).Item("ModifierB")
            CType(pnlBillingInfo.FindControl("txtC" & i), TextBox).Text = pDS.Tables(0).Rows(i - 1).Item("ModifierC")
            CType(pnlBillingInfo.FindControl("txtD" & i), TextBox).Text = pDS.Tables(0).Rows(i - 1).Item("ModifierD")
            CType(pnlBillingInfo.FindControl("txtPointer" & i), TextBox).Text = pDS.Tables(0).Rows(i - 1).Item("Pointer")
            CType(pnlBillingInfo.FindControl("btnCPTSearch" & i), ImageButton).Enabled = False
        Next



        'This loop adds the Current Date to all the unfilled date pickers
        If (pDS.Tables(0).Rows.Count = 1) Then

            For i = 1 To 18
                CType(pnlBillingInfo.FindControl("dtDate" & i & "1"), RadDatePicker).SelectedDate = Now.Date
                CType(pnlBillingInfo.FindControl("dtDate" & i & "2"), RadDatePicker).SelectedDate = Now.Date
            Next

        Else

            For i = pDS.Tables(0).Rows.Count - 1 To 18
                CType(pnlBillingInfo.FindControl("dtDate" & i & "1"), RadDatePicker).SelectedDate = Now.Date
                CType(pnlBillingInfo.FindControl("dtDate" & i & "2"), RadDatePicker).SelectedDate = Now.Date
            Next
        End If



    End Sub








    Private Sub LoadSuperBillOrderInformation()
        Dim lUser As User
        Dim lSuperBill As SuperBill
        Dim lResult As Boolean
        Dim lDS As DataSet = Nothing

        lUser = CType(Session.Item("User"), User)


        lSuperBill = New SuperBill(lUser.ConnectionString)
        lSuperBill.SuperBill.SuperBillId = txtSuperBillTemplateId.Text
        lResult = lSuperBill.GetRecordByID()

        If Not lResult Then
            Return
        End If

        With lSuperBill.SuperBill
            txtOrderBy.Text = lSuperBill.SuperBill.ICDSortBy & "|" & lSuperBill.SuperBill.ICDSortOrder & "|" & _
                                       lSuperBill.SuperBill.CPTSortBy & "|" & lSuperBill.SuperBill.CPTSortOrder
        End With


        loadICD9BillingGrid()
        LoadCPTBillingGrid()

    End Sub

    Private Sub LoadCPTBillingGrid()
        Dim lDS As DataSet = Nothing
        lDS = ClaimMethods.GetCPTForBillingGrid(txtPatientSuperBillId.Text)

        lDS.Tables(0).Columns.Add("Enabled", GetType(Boolean))

        Dim i As Integer
        For i = 0 To lDS.Tables(0).Rows.Count - 1
            lDS.Tables(0).Rows(i).Item("Enabled") = False
            If (Not IsDBNull(lDS.Tables(0).Rows(i).Item("NPI"))) Then
                Me.txtRenderringProviderNPI.Text = lDS.Tables(0).Rows(i).Item("NPI")
            End If
        Next

        lDS.Tables(0).Rows.Add()
        lDS.Tables(0).Rows(lDS.Tables(0).Rows.Count - 1).Item("CPTDate") = Now.Date
        lDS.Tables(0).Rows(lDS.Tables(0).Rows.Count - 1).Item("Charges") = 0.0
        lDS.Tables(0).Rows(lDS.Tables(0).Rows.Count - 1).Item("Fees") = 0.0
        lDS.Tables(0).Rows(lDS.Tables(0).Rows.Count - 1).Item("DateOfServiceTo") = Now.Date
        lDS.Tables(0).Rows(lDS.Tables(0).Rows.Count - 1).Item("DateOfServiceFrom") = Now.Date
        lDS.Tables(0).Rows(lDS.Tables(0).Rows.Count - 1).Item("Enabled") = True
        lDS.Tables(0).Rows(lDS.Tables(0).Rows.Count - 1).Item("Days") = 1
        lDS.Tables(0).Rows(lDS.Tables(0).Rows.Count - 1).Item("Pointer") = 1

        LoadModifier(lDS)


    End Sub

    Private Sub LoadClinic()
        Dim lUser As User
        Dim lClinic As ClinicDB
        Dim lState As StateDB
        Dim lPatientSuperBill As PatientSuperBill
        Dim lFormatedSuperBillId As String

        lUser = CType(Session("User"), User)
        lClinic = ClinicMethods.GetClinic(lUser)
        lPatientSuperBill = New PatientSuperBill(lUser.ConnectionString)

        lblClinicName.Text = lClinic.ClinicName
        lblClinicAddress.Text = lClinic.AddressLine1
        lblClinicCity.Text = lClinic.City
        lblClinicZipCode.Text = lClinic.ZipCode
        lState = StateMethods.GetState(lClinic.StateId)
        lblClinicState.Text = lState.Abbr


        lPatientSuperBill.PatientSuperBill.PatientSuperBillID = txtPatientSuperBillId.Text
        lPatientSuperBill.GetRecordByID()
        lFormatedSuperBillId = Date.Parse(lPatientSuperBill.PatientSuperBill.DateOfService).Year & "-" & Date.Parse(lPatientSuperBill.PatientSuperBill.DateOfService).ToString("MM") & "-" & lPatientSuperBill.PatientSuperBill.PatientSuperBillDisplayID.PadLeft(5, "0")
        lblSuperBillID.Text = lFormatedSuperBillId
    End Sub

    Private Sub LoadPatient(ByVal pPatientSuperBillID As String)
        Dim lDataSet As DataSet = Nothing
        lDataSet = SuperBillMethods.GetPatientSuperBill(pPatientSuperBillID)
        Dim lUser As User = CType(Session("User"), User)

        If (lDataSet IsNot Nothing) AndAlso (lDataSet.Tables(0).Rows.Count > 0) Then


            lblPatientName.Text = lDataSet.Tables(0).Rows(0).Item("PatientName").ToString
            lblPatientDOB.Text = lDataSet.Tables(0).Rows(0).Item("DOB").ToString.Split(" ")(0)
            lblPatientAddress.Text = lDataSet.Tables(0).Rows(0).Item("Address").ToString
            lblPatientCity.Text = lDataSet.Tables(0).Rows(0).Item("City").ToString
            lblPatientState.Text = lDataSet.Tables(0).Rows(0).Item("State").ToString
            lblPatientZipCode.Text = lDataSet.Tables(0).Rows(0).Item("ZipCode").ToString
            lblPrimaryInsuranceCompany.Text = lDataSet.Tables(0).Rows(0).Item("PrimaryInsuranceCompanyName").ToString
            lblSecondaryInsuranceCompany.Text = lDataSet.Tables(0).Rows(0).Item("SecondryInsuranceCompanyName").ToString
            lblGuarantorName.Text = lDataSet.Tables(0).Rows(0).Item("GuarantorName").ToString
            lblBalance.Text = lDataSet.Tables(0).Rows(0).Item("Balance").ToString

            Me.txtCopayAmount.Text = lDataSet.Tables(0).Rows(0).Item("CopayAmount").ToString
            lblCopayAmount.Text = IIf(lDataSet.Tables(0).Rows(0).Item("PaymentMethod").Equals(""), "", lDataSet.Tables(0).Rows(0).Item("CopayAmount").ToString)

            Utility.SelectComboItem(Me.cmbPaymentMethod, lDataSet.Tables(0).Rows(0).Item("PaymentMethod").ToString, False)
            lblPaymentMethod.Text = lDataSet.Tables(0).Rows(0).Item("PaymentMethod").ToString

            If (lDataSet.Tables(0).Rows(0).Item("PaymentMethod").ToString = "Cheque") Then
                Me.dtChequeDate.Enabled = True
                Me.txtChequeNumber.Enabled = True
            Else
                Me.dtChequeDate.Enabled = False
                Me.txtChequeNumber.Enabled = False
            End If
            Me.txtChequeNumber.Text = lDataSet.Tables(0).Rows(0).Item("ChequeNumber").ToString
            lblChequeNumber.Text = lDataSet.Tables(0).Rows(0).Item("ChequeNumber").ToString
            Me.dtChequeDate.SelectedDate = lDataSet.Tables(0).Rows(0).Item("ChequeDate").ToString
            If (lDataSet.Tables(0).Rows(0).Item("ChequeDate").ToString = "1/1/1900 12:00:00 AM") Then
                lblChequeDate.Text = ""
            Else
                lblChequeDate.Text = lDataSet.Tables(0).Rows(0).Item("ChequeDate").ToString.Split(" ")(0)
            End If


            lblDateOfService.Text = lDataSet.Tables(0).Rows(0).Item("DateOfService").ToString.Split(" ")(0) ' This was done to ensure that time does not get appended to the date: cudnt do it in the query cuz it was generalized
            txtSuperBillTemplateId.Text = lDataSet.Tables(0).Rows(0).Item("SuperBillTemplateID").ToString
            Dim lEmployeeDs As New DataSet
            lEmployeeDs = EmployeeMethods.GetEmployeeByID(lUser, lDataSet.Tables(0).Rows(0).Item("PrescriberID").ToString)
            'lblPrescriberName.Text = EmployeeMethods.GetEmployeeByID(lUser, lDataSet.Tables(0).Rows(0).Item("PrescriberID").ToString).Tables(0).Rows(0).Item("EmployeeName")
            lblPrescriberName.Text = lEmployeeDs.Tables(0).Rows(0).Item("EmployeeName")
            If (Me.txtRenderringProviderNPI.Text <> "" And Not Me.txtRenderringProviderNPI.Text Is Nothing) Then
                cmbProvider.SelectedValue = lDataSet.Tables(0).Rows(0).Item("PrescriberID") & "|" & Me.txtRenderringProviderNPI.Text
            Else
                cmbProvider.SelectedValue = lDataSet.Tables(0).Rows(0).Item("PrescriberID") & "|" & lEmployeeDs.Tables(0).Rows(0).Item("ID").ToString.Split("|")(1)
            End If


        End If



    End Sub

    Private Sub loadICD9BillingGrid()
        Dim lDS As DataSet
        lDS = ClaimMethods.GetICDForBillingGrid(txtPatientSuperBillId.Text)

        For x As Integer = 1 To 4
            If Not lDS.Tables(0).Rows.Count > x - 1 Then
                Exit For
            End If

            CType(pnlBillingInfo.FindControl("cmbICD" & x.ToString), RadComboBox).Text = lDS.Tables(0).Rows(x - 1).Item(0)
            CType(pnlBillingInfo.FindControl("txtICDDescription" & x.ToString), TextBox).Text = lDS.Tables(0).Rows(x - 1).Item(1)
            CType(pnlBillingInfo.FindControl("txtICDFromGrid" & x.ToString), TextBox).Text = lDS.Tables(0).Rows(x - 1).Item(2)
        Next


        Select Case lDS.Tables(0).Rows.Count
            Case 1
                cmbICD1.Text = lDS.Tables(0).Rows(0).Item(0)
                txtICDDescription1.Text = lDS.Tables(0).Rows(0).Item(1)
                txtICDFromGrid1.Text = lDS.Tables(0).Rows(0).Item(2)
            Case 2
                cmbICD1.Text = lDS.Tables(0).Rows(0).Item(0)
                txtICDDescription1.Text = lDS.Tables(0).Rows(0).Item(1)
                txtICDFromGrid1.Text = lDS.Tables(0).Rows(0).Item(2)

                cmbICD2.Text = lDS.Tables(0).Rows(1).Item(0)
                txtICDDescription2.Text = lDS.Tables(0).Rows(1).Item(1)
                txtICDFromGrid2.Text = lDS.Tables(0).Rows(1).Item(2)
            Case 3
                cmbICD1.Text = lDS.Tables(0).Rows(0).Item(0)
                txtICDDescription1.Text = lDS.Tables(0).Rows(0).Item(1)
                txtICDFromGrid1.Text = lDS.Tables(0).Rows(0).Item(2)

                cmbICD2.Text = lDS.Tables(0).Rows(1).Item(0)
                txtICDDescription2.Text = lDS.Tables(0).Rows(1).Item(1)
                txtICDFromGrid1.Text = lDS.Tables(0).Rows(1).Item(2)

                cmbICD3.Text = lDS.Tables(0).Rows(2).Item(0)
                txtICDDescription3.Text = lDS.Tables(0).Rows(2).Item(1)
                txtICDFromGrid3.Text = lDS.Tables(0).Rows(2).Item(2)
            Case 4
                cmbICD1.Text = lDS.Tables(0).Rows(0).Item(0)
                txtICDDescription1.Text = lDS.Tables(0).Rows(0).Item(1)
                txtICDFromGrid1.Text = lDS.Tables(0).Rows(0).Item(2)

                cmbICD2.Text = lDS.Tables(0).Rows(1).Item(0)
                txtICDDescription2.Text = lDS.Tables(0).Rows(1).Item(1)
                txtICDFromGrid2.Text = lDS.Tables(0).Rows(1).Item(2)

                cmbICD3.Text = lDS.Tables(0).Rows(2).Item(0)
                txtICDDescription3.Text = lDS.Tables(0).Rows(2).Item(1)
                txtICDFromGrid3.Text = lDS.Tables(0).Rows(2).Item(2)

                cmbICD4.Text = lDS.Tables(0).Rows(3).Item(0)
                txtICDDescription4.Text = lDS.Tables(0).Rows(3).Item(1)
                txtICDFromGrid4.Text = lDS.Tables(0).Rows(3).Item(2)
        End Select

    End Sub
    Private Sub OpenWindow(ByVal pNavigateUrl As String, ByVal pWindowId As String, ByVal pCallBackFunction As String)
        Dim newWindow As New RadWindow()

        newWindow.NavigateUrl = pNavigateUrl
        newWindow.ID = pWindowId
        newWindow.VisibleOnPageLoad = True
        newWindow.Top = 150
        newWindow.Left = 14
        newWindow.Width = Unit.Pixel(700)
        newWindow.Height = Unit.Pixel(315)
        newWindow.VisibleTitlebar = False
        newWindow.VisibleStatusbar = False
        newWindow.BorderStyle = BorderStyle.Solid
        newWindow.ReloadOnShow = True
        newWindow.BackColor = Drawing.Color.Transparent
        newWindow.ClientCallBackFunction = pCallBackFunction
        newWindow.Enabled = True
        newWindow.Visible = True
        'newWindow.Modal = True
        rwmGenerateSuperBill.Windows.Add(newWindow)
    End Sub

    Private Function SavePatientSuperBill() As Integer

        Dim lUser As User
        lUser = CType(Session.Item("User"), User)

        Dim lPatientSuperBillDB As New PatientSuperBillDB()
        Dim lResult As Boolean = False
        Dim lStatus As String = String.Empty

        If checkapprove.Checked Then
            lStatus = "Approved"
        Else
            lStatus = "UnApproved"
        End If

        lPatientSuperBillDB.PatientSuperBillID = txtPatientSuperBillId.Text
        lPatientSuperBillDB.Status = lStatus
        Try
            lPatientSuperBillDB.CopayAmount = CType(Me.txtCopayAmount.Text, Double)
        Catch ex As Exception
            lPatientSuperBillDB.CopayAmount = 0.0
        End Try
        lPatientSuperBillDB.PaymentMethod = Me.cmbPaymentMethod.Text
        lPatientSuperBillDB.ChequeNumber = Me.txtChequeNumber.Text
        If (Me.dtChequeDate.SelectedDate.ToString <> "") Then
            lPatientSuperBillDB.ChequeDate = Me.dtChequeDate.SelectedDate
        End If



        With lPatientSuperBillDB

            .PatientId = txtPatientID.Text
            .DateOfService = lblDateOfService.Text
            .PatientSuperBillID = txtPatientSuperBillId.Text
            .Status = lStatus

        End With


        lResult = GenerateSuperBillMethods.EditPatientSuperBill(lPatientSuperBillDB, pnlBillingInfo, Request.Url.AbsoluteUri, cmbProvider.SelectedItem.Value.Split("|")(1))

        If ((checkapprove.Checked = True) And lResult) Then
            'PatientLedgerMethods.SavePatientLedger(pnlBillingInfo, lPatientSuperBillDB)
        End If


        Return lResult

    End Function
    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSave.Click
        Dim lResult As Boolean

        lResult = SavePatientSuperBill()
        If lResult = True Then
            Response.Redirect("Main.aspx")
        Else
            Me.RadAjaxManager1.Alert("Error Updating Superbill, try again later")
            'lblMessage.Text = "Error Updating Superbill, try again later"
        End If


    End Sub

    Protected Sub btnSaveNPrint_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSavenPrint.Click

        Dim lResult As Boolean
        Dim lScript As String = "javascript:OpenPopUpWindowVisitSummary('PSBPrint.aspx?sid=" & txtPatientSuperBillId.Text & "');"

        If txtApproved.text.equals("A") Then
            lResult = True
        Else
            lResult = SavePatientSuperBill()
        End If

        If lResult = True Then
            RadAjaxManager1.ResponseScripts.Add(lScript)
            RadAjaxManager1.Redirect("../Billing/VisitSearch.aspx")
            'Response.Redirect("PreviewSuperBill.aspx?sid=" & txtPatientSuperBillId.Text)
        Else
            Me.RadAjaxManager1.Alert("Error Updating Superbill, try again later")
        End If
    End Sub

    Private Sub EnableControls(ByVal pControl As Control)
        If TypeOf pControl Is WebControl Then
            CType(pControl, WebControl).Enabled = True
        End If

        For Each child As Control In pControl.Controls
            EnableControls(child)
        Next
    End Sub

    Private Sub DisableControls(ByVal pControl As Control)
        If TypeOf pControl Is WebControl Then
            CType(pControl, WebControl).Enabled = False
        End If

        For Each child As Control In pControl.Controls
            DisableControls(child)
        Next
    End Sub


    Protected Sub btnCPTSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnCPTSearch1.Click, _
                                                                                                                    btnCPTSearch2.Click, _
                                                                                                                    btnCPTSearch3.Click, _
                                                                                                                    btnCPTSearch4.Click, _
                                                                                                                    btnCPTSearch5.Click, _
                                                                                                                    btnCPTSearch6.Click, _
                                                                                                                    btnCPTSearch7.Click, _
                                                                                                                    btnCPTSearch8.Click, _
                                                                                                                    btnCPTSearch9.Click, _
                                                                                                                    btnCPTSearch10.Click, _
                                                                                                                    btnCPTSearch11.Click, _
                                                                                                                    btnCPTSearch12.Click, _
                                                                                                                    btnCPTSearch13.Click, _
                                                                                                                    btnCPTSearch14.Click, _
                                                                                                                    btnCPTSearch15.Click, _
                                                                                                                    btnCPTSearch16.Click, _
                                                                                                                    btnCPTSearch17.Click, _
                                                                                                                    btnCPTSearch18.Click


        Dim lSenderID As String = sender.id.ToString

        Select Case lSenderID
            Case "btnCPTSearch1"
                OpenWindow("SearchCPT.aspx?CPT=" & cmbCPT1.Text & "&lid=1", "rwCPTSearch", "CPTCallBackFunction")
            Case "btnCPTSearch2"

                OpenWindow("SearchCPT.aspx?CPT=" & cmbCPT2.Text & "&lid=2", "rwCPTSearch", "CPTCallBackFunction")

            Case "btnCPTSearch3"

                OpenWindow("SearchCPT.aspx?CPT=" & cmbCPT3.Text & "&lid=3", "rwCPTSearch", "CPTCallBackFunction")

            Case "btnCPTSearch4"

                OpenWindow("SearchCPT.aspx?CPT=" & cmbCPT4.Text & "&lid=4", "rwCPTSearch", "CPTCallBackFunction")

            Case "btnCPTSearch5"

                OpenWindow("SearchCPT.aspx?CPT=" & cmbCPT5.Text & "&lid=5", "rwCPTSearch", "CPTCallBackFunction")

            Case "btnCPTSearch6"

                OpenWindow("SearchCPT.aspx?CPT=" & cmbCPT6.Text & "&lid=6", "rwCPTSearch", "CPTCallBackFunction")

            Case "btnCPTSearch7"

                OpenWindow("SearchCPT.aspx?CPT=" & cmbCPT7.Text & "&lid=7", "rwCPTSearch", "CPTCallBackFunction")

            Case "btnCPTSearch8"

                OpenWindow("SearchCPT.aspx?CPT=" & cmbCPT8.Text & "&lid=8", "rwCPTSearch", "CPTCallBackFunction")

            Case "btnCPTSearch9"

                OpenWindow("SearchCPT.aspx?CPT=" & cmbCPT9.Text & "&lid=9", "rwCPTSearch", "CPTCallBackFunction")

            Case "btnCPTSearch10"

                OpenWindow("SearchCPT.aspx?CPT=" & cmbCPT10.Text & "&lid=10", "rwCPTSearch", "CPTCallBackFunction")

            Case "btnCPTSearch11"

                OpenWindow("SearchCPT.aspx?CPT=" & cmbCPT11.Text & "&lid=11", "rwCPTSearch", "CPTCallBackFunction")

            Case "btnCPTSearch12"

                OpenWindow("SearchCPT.aspx?CPT=" & cmbCPT12.Text & "&lid=12", "rwCPTSearch", "CPTCallBackFunction")

            Case "btnCPTSearch13"

                OpenWindow("SearchCPT.aspx?CPT=" & cmbCPT13.Text & "&lid=13", "rwCPTSearch", "CPTCallBackFunction")

            Case "btnCPTSearch14"

                OpenWindow("SearchCPT.aspx?CPT=" & cmbCPT14.Text & "&lid=14", "rwCPTSearch", "CPTCallBackFunction")

            Case "btnCPTSearch15"

                OpenWindow("SearchCPT.aspx?CPT=" & cmbCPT15.Text & "&lid=15", "rwCPTSearch", "CPTCallBackFunction")

            Case "btnCPTSearch16"

                OpenWindow("SearchCPT.aspx?CPT=" & cmbCPT16.Text & "&lid=16", "rwCPTSearch", "CPTCallBackFunction")

            Case "btnCPTSearch17"

                OpenWindow("SearchCPT.aspx?CPT=" & cmbCPT17.Text & "&lid=17", "rwCPTSearch", "CPTCallBackFunction")

            Case "btnCPTSearch18"
                OpenWindow("SearchCPT.aspx?CPT=" & cmbCPT18.Text & "&lid=18", "rwCPTSearch", "CPTCallBackFunction")
        End Select

    End Sub

    Protected Sub btnICDSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnICD1Search.Click, btnICD2Search.Click, btnICD3Search.Click, btnICD4Search.Click
        Dim lSenderID As String = sender.id.ToString

        Select Case lSenderID
            Case "btnICD1Search"
                OpenWindow("SearchICD9.aspx?icd=" & cmbICD1.Text & "&lid=1", "rwICD9Search", "ICDCallBackFunction")
            Case "btnICD2Search"
                OpenWindow("SearchICD9.aspx?icd=" & cmbICD2.Text & "&lid=2", "rwICD9Search", "ICDCallBackFunction")
            Case "btnICD3Search"
                OpenWindow("SearchICD9.aspx?icd=" & cmbICD3.Text & "&lid=3", "rwICD9Search", "ICDCallBackFunction")
            Case "btnICD4Search"
                OpenWindow("SearchICD9.aspx?icd=" & cmbICD4.Text & "&lid=4", "rwICD9Search", "ICDCallBackFunction")
        End Select
    End Sub


    Protected Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnCancel.Click
        Response.Redirect("VisitSearch.aspx")
    End Sub

    Protected Sub cmbICD1_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbICD1.ItemsRequested, _
                                                                                                                                       cmbICD2.ItemsRequested, _
                                                                                                                                       cmbICD3.ItemsRequested, _
                                                                                                                                       cmbICD4.ItemsRequested


        Try

            Select Case o.id
                Case "cmbICD1"
                    SuperBillMethods.LoadICDForCombo(cmbICD1, e.Text)
                Case "cmbICD2"
                    SuperBillMethods.LoadICDForCombo(cmbICD2, e.Text)
                Case "cmbICD3"
                    SuperBillMethods.LoadICDForCombo(cmbICD3, e.Text)
                Case "cmbICD4"
                    SuperBillMethods.LoadICDForCombo(cmbICD4, e.Text)
            End Select


        Catch ex As Exception
            Dim lLogID As Integer
            lLogID = ErrorLogMethods.LogError(ex, "EditPatientSuperBill.aspx\cmbICD1_ItemsRequested :")
        End Try
    End Sub



    Protected Sub cmbCPT_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbCPT1.ItemsRequested, _
                                                                                                                                      cmbCPT2.ItemsRequested, _
                                                                                                                                      cmbCPT3.ItemsRequested, _
                                                                                                                                      cmbCPT4.ItemsRequested, _
                                                                                                                                      cmbCPT5.ItemsRequested, _
                                                                                                                                      cmbCPT6.ItemsRequested, _
                                                                                                                                      cmbCPT7.ItemsRequested, _
                                                                                                                                      cmbCPT8.ItemsRequested, _
                                                                                                                                      cmbCPT9.ItemsRequested, _
                                                                                                                                      cmbCPT10.ItemsRequested, _
                                                                                                                                      cmbCPT11.ItemsRequested, _
                                                                                                                                      cmbCPT12.ItemsRequested, _
                                                                                                                                      cmbCPT13.ItemsRequested, _
                                                                                                                                      cmbCPT14.ItemsRequested, _
                                                                                                                                      cmbCPT15.ItemsRequested, _
                                                                                                                                      cmbCPT16.ItemsRequested, _
                                                                                                                                      cmbCPT17.ItemsRequested, _
                                                                                                                                      cmbCPT18.ItemsRequested


        Try

            Select Case o.id
                Case "cmbCPT1"
                    SuperBillMethods.LoadCPTForCombo(cmbCPT1, e.Text)
                Case "cmbCPT2"
                    SuperBillMethods.LoadCPTForCombo(cmbCPT2, e.Text)
                Case "cmbCPT3"
                    SuperBillMethods.LoadCPTForCombo(cmbCPT3, e.Text)
                Case "cmbCPT4"
                    SuperBillMethods.LoadCPTForCombo(cmbCPT4, e.Text)
                Case "cmbCPT5"
                    SuperBillMethods.LoadCPTForCombo(cmbCPT5, e.Text)
                Case "cmbCPT6"
                    SuperBillMethods.LoadCPTForCombo(cmbCPT6, e.Text)
                Case "cmbCPT7"
                    SuperBillMethods.LoadCPTForCombo(cmbCPT7, e.Text)
                Case "cmbCPT8"
                    SuperBillMethods.LoadCPTForCombo(cmbCPT8, e.Text)
                Case "cmbCPT9"
                    SuperBillMethods.LoadCPTForCombo(cmbCPT9, e.Text)
                Case "cmbCPT10"
                    SuperBillMethods.LoadCPTForCombo(cmbCPT10, e.Text)
                Case "cmbCPT11"
                    SuperBillMethods.LoadCPTForCombo(cmbCPT11, e.Text)
                Case "cmbCPT12"
                    SuperBillMethods.LoadCPTForCombo(cmbCPT12, e.Text)
                Case "cmbCPT13"
                    SuperBillMethods.LoadCPTForCombo(cmbCPT13, e.Text)
                Case "cmbCPT14"
                    SuperBillMethods.LoadCPTForCombo(cmbCPT14, e.Text)
                Case "cmbCPT15"
                    SuperBillMethods.LoadCPTForCombo(cmbCPT15, e.Text)
                Case "cmbCPT16"
                    SuperBillMethods.LoadCPTForCombo(cmbCPT16, e.Text)
                Case "cmbCPT17"
                    SuperBillMethods.LoadCPTForCombo(cmbCPT17, e.Text)
                Case "cmbCPT18"
                    SuperBillMethods.LoadCPTForCombo(cmbCPT18, e.Text)
            End Select


        Catch ex As Exception
            Dim lLogID As Integer
            lLogID = ErrorLogMethods.LogError(ex, "EditPatientSuperBill.aspx\cmbCPT_ItemsRequested :")
        End Try
    End Sub




End Class
