
Partial Class Billing_PatientLedgerPageComboStreamer
    Inherits System.Web.UI.Page
    Protected Sub cmbPaymentApplyPayerName_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbPatient.ItemsRequested
        If (Session.Count = 0) Then
            Exit Sub
        End If

        If e.Text = "" Then
            Exit Sub
        End If
        Dim lDs As New DataSet
        Dim lUser As User
        Try
            lUser = CType(Session.Item("User"), User)
            lDs = PatientMethods.GetPatientsLastNameForPatientLedger(Utility.AdjustApostrophie(e.Text.Trim()), lUser)
            cmbPatient.DataSource = lDs
            cmbPatient.DataTextField = "Full"
            cmbPatient.DataValueField = "PatientID"
            cmbPatient.DataBind()
        Catch ex As Exception
            ErrorLogMethods.LogError(ex, "EditPatient.aspx\RadComboBox1_ItemsRequested()")
            'Response.Redirect("Error.aspx")
        Finally
            lDs.Dispose()
        End Try
    End Sub
End Class
