Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports System.Data
Imports ElixirLibrary
Imports System.Data.SqlClient
Partial Class Billing_PatientLedger
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim lDs As New DataSet
        Dim lDstemp As New DataSet
        Dim lUser As User = CType(HttpContext.Current.Session("User"), User)
        Dim lConnection As New Connection(lUser.ConnectionString)
        Dim lQuery As String = "", lPatientName, lFromDate, lToDate As String
        lPatientName = Request.QueryString.Get(0).ToString.Split("|")(0)
        lFromDate = Request.QueryString.Get(0).ToString.Split("|")(1)
        lToDate = Request.QueryString.Get(0).ToString.Split("|")(2)


        lQuery = "Select PL.ReferenceDate,PL.Description,PL.Debit,PL.Credit,PL.Adjustment,PL.Reference,Pt.AddressLine1,Pt.FirstName + ' ' + Pt.LastName As PatientName " _
        & "from PatientLedger PL inner join Patient Pt on " _
        & " PL.PatientID = Pt.PatientID where PL.PatientID='" & lPatientName & "' And " _
        & "PL.ReferenceDate between '" & lFromDate & "' And '" & lToDate & "'"

        lDs = lConnection.ExecuteQuery(lQuery)
        lDs.Tables(0).TableName = "PatientLedger"

        ''to get the clinic info....
        lDs.Tables.Add(GetClinicID())
        
        CrystalReportViewer1.DisplayGroupTree = True
        CrystalReportViewer1.HasCrystalLogo = False
        CrystalReportViewer1.BestFitPage = True

        Dim myReportDocument As New ReportDocument()
         

        myReportDocument.Load(Server.MapPath("Reports/PatientLedger.rpt"))
        myReportDocument.SetDataSource(lDs)

        Session.Add("ReportDocument", myReportDocument)

        CrystalReportViewer1.ReportSource = myReportDocument
        CrystalReportViewer1.DataBind()
    End Sub

 Private Function GetClinicID() As DataTable
        Dim ldsClinic As New DataSet
        Dim lUser As User
        Dim lds1, ldsclinicinfo As New DataSet
        Dim ldt, ldtClinicInfo As New DataTable
        lUser = CType(Session.Item("User"), User)

        Dim lCond As String
        lCond = ""

        lds1 = ClinicMethods.GetAllRecords(lUser)
        ldt = lds1.Tables(0).Copy()

        ldt.TableName = "ClinicInfo"

        Return ldt

 End Function

    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload

        If Session("ReportDocument") IsNot Nothing Then
            Dim myReportDocument As ReportDocument
            myReportDocument = CType(Session("ReportDocument"), ReportDocument)
            myReportDocument.Close()
            myReportDocument.Dispose()
            Session.Remove("ReportDocument")
        End If
    End Sub
End Class
