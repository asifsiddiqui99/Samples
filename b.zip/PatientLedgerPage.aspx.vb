Imports Telerik.WebControls

Partial Class Billing_PatientLedgerPage
    Inherits System.Web.UI.Page
    Dim mBalance As Double = 0.0

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim queryString As NameValueCollection = Nothing
        Dim lPatientID As String
        Try
            Me.cmbPatient.Focus()
            If IsPostBack = False Then
                dpTransactionPeriodTo.SelectedDate = Date.Now
                dpTransactionPeriodFrom.SelectedDate = Date.Now.AddMonths(-6)
                dpTransactionPeriodTo.MaxDate = Date.Now
                lblCurrentBalance.Text = "$0"
                If (Request.QueryString.Count > 0) Then
                    queryString = Encryption.DecryptQueryString(Request.QueryString.ToString())
                    If (queryString IsNot Nothing) Then
                        lPatientID = queryString("id").ToString
                        txtPatientID.Text = lPatientID
                        btnBackPS.Visible = True
                        mBalance = 0.0
                        'LoadLedger()
                        Dim lPatient As New PatientDBExtended
                        Dim lUser As User
                        lUser = CType(Session.Item("User"), User)
                        lPatient = PatientMethods.LoadPatientsById(lPatientID, lUser)
                        cmbPatient.Text = lPatient.LastName & "," & lPatient.FirstName
                        cmbPatient.Value = lPatient.PatientID
                    End If
                End If
            End If
        Catch ex As Exception
            Dim lLogID As String = String.Empty
            lLogID = ErrorLogMethods.LogError(ex, " Billing_PatientLedgerPage.aspx\Page_Load()")
            Response.Redirect("~/ErrorPage.aspx?LogID=" & lLogID, False)
        End Try
    End Sub

    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSearch.Click
        Try
            'txtPatientID.Text = ""
            'btnBackPS.Visible = False
            'If (cmbPatient.Text <> "") Then
            txtHiddenPatientId.Text = cmbPatient.Value
            mBalance = 0.0
            grdSearch.Visible = True
            grdSearch.Rebind()
            'Else
            'grdSearch.DataSource = Nothing
            'grdSearch.DataBind()
            'lblPrimary.Text = ""
            'lblSecondary.Text = ""
            'Response.Write("<script>alert('Please select patient');</script>")
            'End If
            'grdSearch.Rebind()

            ' Start => Added by: Affan Toor | Date: 24-09-14 | Defect#: 2297 
            Dim lFromDate As Date
            Dim lToDate As Date

            Try
                If (txtHiddenPatientId.Text <> "") Then
                    lFromDate = dpTransactionPeriodFrom.SelectedDate
                    lToDate = dpTransactionPeriodTo.SelectedDate.Value.Date

                    Dim lEncryptedPart As String = ElixirLibrary.Encryption.EncryptQueryString("value=" & txtHiddenPatientId.Text & "|" & lFromDate & "|" & lToDate)
                    btnGenerateReport.Attributes.Add("OnClick", "window.open('ReportPatientLedger.aspx" & lEncryptedPart & "','winPrn','toolbar=0,scrollbars=1,location=0,statusbar=0,menubar=0,resizable=1,width=900,height=800,left=200,top=80'); return false;")
                Else
                    Response.Write("<script>alert('Please select patient');</script>")
                End If
            Catch ex As Exception

            End Try
            ' End => Added by: Affan Toor | Date: 24-09-14 | Defect#: 2297 
        Catch ex As Exception
            Dim lLogID As String = String.Empty
            lLogID = ErrorLogMethods.LogError(ex, " Billing_PatientLedgerPage.aspx\btnSearch_Click()")
            Response.Redirect("~/ErrorPage.aspx?LogID=" & lLogID, False)
        End Try
    End Sub

    Protected Sub btnMirror_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnMirror.Click
        Dim newWindow As RadWindow
        Try
            newWindow = New RadWindow()
            If (cmbPatient.Text.ToString.Split(",").Length = 1) Then
                newWindow.NavigateUrl = "PatientSearch.aspx?srch=" & Utility.AdjustApostrophie(Me.cmbPatient.Text.ToString.Split(",")(0)) & "|" & "" & ""
            ElseIf (cmbPatient.Text.ToString.Split(",").Length > 1) Then
                newWindow.NavigateUrl = "PatientSearch.aspx?srch=" & Utility.AdjustApostrophie(Me.cmbPatient.Text.ToString.Split(",")(0)) & "|" & Me.cmbPatient.Text.ToString.Split(",")(1) & ""
            Else

            End If
            newWindow.ID = "rwPrimaryInsurer"
            newWindow.VisibleOnPageLoad = True
            newWindow.Top = 220
            newWindow.Left = 280
            newWindow.Width = Unit.Pixel(697)
            newWindow.Height = Unit.Pixel(400)
            newWindow.VisibleTitlebar = False
            newWindow.VisibleStatusbar = False
            newWindow.BorderStyle = BorderStyle.Solid
            newWindow.ReloadOnShow = True
            newWindow.BackColor = Drawing.Color.Transparent
            newWindow.ClientCallBackFunction = "PatientSearchCallBackFunction"
            newWindow.Enabled = True
            newWindow.Visible = True
            rwmSuperBill.Windows.Add(newWindow)
        Catch ex As Exception
            Dim lLogID As String = String.Empty
            lLogID = ErrorLogMethods.LogError(ex, " Billing_PatientLedgerPage.aspx\btnMirror_Click() ")
            Response.Redirect("~/ErrorPage.aspx?LogID=" & lLogID, False)
        End Try
    End Sub

    Protected Sub btnPostPay_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnPostPay.Click
        Try
            Response.Redirect("~/Billing/PostNewPayment.aspx", False)
        Catch ex As Exception
            Dim lLogID As String = String.Empty
            lLogID = ErrorLogMethods.LogError(ex, " Billing_PatientLedgerPage.aspx\btnPostPay_Click()")
            Response.Redirect("~/ErrorPage.aspx?LogID=" & lLogID, False)
        End Try
    End Sub

    Protected Sub grdSearch_ItemDataBound(ByVal sender As Object, ByVal e As Telerik.WebControls.GridItemEventArgs) Handles grdSearch.ItemDataBound
        Dim lDate As Date
        Dim lBalance As Double = 0.0

        Dim lTextBox As New Label
        Try
            If (e.Item.ItemType = Telerik.WebControls.GridItemType.Item Or e.Item.ItemType = Telerik.WebControls.GridItemType.AlternatingItem) Then
                lDate = e.Item.Cells(2).Text
                'If (lDate.Date = "1/1/1900") Then
                '    e.Item.Cells(2).Text = Me.dpTransactionPeriodFrom.SelectedDate.Value.AddDays(-1).Date
                'Else
                e.Item.Cells(2).Text = lDate.Date
                'End If

                lBalance = mBalance + CType(e.Item.Cells(6).Text, Double) - CType(e.Item.Cells(7).Text, Double)
                mBalance = Math.Round(lBalance, 4)
                ''mBalance = lBalance
                lTextBox = CType(e.Item.FindControl("txtBalance"), Label)
                If (mBalance < 0) Then
                    lTextBox.Text = "(" & FormatNumber(mBalance.ToString.Remove(0, 1), 2, , , TriState.False) & ")"
                Else
                    lTextBox.Text = FormatNumber(mBalance, 2, , , TriState.False)
                End If
                If (e.Item.Cells(6).Text = "") Then
                    e.Item.Cells(6).Text = e.Item.Cells(6).Text = FormatNumber(0, 2, , , TriState.False)
                Else
                    e.Item.Cells(6).Text = FormatNumber(e.Item.Cells(6).Text, 2, , , TriState.False)
                End If
                e.Item.Cells(7).Text = FormatNumber(e.Item.Cells(7).Text, 2, , , TriState.False)
                e.Item.Cells(8).Text = FormatNumber(e.Item.Cells(8).Text, 2, , , TriState.False)

                If (e.Item.Cells(18).Text.ToUpper = "V") Then
                    e.Item.Cells(5).Text = e.Item.Cells(5).Text & " : " & e.Item.Cells(10).Text
                End If

                'Add By:Kanwal Jeet

                Dim lTransType As String = e.Item.Cells(18).Text
                Dim lDataItem As GridDataItem = CType(e.Item, GridDataItem)
                Dim lHyplnk As HyperLink = CType(lDataItem.Cells(4).Controls(0), HyperLink)

                If lTransType = "V" Then
                    'Dim lReferenceId As Integer = e.Item.Cells(12).Text
                    lHyplnk.Attributes.Add("onclick", "window.open('VisitSummary.aspx" + ElixirLibrary.Encryption.EncryptQueryString("sid=" & e.Item.Cells(12).Text) + "','','left=20,top=20,width=1050,height=700,toolbar=0,scrollbars=1','_blank');")
                Else
                    'Dim lReferenceId2 As Integer = e.Item.Cells(14).Text
                    lHyplnk.Attributes.Add("onclick", "window.open('VisitSummary.aspx" + ElixirLibrary.Encryption.EncryptQueryString("sid=" & e.Item.Cells(14).Text) + "','','left=20,top=20,width=1050,height=700,toolbar=0,scrollbars=1','_blank');")
                End If




                'Dim lDataItem As GridDataItem = CType(e.Item, GridDataItem)
                'Dim lHyplnk As HyperLink = CType(lDataItem.Cells(3).Controls(0), HyperLink)
                ''lHyplnk.Target = "_blank"

                '' lHyplnk.NavigateUrl = "VisitSummary.aspx" + ElixirLibrary.Encryption.EncryptQueryString("sid=" & e.Item.Cells(24).Text)
                'lHyplnk.Attributes.Add("onclick", "window.open('VisitSummary.aspx" + ElixirLibrary.Encryption.EncryptQueryString("sid=" & e.Item.Cells(25).Text) + "','','left=20,top=20,width=1050,height=700,toolbar=0,scrollbars=1','_blank');")
            End If


        Catch ex As Exception
            Dim lLogID As String = String.Empty
            lLogID = ErrorLogMethods.LogError(ex, " Billing_PatientLedgerPage.aspx\grdSearch_ItemDataBound()")
            Response.Redirect("~/ErrorPage.aspx?LogID=" & lLogID, False)
        End Try
    End Sub

    'Protected Sub grdSearch_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdSearch.NeedDataSource

    'End Sub

    Protected Sub btnGenerateReport_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnGenerateReport.Click
        ' Edited by Affan Toor | Date: 24-09-14 | Defect#: 2297 
        'Dim lFromDate As Date
        'Dim lToDate As Date
        Try

            If (txtHiddenPatientId.Text <> "") Then
                'lFromDate = dpTransactionPeriodFrom.SelectedDate
                'lToDate = dpTransactionPeriodTo.SelectedDate.Value.Date

                'Dim lEncryptedPart As String = ElixirLibrary.Encryption.EncryptQueryString("value=" & txtHiddenPatientId.Text & "|" & lFromDate & "|" & lToDate)
                'Dim lScript As String = "window.open('ReportPatientLedger.aspx" & lEncryptedPart & "','winPrn','toolbar=0,scrollbars=1,location=0,statusbar=0,menubar=0,resizable=1,width=900,height=800,left=200,top=80');"
                ''Page.RegisterStartupScript("calllScript", lScript)
                'Response.Write("<script>" & lScript & ";</script>")
            Else
                Response.Write("<script>alert('Please select patient');</script>")
            End If
        Catch ex As Exception
            Dim lLogID As String = String.Empty
            lLogID = ErrorLogMethods.LogError(ex, " Billing_PatientLedgerPage.aspx\btnGenerateReport_Click()")
            Response.Redirect("~/ErrorPage.aspx?LogID=" & lLogID, False)
        End Try

    End Sub
    Public Sub LoadLedger()
        Try
            Dim ldatatable As New DataTable
            Dim lDS As New DataSet
            Dim lCurrentBAL As Double = 0.0
            If (txtHiddenPatientId.Text <> "") Then
                lDS = PatientLedgerMethods.GetPatientLedger(txtHiddenPatientId.Text, dpTransactionPeriodFrom.SelectedDate.Value.Date, dpTransactionPeriodTo.SelectedDate.Value.Date)
                If (lDS.Tables.Count > 0 AndAlso lDS.Tables(0).Rows.Count > 0) Then
                    grdSearch.DataSource = lDS
                    'grdSearch.DataBind()
                    lCurrentBAL = lDS.Tables(0).Rows(0).Item("CurrentBalance")
                    If (lDS.Tables(0).Rows(0).Item("CurrentBalance").ToString.Substring(0, 1) = "-") Then
                        lblCurrentBalance.Text = "$(" & lCurrentBAL.ToString("##0.00").Remove(0, 1) & ")"
                    Else
                        lblCurrentBalance.Text = "$" & lCurrentBAL.ToString("##0.00")
                    End If
                Else
                    grdSearch.DataSource = ldatatable
                    'grdSearch.DataBind()
                End If
            ElseIf (txtPatientID.Text <> "") Then
                lDS = PatientLedgerMethods.GetPatientLedger(txtPatientID.Text, dpTransactionPeriodFrom.SelectedDate.Value.Date, dpTransactionPeriodTo.SelectedDate.Value.Date)
                If (lDS.Tables.Count > 0 AndAlso lDS.Tables(0).Rows.Count > 0) Then
                    grdSearch.DataSource = lDS
                    'grdSearch.DataBind()
                    lCurrentBAL = lDS.Tables(0).Rows(0).Item("CurrentBalance")
                    If (lDS.Tables(0).Rows(0).Item("CurrentBalance").ToString.Substring(0, 1) = "-") Then
                        lblCurrentBalance.Text = "$(" & lCurrentBAL.ToString("##0.00").Remove(0, 1) & ")"
                    Else
                        lblCurrentBalance.Text = "$" & lCurrentBAL.ToString("##0.00")
                    End If
                Else
                    grdSearch.DataSource = ldatatable
                    'grdSearch.DataBind()
                End If
            Else
                'Response.Write("<script>alert('Please select patient');</script>")
            End If
            
        Catch ex As Exception
            Dim lLogID As String = String.Empty
            lLogID = ErrorLogMethods.LogError(ex, " Billing_PatientLedgerPage.aspx\grdSearch_NeedDataSource()")
            Response.Redirect("~/ErrorPage.aspx?LogID=" & lLogID, False)
        End Try
    End Sub



    Protected Sub cmbPatient_SelectedIndexChanged(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxSelectedIndexChangedEventArgs) Handles cmbPatient.SelectedIndexChanged

        Dim lPatientld As Integer
        Dim lPatientName As String()
        Try
            lPatientName = cmbPatient.Value.Split("|"c)
            lPatientld = lPatientName(0)
            LoadPriSecIns(lPatientld)

        Catch ex As Exception

        End Try

    End Sub

    Public Function LoadPriSecIns(ByVal pPatientId As Integer) As Boolean

        Dim lPatient As PatientExtended
        Dim lUser As New User
        Dim lPatientId As String = pPatientId

        Try

            lUser = CType(Session.Item("User"), User)
            lPatient = New PatientExtended(lUser.ConnectionString)
            lPatient.Patient.PatientID = lPatientId

            lPatient.GetPatientInsCompanyByID()

            If lPatient.Patient.PrimaryInsurance.InsuranceCompanyName <> "" Then
                lblPrimary.Text = lPatient.Patient.PrimaryInsurance.InsuranceCompanyName
            Else
                lblPrimary.Text = "Not available"
            End If

            If lPatient.Patient.SecondaryInsurance.InsuranceCompanyName <> "" Then
                lblSecondary.Text = lPatient.Patient.SecondaryInsurance.InsuranceCompanyName
            Else
                lblSecondary.Text = "Not available"
            End If

            Return True
        Catch ex As Exception
            Dim lLogID As String = String.Empty
            lLogID = ErrorLogMethods.LogError(ex, " Billing_PatientLedgerPage.aspx\LoadPriSecIns(ByVal pPatientId As Integer)")
            Response.Redirect("~/ErrorPage.aspx?LogID=" & lLogID, False)
        End Try
    End Function
    Protected Sub btnBackPS_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnBackPS.Click
        Dim lPatientID As String
        Try
            lPatientID = ElixirLibrary.Encryption.EncryptQueryString("id=" & txtPatientID.Text)
            Response.Redirect("selectpatient.aspx" & lPatientID)
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub grdSearch_NeedDataSource(source As Object, e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdSearch.NeedDataSource
        Try
            If grdSearch.Visible Then
                LoadLedger()
            End If

        Catch ex As Exception
            Dim lLogID As String = String.Empty
            lLogID = ErrorLogMethods.LogError(ex, " Billing_PatientLedgerPage.aspx\grdSearch_NeedDataSource()")
            Response.Redirect("~/ErrorPage.aspx?LogID=" & lLogID, False)

        End Try
    End Sub
End Class
