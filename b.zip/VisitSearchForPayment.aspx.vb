Imports Telerik.WebControls
Partial Class Billing_VisitSearchForPayment
    Inherits System.Web.UI.Page
Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        

        If (Page.IsPostBack = False) Then
        rdpFrom.SelectedDate = Date.Now.AddYears(-1)
        rdpTo.SelectedDate = Date.Now

        End If

    End Sub
    Private Sub CreateCondition(ByRef pCondition As String)
        ''line changed by talha....

        If Not txtVisitID.Text.Equals("") Then
            pCondition &= " And VisitDisplayID = '" & Utility.AdjustApostrophie(txtVisitID.Text) & "' "
        End If

        pCondition &= " And VisitDisplayDate between '" & rdpFrom.SelectedDate.GetValueOrDefault & "' and '" & rdpTo.SelectedDate.GetValueOrDefault & "'"
    End Sub

  Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSearch.Click

        grdVisit.Visible = True
        grdVisit.Rebind()
    End Sub
 
     Protected Sub btnClose_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnClose.Click
     InjectScript.Text = "<script>CloseOnly()</Script>"
     End Sub

    Protected Sub grdClaim_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdVisit.NeedDataSource
        Dim lUser As User
        Dim lCondition As String = ""


            CreateCondition(lCondition)

            lUser = CType(Session.Item("User"), User)
            ClaimMethods.LoadClaimGrid(grdVisit, lCondition, lUser)

    End Sub

    Protected Sub grdClaim_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdVisit.SelectedIndexChanged
       Dim lString As String = ""


        lString = grdVisit.SelectedItems.Item(0).Cells(2).Text & "|" & grdVisit.SelectedItems.Item(0).Cells(3).Text
        InjectScript.Text = "<script>CloseOnReload('" & lString & "')</Script>"

    End Sub
     Protected Sub grdVisit_ItemDataBound(ByVal sender As Object, ByVal e As Telerik.WebControls.GridItemEventArgs) Handles grdVisit.ItemDataBound
       If e.Item.ItemType = GridItemType.Item Or e.Item.ItemType = GridItemType.AlternatingItem Then

            Dim lItem As GridDataItem = CType(e.Item, GridDataItem)
            Dim lStatus As String = e.Item.Cells(10).Text
            Dim lButton As LinkButton

            If lStatus.ToUpper.Equals("APPROVED") Then

                lButton = CType(lItem("ClaimID").Controls(0), LinkButton)
                lButton.ForeColor = Drawing.Color.Red

            Else 'Remove the Generate HCFA button from the Unapproved links

            lButton = CType(lItem("ClaimID").Controls(0), LinkButton)
            lButton.ForeColor = Drawing.Color.Green

            End If



        End If
    End Sub
End Class
