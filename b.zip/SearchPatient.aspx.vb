Imports Patient
Imports Telerik.WebControls
Imports iTextSharp.text.pdf
Partial Class Billing_SearchPatient
    Inherits System.Web.UI.Page
    Dim mSpecificVisitTemplatePath As String
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim queryString As NameValueCollection = Nothing
        Dim lPatienExtended As PatientExtended
        Dim lResult As Boolean

        If (Session("EditPatientID") Is Nothing) Then
            Session("EditPatientID") = ""
        End If



        Dim lUser As User
        'Dim lIsAuthorize As Boolean
        'Dim lUserRoles As UserRoles
        Dim lLogId As Int32 = 0
        Dim lStrScript As String

        If Not Page.IsPostBack Then
            queryString = Encryption.DecryptQueryString(Request.QueryString.ToString())
            If (queryString IsNot Nothing) Then
                Me.txtPatientID.Text = queryString("id").ToString
            Else
                Response.Write("<Script>alert('Please select a patient before proceeding');window.location='SelectPatient.aspx';</Script>")
                Return
            End If
            cmbSuperBill.Focus()
            Try
                lUser = CType(Session.Item("User"), User)
                lPatienExtended = New PatientExtended(lUser.ConnectionString)
                lPatienExtended.Patient.PatientID = Me.txtPatientID.Text
                lResult = lPatienExtended.GetRecordByID()
                If Not lResult Then
                    Response.Write("<Script>alert('Please select a patient before proceeding');window.location='SelectPatient.aspx';</Script>")
                    Return
                End If


                lblPatientName.Text = lPatienExtended.Patient.LastName & "," & lPatienExtended.Patient.FirstName

                lblPatientDOB.Text = lPatienExtended.Patient.DOB
                lblPatientPhone.Text = Regex.Replace(lPatienExtended.Patient.HomePhone.ToString, "^\D*(\d)\D*(\d)\D*(\d)\D*(\d)\D*(\d)\D*(\d)\D*(\d)\D*(\d)\D*(\d)\D*(\d)\D*$", "($1$2$3) $4$5$6-$7$8$9$10")

                'lUserRoles = New UserRoles(lUser.ConnectionString)


                'Try
                '    '********* Check User Validity ************
                '    lIsAuthorize = lUserRoles.CheckPageAuthorization(lUser.UserId, "EditPatientTS.aspx")
                '    If Not lIsAuthorize Then
                '        Response.Redirect("unauthorization.aspx")
                '    End If
                'Catch ex As Exception
                '    ErrorLogMethods.LogError(ex, "PatientPreview.aspx\Page_Load().CheckPageAuthorization()")
                '    Response.Redirect("unauthorization.aspx")
                'End Try
                LoadSuperBillCombo()
                LoadProviderCombo()
                'LoadPatient(Me.txtPatientID.Text)

                RadDatePicker1.SelectedDate = Date.Now()


            Catch ex As Exception
                lLogId = ErrorLogMethods.LogError(ex, "SearchPatient.aspx\Page_Load()")
                Response.Redirect("ErrorPage.aspx?LogId=" & lLogId)
            End Try

        End If

        If (Me.cmbPaymentMethod.Text.ToUpper <> "CHECK") Then
            lStrScript = "<script language=javascript id='DisableCheckDateScript'>DisableCheckDate();</script>"
            Page.RegisterStartupScript("callDisableCheck", lStrScript)
        End If


    End Sub
    Public Sub LoadProviderCombo()
        Dim lUser As User
        Dim lID As String
        Try
            lUser = CType(Session("User"), User)
            EmployeeMethods.LoadDoctorsCombo(cmbProvider)
            lID = lUser.UserId & "|" & lUser.NPI

            If (cmbProvider.FindItemIndexByValue(lID) <> -1) Then
                cmbProvider.SelectedValue = lID
            Else
                cmbProvider.SelectedIndex = 0
            End If

        Catch ex As Exception

        End Try
    End Sub

  

    

   
    Protected Sub ibtnLaunchSuperBill_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ibtnLaunchSuperBill.Click

       

        If cmbSuperBill.SelectedIndex = -1 Then
            Response.Write("<Script>alert('Please create Super Bill Template before proceeding');</Script>")
            Return

        End If


        Dim lUser As User
        lUser = CType(Session.Item("User"), User)


        'Called to fill the textBoxes  & for the following check
       

        Dim lResult2 As Integer
        Dim lLaunchBillUrl As String = ""


        lResult2 = SavePatientSuperBill()


        Dim lquerystring As String = ""

        Try
            Dim lPatientId As String = txtPatientID.Text
            lquerystring = ElixirLibrary.Encryption.EncryptQueryString("sid=" & lResult2.ToString() & "|" & lPatientId & "|" & cmbSuperBill.SelectedValue.ToString() & "|0" & "|U")
            lLaunchBillUrl = "EditPatientSuperBill.aspx" + lquerystring
        Catch ex As Exception
            ErrorLogMethods.LogError(ex, "PatientPreview.aspx\ibtnLaunchSuperBill_Click()")
        End Try

        If lResult2 <> 0 Then
            If (chkSpecificSB.Checked = True AndAlso mSpecificVisitTemplatePath <> "") Then
                lquerystring = ElixirLibrary.Encryption.EncryptQueryString("Path=" & mSpecificVisitTemplatePath)
                Response.Write("<Script>window.open('ViewSpecificSB.aspx" & lquerystring & "');window.location='" & lLaunchBillUrl & " ';</Script>")
            Else
                Response.Redirect(lLaunchBillUrl)
            End If
        Else
            Response.Write("<Script>alert('Failed to Update Patient/Launch SuperBill');</Script>")
        End If

    End Sub

    Public Sub LoadSuperBillCombo()
        Dim lDs As New DataSet
        Dim lUser As User
        Dim lLogId As Int32 = 0

        Dim lObjSuperBill As SuperBill
        Try
            lUser = CType(Session.Item("User"), User)
            lObjSuperBill = New SuperBill(lUser.ConnectionString)
            lDs = lObjSuperBill.GetAllRecords()
            cmbSuperBill.DataSource = lDs
            cmbSuperBill.DataBind()
        Catch ex As Exception
            lLogId = ErrorLogMethods.LogError(ex, "PatientPreview.aspx\LoadSuperBillCombo()")
            Response.Redirect("ErrorPage.aspx?LogId=" & lLogId)
            'Me.cmbSuperBill.DataSource = Nothing
        Finally
            lDs.Dispose()
        End Try

    End Sub

    Private Function SavePatientSuperBill() As Integer
        Dim lUser As User
        Dim lResultPrimaryInsurance As Boolean
        Dim lResultSecondaryInsurance As Boolean

        Dim lPatienExtended As PatientExtended
        Dim lPatientInsurancePrimary As PatientInsurance
        Dim lPatientInsuranceSecondary As PatientInsurance
        Dim lTempPatient As PatientExtended
        Dim lTempPatientSecondary As PatientExtended
        Dim lTempPatientInsurance As PatientInsurance
        Dim lTempPatientInsuranceSecondary As PatientInsurance

        Dim lFormatedSuperBillId As String

        lUser = CType(Session.Item("User"), User)
        lTempPatient = New PatientExtended(lUser.ConnectionString)
        lTempPatientSecondary = New PatientExtended(lUser.ConnectionString)
        lPatienExtended = New PatientExtended(lUser.ConnectionString)
        Dim lPatientId As String = txtPatientID.Text
        Dim lPaymentHdrObj As New PaymentHdr(lUser.ConnectionString)



        'System.Threading.Thread.Sleep(10000)

        Dim lPaymentHdr As New PaymentHdrDB
        Dim lPatientSuperBillDB As New PatientSuperBillDB
        Dim lResult As Integer
        Dim lLogId As Int32 = 0

        Try

            lPatientInsurancePrimary = New PatientInsurance(lUser.ConnectionString)
            lPatientInsurancePrimary.PatientInsurance.PatientID = lPatientId
            lPatientInsurancePrimary.PatientInsurance.Type = "P"
            lResultPrimaryInsurance = lPatientInsurancePrimary.GetRecordByID()

            lPatientInsuranceSecondary = New PatientInsurance(lUser.ConnectionString)
            lPatientInsuranceSecondary.PatientInsurance.PatientID = txtPatientID.Text
            lPatientInsuranceSecondary.PatientInsurance.Type = "S"
            lResultSecondaryInsurance = lPatientInsuranceSecondary.GetRecordByID()

            ''''''''''''''''''''''''''''''''''''''''''

            ''Primary Insurance
            If (lResultPrimaryInsurance) Then
                With lPatientInsurancePrimary.PatientInsurance
                    If (.InsurerId = 0) Then
                        lPatientSuperBillDB.PrimaryInsuranceCompanyId = lPatientInsurancePrimary.PatientInsurance.InsuranceCompanyID  'lPatienExtended.Patient.InsuranceID
                        lPatientSuperBillDB.PrimaryInsuranceCompanyName = lPatientInsurancePrimary.PatientInsurance.InsuranceCompanyName 'lPatienExtended.Patient.InsuranceName
                        lPatientSuperBillDB.GuarantorName = "Self"
                        lPatientSuperBillDB.GuarantorID = "0"
                    Else
                        Dim lTempResult As Boolean

                        lTempPatient.Patient.PatientID = .InsurerId

                        lTempPatientInsurance = New PatientInsurance(lUser.ConnectionString)
                        lTempPatientInsurance.PatientInsurance.PatientID = .InsurerId
                        lTempPatientInsurance.PatientInsurance.PatientInsID = .InsurerInsuranceId
                        lTempPatientInsurance.PatientInsurance.Type = .InsurerInsuranceType

                        lTempResult = lTempPatientInsurance.GetRecordByID()
                        lTempResult = lTempPatient.GetRecordByID()

                        lPatientSuperBillDB.PrimaryInsuranceCompanyId = lTempPatientInsurance.PatientInsurance.InsuranceCompanyID
                        lPatientSuperBillDB.PrimaryInsuranceCompanyName = lTempPatientInsurance.PatientInsurance.InsuranceCompanyName
                        lPatientSuperBillDB.GuarantorName = lTempPatient.Patient.LastName + "," + lTempPatient.Patient.FirstName + " " + lTempPatient.Patient.MiddleName
                        lPatientSuperBillDB.GuarantorID = lTempPatient.Patient.PatientID

                    End If

                End With

           
            End If

            ''Secondary Insurance
            If (lResultSecondaryInsurance) Then
                With lPatientInsuranceSecondary.PatientInsurance
                    If (.InsurerId = 0) Then
                        lPatientSuperBillDB.SecondryInsuranceCompanyId = lPatientInsuranceSecondary.PatientInsurance.InsuranceCompanyID
                        lPatientSuperBillDB.SecondryInsuranceCompanyName = lPatientInsuranceSecondary.PatientInsurance.InsuranceCompanyName
                    Else
                        Dim lTempResult As Boolean
                        lTempPatientSecondary.Patient.PatientID = .InsurerId
                        lTempPatientInsuranceSecondary = New PatientInsurance(lUser.ConnectionString)
                        lTempPatientInsuranceSecondary.PatientInsurance.PatientID = .InsurerId
                        lTempPatientInsuranceSecondary.PatientInsurance.PatientInsID = .InsurerInsuranceId
                        lTempPatientInsuranceSecondary.PatientInsurance.Type = .InsurerInsuranceType
                        lTempResult = lTempPatientInsuranceSecondary.GetRecordByID()
                        lTempResult = lTempPatientSecondary.GetRecordByID()
                        lPatientSuperBillDB.SecondryInsuranceCompanyId = lTempPatientInsuranceSecondary.PatientInsurance.InsuranceCompanyID
                        lPatientSuperBillDB.SecondryInsuranceCompanyName = lTempPatientInsuranceSecondary.PatientInsurance.InsuranceCompanyName
                    End If
                End With
            End If
            lPatienExtended.Patient.PatientID = txtPatientID.Text
            lPatienExtended.GetRecordByID()
            With lPatientSuperBillDB
                .DateOfService = Date.Today.Date
                .VisitDisplayDATE = Date.Now.Date
                .SuperBillTemplateID = cmbSuperBill.SelectedValue.ToString()
                .PatientId = lPatientId
                .PatientName = lPatienExtended.Patient.LastName + "," + lPatienExtended.Patient.FirstName + " " + lPatienExtended.Patient.MiddleName
                .DOB = lPatienExtended.Patient.DOB
                .PatientId = lPatienExtended.Patient.PatientID
                .Address = lPatienExtended.Patient.AddressLine1
                .City = lPatienExtended.Patient.City
                Dim lState = New State(lUser.ConnectionString)
                lState.state = StateMethods.GetState(lPatienExtended.Patient.StateID)
                .State = lState.State.Abbr
                .ZipCode = lPatienExtended.Patient.ZipCode
                .Balance = "0"
                If Me.txtCopayAmount.Text.Equals("") Then
                    .CopayAmount = "0"
                    .PaymentMethod = ""
                Else
                    .CopayAmount = Me.txtCopayAmount.Text
                    .PaymentMethod = Me.cmbPaymentMethod.Text
                End If
                .ChequeNumber = Utility.AdjustApostrophie(Me.txtChequeNumber.Text)
                If (Me.dtChequeDate.DbSelectedDate IsNot Nothing) Then
                    .ChequeDate = Me.dtChequeDate.SelectedDate
                End If
                .PrescriberID = cmbProvider.SelectedValue.Split("|")(0)
                .Status = "UnApproved"
                .IsDeleted = "N"
                .EntryDate = Date.Now.Date
            End With
            If (txtCopayAmount.Text <> "") Then
                With lPaymentHdr
                    .PaymentDate = Date.Today
                    .PaymentDispDate = Date.Today
                    .PayerType = "P"
                    .PaymentMode = Utility.AdjustApostrophie(cmbPaymentMethod.SelectedItem.Text)
                    .CheckNumber = Utility.AdjustApostrophie(txtChequeNumber.Text)
                    .CheckDate = dtChequeDate.DbSelectedDate
                    .Amount = Utility.AdjustApostrophie(txtCopayAmount.Text)
                    .Description = "Copay"
                    .UserID = lUser.UserId
                    .PayerName = Utility.AdjustApostrophie(lblPatientName.Text)
                    .PayerID = txtPatientID.Text
                    If CType(lPaymentHdrObj.GetLastEnteredDate(), Date).Month <> Date.Now.Month Then
                        .DisplayID = "1"
                    Else
                        Dim lint As Integer = PaymentHdr.GetMaxDispID(lUser.ConnectionString)
                        'lPaymentHdrDB.DisplayID = lint + 1
                        .DisplayID = lint
                    End If
                    .EntryDate = Date.Now
                End With
            End If
            lResult = GenerateSuperBillMethods.AddPatientSuperBill(lPatientSuperBillDB, lPaymentHdr, Request.Url.AbsoluteUri, lUser.UserId)
            If (chkSpecificSB.Checked) Then
                lFormatedSuperBillId = "SB-" & lPatientSuperBillDB.PatientSuperBillDisplayID.PadLeft(5, "0")
                GenerateSpecificSB(lFormatedSuperBillId, lPatienExtended.Patient.DOB, lPatienExtended.Patient.LastName & ", " & lPatienExtended.Patient.FirstName)
            End If
            Return lResult
        Catch ex As Exception
            lLogId = ErrorLogMethods.LogError(ex, "PatientPreview.aspx\GetInsurerInsurance()")
            Return 0
        End Try


    End Function

    Protected Sub btnPersonalCancel_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnPersonalCancel.Click
        Response.Redirect("SelectPatient.aspx")
    End Sub

    

    

    

    Protected Sub btnPrnt_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnPrnt.Click

        

        Dim lUser As User
        lUser = CType(Session.Item("User"), User)
        Dim lResult2 As Integer
        lResult2 = SavePatientSuperBill()

        If lResult2 <> 0 Then
            If (CType(sender, ImageButton).ID = "btnPrnt") Then
                If (chkSpecificSB.Checked = True AndAlso mSpecificVisitTemplatePath <> "") Then
                    Dim lSSBtempPath As String = ElixirLibrary.Encryption.EncryptQueryString("Path=" & mSpecificVisitTemplatePath)
                    Response.Write("<Script>window.open('ViewSpecificSB.aspx" & lSSBtempPath & "');window.location=""VisitSearch.aspx"";</Script>")
                Else
                    Dim lquerystring As String = ElixirLibrary.Encryption.EncryptQueryString("sid=" & lResult2.ToString())
                    Response.Write("<Script>window.open('PSBPrint.aspx" & lquerystring & "');window.location=""VisitSearch.aspx"";</Script>")
                End If
            End If
        Else
            Response.Write("<Script>Alert('Failed to Update Patient');</Script>")

        End If

    End Sub

    

    Public Sub GenerateSpecificSB(ByVal pSuperBillID As String, ByVal pDOB As String, ByVal pPatientName As String)
        Dim lUser As User
        Dim lFileName As String = ""
        Dim lFilePath As String = ""
        Dim lPdfTemplatePath As String
        Dim lNewPath As String = ""
        Dim lDirectoryInfo As DirectoryInfo
        Dim lPdfReader As PdfReader
        Dim lPdfStamper As PdfStamper
        Dim pdfFormFields As AcroFields
        Try
            lUser = CType(HttpContext.Current.Session.Item("User"), User)
            lPdfTemplatePath = Server.MapPath("PdfTemplates\KaziSB.pdf") 'ConfigurationManager.AppSettings("SpecificSBPath") & lUser.ClinicId & "\Visits\SpecificSBTemplate.PDF"
          
            ''Check Save Directory if not exist than Create
            lFilePath = CType(ConfigurationManager.AppSettings("SpecificSBPath"), String)
            lDirectoryInfo = New DirectoryInfo(lFilePath)
            If Not lDirectoryInfo.Exists Then
                lDirectoryInfo.Create()
            End If
            lFilePath = CType(ConfigurationManager.AppSettings("SpecificSBPath"), String) + lUser.ClinicId
            lDirectoryInfo = New DirectoryInfo(lFilePath)
            If Not lDirectoryInfo.Exists Then
                lDirectoryInfo.Create()
            End If
            lFilePath = CType(ConfigurationManager.AppSettings("SpecificSBPath"), String) + lUser.ClinicId + "\Visits\"
            lDirectoryInfo = New DirectoryInfo(lFilePath)
            If Not lDirectoryInfo.Exists Then
                lDirectoryInfo.Create()
            End If

            lFileName = Date.Now.Year & "-" & Date.Now.Month & "-" & Date.Now.Day & "-" & Date.Now.Minute & "-" & Date.Now.Second & ".pdf"
            lNewPath = lFilePath & lFileName

            lPdfReader = New PdfReader(lPdfTemplatePath)
            lPdfStamper = New PdfStamper(lPdfReader, New FileStream(lNewPath, FileMode.Create))


            pdfFormFields = lPdfStamper.AcroFields
            pdfFormFields.SetField("txtDate", Date.Now.Date)
            pdfFormFields.SetField("txtDOB", pDOB)
            pdfFormFields.SetField("txtSuperbillId", pSuperBillID)
            pdfFormFields.SetField("txtSuperbillId2", pSuperBillID)
            pdfFormFields.SetField("txtPatientName", pPatientName)
            pdfFormFields.SetField("txtPatientName2", pPatientName)
            lPdfStamper.FormFlattening = True
            lPdfStamper.Close()

            mSpecificVisitTemplatePath = lFileName
            'Response.Write("<Script>window.open('ViewSpecificSB.aspx?Path=" & lFileName & "');window.location='VisitSearch.aspx';</Script>")
        Catch ex As Exception

        End Try
    End Sub

    

    Public Function GetPostBackControl(ByVal page As Page) As Control


        Dim postbackControlInstance As Control = Nothing



        Dim postbackControlName As String = page.Request.Params.[Get]("__EVENTTARGET")

        If postbackControlName IsNot Nothing AndAlso postbackControlName <> String.Empty Then



            postbackControlInstance = page.FindControl(postbackControlName)
        Else



            ' handle the Button control postbacks

            For i As Integer = 0 To page.Request.Form.Keys.Count - 1


                postbackControlInstance = page.FindControl(page.Request.Form.Keys(i))

                If TypeOf postbackControlInstance Is System.Web.UI.WebControls.Button Then



                    Return postbackControlInstance

                End If

            Next
        End If

        ' handle the ImageButton postbacks

        If postbackControlInstance Is Nothing Then


            For i As Integer = 0 To page.Request.Form.Count - 1


                If (page.Request.Form.Keys(i).EndsWith(".x")) OrElse (page.Request.Form.Keys(i).EndsWith(".y")) Then


                    postbackControlInstance = page.FindControl(page.Request.Form.Keys(i).Substring(0, page.Request.Form.Keys(i).Length - 2))


                    Return postbackControlInstance

                End If

            Next
        End If

        Return postbackControlInstance

    End Function

End Class
