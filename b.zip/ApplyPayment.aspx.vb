
Imports Telerik.WebControls
Imports System
Imports System.Collections.Generic
Imports System.Globalization

Partial Class Billing_ApplyPayment
    Inherits System.Web.UI.Page


    Dim mPaymentDtlCollection As Hashtable 'PaymentDtlCollection
    Private _ordersExpandedState As Hashtable
    Private _selectedState As Hashtable

    Private mIndex As Integer = 0


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim lPaymentiD As String = String.Empty
        Dim lds As DataSet = Nothing
        Dim queryString As NameValueCollection



      


        If (Not Page.IsPostBack) Then

            Try

                ''Checking for session.........
                If (Session("PaymentDetailCollectionForHeader") IsNot Nothing) Then
                    Session.Remove("PaymentDetailCollectionForHeader")
                    mPaymentDtlCollection = New Hashtable
                    Session.Add("PaymentDetailCollectionForHeader", mPaymentDtlCollection)
                End If

                If (Session("PaymentDetailCollectionForHeader") Is Nothing) Then
                    mPaymentDtlCollection = New Hashtable
                    Session.Add("PaymentDetailCollectionForHeader", mPaymentDtlCollection)
                End If


                If (Request.QueryString Is Nothing) Then
                    Exit Sub
                Else
                    queryString = Encryption.DecryptQueryString(Request.QueryString.ToString)

                    If queryString.Keys(0).Contains("PaymentID") Then
                        ViewState("PaymentID") = queryString("PaymentID")
                        loadheaderinformation(ViewState("PaymentID"))
                    Else
                        ''if user is coming from visit page.....
                        ViewState("VisitID") = queryString("VisitID")
                        FillForVisit()
                    End If
                End If

                dtFromDate.SelectedDate = Date.Now.AddMonths(-1)
                dtTodate.SelectedDate = Date.Today

                If (Session("_ordersExpandedState") IsNot Nothing) Then
                    Session.Remove("_ordersExpandedState")
                End If

                If (Me.Session("_selectedState") IsNot Nothing) Then
                    Session.Remove("_selectedState")
                End If

            Catch ex As Exception
                Response.Write(ex.Message)
            End Try

        End If

        ''session for adjustment

        If Session("Save") = True Then
            'Response.Write("<script language='javascript'>history.go(-(history.length));window.location('ApplyPayment.aspx');</script>")
            grdHCFA.Rebind()
        End If

        Session("Save") = False



        ''Preserving values for the child grid........
        HoldValue()







        'THIS CODE TRAVERSES THROUGH THE PARENT CHILD GRIDS AND CHECKS FOR DISABLED TEXTFIELDS AND APPLIES THE APPROPRIATE CSS CLASS ONLY
        For Each item As GridDataItem In grdHCFA.Items

            If CType(item.Cells(2).FindControl("txtPayment"), TextBox).Enabled = False Then

                Me.ClientScript.RegisterStartupScript(Me.GetType, mIndex, "<script>ApplyCSS('" & CType(item.Cells(2).FindControl("txtPayment"), TextBox).ClientID & "', 'textfield-disabled');</script>")
                mIndex += 1

            End If


            If item.ChildItem IsNot Nothing Then

                Dim childTable As GridTableView = DirectCast(item.ChildItem.NestedTableViews(0), GridTableView)
                For Each childItem As GridDataItem In childTable.Items

                    If CType(childItem.Cells(5).FindControl("txtPayment"), TextBox).Enabled = False Then

                        Me.ClientScript.RegisterStartupScript(Me.GetType, mIndex, "<script>ApplyCSS('" & CType(childItem.Cells(5).FindControl("txtPayment"), TextBox).ClientID & "', 'textfield-disabled');</script>")
                        mIndex += 1

                    End If

                Next

            End If

        Next

        Me.ImageButton1.OnClientClick = "javascript:window.history.go(-1);return false;"


    End Sub

    Protected Sub ImgSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImgSearch.Click
        Dim lds As DataSet = Nothing
        Dim lcondition As String = String.Empty

        Try
            If Not (txtPatient.Text = "") Then
                lcondition = " And PatientID='" & txtPatient.Value & "'"
            End If
            If (dtFromDate.SelectedDate.HasValue = True) And (dtTodate.SelectedDate.HasValue = True) Then
                lcondition &= " And DateOfService between  '" & dtFromDate.SelectedDate.Value & "' And '" & dtTodate.SelectedDate.Value & "'"
            End If

            If Not cmbStatus.Value = "A" Then
                If cmbStatus.Value = "P" Then
                    lcondition &= " and dbo.GetVisitBalance(patientSuperBillID)=0"
                Else
                    lcondition &= " and dbo.GetVisitBalance(patientSuperBillID)<>0"
                End If
                'Else
                '    lcondition &= " and dbo.GetVisitBalance(patientSuperBillID)>=0"
            End If

            lcondition &= " And status='Approved'"

            lds = SuperBillMethods.GetPatientSuperBillForApplyPayment(lcondition)

            If (lds.Tables(0).Rows.Count > 0) Then
                grdVisit.DataSource = lds
                grdVisit.Columns(6).Visible = True
                grdVisit.DataBind()
                grdVisit.Columns(6).Visible = False
            Else
                grdVisit.DataSource = ""
                grdVisit.DataBind()

            End If

        Catch ex As Exception
            Response.Write(ex.Message)
        End Try
    End Sub

    Protected Sub btnPatientSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnPatientSearch.Click
        'Dim newWindow As New RadWindow()

        'Try

        '    newWindow.NavigateUrl = "PatientSearchForPayment.aspx?srch=" & Utility.AdjustApostrophie(Me.txtPatient.Text.Split(",")(0))
        '    newWindow.ID = "rwPatient"
        '    newWindow.VisibleOnPageLoad = True
        '    newWindow.Top = 146
        '    newWindow.Left = 7
        '    newWindow.Width = Unit.Pixel(700)
        '    newWindow.Height = Unit.Pixel(400)
        '    newWindow.VisibleTitlebar = False
        '    newWindow.VisibleStatusbar = False
        '    newWindow.BorderStyle = BorderStyle.Solid
        '    newWindow.ReloadOnShow = True
        '    newWindow.BackColor = Drawing.Color.Transparent
        '    newWindow.ClientCallBackFunction = "PatientSearchCallBackFunction"

        '    newWindow.Enabled = True
        '    newWindow.Visible = True
        '    rwmApplyPayment.Windows.Add(newWindow)

        'Catch ex As Exception
        '    Dim lLogID As String = String.Empty

        '    lLogID = ErrorLogMethods.LogError(ex, " Billing_PaymentApply.aspx\btnMirror_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) ")
        '    Response.Redirect("ErrorPage.aspx?LogID=" & lLogID, False)
        'End Try
        Dim newWindow As RadWindow
        Try
            newWindow = New RadWindow()
            If (txtPatient.Text.ToString.Split(",").Length = 1) Then
                newWindow.NavigateUrl = "PatientSearch.aspx?srch=" & Utility.AdjustApostrophie(Me.txtPatient.Text.ToString.Split(",")(0)) & "|" & "" & ""
            ElseIf (txtPatient.Text.ToString.Split(",").Length > 1) Then
                newWindow.NavigateUrl = "PatientSearch.aspx?srch=" & Utility.AdjustApostrophie(Me.txtPatient.Text.ToString.Split(",")(0)) & "|" & Me.txtPatient.Text.ToString.Split(",")(1) & ""
            Else

            End If
            newWindow.ID = "rwPatient"
            newWindow.VisibleOnPageLoad = True
            newWindow.Top = 220
            newWindow.Left = 280
            newWindow.Width = Unit.Pixel(697)
            newWindow.Height = Unit.Pixel(400)
            newWindow.VisibleTitlebar = False
            newWindow.VisibleStatusbar = False
            newWindow.BorderStyle = BorderStyle.Solid
            newWindow.ReloadOnShow = True
            newWindow.BackColor = Drawing.Color.Transparent
            newWindow.ClientCallBackFunction = "PatientSearchCallBackFunction"
            newWindow.Enabled = True
            newWindow.Visible = True
            rwmApplyPayment.Windows.Add(newWindow)
        Catch ex As Exception
            Dim lLogID As String = String.Empty
            lLogID = ErrorLogMethods.LogError(ex, " Billing_PaymentApply.aspx\btnPatientSearch_Click()")
            Response.Redirect("~/ErrorPage.aspx?LogID=" & lLogID, False)
        End Try

    End Sub

    Protected Sub grdHCFA_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdHCFA.DataBound

        Try
            Dim indexes As String() = New String(Me.ExpandedStates.Keys.Count - 1) {}
            Me.ExpandedStates.Keys.CopyTo(indexes, 0)

            Dim arr As New ArrayList(indexes)
            'Sort so we can guarantee that a parent item is expanded before any of 
            'its children
            arr.Sort()

            For Each key As String In arr
                Dim value As Boolean = CBool(Me.ExpandedStates(key))
                If value Then

                    grdHCFA.Items(key).Expanded = True

                End If
            Next

            'Select all items using our custom storage
            indexes = New String(Me.SelectedStates.Keys.Count - 1) {}
            Me.SelectedStates.Keys.CopyTo(indexes, 0)

            arr = New ArrayList(indexes)
            'Sort to ensure that a parent item is selected before any of its children
            arr.Sort()

            For Each key As String In arr
                Dim value As Boolean = CBool(Me.SelectedStates(key))
                If value Then
                    grdHCFA.Items(key).Selected = True
                End If
            Next

           

        Catch ex As Exception

        End Try

    End Sub

   


    Protected Sub grdHCFA_DetailTableDataBind(ByVal source As Object, ByVal e As Telerik.WebControls.GridDetailTableDataBindEventArgs) Handles grdHCFA.DetailTableDataBind

        Try

            Dim parentItem As GridDataItem = CType(e.DetailTableView.ParentItem, GridDataItem)
            Dim lpaymentdtl As PaymentDtlDB = Nothing



            ''ADDED BY FARAZ AHMED FOR IMPLEMENTATION OF CSS CLASS ON DISABLED TEXTBOX
            'If Not CType(parentItem.Cells(2).FindControl("txtPayment"), TextBox).Enabled Then
            '    Me.ClientScript.RegisterStartupScript(Me.GetType, mIndex, "<script>ApplyCSS('" & CType(parentItem.Cells(2).FindControl("txtPayment"), TextBox).ClientID & "', 'textfield-disabled');</script>")
            '    mIndex += 1
            'End If

            If (Session("PaymentDetailCollectionForHeader") IsNot Nothing) Then

                mPaymentDtlCollection = Session("PaymentDetailCollectionForHeader")
                lpaymentdtl = mPaymentDtlCollection.Item(parentItem.Cells(7).Text)

                If (lpaymentdtl.PaymentCPTDetailCollection Is Nothing) Then
                    lpaymentdtl.PaymentCPTDetailCollection = PaymentMethods.GetForDetailApplyPaymentGrid(parentItem.Cells(7).Text)
                    Session("PaymentDetailCollectionForHeader") = mPaymentDtlCollection
                End If


            End If


            e.DetailTableView.DataSource = lpaymentdtl.PaymentCPTDetailCollection


        Catch ex As Exception
            Response.Write(ex.Message)

        End Try

    End Sub

    Protected Sub ImgAddRecords_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImgAddRecords.Click
        AddRecordsInHcfa()
    End Sub

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSave.Click

        Dim lUser As User = CType(Session("User"), User)

        Try


            Dim lPaymentDtl As New PaymentDtl(lUser.ConnectionString)
            Dim lPaymentHdr As New PaymentHdr(lUser.ConnectionString)
            Dim lReference As String = String.Empty
            Dim lresult As Boolean = False
            Dim lTotalAdjustmentAmount As Double = 0
            Dim li, lj, lrow As Integer
            Dim lTotalPaymentAmount As Double = 0
            Dim lDifferencePayment As Double = 0

            ''if user has come from visit....
            If (ViewState("VisitID") IsNot Nothing) Then
                insertForvisit()
                Exit Sub
            End If

            lPaymentHdr.PaymentHdr.PaymentID = ViewState("PaymentID")
            lPaymentHdr.GetRecordByID()


            mPaymentDtlCollection = Session("PaymentDetailCollectionForHeader")


            For Each litem As PaymentDtlDB In mPaymentDtlCollection.Values
                lPaymentDtl.PaymentDtl = litem
                lTotalAdjustmentAmount = litem.Adjustment

                ' ''check for Amount text box if it is string.....
                'If Not Regex.IsMatch(litem.Amount.Trim(), "[0-9]+(\.[0-9][0-9]?)") Then
                '    Response.Write("<script>alert('Alphabets are not allowed in amount textbox');</script>")
                '    Exit Sub
                'End If


                lPaymentDtl.PaymentDtl.Amount = IIf(litem.Amount = "", 0, litem.Amount)
                lPaymentDtl.PaymentDtl.TotalAmount = litem.TotalAmount
                ''''''' Load Patient Ledger Object 
                lblAppliedAmount.Text = IIf(lblAppliedAmount.Text = "", 0, lblAppliedAmount.Text)

                lblAppliedAmount.Text = Decimal.Parse(lblAppliedAmount.Text).ToString("0.##")

                lblPaymentAmount.Text = Decimal.Parse(lblPaymentAmount.Text).ToString("0.##")

                lDifferencePayment = lblPaymentAmount.Text - lblAppliedAmount.Text

                lDifferencePayment = Decimal.Parse(lDifferencePayment).ToString("0.##")

                If (litem.TotalAmount > (lDifferencePayment)) Then
                    Response.Write("<script>alert('Amount exceeds remaining balance of the payment');</script>")
                    Exit Sub
                End If


                lPaymentDtl.PaymentDtl.PatientLedger = New PatientLedgerDB

                With lPaymentDtl.PaymentDtl.PatientLedger
                    .ReferenceID = ViewState("PaymentID")
                    .ReferenceDate = lblPaymentDate.Text
                    .ReferenceDisplayID = Year(CDate(lblPaymentDate.Text)) & "-" & Right("00" & Month(CDate(lblPaymentDate.Text)), 2) & "-" & Right("000" & ViewState("PaymentID"), 5)
                    .ReferenceDisplayDate = lblPaymentDate.Text

                    .ReferenceID2 = litem.VisitId
                    .ReferenceDate2 = litem.VisitDisplayDate
                    .ReferenceDisplayID2 = Year(CDate(.ReferenceDate2)) & "-" & Right("00" & Month(CDate(.ReferenceDate2)), 2) & "-" & Right("00000" & litem.VisitDisplayID, 5)
                    .Adjustment = "0"
                    .ChequeDate = lblCheckDate.Text
                    .ChequeNumber = lblChequeNumber.Text
                    .Date1 = Date.Today
                    .Debit = "0"
                    .Credit = litem.Amount

                    .Description = "Payment received from  " & lblPayerName.Text & " " & IIf(lblChequeNumber.Text <> "", "by Check No " & lblChequeNumber.Text, "")
                    .PatientID = litem.PatientID
                    .PayerName = lblPayerName.Text

                    If (lblPayerType.Text.Length > 0) Then
                        .PayerType = lblPayerType.Text.Substring(0, 1)
                    End If


                    .PaymentMethod = lblPaymentMode.Text
                    .TransactionType = "P"


                    .Reference = "Applying on visit level"

                    ''CALCULATING TOTAL ADJUSTMENT.......
                    If (lPaymentDtl.PaymentDtl.PaymentCPTDetailCollection IsNot Nothing) Then
                        For li = 0 To lPaymentDtl.PaymentDtl.PaymentCPTDetailCollection.Count - 1
                            If (lPaymentDtl.PaymentDtl.PaymentCPTDetailCollection.Item(li).AdjustmentCollection IsNot Nothing) Then
                                For lj = 0 To lPaymentDtl.PaymentDtl.PaymentCPTDetailCollection.Item(li).AdjustmentCollection.Count - 1
                                    lTotalAdjustmentAmount += lPaymentDtl.PaymentDtl.PaymentCPTDetailCollection.Item(li).AdjustmentCollection.Item(lj).Amount
                                Next
                            End If

                        Next
                    End If

                End With


                lresult = lPaymentDtl.InsertPayment()

                ''Ledger block....
                If (lresult) Then

                    If (lPaymentDtl.PaymentDtl.PaymentCPTDetailCollection IsNot Nothing) Then
                        For li = 0 To lPaymentDtl.PaymentDtl.PaymentCPTDetailCollection.Count - 1
                            lPaymentDtl.PaymentDtl.PatientLedger = New PatientLedgerDB

                            With lPaymentDtl.PaymentDtl.PatientLedger
                                .ReferenceID = ViewState("PaymentID")
                                .ReferenceDate = lblPaymentDate.Text
                                .ReferenceDisplayID = Year(CDate(lblPaymentDate.Text)) & "-" & Right("00" & Month(CDate(lblPaymentDate.Text)), 2) & "-" & Right("000" & ViewState("PaymentID"), 5)
                                .ReferenceDisplayDate = lblPaymentDate.Text

                                .ReferenceID2 = litem.VisitId
                                .ReferenceDate2 = lPaymentDtl.PaymentDtl.PaymentCPTDetailCollection.Item(li).DateOfService
                                .ReferenceDisplayID2 = Year(CDate(.ReferenceDate2)) & "-" & Right("00" & Month(CDate(.ReferenceDate2)), 2) & "-" & Right("00000" & litem.VisitDisplayID, 5)
                                .Adjustment = "0"
                                .ChequeDate = lblCheckDate.Text
                                .ChequeNumber = lblChequeNumber.Text
                                .Date1 = Date.Today
                                .Debit = "0"
                                .Credit = lPaymentDtl.PaymentDtl.PaymentCPTDetailCollection.Item(li).Amount
                                .Reference = lPaymentDtl.PaymentDtl.PaymentCPTDetailCollection.Item(li).CPTCode
                                .Description = "Payment received from  " & lblPayerName.Text & " " & IIf(lblChequeNumber.Text <> "", "by Check No " & lblChequeNumber.Text, "") _
                                & " for CPT:" & lPaymentDtl.PaymentDtl.PaymentCPTDetailCollection.Item(li).CPTCode
                                .PatientID = litem.PatientID
                                .PayerName = lblPayerName.Text

                                If (lblPayerType.Text.Length > 0) Then
                                    .PayerType = lblPayerType.Text.Substring(0, 1)
                                End If

                                .PaymentMethod = lblPaymentMode.Text
                                .TransactionType = "P"

                            End With

                            If (lPaymentDtl.PaymentDtl.PaymentCPTDetailCollection.Item(li).Amount > 0) Then
                                lPaymentDtl.InsertPatientLedger()
                            End If

                        Next
                    End If
                End If

                lrow = lrow + 1
            Next

            'Response.Write("<script>alert('Payment saved successfully');</script>")

            'Page.RegisterStartupScript("testscript", "<script language='javascript'>alert('Payment saved successfully');window.location='PaymentSearch.aspx';</script>")

            'PageExpire()

            'Response.Write("<script>location.href = 'PaymentSearch.aspx';</script>")

            Response.Write("<script language='javascript'>alert('Payment saved successfully');history.go(-(history.length));window.location='PaymentSearch.aspx';</script>")




        Catch ex As Exception
            Response.Write("<script>alert('Error in saving payment');</script>")
        End Try


    End Sub

    Private Sub HoldValue()

        If (Session("PaymentDetailCollectionForHeader") Is Nothing) Then
            Exit Sub
        End If

        Try

            mPaymentDtlCollection = Session("PaymentDetailCollectionForHeader")
            Dim lpaymentdtl As PaymentDtlDB
            Dim lpaymentcptdtl As PaymentCPTDetailDB
            Dim lrow As Integer
            Dim ltotalinteger As Double = 0


            For Each lGridItem As GridDataItem In grdHCFA.Items
                lpaymentdtl = mPaymentDtlCollection.Item(lGridItem.Cells(7).Text)
                lrow = 0

                If (lpaymentdtl IsNot Nothing) Then


                    lpaymentdtl.Amount = CType(lGridItem.FindControl("txtPayment"), TextBox).Text

                    ''check for Amount text box if it is string.....
                    'If Not Regex.IsMatch(lpaymentdtl.Amount.Trim(), "^[0-9]*$") Then
                    'Exit Sub
                    'End If

                    ''calculation total amount......
                    ltotalinteger = IIf(CType(lGridItem.FindControl("TotalAmount"), TextBox).Text = "", 0, CType(lGridItem.FindControl("TotalAmount"), TextBox).Text)
                    lpaymentdtl.TotalAmount = IIf(lpaymentdtl.Amount = "", 0, lpaymentdtl.Amount) + ltotalinteger


                    For Each lChildGridItem As GridDataItem In lGridItem.ChildItem.NestedTableViews(0).Items

                        lpaymentcptdtl = lpaymentdtl.PaymentCPTDetailCollection.Item(lrow)

                        If (CType(lChildGridItem.FindControl("txtPayment"), TextBox).Text <> "") Then
                            lpaymentcptdtl.Amount = CType(lChildGridItem.FindControl("txtPayment"), TextBox).Text
                        End If

                        If (CType(lChildGridItem.FindControl("txtDeductible"), TextBox).Text <> "") Then
                            lpaymentcptdtl.Deductable = CType(lChildGridItem.FindControl("txtDeductible"), TextBox).Text
                        End If

                        If (CType(lChildGridItem.FindControl("txtcopay"), TextBox).Text <> "") Then
                            lpaymentcptdtl.Copay = CType(lChildGridItem.FindControl("txtcopay"), TextBox).Text
                        End If

                        lrow += 1
                    Next
                End If

            Next

            Session("PaymentDetailCollectionForHeader") = mPaymentDtlCollection


        Catch ex As Exception
            Response.Write(ex.Message)
        End Try

    End Sub

    Protected Sub grdHCFA_ItemCommand(ByVal source As Object, ByVal e As Telerik.WebControls.GridCommandEventArgs) Handles grdHCFA.ItemCommand


        If (e.CommandName = "Apply Adjustment") Then


            Dim lquerystring As String = "AdjustmentScreen.aspx" + Encryption.EncryptQueryString("VisitID=" & e.Item.Cells(18).Text)

            Page.RegisterStartupScript("WindowOpening", "<script>window.open('" & Page.ResolveUrl(lquerystring) & "','WritingTips','toolbar=no width=600 height=400,left=300,top=300')</script>")


          
        End If

        If (e.CommandName = "ChildApplyAdjustment") Then

            Dim lquerystring As String = "AdjustmentScreen.aspx" + Encryption.EncryptQueryString("VisitID=" + e.Item.Cells(13).Text _
            & "& CPTCode=" + e.Item.Cells(3).Text & "& LineID=" + e.Item.Cells(15).Text)

            Page.RegisterStartupScript("WindowOpening", "<script>window.open('" & Page.ResolveUrl(lquerystring) & "','WritingTips','toolbar=no width=600 height=400,left=300,top=300')</script>")



            'Page.RegisterStartupScript("WindowOpening", "<script>window.open('" & Page.ResolveUrl("AdjustmentScreen.aspx?VisitID=" + e.Item.Cells(13).Text + _
            '"& CPTCode=" + e.Item.Cells(3).Text + "& LineID=" + e.Item.Cells(15).Text) & "' ,'WritingTips','toolbar=no width=600 height=400,left=300,top=300')</script>")


        End If

        If (e.CommandName = "Delete") Then
            mPaymentDtlCollection.Remove(e.Item.Cells(18).Text)
            Session("PaymentDetailCollectionForHeader") = mPaymentDtlCollection
            'Session("AdjustmentClick") = True
            grdHCFA.Rebind()
        End If


        If e.CommandName = RadGrid.ExpandCollapseCommandName Then

            'Is the item about to be expanded or collapsed
            If Not e.Item.Expanded Then
                'Save its unique index among all the items in the hierarchy
                Me.ExpandedStates(e.Item.ItemIndexHierarchical) = True
            Else
                'collapsed
                Me.ExpandedStates.Remove(e.Item.ItemIndexHierarchical)
                Me.ClearExpandedChildren(e.Item.ItemIndexHierarchical)
            End If
            'Is the item about to be selected 
        ElseIf e.CommandName = RadGrid.SelectCommandName Then
            'Save its unique index among all the items in the hierarchy
            Me.SelectedStates(e.Item.ItemIndexHierarchical) = True
            'Is the item about to be deselected 
        ElseIf e.CommandName = RadGrid.DeselectCommandName Then
            Me.SelectedStates.Remove(e.Item.ItemIndexHierarchical)
        End If



    End Sub

    Protected Sub grdHCFA_ItemDataBound(ByVal sender As Object, ByVal e As Telerik.WebControls.GridItemEventArgs) Handles grdHCFA.ItemDataBound

        Dim lpaymentdtl As PaymentDtlDB
        Dim lpaymentcptdtl As PaymentCPTDetailDB


        mPaymentDtlCollection = Session("PaymentDetailCollectionForHeader")

        Dim lbtnNotes As ImageButton
        Dim parentItem As GridDataItem = Nothing
        Dim lStrAmount As String
        ''Header
        If (e.Item.ItemType = Telerik.WebControls.GridItemType.Item Or e.Item.ItemType = Telerik.WebControls.GridItemType.AlternatingItem) Then
            lpaymentdtl = mPaymentDtlCollection.Item(e.Item.Cells(7).Text)
            If (lpaymentdtl IsNot Nothing) Then
                CType(e.Item.FindControl("txtPayment"), TextBox).Text = lpaymentdtl.Amount
                lbtnNotes = CType(e.Item.FindControl("btnNotes"), ImageButton)
                lbtnNotes.Attributes.Add("onclick", "javascript:return clickOnceQuestion(this," & e.Item.Cells(7).Text & ")")
                If Not lpaymentdtl.Notes = "" Then
                    lbtnNotes.ImageUrl = "../images/commentYellow.gif"
                Else
                    lbtnNotes.ImageUrl = "../images/commentBlue.gif"
                End If
            End If

            If (e.Item.OwnerTableView.Name <> "CPTCodes") Then
                lbtnNotes = CType(e.Item.FindControl("btnNotes"), ImageButton)
                lbtnNotes.Attributes.Add("onclick", "javascript:return clickOnceQuestion(this," & e.Item.Cells(7).Text & ")")
               
                '**********************************

                'Adjustment
                If e.Item.Cells(5).Text <> "" Then
                    lStrAmount = e.Item.Cells(5).Text
                    If (lStrAmount.Substring(0, 1) = "-") Then
                        lStrAmount = "(" & lStrAmount.Remove(0, 1) & ")"
                        e.Item.Cells(5).Text = lStrAmount
                    End If
                End If
                'Balance
                If e.Item.Cells(6).Text <> "" Then
                    lStrAmount = e.Item.Cells(6).Text
                    If (lStrAmount.Substring(0, 1) = "-") Then
                        lStrAmount = "(" & lStrAmount.Remove(0, 1) & ")"
                        e.Item.Cells(6).Text = lStrAmount
                    End If
                End If
                'Prev Insurance Payment 
                If e.Item.Cells(10).Text <> "" Then
                    lStrAmount = e.Item.Cells(10).Text
                    If (lStrAmount.Substring(0, 1) = "-") Then
                        lStrAmount = "(" & lStrAmount.Remove(0, 1) & ")"
                        e.Item.Cells(10).Text = lStrAmount
                    End If
                End If
                'Prev Patient Payment
                If e.Item.Cells(11).Text <> "" Then
                    lStrAmount = e.Item.Cells(11).Text
                    If (lStrAmount.Substring(0, 1) = "-") Then
                        lStrAmount = "(" & lStrAmount.Remove(0, 1) & ")"
                        e.Item.Cells(11).Text = lStrAmount
                    End If
                End If

                'Total Balance
                If e.Item.Cells(19).Text <> "" Then
                    lStrAmount = e.Item.Cells(19).Text
                    If (lStrAmount.Substring(0, 1) = "-") Then
                        lStrAmount = "(" & lStrAmount.Remove(0, 1) & ")"
                        e.Item.Cells(19).Text = lStrAmount
                    End If
                End If


                '**************************


                If (ViewState("VisitID") IsNot Nothing) Then

                    Dim item As GridDataItem = DirectCast(e.Item, GridDataItem)

                    CType(e.Item.FindControl("txtPayment"), TextBox).Enabled = False
                    ''ADDED BY FARAZ AHMED FOR APPLYING THE DISABLED CSS FOR TEXTBOX                   
                    'Me.ClientScript.RegisterStartupScript(Me.GetType, ViewState("VisitID"), "<script>ApplyCSS('" & CType(e.Item.FindControl("txtPayment"), TextBox).ClientID & "', 'textfield-disabled');</script>")


                    item("DeleteColumn").Enabled = False
                    item("Notes").Enabled = False




                End If
            End If


        End If

        ''detail
        If (e.Item.ItemType = Telerik.WebControls.GridItemType.Item Or e.Item.ItemType = Telerik.WebControls.GridItemType.AlternatingItem) And e.Item.OwnerTableView.Name = "CPTCodes" Then
            lpaymentdtl = mPaymentDtlCollection.Item(e.Item.Cells(13).Text)


            If (lpaymentdtl.PaymentCPTDetailCollection IsNot Nothing) Then
                lpaymentcptdtl = lpaymentdtl.PaymentCPTDetailCollection.Item(e.Item.ItemIndex)
                CType(e.Item.FindControl("txtPayment"), TextBox).Text = lpaymentcptdtl.Amount
                CType(e.Item.FindControl("txtDeductible"), TextBox).Text = lpaymentcptdtl.Deductable
                CType(e.Item.FindControl("txtcopay"), TextBox).Text = lpaymentcptdtl.Copay
            End If

            If (ViewState("VisitID") IsNot Nothing) Then
                CType(e.Item.FindControl("txtPayment"), TextBox).Enabled = False
                Me.ClientScript.RegisterStartupScript(Me.GetType, mIndex, "<script>ApplyCSS('" & CType(e.Item.FindControl("txtPayment"), TextBox).ClientID & "', 'textfield-disabled');</script>")
                mIndex += 1
                CType(e.Item.FindControl("txtDeductible"), TextBox).Enabled = False
                CType(e.Item.FindControl("txtcopay"), TextBox).Enabled = False


            End If



            '**********************************

            'Charges
            If e.Item.Cells(4).Text <> "" Then
                lStrAmount = e.Item.Cells(4).Text
                If (lStrAmount.Substring(0, 1) = "-") Then
                    lStrAmount = "(" & lStrAmount.Remove(0, 1) & ")"
                    e.Item.Cells(4).Text = lStrAmount
                End If
            End If

            'Amount Allowed
            If e.Item.Cells(5).Text <> "" Then
                lStrAmount = e.Item.Cells(5).Text
                If (lStrAmount.Substring(0, 1) = "-") Then
                    lStrAmount = "(" & lStrAmount.Remove(0, 1) & ")"
                    e.Item.Cells(5).Text = lStrAmount
                End If
            End If

            'Adjustment
            If e.Item.Cells(7).Text <> "" Then
                lStrAmount = e.Item.Cells(7).Text
                If (lStrAmount.Substring(0, 1) = "-") Then
                    lStrAmount = "(" & lStrAmount.Remove(0, 1) & ")"
                    e.Item.Cells(7).Text = lStrAmount
                End If
            End If
            ' Insurance payment
            If e.Item.Cells(11).Text <> "" Then
                lStrAmount = e.Item.Cells(11).Text
                If (lStrAmount.Substring(0, 1) = "-") Then
                    lStrAmount = "(" & lStrAmount.Remove(0, 1) & ")"
                    e.Item.Cells(11).Text = lStrAmount
                End If
            End If

            'Patient payment
            If e.Item.Cells(12).Text <> "" Then
                lStrAmount = e.Item.Cells(12).Text
                If (lStrAmount.Substring(0, 1) = "-") Then
                    lStrAmount = "(" & lStrAmount.Remove(0, 1) & ")"
                    e.Item.Cells(12).Text = lStrAmount
                End If
            End If

            'CPT Balance
            If e.Item.Cells(14).Text <> "" Then
                lStrAmount = e.Item.Cells(14).Text
                If (lStrAmount.Substring(0, 1) = "-") Then
                    lStrAmount = "(" & lStrAmount.Remove(0, 1) & ")"
                    e.Item.Cells(14).Text = lStrAmount
                End If
            End If


            '**************************

        



        End If

      

    End Sub

    Private Sub loadheaderinformation(ByVal pPaymentID As String)
        Dim lUser As User = CType(Session("User"), User)
        Dim lPaymentHdr As New PaymentHdr(lUser.ConnectionString)
        Dim lresult As Boolean

        lPaymentHdr.PaymentHdr.PaymentID = ViewState("PaymentID")
        lresult = lPaymentHdr.GetRecordByID()

        If (lresult) Then
            lblPaymentAmount.Text = lPaymentHdr.PaymentHdr.Amount
            lblAppliedAmount.Text = IIf(lPaymentHdr.CalculateAppliedAmount(ViewState("PaymentID")) = "", 0, lPaymentHdr.CalculateAppliedAmount(ViewState("PaymentID")))
            lblPayerName.Text = lPaymentHdr.PaymentHdr.PayerName
            lblChequeNumber.Text = lPaymentHdr.PaymentHdr.CheckNumber


            If (lPaymentHdr.PaymentHdr.PayerType = "P") Then
                txtPatient.Text = lPaymentHdr.PaymentHdr.PayerName.Replace(", ", ",")
                txtPatient.Value = lPaymentHdr.PaymentHdr.PayerID
            End If


            If (lPaymentHdr.PaymentHdr.PaymentDate <> "") Then
                lblPaymentDate.Text = lPaymentHdr.PaymentHdr.PaymentDate.Substring(0, lPaymentHdr.PaymentHdr.PaymentDate.IndexOf(" ") + 1)
            End If

            lblDisplayID.Text = lPaymentHdr.PaymentHdr.DisplayID

            If (lPaymentHdr.PaymentHdr.CheckDate <> "") Then
                lblCheckDate.Text = lPaymentHdr.PaymentHdr.CheckDate.Substring(0, lPaymentHdr.PaymentHdr.CheckDate.IndexOf(" ") + 1)
            End If

            lblPayerType.Text = lPaymentHdr.PaymentHdr.PayerType
            lblPaymentMode.Text = lPaymentHdr.PaymentHdr.PaymentMode

        End If




    End Sub

    Protected Sub grdHCFA_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdHCFA.NeedDataSource

        'If (Session("AdjustmentClick") = False) Then
        '    Exit Sub
        'End If

        mPaymentDtlCollection = Session("PaymentDetailCollectionForHeader")
        grdHCFA.DataSource = Nothing
        grdHCFA.DataSource = mPaymentDtlCollection.Values
        'Session("AdjustmentClick") = False


    End Sub

    Private Sub FillForVisit()
        Dim lds As DataSet = Nothing
        Dim lPatientSuperBillID As String = String.Empty
        txtPatient.Enabled = False
        btnPatientSearch.Enabled = False
        dtFromDate.Enabled = False
        dtTodate.Enabled = False
        ImgSearch.Enabled = False
        ImgAddRecords.Enabled = False
        Try
            ''for binding Visit Grid......
            lPatientSuperBillID = ViewState("VisitID") 'Request.QueryString.Get(0).ToString
            lds = SuperBillMethods.GetPatientSuperBillForApplyPayment("And PatientSuperBillID=" & lPatientSuperBillID & " And status='Approved'")

            If (lds.Tables(0).Rows.Count > 0) Then

                grdVisit.DataSource = lds
                grdVisit.Columns(6).Visible = True
                grdVisit.DataBind()
                grdVisit.Columns(6).Visible = False

                CType(grdVisit.Rows(0).FindControl("CheckBox1"), CheckBox).Checked = True
                CType(grdVisit.Rows(0).FindControl("CheckBox1"), CheckBox).Enabled = False



                'Session("PaymentDetailCollectionForHeader") = mPaymentDtlCollection
                AddRecordsInHcfa()

            End If



        Catch ex As Exception
            Response.Write(ex.Message)
        End Try
    End Sub

    Private Sub AddRecordsInHcfa()
        Dim lUser As User = CType(Session("User"), User)
        Dim lds As DataSet = Nothing
        Dim lPaymentDtlDb As PaymentDtlDB
        Dim li As Integer = 0
        Dim lrow As Integer = 0
        Try
            If (Session("PaymentDetailCollectionForHeader") IsNot Nothing) Then
                mPaymentDtlCollection = Session("PaymentDetailCollectionForHeader")
            End If

            For Each litem As GridViewRow In grdVisit.Rows
                If CType(litem.FindControl("CheckBox1"), CheckBox).Checked = True Then
                    lPaymentDtlDb = PaymentMethods.GetForMasterApplyPaymentGrid(litem.Cells(6).Text)
                    ''populating fields...
                    lPaymentDtlDb.PaymentID = ViewState("PaymentID")
                    lPaymentDtlDb.VisitId = litem.Cells(6).Text
                    lPaymentDtlDb.UserId = lUser.UserId
                    lPaymentDtlDb.EntryDate = Now.Date
                    lPaymentDtlDb.FormattedDisplayID = litem.Cells(1).Text 'CType(litem.FindControl("LinkButton1"), LinkButton).Text
                    ''
                    If (mPaymentDtlCollection.ContainsKey(litem.Cells(6).Text) = False) Then
                        mPaymentDtlCollection.Add(lPaymentDtlDb.PatientSuperBillID, lPaymentDtlDb)
                    End If

                Else

                    lPaymentDtlDb = PaymentMethods.GetForMasterApplyPaymentGrid(litem.Cells(6).Text)
                    If (mPaymentDtlCollection.ContainsKey(litem.Cells(6).Text) = True) Then
                        mPaymentDtlCollection.Remove(lPaymentDtlDb.PatientSuperBillID)
                    End If

                End If
            Next


            If (Not Page.IsPostBack) Then
                If (Session("_ordersExpandedState") IsNot Nothing) Then
                    Session.Remove("_ordersExpandedState")
                End If

                If (Me.Session("_selectedState") IsNot Nothing) Then
                    Session.Remove("_selectedState")
                End If
            End If


            grdHCFA.DataSource = mPaymentDtlCollection.Values
            grdHCFA.DataBind()


            Session("PaymentDetailCollectionForHeader") = mPaymentDtlCollection

        Catch ex As Exception
            Response.Write(ex.Message)
        End Try
    End Sub

    'Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
    '    Response.Redirect("PaymentSearch.aspx")
    'End Sub

    Protected Sub btnSave2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave2.Click
        mPaymentDtlCollection = Session("PaymentDetailCollectionForHeader")
        Dim lpaymentdtl As PaymentDtlDB = Nothing

        lpaymentdtl = mPaymentDtlCollection.Item(hdVisitID.Value)

        lpaymentdtl.Notes = hdComment.Value

        Session("PaymentDetailCollectionForHeader") = mPaymentDtlCollection
        grdHCFA.Rebind()
    End Sub

    Private Sub insertForvisit()
        Dim lUser As User = CType(Session("User"), User)
        mPaymentDtlCollection = Session("PaymentDetailCollectionForHeader")

        Try
            Dim lPaymentDtldb As New PaymentDtlDB()

            Dim lpaymentdtl As New PaymentDtl(lUser.ConnectionString)

            lPaymentDtldb = mPaymentDtlCollection.Item(ViewState("VisitID"))

            lpaymentdtl.PaymentDtl = lPaymentDtldb

            lpaymentdtl.InsertAdjustment()

            lpaymentdtl.InsertPaymentCptDetail()

            'Response.Write("<script>alert('Adjustment inserted successfully');</script>")
            Page.RegisterStartupScript("testscript", "<script language='javascript'>alert('Adjustment inserted successfully');window.location='VisitSummarySearch.aspx';</script>")


        Catch ex As Exception
            Response.Write("<script>alert('Error in saving adjustment');</script>")
        End Try

    End Sub

    Private ReadOnly Property ExpandedStates() As Hashtable
        Get

            If Me._ordersExpandedState Is Nothing Then
                _ordersExpandedState = TryCast(Me.Session("_ordersExpandedState"), Hashtable)
                If _ordersExpandedState Is Nothing Then
                    _ordersExpandedState = New Hashtable()
                    Me.Session("_ordersExpandedState") = _ordersExpandedState
                End If
            End If

            Return Me._ordersExpandedState
        End Get
    End Property

    Private Sub ClearExpandedChildren(ByVal parentHierarchicalIndex As String)
        Dim indexes As String() = New String(Me.ExpandedStates.Keys.Count - 1) {}
        Me.ExpandedStates.Keys.CopyTo(indexes, 0)
        For Each index As String In indexes
            'all indexes of child items
            If index.StartsWith(parentHierarchicalIndex & "_") OrElse index.StartsWith(parentHierarchicalIndex & ":") Then
                Me.ExpandedStates.Remove(index)
            End If
        Next

        'If Not CType(grdHCFA.Items(parentHierarchicalIndex).Cells(2).FindControl("txtPayment"), TextBox).Enabled Then
        '    Me.ClientScript.RegisterStartupScript(Me.GetType, mIndex, "<script>ApplyCSS('" & CType(grdHCFA.Items(parentHierarchicalIndex).Cells(2).FindControl("txtPayment"), TextBox).ClientID & "', 'textfield-disabled');</script>")
        '    mIndex += 1
        'End If
    End Sub

    Private ReadOnly Property SelectedStates() As Hashtable
        Get
            If Me._selectedState Is Nothing Then
                _selectedState = TryCast(Me.Session("_selectedState"), Hashtable)
                If _selectedState Is Nothing Then
                    _selectedState = New Hashtable()
                    Me.Session("_selectedState") = _selectedState
                End If
            End If

            Return Me._selectedState
        End Get
    End Property


    Public Sub PageExpire()
        Response.Buffer = True
        Response.ExpiresAbsolute = Now.Subtract(New TimeSpan(1, 0, 0, 0))
        Response.Expires = 0
        Response.CacheControl = "no-cache"
    End Sub



End Class
