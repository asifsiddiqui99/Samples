Imports Telerik.WebControls
Imports System.Drawing
Partial Class Billing_ClaimBatchSearch
    Inherits System.Web.UI.Page

    Protected Sub grdBatch_DetailTableDataBind(ByVal source As Object, ByVal e As Telerik.WebControls.GridDetailTableDataBindEventArgs) Handles grdBatch.DetailTableDataBind
        Dim parentItem As GridDataItem = CType(e.DetailTableView.ParentItem, GridDataItem)
        e.DetailTableView.DataSource = ClaimBatchMethods.searchClaimDtlByID(parentItem("BatchID").Text)

    End Sub

    Protected Sub grdBatch_ItemDataBound(ByVal sender As Object, ByVal e As Telerik.WebControls.GridItemEventArgs) Handles grdBatch.ItemDataBound
        Dim lChk As CheckBox
        If (e.Item.ItemType = GridItemType.Item Or e.Item.ItemType = GridItemType.AlternatingItem) Then
            lChk = CType(e.Item.Cells(2).FindControl("selectSelectCheckBox"), CheckBox)
            If (Not lChk Is Nothing) Then
                If (e.Item.Cells(8).Text = "Y") Then
                    lChk.Checked = True
                    lChk.Enabled = False
                    e.Item.Cells(4).ForeColor = Color.Green

                Else

                    e.Item.Cells(4).ForeColor = Color.Red
                End If
            End If
        End If
    End Sub

    Protected Sub grdBatch_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdBatch.NeedDataSource
        'If (Page.IsPostBack) Then
        Dim lresult As String = String.Empty

        lresult = CreateSearchCondition()
        If (lresult <> "Error") Then
            grdBatch.DataSource = ClaimBatchMethods.SearchBatch(lresult)
        End If


        'End If
    End Sub

    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSearch.Click
        'txtPatientID.Text = ""
        'btnBackPS.Visible = False
        grdBatch.Rebind()
    End Sub

    Public Function CreateSearchCondition() As String
        Dim lCondition As String = ""



        ''added by madiha
        Dim lPatientname As String = String.Empty
        Dim lvalue() As String
        Dim lLastName As String = String.Empty
        Dim lFirstName As String = String.Empty
        If cmbPatient.Text.Trim <> "" Then
            lPatientname = cmbPatient.Text
            If lPatientname.Contains(",") Then
                lvalue = lPatientname.Split(",")
                lLastName = lvalue(0)
                lFirstName = lvalue(1)
                txtPatientName.Text = lLastName & ",%" & lFirstName

            Else
                lLastName = cmbPatient.Text
                txtPatientName.Text = lLastName
            End If
        Else
            txtPatientName.Text = ""
        End If
        ''
        Try
            'If ((Me.dtBatchDateFrom.DbSelectedDate) > (Me.dtBatchDateTo.DbSelectedDate)) Then
            '    Dim lMessage As String = String.Empty
            '    lMessage = "InValid Date Range"
            '    Response.Write("<script type='text/javascript' language=""JavaScript"">alert(""" + lMessage + """);</script>")
            '    Return "Error"
            'End If

            'If ((Me.dpDOSFrom.DbSelectedDate) > (Me.dpDOSTo.DbSelectedDate)) Then
            '    Dim lMessage As String = String.Empty
            '    lMessage = "InValid Date Range"
            '    Response.Write("<script type='text/javascript' language=""JavaScript"">alert(""" + lMessage + """);</script>")
            '    Return "Error"
            'End If



            If ((Not Me.dtBatchDateFrom.DbSelectedDate Is Nothing) And (Not Me.dtBatchDateFrom.DbSelectedDate Is Nothing)) Then
                Dim lBatchDateTo As DateTime = dtBatchDateTo.DbSelectedDate
                lBatchDateTo = lBatchDateTo.AddDays(1)

                lCondition = " AND B.CreationDate between Convert(varchar,Cast(''" & dtBatchDateFrom.DbSelectedDate.ToString & "'' as datetime),111) And Convert(varchar,Cast(''" & lBatchDateTo.ToString & "'' as datetime),111)"

            End If

            If (Not Me.dtSendDate.DbSelectedDate Is Nothing) Then
                lCondition = lCondition & " AND convert(varchar,isNull(B.SendDate,1900-01-01),101)=Convert(varchar,Cast(''" & dtSendDate.DbSelectedDate.ToString & "'' as datetime),101)"
            End If

            'If ((Me.cmbBatchStatus.Text.ToUpper() <> "ALL") Or (Me.cmbBatchStatus.Text.ToUpper() <> "")) Then
            '    If (Me.cmbBatchStatus.Text.ToUpper() = "SENT") Then
            '        lCondition = lCondition & " AND B.Status=''Y''"
            '    Else
            '        lCondition = lCondition & " AND B.Status=''N''"
            '    End If
            'End If

            If (Me.txtBatchID.Text <> "") Then
                lCondition = lCondition & " AND ''BT-'' + Cast(Year(B.CreationDate) as Varchar) + ''-'' + Cast(Month(B.CreationDate) as Varchar) + ''-'' + Right(REPLICATE(''0'', 5) + Cast(B.BatchDisplayId As Varchar),5)=''" & Utility.AdjustApostrophie(Me.txtBatchID.Text) & "''"
            End If

            If (Me.txtClaimID.Text <> "") Then
                lCondition = lCondition & " AND B.BatchID=(Select BatchID from ClaimBatchDtl where ClaimID=(Select Top(1) HcfaID from HCFAUpdated where ''CL-'' + Cast(Year(HcfaPreparedDate) as Varchar) + ''-'' + Right(REPLICATE(''0'', 2) + Cast(Month(HcfaPreparedDate) as Varchar),2) + ''-'' + Right(REPLICATE(''0'', 5) + Cast(HcfaDisplayId As Varchar),5)=''" & Utility.AdjustApostrophie(Me.txtClaimID.Text) & "''))"
            End If

            If (Me.txtPatientName.Text <> "") Then
                lCondition = lCondition & " AND B.BatchID in (Select BatchID from ClaimBatchDtl CBD inner join PatientSuperBill PSB on PSB.PatientSuperBillID=CBD.VisitID And PSB.PatientName like ''" & txtPatientName.Text & "%'')"
                'ElseIf (txtPatientID.Text <> "") Then
                '    lCondition = lCondition & " AND B.BatchID in (Select BatchID from ClaimBatchDtl CBD inner join PatientSuperBill PSB on PSB.PatientSuperBillID=CBD.VisitID And PSB.PatientID = ''" & txtPatientID.Text & "'')"
            End If

            If (Me.cmbFavouriteInsurance.SelectedItem.Text <> "All") Then
                lCondition = lCondition & " AND B.BatchID in (Select distinct BatchID from ClaimBatchDtl CBD inner join HCFAUpdated on CBD.VisitID=HCFAUpdated.PatientSuperBillID where HCFAUpdated.MainICCompanyName = ''" & cmbFavouriteInsurance.SelectedItem.Text & "'')"

            End If

            If ((Not dpDOSFrom.DbSelectedDate Is Nothing) And (Not dpDOSTo.DbSelectedDate Is Nothing)) Then
                Dim ldpDOSTo As DateTime = dpDOSTo.DbSelectedDate


                lCondition = lCondition & " AND B.BatchID in (Select distinct BatchID from ClaimBatchDtl CBD inner join PatientSuperBill on CBD.VisitID=PatientSuperBill.PatientSuperBillID where  PatientSuperBill.VisitDisplayDate between Convert(varchar,Cast(''" & dpDOSFrom.DbSelectedDate.ToString & "'' as datetime),101) And Convert(varchar,Cast(''" & ldpDOSTo.ToString & "'' as datetime),101))"
            End If

        Catch ex As Exception
            Return ""
        End Try

        Return lCondition

    End Function

    Protected Sub btnSend_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSend.Click
        Try
            If (chkIs5010.Checked = True) Then

                '*********** "chkIs5010.Checked=True" Code starts from here ***********
                lblMsg.Visible = False
                Dim lBatchId() As String
                Dim lBatchDisplayID() As String
                Dim lBatchIdArrayList As New ArrayList()
                Dim lBatchDisplayIdArrayList As New ArrayList()
                Dim lResult As String = ""
                For Each lrow As GridDataItem In grdBatch.MasterTableView.Items
                    Dim lCheckbox As CheckBox
                    lCheckbox = CType(lrow.FindControl("selectSelectCheckBox"), CheckBox)
                    If (lCheckbox.Checked = True AndAlso lrow.Cells(8).Text = "N") Then
                        lBatchIdArrayList.Add(lrow.Cells(3).Text)
                        lBatchDisplayIdArrayList.Add(lrow.Cells(4).Text)
                    End If
                Next
                lBatchId = CType(lBatchIdArrayList.ToArray(GetType(String)), String())
                lBatchDisplayID = CType(lBatchDisplayIdArrayList.ToArray(GetType(String)), String())
                If (lBatchId.Length < 1 AndAlso lBatchDisplayID.Length < 1) Then
                    Response.Write("<script>alert('No batch to send.')</script>")
                Else
                    lResult = ClaimBatchMethods.SendClaimBatch(lBatchId, lBatchDisplayID, True)
                    Response.Write("<script language='javascript'>alert('" & lResult & "');history.go(-(history.length));window.location='ClaimBatchSearch.aspx';</script>")
                End If
                grdBatch.Rebind()
                '*********** "chkIs5010.Checked=True" Code ends here ***********

            Else

                '*********** "chkIs5010.Checked=False" Code starts from here ***********
                lblMsg.Visible = False
                Dim lBatchId() As String
                Dim lBatchDisplayID() As String
                Dim lBatchIdArrayList As New ArrayList()
                Dim lBatchDisplayIdArrayList As New ArrayList()
                Dim lResult As String = ""
                For Each lrow As GridDataItem In grdBatch.MasterTableView.Items
                    Dim lCheckbox As CheckBox
                    lCheckbox = CType(lrow.FindControl("selectSelectCheckBox"), CheckBox)
                    If (lCheckbox.Checked = True AndAlso lrow.Cells(8).Text = "N") Then
                        lBatchIdArrayList.Add(lrow.Cells(3).Text)
                        lBatchDisplayIdArrayList.Add(lrow.Cells(4).Text)
                    End If
                Next
                lBatchId = CType(lBatchIdArrayList.ToArray(GetType(String)), String())
                lBatchDisplayID = CType(lBatchDisplayIdArrayList.ToArray(GetType(String)), String())
                If (lBatchId.Length < 1 AndAlso lBatchDisplayID.Length < 1) Then
                    Response.Write("<script>alert('No batch to send.')</script>")
                Else
                    lResult = ClaimBatchMethods.SendClaimBatch(lBatchId, lBatchDisplayID, False)
                    Response.Write("<script language='javascript'>alert('" & lResult & "');history.go(-(history.length));window.location='ClaimBatchSearch.aspx';</script>")
                End If
                grdBatch.Rebind()
                '*********** "chkIs5010.Checked=False" Code ends here ***********

            End If

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim queryString As NameValueCollection = Nothing
        Dim lPatientID As String
        Dim lPatient As New PatientDBExtended
        Try
            If (ConfigurationManager.AppSettings.Item("EdiVersion").ToString = "5010") Then
                chkIs5010.Checked = True
            Else
                chkIs5010.Checked = False
            End If
            If (Page.IsPostBack = False) Then
                Dim lUser As User
                lUser = CType(Session("User"), User)
                Dim lInsurance As New Insurance(lUser.ConnectionString)
                'Utility.SelectComboItem(cmbBatchStatus, "0", True)
                cmbFavouriteInsurance.DataSource = lInsurance.GetInsuranceRecords(" Order By CompanyName")
                cmbFavouriteInsurance.DataBind()
                cmbFavouriteInsurance.Items.Insert(0, "All")
                dtBatchDateFrom.DbSelectedDate = DateTime.Now.AddMonths(-6)
                dtBatchDateTo.DbSelectedDate = Now.Date
                If (Request.QueryString.Count > 0) Then
                    queryString = Encryption.DecryptQueryString(Request.QueryString.ToString())
                    If (queryString IsNot Nothing) Then
                        lPatientID = queryString("id").ToString
                        txtPatientID.Text = lPatientID
                        lPatient = PatientMethods.LoadPatientsById(lPatientID, lUser)
                        cmbPatient.Text = lPatient.LastName & "," & lPatient.FirstName
                        btnBackPS.Visible = True
                    End If
                End If
                grdBatch.Rebind()

            End If
        Catch ex As Exception

        End Try
    End Sub
   
    Protected Sub btnMirror_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnMirror.Click
        Dim newWindow As RadWindow
        Try
            newWindow = New RadWindow()
            If (cmbPatient.Text.ToString.Split(",").Length = 1) Then
                newWindow.NavigateUrl = "PatientSearch.aspx?srch=" & Utility.AdjustApostrophie(Me.cmbPatient.Text.ToString.Split(",")(0)) & "|" & "" & ""
            ElseIf (cmbPatient.Text.ToString.Split(",").Length > 1) Then
                newWindow.NavigateUrl = "PatientSearch.aspx?srch=" & Utility.AdjustApostrophie(Me.cmbPatient.Text.ToString.Split(",")(0)) & "|" & Me.cmbPatient.Text.ToString.Split(",")(1) & ""
            Else

            End If
            newWindow.ID = "rwPrimaryInsurer"
            newWindow.VisibleOnPageLoad = True
            newWindow.Top = 220
            newWindow.Left = 280
            newWindow.Width = Unit.Pixel(697)
            newWindow.Height = Unit.Pixel(400)
            newWindow.VisibleTitlebar = False
            newWindow.VisibleStatusbar = False
            newWindow.BorderStyle = BorderStyle.Solid
            newWindow.ReloadOnShow = True
            newWindow.BackColor = Drawing.Color.Transparent
            newWindow.ClientCallBackFunction = "PatientSearchCallBackFunction"
            newWindow.Enabled = True
            newWindow.Visible = True
            rwmSuperBill.Windows.Add(newWindow)
        Catch ex As Exception
            Dim lLogID As String = String.Empty
            lLogID = ErrorLogMethods.LogError(ex, " Billing_PatientLedgerPage.aspx\btnMirror_Click() ")
            Response.Redirect("~/ErrorPage.aspx?LogID=" & lLogID, False)
        End Try
    End Sub

    Protected Sub btnBackPS_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnBackPS.Click
        Dim lPatientID As String
        Try
            lPatientID = ElixirLibrary.Encryption.EncryptQueryString("id=" & txtPatientID.Text)
            Response.Redirect("selectpatient.aspx" & lPatientID)
        Catch ex As Exception

        End Try
    End Sub


End Class
