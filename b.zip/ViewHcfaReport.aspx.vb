Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports System.Data
Imports ElixirLibrary
Imports System.Data.SqlClient

Partial Class Billing_ViewHcfaReport
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'CrystalReportViewer1.ReportSource = Server.MapPath("HCFA.rpt")
        Dim lDs As New DataSet
        Dim lUser As User = CType(HttpContext.Current.Session("User"), User)
        Dim lConnection As New Connection(lUser.ConnectionString)
        Dim lHcfaId As Int32 = 0
        Dim lHcfaRowCount As Int32 = 0

        If (Request.QueryString("HCFAID") IsNot Nothing AndAlso Request.QueryString("HCFAID") <> "") Then
            lHcfaId = Request.QueryString("HCFAID")
        End If

        Dim lQuery As String = "Exec GetHcfaForReportNEW " & lHcfaId
        'Dim lQuery As String = "select *  from HCFA H, PatientCpt C where H.hcfaid=c.hcfaid and h.hcfaid=" & lHcfaId
        lDs = lConnection.ExecuteQuery(lQuery)

        If (lDs.Tables(0).Rows.Count < 6) Then
            Dim lrow As DataRow
            For lHcfaRowCount = lDs.Tables(0).Rows.Count To 5
                lrow = lDs.Tables(0).NewRow()
                lrow.ItemArray = lDs.Tables(0).Rows(0).ItemArray.Clone
                lrow.Item("CPTCODE") = ""
                lrow.Item("FacilitySecondaryIdentificationQualifier") = ""
                lrow.Item("DateOfServiceFrom") = ""
                lrow.Item("DateOfServiceTo") = ""
                lrow.Item("PlaceOfService") = DBNull.Value
                lrow.Item("DignosisPointer") = DBNull.Value
                lrow.Item("Charges") = DBNull.Value
                lrow.Item("Days") = DBNull.Value
                lrow.Item("EPSDT") = ""
                lrow.Item("NPI") = ""
                lDs.Tables(0).Rows.Add(lrow)
            Next
        End If
       
        CrystalReportViewer1.DisplayGroupTree = False
        CrystalReportViewer1.HasCrystalLogo = False
        CrystalReportViewer1.HasToggleGroupTreeButton = False
        CrystalReportViewer1.HasZoomFactorList = False

        CrystalReportViewer1.Zoom(130)
        CrystalReportViewer1.BestFitPage = False
        CrystalReportViewer1.Width = New Unit("100%")
        CrystalReportViewer1.Height = New Unit("100%")
        CrystalReportViewer1.HasSearchButton = False
        CrystalReportViewer1.HasViewList = False

        Dim myReportDocument As New ReportDocument()
        'myReportDocument.PrintOptions.PaperSize = PaperSize.PaperEnvelopeB4

        myReportDocument.Load(Server.MapPath("HCFANew.rpt"))
        myReportDocument.SetDataSource(lDs.Tables(0))

        Session.Add("ReportDocument", myReportDocument)

        'CrystalReportViewer1.ReportSource = myReportDocument
        'CrystalReportViewer1.DataBind()
        'CrystalReportViewer1.PrintMode = CrystalDecisions.Web.PrintMode.ActiveX

        ' Export the document to PDF
        Response.ClearContent()
        Response.ClearHeaders()
        Response.ContentType = "application/pdf"


        myReportDocument.ExportToHttpResponse(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat, Response, False, "")
        Response.Flush()
        Response.Close()
        ' Export the document to PDF

    End Sub

    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload
        Dim myReportDocument As ReportDocument

        If Session("ReportDocument") IsNot Nothing Then
            myReportDocument = CType(Session("ReportDocument"), ReportDocument)
            myReportDocument.Close()
            myReportDocument.Dispose()
            Session.Remove("ReportDocument")
        End If

    End Sub
   
End Class
