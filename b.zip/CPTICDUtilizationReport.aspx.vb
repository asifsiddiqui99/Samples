Imports Telerik.WebControls

Partial Class Billing_CPTICD
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim lRadWindow As Telerik.WebControls.RadWindow
        Dim lData As String()
        Dim lDAte As New Date
        lDAte = Date.Now
        If Not Page.IsPostBack Then
            rdoCPT.Checked = True
            dtFrom.SelectedDate = lDAte.AddMonths(-6)
            dpTo.SelectedDate = Date.Now
            Session.Remove("ICD9Coll")
            Session.Remove("CPTColl")
            

        End If

        If Page.IsPostBack Then
            LoadReport()
        End If
      

    End Sub


    Protected Sub btnICDSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnICDSearch.Click

        If rdoICD.Checked Then
            AjxMSuperBill.ResponseScripts.Add("window.radopen('SearchICD9.aspx?icd=" & Server.UrlEncode(txtICD.Text) & "','rwICD9Search');")

        End If
        If rdoCPT.Checked Then
            AjxMSuperBill.ResponseScripts.Add("window.radopen('SearchCPT.aspx?cpt=" & Server.UrlEncode(txtICD.Text) & "','rwCPTSearch');")

        End If


    End Sub

    


    Protected Sub btnICDCancel_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)
        Response.Redirect("SuperBillSetup.aspx")
    End Sub

  

    

   

    Public Sub LoadReport()
        Dim lDS As DataSet
        If rdoCPT.Checked Then
            lDS = SuperBillMethods.GetCPTFromDateRange(txtICD.Text, dtFrom.SelectedDate, dpTo.SelectedDate)
        Else
            lDS = SuperBillMethods.GetICDFromDateRange(txtICD.Text, dtFrom.SelectedDate, dpTo.SelectedDate)
        End If

        Dim myReportDocument As CrystalDecisions.CrystalReports.Engine.ReportDocument
        Try


            lDS.Tables(0).TableName = "CPTICD"
            RemoveReportDoc()

            If lDS.Tables(0).Rows.Count = 0 Then
                Panel3.Visible = True
                lblMessage.Text = "No Record found"
                Return
            End If

            If Session("ReportDocument") Is Nothing Then
                myReportDocument = New CrystalDecisions.CrystalReports.Engine.ReportDocument()
            Else
                myReportDocument = CType(Session("ReportDocument"), CrystalDecisions.CrystalReports.Engine.ReportDocument)
            End If



            myReportDocument.Load(Server.MapPath("Reports/CPTICDUtilizationReport.rpt"))
            myReportDocument.SetDataSource(lDS)


            Session.Add("ReportDocument", myReportDocument)
            crReport.ReportSource = myReportDocument
            crReport.DataBind()

        Catch ex As Exception

        End Try

    End Sub


    Protected Sub rdoCPT_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdoCPT.CheckedChanged
        txtICD.Text = ""
        Panel2.Visible = False
        RemoveReportDoc()
        Panel3.Visible = False
    End Sub

    Private Sub RemoveReportDoc()
        Dim myReportDocument As CrystalDecisions.CrystalReports.Engine.ReportDocument
        Try
            If Session("ReportDocument") IsNot Nothing Then
                myReportDocument = CType(Session("ReportDocument"), CrystalDecisions.CrystalReports.Engine.ReportDocument)
                myReportDocument.Close()
                myReportDocument.Dispose()
                Session.Remove("ReportDocument")
            End If

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload
        Try
            Dim myReportDocument As CrystalDecisions.CrystalReports.Engine.ReportDocument
            RemoveReportDoc()
            If Session("ReportDocument") IsNot Nothing Then
                myReportDocument = CType(Session("ReportDocument"), CrystalDecisions.CrystalReports.Engine.ReportDocument)
                myReportDocument.Close()
                myReportDocument.Dispose()
                Session.Remove("ReportDocument")


            End If
            crReport.Dispose()
            crReport = Nothing
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub btnView_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnView.Click
        Panel3.Visible = False
        Try
            LoadReport()
            Panel2.Visible = True
        Catch ex As Exception

        End Try

    End Sub
End Class
