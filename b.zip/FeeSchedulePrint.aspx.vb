
Partial Class FeeSchedulePrint
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
      
        Dim lQueryString As String = String.Empty
        Try
            lQueryString = Session("sCompanyName")
            FillGrid()
           
            lblCompanyName.Text = "Fee schedule of " & lQueryString
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "alert", "hello();", True)
        Catch ex As Exception

        End Try

    End Sub


    Sub FillGrid()
        'Dim lDataTable As New DataTable()
        'Dim lds As New DataSet
        'Dim lDatarow As DataRow
        'Dim lGridview As GridView = Nothing
        'Dim lFee As Decimal = 0

        'lGridview = Session("FeeSchedule")

        'lDataTable.Columns.Add("CPTCode")
        'lDataTable.Columns.Add("Description")
        'lDataTable.Columns.Add("Modifiers")
        'lDataTable.Columns.Add("Fee")



        'For index As Integer = 0 To lGridview.Rows.Count - 1

        '    lDatarow = lDataTable.NewRow()
        '    lDatarow("CPTCode") = lGridview.Rows(index).Cells(1).Text.Replace("&nbsp;", "")
        '    lDatarow("Description") = lGridview.Rows(index).Cells(2).Text.Replace("&nbsp;", "")
        '    lDatarow("Modifiers") = lGridview.Rows(index).Cells(3).Text.Replace("&nbsp;", "")
        '    If CType(lGridview.Rows(index).Cells(2).FindControl("TextBox2"), TextBox).Text.Equals("") Then
        '        lDatarow("Fee") = CType(lGridview.Rows(index).Cells(2).FindControl("TextBox2"), TextBox).Text = "0"
        '    End If
        '    'lDatarow("Fee") = CType(lGridview.Rows(index).Cells(2).FindControl("TextBox2"), TextBox).Text()
        '    lFee = CDec(CType(lGridview.Rows(index).Cells(2).FindControl("TextBox2"), TextBox).Text())


        '    Dim returnValue As Decimal

        '    returnValue = Decimal.Round(lFee, 2)

        '    'lFee = Math.Round(lFee - 0.005, 2)
        '    lDatarow("Fee") = returnValue
        '    lDataTable.Rows.Add(lDatarow)
        'Next



        grdFeeSchedule.DataSource = Session("DataSource")
        grdFeeSchedule.DataBind()

    End Sub

   
    Protected Sub ImgbtnPrint_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImgbtnPrint.Click

    End Sub
End Class
