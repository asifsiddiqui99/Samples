Imports Telerik.WebControls

Partial Class Billing_GenerateSuperBill
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        tsGenerateSuperBill.SelectedIndex = 0
        mpGenerateSuperBill.SelectedIndex = 0

        If Request.QueryString("sid") Is Nothing Or _
           Request.QueryString("pid") Is Nothing Then
            Return
        End If
        txtSuperBillTemplateId.Text = Request.QueryString("sid").ToString()
        txtPatientID.Text = Request.QueryString("pid").ToString()

        LoadSuperBillOrderInformation()
        If Not Page.IsPostBack Then
            LoadClinic()
            LoadPatientData()
            EmployeeMethods.LoadDoctorsCombo(cmbProvider)
            lblDateOfService.Text = Date.Today.Date
            If cmbProvider.Items.Count > 0 Then
                cmbProvider.SelectedIndex = 0
                lblPrescriberName.Text = cmbProvider.SelectedItem.Text
            Else
                lblPrescriberName.Text = ""
            End If

        End If



        If hdnText.Text.Equals("") And Page.IsPostBack = False Then

            hdnText.Text = 0
            InitiateDates()


        End If





    End Sub


    Public Sub InitiateDates()
        dtDate11.SelectedDate = Date.Now
        dtDate12.SelectedDate = Date.Now

        dtDate21.SelectedDate = Date.Now
        dtDate22.SelectedDate = Date.Now

        dtDate31.SelectedDate = Date.Now
        dtDate32.SelectedDate = Date.Now

        dtDate41.SelectedDate = Date.Now
        dtDate42.SelectedDate = Date.Now

        dtDate51.SelectedDate = Date.Now
        dtDate52.SelectedDate = Date.Now

        dtDate61.SelectedDate = Date.Now
        dtDate62.SelectedDate = Date.Now

        dtDate71.SelectedDate = Date.Now
        dtDate72.SelectedDate = Date.Now

        dtDate81.SelectedDate = Date.Now
        dtDate82.SelectedDate = Date.Now

        dtDate91.SelectedDate = Date.Now
        dtDate92.SelectedDate = Date.Now

        dtDate101.SelectedDate = Date.Now
        dtDate102.SelectedDate = Date.Now

        dtDate111.SelectedDate = Date.Now
        dtDate112.SelectedDate = Date.Now

        dtDate121.SelectedDate = Date.Now
        dtDate122.SelectedDate = Date.Now

        dtDate131.SelectedDate = Date.Now
        dtDate132.SelectedDate = Date.Now

        dtDate141.SelectedDate = Date.Now
        dtDate142.SelectedDate = Date.Now

        dtDate151.SelectedDate = Date.Now
        dtDate152.SelectedDate = Date.Now

        dtDate161.SelectedDate = Date.Now
        dtDate162.SelectedDate = Date.Now

        dtDate171.SelectedDate = Date.Now
        dtDate172.SelectedDate = Date.Now

        dtDate181.SelectedDate = Date.Now
        dtDate182.SelectedDate = Date.Now


    End Sub


    Private Sub LoadClinic()
        Dim lUser As User
        Dim lClinic As ClinicDB
        Dim lState As StateDB
        Dim lPatientSuperBill As PatientSuperBill
        Dim lFormatedSuperBillId As String

        lUser = CType(Session("User"), User)
        lClinic = ClinicMethods.GetClinic(lUser)
        lPatientSuperBill = New PatientSuperBill(lUser.ConnectionString)

        lblClinicName.Text = lClinic.ClinicName
        lblClinicAddress.Text = lClinic.AddressLine1
        lblClinicCity.Text = lClinic.City
        lblClinicZipCode.Text = lClinic.ZipCode
        lState = StateMethods.GetState(lClinic.StateId)
        lblClinicState.Text = lState.Abbr

        lFormatedSuperBillId = lPatientSuperBill.GetUniqueId("")
        lFormatedSuperBillId = "RxCure-SB-" & lFormatedSuperBillId.PadLeft(8, "0")
        lblSuperBillID.Text = lFormatedSuperBillId
    End Sub

    Private Sub LoadPatientData()
        Dim lPatient As PatientDBExtended


        lPatient = PatientMethodsExtended.GetPatientDetails(txtPatientID.Text)

        lblPatientName.Text = lPatient.LastName & "," & lPatient.FirstName
        lblPatientDOB.Text = lPatient.DOB
        lblPatientAddress.Text = lPatient.AddressLine1 & " " & lPatient.AddressLine2
        lblPatientCity.Text = lPatient.City
        lblPatientState.Text = StateMethods.GetState(lPatient.StateID).Abbr
        lblPatientZipCode.Text = lPatient.ZipCode
        lblLastVisitDate.Text = GenerateSuperBillMethods.GetLastVisitDate(txtPatientID.Text)

        lblPrimaryInsuranceCompany.Text = lPatient.PrimaryInsurance.InsuranceCompanyName
        txtPrimaryInsuranceCompanyID.Text = lPatient.PrimaryInsurance.InsuranceCompanyID

        lblSecondaryInsuranceCompany.Text = lPatient.SecondaryInsurance.InsuranceCompanyName
        txtSecondaryInsuranceCompanyID.Text = lPatient.SecondaryInsurance.InsuranceCompanyID

        If lPatient.PrimaryInsurance.RelationshipToPrimaryInsurer <> "Self" Then

            txtInsuredID.Text = lPatient.PrimaryInsurance.InsurerId
        ElseIf lPatient.SecondaryInsurance.RelationshipToPrimaryInsurer <> "Self" Then
            txtInsuredID.Text = lPatient.SecondaryInsurance.InsurerId
        End If

        If txtInsuredID.Text <> "" Then
            lPatient = PatientMethodsExtended.GetPatientDetails(txtInsuredID.Text)            
            lblGuarantorName.Text = IIf(lPatient.PrimaryInsurance.RelationshipToPrimaryInsurer.Equals(""), "Self", lPatient.LastName & "," & lPatient.FirstName)
        End If

    End Sub


    Private Sub LoadSuperBillOrderInformation()
        Dim lUser As User
        Dim lSuperBill As SuperBill
        Dim lResult As Boolean

        lUser = CType(Session.Item("User"), User)


        lSuperBill = New SuperBill(lUser.ConnectionString)
        lSuperBill.SuperBill.SuperBillId = txtSuperBillTemplateId.Text
        lResult = lSuperBill.GetRecordByID()

        If Not lResult Then
            Return
        End If

        With lSuperBill.SuperBill           
            txtOrderBy.Text = lSuperBill.SuperBill.ICDSortBy & "|" & lSuperBill.SuperBill.ICDSortOrder & "|" & _
                                       lSuperBill.SuperBill.CPTSortBy & "|" & lSuperBill.SuperBill.CPTSortOrder
        End With
    End Sub


    Protected Sub grdCPT_ItemDataBound(ByVal sender As Object, ByVal e As Telerik.WebControls.GridItemEventArgs) Handles grdCPT1.ItemDataBound, grdCPT2.ItemDataBound, grdCPT3.ItemDataBound
        If e.Item.ItemType = GridItemType.GroupHeader Then
            e.Item.Cells(1).Text = e.Item.Cells(1).Text.ToString().Substring(e.Item.Cells(1).Text.IndexOf(":") + 1)
        End If
    End Sub


    Protected Sub grdCPT_ItemCreated(ByVal sender As Object, ByVal e As Telerik.WebControls.GridItemEventArgs) Handles grdCPT1.ItemCreated, grdCPT2.ItemCreated, grdCPT3.ItemCreated
        Dim lcheckBox As CheckBox
        Dim litem As GridHeaderItem

        If e.Item.ItemType = GridItemType.Header Then
            litem = e.Item
            lcheckBox = litem("Select").Controls(1)
            lcheckBox.Visible = False
        End If
    End Sub



    Protected Sub grdCPT1_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdCPT1.NeedDataSource
        GenerateSuperBillMethods.LoadCPTGrid(grdCPT1, txtSuperBillTemplateId.Text, txtOrderBy.Text, 0)
    End Sub

    Protected Sub grdCPT2_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdCPT2.NeedDataSource
        GenerateSuperBillMethods.LoadCPTGrid(grdCPT2, txtSuperBillTemplateId.Text, txtOrderBy.Text, 1)
    End Sub

    Protected Sub grdCPT3_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdCPT3.NeedDataSource
        GenerateSuperBillMethods.LoadCPTGrid(grdCPT3, txtSuperBillTemplateId.Text, txtOrderBy.Text, 2)
    End Sub

    Protected Sub grdICD1_ItemCreated(ByVal sender As Object, ByVal e As Telerik.WebControls.GridItemEventArgs) Handles grdICD1.ItemCreated, grdICD2.ItemCreated, grdICD3.ItemCreated
        Dim lcheckBox As CheckBox
        Dim litem As GridHeaderItem

        If e.Item.ItemType = GridItemType.Header Then
            litem = e.Item
            lcheckBox = litem("CheckboxSelectColumn").Controls(1)
            lcheckBox.Visible = False
        End If
    End Sub

    Protected Sub grdICD1_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdICD1.NeedDataSource
        GenerateSuperBillMethods.LoadICDGrid(grdICD1, txtSuperBillTemplateId.Text, txtOrderBy.Text, 0)
    End Sub

    Protected Sub grdICD2_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdICD2.NeedDataSource
        GenerateSuperBillMethods.LoadICDGrid(grdICD2, txtSuperBillTemplateId.Text, txtOrderBy.Text, 1)
    End Sub

    Protected Sub grdICD3_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdICD3.NeedDataSource
        GenerateSuperBillMethods.LoadICDGrid(grdICD3, txtSuperBillTemplateId.Text, txtOrderBy.Text, 2)
    End Sub

    Protected Sub btnICDSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnICD1Search.Click, btnICD2Search.Click, btnICD3Search.Click, btnICD4Search.Click
        Dim lSenderID As String = sender.id.ToString

        Select Case lSenderID
            Case "btnICD1Search"
                OpenWindow("SearchICD9.aspx?icd=" & txtICD1.Text & "&lid=1", "rwICD9Search", "ICDCallBackFunction")
            Case "btnICD2Search"
                OpenWindow("SearchICD9.aspx?icd=" & txtICD2.Text & "&lid=2", "rwICD9Search", "ICDCallBackFunction")
            Case "btnICD3Search"
                OpenWindow("SearchICD9.aspx?icd=" & txtICD3.Text & "&lid=3", "rwICD9Search", "ICDCallBackFunction")
            Case "btnICD4Search"
                OpenWindow("SearchICD9.aspx?icd=" & txtICD4.Text & "&lid=4", "rwICD9Search", "ICDCallBackFunction")
        End Select
    End Sub


    Protected Sub btnCPTSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnCPTSearch1.Click, _
                                                                                                                   btnCPTSearch2.Click, _
                                                                                                                   btnCPTSearch3.Click, btnCPTSearch4.Click, btnCPTSearch5.Click, btnCPTSearch6.Click, btnCPTSearch7.Click, btnCPTSearch8.Click, btnCPTSearch9.Click, btnCPTSearch10.Click, btnCPTSearch11.Click, _
                                                                                                                   btnCPTSearch12.Click, _
                                                                                                                   btnCPTSearch13.Click, _
                                                                                                                   btnCPTSearch14.Click, _
                                                                                                                   btnCPTSearch15.Click, _
                                                                                                                   btnCPTSearch16.Click, _
                                                                                                                   btnCPTSearch17.Click, _
                                                                                                                   btnCPTSearch18.Click


        Dim lSenderID As String = sender.id.ToString

        Select Case lSenderID
            Case "btnCPTSearch1"
                OpenWindow("SearchCPT.aspx?icd=" & txtCPT1.Text & "&lid=1", "rwCPTSearch", "CPTCallBackFunction")
            Case "btnCPTSearch2"
                OpenWindow("SearchCPT.aspx?icd=" & txtCPT2.Text & "&lid=2", "rwCPTSearch", "CPTCallBackFunction")
            Case "btnCPTSearch3"
                OpenWindow("SearchCPT.aspx?icd=" & txtCPT3.Text & "&lid=3", "rwCPTSearch", "CPTCallBackFunction")
            Case "btnCPTSearch4"
                OpenWindow("SearchCPT.aspx?icd=" & txtCPT4.Text & "&lid=4", "rwCPTSearch", "CPTCallBackFunction")
            Case "btnCPTSearch5"
                OpenWindow("SearchCPT.aspx?icd=" & txtCPT5.Text & "&lid=5", "rwCPTSearch", "CPTCallBackFunction")
            Case "btnCPTSearch6"
                OpenWindow("SearchCPT.aspx?icd=" & txtCPT6.Text & "&lid=6", "rwCPTSearch", "CPTCallBackFunction")
            Case "btnCPTSearch7"
                OpenWindow("SearchCPT.aspx?icd=" & txtCPT7.Text & "&lid=7", "rwCPTSearch", "CPTCallBackFunction")
            Case "btnCPTSearch8"
                OpenWindow("SearchCPT.aspx?icd=" & txtCPT8.Text & "&lid=8", "rwCPTSearch", "CPTCallBackFunction")
            Case "btnCPTSearch9"
                OpenWindow("SearchCPT.aspx?icd=" & txtCPT9.Text & "&lid=9", "rwCPTSearch", "CPTCallBackFunction")
            Case "btnCPTSearch10"
                OpenWindow("SearchCPT.aspx?icd=" & txtCPT10.Text & "&lid=10", "rwCPTSearch", "CPTCallBackFunction")
            Case "btnCPTSearch11"
                OpenWindow("SearchCPT.aspx?icd=" & txtCPT11.Text & "&lid=11", "rwCPTSearch", "CPTCallBackFunction")
            Case "btnCPTSearch12"
                OpenWindow("SearchCPT.aspx?icd=" & txtCPT12.Text & "&lid=12", "rwCPTSearch", "CPTCallBackFunction")
            Case "btnCPTSearch13"
                OpenWindow("SearchCPT.aspx?icd=" & txtCPT13.Text & "&lid=13", "rwCPTSearch", "CPTCallBackFunction")
            Case "btnCPTSearch14"
                OpenWindow("SearchCPT.aspx?icd=" & txtCPT14.Text & "&lid=14", "rwCPTSearch", "CPTCallBackFunction")
            Case "btnCPTSearch15"
                OpenWindow("SearchCPT.aspx?icd=" & txtCPT15.Text & "&lid=15", "rwCPTSearch", "CPTCallBackFunction")
            Case "btnCPTSearch16"
                OpenWindow("SearchCPT.aspx?icd=" & txtCPT16.Text & "&lid=16", "rwCPTSearch", "CPTCallBackFunction")
            Case "btnCPTSearch17"
                OpenWindow("SearchCPT.aspx?icd=" & txtCPT17.Text & "&lid=17", "rwCPTSearch", "CPTCallBackFunction")
            Case "btnCPTSearch18"
                OpenWindow("SearchCPT.aspx?icd=" & txtCPT18.Text & "&lid=18", "rwCPTSearch", "CPTCallBackFunction")
        End Select

    End Sub

   
    Protected Sub cmbProvider_SelectedIndexChanged(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxSelectedIndexChangedEventArgs) Handles cmbProvider.SelectedIndexChanged
        lblPrescriberName.Text = cmbProvider.SelectedItem.Text
    End Sub




    ''''''''''''''''''''''''''''''''''''''''''''''''''Change Log''''''''''''''''''''''''''''''''''''''''''''''''
    'Date : 25th July 2007 
    'By : Faraz Ahmed
    'Description : Return type from Boolean to integer for returning the PAtientSuperBillID    
    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''    

    Private Function SavePatientSuperBill() As Integer

        Dim lUser As User
        lUser = CType(Session.Item("User"), User)

        Dim lPatientSuperBillDB As New PatientSuperBillDB()
        Dim lResult As Integer

        With lPatientSuperBillDB
            .DateOfService = lblDateOfService.Text
            .SuperBillTemplateID = txtSuperBillTemplateId.Text
            .PatientId = txtPatientID.Text
            .PatientName = lblPatientName.Text
            .DOB = lblPatientDOB.Text
            .Address = lblPatientAddress.Text
            .City = lblPatientCity.Text
            .State = lblPatientState.Text
            .ZipCode = lblPatientZipCode.Text
            .PrimaryInsuranceCompanyId = txtPrimaryInsuranceCompanyID.Text
            .PrimaryInsuranceCompanyName = lblPrimaryInsuranceCompany.Text
            .SecondryInsuranceCompanyId = txtSecondaryInsuranceCompanyID.Text
            .SecondryInsuranceCompanyName = lblSecondaryInsuranceCompany.Text
            .GuarantorName = lblGuarantorName.Text
            .GuarantorID = txtInsuredID.Text
            .Balance = "0"
            Try
                .CopayAmount = CType(Me.txtCopayAmount.Text, Double)
                
            Catch ex As Exception
                .CopayAmount = 0.0
            End Try
            .PaymentMethod = Me.cmbPaymentMethod.Text

            .ChequeNumber = Me.txtChequeNumber.Text
            If (Me.dtChequeDate.SelectedDate.ToString <> "") Then
                .ChequeDate = Me.dtChequeDate.SelectedDate
            End If
            .PrescriberID = cmbProvider.SelectedItem.Value.Split("|")(0)

            ''line add by talha for approve check box.........
            If (checkapprove.Checked = True) Then
                .Status = "Approved"
            Else
                .Status = "UnApproved"
            End If

            .IsDeleted = "N"

        End With

        lResult = GenerateSuperBillMethods.AddPatientSuperBill(lPatientSuperBillDB, pnlBillingInfo, Request.Url.AbsoluteUri, cmbProvider.SelectedItem.Value.Split("|")(1))

        If ((checkapprove.Checked = True) And lResult) Then
            PatientLedgerMethods.SavePatientLedger(pnlBillingInfo, lPatientSuperBillDB)
        End If

        Return lResult


    End Function

    ''''''''''''''''''''''''''''''''''''''''''''''''''Change Log''''''''''''''''''''''''''''''''''''''''''''''''
    'Date : 25th July 2007 
    'By : Faraz Ahmed
    'Description : 
    '               (1) lResult Converted to int from boolean , 
    '               (2) Redirectd to PreviewSuperBill.aspx
    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''    
    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSave.Click, btnSavenPrint.Click
        Dim lResult As Integer

        lResult = SavePatientSuperBill()
        If Not lResult = 0 Then            
            If CType(sender, ImageButton).ID = "btnSavenPrint" Then
                Response.Redirect("PSBPrint.aspx?sid=" & lResult.ToString)
            Else
                Response.Redirect("Main.aspx")
            End If
        Else
            lblMessage.Text = "Error Generating Superbill, try agin later"
        End If
    End Sub

    Protected Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnCancel.Click
        Response.Redirect("Main.aspx")
    End Sub

 


   
    Private Sub OpenWindow(ByVal pNavigateUrl As String, ByVal pWindowId As String, ByVal pCallBackFunction As String)
        Dim newWindow As New RadWindow()

        newWindow.NavigateUrl = pNavigateUrl
        newWindow.ID = pWindowId
        newWindow.VisibleOnPageLoad = True
        newWindow.Top = 150
        newWindow.Left = 14
        newWindow.Width = Unit.Pixel(700)
        newWindow.Height = Unit.Pixel(315)
        newWindow.VisibleTitlebar = False
        newWindow.VisibleStatusbar = False
        newWindow.BorderStyle = BorderStyle.Solid
        newWindow.ReloadOnShow = True
        newWindow.BackColor = Drawing.Color.Transparent
        newWindow.ClientCallBackFunction = pCallBackFunction
        newWindow.Enabled = True
        newWindow.Visible = True
        'newWindow.Modal = True
        rwmGenerateSuperBill.Windows.Add(newWindow)

    End Sub



End Class

