Imports Telerik.WebControls


Partial Class Billing_AddInsuranceCompany
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim lUser As User
        Dim lRadWindow As RadWindow

        If Not Page.IsPostBack Then
            lUser = CType(Session.Item("User"), User)
            tsEmployee.SelectedIndex = 0
            mpEmployee.SelectedIndex = 0

            cmbState.Enabled = False

            'StateMethods.Load_States(cmbState, lUser)
            'cmbState.Items.Insert(0, New RadComboBoxItem("All"))

        End If

        'rwmInsurance.OpenerElementId = btnSearch.ClientID        
        lRadWindow = CType(rwmInsurance.FindControl("wndInsurance"), RadWindow)
        lRadWindow.NavigateUrl = "InsuranceList.aspx"


    End Sub

   
    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click

        If Session("InsuranceInformation") IsNot Nothing Then
            Dim lClinic As ClinicDB
            Dim lUser As User
            lUser = CType(Session.Item("User"), User)
            lClinic = ClinicMethods.GetClinic(lUser)

            Dim lRetrievedInformation As String = Session("InsuranceInformation").ToString
            txtCompany.Text = lRetrievedInformation.Split("|")(0)
            txtPayerID.Text = lRetrievedInformation.Split("|")(2)

            ''for loading of states...
            StateMethods.Load_States(cmbState, lUser)
            ''loading of states ends here.......

            If (lRetrievedInformation.Split("|")(1).ToUpper = "ALL") Then
                cmbState.SelectedIndex = cmbState.FindItemIndexByValue(lClinic.StateId)
                cmbState.Enabled = True
            Else
                cmbState.SelectedIndex = cmbState.FindItemIndexByText(lRetrievedInformation.Split("|")(1))
            End If

            ViewState("InsuranceID") = lRetrievedInformation.Split("|")(3)


            Session("InsuranceInformation") = Nothing
        End If
    End Sub

    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSearch.Click
        RadAjaxManager1.ResponseScripts.Add("window.radopen('InsuranceList.aspx?InsuranceName=" & txtCompany.Text & "','wndInsurance');")

    End Sub

   
    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSave.Click

        Dim lResult As String
        Dim lInsuranceDB As InsuranceDB = New InsuranceDB

        With lInsuranceDB
            .CompanyName = txtCompany.Text
            .InsuranceID = ViewState("InsuranceID")
            .PayerID = txtPayerID.Text
            .AddressLine1 = txtAddressLine1.Text
            .AddressLine2 = txtAddressLine2.Text
            .City = txtCity.Text
            .State = cmbState.Text
            .ZipCode = mtbZipCode.Text
            .ContactName = txtContactName.Text
            .InsuranceType = cmbInsuranceType.SelectedItem.Text
            .WorkPhone = mtbWorkPhone.Text
            .Fax = mtbFax.Text
            .Email = txtEmail.Text
            .BillType = cmbBillType.SelectedItem.Text

        End With

       
        lResult = InsuranceMethods.AddInsurance(lInsuranceDB)

        'lblMessage.Text = lResult
        Me.RadAjaxManager1.Alert(lResult)
        Me.RadAjaxManager1.Redirect("InsuranceSetup.aspx")
    End Sub

    Protected Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnCancel.Click
        Response.Redirect("InsuranceSetup.aspx")
    End Sub



    Protected Sub cmbState_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbState.ItemsRequested
        Dim lUser As User
        lUser = CType(Session.Item("User"), User)

        Dim lCond As String
        lCond = "And Abbr Like '" & Utility.AdjustApostrophie(e.Text) & "%' "

        If (e.Text = "") Then
            Exit Sub
        End If

        StateMethods.Load_States(cmbState, lUser, lCond)
        'cmbState.Items.Insert(0, New RadComboBoxItem("All"))
    End Sub
End Class
