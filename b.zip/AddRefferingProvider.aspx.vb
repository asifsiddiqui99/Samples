
Partial Class Billing_AddRefferingProvider
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim lUser As User

        If Not Page.IsPostBack Then

            lUser = CType(Session.Item("User"), User)
            tsEmployee.SelectedIndex = 0
            mpEmployee.SelectedIndex = 0

            StateMethods.Load_States(cmbState, lUser)
        End If

    End Sub
End Class
