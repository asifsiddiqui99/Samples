Imports Telerik.WebControls
Imports System.Web.SessionState.HttpSessionState
Partial Class Billing_EditFacilityDialog
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


        Try


            If (Not Page.IsPostBack) Then


                '*********************

                LoadData()

            End If

        Catch ex As Exception

        End Try
    End Sub

   

    Private Sub LoadData()

        Dim lHCFADBUpdated As HCFADBUpdated

        Try
            If (Session("HCFADBUpdated") Is Nothing) Then
                Exit Sub
            Else

                lHCFADBUpdated = CType(Session("HCFADBUpdated"), HCFADBUpdated)
                Me.txtFacilityId.Text = lHCFADBUpdated.ServiceFacility.FacilityID
            End If


        Catch ex As Exception

            Return
        End Try



        Dim lUser As User
        lUser = CType(Session.Item("User"), User)
        Dim lState As String

        'Dim lDs As New DataSet

        'lDs = FacilityMethods.GetAllRecords(Me.txtFacilityId.Text)


        ' If (lDs.Tables(0).Rows.Count > 0) Then
        With lHCFADBUpdated
            txtFacilityName.Text = .ServiceFacility.FacilityName
            txtNPI.Text = .ServiceFacility.NPI
            txtAddressLine1.Text = .ServiceFacility.AddressLine1
            txtAddressLine2.Text = .ServiceFacility.AddressLine2
            txtCity.Text = .ServiceFacility.City
            txtFacilityCode.Text = .ServiceFacility.FacilityCode

            mtbHomePhone.Text = .ServiceFacility.Phone
            mtbFax.Text = .ServiceFacility.Fax
            lState = .ServiceFacility.State

            ''for drop down loading and selection.......
            If (lState <> "") Then
                StateMethods.Load_States(cmbState, lUser)
                cmbState.SelectedIndex = cmbState.FindItemIndexByText(.ServiceFacility.State)
            End If

            mtbZipCode.Text = .ServiceFacility.ZipCode
        End With
        'End If



    End Sub



    Protected Sub cmbState_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbState.ItemsRequested
        Dim lUser As User
        lUser = CType(Session.Item("User"), User)

        Dim lCond As String
        lCond = "And Abbr Like '" & Utility.AdjustApostrophie(e.Text) & "%' "

        If (e.Text = "") Then
            Exit Sub
        End If

        StateMethods.Load_States(cmbState, lUser, lCond)
    End Sub

  

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim lHCFADBUpdated As HCFADBUpdated
        lHCFADBUpdated = CType(Session("HCFADBUpdated"), HCFADBUpdated)

        Try

            With lHCFADBUpdated.ServiceFacility
                .FacilityID = txtFacilityId.Text.ToString
                .FacilityName = Utility.AdjustApostrophie(txtFacilityName.Text)
                .NPI = Utility.AdjustApostrophie(txtNPI.Text)
                .AddressLine1 = Utility.AdjustApostrophie(txtAddressLine1.Text)
                .AddressLine2 = Utility.AdjustApostrophie(txtAddressLine2.Text)
                .City = Utility.AdjustApostrophie(txtCity.Text)
                .ZipCode = mtbZipCode.Text
                .Phone = mtbHomePhone.Text
                .Fax = mtbFax.Text
                .State = cmbState.Text
                .FacilityCode = txtFacilityCode.Text
            End With


            Session("HCFADBUpdated") = lHCFADBUpdated
            Response.Write("<script language=javascript>parent.questionwindow1.hide();</script>")
        Catch ex As Exception

        End Try





        ''if user hasnt selected a state.......
        If (cmbState.Text = "") Then
            cmbState.Items.Clear()
        End If
    End Sub
End Class
