
Partial Class ClaimSearchForPayment
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim lUser As User
        Dim lIsAuthorize As Boolean
        Dim lUserRoles As UserRoles



        If Not Page.IsPostBack Then


            lUser = CType(Session.Item("User"), User)
            lUserRoles = New UserRoles(lUser.ConnectionString)


            '********* Check User Validity ************
            'lIsAuthorize = lUserRoles.CheckPageAuthorization(lUser.UserId, "")
            'If Not lIsAuthorize Then
            '    Response.Redirect("unauthorization.aspx")
            'End If
            rdpFromDate.SelectedDate = Date.Now.AddYears(-1)
            rdpToDate.SelectedDate = Date.Now

        End If

    End Sub


    Protected Sub grdClaim_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdClaim.NeedDataSource
        Dim lUser As User
        Dim lCondition As String = ""

        'If IsPostBack Then
        CreateCondition(lCondition)

        lUser = CType(Session.Item("User"), User)
        ClaimMethods.LoadClaimGridNew(grdClaim, lCondition, lUser)
        'End If
    End Sub

    Private Sub CreateCondition(ByRef pCondition As String)        
        If Not txtHCFAID.Text.Equals("") Then
            pCondition &= " And H.HCFAID = " & txtHCFAID.Text
        End If

        pCondition &= " And S.DateOfService between '" & rdpFromDate.SelectedDate.GetValueOrDefault & "' and '" & rdpToDate.SelectedDate.GetValueOrDefault & "'"
    End Sub

    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSearch.Click       
        grdClaim.Visible = True
        grdClaim.Rebind()
    End Sub

    Protected Sub grdClaim_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdClaim.SelectedIndexChanged
        Dim lString As String

        
        lString = grdClaim.SelectedItems.Item(0).Cells(3).Text & "|" & grdClaim.SelectedItems.Item(0).Cells(4).Text
        InjectScript.Text = "<script>CloseOnReload('" & lString & "')</Script>"

        

    End Sub

    Protected Sub btnClose_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnClose.Click
        InjectScript.Text = "<script>CloseOnly()</Script>"
    End Sub

End Class
