
Partial Class Billing_FacilitySearchWindow
    Inherits System.Web.UI.Page

    Protected Sub grdFacility_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdFacility.NeedDataSource

        Dim dtb As New DataTable
        Dim lds As New DataSet
        
        If (Page.IsPostBack) Then
            If (cmbFacility.Text = "") Then
                grdFacility.DataSource = FacilityMethods.GetAllRecordsforSearchWindow(0)


                'grdFacility.DataBind()
            Else
                grdFacility.DataSource = FacilityMethods.GetAllRecordsforSearchWindow(cmbFacility.Value)                
            End If
        End If

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        grdFacility.Rebind()
    End Sub

    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSearch.Click
        pnlGrid.Visible = True
        grdFacility.Rebind()
    End Sub

    Protected Sub cmbFacility_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbFacility.ItemsRequested
        Dim lCond As String
        lCond = "And FacilityName Like '" & Utility.AdjustApostrophie(e.Text) & "%' "

        If (e.Text = "") Then
            Exit Sub
        End If

        FacilityMethods.LoadFacilityNameCombo(cmbFacility, lCond)
    End Sub

    Protected Sub btnClose_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnClose.Click
        InjectScript.Text = "<script>CloseOnly()</Script>"
    End Sub

    Protected Sub grdFacility_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdFacility.SelectedIndexChanged

        Dim lString As String = ""
        Dim lFacilityId As Integer
        Dim lFacilityName As String
        Dim lAddress As String
        Dim lCity As String
        Dim lState As String
        Dim lZip As String
        Dim lPhone As String
        Dim lNPI As String
        Dim lFacilityCode As String

        lFacilityId = grdFacility.SelectedItems.Item(0).Cells(2).Text
        lFacilityName = grdFacility.SelectedItems.Item(0).Cells(3).Text
        lAddress = grdFacility.SelectedItems.Item(0).Cells(5).Text
        lCity = grdFacility.SelectedItems.Item(0).Cells(6).Text
        lState = grdFacility.SelectedItems.Item(0).Cells(7).Text
        lZip = grdFacility.SelectedItems.Item(0).Cells(8).Text
        lPhone = grdFacility.SelectedItems.Item(0).Cells(9).Text
        lNPI = grdFacility.SelectedItems.Item(0).Cells(10).Text
        lFacilityCode = grdFacility.SelectedItems.Item(0).Cells(11).Text

        lString = lFacilityId & "|" & _
        lFacilityName & "|" & lAddress & "|" & lCity & "|" & lState & "|" & lZip & "|" & lPhone & "|" & lNPI & "|" & lFacilityCode

        lString = lString.Replace("&nbsp;", "")
        InjectScript.Text = "<script>CloseOnReload('" & lString & "')</script>"
    End Sub
End Class
