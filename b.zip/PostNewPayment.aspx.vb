
Partial Class Billing_PostNewPayment
    Inherits System.Web.UI.Page

   
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Me.IsPostBack Then

            Dim lPaymentMethod As New PaymentMethods()
            cmbPatient.Visible = False
            cmbInsuranceCompany.Visible = True
            rfvCompany.Visible = True
            '  Me.cmbInsuranceCompany.DataSource = PaymentMethods.GetPayerName("Insurance")
            Me.cmbInsuranceCompany.DataTextField = "CompanyName"
            Me.cmbInsuranceCompany.DataValueField = "PayerID"
            ' Me.cmbInsuranceCompany.DataBind()
            Me.dpPaymentDate.SelectedDate = Date.Now.Date
        End If

        Me.btnCancel.OnClientClick = "javascript:window.history.go(-1);return false;"

    End Sub

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSave.Click
        rfvCompany.Visible = False
        rfvPatient.Visible = False
        Dim lpaymentid As Integer = 0
        Dim lquerystring As String = String.Empty

        Try
            lpaymentid = Save()
            ViewState("PaymentID") = lpaymentid
            If lpaymentid <> 0 Then
               
                Page.RegisterStartupScript("testscript", "<script language='javascript'>abc();</script>")

            Else
                Page.RegisterStartupScript("testscript", "<script language='javascript'>alert('Error Occur While Saving');</script>")
            End If

            



        Catch ex As Exception

        End Try

    End Sub

    Public Function Save() As Integer
        Try


            Dim lUser As User = CType(HttpContext.Current.Session("User"), User)
            Dim lpaymentid As Integer = 0

            Dim lPaymentHdrDB As New PaymentHdrDB()
            Dim lPaymentHdr As New PaymentHdr(lUser.ConnectionString)
            If CType(lPaymentHdr.GetLastEnteredDate(), Date).Month <> Date.Now.Month Then
                lPaymentHdrDB.DisplayID = "1"
            Else
                Dim lint As Integer = PaymentHdr.GetMaxDispID(lUser.ConnectionString)
                'lPaymentHdrDB.DisplayID = lint + 1
                lPaymentHdrDB.DisplayID = lint
            End If

            If cmbPaymentMode.Text.ToUpper = "CHECK" Then
                lPaymentHdrDB.CheckDate = Me.dpPaymentDate.SelectedDate.GetValueOrDefault
            End If

            lPaymentHdrDB.PaymentDate = Me.dpPaymentDate.SelectedDate.GetValueOrDefault
            lPaymentHdrDB.PayerType = Left(Me.cmbPayerType.SelectedValue, 1)
            If lPaymentHdrDB.PayerType = "I" Then
                lPaymentHdrDB.PayerName = Me.cmbInsuranceCompany.Text
                lPaymentHdrDB.PayerID = cmbInsuranceCompany.Value
            Else
                lPaymentHdrDB.PayerName = cmbPatient.Text
                lPaymentHdrDB.PayerID = cmbPatient.Value
            End If

            lPaymentHdrDB.PaymentMode = Me.cmbPaymentMode.SelectedItem.Text
            lPaymentHdrDB.UserID = lUser.UserId
            lPaymentHdrDB.Description = Me.txtDescription.Text
            lPaymentHdrDB.CheckNumber = Me.txtCheckNumber.Text
            lPaymentHdrDB.Amount = Me.txtAmount.Text
            lPaymentHdrDB.PaymentDispDate = Date.Now
            lPaymentHdrDB.EntryDate = Date.Now
            lPaymentHdr.PaymentHdr = lPaymentHdrDB
            lpaymentid = lPaymentHdr.InsertRecordPayHdrNew()
            Return lpaymentid
        Catch ex As Exception
            Return False
        End Try
    End Function

    Protected Sub btnSaveNApply_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSaveNApply.Click
        rfvCompany.Visible = False
        rfvPatient.Visible = False
        Dim lpaymentid As Integer = 0
        Dim lquerystring As String = String.Empty
        Try
            lpaymentid = Save()

            lquerystring = "ApplyPayment.aspx" + Encryption.EncryptQueryString("PaymentID=" & lpaymentid)

            If lpaymentid <> 0 Then
                Page.RegisterStartupScript("testscript", "<script language='javascript'>alert('Saved Successfully');window.location='" & lquerystring & "';</script>")
            Else
                Page.RegisterStartupScript("testscript", "<script language='javascript'>alert('Error Occur While Saving');</script>")
            End If

        Catch ex As Exception

        End Try




    End Sub

    Protected Sub cmbPayerType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbPayerType.SelectedIndexChanged
        If cmbPayerType.SelectedItem.Text = "Insurance" Then
            cmbPatient.Visible = False
            cmbInsuranceCompany.Visible = True
            rfvCompany.Visible = True
            rfvPatient.Visible = False

            '  Me.cmbInsuranceCompany.DataSource = PaymentMethods.GetPayerName("Insurance")
            Me.cmbInsuranceCompany.DataTextField = "CompanyName"
            Me.cmbInsuranceCompany.DataValueField = "PayerID"
            '  Me.cmbInsuranceCompany.DataBind()
        Else
            cmbPatient.Visible = True
            cmbInsuranceCompany.Visible = False
            rfvCompany.Visible = False
            rfvPatient.Visible = True

            'Me.cmbPatient.DataSource = PaymentMethods.GetPayerName("Patient")
            Me.cmbPatient.DataTextField = "CompanyName"
            Me.cmbPatient.DataValueField = "PatientID"
            '  Me.cmbPatient.DataBind()
        End If
    End Sub


    'Protected Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnCancel.Click
    '    Response.Redirect("PaymentSearch.aspx")
    'End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click

        Dim lquerystring As String = String.Empty
        Try
            lquerystring = "ApplyPayment.aspx" + Encryption.EncryptQueryString("PaymentID=" & ViewState("PaymentID"))

            'Response.Redirect(lquerystring)

            Response.Write("<script language='javascript'>history.go(-(history.length));window.location='" & lquerystring & "';</script>")


        Catch ex As Exception

        End Try


    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim lquerystring As String = String.Empty
        'dpCheckDate.SelectedDate = Nothing
        txtAmount.Text = ""
        txtDescription.Text = ""
        cmbInsuranceCompany.Text = ""
        txtCheckNumber.Text = ""
    End Sub

   
    Protected Sub dpCheckDate_SelectedDateChanged(ByVal sender As Object, ByVal e As Telerik.WebControls.SelectedDateChangedEventArgs) Handles dpCheckDate.SelectedDateChanged

    End Sub

   
End Class
