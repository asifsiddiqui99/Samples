Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports System.Data
Imports ElixirLibrary
Imports System.Data.SqlClient
Partial Class Billing_VisitSummarySearchReport
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            Dim queryString As NameValueCollection
            Dim myReportDocument As ReportDocument
            Dim lUser As User = CType(HttpContext.Current.Session("User"), User)
            Dim lDs As New DataSet
            Dim lDs2 As New DataSet
            Dim lClinic As New Clinic(lUser.ConnectionString)
            Dim lParameters() As String

            Dim lParameterFields As New ParameterFields()
            Dim lParameterField As New ParameterField()
            Dim lParameterValue As New ParameterDiscreteValue()

            Dim lPatientId As String = ""
            Dim lFromDate As String = ""
            Dim lToDate As String = ""
            Dim lFavInsuranceID As String = ""
            Dim lProviderID As String = ""
            Dim lVisitStatus As String = ""


            Dim lDataCol As DataColumn
            RemoveReportDoc()

            If Session("ReportDocument") Is Nothing Then
                myReportDocument = New ReportDocument()
            Else
                myReportDocument = CType(Session("ReportDocument"), ReportDocument)
            End If

            If (Request.QueryString Is Nothing) Then
                Exit Sub
            ElseIf (Page.IsPostBack = False) Then
                queryString = Encryption.DecryptQueryString(Request.QueryString.ToString())
                lParameters = queryString.GetValues("value")
                If (lParameters IsNot Nothing AndAlso lParameters.Length > 0) Then
                    If (lParameters(0).Contains("|") AndAlso lParameters(0).Split("|").Length = 6) Then
                        lPatientId = lParameters(0).Split("|")(0)
                        lFromDate = Convert.ToDateTime(lParameters(0).Split("|")(1)).Date.ToShortDateString
                        lToDate = Convert.ToDateTime(lParameters(0).Split("|")(2)).Date.ToShortDateString
                        lFavInsuranceID = lParameters(0).Split("|")(3)
                        lProviderID = lParameters(0).Split("|")(4)
                        lVisitStatus = lParameters(0).Split("|")(5)

                        txtPatientId.Text = lPatientId
                        txtFromDate.Text = lFromDate
                        txtToDate.Text = lToDate
                        txtFavInsuranceID.Text = lFavInsuranceID
                        txtProviderID.Text = lProviderID
                        txtVisitStatus.Text = lVisitStatus

                    End If
                End If
            End If

            lDs = PatientSuperBillMethods.LoadVisitSummarySearch(txtFromDate.Text, txtToDate.Text, txtPatientId.Text, txtFavInsuranceID.Text, txtProviderID.Text, txtVisitStatus.Text)
            lDs2 = lClinic.GetClinicInfoForReports(lUser.ClinicId)

            CrystalReportViewer1.DisplayGroupTree = False
            CrystalReportViewer1.HasCrystalLogo = False
            CrystalReportViewer1.HasViewList = True
            CrystalReportViewer1.Zoom(100)
            CrystalReportViewer1.BestFitPage = False
            CrystalReportViewer1.Width = New Unit("100%")
            CrystalReportViewer1.Height = New Unit("1500")
            myReportDocument.Load(Server.MapPath("Reports\VisitSummarySearch.rpt"))

            If (lDs.Tables.Count > 0 AndAlso lDs.Tables(0).Rows.Count > 0) Then
                lDs.Tables(0).TableName = "VisitSummarySearch"
                myReportDocument.SetDataSource(lDs.Tables(0))
            Else
                myReportDocument.SetDataSource(lDs)
            End If

            'myReportDocument.SetParameterValue("PProvider", lDs.Tables(0).Rows(0)("Provider"))
            'If lDs.Tables(0).Rows(0)("Balance") = 0 Then
            '    myReportDocument.SetParameterValue("PStatus", "Paid")
            'Else
            '    myReportDocument.SetParameterValue("PStatus", "Unpaid")
            'End If

            myReportDocument.SetParameterValue("DOSFrom", txtFromDate.Text)
            myReportDocument.SetParameterValue("DOSTo", txtToDate.Text)
            myReportDocument.SetParameterValue("PClinicName", lDs2.Tables(0).Rows(0)("ClinicName"))
            myReportDocument.SetParameterValue("PClinicAddress", lDs2.Tables(0).Rows(0)("ClinicAddressLine1") + " " + lDs2.Tables(0).Rows(0)("ClinicCity") + " " + lDs2.Tables(0).Rows(0)("ClinicState") + " " + lDs2.Tables(0).Rows(0)("ClinicZipCode"))
            CrystalReportViewer1.ParameterFieldInfo = lParameterFields

            Session.Add("ReportDocument", myReportDocument)
            CrystalReportViewer1.ReportSource = myReportDocument
            CrystalReportViewer1.DataBind()
            'CrystalReportViewer1.PrintMode = CrystalDecisions.Web.PrintMode.ActiveX






        Catch ex As Exception
            Response.Write("<script>alert('Error Generating Report, Contact your System administrator');</script>")
        End Try
    End Sub

    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload
        Try
            Dim myReportDocument As ReportDocument
            RemoveReportDoc()
            If Session("ReportDocument") IsNot Nothing Then
                myReportDocument = CType(Session("ReportDocument"), ReportDocument)
                myReportDocument.Close()
                myReportDocument.Dispose()
                Session.Remove("ReportDocument")
          

            End If
            CrystalReportViewer1.Dispose()
            CrystalReportViewer1 = Nothing
        Catch ex As Exception

        End Try
    End Sub

    Private Sub RemoveReportDoc()
        Dim myReportDocument As ReportDocument
        Try
            If Session("ReportDocument") IsNot Nothing Then
                myReportDocument = CType(Session("ReportDocument"), ReportDocument)
                myReportDocument.Close()
                myReportDocument.Dispose()
                Session.Remove("ReportDocument")
            End If
           
        Catch ex As Exception

        End Try
    End Sub
End Class
