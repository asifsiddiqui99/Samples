
Partial Class Billing_ReferringProviderSearchWindow
    Inherits System.Web.UI.Page

    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSearch.Click
        Try
            grdEmployee.Visible = True
            grdEmployee.Rebind()
        Catch ex As Exception
            'lErrorLog.HandleError(ex, pobjUser, pPageUrl)
        End Try
    End Sub


    Protected Sub grdEmployee_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdEmployee.NeedDataSource
        Try

            Dim whereClause As String = ""

            Dim lds As New DataSet

            Dim lLastName As String = cmbLastName.Text
            Dim lFirstName As String = cmbFirstName.Text
            Dim lCity As String = Utility.AdjustApostrophie(txtCity.Text)
            Dim lZip As String = mtbZipCode.Text
            Dim lState = cmbState.Text


            If lLastName = "" Then
                whereClause = whereClause
            Else
                whereClause = whereClause & " And RP.LastName = '" & cmbLastName.Text & "'"
            End If

            If lState = "" Then
                whereClause = whereClause
            Else
                whereClause = whereClause & " And RP.State = '" & cmbState.Text & "'"
            End If


            If lFirstName = "" Then
                whereClause = whereClause
            Else
                whereClause = whereClause & " And RP.FirstName = '" & cmbFirstName.Text & "'"
            End If


            If lCity <> "" Then
                whereClause = whereClause & " And RP.City = '" & Utility.AdjustApostrophie(txtCity.Text) & "' "
            End If

            If lZip <> "" Then
                whereClause = whereClause & " And RP.ZipCode = '" & mtbZipCode.Text & "' "
            End If

            whereClause = whereClause & " And RP.IsDelete='N' "

            lds = ReferringMethods.GetReferringProvider(whereClause)

            grdEmployee.Visible = True
            grdEmployee.DataSource = lds
            

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub cmbState_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbState.ItemsRequested
        Dim lUser As User
        lUser = CType(Session.Item("User"), User)

        Dim lCond As String
        lCond = "And Abbr Like '" & Utility.AdjustApostrophie(e.Text) & "%'"

        If (e.Text = "") Then
            Exit Sub
        End If

        StateMethods.Load_States(cmbState, lUser, lCond)

    End Sub

    Protected Sub cmbFirstName_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbFirstName.ItemsRequested
        Dim lds As New DataSet

        Dim lCond As String
        lCond = "And FirstName Like '" & Utility.AdjustApostrophie(e.Text) & "%' And IsDelete='N'"

        If (e.Text = "") Then
            Exit Sub
        End If

        lds = ReferringMethods.GetAllRecords(lCond)

        cmbFirstName.DataSource = lds
        cmbFirstName.DataTextField = "FirstName"

        cmbFirstName.DataBind()
    End Sub

    Protected Sub cmbLastName_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbLastName.ItemsRequested
        Dim lds As New DataSet

        Dim lCond As String
        lCond = "And LastName Like '" & Utility.AdjustApostrophie(e.Text) & "%' And IsDelete='N'"

        If (e.Text = "") Then
            Exit Sub
        End If

        lds = ReferringMethods.GetAllRecords(lCond)
        cmbLastName.DataSource = lds
        cmbLastName.DataTextField = "LastName"

        cmbLastName.DataBind()

    End Sub

    Protected Sub grdEmployee_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdEmployee.SelectedIndexChanged
        Dim lString As String
        Dim lProviderId As Integer
        Dim lProviderName As String
        Dim lCity As String        
        Dim lState As String
        Dim lPhone As String
        Dim lNPI As String
        Dim lDegree As String = ""

        lProviderId = grdEmployee.SelectedItems.Item(0).Cells(2).Text
        lProviderName = grdEmployee.SelectedItems.Item(0).Cells(3).Text.Replace("  ", " ")
        lCity = grdEmployee.SelectedItems.Item(0).Cells(5).Text
        lState = grdEmployee.SelectedItems.Item(0).Cells(6).Text
        lPhone = grdEmployee.SelectedItems.Item(0).Cells(7).Text
        lNPI = grdEmployee.SelectedItems.Item(0).Cells(8).Text

        'Added For HCFAUpdated *******

        Dim lHCFADBUpdated As HCFADBUpdated
        Dim lRefPvd = New ReferringProviderDB
        lHCFADBUpdated = CType(Session("HCFADBUpdated"), HCFADBUpdated)

        Dim lDataset As DataSet
        Try

       
            lDataset = ReferringMethods.GetReferringProvider("And ProviderID=" & lProviderId)
            If lDataset.Tables(0).Rows.Count > 0 Then
                With lRefPvd
                    .AddressLine1 = lDataset.Tables(0).Rows(0).Item("AddressLine1")
                    .AddressLine2 = lDataset.Tables(0).Rows(0).Item("AddressLine2")
                    .City = lDataset.Tables(0).Rows(0).Item("City")
                    .Degree = lDataset.Tables(0).Rows(0).Item("Degree")
                    'Argument required to be displayed in HCFA block 17
                    lDegree = lDataset.Tables(0).Rows(0).Item("Degree")
                    .Email = lDataset.Tables(0).Rows(0).Item("Email")
                    .Ext = lDataset.Tables(0).Rows(0).Item("Ext")
                    .Facility = lDataset.Tables(0).Rows(0).Item("FacilityId")
                    .Fax = lDataset.Tables(0).Rows(0).Item("Fax")
                    .FirstName = lDataset.Tables(0).Rows(0).Item("FirstName")
                    .LastName = lDataset.Tables(0).Rows(0).Item("LastName")
                    .MiddleName = lDataset.Tables(0).Rows(0).Item("MiddleName")
                    .NPI = lDataset.Tables(0).Rows(0).Item("NPI")
                    .Speciality = lDataset.Tables(0).Rows(0).Item("Speciality")
                    .State = lDataset.Tables(0).Rows(0).Item("State")
                    .Title = IIf(IsDBNull(lDataset.Tables(0).Rows(0).Item("Title")), " ", lDataset.Tables(0).Rows(0).Item("Title"))
                    .WorkPhone = lDataset.Tables(0).Rows(0).Item("WorkPhone")
                    .ZipCode = lDataset.Tables(0).Rows(0).Item("ZipCode")
                End With


                lHCFADBUpdated.ReferencePvd = lRefPvd
                lHCFADBUpdated.ReferencePvd.ProviderID = lProviderId
                Session("HCFADBUpdated") = lHCFADBUpdated

            End If

        Catch ex As Exception

        End Try
        '**********

        lString = lProviderId & "|" & lProviderName & " " & lDegree & "|" & _
        lCity & "|" & lState & "|" & lPhone & "|" & lNPI
        InjectScript.Text = "<script>CloseOnReload('" & lString & "')</Script>"

    End Sub

    Protected Sub btnClose_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnClose.Click
        InjectScript.Text = "<script>CloseOnly()</Script>"
    End Sub

   
End Class
