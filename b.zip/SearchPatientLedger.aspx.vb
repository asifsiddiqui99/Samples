
Partial Class Billing_SearchPatientLedger
    Inherits System.Web.UI.Page

    Protected Sub btnViewPatientLedger_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnViewPatientLedger.Click
        Response.Write("<script>window.open('PatientLedger.aspx?" & Me.cmbPatient.Value & "|" & Me.dtFrom.SelectedDate.GetValueOrDefault & "|" & Me.dtTo.SelectedDate.GetValueOrDefault & "','123')</script>")

    End Sub

    Protected Sub cmbPatientName_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbPatient.ItemsRequested

        Dim lUser As User
        lUser = CType(Session.Item("User"), User)

        Dim lCond As String
        lCond = ""

        cmbPatient.DataSource = PatientMethods.LoadPatients("", lUser)
        cmbPatient.DataBind()

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
       ''to get the date of one month befor.........in vbscript......
       If (Not Page.IsPostBack) Then
       dtFrom.SelectedDate = DateSerial(Year(Now), Month(Now) - 1, Day(Now))
       dtTo.SelectedDate = Now.Date
       End If

    End Sub
End Class
