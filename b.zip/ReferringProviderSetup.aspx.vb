Imports System.Data
Imports Telerik.WebControls

Partial Class Billing_RefeRringProviderSetup
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If (Not Page.IsPostBack) Then
            cmbLastName.Focus()
            tsEmployee.SelectedIndex = 0
            mpEmployee.SelectedIndex = 0
        End If
    End Sub

    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSearch.Click
        Try
            grdEmployee.Rebind()
        Catch ex As Exception
            'lErrorLog.HandleError(ex, pobjUser, pPageUrl)
        End Try
    End Sub

    Protected Sub grdEmployee_DeleteCommand(ByVal source As Object, ByVal e As Telerik.WebControls.GridCommandEventArgs) Handles grdEmployee.DeleteCommand

        Dim lReferringProvider As New ReferringProviderDB
        Dim lResult As Boolean

        With lReferringProvider
            .ProviderID = CType(e.Item.Cells(2).Text, Integer)
        End With

        lResult = ReferringMethods.DeleteReferringProvider(lReferringProvider)        
    End Sub

    Protected Sub grdEmployee_ItemDataBound(ByVal sender As Object, ByVal e As Telerik.WebControls.GridItemEventArgs) Handles grdEmployee.ItemDataBound
        If (e.Item.ItemType = GridItemType.Item Or e.Item.ItemType = GridItemType.AlternatingItem) Then
            Dim lDataItem As GridDataItem = CType(e.Item, GridDataItem)
            Dim lHyplnk As HyperLink = CType(lDataItem("EmployeeName").Controls(0), HyperLink)
            Dim lID As String = lDataItem("column").Text

            If (e.Item.Cells(6).Text <> "" And (e.Item.Cells(6).Text.Length = 9)) Then


                e.Item.Cells(6).Text = String.Format("{0:#####-####}", Double.Parse(e.Item.Cells(6).Text))
            End If

            lHyplnk.NavigateUrl = "EditReferringProvider.aspx" + ElixirLibrary.Encryption.EncryptQueryString("eid=" & lID)

        End If
    End Sub

    Protected Sub grdEmployee_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdEmployee.NeedDataSource

        Try

            Dim whereClause As String = ""

            Dim lds As New DataSet

            Dim lLastName As String = Utility.AdjustApostrophie(cmbLastName.Text)
            Dim lFirstName As String = Utility.AdjustApostrophie(cmbFirstName.Text)
            Dim lCity As String = Utility.AdjustApostrophie(txtCity.Text)
            Dim lZip As String = mtbZipCode.Text
            Dim lState = Utility.AdjustApostrophie(cmbState.Text)


            If lLastName = "" Then
                whereClause = whereClause
            Else
                whereClause = whereClause & " And RP.LastName = '" & Utility.AdjustApostrophie(cmbLastName.Text) & "'"
            End If

            If lState = "" Then
                whereClause = whereClause
            Else
                whereClause = whereClause & " And RP.State = '" & Utility.AdjustApostrophie(cmbState.Text) & "'"
            End If


            If lFirstName = "" Then
                whereClause = whereClause
            Else
                whereClause = whereClause & " And RP.FirstName = '" & Utility.AdjustApostrophie(cmbFirstName.Text) & "'"
            End If


            If lCity <> "" Then
                whereClause = whereClause & " And RP.City Like '" & Utility.AdjustApostrophie(txtCity.Text) & "%' "
            End If

            If lZip <> "" Then
                whereClause = whereClause & " And RP.ZipCode Like '" & mtbZipCode.Text & "%' "
            End If

            whereClause = whereClause & " And RP.IsDelete='N' "

            lds = ReferringMethods.GetReferringProvider(whereClause)

            pnlGrid.Visible = True

            grdEmployee.DataSource = lds.Tables(0)


        Catch ex As Exception

        End Try
    End Sub

    Protected Sub ImgAddEmployee_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImgAddEmployee.Click
        Response.Redirect("AddReferringProvider.aspx")
    End Sub

        Protected Sub cmbState_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbState.ItemsRequested
        Dim lUser As User
        lUser = CType(Session.Item("User"), User)

        Dim lCond As String
        lCond = "And Abbr Like '" & Utility.AdjustApostrophie(e.Text) & "%'"

        If (e.Text = "") Then
            Exit Sub
        End If

        StateMethods.Load_States(cmbState, lUser, lCond)

    End Sub

    Protected Sub cmbFirstName_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbFirstName.ItemsRequested
        Dim lds As New DataSet

        Dim lCond As String
        lCond = "And FirstName Like '" & Utility.AdjustApostrophie(e.Text) & "%' And IsDelete='N'"

        If (e.Text = "") Then
            Exit Sub
        End If

        lds = ReferringMethods.GetAllRecords(lCond)

        cmbFirstName.DataSource = lds
        cmbFirstName.DataTextField = "FirstName"

        cmbFirstName.DataBind()
    End Sub

    Protected Sub cmbLastName_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbLastName.ItemsRequested
        Dim lds As New DataSet

        Dim lCond As String
        lCond = "And LastName Like '" & Utility.AdjustApostrophie(e.Text) & "%' And IsDelete='N'"

        If (e.Text = "") Then
            Exit Sub
        End If

        lds = ReferringMethods.GetAllRecords(lCond)
        cmbLastName.DataSource = lds
        cmbLastName.DataTextField = "LastName"

        cmbLastName.DataBind()

    End Sub

End Class
