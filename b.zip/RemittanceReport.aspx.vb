Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Partial Class Billing_RemittanceReport
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim Rid As String = ""
        Dim lStrFormat As String = ""
        'Dim queryString As NameValueCollection
        Dim queryString As String
        Dim lUser As User
        Dim lClinic As Clinic
        Dim lDs As New DataSet
        Dim lDs2 As New DataSet
        Dim lParameterFields As New ParameterFields()
        Dim lParameterField As New ParameterField()
        Dim lParameterValue As New ParameterDiscreteValue()
        Dim clinicTbl As New DataTable("ClinicInfo")
        Dim myReportDocument As ReportDocument
        Dim lRemittanceMethod As New RemittanceMethods

        Try
            If Session("ReportDocument") Is Nothing Then
                myReportDocument = New ReportDocument()
            Else
                myReportDocument = CType(Session("ReportDocument"), ReportDocument)
            End If

            lUser = CType(HttpContext.Current.Session("User"), User)
            lClinic = New Clinic(lUser.ConnectionString)
            'queryString = Encryption.DecryptQueryString(Request.QueryString.ToString())
            queryString = Request.QueryString("rid")
            If (queryString IsNot Nothing AndAlso queryString <> "") Then

                Rid = queryString.Split("|")(0)
                lStrFormat = queryString.Split("|")(1)

                If (Rid <> "" AndAlso lStrFormat <> "") Then
                    lDs = lRemittanceMethod.LoadReport(Rid)
                    If (lStrFormat = "S") Then
                        myReportDocument.Load(Server.MapPath("Reports/StandardRemittanceReport.rpt"))
                    ElseIf (lStrFormat = "M") Then
                        myReportDocument.Load(Server.MapPath("Reports/MedicareRemittanceReport.rpt"))
                    End If
                    lDs2 = lClinic.GetClinicInfoForReports(lUser.ClinicId)
                    lDs2.Tables(0).TableName = "ClinicInfo"
                    clinicTbl = New DataTable("ClinicInfo")
                    clinicTbl = lDs2.Tables(0).Copy()
                    lDs.Tables.Add(clinicTbl)
                    lDs.Tables(0).TableName = "RemittanceReport"
                    lDs.Tables(1).TableName = "ClinicInfo"
                    'myReportDocument.SetDataSource(lDs.Tables(0))
                    'lParameterValue.Value = lDs2.Tables(0).Rows(0)("ClinicName")


                    myReportDocument.SetDataSource(lDs)
                    myReportDocument.SetParameterValue("PClinicName", lDs2.Tables(0).Rows(0)("ClinicName"))

                    myReportDocument.SetParameterValue("PClinicAddress", lDs2.Tables(0).Rows(0)("ClinicAddressLine1") + " " + lDs2.Tables(0).Rows(0)("ClinicCity") + " " + lDs2.Tables(0).Rows(0)("ClinicState") + " " + lDs2.Tables(0).Rows(0)("ClinicZipCode"))


                    'lParameterValue.Value = CType("04/09/2008", Date)
                    'lParameterField.Name = "PClinicNamez"
                    'lParameterField.CurrentValues.Add(lParameterValue)
                    'lParameterFields.Add(lParameterField)
                    'lParameterField = New ParameterField()
                    'lParameterValue = New ParameterDiscreteValue()
                    'lParameterValue.Value = lDs2.Tables(0).Rows(0)("ClinicAddressLine1") + "," + lDs2.Tables(0).Rows(0)("ClinicCity") + "," + lDs2.Tables(0).Rows(0)("ClinicState") + "," + lDs2.Tables(0).Rows(0)("ClinicZipCode").ToString
                    'If lDs2.Tables(0).Rows(0)("ClinicZipCode").ToString.Length > 5 Then
                    '    lParameterValue.Value = lParameterValue.Value + "," + lDs2.Tables(0).Rows(0)("ClinicZipCode").ToString.Substring(0, 5) + "-" + lDs2.Tables(0).Rows(0)("ClinicZipCode").ToString.Substring(5, 4)
                    'End If
                    'lParameterValue.Value = CType("04/09/2008", Date)
                    'lParameterField.Name = "PClinicAddress"
                    'lParameterField.CurrentValues.Add(lParameterValue)
                    'lParameterFields.Add(lParameterField)
                    'CrystalReportViewer1.ParameterFieldInfo = lParameterFields


                    Session.Add("ReportDocument", myReportDocument)
                    CrystalReportViewer1.ReportSource = myReportDocument
                    CrystalReportViewer1.HasCrystalLogo = False
                    CrystalReportViewer1.BestFitPage = False
                    CrystalReportViewer1.HasViewList = False
                    CrystalReportViewer1.DisplayGroupTree = False
                    CrystalReportViewer1.Zoom(100)
                    CrystalReportViewer1.Width = New Unit("100%")
                    CrystalReportViewer1.Height = New Unit("1500")
                    CrystalReportViewer1.HasSearchButton = False
                    CrystalReportViewer1.EnableDrillDown = False
                    'CrystalReportViewer1.PrintMode = CrystalDecisions.Web.PrintMode.ActiveX
                    CrystalReportViewer1.DataBind()
                End If

            End If
        Catch ex As Exception
            lblErrorMsg.Text = ex.Message
            lblErrorMsg.Visible = True
        End Try
    End Sub

    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload
        Dim myReportDocument As ReportDocument

        If Session("ReportDocument") IsNot Nothing Then
            myReportDocument = CType(Session("ReportDocument"), ReportDocument)
            myReportDocument.Close()
            myReportDocument.Dispose()
            Session.Remove("ReportDocument")
           
        End If
        CrystalReportViewer1.Dispose()
        CrystalReportViewer1 = Nothing
    End Sub
End Class
