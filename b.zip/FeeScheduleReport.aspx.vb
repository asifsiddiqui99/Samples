Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports System.Data
Imports System.Data.SqlClient


Partial Class Billing_FeeScheduleReport
    Inherits System.Web.UI.Page



    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            BindReport()
        End If
    End Sub


    Protected Sub btnSearchPayer_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSearchPayer.Click
        Try

            BindReport()

        Catch ex As Exception

        End Try
    End Sub

    Private Sub BindReport()


        Dim lDs As New DataSet()
        Dim lReportDocument As ReportDocument
        Dim lUser As User = CType(HttpContext.Current.Session("User"), User)
        Dim lConnection As New Connection(lUser.ConnectionString)
        Dim lClinic As New Clinic(lUser.ConnectionString)
        Dim lClinicDS As DataSet = Nothing
        Dim lCondition As String = String.Empty

        Try


            RemoveReportDoc()

            If Session("ReportDocument") Is Nothing Then
                lReportDocument = New ReportDocument()
            Else
                lReportDocument = CType(Session("ReportDocument"), ReportDocument)
            End If

            lCondition = Me.CreateCondition(Utility.AdjustApostrophie(cmbPayer.Text), Utility.AdjustApostrophie(txtCPTCodeFrom.Text).Trim, Utility.AdjustApostrophie(txtCPTCodeTo.Text).Trim)
            If lCondition Is Nothing Then
                Exit Sub
            End If

            lDs = FeeScheduleReportMethods.GetFeeScheduleForReport(lCondition)


            If lDs.Tables(0).Rows.Count > 0 Then

                Me.pnlReportViewer.Style("display") = "block"

                lClinicDS = New DataSet
                lClinicDS = lClinic.GetClinicInfoForReports(lUser.ClinicId)


                lReportDocument.Load(Server.MapPath("Reports/FeeScheduleReport.rpt"))
                lReportDocument.SetDataSource(lDs)

                lReportDocument.SetParameterValue("PClinicName", lClinicDS.Tables(0).Rows(0)("ClinicName"))
                lReportDocument.SetParameterValue("pClinicAddress", lClinicDS.Tables(0).Rows(0)("ClinicAddressLine1") + " " + lClinicDS.Tables(0).Rows(0)("ClinicCity") + " " + lClinicDS.Tables(0).Rows(0)("ClinicState") + " " + lClinicDS.Tables(0).Rows(0)("ClinicZipCode"))


                Me.crvFeeScheduleReport.ReportSource = lReportDocument
                Me.crvFeeScheduleReport.DataBind()
                Session.Add("ReportDocument", lReportDocument)
                Me.crvFeeScheduleReport.Zoom(100)
                Me.crvFeeScheduleReport.BestFitPage = False
                Me.crvFeeScheduleReport.DisplayGroupTree = False
                Me.crvFeeScheduleReport.HasViewList = False
                Me.crvFeeScheduleReport.HasDrillUpButton = False
                Me.crvFeeScheduleReport.HasZoomFactorList = False
                Me.crvFeeScheduleReport.HasExportButton = False
                Me.crvFeeScheduleReport.HasSearchButton = False
                Me.crvFeeScheduleReport.HasPageNavigationButtons = True
                Me.crvFeeScheduleReport.HasToggleGroupTreeButton = False
                Me.crvFeeScheduleReport.HasCrystalLogo = False
                Me.crvFeeScheduleReport.HasDrillUpButton = False
                Me.crvFeeScheduleReport.HasGotoPageButton = False
                Me.crvFeeScheduleReport.EnableDrillDown = False
                Me.crvFeeScheduleReport.Width = New Unit("100%")
                Me.crvFeeScheduleReport.Height = New Unit("100%")
                Me.crvFeeScheduleReport.DataBind()
                'Me.crvFeeScheduleReport.PrintMode = CrystalDecisions.Web.PrintMode.ActiveX
                lblMessage.Text = ""


            Else
                lblMessage.Text = "No Records Found!"
                Me.pnlReportViewer.Style("display") = "none"
            End If





        Catch ex As Exception

        End Try
    End Sub



    Private Function CreateCondition(ByVal pInsuranceCompany As String, ByVal pCPTFrom As String, ByVal pCPTTo As String) As String


        Dim lCondition As String = String.Empty

        Try

            If Not pInsuranceCompany.Equals("") Then
                lCondition &= "And CompanyName Like '%" & pInsuranceCompany & "%' "
            End If


            If (pCPTFrom.Equals("") And Not pCPTTo.Equals("")) Or (Not pCPTFrom.Equals("") And pCPTTo.Equals("")) Then
                lblMessage.Text = "Please Enter the Correct Range"
                Return Nothing

            ElseIf (Not pCPTFrom.Equals("") And Not pCPTTo.Equals("")) Then
                lCondition &= "And CPTCode between '" & pCPTFrom & "' and '" & pCPTTo & "'"
            End If

            Return lCondition


        Catch ex As Exception
            Return Nothing
        End Try
    End Function


    Private Sub RemoveReportDoc()
        Dim myReportDocument As ReportDocument
        Try
            If Session("ReportDocument") IsNot Nothing Then
                myReportDocument = CType(Session("ReportDocument"), ReportDocument)
                myReportDocument.Close()
                myReportDocument.Dispose()
                Session.Remove("ReportDocument")

            End If
        Catch ex As Exception

        End Try
    End Sub


    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload

        Try
            Dim myReportDocument As ReportDocument
            RemoveReportDoc()
            If Session("ReportDocument") IsNot Nothing Then
                myReportDocument = CType(Session("ReportDocument"), ReportDocument)
                myReportDocument.Close()
                myReportDocument.Dispose()
                Session.Remove("ReportDocument")

            End If
            crvFeeScheduleReport.Dispose()
            crvFeeScheduleReport = Nothing
        Catch ex As Exception
        End Try
    End Sub
End Class
