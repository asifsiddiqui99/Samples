Imports System.Collections.Generic
Imports Telerik.WebControls
Imports BillingReportMethod
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared


Partial Class Billing_DailyRecap
    Inherits System.Web.UI.Page
    Dim lYearlist As New Collection

    

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If (Page.IsPostBack) Then
            LoadReport()
        End If

        If (Not Page.IsPostBack) Then
            CmbMonth.SelectedValue = Date.Now.AddMonths(-1).Month
            Try
                'Dim lYearCount As Int32 = 0
                'lYearlist.Add(Now.Date.AddYears(-10).Year)
                'For lYearCount = 1 To 50
                '    lYearlist.Add(lYearlist.Item(lYearCount) + 1)
                'Next
                'CmbYear.DataSource = lYearlist

                lYearlist.Add(2000)
                lYearlist.Add(2001)
                lYearlist.Add(2002)
                lYearlist.Add(2003)
                lYearlist.Add(2004)
                lYearlist.Add(2005)
                lYearlist.Add(2006)
                lYearlist.Add(2007)
                lYearlist.Add(2008)
                lYearlist.Add(2010)
                lYearlist.Add(2011)
                lYearlist.Add(2012)
                lYearlist.Add(2013)
                lYearlist.Add(2014)
                lYearlist.Add(2015)
                lYearlist.Add(2015)
                lYearlist.Add(2016)
                lYearlist.Add(2017)
                lYearlist.Add(2018)
                lYearlist.Add(2019)
                lYearlist.Add(2020)
                lYearlist.Add(2021)
                lYearlist.Add(2022)
                lYearlist.Add(2023)
                lYearlist.Add(2024)
                lYearlist.Add(2025)
                lYearlist.Add(2026)
                lYearlist.Add(2027)
                lYearlist.Add(2028)
                lYearlist.Add(2029)
                lYearlist.Add(2030)
                lYearlist.Add(2031)
                lYearlist.Add(2032)
                lYearlist.Add(2033)
                lYearlist.Add(2034)
                lYearlist.Add(2035)
                lYearlist.Add(2036)
                lYearlist.Add(2037)
                lYearlist.Add(2038)
                lYearlist.Add(2039)
                lYearlist.Add(2040)
                lYearlist.Add(2041)
                lYearlist.Add(2042)
                lYearlist.Add(2043)
                lYearlist.Add(2044)
                lYearlist.Add(2045)
                lYearlist.Add(2046)
                lYearlist.Add(2047)
                lYearlist.Add(2048)
                lYearlist.Add(2049)
                lYearlist.Add(2050)
            Catch ex As Exception
                Response.Write("<script>alert('Error Generating Report, Contact your System administrator');</script>")
            End Try
            CmbYear.DataSource = lYearlist
            CmbYear.SelectedValue = Date.Now.AddMonths(-1).Year
            CmbYear.DataBind()
        End If
    End Sub

    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click

        Try
            LoadReport()
        Catch ex As Exception
            Response.Write("<script>alert('Error Generating Report, Contact your System administrator');</script>")
        End Try

    End Sub

    Public Sub LoadReport()
        Dim lYear As Integer = CmbYear.SelectedIndex
        Dim lDate As DateTime
        Dim lDs As New DataSet()
        Dim myReportDocument As ReportDocument
        Dim lUser As User = CType(HttpContext.Current.Session("User"), User)
        Dim lConnection As New Connection(lUser.ConnectionString)
        Dim lClinic As New Clinic(lUser.ConnectionString)
        Dim clinicTbl As DataTable
        Dim lDs2 As New DataSet()

        Try
            RemoveReportDoc()
            If Session("ReportDocument") Is Nothing Then
                myReportDocument = New ReportDocument()
            Else
                myReportDocument = CType(Session("ReportDocument"), ReportDocument)
            End If

            lDate = CmbMonth.Value + " / 01 / " + CmbYear.Items(lYear).Text
            'lblDate.Text = Convert.ToDateTime(lblDate.Text)

            lDs2 = lClinic.GetClinicInfoForReports(lUser.ClinicId)
            lDs = GetDailyRecap(lDate)
            lDs2.Tables(0).TableName = "ClinicInfo"
            clinicTbl = New DataTable("ClinicInfo")
            clinicTbl = lDs2.Tables(0).Copy()
            lDs.Tables.Add(clinicTbl)
            lDs.Tables(1).TableName = "ClinicInfo"
            lDs.Tables(0).TableName = "DailyRecap"
            myReportDocument.Load(Server.MapPath("Reports/DailyRecapRpt.rpt"))
            If lDs.Tables(0).Rows.Count > 0 Then
                myReportDocument.SetDataSource(lDs)
                Me.crvDailyRecap.ReportSource = myReportDocument
                Session.Add("ReportDocument", myReportDocument)
                Me.crvDailyRecap.Zoom(100)
                Me.crvDailyRecap.BestFitPage = False
                Me.crvDailyRecap.DisplayGroupTree = False
                Me.crvDailyRecap.HasViewList = False
                Me.crvDailyRecap.HasDrillUpButton = False
                Me.crvDailyRecap.HasZoomFactorList = False
                Me.crvDailyRecap.HasExportButton = False
                Me.crvDailyRecap.HasSearchButton = False
                Me.crvDailyRecap.HasPageNavigationButtons = True
                Me.crvDailyRecap.HasToggleGroupTreeButton = False
                Me.crvDailyRecap.HasCrystalLogo = False
                Me.crvDailyRecap.HasDrillUpButton = False
                Me.crvDailyRecap.HasGotoPageButton = False
                Me.crvDailyRecap.EnableDrillDown = True
                Me.crvDailyRecap.Width = New Unit("100%")
                Me.crvDailyRecap.Height = New Unit("100%")
                Me.crvDailyRecap.DataBind()
                ' Me.crvDailyRecap.PrintMode = CrystalDecisions.Web.PrintMode.ActiveX

            End If

        Catch ex As Exception
            Response.Write("<script>alert('Error Generating Report, Contact your System administrator');</script>")
        End Try

    End Sub

    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload
        Try
            Dim myReportDocument As ReportDocument
            If Session("ReportDocument") IsNot Nothing Then
                myReportDocument = CType(Session("ReportDocument"), ReportDocument)
                myReportDocument.Close()
                myReportDocument.Dispose()
                Session.Remove("ReportDocument")
                
            End If
            crvDailyRecap.Dispose()
            crvDailyRecap = Nothing
        Catch ex As Exception
            Response.Write("<script>alert('Error Generating Report, Contact your System administrator');</script>")
            Return
        End Try
    End Sub
    Private Sub RemoveReportDoc()
        Dim myReportDocument As ReportDocument
        Try
            If Session("ReportDocument") IsNot Nothing Then
                myReportDocument = CType(Session("ReportDocument"), ReportDocument)
                myReportDocument.Close()
                myReportDocument.Dispose()
                Session.Remove("ReportDocument")
            End If
        Catch ex As Exception

        End Try
    End Sub
End Class
