
Imports System.Drawing
Imports CrystalDecisions.Web
Imports CrystalDecisions.CrystalReports
Imports Telerik.WebControls
Partial Class Billing_ClaimSearch
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        tsEmployee.SelectedIndex = 0
        mpEmployee.SelectedIndex = 0
        Dim lUser As User
        Dim queryString As NameValueCollection = Nothing
        Dim lPatientID As String
        Try
            lUser = CType(Session.Item("User"), User)
            Dim lInsurance As Insurance = New Insurance(lUser.ConnectionString)
            lInsurance.GetAllRecords("AND IsDelete= 'N'") 'FOR SOME REASON, THIS LINE HAS BEEN ADDED. HAVE TO MAKE SURE WHETHER THERES ANY NEED.
            Me.cmbPatient.Focus()
            If IsPostBack = False Then
                EmployeeMethods.LoadDoctorsCombo(rcbDoctors)
                rdpTo.SelectedDate = Date.Now
                rdpFrom.SelectedDate = Date.Now.AddMonths(-6)
                ''line add by talha..
                rcbDoctors.Items.Insert(0, New Telerik.WebControls.RadComboBoxItem(""))
                pnlGrid.Visible = True
                grdClaim.Visible = True
                If (Request.QueryString.Count > 0) Then
                    queryString = Encryption.DecryptQueryString(Request.QueryString.ToString())
                    If (queryString IsNot Nothing) Then
                        lPatientID = queryString("id").ToString
                        txtPatientID.Text = lPatientID
                        btnBackPS.Visible = True
                        Dim lPatient As New PatientDBExtended
                        lPatient = PatientMethods.LoadPatientsById(lPatientID, lUser)
                        cmbPatient.Text = lPatient.LastName & "," & lPatient.FirstName
                    End If
                End If
                grdClaim.Rebind()
            End If

            ' Start => Added by: Affan Toor | Date: 24-09-14 | Defect#: 2297 
            Dim lCondition As String = ""
            CreateCondition(lCondition)
            Session("Condition") = lCondition
            'Response.Redirect("../Billing/ClaimReport.aspx?Condition=" & lCondition)
            BtnPrinterFriendly.Attributes.Add("Onclick", "window.open('ClaimReport.aspx?Condition=" & ElixirLibrary.Encryption.EncryptQueryString(lCondition) & "','Edit','scrollbars=yes,resizable=no,width=1050,height=800'); return false;")
            ' End => Added by: Affan Toor | Date: 24-09-14 | Defect#: 2297 

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub grdClaim_DeleteCommand(ByVal source As Object, ByVal e As Telerik.WebControls.GridCommandEventArgs) Handles grdClaim.DeleteCommand
        Dim lPatientSuperBillId = e.Item.Cells(2).Text.ToString
        Dim lUser As User

        lUser = CType(Session.Item("User"), User)
        ClaimMethods.DeleteClaim(lUser, lPatientSuperBillId)

    End Sub

    Protected Sub grdClaim_ItemCommand(ByVal source As Object, ByVal e As Telerik.WebControls.GridCommandEventArgs) Handles grdClaim.ItemCommand

    End Sub

   
 
    Protected Sub grdClaim_ItemDataBound(ByVal sender As Object, ByVal e As Telerik.WebControls.GridItemEventArgs) Handles grdClaim.ItemDataBound

        Dim lDataItem As Telerik.WebControls.GridDataItem
        Dim lbtnNotes As ImageButton
        If (e.Item.ItemType = GridItemType.Item Or e.Item.ItemType = GridItemType.AlternatingItem) Then
            lDataItem = CType(e.Item, Telerik.WebControls.GridDataItem)
            Dim lCheckbox As CheckBox
            lCheckbox = CType(e.Item.FindControl("selectSelectCheckBox"), CheckBox)
            If (e.Item.Cells(14).Text = "Secondary") Then
                lCheckbox.Checked = True
                lCheckbox.Enabled = False
                lCheckbox.ToolTip = "Disabled because secondary claim cannot become part of batch."

            ElseIf (e.Item.Cells(3).Text.ToUpper = "N") Then
                e.Item.Enabled = True
                lCheckbox.Enabled = True



            Else
                lCheckbox.Checked = True
                lCheckbox.Enabled = False
                lCheckbox.ToolTip = "Disabled because already part of batch."



            End If

            'lbtnNotes = CType(e.Item.FindControl("btnNotes"), ImageButton)
            'lbtnNotes.Attributes.Add("onclick", "javascript:return clickOnceQuestion(this," & e.Item.Cells(5).Text & ")")

            Dim lComments As String = e.Item.Cells(25).Text


            lbtnNotes = CType(e.Item.FindControl("btnNotes"), ImageButton)
            lbtnNotes.Attributes.Add("onclick", "javascript:return clickOnceQuestion(this," & e.Item.Cells(5).Text & ");")


          
            If Not e.Item.Cells(25).Text.Trim.Replace("&nbsp;", "").Equals("") Then
                lbtnNotes.ImageUrl = "../images/commentYellow.gif"
            Else
                lbtnNotes.ImageUrl = "../images/commentBlue.gif"
            End If


            Dim lHyplnk As HyperLink = CType(lDataItem.Cells(12).Controls(0), HyperLink)
            If (lCheckbox.Enabled = True) Then
                lHyplnk.ForeColor = Drawing.Color.Red
            ElseIf (e.Item.Cells(14).Text = "Secondary" And lCheckbox.Enabled = False) Then

                lHyplnk.ForeColor = Drawing.Color.Red
            Else
                lHyplnk.ForeColor = Drawing.Color.Green
            End If

            lHyplnk.NavigateUrl = "HCFA.aspx" + ElixirLibrary.Encryption.EncryptQueryString("PSBID=" & e.Item.Cells(24).Text & "&ClaimCount=" & e.Item.Cells(22).Text)

            'mouse over add by kanwal jeet

            If (lComments.Trim <> "&nbsp;" And lComments.Trim <> "") Then
                If (e.Item.Cells(25).Text.Length > 125) Then
                    e.Item.Cells(25).Text = e.Item.Cells(25).Text.Substring(0, 125) & "...."
                End If
                'lCommentsImg.Attributes.Add("onmouseover", "javascript:Tip('" & e.Item.Cells(28).Text.Substring(e.Item.Cells(28).Text.ToString.LastIndexOf(":") + 1) & "');")
                'lCommentsImg.Attributes.Add("onmouseover", "javascript:Tip('123', DURATION,5000, OFFSETX, -50);")

                If (e.Item.Cells(25).Text.Contains(vbCrLf)) Then
                    lbtnNotes.Attributes.Add("onmouseover", "javascript:Tip('<table background=\'../Images/comments.gif\' width=\'199\' height=\'132\'  border=\'0\' cellspacing=\'0\' cellpadding=\'16\' style=\'color:#666666; background-repeat:no-repeat; margin-right:70px;\' ><tr><td valign=\'top\' style=\'padding-top:43px; padding-right:25px;\' >" & e.Item.Cells(25).Text.Replace(vbCrLf, "") & "<\/td><\/tr><\/table>', DURATION,5000, OFFSETX, -5)")
                Else
                    lbtnNotes.Attributes.Add("onmouseover", "javascript:Tip('<table background=\'../Images/comments.gif\' width=\'199\' height=\'132\'  border=\'0\' cellspacing=\'0\' cellpadding=\'16\' style=\'color:#666666; background-repeat:no-repeat; margin-right:70px;\' ><tr><td valign=\'top\' style=\'padding-top:43px; padding-right:25px;\' >" & e.Item.Cells(25).Text & "<\/td><\/tr><\/table>', DURATION,5000, OFFSETX, -5)")
                End If
            End If


        End If
     
    End Sub


    Protected Sub grdClaim_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdClaim.NeedDataSource
        Dim lUser As User
        Dim lCondition As String = ""

        'If IsPostBack Then
        CreateCondition(lCondition)

        lUser = CType(Session.Item("User"), User)
        ClaimMethods.LoadClaimGridNew(grdClaim, lCondition, lUser)
        'End If
    End Sub

    Private Sub CreateCondition(ByRef pCondition As String)
        ''line changed by talha....
        If Not rcbDoctors.Text = "" Then 'Means All the doctors
            pCondition = " And S.PrescriberID = " & rcbDoctors.SelectedValue
            ''''''''''''''''''''''''''''''''''''''''''''Change Log ''''''''''''''''''''''''''''''''''''''''''''''
            'Name : Faraz Ahmed
            'Reason: The condtion should be null for prescriber id
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            'Else
            'pCondition = " And PrescriberID= " & 0
        End If
        ''added by madiha
        Dim lPatientname As String = String.Empty
        Dim lvalue() As String
        Dim lLastName As String = String.Empty
        Dim lFirstName As String = String.Empty
        If cmbPatient.Text.Trim <> "" Then
            lPatientname = cmbPatient.Text
            If lPatientname.Contains(",") Then
                lvalue = lPatientname.Split(",")
                lLastName = lvalue(0)
                lFirstName = lvalue(1)
                txtPatient.Text = lLastName & ",%" & lFirstName

            Else
                lLastName = cmbPatient.Text
                txtPatient.Text = lLastName
            End If
        Else
            txtPatient.Text = ""
        End If
        ''

        If Not txtPatient.Text.Equals("") Then
            pCondition &= " And (H.PatientLastName + ', ' + H.PatientFirstName) like '%" & Utility.AdjustApostrophie(txtPatient.Text) & "%' "
        End If


        If dpPatientDob.DbSelectedDate IsNot Nothing AndAlso dpPatientDob.DbSelectedDate.ToString <> "" Then

            Dim lDate() As String = dpPatientDob.DbSelectedDate.ToString.Split(" ")
            If (lDate(0) <> "") Then
                pCondition = pCondition + " And H.PatientDOB between '" + Convert.ToDateTime(lDate(0)) + "'" & " and '" & Convert.ToDateTime(lDate(0)) & "'"
            End If
        End If
        If (cmbPayer.Text <> "") Then
            pCondition &= " and H.MainICCompanyName='" & Utility.AdjustApostrophie(cmbPayer.Text) & "' "
        End If


        If (rcbDate.SelectedValue = "C") Then
            pCondition &= " And Cast(Convert(varchar(10),HCFAPreparedDate,101) as datetime) between '" & rdpFrom.SelectedDate.GetValueOrDefault & "' and '" & rdpTo.SelectedDate.GetValueOrDefault & "'"
        ElseIf (rcbDate.SelectedValue = "S") Then
            pCondition &= " and H.Hcfaid in (SELECT distinct HCFAID from HCFAUpdated,patientSuperBill p where p.PatientSuperBillID=HCFAUpdated.PatientSuperBillID and (Cast(Convert(varchar(10),p.VisitDisplayDate,101) as datetime) between '" & rdpFrom.SelectedDate.GetValueOrDefault & "' and '" & rdpTo.SelectedDate.GetValueOrDefault & "')) "
        End If

        If Not txtClaimID.Text.Equals("") Then
            pCondition &= " And 'CL-' + Cast(Year(H.HCFAPreparedDate) as Varchar) + '-'+ case Len(Cast(Month(H.HCFAPreparedDate) as Varchar)) when 1 then '0'+ Cast(Month(H.HCFAPreparedDate) as Varchar) when 2 then Cast(Month(H.HCFAPreparedDate) as Varchar) End + '-'+ Right(REPLICATE('0', 5) + Cast(H.HCFADisplayID As Varchar),5) = '" & Utility.AdjustApostrophie(txtClaimID.Text) & "' "
        End If

        'If (txtPatientID.Text <> "") Then
        '    pCondition &= " and S.PatientId ='" & txtPatientID.Text & "' "
        'End If

    End Sub

    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSearch.Click
        'txtPatientID.Text = ""
        'btnBackPS.Visible = False
        pnlGrid.Visible = True
        grdClaim.Visible = True
        grdClaim.Rebind()
    End Sub

    Protected Sub btnCreateBatch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnCreateBatch.Click
        Dim lXmlDocument As New XmlDocument
        Dim lXmlElement As XmlElement
        Dim lCheckbox As CheckBox
        Dim lCheck As Boolean = False

        Dim lClaimIds As String = ""
        Try
            lXmlDocument.LoadXml("<ClaimBatchDtls></ClaimBatchDtls>")
            lXmlElement = lXmlDocument.CreateElement("ClaimBatchDtl")

            For Each lrow As GridDataItem In grdClaim.Items
                lCheckbox = CType(lrow.FindControl("selectSelectCheckBox"), CheckBox)
                If (lCheckbox.Checked = True AndAlso lCheckbox.Enabled = True) Then
                    'If (lrow.Selected = True AndAlso grdClaim.SelectedItems.Item(0).Cells(3).Text = "N") Then
                    With lXmlElement
                        .SetAttribute("BatchID", "BATCHID")
                        .SetAttribute("ClaimID", lrow.Cells(5).Text)
                        .SetAttribute("VisitID", lrow.Cells(6).Text)
                        .SetAttribute("Status", "N")
                        lClaimIds = lClaimIds & "," & lrow.Cells(5).Text
                    End With
                    lXmlDocument.DocumentElement.AppendChild(lXmlElement.CloneNode(True))
                End If
            Next
            If (ClaimBatchMethods.InsertClaimBatch(lXmlDocument.InnerXml.ToString, lClaimIds)) Then
                'Response.Write("<script>alert('Batch created successfully and sent to outbox.');</script>")

                Response.Write("<script language='javascript'> alert('Batch created successfully and sent to outbox.');history.go(-(history.length));window.location='ClaimSearch.aspx';</script>")



                lCheck = True
            End If
            For Each lrow As GridDataItem In grdClaim.Items
                lCheckbox = CType(lrow.FindControl("CheckBox1"), CheckBox)
                If (lCheckbox.Checked = True AndAlso lCheckbox.Enabled = True) Then
                    lCheckbox.Checked = False
                End If
            Next
            grdClaim.Rebind()
            If (lCheck) Then
                Page.RegisterStartupScript("testscript", "<script language='javascript'>location.href='ClaimBatchSearch.aspx';</script>")
            Else
                Response.Write("<script>alert('Please select at least one claim to create batch.');</script>")
            End If

        Catch ex As Exception
            Response.Write("<script>alert('Unable to create batch');</script>")
        End Try

    End Sub

    Protected Sub cmbPayer_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbPayer.ItemsRequested

        Dim lUser As User


        If (Session.Count = 0) Then
            Exit Sub
        End If


        Try

            If e.Text = "" Then
                Exit Sub
            End If

            lUser = CType(Session.Item("User"), User)

            Dim lInsurance As Insurance = New Insurance(lUser.ConnectionString)

            cmbPayer.DataSource = lInsurance.GetAllRecords("AND IsDelete= 'N' And CompanyName like '" & Utility.AdjustApostrophie(e.Text) & "%'Order By CompanyName").Tables(0)
            cmbPayer.DataTextField = "CompanyName"
            cmbPayer.DataBind()
            cmbPayer.Items.Insert(0, New RadComboBoxItem(""))


        Catch ex As Exception
            Dim lLogID As String
            lLogID = ErrorLogMethods.LogError(ex, " : UserControls\UserControls_PatientSearch.cmbLastName_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs)  ")
            Response.Redirect("ErrorPage.aspx?LogID=" & lLogID)

        End Try


    End Sub

    ' Commented by: Affan Toor | Date: 24-09-14 | Defect#: 2297 
    'Protected Sub btnPrinterFriendly_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles BtnPrinterFriendly.Click

    ''grdClaim.Rebind()
    ''Dim lds As DataSet = grdClaim.DataSource
    ''lds.WriteXml("C:\Inetpub\wwwroot\RxCure\Billing\Claims.xml")
    'Dim lCondition As String = ""
    'CreateCondition(lCondition)
    'Session("Condition") = lCondition
    ''Response.Redirect("../Billing/ClaimReport.aspx?Condition=" & lCondition)
    'Dim lScript As String = "window.open('ClaimReport.aspx?Condition=" & ElixirLibrary.Encryption.EncryptQueryString(lCondition) & "','Edit','scrollbars=yes,resizable=no,width=1050,height=800');"
    'Response.Write("<script>" & lScript & " return false;</script>")

    'End Sub

    Public Overrides Sub VerifyRenderingInServerForm(ByVal control As Control)
        ' Confirms that an HtmlForm control is rendered for the specified ASP.NET
        '     server control at run time. 
    End Sub

    Protected Sub btnSave2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave2.Click

        Dim lUser As User
        Dim lHCFAID As String = String.Empty
        Dim lComment As String = String.Empty
        Dim lClaim As ClaimMethods = Nothing

        Try

            lUser = CType(Session.Item("User"), User)
            lHCFAID = Me.hdHCFAID.Value.ToString
            If Me.hdComment.Value.ToString.Equals("") Then
                'Return
            Else
                '& lUser.FirstName & " " & lUser.LastName & "[" & lUser.LoginId & "]," + Date.Today.Date & ": "
                lComment = Me.hdComment.Value.ToString & " "
            End If


            'If Not lComment.Equals("") Then
            lClaim = New ClaimMethods
            ClaimMethods.UpdateComment(lHCFAID, lComment, lUser)
            grdClaim.Rebind()
            'End If



        Catch ex As Exception

        End Try

    End Sub

    Protected Sub grdClaim_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdClaim.SelectedIndexChanged

    End Sub

    Protected Sub btnMirror_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnMirror.Click
        Dim newWindow As RadWindow
        Try
            newWindow = New RadWindow()
            If (cmbPatient.Text.ToString.Split(",").Length = 1) Then
                newWindow.NavigateUrl = "PatientSearch.aspx?srch=" & Utility.AdjustApostrophie(Me.cmbPatient.Text.ToString.Split(",")(0)) & "|" & "" & ""
            ElseIf (cmbPatient.Text.ToString.Split(",").Length > 1) Then
                newWindow.NavigateUrl = "PatientSearch.aspx?srch=" & Utility.AdjustApostrophie(Me.cmbPatient.Text.ToString.Split(",")(0)) & "|" & Me.cmbPatient.Text.ToString.Split(",")(1) & ""
            Else

            End If
            newWindow.ID = "rwPrimaryInsurer"
            newWindow.VisibleOnPageLoad = True
            newWindow.Top = 220
            newWindow.Left = 280
            newWindow.Width = Unit.Pixel(697)
            newWindow.Height = Unit.Pixel(400)
            newWindow.VisibleTitlebar = False
            newWindow.VisibleStatusbar = False
            newWindow.BorderStyle = BorderStyle.Solid
            newWindow.ReloadOnShow = True
            newWindow.BackColor = Drawing.Color.Transparent
            newWindow.ClientCallBackFunction = "PatientSearchCallBackFunction"
            newWindow.Enabled = True
            newWindow.Visible = True
            rwmSuperBill.Windows.Add(newWindow)
        Catch ex As Exception
            Dim lLogID As String = String.Empty
            lLogID = ErrorLogMethods.LogError(ex, " Billing_PatientLedgerPage.aspx\btnMirror_Click() ")
            Response.Redirect("~/ErrorPage.aspx?LogID=" & lLogID, False)
        End Try
    End Sub

    Protected Sub btnBackPS_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnBackPS.Click
        Dim lPatientID As String
        Try
            lPatientID = ElixirLibrary.Encryption.EncryptQueryString("id=" & txtPatientID.Text)
            Response.Redirect("selectpatient.aspx" & lPatientID)
        Catch ex As Exception

        End Try
    End Sub
End Class
