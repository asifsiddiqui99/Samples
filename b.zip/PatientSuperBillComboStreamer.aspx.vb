
Partial Class PatientSuperBillComboStreamer
    Inherits System.Web.UI.Page
    Protected Sub cmbCPT1_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbCPT1.ItemsRequested

        If (Session.Count = 0) Then
            Exit Sub
        End If


        If e.Text = "" Then
            Exit Sub
        End If
        Dim lDs As New DataSet
        Dim lUser As User
        Dim lInsuranceCompanyID As String = ""

        'Dim lobjHealthPlanDb As New HealthPlanDB
        'lobjHealthPlanDb.ConsolidatedName = e.Text
        'mobjHealthPlanDb.State = cmbHealthPlanState.Text.Trim
        Try
            'lDs = HealthPlanMethods.GetHealthPlan(lobjHealthPlanDb, lUser, Request.Url.AbsoluteUri)
            If Session("InsuranceCompanyID") IsNot Nothing Then
                lInsuranceCompanyID = Session("InsuranceCompanyID").ToString()
            End If

            lUser = CType(Session.Item("User"), User)
            lDs = IMOMethods.SearchCPT(lUser, Utility.AdjustApostrophie(e.Text.Trim()), lInsuranceCompanyID)
            Me.cmbCPT1.DataSource = lDs
            Me.cmbCPT1.DataBind()
        Catch ex As Exception
            ErrorLogMethods.LogError(ex, "PatientSuperBillComboStreamer.aspx\cmbCPT1_ItemsRequested()")
            'Me.RadAjaxPanel1.Alert("Error in searching Patient FirstName")
        Finally
            lDs.Dispose()
        End Try
    End Sub

    Protected Sub cmbCPT2_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbCPT2.ItemsRequested

        If (Session.Count = 0) Then
            Exit Sub
        End If


        If e.Text = "" Then
            Exit Sub
        End If
        Dim lDs As New DataSet
        Dim lUser As User
        Dim lInsuranceCompanyID As String = ""

        'Dim lobjHealthPlanDb As New HealthPlanDB
        'lobjHealthPlanDb.ConsolidatedName = e.Text
        'mobjHealthPlanDb.State = cmbHealthPlanState.Text.Trim
        Try
            'lDs = HealthPlanMethods.GetHealthPlan(lobjHealthPlanDb, lUser, Request.Url.AbsoluteUri)
            If Session("InsuranceCompanyID") IsNot Nothing Then
                lInsuranceCompanyID = Session("InsuranceCompanyID").ToString()
            End If

            lUser = CType(Session.Item("User"), User)
            lDs = IMOMethods.SearchCPT(lUser, Utility.AdjustApostrophie(e.Text.Trim()), lInsuranceCompanyID)
            Me.cmbCPT2.DataSource = lDs
            Me.cmbCPT2.DataBind()
        Catch ex As Exception
            ErrorLogMethods.LogError(ex, "PatientSuperBillComboStreamer.aspx\cmbCPT2_ItemsRequested()")

        Finally
            lDs.Dispose()
        End Try
    End Sub

    Protected Sub cmbCPT3_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbCPT3.ItemsRequested

        If (Session.Count = 0) Then
            Exit Sub
        End If


        If e.Text = "" Then
            Exit Sub
        End If
        Dim lDs As New DataSet
        Dim lUser As User
        Dim lInsuranceCompanyID As String = ""

        'Dim lobjHealthPlanDb As New HealthPlanDB
        'lobjHealthPlanDb.ConsolidatedName = e.Text
        'mobjHealthPlanDb.State = cmbHealthPlanState.Text.Trim
        Try
            'lDs = HealthPlanMethods.GetHealthPlan(lobjHealthPlanDb, lUser, Request.Url.AbsoluteUri)
            If Session("InsuranceCompanyID") IsNot Nothing Then
                lInsuranceCompanyID = Session("InsuranceCompanyID").ToString()
            End If

            lUser = CType(Session.Item("User"), User)
            lDs = IMOMethods.SearchCPT(lUser, Utility.AdjustApostrophie(e.Text.Trim()), lInsuranceCompanyID)
            Me.cmbCPT3.DataSource = lDs
            Me.cmbCPT3.DataBind()
        Catch ex As Exception
            ErrorLogMethods.LogError(ex, "PatientSuperBillComboStreamer.aspx\cmbCPT3_ItemsRequested()")

        Finally
            lDs.Dispose()
        End Try
    End Sub

    Protected Sub cmbCPT4_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbCPT4.ItemsRequested

        If (Session.Count = 0) Then
            Exit Sub
        End If


        If e.Text = "" Then
            Exit Sub
        End If
        Dim lDs As New DataSet
        Dim lUser As User
        Dim lInsuranceCompanyID As String = ""

        'Dim lobjHealthPlanDb As New HealthPlanDB
        'lobjHealthPlanDb.ConsolidatedName = e.Text
        'mobjHealthPlanDb.State = cmbHealthPlanState.Text.Trim
        Try
            'lDs = HealthPlanMethods.GetHealthPlan(lobjHealthPlanDb, lUser, Request.Url.AbsoluteUri)
            If Session("InsuranceCompanyID") IsNot Nothing Then
                lInsuranceCompanyID = Session("InsuranceCompanyID").ToString()
            End If

            lUser = CType(Session.Item("User"), User)
            lDs = IMOMethods.SearchCPT(lUser, Utility.AdjustApostrophie(e.Text.Trim()), lInsuranceCompanyID)
            Me.cmbCPT4.DataSource = lDs
            Me.cmbCPT4.DataBind()
        Catch ex As Exception
            ErrorLogMethods.LogError(ex, "PatientSuperBillComboStreamer.aspx\cmbCPT4_ItemsRequested()")

        Finally
            lDs.Dispose()
        End Try
    End Sub

    Protected Sub cmbCPT5_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbCPT5.ItemsRequested

        If (Session.Count = 0) Then
            Exit Sub
        End If


        If e.Text = "" Then
            Exit Sub
        End If
        Dim lDs As New DataSet
        Dim lUser As User
        Dim lInsuranceCompanyID As String = ""

        'Dim lobjHealthPlanDb As New HealthPlanDB
        'lobjHealthPlanDb.ConsolidatedName = e.Text
        'mobjHealthPlanDb.State = cmbHealthPlanState.Text.Trim
        Try
            'lDs = HealthPlanMethods.GetHealthPlan(lobjHealthPlanDb, lUser, Request.Url.AbsoluteUri)
            If Session("InsuranceCompanyID") IsNot Nothing Then
                lInsuranceCompanyID = Session("InsuranceCompanyID").ToString()
            End If

            lUser = CType(Session.Item("User"), User)
            lDs = IMOMethods.SearchCPT(lUser, Utility.AdjustApostrophie(e.Text.Trim()), lInsuranceCompanyID)
            Me.cmbCPT5.DataSource = lDs
            Me.cmbCPT5.DataBind()
        Catch ex As Exception
            ErrorLogMethods.LogError(ex, "PatientSuperBillComboStreamer.aspx\cmbCPT5_ItemsRequested()")

        Finally
            lDs.Dispose()
        End Try
    End Sub

    Protected Sub cmbCPT6_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbCPT6.ItemsRequested

        If (Session.Count = 0) Then
            Exit Sub
        End If


        If e.Text = "" Then
            Exit Sub
        End If
        Dim lDs As New DataSet
        Dim lUser As User
        Dim lInsuranceCompanyID As String = ""

        'Dim lobjHealthPlanDb As New HealthPlanDB
        'lobjHealthPlanDb.ConsolidatedName = e.Text
        'mobjHealthPlanDb.State = cmbHealthPlanState.Text.Trim
        Try
            'lDs = HealthPlanMethods.GetHealthPlan(lobjHealthPlanDb, lUser, Request.Url.AbsoluteUri)
            If Session("InsuranceCompanyID") IsNot Nothing Then
                lInsuranceCompanyID = Session("InsuranceCompanyID").ToString()
            End If

            lUser = CType(Session.Item("User"), User)
            lDs = IMOMethods.SearchCPT(lUser, Utility.AdjustApostrophie(e.Text.Trim()), lInsuranceCompanyID)
            Me.cmbCPT6.DataSource = lDs
            Me.cmbCPT6.DataBind()
        Catch ex As Exception
            ErrorLogMethods.LogError(ex, "PatientSuperBillComboStreamer.aspx\cmbCPT6_ItemsRequested()")

        Finally
            lDs.Dispose()
        End Try
    End Sub

    Protected Sub cmbICD1_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbICD1.ItemsRequested

        If (Session.Count = 0) Then
            Exit Sub
        End If

        If e.Text = "" Then
            Exit Sub
        End If

        Dim lDs As New DataSet
        Dim lUser As User

        Try
            lUser = CType(Session.Item("User"), User)
            lDs = IMOMethods.SearchICD9(Utility.AdjustApostrophie(e.Text.Trim()))
            Me.cmbICD1.DataSource = lDs
            Me.cmbICD1.DataBind()
        Catch ex As Exception
            ErrorLogMethods.LogError(ex, "PatientSuperBillComboStreamer.aspx\cmbICD1_ItemsRequested()")

        Finally
            lDs.Dispose()
        End Try
    End Sub

    Protected Sub cmbICD2_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbICD2.ItemsRequested

        If (Session.Count = 0) Then
            Exit Sub
        End If

        If e.Text = "" Then
            Exit Sub
        End If

        Dim lDs As New DataSet
        Dim lUser As User

        Try
            lUser = CType(Session.Item("User"), User)
            lDs = IMOMethods.SearchICD9(Utility.AdjustApostrophie(e.Text.Trim()))
            Me.cmbICD2.DataSource = lDs
            Me.cmbICD2.DataBind()
        Catch ex As Exception
            ErrorLogMethods.LogError(ex, "PatientSuperBillComboStreamer.aspx\cmbICD2_ItemsRequested()")

        Finally
            lDs.Dispose()
        End Try
    End Sub

    Protected Sub cmbICD3_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbICD3.ItemsRequested

        If (Session.Count = 0) Then
            Exit Sub
        End If

        If e.Text = "" Then
            Exit Sub
        End If

        Dim lDs As New DataSet
        Dim lUser As User

        Try
            lUser = CType(Session.Item("User"), User)
            lDs = IMOMethods.SearchICD9(Utility.AdjustApostrophie(e.Text.Trim()))
            Me.cmbICD3.DataSource = lDs
            Me.cmbICD3.DataBind()
        Catch ex As Exception
            ErrorLogMethods.LogError(ex, "PatientSuperBillComboStreamer.aspx\cmbICD3_ItemsRequested()")

        Finally
            lDs.Dispose()
        End Try
    End Sub

    Protected Sub cmbICD4_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbICD4.ItemsRequested

        If (Session.Count = 0) Then
            Exit Sub
        End If

        If e.Text = "" Then
            Exit Sub
        End If

        Dim lDs As New DataSet
        Dim lUser As User

        Try
            lUser = CType(Session.Item("User"), User)
            lDs = IMOMethods.SearchICD9(Utility.AdjustApostrophie(e.Text.Trim()))
            Me.cmbICD4.DataSource = lDs
            Me.cmbICD4.DataBind()
        Catch ex As Exception
            ErrorLogMethods.LogError(ex, "PatientSuperBillComboStreamer.aspx\cmbICD4_ItemsRequested()")

        Finally
            lDs.Dispose()
        End Try
    End Sub
End Class
