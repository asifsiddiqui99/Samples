Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared

Imports System.Data
Imports ElixirLibrary
Imports System.Data.SqlClient
Partial Class Billing_SBTemplatePrint
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim lOrderInformation As String
        Dim lSuperBillId As String
        Dim lDs As New DataSet
        Dim lDsCPT As New DataSet
        Dim lDsICD As New DataSet
        Dim lUser As User = Session("User")
        Dim lSuperBill As SuperBill

        '//--Initializing CrystalReport        
        Dim myReportDocument As ReportDocument

        Try
            If Session("ReportDocument") Is Nothing Then
                myReportDocument = New ReportDocument
            Else
                myReportDocument = CType(Session("ReportDocument"), ReportDocument)
            End If

            Dim lqueryString As NameValueCollection = Encryption.DecryptQueryString(Request.QueryString.ToString())

            If Not (lqueryString.Count > 0) Then
                Throw New Exception()
            End If
            lSuperBillId = lqueryString("sid")
            lOrderInformation = SuperBillMethods.LoadSuperBillOrderInformation(lSuperBillId)

            lSuperBill = New SuperBill(lUser.ConnectionString)
            lSuperBill.SuperBill.SuperBillId = lSuperBillId

            lDs = lSuperBill.GetSuperBillHeaderForTemplate("", "SuperBillTemplate")

            '********** CPT Codes *********************
            lDsCPT = SuperBillMethods.GetCPT(lSuperBillId, lOrderInformation, "SuperBillTemplateCPT")
            If lDsCPT.Tables.Count < 3 Then
                Throw New Exception()
            End If
            '********** End CPT Codes *********************


            '********** ICD Codes *********************
            lDsICD = SuperBillMethods.GetICD(lSuperBillId, lOrderInformation, "SuperBillTemplateICD")
            If lDsICD.Tables.Count < 3 Then
                Throw New Exception()
            End If
            '********** END ICD Codes *********************
        Catch ex As Exception
            Response.Write("<script>alert('Error Generating Report, Contact your System administrator');</script>")
            Return
        End Try

        CrystalReportViewer1.DisplayGroupTree = False
        CrystalReportViewer1.HasCrystalLogo = False

        CrystalReportViewer1.Zoom(130)
        CrystalReportViewer1.BestFitPage = False
        CrystalReportViewer1.Width = New Unit("100%")
        CrystalReportViewer1.Height = New Unit("1500")



     

        myReportDocument.Load(Server.MapPath("Reports\SuperBillTemplate.rpt"))
        myReportDocument.SetDataSource(lDs)

        myReportDocument.Subreports(0).SetDataSource(lDsCPT.Tables(0))
        myReportDocument.Subreports(1).SetDataSource(lDsCPT.Tables(1))
        myReportDocument.Subreports(2).SetDataSource(lDsCPT.Tables(2))


        myReportDocument.Subreports(3).SetDataSource(lDsICD.Tables(0))
        myReportDocument.Subreports(4).SetDataSource(lDsICD.Tables(1))
        myReportDocument.Subreports(5).SetDataSource(lDsICD.Tables(2))
        Session.Add("ReportDocument", myReportDocument)

        ''//--Binding report with CrystalReportViewer        
        'CrystalReportViewer1.ReportSource = myReportDocument
        'CrystalReportViewer1.DataBind()

        'CrystalReportViewer1.PrintMode = CrystalDecisions.Web.PrintMode.ActiveX
        Response.ClearContent()
        Response.ClearHeaders()
        Response.ContentType = "application/pdf"

        myReportDocument.ExportToHttpResponse(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat, Response, False, "")
        Response.Flush()
        Response.Close()
    End Sub



    
    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload
        Dim myReportDocument As ReportDocument

        If Session("ReportDocument") IsNot Nothing Then
            myReportDocument = CType(Session("ReportDocument"), ReportDocument)
            myReportDocument.Close()
            myReportDocument.Dispose()
            Session.Remove("ReportDocument")
            CrystalReportViewer1.Dispose()
            CrystalReportViewer1 = Nothing
        End If

        
    End Sub
End Class
