
Partial Class Billing_ClaimReport
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim lds As DataSet
        Dim lClaim As ClaimMethods
        Dim pGrid As New Telerik.WebControls.RadGrid
        Dim lUser As User
        Dim lCondition As String
        Dim myReportDocument As CrystalDecisions.CrystalReports.Engine.ReportDocument

        lUser = CType(Session.Item("User"), User)

        Try
            RemoveReportDoc()

            If Session("ReportDocument") Is Nothing Then
                myReportDocument = New CrystalDecisions.CrystalReports.Engine.ReportDocument
            Else
                myReportDocument = CType(Session("ReportDocument"), CrystalDecisions.CrystalReports.Engine.ReportDocument)
            End If

            lClaim = New ClaimMethods()
            'lCondition = Request.QueryString("Condition").ToString
            'queryString = Encryption.DecryptQueryString(Request.QueryString.ToString())
            lCondition = Session("Condition")
            ClaimMethods.LoadClaimGridNew(pGrid, lCondition, lUser)
            lds = pGrid.DataSource
            lds.Tables(0).TableName = "Claim"

            myReportDocument.Load(Server.MapPath("Reports\ClaimsRpt.rpt"))
            myReportDocument.SetDataSource(lds)

            Dim lCrystalViewer As New CrystalDecisions.Web.CrystalReportViewer
            CrystalReportViewer1.DisplayGroupTree = False
            CrystalReportViewer1.HasCrystalLogo = False
            CrystalReportViewer1.HasViewList = True


            CrystalReportViewer1.Zoom(100)
            CrystalReportViewer1.BestFitPage = False
            CrystalReportViewer1.Width = New Unit("100%")
            CrystalReportViewer1.Height = New Unit("800")
            CrystalReportViewer1.ReportSource = myReportDocument
            Session("ReportDocument") = myReportDocument
            CrystalReportViewer1.DataBind()


            'CrystalReportViewer1.PrintMode = CrystalDecisions.Web.PrintMode.ActiveX
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload

        Dim myReportDocument As CrystalDecisions.CrystalReports.Engine.ReportDocument
        If Session("ReportDocument") IsNot Nothing Then
            myReportDocument = CType(Session("ReportDocument"), CrystalDecisions.CrystalReports.Engine.ReportDocument)
            myReportDocument.Close()
            myReportDocument.Dispose()
            Session.Remove("ReportDocument")
        End If
        CrystalReportViewer1.Dispose()
        CrystalReportViewer1 = Nothing

    End Sub
    Private Sub RemoveReportDoc()
        Dim myReportDocument As CrystalDecisions.CrystalReports.Engine.ReportDocument
        Try
            If Session("ReportDocument") IsNot Nothing Then
                myReportDocument = CType(Session("ReportDocument"), CrystalDecisions.CrystalReports.Engine.ReportDocument)
                myReportDocument.Close()
                myReportDocument.Dispose()
                Session.Remove("ReportDocument")
            End If
        Catch ex As Exception

        End Try
    End Sub
End Class
