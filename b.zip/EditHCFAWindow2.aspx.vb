
Partial Class Billing_EditHCFAWindow2
    Inherits System.Web.UI.Page

    Dim mqueryString As String
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim lHCFAUpdated As HCFADBUpdated

        Try
            pnlFacility.Visible = False
            pnlBilling.Visible = False
            lHCFAUpdated = New HCFADBUpdated
            lHCFAUpdated = Session("HCFADBUpdated")

            mqueryString = Request.QueryString.ToString()

            Select Case (mqueryString)
                Case "LocationInfo"
                    pnlFacility.Visible = True
                    txtFAddress1.Text = lHCFAUpdated.ServiceFacility.AddressLine1
                    txtFAddress2.Text = lHCFAUpdated.ServiceFacility.AddressLine2
                    txtFCity.Text = lHCFAUpdated.ServiceFacility.City
                    txtFState.Text = lHCFAUpdated.ServiceFacility.State
                    txtFZipCode.Text = lHCFAUpdated.ServiceFacility.ZipCode
                Case "ProviderInfo"
                    pnlBilling.Visible = True
                    txtBAddress1.Text = lHCFAUpdated.BillingPvd.AddressLine1
                    txtBAddress2.Text = lHCFAUpdated.BillingPvd.AddressLine2
                    txtBCity.Text = lHCFAUpdated.BillingPvd.City
                    txtBPhone1.Text = lHCFAUpdated.BillingPvd.Phone1
                    txtBPhone2.Text = lHCFAUpdated.BillingPvd.Phone2

            End Select


        Catch ex As Exception

        End Try
    End Sub

    Protected Sub ImgBtnSave_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImgBtnSave.Click
        Dim lHCFAUpdated As HCFADBUpdated

        Try
            lHCFAUpdated = New HCFADBUpdated
            lHCFAUpdated = Session("HCFADBUpdated")
            Select Case (mqueryString)
                Case "LocationInfo"

                    lHCFAUpdated.ServiceFacility.AddressLine1 = Utility.AdjustApostrophie(txtFAddress1.Text)
                    lHCFAUpdated.ServiceFacility.AddressLine2 = Utility.AdjustApostrophie(txtFAddress2.Text)
                    lHCFAUpdated.ServiceFacility.City = Utility.AdjustApostrophie(txtFCity.Text)
                    lHCFAUpdated.ServiceFacility.State = Utility.AdjustApostrophie(txtFState.Text)
                    lHCFAUpdated.ServiceFacility.ZipCode = Utility.AdjustApostrophie(txtFZipCode.Text)
                    Session("HCFADBUpdated") = lHCFAUpdated
                Case "ProviderInfo"

                    lHCFAUpdated.BillingPvd.AddressLine1 = Utility.AdjustApostrophie(txtBAddress1.Text)
                    lHCFAUpdated.BillingPvd.AddressLine2 = Utility.AdjustApostrophie(txtBAddress2.Text)
                    lHCFAUpdated.BillingPvd.City = Utility.AdjustApostrophie(txtBCity.Text)
                    lHCFAUpdated.BillingPvd.Phone1 = Utility.AdjustApostrophie(txtBPhone1.Text)
                    lHCFAUpdated.BillingPvd.Phone2 = Utility.AdjustApostrophie(txtBPhone2.Text)
                    Session("HCFADBUpdated") = lHCFAUpdated
            End Select
            CloseWindow()
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub ImgBtnCancel_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImgBtnCancel.Click
        Response.Write("<script>window.close();</script>")
    End Sub
    Private Sub CloseWindow()

        Dim sb As New StringBuilder()
        sb.Append("window.opener.document.forms[0].submit();")
        sb.Append("window.close();")
        ClientScript.RegisterClientScriptBlock(Me.[GetType](), "CloseWindowScript", sb.ToString(), True)
    End Sub
End Class
