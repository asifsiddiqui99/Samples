Imports System.Collections.Generic
Imports Telerik.WebControls
Imports BillingReportMethod
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Partial Class Billing_MontlyTransactionReport
    Inherits System.Web.UI.Page

    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click

        Try
            LoadReport()
        Catch ex As Exception
            Response.Write("<script>alert('Error Generating Report, Contact your System administrator');</script>")
        End Try
    End Sub
    Public Sub LoadReport()

        Dim lDs As New DataSet()
        Dim myReportDocument As ReportDocument
        Dim lUser As User = CType(HttpContext.Current.Session("User"), User)
        Dim lConnection As New Connection(lUser.ConnectionString)
        Dim lClinic As New Clinic(lUser.ConnectionString)
        Dim clinicTbl As DataTable
        Dim lDs2 As New DataSet()

        Dim lYear As String = CmbYear.Text.ToString
        Dim lFirstYear As String
        Dim lLastYear As String

        lFirstYear = lYear.Split("-")(0)
        lLastYear = lYear.Split("-")(1)

        Dim lFDate As DateTime = CDate("September" + " / 01 / " + lFirstYear)
        Dim lLDate As DateTime = CDate("September" + " / 01 / " + lLastYear)
        Try

            RemoveReportDoc()
            If Session("ReportDocument") Is Nothing Then
                myReportDocument = New ReportDocument
            Else
                myReportDocument = CType(Session("ReportDocument"), ReportDocument)
            End If

            lDs2 = lClinic.GetClinicInfoForReports(lUser.ClinicId)
            lDs = GetMonthlyTransDetail(lFDate, lLDate)
            lDs2.Tables(0).TableName = "ClinicInfo"
            clinicTbl = New DataTable("ClinicInfo")
            clinicTbl = lDs2.Tables(0).Copy()
            lDs.Tables.Add(clinicTbl)
            lDs.Tables(1).TableName = "ClinicInfo"
            lDs.Tables(0).TableName = "MonthlyTransDetail"

            myReportDocument.Load(Server.MapPath("Reports/MonthlyDailyTransDetailReport.rpt"))
            If lDs.Tables(0).Rows.Count > 0 Then
                myReportDocument.SetDataSource(lDs)
                Me.crvMontlyTransReport.ReportSource = myReportDocument
                Session.Add("ReportDocument", myReportDocument)
                Me.crvMontlyTransReport.Zoom(100)
                Me.crvMontlyTransReport.BestFitPage = False
                Me.crvMontlyTransReport.DisplayGroupTree = False
                Me.crvMontlyTransReport.HasViewList = False
                Me.crvMontlyTransReport.HasDrillUpButton = False
                Me.crvMontlyTransReport.HasZoomFactorList = False
                Me.crvMontlyTransReport.HasExportButton = False
                Me.crvMontlyTransReport.HasSearchButton = False
                Me.crvMontlyTransReport.HasPageNavigationButtons = True
                Me.crvMontlyTransReport.HasToggleGroupTreeButton = False
                Me.crvMontlyTransReport.HasCrystalLogo = False
                Me.crvMontlyTransReport.HasDrillUpButton = False
                Me.crvMontlyTransReport.HasGotoPageButton = False
                Me.crvMontlyTransReport.EnableDrillDown = True
                Me.crvMontlyTransReport.Width = New Unit("100%")
                Me.crvMontlyTransReport.Height = New Unit("100%")
                Me.crvMontlyTransReport.DataBind()
                'Me.crvMontlyTransReport.PrintMode = CrystalDecisions.Web.PrintMode.ActiveX

            End If

        Catch ex As Exception
            Response.Write("<script>alert('Error Generating Report, Contact your System administrator');</script>")
        End Try

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim lCurrentMonth As Integer = Now.Month
        Dim lItem As String
        Dim lCurYr As Integer = Now.Date.Year
        Dim lNxtYr As Integer = Date.Now.AddYears(1).Year
        Dim lPrYr As Integer = Date.Now.AddYears(-1).Year

        Try


            If (Not Page.IsPostBack) Then

                If lCurrentMonth > 9 Then
                    lItem = lCurYr.ToString + "-" + lNxtYr.ToString
                    CmbYear.SelectedIndex = CmbYear.FindItemIndexByText(lItem)
                Else

                    lItem = lPrYr.ToString + "-" + lCurYr.ToString
                    CmbYear.SelectedIndex = CmbYear.FindItemIndexByText(lItem)

                End If
            End If

            If (Page.IsPostBack) Then
                LoadReport()

                If CmbYear.SelectedIndex = -1 Then
                    CmbYear.SelectedIndex = CmbYear.FindItemIndexByValue(0)
                End If

            End If
        Catch ex As Exception
            Response.Write("<script>alert('Error Generating Report, Contact your System administrator');</script>")
        End Try

    End Sub
    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload
        Try
            Dim myReportDocument As ReportDocument
            If Session("ReportDocument") IsNot Nothing Then
                myReportDocument = CType(Session("ReportDocument"), ReportDocument)
                myReportDocument.Close()
                myReportDocument.Dispose()
                Session.Remove("ReportDocument")
               
            End If
            crvMontlyTransReport.Dispose()
            crvMontlyTransReport = Nothing
        Catch ex As Exception
            Response.Write("<script>alert('Error Generating Report, Contact your System administrator');</script>")
            Return
        End Try
    End Sub

    Private Sub RemoveReportDoc()
        Dim myReportDocument As ReportDocument
        Try
            If Session("ReportDocument") IsNot Nothing Then
                myReportDocument = CType(Session("ReportDocument"), ReportDocument)
                myReportDocument.Close()
                myReportDocument.Dispose()
                Session.Remove("ReportDocument")

            End If
        Catch ex As Exception

        End Try
    End Sub
End Class
