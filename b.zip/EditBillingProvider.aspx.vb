
Partial Class Billing_EditBillingProvider
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim lUser As User
        Dim lIsAuthorize As Boolean
        Dim lUserRoles As UserRoles
        Dim lBillingProviderID As String = ""
        lUser = CType(Session.Item("User"), User)

        Dim lqueryString As NameValueCollection = Encryption.DecryptQueryString(Request.QueryString.ToString())

        If (lqueryString("ID") IsNot Nothing AndAlso lqueryString("ID") <> "") Then
            lBillingProviderID = lqueryString("ID")
        End If

        If IsPostBack = False Then
            lUserRoles = New UserRoles(lUser.ConnectionString)
            '********* Check User Validity ************
            lIsAuthorize = lUserRoles.CheckPageAuthorization(lUser.UserId, "ClinicSetup.aspx")
            If Not lIsAuthorize Then
                Response.Redirect("unauthorization.aspx", False)
            End If
            '********* Load Authorized Tabs Only ***********
            StateMethods.Load_States(cbState, lUser)
            FillInformationFromObject(BillingProviderMethods.GetBillingProvider(lUser, "BillingProviderID='" & lBillingProviderID & "'"))
            LoadTypeCombo()

        End If

        Me.btnCancel.OnClientClick = "javascript:window.history.go(-1);return false;"
    End Sub
    Public Sub LoadTypeCombo()
        If (txtOrganizationName.Text <> "") Then
            cbType.SelectedValue = 1
            txtFirstName.Enabled = False
            txtMiddleName.Enabled = False
            txtLastName.Enabled = False
            txtOrganizationName.Enabled = True
        End If
    End Sub
    Public Sub LoadProvider()
        Dim lDS As New DataSet
        Dim lUser As User
        Try
            lUser = CType(Session.Item("User"), User)
            lDS = BillingProviderMethods.LoadAllProviders(lUser, "")
            cbProvider.DataSource = lDS.Tables(0)
            cbProvider.DataBind()
        Catch ex As Exception

        End Try
    End Sub
    Public Sub FillInformationFromObject(ByVal pBillingProviderDB As BillingProviderDB)

        If (pBillingProviderDB.FirstName = "") Then
            txtOrganizationName.Text = pBillingProviderDB.LastName
        Else
            txtFirstName.Text = pBillingProviderDB.FirstName
            txtMiddleName.Text = pBillingProviderDB.MiddleName
            txtLastName.Text = pBillingProviderDB.LastName
        End If
        txtBillingProviderID.Text = pBillingProviderDB.BillingProviderId
        txtAddressOne.Text = pBillingProviderDB.AddressLine1
        txtAddressTwo.Text = pBillingProviderDB.AddressLine2
        txtCity.Text = pBillingProviderDB.City
        Utility.SelectComboItem(cbState, pBillingProviderDB.State, False)
        txtZipCode.Text = pBillingProviderDB.ZipCode
        txtPhoneOne.Text = pBillingProviderDB.Phone1
        txtPhoneTwo.Text = pBillingProviderDB.Phone2
        txtFax.Text = pBillingProviderDB.Fax
        txtEmail.Text = pBillingProviderDB.Email
        txtNPI.Text = pBillingProviderDB.NPI
        txtTaxID.Text = pBillingProviderDB.TaxID
        mtbSSN.Text = pBillingProviderDB.SSN
        Utility.SelectComboItem(cbBillingProviderType, pBillingProviderDB.EntryType, True)
        txtHiddenNPI.Text = pBillingProviderDB.ProviderNPI

        If (pBillingProviderDB.EntryType <> "G") Then
            LoadProvider()
            Utility.SelectComboItem(cbProvider, pBillingProviderDB.ProviderID, True)
            Utility.SelectComboItem(cbInsuranceType, pBillingProviderDB.EntryInsuranceTypeCode, True)
        Else
            Utility.SelectComboItem(cbInsuranceType, "0", True)
        End If
    End Sub

    'Protected Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnCancel.Click
    '    Response.Redirect("BillingProviderSetup.aspx")
    'End Sub
    Public Function SaveInformationToObject() As BillingProviderDB
        Dim lBillingProviderDB As New BillingProviderDB
        With lBillingProviderDB
            If (txtOrganizationName.Text <> "") Then
                .LastName = Utility.ChangeCase(Utility.AdjustApostrophie(txtOrganizationName.Text))
            Else
                .LastName = Utility.ChangeCase(Utility.AdjustApostrophie(txtLastName.Text))
            End If
            .FirstName = Utility.ChangeCase(Utility.AdjustApostrophie(txtFirstName.Text))
            .MiddleName = Utility.ChangeCase(Utility.AdjustApostrophie(txtMiddleName.Text))
            .BillingProviderId = txtBillingProviderID.Text
            .AddressLine1 = Utility.AdjustApostrophie(txtAddressOne.Text)
            .AddressLine2 = Utility.AdjustApostrophie(txtAddressTwo.Text)
            .City = Utility.ChangeCase(Utility.AdjustApostrophie(txtCity.Text))
            .State = cbState.SelectedItem.Text
            .ZipCode = Utility.AdjustApostrophie(txtZipCode.Text)
            .Phone1 = Utility.AdjustApostrophie(txtPhoneOne.Text)
            .Phone2 = Utility.AdjustApostrophie(txtPhoneTwo.Text)
            .Fax = Utility.AdjustApostrophie(txtFax.Text)
            .Email = Utility.AdjustApostrophie(txtEmail.Text)
            .TaxID = Utility.AdjustApostrophie(txtTaxID.Text)
            .NPI = Utility.AdjustApostrophie(txtNPI.Text)
            .SSN = Utility.AdjustApostrophie(mtbSSN.Text)
            .EntryType = Utility.AdjustApostrophie(cbBillingProviderType.SelectedValue)

            If (cbBillingProviderType.SelectedValue <> "G") Then
                .ProviderID = Utility.AdjustApostrophie(cbProvider.SelectedValue)
                .ProviderNPI = Utility.AdjustApostrophie(txtHiddenNPI.Text)
                .EntryInsuranceTypeCode = Utility.AdjustApostrophie(cbInsuranceType.SelectedValue)
                .EntryInsuranceTypeValue = Utility.AdjustApostrophie(cbInsuranceType.SelectedItem.Text)
            Else
                .ProviderID = ""
                .ProviderNPI = ""
                .EntryInsuranceTypeCode = "0"
                .EntryInsuranceTypeValue = ""
            End If
        End With
        Return lBillingProviderDB
    End Function

    Protected Sub btnUpdate_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnUpdate.Click
        Dim lUser As User
        Try
            lUser = CType(Session.Item("User"), User)
            If (BillingProviderMethods.UpdateBillingProvider(SaveInformationToObject, lUser)) Then
                Response.Write("<script>alert('Billing Provider Updated Successfully');</script>")
                PageExpire()
                Response.Write("<script>location.href = 'BillingProviderSetup.aspx';</script>")
            End If
        Catch ex As Exception

        End Try

    End Sub


    Public Sub PageExpire()
        Response.Buffer = True
        Response.ExpiresAbsolute = Now.Subtract(New TimeSpan(1, 0, 0, 0))
        Response.Expires = 0
        Response.CacheControl = "no-cache"
    End Sub
End Class
