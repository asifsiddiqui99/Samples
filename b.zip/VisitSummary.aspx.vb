Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared

Imports System.Data
Imports ElixirLibrary
Imports System.Data.SqlClient


Partial Class Billing_VisitSummary
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Try
            Dim lSuperBillId As String
            Dim queryString As NameValueCollection

            If (Page.IsPostBack = False) Then

                queryString = Encryption.DecryptQueryString(Request.QueryString.ToString())
                If queryString("sid") Is Nothing Then
                    Throw New Exception()
                End If

                lSuperBillId = queryString("sid").ToString
                Me.txtSid.Text = queryString("sid").ToString

            End If
            'If (Page.IsPostBack = False) Then

            Dim myReportDocument As New ReportDocument()

            Dim lUser As User = CType(HttpContext.Current.Session("User"), User)
            Dim lDs As New DataSet
            Dim lClinic As New Clinic(lUser.ConnectionString)

            Dim lDs2 As New DataSet
            Dim ldt As New DataTable
            Dim lDsCPT As New DataSet
            Dim lDsICD As New DataSet
            'Dim lUser As User = Session("User")
            Dim lSuperBill As SuperBill
            Dim lParameterFields As New ParameterFields()
            Dim lParameterField As New ParameterField()
            Dim lParameterValue As New ParameterDiscreteValue()

            lSuperBill = New SuperBill(lUser.ConnectionString)
            lSuperBill.SuperBill.SuperBillId = Me.txtSid.Text

            lDs = SuperBillMethods.GetVisitSummary(Me.txtSid.Text)
            lDs2 = lClinic.GetClinicInfoForReports(lUser.ClinicId)


            lDs.Tables(0).TableName = "VisitSummary1"
            lDs.Tables(1).TableName = "VisitSummaryReceipt"
            lDs.Tables(2).TableName = "VisitSummaryClaimInformation"
            lDs.Tables(3).TableName = "VisitSummaryDetail"
            lDs.Tables(4).TableName = "VisitPaymentDetail"
            lDs.Tables(5).TableName = "VisitAdjustment"

            CrystalReportViewer1.DisplayGroupTree = False
            CrystalReportViewer1.HasCrystalLogo = False
            CrystalReportViewer1.HasViewList = True


            CrystalReportViewer1.Zoom(100)
            CrystalReportViewer1.BestFitPage = False
            CrystalReportViewer1.Width = New Unit("100%")
            CrystalReportViewer1.Height = New Unit("1500")


            myReportDocument.Load(Server.MapPath("Reports\VisitSummaryReport.rpt"))
            myReportDocument.SetDataSource(lDs.Tables(0))

            'myReportDocument.Subreports(0).d
            myReportDocument.Subreports(0).SetDataSource(lDs.Tables("VisitAdjustment"))
            myReportDocument.Subreports(1).SetDataSource(lDs.Tables("VisitSummaryClaimInformation"))
            myReportDocument.Subreports(2).SetDataSource(lDs.Tables("VisitPaymentDetail"))
            myReportDocument.Subreports(3).SetDataSource(lDs.Tables("VisitSummaryReceipt"))

        

            myReportDocument.SetParameterValue("PClinicName", lDs2.Tables(0).Rows(0)("ClinicName"))


            myReportDocument.SetParameterValue("PClinicAddress", lDs2.Tables(0).Rows(0)("ClinicAddressLine1") + " " + lDs2.Tables(0).Rows(0)("ClinicCity") + " " + lDs2.Tables(0).Rows(0)("ClinicState") + " " + lDs2.Tables(0).Rows(0)("ClinicZipCode"))

            CrystalReportViewer1.ParameterFieldInfo = lParameterFields

            Session.Add("ReportDocument", myReportDocument)

            ''//--Binding report with CrystalReportViewer  

            'CrystalReportViewer1.OnDrillDownSubreport
            CrystalReportViewer1.ReportSource = myReportDocument
            CrystalReportViewer1.DataBind()

            'CrystalReportViewer1.PrintMode = CrystalDecisions.Web.PrintMode.ActiveX
            'Response.ClearContent()
            'Response.ClearHeaders()
            'Response.ContentType = "application/pdf"
            'Session.Add("ReportDocument", myReportDocument)

            'myReportDocument.ExportToHttpResponse(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat, Response, False, "")
            'Response.Flush()
            'Response.Close()

            'End If
        Catch ex As Exception
            Response.Write("<script>alert('Error Generating Report, Contact your System administrator');</script>")
        End Try

    End Sub

    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload
        Dim myReportDocument As ReportDocument

        If Session("ReportDocument") IsNot Nothing Then
            myReportDocument = CType(Session("ReportDocument"), ReportDocument)
            myReportDocument.Close()
            myReportDocument.Dispose()
            Session.Remove("ReportDocument")
        End If


    End Sub
End Class
