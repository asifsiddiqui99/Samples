
Partial Class Billing_AgingReport
    Inherits System.Web.UI.Page

    Protected Sub rdSelect_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdSelect.SelectedIndexChanged

        Try
            If (rdSelect.SelectedValue = "P") Then
                pnlPatient.Visible = True
                pnlInsurance.Visible = False
                Session("Type") = "P"
                If Session("PatientDS") IsNot Nothing Then
                    btnPrint.Enabled = True

                Else
                    btnPrint.Enabled = False
                End If
            ElseIf (rdSelect.SelectedValue = "I") Then
                pnlPatient.Visible = False
                pnlInsurance.Visible = True
                Session("Type") = "I"
                If Session("InsuranceDS") IsNot Nothing Then
                    btnPrint.Enabled = True

                Else
                    btnPrint.Enabled = False
                End If
            End If




        Catch ex As Exception

        End Try
    End Sub

    Protected Sub btnPrint_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnPrint.Click
        If Session("InsuranceDS") IsNot Nothing Or Session("PatientDS") IsNot Nothing Then
            Me.AgingRptByPatient1.GridRetain()
            Me.AgingRptByInsurance1.GridRetain()
            Dim lScript As String = "window.open('AgingPrinterFriendly.aspx','Edit','scrollbars=yes,resizable=no,width=1050,height=600');"
            Response.Write("<script>" & lScript & ";</script>")
        Else

        End If
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        EnableDisable(Me.btnPrint)
        If Not IsPostBack Then
            Session("Type") = "P"
            Session("PatientDS") = Nothing
            Session("InsuranceDS") = Nothing
        End If
    End Sub
    Public Sub EnableDisable(ByRef lBtn As ImageButton)

        Me.AgingRptByPatient1.BtnPrint = lBtn
        Me.AgingRptByInsurance1.BtnPrint = lBtn
    End Sub
End Class
