Imports Telerik.WebControls

Partial Class Billing_PreviewSuperBill
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim lPatientSuperBillID As String = Request.QueryString("sid")
        txtSuperID.text = lPatientSuperBillID

        Dim lFormatedSuperBillId As String = "RxCure-SB-" & lPatientSuperBillID.PadLeft(8, "0")
        lblSuperBillID.Text = lFormatedSuperBillId


        If lPatientSuperBillID.Equals("") Then
            Response.Redirect("Main.aspx")
        End If


        grdCPT1.Columns(0).Resizable = True
        'grdCPT1.Columns(0).HeaderStyle.Width = Unit.Pixel(2)
        ' grdCPT1.Columns(0).FooterStyle.Width = Unit.Pixel(2)
        'grdCPT1.Columns(1).Visible = False
        'grdCPT1.Columns(2).Visible = False

        LoadPatient(lPatientSuperBillID)
        LoadClinic()
        LoadSuperBillOrderInformation()



    End Sub

    Private Sub LoadPatient(ByVal pPatientSuperBillID As String)
        Dim lDataSet As DataSet = Nothing
        lDataSet = SuperBillMethods.GetPatientSuperBill(pPatientSuperBillID)
        Dim lUser As User = CType(Session("User"), User)

        If lDataSet IsNot Nothing AndAlso lDataSet.Tables(0).Rows.Count > 0 Then
            lblPatientName.Text = lDataSet.Tables(0).Rows(0).Item("PatientName").ToString
            lblPatientDOB.Text = lDataSet.Tables(0).Rows(0).Item("DOB").ToString.Split(" ")(0)
            lblPatientAddress.Text = lDataSet.Tables(0).Rows(0).Item("Address").ToString
            lblPatientCity.Text = lDataSet.Tables(0).Rows(0).Item("City").ToString
            lblPatientState.Text = lDataSet.Tables(0).Rows(0).Item("State").ToString
            lblPatientZipcode.Text = lDataSet.Tables(0).Rows(0).Item("ZipCode").ToString
            lblPrimaryInsuranceCompany.Text = lDataSet.Tables(0).Rows(0).Item("PrimaryInsuranceCompanyName").ToString
            lblSecondaryInsuranceCompany.Text = lDataSet.Tables(0).Rows(0).Item("SecondryInsuranceCompanyName").ToString
            lblGuarantorName.Text = lDataSet.Tables(0).Rows(0).Item("GuarantorName").ToString
            lblBalance.Text = lDataSet.Tables(0).Rows(0).Item("Balance").ToString
            lblDateOfService.Text = lDataSet.Tables(0).Rows(0).Item("DateOfService").ToString.Split(" ")(0) ' This was done to ensure that time does not get appended to the date: cudnt do it in the query cuz it was generalized
            txtSuperBillTemplateId.Text = lDataSet.Tables(0).Rows(0).Item("SuperBillTemplateID").ToString
            Label7.Text = EmployeeMethods.GetEmployeeByID(lUser, lDataSet.Tables(0).Rows(0).Item("PrescriberID").ToString).Tables(0).Rows(0).Item("EmployeeName")
            'txtPatientSuperBillID.text = pPatientSuperBillID
        End If

    End Sub

    Private Sub LoadClinic()
        Dim lUser As User
        Dim lClinic As ClinicDB
        Dim lState As StateDB        

        lUser = CType(Session("User"), User)
        lClinic = ClinicMethods.GetClinic(lUser)        

        lblClinicName.Text = lClinic.ClinicName
        lblClinicAddress.Text = lClinic.AddressLine1
        lblClinicCity.Text = lClinic.City
        lblClinicZipCode.Text = lClinic.ZipCode
        lState = StateMethods.GetState(lClinic.StateId)
        lblClinicState.Text = lState.Abbr

    End Sub

    Private Sub LoadSuperBillOrderInformation()
        Dim lUser As User
        Dim lSuperBill As SuperBill
        Dim lResult As Boolean

        lUser = CType(Session.Item("User"), User)


        lSuperBill = New SuperBill(lUser.ConnectionString)
        lSuperBill.SuperBill.SuperBillId = txtSuperBillTemplateId.Text
        lResult = lSuperBill.GetRecordByID()

        If Not lResult Then
            Return
        End If

        With lSuperBill.SuperBill
            'ICDSortBy + Order + CPTSortBy + Order 
            txtOrderBy.Text = lSuperBill.SuperBill.ICDSortBy & "|" & lSuperBill.SuperBill.ICDSortOrder & "|" & _
                                       lSuperBill.SuperBill.CPTSortBy & "|" & lSuperBill.SuperBill.CPTSortOrder
        End With
    End Sub

    Protected Sub grdCPT1_ItemDataBound(ByVal sender As Object, ByVal e As Telerik.WebControls.GridItemEventArgs) Handles grdCPT1.ItemDataBound, grdCPT2.ItemDataBound, grdCPT3.ItemDataBound
        Dim lCheckBox As CheckBox = Nothing
        Dim litem As GridDataItem

        If e.Item.ItemType = GridItemType.Item Or e.Item.ItemType = GridItemType.AlternatingItem Then
            litem = e.Item
            'lCheckBox = litem("CheckboxSelectColumn").Controls(1)
            lCheckBox = litem.FindControl("cbCPT")


            If e.Item.Cells(9).Text.ToString.Equals("Y") Then
                lCheckBox.Checked = True
            End If
        End If
        e.Item.Cells(0).Visible = False
        If e.Item.ItemType = GridItemType.GroupHeader Then
            e.Item.Cells(1).Text = e.Item.Cells(1).Text.ToString().Substring(e.Item.Cells(1).Text.IndexOf(":") + 1)
        End If
    End Sub

    Protected Sub grdCPT1_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdCPT1.NeedDataSource
        GenerateSuperBillMethods.LoadPreviewCPTGrid(grdCPT1, txtSuperID.Text, txtSuperBillTemplateId.Text, txtOrderBy.Text, 0)
    End Sub


    Protected Sub grdCPT2_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdCPT2.NeedDataSource
        GenerateSuperBillMethods.LoadPreviewCPTGrid(grdCPT2, txtSuperID.Text, txtSuperBillTemplateId.Text, txtOrderBy.Text, 1)
    End Sub

    Protected Sub grdCPT3_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdCPT3.NeedDataSource
        GenerateSuperBillMethods.LoadPreviewCPTGrid(grdCPT3, txtSuperID.Text, txtSuperBillTemplateId.Text, txtOrderBy.Text, 2)
    End Sub


    Protected Sub grdCPT_ItemCreated(ByVal sender As Object, ByVal e As Telerik.WebControls.GridItemEventArgs) Handles grdCPT1.ItemCreated, grdCPT2.ItemCreated, grdCPT3.ItemCreated
        'Dim lCheckBox As CheckBox
        'Dim litem As GridHeaderItem

        'If e.Item.ItemType = GridItemType.Header Then
        '    litem = e.Item
        '    lCheckBox = litem("CheckboxSelectColumn").Controls(1)
        '    lCheckBox.Visible = False
        'End If
    End Sub


    Protected Sub grdICD1_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdICD1.NeedDataSource
        GenerateSuperBillMethods.LoadICDGridForPreview(grdICD1, txtSuperID.Text, txtSuperBillTemplateId.Text, txtOrderBy.Text, 0)
    End Sub

    Protected Sub grdICD2_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdICD2.NeedDataSource
        GenerateSuperBillMethods.LoadICDGridForPreview(grdICD2, txtSuperID.Text, txtSuperBillTemplateId.Text, txtOrderBy.Text, 1)
    End Sub

    Protected Sub grdICD3_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdICD3.NeedDataSource
        GenerateSuperBillMethods.LoadICDGridForPreview(grdICD3, txtSuperID.Text, txtSuperBillTemplateId.Text, txtOrderBy.Text, 2)
    End Sub

    Protected Sub grdICD1_ItemCreated(ByVal sender As Object, ByVal e As Telerik.WebControls.GridItemEventArgs) Handles grdICD1.ItemCreated, grdICD2.ItemCreated, grdICD3.ItemCreated
        'Dim lcheckBox As CheckBox
        'Dim litem As GridHeaderItem

        'If e.Item.ItemType = GridItemType.Header Then
        '    litem = e.Item
        '    lcheckBox = litem("CheckboxSelectColumn").Controls(1)
        '    lcheckBox.Visible = False
        'End If
    End Sub

    Protected Sub grdICD_ItemDataBound(ByVal sender As Object, ByVal e As Telerik.WebControls.GridItemEventArgs) Handles grdICD1.ItemDataBound, grdICD2.ItemDataBound, grdICD3.ItemDataBound
        Dim lCheckBox As CheckBox = Nothing
        Dim litem As GridDataItem

        If e.Item.ItemType = GridItemType.Item Or e.Item.ItemType = GridItemType.AlternatingItem Then

            litem = e.Item
            'lCheckBox = litem("CheckboxSelectColumn").Controls(1)
            lCheckBox = litem.FindControl("cbICD")


            If e.Item.Cells(5).Text.ToString.Equals("Y") Then
                lCheckBox.Checked = True
            End If
        End If
    End Sub

End Class
