
Partial Class FeeScheduleStreamer
    Inherits System.Web.UI.Page

    Protected Sub cbInsurance_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cbInsurance.ItemsRequested

        Dim lDS As DataSet = Nothing

        Try
            lDS = FeeScheduleMethod.AutocompeteQueryForAddFeeSch(Session.Item("User"), e.Text)
            cbInsurance.DataSource = Nothing
            cbInsurance.DataSource = lDS
            cbInsurance.DataTextField = "CompanyName"
            cbInsurance.DataValueField = "FavouriteInsuranceID"
            cbInsurance.DataBind()


        Catch ex As Exception

        End Try


    End Sub
End Class
