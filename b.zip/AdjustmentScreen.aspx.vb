Imports Telerik.WebControls
Imports System
Imports System.Collections.Generic
Imports System.Globalization
Partial Class Billing_AdjustmentScreen
    Inherits System.Web.UI.Page
    Dim mUser As User
    Dim mDs As New DataSet
    Dim mobj As AdjustmentScreenDB
    Dim mPaymentDtlCollection As New Hashtable 'PaymentDtlCollection

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Try
            mUser = CType(Session.Item("User"), User)
            Dim lvisitid As String = String.Empty
            Dim lCPTCode As String = String.Empty
            Dim lCPTID As String = String.Empty
            Dim lds As DataSet = Nothing
            If (Not Page.IsPostBack) Then

                FillTypecombo()
                FillReasonCodecombo()

                If (Session("Count") IsNot Nothing) Then
                    Session.Remove("Count")
                End If


                ''IF USER HAS CLICK THE HEADER ROW.......
                Dim queryString As NameValueCollection = Encryption.DecryptQueryString(Request.QueryString.ToString())
                If (queryString.Count = 1) Then


                    lvisitid = queryString(0)
                    lds = AdjustmentScreenMethods.GetAdjustmentByVisitID(mUser, " And VisitID=" & lvisitid & " And CPTCode=''")
                    lblCPTCode.Text = ""

                    If (lds IsNot Nothing) Then

                        Session("Count") = lds.Tables(0).Rows.Count

                        grdList.DataSource = lds
                        grdList.DataBind()


                        Session("DataSet") = lds

                        getbycollection()

                    End If
                End If

                ''IF USER HAS CLICK THE CHILD ROW........
                If (queryString.Count > 1) Then
                    lvisitid = queryString(0)
                    lCPTCode = queryString(1)
                    lCPTID = queryString(2)
                    lblCPTCode.Text = " for CPT Code: " & lCPTCode

                    lds = AdjustmentScreenMethods.GetAdjustmentByVisitID(mUser, " And VisitID=" & lvisitid & " And CPTCode='" & lCPTCode & "'" & " And CptId='" & lCPTID & "'")
                    If (lds IsNot Nothing) Then

                        Session("Count") = lds.Tables(0).Rows.Count

                        grdList.DataSource = lds
                        grdList.DataBind()



                        Session("DataSet") = lds

                        getchildbycollection()


                    End If
                End If



            End If





        Catch ex As Exception

        End Try
    End Sub

    Public Sub FillTypecombo()
        Try




            cmbType.DataSource = AdjustmentScreenMethods.GetTypeCode(mUser)
            cmbType.DataTextField = "AdjustmentType"
            cmbType.DataValueField = "AdjustmentType"
            cmbType.DataBind()

            DropDownList1.DataSource = AdjustmentScreenMethods.GetTypeCode(mUser)
            DropDownList1.DataTextField = "AdjustmentType"
            DropDownList1.DataValueField = "DrCrAdjustment"
            DropDownList1.DataBind()
        Catch ex As Exception

        End Try
    End Sub

    Public Sub FillReasonCodecombo()
        Try
            cmbReasonCode.DataSource = AdjustmentScreenMethods.GetAdjReasonCode(mUser)
            cmbReasonCode.DataTextField = "ReasonCode"
            cmbReasonCode.DataValueField = "ReasonID"
            cmbReasonCode.DataBind()
            cmbReasonCode.Items.Insert(0, "")
        Catch ex As Exception

        End Try
    End Sub

    Public Sub Fillgrid()
        Try
            grdList.DataSource = AdjustmentScreenMethods.GetListRecord(mUser)
            grdList.DataBind()
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub ImgbtnAddtoList_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImgbtnAddtoList.Click
        Dim lDataTable As New DataTable()
        Dim lds As New DataSet
        Dim li As Integer = 0

        Try

            For li = 0 To cmbType.Items.Count - 1
                If (cmbType.SelectedItem.Text = DropDownList1.Items(li).Text) Then
                    Exit For
                End If
            Next

            lDataTable.Columns.Add("AdjustmentDescription")
            lDataTable.Columns.Add("AdjustmentType")
            lDataTable.Columns.Add("ReasonCode")
            lDataTable.Columns.Add("Amount")
            lDataTable.Columns.Add("IsPrevious")
            lDataTable.Columns.Add("Notes")

            Dim lDatarow As DataRow
            lDatarow = lDataTable.NewRow()

            lDatarow("AdjustmentDescription") = cmbType.SelectedItem.Text
            lDatarow("AdjustmentType") = DropDownList1.Items(li).Value
            lDatarow("ReasonCode") = cmbReasonCode.SelectedItem.Text
            lDatarow("Amount") = txtAmount.Text
            lDatarow("IsPrevious") = "No"
            lDatarow("Notes") = txtNote.Text

            lDataTable.Rows.Add(lDatarow)

            If Session("DataSet") Is Nothing Then
                lds.Tables.Add(lDataTable)
            Else
                lds = Session("DataSet")
                Dim i As Integer

                For i = 0 To lDataTable.Rows.Count - 1
                    lds.Tables(0).Rows.Add( _
                       lDataTable.Rows(i)("AdjustmentDescription"), lDataTable.Rows(i)("AdjustmentType"), lDataTable.Rows(i)("ReasonCode"), lDataTable.Rows(i)("Amount"), "No", lDataTable.Rows(i)("Notes"))
                Next
            End If



            Session("DataSet") = lds

            grdList.DataSource = lds
            grdList.DataBind()




            txtAmount.Text = ""
            cmbReasonCode.SelectedIndex = 0
            txtNote.Text = ""

            ViewState("ClickAddToList") = True

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub ImgbtnSave_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImgbtnSave.Click
        Try
            Dim li As Integer = 0
            Dim lj As Integer = 0
            Dim lk As Integer = 0
            Dim lNewlyAdded As Integer = 0

            Dim lds As DataSet = Nothing
            Dim lpaymentdtl As PaymentDtlDB = Nothing
            Dim queryString As NameValueCollection = Encryption.DecryptQueryString(Request.QueryString.ToString())
            Dim lvisitid As String = queryString(0)
            Dim lCPTCode As String = String.Empty
            Dim lCPTID As String = String.Empty

            lds = Session("DataSet")

            For li = 0 To lds.Tables(0).Rows.Count - 1
                mobj = New AdjustmentScreenDB
                mobj.VisitID = 1
                mobj.CPTCode = "asdAS"
                mobj.AdjustmentDescription = lds.Tables(0).Rows(li)("AdjustmentDescription")
                mobj.ReasonCode = lds.Tables(0).Rows(li)("ReasonCode")
                mobj.AdjustmentType = lds.Tables(0).Rows(li)("AdjustmentType")
                mobj.Amount = mobj.Amount + lds.Tables(0).Rows(li)("Amount")
                mobj.UserID = 1
                mobj.PaymentDtlID = 1
                mobj.PaymentID = 1
                'AdjustmentScreenMethods.InsertListRecord(mUser, mobj)
            Next


            ''..............Area for calculating adjustment..................
            mPaymentDtlCollection = Session("PaymentDetailCollectionForHeader")
            lpaymentdtl = mPaymentDtlCollection.Item(lvisitid)


            ''IF USER HAS CLICK THE HEADER ROW........(AT THE CLAIM LEVEL)
            If (queryString.Count = 1) Then
                lpaymentdtl.AdjustmentCollection.Clear()

                lpaymentdtl.Adjustment = CalculateForHeader()
                For li = 0 To grdList.Items.Count - 1

                    lpaymentdtl.AdjustmentCollection.Add(New AdjustmentDB)

                    lpaymentdtl.AdjustmentCollection.Item(li).Amount = grdList.Items(li).Cells(4).Text
                    lpaymentdtl.AdjustmentCollection.Item(li).AdjustmentDate = Now.Date
                    lpaymentdtl.AdjustmentCollection.Item(li).VisitID = lvisitid
                    lpaymentdtl.AdjustmentCollection.Item(li).CPTCode = ""
                    lpaymentdtl.AdjustmentCollection.Item(li).CPTID = ""
                    lpaymentdtl.AdjustmentCollection.Item(li).AdjustmentDescription = grdList.Items(li).Cells(2).Text
                    lpaymentdtl.AdjustmentCollection.Item(li).ReasonCode = grdList.Items(li).Cells(3).Text
                    lpaymentdtl.AdjustmentCollection.Item(li).AdjustmentType = grdList.Items(li).Cells(5).Text
                    lpaymentdtl.AdjustmentCollection.Item(li).UserID = mUser.UserId
                    lpaymentdtl.AdjustmentCollection.Item(li).Notes = IIf(grdList.Items(li).Cells(8).Text = "&nbsp;", "", grdList.Items(li).Cells(8).Text)



                    If (grdList.Items(li).Cells(6).Text = "Yes") Then
                        lpaymentdtl.AdjustmentCollection.Item(li).IsPrevious = "Yes"
                    Else
                        lpaymentdtl.AdjustmentCollection.Item(li).IsPrevious = "No"
                    End If
                Next



            End If

            ''IF USER HAS CLICK THE DETAIL ROW........(AT THE CPT LEVEL)
            If (queryString.Count > 1) Then
                lCPTCode = queryString(1)
                lCPTID = queryString(2)

                For li = 0 To lpaymentdtl.PaymentCPTDetailCollection.Count - 1

                    If (lpaymentdtl.PaymentCPTDetailCollection.Item(li).CPTCode = lCPTCode) And _
                        (lpaymentdtl.PaymentCPTDetailCollection.Item(li).CPTId = lCPTID) Then

                        lpaymentdtl.PaymentCPTDetailCollection.Item(li).AdjustmentCollection.Clear()

                        lpaymentdtl.PaymentCPTDetailCollection.Item(li).Adjustment = CalculateForDetail()


                        For lj = 0 To grdList.Items.Count - 1

                            lpaymentdtl.PaymentCPTDetailCollection.Item(li).AdjustmentCollection.Add(New AdjustmentDB)
                            lpaymentdtl.PaymentCPTDetailCollection.Item(li).AdjustmentCollection(lj).Amount = grdList.Items(lj).Cells(4).Text
                            lpaymentdtl.PaymentCPTDetailCollection.Item(li).AdjustmentCollection(lj).AdjustmentDate = Now.Date
                            lpaymentdtl.PaymentCPTDetailCollection.Item(li).AdjustmentCollection(lj).VisitID = lvisitid
                            lpaymentdtl.PaymentCPTDetailCollection.Item(li).AdjustmentCollection(lj).CPTCode = lCPTCode
                            lpaymentdtl.PaymentCPTDetailCollection.Item(li).AdjustmentCollection(lj).CPTID = lCPTID
                            lpaymentdtl.PaymentCPTDetailCollection.Item(li).AdjustmentCollection(lj).AdjustmentDescription = grdList.Items(lj).Cells(2).Text & " for CPT:" & lCPTCode
                            lpaymentdtl.PaymentCPTDetailCollection.Item(li).AdjustmentCollection(lj).ReasonCode = IIf(grdList.Items(lj).Cells(3).Text = "&nbsp;", "", grdList.Items(lj).Cells(3).Text)
                            lpaymentdtl.PaymentCPTDetailCollection.Item(li).AdjustmentCollection(lj).AdjustmentType = grdList.Items(lj).Cells(5).Text
                            lpaymentdtl.PaymentCPTDetailCollection.Item(li).AdjustmentCollection(lj).UserID = mUser.UserId
                            lpaymentdtl.PaymentCPTDetailCollection.Item(li).AdjustmentCollection(lj).Notes = IIf(grdList.Items(lj).Cells(8).Text = "&nbsp;", "", grdList.Items(lj).Cells(8).Text)

                            If (grdList.Items(lj).Cells(6).Text = "Yes") Then
                                lpaymentdtl.PaymentCPTDetailCollection.Item(li).AdjustmentCollection.Item(lj).IsPrevious = "Yes"
                            Else
                                lpaymentdtl.PaymentCPTDetailCollection.Item(li).AdjustmentCollection.Item(lj).IsPrevious = "No"
                            End If



                        Next

                        Exit For

                    End If

                Next
            End If

            Session("PaymentDetailCollectionForHeader") = mPaymentDtlCollection

            Const cRefreshParent As String = "<script language='javascript'>" & "  window.opener.document.forms(0).submit();" & "</script>"
            Const cRefreshParentKey As String = "RefreshParentKey"
            If Not Me.Page.ClientScript.IsClientScriptBlockRegistered(cRefreshParentKey) Then
                Me.Page.ClientScript.RegisterClientScriptBlock(Me.[GetType](), cRefreshParentKey, cRefreshParent)
            End If

            Session("Save") = True


            If (ViewState("ClickAddToList") = False) Then
                Response.Write("<script>alert('No records to add');</script>")
                Exit Sub
            End If

            ViewState("ClickAddToList") = False

            CloseWindow()


        Catch ex As Exception
            Response.Write(ex.Message)
        End Try
    End Sub

    Protected Sub ImgbtnCancel_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImgbtnCancel.Click
        'Const cRefreshParent As String = "<script language='javascript'>" & "  window.opener.document.forms(0).submit();" & "</script>"
        'Const cRefreshParentKey As String = "RefreshParentKey"
        'If Not Me.Page.ClientScript.IsClientScriptBlockRegistered(cRefreshParentKey) Then
        '    'Me.Page.ClientScript.RegisterClientScriptBlock(Me.[GetType](), cRefreshParentKey, cRefreshParent)
        'End If
        ViewState("ClickAddToList") = False
        CloseWindow()

    End Sub
    Private Sub CloseWindow()

        Dim sb As New StringBuilder()
        'sb.Append("window.opener.document.forms[0].submit();")
        sb.Append("window.close();")
        ClientScript.RegisterClientScriptBlock(Me.[GetType](), "CloseWindowScript", sb.ToString(), True)

    End Sub

    Private Function CalculateForHeader() As Double
        Dim li As Integer = 0
        Dim lAdjustmentSum As Double = 0
        Dim lAdjustmentRow As Integer = 0

        Try
            For li = 0 To grdList.Items.Count - 1

                If (grdList.Items(li).Cells(5).Text.ToUpper = "DR") Then
                    lAdjustmentSum = CType(lAdjustmentSum, Double) + CType(grdList.Items(li).Cells(4).Text, Double)
                End If

                If (grdList.Items(li).Cells(5).Text.ToUpper = "CR") Then
                    lAdjustmentSum = CType(lAdjustmentSum, Double) - CType(grdList.Items(li).Cells(4).Text, Double)
                End If

            Next

            Return lAdjustmentSum
        Catch ex As Exception
            Response.Write(ex.Message)
        End Try

        Return Nothing

    End Function

    Private Function CalculateForDetail() As Double
        Dim li As Integer = 0
        Dim lAdjustmentSum As Double = 0
        Dim lAdjustmentRow As Integer = 0

        Try
            For li = 0 To grdList.Items.Count - 1

                If (grdList.Items(li).Cells(5).Text.ToUpper = "DR") Then
                    lAdjustmentSum = CType(lAdjustmentSum, Double) + CType(grdList.Items(li).Cells(4).Text, Double)
                End If

                If (grdList.Items(li).Cells(5).Text.ToUpper = "CR") Then
                    lAdjustmentSum = CType(lAdjustmentSum, Double) - CType(grdList.Items(li).Cells(4).Text, Double)
                End If

            Next

            Return lAdjustmentSum

        Catch ex As Exception
            Response.Write(ex.Message)
        End Try

        Return Nothing

    End Function

    Private Sub getbycollection()

        Dim li As Integer = 0

        Dim lpaymentdtl As PaymentDtlDB = Nothing
        Dim queryString As NameValueCollection = Encryption.DecryptQueryString(Request.QueryString.ToString())
        Dim lvisitid As String = queryString(0)
        Dim lCPTCode As String = String.Empty
        Dim lDataTable As New DataTable()
        Dim lds As New DataSet

        lDataTable.Columns.Add("AdjustmentDescription")
        lDataTable.Columns.Add("AdjustmentType")
        lDataTable.Columns.Add("ReasonCode")
        lDataTable.Columns.Add("Amount")
        lDataTable.Columns.Add("IsPrevious")


        ''..............Area for calculating adjustment..................
        mPaymentDtlCollection = Session("PaymentDetailCollectionForHeader")
        lpaymentdtl = mPaymentDtlCollection.Item(lvisitid)

        For li = 0 To lpaymentdtl.AdjustmentCollection.Count - 1

            lDataTable.Rows.Add(lpaymentdtl.AdjustmentCollection.Item(li).AdjustmentDescription, _
            lpaymentdtl.AdjustmentCollection.Item(li).AdjustmentType, lpaymentdtl.AdjustmentCollection.Item(li).ReasonCode, _
            lpaymentdtl.AdjustmentCollection.Item(li).Amount, lpaymentdtl.AdjustmentCollection.Item(li).IsPrevious)

        Next

        If (lDataTable.Rows.Count > 0) Then
            grdList.DataSource = lDataTable
            grdList.DataBind()

            lds.Tables.Add(lDataTable)
            Session("DataSet") = lds
        End If



    End Sub

    Private Sub getchildbycollection()

        Dim li As Integer = 0
        Dim lj As Integer = 0

        Dim lpaymentdtl As PaymentDtlDB = Nothing

        Dim queryString As NameValueCollection = Encryption.DecryptQueryString(Request.QueryString.ToString())

        Dim lvisitid As String = queryString(0)
        Dim lCPTCode As String = queryString(1)
        Dim lLineID As String = queryString(2)
        Dim lDataTable As New DataTable()
        Dim lds As New DataSet

        lDataTable.Columns.Add("AdjustmentDescription")
        lDataTable.Columns.Add("AdjustmentType")
        lDataTable.Columns.Add("ReasonCode")
        lDataTable.Columns.Add("Amount")
        lDataTable.Columns.Add("IsPrevious")


        ''..............Area for calculating adjustment..................
        mPaymentDtlCollection = Session("PaymentDetailCollectionForHeader")
        lpaymentdtl = mPaymentDtlCollection.Item(lvisitid)

        For li = 0 To lpaymentdtl.PaymentCPTDetailCollection.Count - 1

            If ((lpaymentdtl.PaymentCPTDetailCollection.Item(li).CPTCode = lCPTCode) And (lpaymentdtl.PaymentCPTDetailCollection.Item(li).LineID = lLineID)) Then

                For lj = 0 To lpaymentdtl.PaymentCPTDetailCollection.Item(li).AdjustmentCollection.Count - 1

                    lDataTable.Rows.Add(lpaymentdtl.PaymentCPTDetailCollection(li).AdjustmentCollection.Item(lj).AdjustmentDescription, _
                                                lpaymentdtl.PaymentCPTDetailCollection(li).AdjustmentCollection.Item(lj).AdjustmentType, _
                                                lpaymentdtl.PaymentCPTDetailCollection(li).AdjustmentCollection.Item(lj).ReasonCode, _
                                                lpaymentdtl.PaymentCPTDetailCollection(li).AdjustmentCollection.Item(lj).Amount, _
                                                lpaymentdtl.PaymentCPTDetailCollection(li).AdjustmentCollection.Item(lj).IsPrevious)


                Next


            End If

        Next


        If (lDataTable.Rows.Count > 0) Then
            grdList.DataSource = lDataTable
            grdList.DataBind()

            lds.Tables.Add(lDataTable)
            Session("DataSet") = lds
        End If



    End Sub

    Protected Sub grdList_ItemCommand(ByVal source As Object, ByVal e As Telerik.WebControls.GridCommandEventArgs) Handles grdList.ItemCommand
        Dim lds As New DataSet
        lds = Session("DataSet")

        Try
            lds.Tables(0).Rows(e.Item.ItemIndex).Delete()
            lds.Tables(0).AcceptChanges()

            grdList.DataSource = lds
            grdList.DataBind()


        Catch ex As Exception

        End Try



    End Sub

    Protected Sub grdList_ItemDataBound(ByVal sender As Object, ByVal e As Telerik.WebControls.GridItemEventArgs) Handles grdList.ItemDataBound
      
        If e.Item.ItemType = GridItemType.AlternatingItem Or e.Item.ItemType = GridItemType.Item Then
            If (Not Page.IsPostBack) Then
                
                Dim item As GridDataItem = DirectCast(e.Item, GridDataItem)

                Dim imgBtn As ImageButton = DirectCast(item("DeleteColumn").Controls(0), ImageButton)


                If (e.Item.ItemIndex < Session("Count")) Then
                    imgBtn.ImageUrl = "~/Images/DeleteforAdjusmtnet.gif"
                    imgBtn.Enabled = False
                Else
                    imgBtn.ImageUrl = "~/Images/delete.gif"
                End If

            

            Else

                Dim item As GridDataItem = DirectCast(e.Item, GridDataItem)

                Dim imgBtn As ImageButton = DirectCast(item("DeleteColumn").Controls(0), ImageButton)

                If (e.Item.ItemIndex >= Session("Count")) Then
                    imgBtn.ImageUrl = "~/Images/delete.gif"
                Else
                    imgBtn.ImageUrl = "~/Images/DeleteforAdjusmtnet.gif"
                    imgBtn.Enabled = False
                End If

                

               



            End If
        End If






    End Sub
End Class
