Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared

Imports System.Data
Imports ElixirLibrary
Imports System.Data.SqlClient
Partial Class Billing_PSBPrint
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim lOrderInformation As String
        Dim lSuperBillId As String
        Dim lDs As New DataSet
        Dim lDsPatient As New DataSet
        Dim lDsCPT As New DataSet
        Dim lDsICD As New DataSet
        Dim lUser As User = Session("User")
        Dim lSuperBill As SuperBill


        Try

            Dim queryString As NameValueCollection
            queryString = Encryption.DecryptQueryString(Request.QueryString.ToString())



            If queryString("sid") Is Nothing Then
                Throw New Exception()
            End If
            'txtSuperID.Text = Request.QueryString("sid").ToString()
            Me.txtPatientSuperBillID.Text = queryString("sid").ToString()
            lDsPatient = LoadPatient(txtPatientSuperBillID.Text)
            lSuperBillId = txtSuperBillTemplateId.Text
            lOrderInformation = SuperBillMethods.LoadSuperBillOrderInformation(lSuperBillId)

            lSuperBill = New SuperBill(lUser.ConnectionString)
            lSuperBill.SuperBill.SuperBillId = lSuperBillId

            lDs = lSuperBill.GetSuperBillHeader(" And PSB.PatientSuperBillID=" & txtPatientSuperBillID.Text, "SuperBillTemplate")
            Dim lTable As New DataTable("PatientInfo")
            lTable = lDsPatient.Tables(0).Copy
            lDs.Tables.Add(lTable)
            lDs.Tables(1).TableName = "PatientInfo"

            '********** CPT Codes *********************
            lDsCPT = SuperBillMethods.GetCPTPreviewPrint(txtPatientSuperBillID.Text, txtSuperBillTemplateId.Text, lOrderInformation, "SuperBillTemplateCPT")
            If lDsCPT.Tables.Count < 3 Then
                Throw New Exception()
            End If
            '********** End CPT Codes *********************


            '********** ICD Codes *********************
            lDsICD = SuperBillMethods.GetICDPreviewPrint(txtPatientSuperBillID.Text, txtSuperBillTemplateId.Text, lOrderInformation, "SuperBillTemplateICD")
            If lDsICD.Tables.Count < 3 Then
                Throw New Exception()
            End If
            '********** END ICD Codes *********************
        Catch ex As Exception
            Response.Write("<script>alert('Error Generating Report, Contact your System administrator');</script>")
            Return
        End Try

        CrystalReportViewer1.DisplayGroupTree = False
        CrystalReportViewer1.HasCrystalLogo = False

        CrystalReportViewer1.Zoom(130)
        CrystalReportViewer1.BestFitPage = False
        CrystalReportViewer1.Width = New Unit("100%")
        CrystalReportViewer1.Height = New Unit("1500")
        'CrystalReportViewer1.EnableParameterPrompt = False



        '//--Initializing CrystalReport        
        Dim myReportDocument As ReportDocument

        If Session("ReportDocument") Is Nothing Then
            myReportDocument = New CrystalDecisions.CrystalReports.Engine.ReportDocument
        Else
            myReportDocument = CType(Session("ReportDocument"), CrystalDecisions.CrystalReports.Engine.ReportDocument)
        End If

        myReportDocument.Load(Server.MapPath("Reports\PatientSuperBill.rpt"))
        'Dim crFormulas As FormulaFieldDefinitions
        'Dim Testing As FormulaFieldDefinition
        'crFormulas = myReportDocument.DataDefinition.FormulaFields
        'Testing = crFormulas("Testing")
        'Testing.Text = "\" & "TransactionSummary\" & ""
        myReportDocument.SetDataSource(lDs)
        'myReportDocument.SetParameterValue("PatientName", lDsPatient.Tables(0).Rows(0).Item("PatientName").ToString())


        myReportDocument.Subreports(0).SetDataSource(lDsCPT.Tables(0))
        myReportDocument.Subreports(1).SetDataSource(lDsCPT.Tables(1))
        myReportDocument.Subreports(2).SetDataSource(lDsCPT.Tables(2))


        myReportDocument.Subreports(3).SetDataSource(lDsICD.Tables(0))
        myReportDocument.Subreports(4).SetDataSource(lDsICD.Tables(1))
        myReportDocument.Subreports(5).SetDataSource(lDsICD.Tables(2))
        Session.Add("ReportDocument", myReportDocument)

        '//--Binding report with CrystalReportViewer        
        'CrystalReportViewer1.ReportSource = myReportDocument
        'CrystalReportViewer1.DataBind()

        'CrystalReportViewer1.PrintMode = CrystalDecisions.Web.PrintMode.ActiveX


        ' Export the document to PDF
        Response.ClearContent()
        Response.ClearHeaders()
        Response.ContentType = "application/pdf"


        myReportDocument.ExportToHttpResponse(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat, Response, False, "")
        Response.Flush()
        Response.Close()
        ' Export the document to PDF
    End Sub
    Private Function LoadPatient(ByVal pPatientSuperBillID As String) As DataSet
        Dim lDataSet As DataSet = Nothing
        lDataSet = SuperBillMethods.GetPatientSuperBillReport(pPatientSuperBillID)
        Dim lUser As User = CType(Session("User"), User)

        If lDataSet IsNot Nothing AndAlso lDataSet.Tables(0).Rows.Count > 0 Then
            ' ''lblPatientName.Text = lDataSet.Tables(0).Rows(0).Item("PatientName").ToString
            ' ''lblPatientDOB.Text = lDataSet.Tables(0).Rows(0).Item("DOB").ToString.Split(" ")(0)
            ' ''lblPatientAddress.Text = lDataSet.Tables(0).Rows(0).Item("Address").ToString
            ' ''lblPatientCity.Text = lDataSet.Tables(0).Rows(0).Item("City").ToString
            ' ''lblPatientState.Text = lDataSet.Tables(0).Rows(0).Item("State").ToString
            ' ''lblPatientZipcode.Text = lDataSet.Tables(0).Rows(0).Item("ZipCode").ToString
            ' ''lblPrimaryInsuranceCompany.Text = lDataSet.Tables(0).Rows(0).Item("PrimaryInsuranceCompanyName").ToString
            ' ''lblSecondaryInsuranceCompany.Text = lDataSet.Tables(0).Rows(0).Item("SecondryInsuranceCompanyName").ToString
            ' ''lblGuarantorName.Text = lDataSet.Tables(0).Rows(0).Item("GuarantorName").ToString
            ' ''lblBalance.Text = lDataSet.Tables(0).Rows(0).Item("Balance").ToString
            ' ''lblDateOfService.Text = lDataSet.Tables(0).Rows(0).Item("DateOfService").ToString.Split(" ")(0) ' This was done to ensure that time does not get appended to the date: cudnt do it in the query cuz it was generalized
            txtSuperBillTemplateId.Text = lDataSet.Tables(0).Rows(0).Item("SuperBillTemplateID").ToString
            ' ''Label7.Text = EmployeeMethods.GetEmployeeByID(lUser, lDataSet.Tables(0).Rows(0).Item("PrescriberID").ToString).Tables(0).Rows(0).Item("EmployeeName")
            'txtPatientSuperBillID.text = pPatientSuperBillID
        End If
        Return lDataSet

    End Function



    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload
        Dim myReportDocument As ReportDocument

        If Session("ReportDocument") IsNot Nothing Then
            myReportDocument = CType(Session("ReportDocument"), ReportDocument)
            myReportDocument.Close()
            myReportDocument.Dispose()
            Session.Remove("ReportDocument")
        End If
        CrystalReportViewer1.Dispose()
        CrystalReportViewer1 = Nothing


    End Sub
  
End Class
