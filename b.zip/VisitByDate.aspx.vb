
Partial Class Billing_VisitByDate
    Inherits System.Web.UI.Page



    Protected Sub cmbProvider_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbProvider.ItemsRequested
        Dim lDS As DataSet
        Dim lUser As User
        Dim lEmployee As Employee
        'lUser = CType(Session.Item("User"), User)
        'Dim lBillingProvider As New BillingProvider(lUser.ConnectionString)
        'Try
        '    lDS = lBillingProvider.AutocompeteQuery(e.Text)
        '    cmbProvider.DataSource = Nothing
        '    cmbProvider.DataSource = lDS
        '    cmbProvider.DataTextField = "Name"
        '    cmbProvider.DataValueField = "EmployeeID"
        '    cmbProvider.DataBind()
        'Catch ex As Exception

        'End Try
        'Upper block commented and below block added by HJ 7-1-2014 for defect no 2440
        lUser = HttpContext.Current.Session("User")
        lEmployee = New Employee(lUser.ConnectionString)

        Try
            lDS = lEmployee.GetActiveEmployees(" And SPI<>'' ")
            cmbProvider.DataTextField = "EmployeeName"
            cmbProvider.DataValueField = "EmployeeID"
            cmbProvider.DataSource = lDS
            cmbProvider.DataBind()
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        
        If Not Me.IsPostBack Then
            Me.dpTo.SelectedDate = Date.Now.Date
            Me.dpFrom.SelectedDate = Date.Now.AddMonths(-6)
            EmployeeMethods.LoadDocCombo(cmbProvider)
            cmbProvider.Items.Insert(0, New Telerik.WebControls.RadComboBoxItem(""))
        End If
        If Page.IsPostBack Then
            LoadReport()
        End If
       
    End Sub

    Protected Sub btnGenerate_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnGenerate.Click
        LoadReport()
    End Sub
    Public Sub RemoveReportDoc()
        Dim myReportDocument As CrystalDecisions.CrystalReports.Engine.ReportDocument
        Try
            If Session("ReportDocument") IsNot Nothing Then
                myReportDocument = CType(Session("ReportDocument"), CrystalDecisions.CrystalReports.Engine.ReportDocument)
                myReportDocument.Close()
                myReportDocument.Dispose()
                Session.Remove("ReportDocument")
              
            End If
        Catch ex As Exception

        End Try
    End Sub
    Public Sub LoadReport()
        Dim lDs As New DataSet
        Dim lUser As User
        Dim lcondition As String
        RemoveReportDoc()
        Dim myReportDocument As CrystalDecisions.CrystalReports.Engine.ReportDocument
        Try

            If Session("ReportDocument") Is Nothing Then
                myReportDocument = New CrystalDecisions.CrystalReports.Engine.ReportDocument
            Else
                myReportDocument = CType(Session("ReportDocument"), CrystalDecisions.CrystalReports.Engine.ReportDocument)
            End If

            lUser = CType(Session.Item("User"), User)
            If cmbProvider.Value.Equals("") Then
                lcondition = "Psb.VisitDisplayDate between '" & dpFrom.SelectedDate.ToString & "' And '" & dpTo.SelectedDate.ToString() & "'"
            Else
                lcondition = "Emp.EmployeeID = " & cmbProvider.Value & " and Psb.VisitDisplayDate between '" & dpFrom.SelectedDate.ToString & "' And '" & dpTo.SelectedDate.ToString() & "'"
            End If

            lDs = ClaimMethods.GetVisitByDate(lcondition, lUser)

            lDs.Tables(0).TableName = "VisitByDate"


            CrystalReportViewer1.DisplayGroupTree = False
            CrystalReportViewer1.HasCrystalLogo = False
            CrystalReportViewer1.HasToggleGroupTreeButton = False
            CrystalReportViewer1.HasZoomFactorList = False

            CrystalReportViewer1.Zoom(100)
            CrystalReportViewer1.BestFitPage = False
            CrystalReportViewer1.Width = New Unit("100%")
            CrystalReportViewer1.Height = New Unit("700")
            CrystalReportViewer1.HasSearchButton = False
            CrystalReportViewer1.HasViewList = False


            myReportDocument.Load(Server.MapPath("Reports\VisitByDate.rpt"))
            myReportDocument.SetDataSource(lDs.Tables(0))

            Session("ReportDocument") = myReportDocument
            CrystalReportViewer1.ReportSource = myReportDocument
            CrystalReportViewer1.DataBind()
        Catch ex As Exception
            RemoveReportDoc()
        End Try
    End Sub

    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload
        Try
            Dim myReportDocument As CrystalDecisions.CrystalReports.Engine.ReportDocument

            If Session("ReportDocument") IsNot Nothing Then
                myReportDocument = CType(Session("ReportDocument"), CrystalDecisions.CrystalReports.Engine.ReportDocument)
                myReportDocument.Close()
                myReportDocument.Dispose()
                Session.Remove("ReportDocument")
               
            End If
            CrystalReportViewer1.Dispose()
            CrystalReportViewer1 = Nothing

        Catch ex As Exception

        End Try
    End Sub
End Class
