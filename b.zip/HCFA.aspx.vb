Imports Telerik.WebControls
Imports PatientExtended

Partial Class Billing_HCFA
    Inherits System.Web.UI.Page
    'Dim mOriginalHCFAUpdated As HCFADBUpdated
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


        If (Not Page.IsPostBack) Then


            Me.cmbRefferingProviderIDQualifier.Attributes.Add("OnChange", "Combo_SelectedIndexChange(this)")
            Me.cmbCOB1.Attributes.Add("OnChange", "Combo_SelectedIndexChange(this)")
            Me.cmbCOB2.Attributes.Add("OnChange", "Combo_SelectedIndexChange(this)")
            Me.cmbCOB3.Attributes.Add("OnChange", "Combo_SelectedIndexChange(this)")
            Me.cmbCOB4.Attributes.Add("OnChange", "Combo_SelectedIndexChange(this)")
            Me.cmbCOB5.Attributes.Add("OnChange", "Combo_SelectedIndexChange(this)")
            Me.cmbCOB6.Attributes.Add("OnChange", "Combo_SelectedIndexChange(this)")
            Me.cmbFacilitySecondaryIdentificationQualifier.Attributes.Add("OnChange", "Combo_SelectedIndexChange(this)")
            Me.cmbClinicSecondaryIdentificationQualifier.Attributes.Add("OnChange", "Combo_SelectedIndexChange(this)")

            Dim queryString As NameValueCollection
            queryString = Encryption.DecryptQueryString(Request.QueryString.ToString())


            If (Not queryString("PSBID") Is Nothing) Then

                Me.txtPSBID.Text = queryString("PSBID").ToString.Split("|")(0)
                Me.txtPatientAccountNumber.Text = queryString("PSBID").ToString.Split("|")(1)
                Me.txtHCFAID.Text = queryString("PSBID").ToString.Split("|")(3)

                ''HardCoded fr the tym
                'Me.txtPSBID.Text = 318
                'Me.txtHCFAID.Text = 21


                If (Me.txtHCFAID.Text = "0" Or Me.txtHCFAID.Text = "") Then
                    Me.btnPrintHcfa.Enabled = False
                Else
                    Me.btnPrintHcfa.Enabled = True
                End If
                'PatientBanner1.SetBannerValues(txtPatientID.Text)

                LoadFormByHCFAUpdated()


             

            Else
                Response.Redirect("../Billing/ClaimSearch.aspx")
            End If

            ' rdpSendByOtherMeans.SelectedDate = Now.Date
            LoadHCFASendDate()
        End If

        Me.btnCancel.OnClientClick = "javascript:window.history.go(-1);return false;"


    End Sub



    Public Sub LoadFormByHCFAUpdated()

        Dim lUser As User
        lUser = CType(Session.Item("User"), User)

        Dim lHCFAUpdated As HCFADBUpdated
        '  Dim lPatientCPT As DataSet
        

        Dim lHcfaObj As New HCFAUpdated(lUser.ConnectionString)

        Dim queryString As NameValueCollection
        queryString = Encryption.DecryptQueryString(Request.QueryString.ToString())


        Dim lCPTCount As Integer = IIf(queryString("ClaimCount") IsNot Nothing, queryString("ClaimCount"), 0)
        lCPTCount = Math.Ceiling(lCPTCount / 6)

        'Load from Session

       
        '******** Running Code
        lHcfaObj.HCFAUpdated.HCFAID = txtHCFAID.Text
        lHcfaObj.GetRecordByID()
        lHCFAUpdated = lHcfaObj.HCFAUpdated
        Session("HCFADBUpdated") = lHCFAUpdated
        '******************
        ''********* Testing Code
        'If Session("HCFADBUpdated") IsNot Nothing Then
        '    lHCFAUpdated = CType(Session("HCFADBUpdated"), HCFADBUpdated)
        'End If
        ''********************


        ' lPatientCPT = HCFAMethods.GetCPTForHCFA(lUser.ConnectionString, txtPSBID.Text)


        With lHCFAUpdated
            txtPSBID.Text = .PatientSuperBillID
            txtHCFAID.Text = .HCFAID
            txtDisplayID.Text = .HCFADisplayID
            'Hv Used PAtAccNo Filed in the next step, instead of ClaimId
            ' Dim ClaimId As String = lUser.ClinicId & "H" & Convert.ToDateTime(.HCFAPreparedDate).ToString("yy") & Convert.ToDateTime(.HCFAPreparedDate).ToString("MM") & txtDisplayID.Text.PadLeft(5, "0")
            '*************
            txtInsuranceName.Text = .MainPatientInsurance.InsuranceCompanyName
            '************
            txtPatientID.Text = lHCFAUpdated.Patient.PatientID ' .PatientACNo
            '****
            Dim lType As String = IIf(.MainInsuranceCompany.InsuranceType <> "", .MainInsuranceCompany.InsuranceType.ToUpper, .OtherInsuranceCompany.InsuranceType.ToUpper)
            '****

            '''' Block 1 ''''''''''''''
            Select Case lType
                Case "MEDICARE"
                    Me.chkMedicare.Checked = True
                Case "MEDICAID"
                    Me.chkMedicaid.Checked = True
                Case "TRICARE"
                    Me.chkTricare.Checked = True
                Case "CHAMPVA"
                    Me.chkChampva.Checked = True
                Case "GROUP HEALTH PLAN"
                    Me.chkGroupHealth.Checked = True
                Case "FECA"
                    Me.chkFecaBuklung.Checked = True
                Case "OTHER"
                    Me.chkOther.Checked = True
            End Select

            Me.chkMedicare.Enabled = False
            Me.chkMedicaid.Enabled = False
            Me.chkTricare.Enabled = False
            Me.chkChampva.Enabled = False
            Me.chkGroupHealth.Enabled = False
            Me.chkFecaBuklung.Enabled = False
            Me.chkOther.Enabled = False
            '1a
            txtInsuredIDNumber.Text = .MainPatientInsurance.SubscriberID

            '''' Block 1 ''''''''''''''

            '''' Block 2 ''''''''''''''
            txtPatientName.Text = .Patient.LastName + ", " + .Patient.FirstName

            If .Patient.MiddleName <> "" Then
                txtPatientName.Text = txtPatientName.Text + ", " + .Patient.MiddleName
            End If
            '''' Block 2 ''''''''''''''

            '''' Block 3 ''''''''''''''
            If .Patient.DOB <> "" Then
                dtPatientDOB.SelectedDate = .Patient.DOB
            Else
                dtPatientDOB.SelectedDate = Nothing
            End If

            If (.Patient.Gender.ToUpper = "F") Then
                Me.rdoPatientGenderFemale.Checked = True
            Else
                Me.rdoPatientGenderMale.Checked = True
            End If
            '''' Block 3 ''''''''''''''



            '''' Block 4 ''''''''''''''
            txtInsuredName.Text = .InsurerPatient.LastName + ", " + .InsurerPatient.FirstName

            If .InsurerPatient.MiddleName <> "" Then
                txtInsuredName.Text = txtInsuredName.Text + ", " + .InsurerPatient.MiddleName
            End If
            '''' Block 4 ''''''''''''''



            '''' Block 5 ''''''''''''''
            txtPatientAddress.Text = .Patient.AddressLine1 + " " + .Patient.AddressLine2

            txtPatientCity.Text = .Patient.City
            txtPatientZipCode.Text = .Patient.ZipCode
            txtPatientState.Text = .Patient.StateID
            txtPatientTelephone.Text = IIf(.Patient.HomePhone <> "", .Patient.HomePhone, .Patient.WorkPhone)
            '''' Block 5 ''''''''''''''


            '''' Block 6 ''''''''''''''
            If (.MainPatientInsurance.RelationshipToPrimaryInsurer = "Spouse") Then
                Me.rdoPatientRelationshipToInsuredSpouse.Checked = True
            ElseIf (.MainPatientInsurance.RelationshipToPrimaryInsurer = "Child") Then
                Me.rdoPatientRelationshipToInsuredChild.Checked = True
            ElseIf (.MainPatientInsurance.RelationshipToPrimaryInsurer = "Other") Then
                Me.rdoPatientRelationshipToInsuredOther.Checked = True
            Else
                Me.rdoPatientRelationshipToInsuredSelf.Checked = True
            End If
            '''' Block 6 ''''''''''''''


            '''' Block 7 ''''''''''''''
            txtInsuredAddress.Text = .InsurerPatient.AddressLine1 + " " + .InsurerPatient.AddressLine2
            txtInsuredCity.Text = .InsurerPatient.City
            txtInsuredState.Text = .InsurerPatient.StateID
            txtInsuredZipCode.Text = .InsurerPatient.ZipCode
            txtInsuredTelephone.Text = IIf(.InsurerPatient.HomePhone <> "", .Patient.HomePhone, .Patient.WorkPhone)

            '''' Block 7 ''''''''''''''

            '''' Block 8 ''''''''''''''
            If (.Patient.MartialStatus.ToUpper = "MARRIED") Then
                Me.rdoPatientMaritalStatusMarried.Checked = True
            ElseIf (.Patient.MartialStatus.ToUpper = "SINGLE") Then
                Me.rdoPatientMaritalStatusSingle.Checked = True
            Else
                Me.rdoPatientMaritalStatusOther.Checked = True
            End If



            If .Patient.EmploymentStatus.ToUpper = "EMPLOYEED" Then
                chkPatientEmploymentInfoEmployed.Checked = True
            ElseIf .Patient.EmploymentStatus.ToUpper = "FULL TIME STUDENT" Then
                chkPatientEmploymentInfoFullTimeStudent.Checked = True
            ElseIf .Patient.EmploymentStatus.ToUpper = "PART TIME STUDENT" Then
                chkPatientEmploymentInfoPartTimeStudent.Checked = True
            End If
            '''' Block 8 ''''''''''''''


            '''' Block 9 ''''''''''''''

            If .OtherInsurerPatient.FirstName <> "" Then



                Me.txtOtherInsuredEmployerName.Text = .OtherInsurerPatient.EmployerName
                Me.txtOtherInsuredPolicy.Text = .OtherPatientInsurance.GroupNo
                Me.txtSecondaryInsurancePlan.Text = .OtherPatientInsurance.PlanName


                Me.txtOtherInsuredName.Text = .OtherInsurerPatient.LastName + ", " + .OtherInsurerPatient.FirstName
                If .OtherInsurerPatient.MiddleName <> "" Then
                    txtOtherInsuredName.Text = txtOtherInsuredName.Text + ", " + .OtherInsurerPatient.MiddleName
                End If

                If (.OtherInsurerPatient.Gender.ToUpper.StartsWith("F")) Then
                    Me.rdoOtherInsuredGenderFemale.Checked = True
                ElseIf (.InsurerPatient.Gender.ToUpper.StartsWith("M")) Then
                    Me.rdoOtherInsuredGenderMale.Checked = True
                End If


                If .OtherInsurerPatient.DOB.Equals("") Then
                    Me.dtOtherInsuredDOB.SelectedDate = Nothing
                Else

                    Me.dtOtherInsuredDOB.DbSelectedDate = .OtherInsurerPatient.DOB
                End If


            End If


            '''' Block 9 ''''''''''''''

            '''' Block 10 ''''''''''''''
            If (.PatientConditionEmployment.ToUpper = "Y") Then
                Me.rdoIsEmploymentRelatedYes.Checked = True
                Me.rdoIsEmploymentRelatedNo.Checked = False

            Else
                Me.rdoIsEmploymentRelatedNo.Checked = True
                Me.rdoIsEmploymentRelatedYes.Checked = False
            End If

            Me.txtPLACEState.Text = .PatientConditionAutoAccPlace
            If (.PatientConditionAutoAccident.ToUpper = "Y") Then
                Me.rdoIsAutoAccidentRelatedYes.Checked = True
                Me.rdoIsAutoAccidentRelatedNo.Checked = False
            Else
                Me.rdoIsAutoAccidentRelatedNo.Checked = True
                Me.rdoIsAutoAccidentRelatedYes.Checked = False
            End If

            If (.PatientConditionOtherAccident.ToUpper = "Y") Then
                Me.rdoIsOtherAccidentRelatedYes.Checked = True
                Me.rdoIsOtherAccidentRelatedNo.Checked = False
            Else
                Me.rdoIsOtherAccidentRelatedNo.Checked = True
                Me.rdoIsOtherAccidentRelatedYes.Checked = False
            End If



            Me.txtReserverBlock10D.Text = ""
            '''' Block 10 ''''''''''''''


            '''' Block 11 ''''''''''''''

            Me.txtAnotherInsuredEmployerName.Text = .InsurerPatient.EmployerName
            Me.txtAnotherInsuredPolicy.Text = .MainPatientInsurance.GroupNo
            Me.txtAnotherInsuredPlan.Text = .MainPatientInsurance.PlanName

            Me.txtInsuredName.Text = .InsurerPatient.LastName + ", " + .InsurerPatient.FirstName
            If .InsurerPatient.MiddleName <> "" Then
                txtInsuredName.Text = txtInsuredName.Text + ", " + .InsurerPatient.MiddleName
            End If
            Me.txtInsuredCity.Text = .InsurerPatient.City
            Me.txtInsuredZipCode.Text = .InsurerPatient.ZipCode
            Me.txtInsuredTelephone.Text = .InsurerPatient.HomePhone
            Me.txtInsuredState.Text = .InsurerPatient.StateID



            If .InsurerPatient.FirstName <> "" Then



                '*** Loading wdOut Insurance type check
                If .InsurerPatient.DOB.Equals("") Then
                    Me.dtInsuredDOB.SelectedDate = Nothing
                Else
                    Me.dtInsuredDOB.SelectedDate = .InsurerPatient.DOB
                End If


                '***





                '*** Loading wd Insurance type check
                'If .InsurerPatient.DOB.Equals("") Then
                '    Me.dtInsuredDOB.SelectedDate = Nothing

                'ElseIf .MainPatientInsurance.RelationshipToPrimaryInsurer.ToUpper = "SELF" Then
                '    dtInsuredDOB.SelectedDate = CType(.Patient.DOB, Date)
                'Else
                '    dtInsuredDOB.SelectedDate = CType(.InsurerPatient.DOB, Date)
                'End If

                'If .OtherInsurerPatient.DOB.Equals("") Then
                '    Me.dtOtherInsuredDOB.SelectedDate = Nothing

                'ElseIf .OtherPatientInsurance.RelationshipToPrimaryInsurer.ToUpper = "SELF" Then
                '    dtOtherInsuredDOB.SelectedDate = CType(.InsurerPatient.DOB, Date)
                'Else
                '    dtOtherInsuredDOB.SelectedDate = CType(.OtherInsurerPatient.DOB, Date)
                'End If
                '***


                If (.InsurerPatient.Gender.ToUpper.StartsWith("F")) Then
                    Me.rdoAnotherInsuredGenderFemale.Checked = True
                ElseIf (.InsurerPatient.Gender.ToUpper.StartsWith("M")) Then
                    Me.rdoAnotherInsuredGenderMale.Checked = True
                End If

                If .OtherInsurerPatient.Gender = "F" Then

                    Me.rdoOtherInsuredGenderFemale.Checked = True

                ElseIf .OtherInsurerPatient.Gender = "M" Then
                    Me.rdoOtherInsuredGenderMale.Checked = True

                End If


                If .OtherPatientInsurance.SubscriberID <> "0" Then
                    Me.rdoIsAnotherHealthPlanYes.Checked = True
                Else
                    Me.rdoIsAnotherHealthPlanNo.Checked = True
                End If

            End If
            '''' Block 11 ''''''''''''''



            '''' Block 12 ''''''''''''''
            lblSignatureOnFile.Text = .SignOnFile
            dtReleaseInfoDate.DbSelectedDate = .SignDate
            lblPaymentSignature.Text = .AuthorizedPersonSign
            '''' Block 12 ''''''''''''''



            '''' Block 13 ''''''''''''''
            If .SignDate.Equals("") Then
                Me.lblSignatureOnFile.Text = ""
                dtReleaseInfoDate.SelectedDate = Nothing
                lblPaymentSignature.Text = ""
            Else
                dtReleaseInfoDate.SelectedDate = CType(.SignDate, Date)
                Me.lblSignatureOnFile.Text = .SignOnFile
                lblPaymentSignature.Text = .AuthorizedPersonSign
            End If
            '''' Block 13 '''''''''''''



            '''' Block 14 '''''''''''''
            If .DateOfOccurance.Equals("") Then
                dtDateOfOccurance.SelectedDate = Nothing
            Else
                dtDateOfOccurance.SelectedDate = CType(.DateOfOccurance, Date)
            End If
            '''' Block 14 '''''''''''''


            '''' Block 15 '''''''''''''
            If .PreviousOccuranceDate.Equals("") Then
                dtPreviousOccuranceDate.SelectedDate = Nothing
            Else
                dtPreviousOccuranceDate.SelectedDate = CType(.PreviousOccuranceDate, Date)
            End If
            '''' Block 15 '''''''''''''


            '''' Block 16 '''''''''''''
            If .PatUnableToWorkFrom.Equals("") Then
                dtUnableToWorkFrom.SelectedDate = Nothing
            Else
                dtUnableToWorkFrom.SelectedDate = CType(.PatUnableToWorkFrom, Date)
            End If

            If .PatUnableToWorkTo.Equals("") Then
                dtUnableToWorkTo.SelectedDate = Nothing
            Else
                dtUnableToWorkTo.SelectedDate = CType(.PatUnableToWorkTo, Date)
            End If
            '''' Block 16 '''''''''''''


            '''' Block 17 '''''''''''''
            txtRefferingProviderName.Text = .ReferencePvd.LastName
            If .ReferencePvd.FirstName <> "" Then
                txtRefferingProviderName.Text = txtRefferingProviderName.Text + ", " + .ReferencePvd.FirstName
            End If
            If .ReferencePvd.MiddleName <> "" Then
                txtRefferingProviderName.Text = txtRefferingProviderName.Text + ", " + .ReferencePvd.MiddleName
            End If



            'If .RenderingProvider.MiddleName <> "" Then
            '    txtRefferingProviderName.Text = txtRefferingProviderName.Text + ", " + .ReferencePvd.MiddleName
            'End If
            txtRefferingProviderNPI.Text = .ReferencePvd.NPI
            '*****
            txtRefferingProvider.Text = .ReferencePvd.ProviderID
            '''' Block 17 '''''''''''''


            '''' Block 18 '''''''''''''
            If .HospitalizationDateFrom.Equals("") Then
                dtHospitalizationDateFrom.SelectedDate = Nothing
            Else
                dtHospitalizationDateFrom.SelectedDate = CType(.HospitalizationDateFrom, Date)
            End If

            If .HospitalizationDateTo.Equals("") Then
                dtHospitalizationDateTo.SelectedDate = Nothing
            Else
                dtHospitalizationDateTo.SelectedDate = CType(.HospitalizationDateTo, Date)
            End If
            '''' Block 18 '''''''''''''


            '''' Block 19 '''''''''''''
            txtReservedField19.Text = .Field19
            '''' Block 19 '''''''''''''


            '''' Block 20 '''''''''''''
            If .IsOutsideLab.ToUpper = "Y" Then
                Me.rdoIsOutsideLabYes.Checked = True
            ElseIf .IsOutsideLab.ToUpper = "N" Then
                Me.rdoIsOutsideLabNo.Checked = True
            End If

            txtOutsideLabCharges1.Text = .OutsideLabCharges
            '''' Block 20 '''''''''''''


            '''' Block 21 '''''''''''''
            txtICD1.Text = .ICD1
            txtICD2.Text = .ICD2
            txtICD3.Text = .ICD3
            txtICD4.Text = .ICD4
            '''' Block 21 '''''''''''''


            '''' Block 22 '''''''''''''
            txtMedicaidCode.Text = .MedicadReSubCode
            txtOriginalRefrenceNumber.Text = .MedicadReSubNo
            '''' Block 22 '''''''''''''



            '''' Block 23 '''''''''''''
            txtPriorAuthorizationNumber.Text = .MainPatientInsurance.AuthorizationNumber
            '''' Block 23 '''''''''''''


            '''' Block 25 '''''''''''''
            txtFederalTaxID.Text = .FederalTaxNo
            Me.rdoIsSSNNo.Checked = True
            '''' Block 25 '''''''''''''


            '''' Block 26 '''''''''''''
            txtPatientAccountNumber.Text = .PatientACNo
            '''' Block 26 '''''''''''''


            '''' Block 27 '''''''''''''
            If (.AcceptAssignment.ToUpper = "Y") Then
                Me.rdoIsAcceptAssignmentYes.Checked = True
            Else
                Me.rdoIsAcceptAssignmentNo.Checked = True
            End If
            '''' Block 27 '''''''''''''


            '''' Block 28 '''''''''''''
            txtTotalCharges1.Text = .TotalCharges
            '''' Block 28 '''''''''''''


            '''' Block 29 '''''''''''''
            txtAmountPaid1.Text = .AmountPaid
            '''' Block 29 '''''''''''''

            '''' Block 30 '''''''''''''
            txtBalanceDue1.Text = .BalanceDue
            '''' Block 30 '''''''''''''


            '''' Block 31 '''''''''''''
            txtProviderName.Text = .RenderingProvider.LastName + ", " + .RenderingProvider.FirstName
            If .RenderingProvider.MiddleName <> "" Then
                txtProviderName.Text = txtProviderName.Text + ", " + .RenderingProvider.MiddleName
            End If

            If .RenderingProvider.Degree <> "" Then
                txtProviderName.Text = txtProviderName.Text + " " + .RenderingProvider.Degree
            End If

            If .HCFAPreparedDate.Equals("") Then
                dtHCFAPreparedDate.DbSelectedDate = Nothing
            Else
                dtHCFAPreparedDate.DbSelectedDate = CType(.HCFAPreparedDate, Date)
            End If
            '''' Block 31 '''''''''''''



            '''' Block 32 '''''''''''''
            If (.ServiceFacility.FacilityID = "0") Then
                Me.txtFacilityInfoType.Text = "C"
                txtFacilityReturnInfo.Text = ""
            Else
                Me.txtFacilityInfoType.Text = "F"
                Me.txtFacilityReturnInfo.Text = .ServiceFacility.FacilityID & "|" & .ServiceFacility.FacilityName & "|" & .ServiceFacility.AddressLine1 + " " + .ServiceFacility.AddressLine2 & "|" & .ServiceFacility.City & "|" & .ServiceFacility.State & "|" & .ServiceFacility.ZipCode
            End If

            Me.txtFacilityInfo.Text = .ServiceFacility.FacilityName & vbCrLf & .ServiceFacility.AddressLine1 + " " + .ServiceFacility.AddressLine2 & vbCrLf & .ServiceFacility.City & " " & .ServiceFacility.State & " " & .ServiceFacility.ZipCode
            Me.txtFacilityCity.Text = .ServiceFacility.City
            Me.txtFacilityState.Text = .ServiceFacility.State
            Me.txtFacilityZipCode.Text = .ServiceFacility.ZipCode

            Me.txtFascilityNPI.Text = .ServiceFacility.NPI
            Me.cmbFacilitySecondaryIdentificationQualifier.SelectedValue = .ServFacSecIdQualifier
            Me.txtFacilityCode.Text = .ServFacSecIdValue

            '''' Block 32 '''''''''''''


            '''' Block 33 '''''''''''''


            Me.TextBox1.Text = IIf(.BillingPvd.Phone1 <> "", .BillingPvd.Phone1, .BillingPvd.Phone2)
            Me.txtClinicInfo.Text = vbCrLf & .BillingPvd.LastName & " " & .BillingPvd.FirstName & " " & .BillingPvd.MiddleName
            Me.txtClinicInfo.Text = Me.txtClinicInfo.Text & " " & .BillingPvd.AddressLine1 & " " & .BillingPvd.AddressLine2 & " " & .BillingPvd.City
            Me.txtClinicInfo.Text = Me.txtClinicInfo.Text & " " & .BillingPvd.State
            Me.txtClinicInfo.Text = Me.txtClinicInfo.Text & " " & .BillingPvd.ZipCode


            Me.txtPrescriberNPI.Text = .BillingPvd.NPI
            Me.cmbClinicSecondaryIdentificationQualifier.SelectedValue = .BPvdSecIdQualifier
            Me.txtPrescriberGroupNumber.Text = .BPvdSecIdValue
            '''' Block 33 '''''''''''''


            'If (.RefferingProviderIDQualifier <> "") Then
            '    Utility.SelectComboItem(Me.cmbRefferingProviderIDQualifier, .RefferingProviderIDQualifier, False)
            'End If



            ' Me.cmbFacilitySecondaryIdentificationQualifier.SelectedValue = .ServiceFacility.


            '****

            ' Me.cmbClinicSecondaryIdentificationQualifier.SelectedValue = .ClinicSecondaryIdentificationQualifier.ToString

            ' txtDoctorUserID.Text = .
            txtCreateByUserID.Text = .CreateByUserID
            '****
            Me.lblInsuranceName.Text = .MainInsuranceCompany.CompanyName
            Me.lblInsuranceAddress1.Text = .MainInsuranceCompany.AddressLine1
            ' Me.lblPrescriberSignature.Text = .ReferencePvd.LastName + ", " + .ReferencePvd.FirstName



            Me.lblInsuranceAddress1.Text = .MainInsuranceCompany.CompanyName
            Me.lblInsuranceAddress2.Text = .MainInsuranceCompany.AddressLine2
            Me.lblInsuranceCity.Text = .MainInsuranceCompany.City
            Me.lblInsuranceState.Text = .MainInsuranceCompany.State
            Me.lblInsuranceZipCode.Text = .MainInsuranceCompany.ZipCode

            Me.txtReserverBlock10D.Text = .ReservedField10d
            Me.txtReservedField19.Text = .Field19




        End With

        LoadCptFromHcfaDtlCol()


    End Sub


    'Public Function GetHCFAHdr() As HCFADB
    '    Dim lHCFADB As New HCFADB
    '    Dim lUser As User

    '    lUser = CType(Session("User"), User)

    '    With lHCFADB
    '        .PatientSuperBillID = Me.txtPSBID.Text
    '        .HCFAID = Me.txtHCFAID.Text
    '        .HCFADisplayID = Me.txtDisplayID.Text

    '        If (Me.chkMedicare.Checked) Then
    '            .Type1 = "MEDICARE"
    '        End If
    '        If (Me.chkMedicaid.Checked And .Type1 = "") Then
    '            .Type1 = "MEDICAID"
    '        End If
    '        If (Me.chkTricare.Checked And .Type1 = "") Then
    '            .Type1 = "TRICARE"
    '        End If
    '        If (Me.chkChampva.Checked And .Type1 = "") Then
    '            .Type1 = "CHAMPVA"
    '        End If
    '        If (Me.chkGroupHealth.Checked And .Type1 = "") Then
    '            .Type1 = "GROUP HEALTH PLAN"
    '        End If
    '        If (Me.chkFecaBuklung.Checked And .Type1 = "") Then
    '            .Type1 = "FECA"
    '        End If
    '        If (Me.chkOther.Checked And .Type1 = "") Then
    '            .Type1 = "OTHER"
    '        End If

    '        If (Me.chkMedicare.Checked And .Type1 <> "MEDICARE" And .Type2 = "") Then
    '            .Type2 = "MEDICARE"
    '        End If
    '        If (Me.chkMedicaid.Checked And .Type1 <> "MEDICAID" And .Type2 = "") Then
    '            .Type2 = "MEDICAID"
    '        End If
    '        If (Me.chkTricare.Checked And .Type1 <> "TRICARE" And .Type2 = "") Then
    '            .Type2 = "TRICARE"
    '        End If
    '        If (Me.chkChampva.Checked And .Type1 <> "CHAMPVA" And .Type2 = "") Then
    '            .Type2 = "CHAMPVA"
    '        End If
    '        If (Me.chkGroupHealth.Checked And .Type1 <> "GROUP" And .Type2 = "") Then
    '            .Type2 = "GROUP HEALTH PLAN"
    '        End If
    '        If (Me.chkFecaBuklung.Checked And .Type1 <> "FECA" And .Type2 = "") Then
    '            .Type2 = "FECA"
    '        End If
    '        If (Me.chkOther.Checked And .Type1 <> "OTHER" And .Type2 = "") Then
    '            .Type2 = "OTHER"
    '        End If



    '        .ReleaseInfoSignature = lblSignatureOnFile.Text
    '        .PaymentSignature = Me.lblPaymentSignature.Text
    '        .Patient.InsuranceID = txtInsuredIDNumber.Text
    '        '.GroupNumber = txtGroupNumber.Text
    '        .PatientName = txtPatientName.Text
    '        .PatientDOB = dtPatientDOB.SelectedDate.GetValueOrDefault
    '        .PatientGender = IIf(rdoPatientGenderFemale.Checked, "F", "M")
    '        .InsuredName = txtInsuredName.Text
    '        .PatientAddress = txtPatientAddress.Text
    '        .PatientCity = txtPatientCity.Text
    '        .PatientZipCode = txtPatientZipCode.Text
    '        .PatientState = txtPatientState.Text
    '        .PatientTelephone = txtPatientTelephone.Text

    '        If rdoPatientRelationshipToInsuredSelf.Checked Then
    '            .PatientRelationshipToInsured = "Self"
    '        ElseIf rdoPatientRelationshipToInsuredChild.Checked Then
    '            .PatientRelationshipToInsured = "Child"
    '        ElseIf rdoPatientRelationshipToInsuredSpouse.Checked Then
    '            .PatientRelationshipToInsured = "Spouse"
    '        Else 'If Other 
    '            .PatientRelationshipToInsured = "Other"
    '        End If

    '        .InsuredAddress = txtInsuredAddress.Text
    '        .InsuredCity = txtInsuredCity.Text
    '        .InsuredState = txtInsuredState.Text
    '        .InsuredZipCode = txtInsuredZipCode.Text
    '        .InsuredTelephone = txtInsuredTelephone.Text

    '        If rdoPatientMaritalStatusMarried.Checked Then
    '            .PatientMaritalStatus = "Married"
    '        ElseIf rdoPatientMaritalStatusSingle.Checked Then
    '            .PatientMaritalStatus = "Single"
    '        Else 'If Other 
    '            .PatientMaritalStatus = "Other"
    '        End If

    '        If chkPatientEmploymentInfoEmployed.Checked Then
    '            .PatientEmploymentInfo = "Employeed"
    '        ElseIf chkPatientEmploymentInfoFullTimeStudent.Checked Then
    '            .PatientEmploymentInfo = "Full Time Student"
    '        ElseIf chkPatientEmploymentInfoPartTimeStudent.Checked Then
    '            .PatientEmploymentInfo = "Part Time Student"
    '        Else
    '            .PatientEmploymentInfo = "Other"
    '        End If


    '        .OtherInsuredName = txtOtherInsuredName.Text
    '        .OtherInsuredPolicy = txtOtherInsuredPolicy.Text
    '        .OtherInsuredDOB = dtOtherInsuredDOB.DbSelectedDate
    '        .OtherInsuredGender = IIf(rdoOtherInsuredGenderFemale.Checked, "F", "M")
    '        .OtherInsuredEmployer = txtOtherInsuredEmployerName.Text
    '        .SecondaryInsurancePlan = txtSecondaryInsurancePlan.Text
    '        .IsEmploymentRelated = IIf(rdoIsEmploymentRelatedYes.Checked, "Y", "N")
    '        .IsAutoAccidentRelated = IIf(rdoIsAutoAccidentRelatedYes.Checked, "Y", "N")
    '        .IsOtherAccidentRelated = IIf(rdoIsOtherAccidentRelatedYes.Checked, "Y", "N")
    '        .ReservedBlock10D = txtReserverBlock10D.Text
    '        .AnotherInsuredPolicy = txtAnotherInsuredPolicy.Text
    '        .AnotherInsuredDOB = dtInsuredDOB.DbSelectedDate
    '        .AnotherInsuredGender = IIf(rdoAnotherInsuredGenderFemale.Checked, "F", "M")
    '        .AnotherInsuredEmployerName = txtAnotherInsuredEmployerName.Text
    '        .AnotherInsuredInsurancePlan = txtAnotherInsuredPlan.Text
    '        .IsAnotherPlan = IIf(rdoIsAnotherHealthPlanYes.Checked, "Y", "N")
    '        .ReleaseInfoSignature = lblSignatureOnFile.Text
    '        .ReleaseInfoDate = dtReleaseInfoDate.DbSelectedDate
    '        .PaymentSignature = lblPaymentSignature.Text
    '        .DateOfOccurance = dtDateOfOccurance.DbSelectedDate
    '        .PreviousOccuranceDate = dtPreviousOccuranceDate.DbSelectedDate
    '        .UnableToWorkFrom = dtUnableToWorkFrom.DbSelectedDate
    '        .UnableToWorkTo = dtUnableToWorkTo.DbSelectedDate
    '        .RefferingProviderName = txtRefferingProviderName.Text
    '        .RefferingProviderID = txtRefferingProvider.Text 'Field To Be loaded
    '        If (Me.txtRefferingProviderID.Text <> "") Then
    '            '.RefferingProviderID = Me.txtRefferingProviderID.Text  'Field To Be loaded
    '            .RefferingProviderIDQualifier = Me.cmbRefferingProviderIDQualifier.SelectedItem.Text
    '        End If
    '        .RefferingProviderNPI = txtRefferingProviderNPI.Text
    '        .HospitalizationDateFrom = dtHospitalizationDateFrom.DbSelectedDate
    '        .HospitalizationDateTo = dtHospitalizationDateTo.DbSelectedDate
    '        .ReservedBlock19 = txtReservedField19.Text 'Field to be added in Database
    '        .IsOutsideLab = IIf(rdoIsOutsideLabYes.Checked, "Y", "N")
    '        Try
    '            .OutsideLabCharges = CType(txtOutsideLabCharges1.Text, Double)
    '        Catch ex As Exception
    '            .OutsideLabCharges = 0.0
    '        End Try

    '        .ICD1 = txtICD1.Text
    '        .ICD2 = txtICD2.Text
    '        .ICD3 = txtICD3.Text
    '        .ICD4 = txtICD4.Text
    '        .MedicaidCode = txtMedicaidCode.Text
    '        .OriginalRefrenceNumber = txtOriginalRefrenceNumber.Text
    '        .PriorAuthorizationNumber = txtPriorAuthorizationNumber.Text
    '        .FederalTaxID = txtFederalTaxID.Text
    '        .IsSSN = IIf(rdoIsSSNYes.Checked, "Y", "N")
    '        .PatientAccountNumber = Me.txtPatientID.Text  'txtPatientAccountNumber.Text
    '        .IsAcceptAssignment = IIf(rdoIsAcceptAssignmentYes.Checked, "Y", "N")

    '        Try
    '            .TotalCharge = CType(txtTotalCharges1.Text, Double)
    '        Catch ex As Exception
    '            .TotalCharge = 0.0
    '        End Try

    '        Try
    '            .AmountPaid = CType(txtAmountPaid1.Text, Double)
    '        Catch ex As Exception
    '            .AmountPaid = 0.0
    '        End Try

    '        Try
    '            .BalanceDue = CType(txtBalanceDue1.Text, Double)
    '            If (.BalanceDue = 0.0) Then
    '                .BalanceDue = .TotalCharge - .AmountPaid
    '            End If
    '        Catch ex As Exception
    '            .BalanceDue = 0.0
    '        End Try

    '        .ProviderName = txtProviderName.Text
    '        .HCFAPreparedDate = dtHCFAPreparedDate.DbSelectedDate

    '        '''''''''''Facilty''''''''''''''''''''''''''''''
    '        If (Me.txtFacilityInfoType.Text = "C") Then
    '            Dim lClinic As New Clinic(lUser.ConnectionString)
    '            Dim lState As New State(lUser.ConnectionString)
    '            lClinic.Clinic.ClinicId = lUser.ClinicId
    '            If (lClinic.GetRecordByID()) Then
    '                lState.State.StateID = lClinic.Clinic.StateId
    '                lState.GetRecordByID()
    '                .FacilityId = 0
    '                .FacilityName = lClinic.Clinic.ClinicName
    '                .FacilityAddress = lClinic.Clinic.AddressLine1 & " " & lClinic.Clinic.AddressLine2 & " " & lClinic.Clinic.City & " " & lState.State.Abbr & " " & lClinic.Clinic.ZipCode
    '                .FacilityProvider = txtFascilityNPI.Text
    '                .FacilityCode = txtFacilityCode.Text ' Field To be Added in DB & Class 
    '            End If
    '        Else
    '            .FacilityId = Me.txtFacilityReturnInfo.Text.Split("|")(0)
    '            .FacilityName = Me.txtFacilityReturnInfo.Text.Split("|")(1)
    '            .FacilityAddress = Me.txtFacilityReturnInfo.Text.Split("|")(2)
    '            .FacilityCity = Me.txtFacilityCity.Text
    '            .FacilityState = Me.txtFacilityState.Text
    '            .FacilityZipCode = Me.txtFacilityZipCode.Text
    '            .FacilityProvider = txtFascilityNPI.Text
    '            .FacilityCode = txtFacilityCode.Text ' Field To be Added in DB & Class 
    '        End If
    '        .FacilitySecondaryIdentificationQualifier = Me.cmbFacilitySecondaryIdentificationQualifier.SelectedItem.Text
    '        '''''''''''Facilty''''''''''''''''''''''''''''''


    '        '''''''''''''''' Doctor/Billing Provider Personal Info '''''''''''''
    '        Dim lBillingProvider As New BillingProvider(lUser.ConnectionString)
    '        'lEmployee.Employee.EmployeeID = lUser.UserId
    '        'Dim lState As New State(lUser.ConnectionString)
    '        If (lBillingProvider.GetRecordByID()) Then
    '            .ClinicName = Convert.ToString(lBillingProvider.BillingProvider.LastName & " " & lBillingProvider.BillingProvider.FirstName & " " & lBillingProvider.BillingProvider.MiddleName).Trim
    '            .ClinicAddress = lBillingProvider.BillingProvider.AddressLine1 & " " & lBillingProvider.BillingProvider.AddressLine2
    '            .ClinicCity = lBillingProvider.BillingProvider.City
    '            .ClinicState = lBillingProvider.BillingProvider.State
    '            .ClinicZip = lBillingProvider.BillingProvider.ZipCode
    '            .ClinicPhoneNumber = lBillingProvider.BillingProvider.Phone1
    '        End If

    '        .ClinicGroupNumber = txtPrescriberGroupNumber.Text
    '        .ClinicPinNumber = txtPrescriberNPI.Text
    '        .ClinicSecondaryIdentificationQualifier = Me.cmbClinicSecondaryIdentificationQualifier.SelectedItem.Text
    '        If (Me.txtHCFAID.Text = "0") Then
    '            .DoctorUserID = lUser.UserId
    '            .CreateByUserID = lUser.UserId
    '        Else
    '            .DoctorUserID = Me.txtDoctorUserID.Text
    '            .CreateByUserID = Me.txtCreateByUserID.Text
    '        End If

    '        .InsuranceNameHdr = Me.lblInsuranceName.Text
    '        .InsuranceAddressHdr = Convert.ToString(Me.lblInsuranceCity.Text & " " & Me.lblInsuranceState.Text & " " & Me.lblInsuranceZipCode.Text).Trim
    '        .InsuranceAddressLine1 = Me.lblInsuranceAddress1.Text
    '        .InsuranceAddressLine2 = Me.lblInsuranceAddress2.Text

    '        'Refferring Provider Secondary Identification




    '    End With

    '    Return lHCFADB

    'End Function


    'Public Function GetHCFADtl() As PatientCPTColl

    '    Dim lPatientCPTDB As PatientCPTDB
    '    Dim lPatientCPTCol As New PatientCPTColl
    '    Dim lTextBox As TextBox
    '    Dim lCombo As DropDownList
    '    Dim lDatePicker As RadDatePicker

    '    Dim lCounter As Integer = 1


    '    lCounter = 1
    '    For lCounter = 1 To 6
    '        lTextBox = CType(pnlAjaxHCFA.FindControl("txtCPTCode" & lCounter), TextBox)

    '        If (lTextBox.Text <> "") Then
    '            lPatientCPTDB = New PatientCPTDB()

    '            With lPatientCPTDB
    '                .HCFAID = Me.txtHCFAID.Text
    '                .Code = lTextBox.Text
    '                .LineId = lCounter

    '                lDatePicker = CType(pnlAjaxHCFA.FindControl("dtDateOfServiceFrom" & lCounter), RadDatePicker)
    '                .DateOfServiceFrom = lDatePicker.DbSelectedDate

    '                lDatePicker = CType(pnlAjaxHCFA.FindControl("dtDateOfServiceTo" & lCounter), RadDatePicker)
    '                .DateOfServiceTo = lDatePicker.DbSelectedDate

    '                lTextBox = CType(pnlAjaxHCFA.FindControl("txtPlaceOfService" & lCounter), TextBox)
    '                .POS = lTextBox.Text

    '                'lTextBox = CType(pnlAjaxHCFA.FindControl("txtEmergency" & lCounter), TextBox)
    '                '.= lTextBox.Text


    '                lTextBox = CType(pnlAjaxHCFA.FindControl("txtModifierA" & lCounter), TextBox)
    '                .ModifierA = lTextBox.Text

    '                lTextBox = CType(pnlAjaxHCFA.FindControl("txtModifierB" & lCounter), TextBox)
    '                .ModifierB = lTextBox.Text

    '                lTextBox = CType(pnlAjaxHCFA.FindControl("txtModifierC" & lCounter), TextBox)
    '                .ModifierC = lTextBox.Text

    '                lTextBox = CType(pnlAjaxHCFA.FindControl("txtModifierD" & lCounter), TextBox)
    '                .ModifierD = lTextBox.Text

    '                lTextBox = CType(pnlAjaxHCFA.FindControl("txtDignosisPointer" & lCounter), TextBox)
    '                .Pointer = lTextBox.Text


    '                lTextBox = CType(pnlAjaxHCFA.FindControl("txtChargesWhole" & lCounter), TextBox)
    '                Try
    '                    .Charges = CType(lTextBox.Text, Double)
    '                Catch ex As Exception
    '                    .Charges = 0.0
    '                End Try


    '                lTextBox = CType(pnlAjaxHCFA.FindControl("txtDays" & lCounter), TextBox)
    '                .Days = lTextBox.Text

    '                lTextBox = CType(pnlAjaxHCFA.FindControl("txtEPSDT" & lCounter), TextBox)
    '                .EPSDT = lTextBox.Text

    '                lTextBox = CType(pnlAjaxHCFA.FindControl("txtEmergency" & lCounter), TextBox)
    '                .EMG = lTextBox.Text

    '                lCombo = CType(pnlAjaxHCFA.FindControl("cmbCOB1"), DropDownList)
    '                .COB = lCombo.SelectedItem.Value

    '                lTextBox = CType(pnlAjaxHCFA.FindControl("txtNPI" & lCounter), TextBox)
    '                .NPI = lTextBox.Text

    '                lTextBox = CType(pnlAjaxHCFA.FindControl("txtPrescriberLicenseID1"), TextBox)
    '                .PrescriberLicenceID = lTextBox.Text 'Field To Be added In DB & Classes

    '            End With

    '            lPatientCPTCol.Add(lPatientCPTDB)
    '        End If

    '    Next

    '    Return lPatientCPTCol

    'End Function
    'Public Sub InsertHCFA(ByVal pShowAlerts As Boolean)
    '    Dim lResult As String = ""
    '    Dim lFilePath As String = ""

    '    Dim lUser As User
    '    lUser = CType(Session("User"), User)

    '    Dim lHCFADB As HCFADB = GetHCFAHdr()

    '    Dim lPatientCPTCol As PatientCPTColl = GetHCFADtl()
    '    Dim lHCFA As New HCFA(lUser.ConnectionString)



    '    ' **************** Commented to stop hcfa updation****************
    '    lResult = HCFAMethods.InsertEditedHCFA(lUser, lHCFADB, lPatientCPTCol, txtPSBID.Text, pnlAjaxHCFA)
    '    ' **************** Commented to stop hcfa updation****************


    '    '' Change 3 NOV 2008 to load as much information from Hcfa as possible instead of 
    '    '' Loading info by calling each object GetRecordbyID() Method during EDI creation
    '    If (Me.cbSendOnline.Checked = True And lResult <> "") Then
    '        ''lHCFA.HCFA.HCFAID = lHCFADB.HCFAID
    '        ''If (lHCFA.GetRecordByID()) Then
    '        ''lFilePath = ClaimRequest837Methods.Make837Request(lUser, lHCFA.HCFA, lPatientCPTCol)
    '        ''Else
    '        lFilePath = ClaimRequest837Methods.Make837Request(lUser, lHCFADB, lPatientCPTCol)
    '        ''End If
    '    End If

    '    If (cbSendByOtherMeans.Checked = True) Then
    '        PatientLedgerMethods.SavePatientLedgerForHcFA(txtDisplayID.Text, txtInsuranceName.Text, rdpSendByOtherMeans.DbSelectedDate, txtPSBID.Text, txtPatientID.Text)
    '    End If

    '    If (pShowAlerts) Then
    '        If (lResult <> "" And Me.cbSendOnline.Checked = False) Then
    '            Dim lAlerttext As String = "CMS 1500 saved sucessfully with id: " & lResult
    '            'Me.pnlAjaxHCFA.Alert(lAlerttext)
    '            Response.Write("<script>alert('" & lAlerttext & "');window.location='../Billing/ClaimSearch.aspx';</script>")
    '            'Me.pnlAjaxHCFA.Redirect("../Billing/VisitSearch.aspx")
    '        ElseIf (lResult = "" And Me.cbSendOnline.Checked = False) Then
    '            Me.pnlAjaxHCFA.Alert("Error occured saving CMS 1500 ")
    '        End If

    '        If (lResult <> "" And lFilePath <> "" And Me.cbSendOnline.Checked = True) Then
    '            Dim lAlerttext As String = "CMS 1500 saved and send successfuly with ID: " & lResult
    '            Response.Write("<script>alert('" & lAlerttext & "');window.location='../Billing/SendClaim.aspx?FilePath=" & Utility.Encrypt(lFilePath, "!#$a54?3") & "';</script>")
    '            ''Me.pnlAjaxHCFA.Alert(lAlerttext)
    '            'Me.pnlAjaxHCFA.Redirect("../Billing/SendClaim.aspx?FilePath=" & Utility.Encrypt(lFilePath, "!#$a54?3"))
    '        ElseIf (lResult <> "" And lFilePath = "" And Me.cbSendOnline.Checked = True) Then
    '            Dim lAlerttext As String = "CMS 1500 saved successfuly but error in sending with ID: " & lResult
    '            'Me.pnlAjaxHCFA.Alert(lAlerttext)
    '            Response.Write("<script>alert('" & lAlerttext & "');window.location='../Billing/ClaimSearch.aspx';</script>")
    '            'Me.pnlAjaxHCFA.Redirect("../Billing/ClaimSearch.aspx")
    '        ElseIf (lResult = "" And lFilePath = "" And Me.cbSendOnline.Checked = True) Then
    '            Dim lAlerttext As String = "Error in saving and sending CMS 1500 with ID: " & lResult
    '            'Me.pnlAjaxHCFA.Alert(lAlerttext)
    '            Response.Write("<script>alert('" & lAlerttext & "');</script>")
    '        End If
    '    End If
    'End Sub

    'Public Sub InsertHCFAandPrint()
    '    Dim lResult As String = ""
    '    Dim lFilePath As String = ""
    '    'Dim lScript As String = "javascript:OpenPopUpWindowVisitSummary('ViewHcfaReport.aspx?HCFAID=" & Me.txtHCFAID.Text & "');"
    '    'Dim lScript As String = OpenPopUpWindowVisitSummary('ViewHcfaReport.aspx?HCFAID=" & Me.txtHCFAID.Text & "');
    '    Dim lScript As String = "window.open('ViewHcfaPdf.aspx" & Encryption.EncryptQueryString("HCFAID=" & Me.txtHCFAID.Text) & "','winPrn','toolbar=0,scrollbars=1,location=0,statusbar=0,menubar=0,resizable=1,width=900,height=800,left=200,top=80');"


    '    Dim lUser As User
    '    lUser = CType(Session("User"), User)

    '    Dim lHCFADB As HCFADB = GetHCFAHdr()

    '    Dim lPatientCPTCol As PatientCPTColl = GetHCFADtl()


    '    ' **************** Commented to stop hcfa updation****************
    '    lResult = HCFAMethods.InsertEditedHCFA(lUser, lHCFADB, lPatientCPTCol, txtPSBID.Text, pnlAjaxHCFA)
    '    ' **************** Commented to stop hcfa updation****************


    '    If (Me.cbSendOnline.Checked = True And lResult <> "") Then
    '        lFilePath = ClaimRequest837Methods.Make837Request(lUser, lHCFADB, lPatientCPTCol)
    '    End If

    '    If (cbSendByOtherMeans.Checked = True) Then
    '        PatientLedgerMethods.SavePatientLedgerForHcFA(txtDisplayID.Text, txtInsuranceName.Text, rdpSendByOtherMeans.DbSelectedDate, txtPSBID.Text, txtPatientID.Text)
    '    End If

    '    If (lResult <> "" And Me.cbSendOnline.Checked = False) Then
    '        Dim lAlerttext As String = "CMS 1500 saved successfully with id: " & lResult
    '        'Response.Write(lScript)
    '        'Me.pnlAjaxHCFA.ResponseScripts.Add(lScript)
    '        Response.Write("<script>" & lScript & "alert('" & lAlerttext & "');window.location='../Billing/ClaimSearch.aspx';</script>")
    '        'Me.pnlAjaxHCFA.Alert(lAlerttext)
    '        'Me.pnlAjaxHCFA.ResponseScripts.Add(lScript)
    '        'Me.pnlAjaxHCFA.Redirect("../Billing/ClaimSearch.aspx")
    '    ElseIf (lResult = "" And Me.cbSendOnline.Checked = False) Then
    '        Me.pnlAjaxHCFA.Alert("Error occured saving CMS 1500 ")
    '    End If

    '    If (lResult <> "" And lFilePath <> "" And Me.cbSendOnline.Checked = True) Then
    '        Dim lAlerttext As String = "CMS 1500 saved and send successfully with ID: " & lResult
    '        'Response.write(lscript)
    '        Response.Write("<script>" & lScript & "alert('" & lAlerttext & "');window.location='../Billing/sendClaim.aspx?FilePath=" & Utility.Encrypt(lFilePath, "!#$a54?3") & "';</script>")
    '        'Me.pnlAjaxHCFA.Alert(lAlerttext)
    '        'Me.pnlAjaxHCFA.Responsescripts.Add(lscript)
    '        'Me.pnlAjaxHCFA.Redirect("../Billing/sendClaim.aspx?FilePath=" & Utility.Encrypt(lFilePath, "!#$a54?3"))
    '    ElseIf (lResult <> "" And lFilePath = "" And Me.cbSendOnline.Checked = True) Then
    '        Dim lAlerttext As String = "CMS 1500 saved successfully but error in sending with ID: " & lResult
    '        'Response.write(lscript)
    '        Response.Write("<script>" & lScript & "alert('" & lAlerttext & "');window.location='../Billing/Claimsearch.aspx';</script>")
    '        'Me.pnlAjaxHCFA.Redirect("../Billing/Claimsearch.aspx")
    '        'Me.pnlAjaxHCFA.Alert(lAlerttext)
    '    ElseIf (lResult = "" And lFilePath = "" And Me.cbSendOnline.Checked = True) Then
    '        Dim lAlerttext As String = "Error in saving and sending CMS 1500 with ID: " & lResult
    '        Response.Write("<script>alert('" & lAlerttext & "');</script>")
    '        'Me.pnlAjaxHCFA.Alert(lAlerttext)
    '    End If
    'End Sub


    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSave.Click
        ' InsertHCFA(True)
        'Create837()
    End Sub

    Protected Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnCancel.Click
        Me.pnlAjaxHCFA.Redirect("../Billing/ClaimSearch.aspx")
    End Sub

    Protected Sub btnFacilitySearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnFacilitySearch.Click
        pnlAjaxHCFA.ResponseScripts.Add("window.radopen('FacilitySearchWindow.aspx','rwFacilitySearch');")
    End Sub

    Protected Sub btnRefferingProviderSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefferingProviderSearch.Click
        pnlAjaxHCFA.ResponseScripts.Add("window.radopen('ReferringProviderSearchWindow.aspx','rwRefferingProviderSearch');")
    End Sub



    'Public Sub Create837()

    '    Dim lResult As String

    '    Dim lUser As User
    '    lUser = CType(Session("User"), User)

    '    Dim lHCFADB As HCFADB = GetHCFAHdr()
    '    Dim lHCFADtlCol As HCFADetailColl = GetHCFADtl()

    '    lResult = ClaimRequest837Methods.Make837Request(lUser, lHCFADB, lHCFADtlCol)


    '    If (lResult <> "") Then
    '        Dim lAlerttext As String = "EDI generated Sucessfuly WIth ID" & lResult
    '        Me.pnlAjaxHCFA.Alert(lAlerttext)
    '        Me.pnlAjaxHCFA.Redirect("../Billing/ClaimSearch.aspx")
    '        ''Response.Write("<script>alert(' HCFA Added Sucessfully');</script>")
    '        ''Response.Write("<script>location.href = '../Billing/ClaimSearch.aspx';</script>")
    '    Else
    '        'Response.Write("<script>alert(' Failed to Add HCFA');</script>")
    '        Me.pnlAjaxHCFA.Alert("Error occured generating EDI ")
    '    End If

    'End Sub

    Protected Sub btnPrintHcfa_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnPrintHcfa.Click
        Dim lUser As User
        Dim lCPTsColl = New PatientCPTColl
        lUser = CType(Session.Item("User"), User)
        Dim lHcFaEdited = New HCFADBUpdated
        Dim lScript As String = "var answer = confirm('Do you want to print on a printed paper?'); if (answer){window.open('ViewHcfaPdf.aspx" & Encryption.EncryptQueryString("HCFAID=" & Me.txtHCFAID.Text & "&sor=abc") & "','winPrn','toolbar=0,scrollbars=1,location=0,statusbar=0,menubar=0,resizable=1,width=900,height=800,left=200,top=80');}else {window.open('ViewHcfaPdf.aspx" & Encryption.EncryptQueryString("HCFAID=" & Me.txtHCFAID.Text & "&sor=Printed") & "','winPrn','toolbar=0,scrollbars=1,location=0,statusbar=0,menubar=0,resizable=1,width=900,height=800,left=200,top=80');}"



        lHcFaEdited = GetHCFAUpdatedHdr()
        'lCPTsColl = GetHCFAUpdateDtl()
        Dim lHcFaDtlEditedColl As HCFADetailCollUpdated
        Dim lFlag = False
        lHcFaDtlEditedColl = GetHCADetailForUpdate()
        Try
            If (Me.btnMakeEditable.Enabled = False) Then
                lFlag = True
            End If
            If (lFlag) Then

                If (HCFAMethods.UpdateHCFA_HCFADtl_PatCPT_PSB(lUser.ConnectionString, lHcFaEdited, lHcFaDtlEditedColl)) Then
                    Response.Write("<script>" & lScript & "alert(' Claim updated successfully ');window.location='../Billing/ClaimSearch.aspx';</script>")
                End If
            Else
                Response.Write("<script>" & lScript & "</script>")
            End If
        Catch ex As Exception
            Response.Write("<script>alert('Unable to update the claim');</script>")

        End Try

    End Sub

    Protected Sub cmbRefferingProviderIDQualifier_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbRefferingProviderIDQualifier.SelectedIndexChanged
        txtRefferingProviderID.Enabled = True
    End Sub


    Protected Sub btnMakeEditable_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnMakeEditable.Click


        btnEdit.Visible = True
        btnEdit.Attributes.Add("onclick", "javascript:return clickOnceSF(this);")

        Me.btnEditBP.Visible = True
        btnEditBP.Attributes.Add("onclick", "javascript:return clickOnceBP(this);")


        Me.btnEditPat.Visible = True
        btnEditPat.Attributes.Add("onclick", "javascript:return clickOncePat(this);")

        Me.btnEditiPat.Visible = True
        btnEditiPat.Attributes.Add("onclick", "javascript:return clickOncePat(this);")

        Me.btnEditOtheriPat.Visible = True
        btnEditOtheriPat.Attributes.Add("onclick", "javascript:return clickOncePat(this);")


        Me.btnEditRenP.Visible = True
        btnEditRenP.Attributes.Add("onclick", "javascript:return clickOnceRenPvd(this);")

        btnMakeEditable.Enabled = False
        Me.hdrBar.Visible = False
        MakeMainAreaEditable()
        MakeCptAreaEditable()

    End Sub


    Protected Sub btnHCFAEdit_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnHCFAEdit.Click
        Dim lUser As User
        Dim lCPTsColl = New PatientCPTColl
        lUser = CType(Session.Item("User"), User)
        Dim lHcFaEdited = New HCFADBUpdated
        lHcFaEdited = GetHCFAUpdatedHdr()
        'lCPTsColl = GetHCFAUpdateDtl()
        Dim lHcFaDtlEditedColl As HCFADetailCollUpdated
        lHcFaDtlEditedColl = GetHCADetailForUpdate()
        Try
            If (HCFAMethods.UpdateHCFA_HCFADtl_PatCPT_PSB(lUser.ConnectionString, lHcFaEdited, lHcFaDtlEditedColl)) Then

                pnlMain.Enabled = False
                Me.btnHCFAEdit.Enabled = False
                Me.hdrBar.Visible = True

                'Response.Write("<script>alert('Claim updated successfully');window.location='../Billing/ClaimSearch.aspx';</script>")


                Response.Write("<script language='javascript'> alert('Claim updated successfully');history.go(-(history.length));window.location='../Billing/ClaimSearch.aspx';</script>")


                'Response.Write("<script>alert('Claim updated successfully');</script>")
                'PageExpire()
                'Response.Write("<script>location.href = '../Billing/ClaimSearch.aspx';</script>")


            End If
        Catch ex As Exception
            Response.Write("<script>alert('Unable to update the claim');</script>")

        End Try


        Me.btnEdit.Visible = False


        Me.btnEditBP.Visible = False


        Me.btnEditPat.Visible = False

        Me.btnEditiPat.Visible = False


        Me.btnEditOtheriPat.Visible = False





    End Sub

    Public Function GetHCFAUpdatedHdr() As HCFADBUpdated
        Dim lHcFaEdited As HCFADBUpdated
        Dim lUser As User


        lUser = CType(Session("User"), User)


        lHcFaEdited = CType(Session.Item("HCFADBUpdated"), HCFADBUpdated)

        With lHcFaEdited
            .PatientSuperBillID = Me.txtPSBID.Text
            .HCFAID = Me.txtHCFAID.Text
            .HCFADisplayID = Me.txtDisplayID.Text
            'And .MainInsuranceCompany.InsuranceType = ""
            If (Me.chkMedicare.Checked) Then
                .MainInsuranceCompany.InsuranceType = "MEDICARE"
            End If
            If (Me.chkMedicaid.Checked) Then
                .MainInsuranceCompany.InsuranceType = "MEDICAID"
            End If
            If (Me.chkTricare.Checked) Then
                .MainInsuranceCompany.InsuranceType = "TRICARE"
            End If
            If (Me.chkChampva.Checked) Then
                .MainInsuranceCompany.InsuranceType = "CHAMPVA"
            End If
            If (Me.chkGroupHealth.Checked) Then
                .MainInsuranceCompany.InsuranceType = "GROUP HEALTH PLAN"
            End If
            If (Me.chkFecaBuklung.Checked) Then
                .MainInsuranceCompany.InsuranceType = "FECA"
            End If
            If (Me.chkOther.Checked) Then
                .MainInsuranceCompany.InsuranceType = "OTHER"
            End If
            'And .OtherInsuranceCompany.InsuranceType = ""
            If (Me.chkMedicare.Checked And .MainInsuranceCompany.InsuranceType <> "MEDICARE") Then
                .OtherInsuranceCompany.InsuranceType = "MEDICARE"
            End If
            If (Me.chkMedicaid.Checked And .MainInsuranceCompany.InsuranceType <> "MEDICAID") Then
                .OtherInsuranceCompany.InsuranceType = "MEDICAID"
            End If
            If (Me.chkTricare.Checked And .MainInsuranceCompany.InsuranceType <> "TRICARE") Then
                .OtherInsuranceCompany.InsuranceType = "TRICARE"
            End If
            If (Me.chkChampva.Checked And .MainInsuranceCompany.InsuranceType <> "CHAMPVA") Then
                .OtherInsuranceCompany.InsuranceType = "CHAMPVA"
            End If
            If (Me.chkGroupHealth.Checked And .MainInsuranceCompany.InsuranceType <> "GROUP") Then
                .OtherInsuranceCompany.InsuranceType = "GROUP HEALTH PLAN"
            End If
            If (Me.chkFecaBuklung.Checked And .MainInsuranceCompany.InsuranceType <> "FECA") Then
                .OtherInsuranceCompany.InsuranceType = "FECA"
            End If
            If (Me.chkOther.Checked And .MainInsuranceCompany.InsuranceType <> "OTHER") Then
                .OtherInsuranceCompany.InsuranceType = "OTHER"
            End If
            '1a
            .MainPatientInsurance.SubscriberID = txtInsuredIDNumber.Text
            '**************** 12

            .SignDate = dtReleaseInfoDate.DbSelectedDate
            .SignOnFile = lblSignatureOnFile.Text
            .AuthorizedPersonSign = lblPaymentSignature.Text

            '*****************
            '.PaymentSignature = Me.lblPaymentSignature.Text

            .Patient.DOB = dtPatientDOB.SelectedDate.ToString.Split(" ")(0)
            .Patient.Gender = IIf(rdoPatientGenderFemale.Checked, "F", "M")
            .Patient.City = Me.txtPatientCity.Text
            .Patient.ZipCode = Me.txtPatientZipCode.Text
            .Patient.HomePhone = Me.txtPatientTelephone.Text
            .Patient.StateID = Me.txtPatientState.Text

            If rdoPatientRelationshipToInsuredSelf.Checked Then
                .MainPatientInsurance.RelationshipToPrimaryInsurer = "Self"
            ElseIf rdoPatientRelationshipToInsuredChild.Checked Then
                .MainPatientInsurance.RelationshipToPrimaryInsurer = "Child"
            ElseIf rdoPatientRelationshipToInsuredSpouse.Checked Then
                .MainPatientInsurance.RelationshipToPrimaryInsurer = "Spouse"
            Else 'If Other 
                .MainPatientInsurance.RelationshipToPrimaryInsurer = "Other"
            End If


            If rdoPatientMaritalStatusMarried.Checked Then
                .Patient.MartialStatus = "Married"
            ElseIf rdoPatientMaritalStatusSingle.Checked Then
                .Patient.MartialStatus = "Single"
            Else 'If Other 
                .Patient.MartialStatus = "Other"
            End If

            If chkPatientEmploymentInfoEmployed.Checked Then
                .Patient.EmploymentStatus = "Employeed"
            ElseIf chkPatientEmploymentInfoFullTimeStudent.Checked Then
                .Patient.EmploymentStatus = "Full Time Student"
            ElseIf chkPatientEmploymentInfoPartTimeStudent.Checked Then
                .Patient.EmploymentStatus = "Part Time Student"
            Else
                .Patient.EmploymentStatus = "Other"
            End If

        

            .MedicadReSubNo = txtOriginalRefrenceNumber.Text
           

            If Me.rdoOtherInsuredGenderFemale.Checked Then
                .OtherInsurerPatient.Gender = "Female"

            ElseIf Me.rdoOtherInsuredGenderMale.Checked Then
                .OtherInsurerPatient.Gender = "Male"
            End If
            'block 11
            .InsurerPatient.DOB = dtInsuredDOB.DbSelectedDate
            .InsurerPatient.Gender = IIf(Me.rdoOtherInsuredGenderFemale.Checked, "F", "M")
            .InsurerPatient.City = Me.txtInsuredCity.Text
            .InsurerPatient.ZipCode = Me.txtInsuredZipCode.Text
            .InsurerPatient.HomePhone = Me.txtInsuredTelephone.Text
            .InsurerPatient.StateID = Me.txtInsuredState.Text

            .InsurerPatient.EmployerName = Me.txtAnotherInsuredEmployerName.Text
            .MainPatientInsurance.GroupNo = Me.txtAnotherInsuredPolicy.Text
            .MainPatientInsurance.PlanName = Me.txtAnotherInsuredPlan.Text

            ' Block 11
            'Block 9

            .OtherInsurerPatient.DOB = Me.dtOtherInsuredDOB.DbSelectedDate
            .OtherInsurerPatient.Gender = IIf(Me.rdoAnotherInsuredGenderFemale.Checked, "F", "M")

            .OtherInsurerPatient.EmployerName = Me.txtOtherInsuredEmployerName.Text
            .OtherPatientInsurance.GroupNo = Me.txtOtherInsuredPolicy.Text
            .OtherPatientInsurance.PlanName = Me.txtSecondaryInsurancePlan.Text

            ' Block 9
            If Me.rdoIsEmploymentRelatedYes.Checked Then
                .PatientConditionEmployment = "Y"
            ElseIf Me.rdoIsEmploymentRelatedNo.Checked Then
                .PatientConditionEmployment = "N"
            End If

            If Me.rdoIsAutoAccidentRelatedYes.Checked Then
                .PatientConditionAutoAccident = "Y"

            ElseIf Me.rdoIsAutoAccidentRelatedNo.Checked Then
                .PatientConditionAutoAccident = "N"
                .PatientConditionAutoAccPlace = ""
            End If
            .PatientConditionAutoAccPlace = Me.txtPLACEState.Text

            If Me.rdoIsOtherAccidentRelatedYes.Checked Then
                .PatientConditionOtherAccident = "Y"
            ElseIf Me.rdoIsOtherAccidentRelatedNo.Checked Then
                .PatientConditionOtherAccident = "N"
            End If



            .MainPatientInsurance.SignatureOfFile = lblSignatureOnFile.Text
            .MainPatientInsurance.SignatureDate = dtReleaseInfoDate.DbSelectedDate

            .DateOfOccurance = dtDateOfOccurance.DbSelectedDate
            .PreviousOccuranceDate = dtPreviousOccuranceDate.DbSelectedDate
            .PatUnableToWorkFrom = dtUnableToWorkFrom.DbSelectedDate
            .PatUnableToWorkTo = dtUnableToWorkTo.DbSelectedDate

            .ReferencePvd.ProviderID = txtRefferingProvider.Text 'Field To Be loaded
            .ReferencePvd.NPI = txtRefferingProviderNPI.Text

            .HospitalizationDateFrom = dtHospitalizationDateFrom.DbSelectedDate
            .HospitalizationDateTo = dtHospitalizationDateTo.DbSelectedDate
            .Field19 = txtReservedField19.Text 'Field to be added in Database
            .IsOutsideLab = IIf(rdoIsOutsideLabYes.Checked, "Y", "N")

            Try
                .OutsideLabCharges = CType(txtOutsideLabCharges1.Text, Double)
            Catch ex As Exception
                .OutsideLabCharges = 0.0
            End Try

            .ICD1 = txtICD1.Text
            .ICD2 = txtICD2.Text
            .ICD3 = txtICD3.Text
            .ICD4 = txtICD4.Text
            .MedicadReSubCode = txtMedicaidCode.Text

            .MainPatientInsurance.AuthorizationNumber = txtPriorAuthorizationNumber.Text
            .FederalTaxNo = txtFederalTaxID.Text
            .Patient.SSN = IIf(rdoIsSSNYes.Checked, "Y", "N")


            'PatientAccountNumber=X.ClinicID + 'H' + substring(Cast(Year(H.HcfaPreparedDate) as Varchar),3,2) + Right(REPLICATE('0', 2) + Cast(Month(H.HcfaPreparedDate) as Varchar),2) + Right(REPLICATE('0', 5) + Cast(H.HcfaDisplayId As Varchar),5), 


            .PatientACNo = txtPatientAccountNumber.Text 'Me.txtPatientID.Text 
            .AcceptAssignment = IIf(rdoIsAcceptAssignmentYes.Checked, "Y", "N")

            Try
                .TotalCharges = CType(txtTotalCharges1.Text, Double)
            Catch ex As Exception
                .TotalCharges = 0.0
            End Try

            Try
                .AmountPaid = CType(txtAmountPaid1.Text, Double)
            Catch ex As Exception
                .AmountPaid = 0.0
            End Try

            Try
                .BalanceDue = CType(txtBalanceDue1.Text, Double)
                If (.BalanceDue = 0.0) Then
                    .BalanceDue = .TotalCharges - .AmountPaid
                End If
            Catch ex As Exception
                .BalanceDue = 0.0
            End Try


            .HCFAPreparedDate = dtHCFAPreparedDate.DbSelectedDate



         
            .BillingPvd.NPI = Me.txtPrescriberNPI.Text
            .BillingPvd.Phone1 = Me.TextBox1.Text


            If (Me.txtHCFAID.Text = "0") Then


                .CreateByUserID = lUser.UserId
            Else

                .CreateByUserID = Me.txtCreateByUserID.Text
            End If

            .MainPatientInsurance.InsuranceCompanyName = Me.lblInsuranceName.Text


            .ReservedField10d = Me.txtReserverBlock10D.Text
            .Field19 = Me.txtReservedField19.Text

            '*** Block 32 & 33 Update 
            .ServiceFacility.NPI = txtFascilityNPI.Text
            .ServFacSecIdQualifier = cmbFacilitySecondaryIdentificationQualifier.SelectedValue
            .ServFacSecIdValue = txtFacilityCode.Text
            .BillingPvd.NPI = txtPrescriberNPI.Text
            .BPvdSecIdQualifier = cmbClinicSecondaryIdentificationQualifier.SelectedValue
            .BPvdSecIdValue = txtPrescriberGroupNumber.Text
            '********

          

        End With

        Return lHcFaEdited

    End Function

    'Public Function GetHCFAUpdateDtl() As PatientCPTColl

    '    Dim lPatientCPTDB As PatientCPTDB
    '    Dim lPatientCPTCol As New PatientCPTColl
    '    Dim lTextBox As TextBox
    '    Dim lCombo As DropDownList
    '    Dim lDatePicker As RadDatePicker

    '    Dim lCounter As Integer = 1


    '    lCounter = 1
    '    For lCounter = 1 To 6
    '        lTextBox = CType(pnlAjaxHCFA.FindControl("txtCPTCode" & lCounter), TextBox)

    '        If (lTextBox.Text <> "") Then
    '            lPatientCPTDB = New PatientCPTDB()

    '            With lPatientCPTDB
    '                .HCFAID = Me.txtHCFAID.Text
    '                .Code = lTextBox.Text
    '                .LineId = lCounter

    '                lDatePicker = CType(pnlAjaxHCFA.FindControl("dtDateOfServiceFrom" & lCounter), RadDatePicker)
    '                .DateOfServiceFrom = lDatePicker.DbSelectedDate

    '                lDatePicker = CType(pnlAjaxHCFA.FindControl("dtDateOfServiceTo" & lCounter), RadDatePicker)
    '                .DateOfServiceTo = lDatePicker.DbSelectedDate

    '                lTextBox = CType(pnlAjaxHCFA.FindControl("txtPlaceOfService" & lCounter), TextBox)
    '                .POS = lTextBox.Text

    '                'lTextBox = CType(pnlAjaxHCFA.FindControl("txtEmergency" & lCounter), TextBox)
    '                '.= lTextBox.Text


    '                lTextBox = CType(pnlAjaxHCFA.FindControl("txtModifierA" & lCounter), TextBox)
    '                .ModifierA = lTextBox.Text

    '                lTextBox = CType(pnlAjaxHCFA.FindControl("txtModifierB" & lCounter), TextBox)
    '                .ModifierB = lTextBox.Text

    '                lTextBox = CType(pnlAjaxHCFA.FindControl("txtModifierC" & lCounter), TextBox)
    '                .ModifierC = lTextBox.Text

    '                lTextBox = CType(pnlAjaxHCFA.FindControl("txtModifierD" & lCounter), TextBox)
    '                .ModifierD = lTextBox.Text

    '                lTextBox = CType(pnlAjaxHCFA.FindControl("txtDignosisPointer" & lCounter), TextBox)
    '                .Pointer = lTextBox.Text


    '                lTextBox = CType(pnlAjaxHCFA.FindControl("txtChargesWhole" & lCounter), TextBox)
    '                Try
    '                    .Charges = CType(lTextBox.Text, Double)
    '                Catch ex As Exception
    '                    .Charges = 0.0
    '                End Try


    '                lTextBox = CType(pnlAjaxHCFA.FindControl("txtDays" & lCounter), TextBox)
    '                .Days = lTextBox.Text

    '                lTextBox = CType(pnlAjaxHCFA.FindControl("txtEPSDT" & lCounter), TextBox)
    '                .EPSDT = lTextBox.Text

    '                lTextBox = CType(pnlAjaxHCFA.FindControl("txtEmergency" & lCounter), TextBox)
    '                .EMG = lTextBox.Text

    '                lCombo = CType(pnlAjaxHCFA.FindControl("cmbCOB1"), DropDownList)
    '                .COB = lCombo.SelectedItem.Value

    '                lTextBox = CType(pnlAjaxHCFA.FindControl("txtNPI" & lCounter), TextBox)
    '                .NPI = lTextBox.Text

    '                lTextBox = CType(pnlAjaxHCFA.FindControl("txtPrescriberLicenseID1"), TextBox)
    '                .PrescriberLicenceID = lTextBox.Text 'Field To Be added In DB & Classes

    '            End With

    '            lPatientCPTCol.Add(lPatientCPTDB)
    '        End If

    '    Next

    '    Return lPatientCPTCol

    'End Function

 
    Protected Sub btnEditFacility_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnEditFacility.Click
        Dim lHCFADBUpdated As HCFADBUpdated
        If (Session("HCFADBUpdated") Is Nothing) Then
            Exit Sub
        Else

            lHCFADBUpdated = CType(Session("HCFADBUpdated"), HCFADBUpdated)

        End If
        With lHCFADBUpdated
          

            If (.ServiceFacility.FacilityID = "0") Then
                Me.txtFacilityInfoType.Text = "C"
                txtFacilityReturnInfo.Text = ""
            Else
                Me.txtFacilityInfoType.Text = "F"
                Me.txtFacilityReturnInfo.Text = .ServiceFacility.FacilityID & "|" & .ServiceFacility.FacilityName & "|" & .ServiceFacility.AddressLine1 + " " + .ServiceFacility.AddressLine2 & "|" & .ServiceFacility.City & "|" & .ServiceFacility.State & "|" & .ServiceFacility.ZipCode
            End If

            Me.txtFacilityInfo.Text = .ServiceFacility.FacilityName & vbCrLf & .ServiceFacility.AddressLine1 + " " + .ServiceFacility.AddressLine2 & vbCrLf & .ServiceFacility.City & " " & .ServiceFacility.State & " " & .ServiceFacility.ZipCode
            Me.txtFacilityCity.Text = .ServiceFacility.City
            Me.txtFacilityState.Text = .ServiceFacility.State
            Me.txtFacilityZipCode.Text = .ServiceFacility.ZipCode
            txtFascilityNPI.Text = .ServiceFacility.NPI
            txtFacilityCode.Text = .ServiceFacility.FacilityCode

        End With
    End Sub

    
    Protected Sub btnEditBProvider_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnEditBProvider.Click
        Dim lHCFADBUpdated As HCFADBUpdated
        If (Session("HCFADBUpdated") Is Nothing) Then
            Exit Sub
        Else

            lHCFADBUpdated = CType(Session("HCFADBUpdated"), HCFADBUpdated)

        End If
        With lHCFADBUpdated

            Me.txtClinicInfo.Text = vbCrLf & .BillingPvd.LastName & " " & .BillingPvd.FirstName & " " & .BillingPvd.MiddleName
            Me.txtClinicInfo.Text = Me.txtClinicInfo.Text & " " & .BillingPvd.AddressLine1 & " " & .BillingPvd.AddressLine2 & " " & .BillingPvd.City
            Me.txtClinicInfo.Text = Me.txtClinicInfo.Text & " " & .BillingPvd.State
            Me.txtClinicInfo.Text = Me.txtClinicInfo.Text & " " & .BillingPvd.ZipCode
            Me.TextBox1.Text = IIf(.BillingPvd.Phone1 <> "", .BillingPvd.Phone1, .BillingPvd.Phone2)
            Me.txtPrescriberNPI.Text = .BillingPvd.NPI
            '****
        End With
    End Sub

    Protected Sub btnEditPatient_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnEditPatient.Click
        Dim lHCFADBUpdated As HCFADBUpdated
        If (Session("HCFADBUpdated") Is Nothing) Then
            Exit Sub
        Else

            lHCFADBUpdated = CType(Session("HCFADBUpdated"), HCFADBUpdated)

        End If
        With lHCFADBUpdated
            ' If .Patient.PatientID <> "0" Then
            If .Patient.FirstName <> "" Then
                Me.txtPatientName.Text = .Patient.LastName & ", " & .Patient.FirstName
                If (.Patient.MiddleName <> "") Then
                    Me.txtPatientName.Text = Me.txtPatientName.Text & ", " & .Patient.MiddleName
                End If

                Me.txtPatientAddress.Text = .Patient.AddressLine1 & " " & .Patient.AddressLine2

            End If
            ' End If

            ' If .InsurerPatient.PatientID <> "0" Then
            If .InsurerPatient.FirstName <> "" Then
                Me.txtInsuredName.Text = .InsurerPatient.LastName & ", " & .InsurerPatient.FirstName
                If (.InsurerPatient.MiddleName <> "") Then
                    Me.txtInsuredName.Text = Me.txtInsuredName.Text & ", " & .InsurerPatient.MiddleName
                End If

                Me.txtInsuredAddress.Text = .InsurerPatient.AddressLine1 & " " & .InsurerPatient.AddressLine2
            End If
            'End If

            '  If .OtherInsurerPatient.PatientID <> "0" Then
            If .OtherInsurerPatient.FirstName <> "" Then
                Me.txtOtherInsuredName.Text = .OtherInsurerPatient.LastName & ", " & .OtherInsurerPatient.FirstName
                If (.OtherInsurerPatient.MiddleName <> "") Then
                    Me.txtOtherInsuredName.Text = Me.txtOtherInsuredName.Text & ", " & .OtherInsurerPatient.MiddleName
                End If
            End If
            ' End If
        End With



    End Sub

    Public Sub LoadCptFromHcfaDtlCol()

        Dim lHCFADetailCollUpdated As New HCFADetailCollUpdated
        Dim lTextBox As TextBox
        Dim lCombo As DropDownList
        Dim lDatePicker As Telerik.WebControls.RadDatePicker
        Dim lUser As User



        lUser = CType(Session.Item("User"), User)
        lHCFADetailCollUpdated = HCFAMethods.GetHCFADetailForHCFA(lUser.ConnectionString, Me.txtHCFAID.Text)
        Session("HCFADtlCol") = lHCFADetailCollUpdated


        '*************************************************************************
        '************************Load CPT Information ****************************
        '*************************************************************************

        Dim lTotalCharges As Double = 0
        Dim lCounter As Int32 = 1
        For Each Item As HCFADetailDBUpdated In lHCFADetailCollUpdated

            With Item

                lTextBox = CType(pnlAjaxHCFA.FindControl("txtCPTCode" & lCounter), TextBox)
                lTextBox.Text = .CPTCode

                lDatePicker = CType(pnlAjaxHCFA.FindControl("dtDateOfServiceFrom" & lCounter), RadDatePicker)
                lDatePicker.SelectedDate = CType(.DateOfServiceFrom, Date)

                lDatePicker = CType(pnlAjaxHCFA.FindControl("dtDateOfServiceTo" & lCounter), RadDatePicker)
                'lDatePicker.SelectedDate = DateAdd(DateInterval.Day, CType(.Item("Days"), Double) - 1, CType(.Item("DateOfServiceTo"), Date))
                lDatePicker.SelectedDate = CType(.DateOfServiceTo, Date)

                lTextBox = CType(pnlAjaxHCFA.FindControl("txtPlaceOfService" & lCounter), TextBox)
                lTextBox.Text = .ServiceFacility.FacilityCode

                lTextBox = CType(pnlAjaxHCFA.FindControl("txtModifierA" & lCounter), TextBox)
                lTextBox.Text = .ModifierA


                lTextBox = CType(pnlAjaxHCFA.FindControl("txtModifierB" & lCounter), TextBox)
                lTextBox.Text = .ModifierB

                lTextBox = CType(pnlAjaxHCFA.FindControl("txtModifierC" & lCounter), TextBox)
                lTextBox.Text = .ModifierC

                lTextBox = CType(pnlAjaxHCFA.FindControl("txtModifierD" & lCounter), TextBox)
                lTextBox.Text = .ModifierD


                lTextBox = CType(pnlAjaxHCFA.FindControl("txtDignosisPointer" & lCounter), TextBox)
                lTextBox.Text = .DignosisPointer

                lTextBox = CType(pnlAjaxHCFA.FindControl("txtChargesWhole" & lCounter), TextBox)
                lTextBox.Text = CType(.Charges, Double).ToString("####.00")

                lTextBox = CType(pnlAjaxHCFA.FindControl("txtDays" & lCounter), TextBox)
                lTextBox.Text = .Days

                lTotalCharges = lTotalCharges + CType(.Charges, Double)


                lTextBox = CType(pnlAjaxHCFA.FindControl("txtNPI" & lCounter), TextBox)
                If (Not IsDBNull(.RenderingProvider.NPI)) Then
                    lTextBox.Text = .RenderingProvider.NPI.ToString
                Else
                    lTextBox.Text = ""
                End If

                lTextBox = CType(pnlAjaxHCFA.FindControl("txtEPSDT" & lCounter), TextBox)
                lTextBox.Text = .EPSDT

                lTextBox = CType(pnlAjaxHCFA.FindControl("txtEmergency" & lCounter), TextBox)
                lTextBox.Text = .Emergency


                lTextBox = CType(pnlAjaxHCFA.FindControl("txtPrescriberLicenseID" & lCounter), TextBox)
                lTextBox.Text = "" '.RenderingProvider.TaxID.ToString  'Field To Be added in Database and Classes

                lCombo = CType(pnlAjaxHCFA.FindControl("cmbCOB" & lCounter), DropDownList)
                lCombo.SelectedValue = .COB.ToString  'Field To Be added in Database and Classes

            End With

            lCounter += 1

        Next




    End Sub

    Public Sub MakeMainAreaEditable()
        Dim lUser As User
        lUser = CType(Session.Item("User"), User)

        pnlMain.Enabled = True
        Me.btnHCFAEdit.Enabled = True
        Me.rdpSendByOtherMeans.Enabled = False
        Me.rdoIsAnotherHealthPlanYes.Enabled = False
        Me.txtPatientAccountNumber.Enabled = False
        '2
        Me.txtPatientName.Enabled = False
        '4
        Me.txtInsuredName.Enabled = False
        '5
        Me.txtPatientAddress.Enabled = False
        'Me.txtPatientCity.Enabled = False
        'Me.txtPatientState.Enabled = False
        'Me.txtPatientTelephone.Enabled = False
        'Me.txtPatientZipCode.Enabled = False

        '7
        Me.txtInsuredAddress.Enabled = False
        'Me.txtInsuredCity.Enabled = False
        'Me.txtInsuredState.Enabled = False
        'Me.txtInsuredTelephone.Enabled = False
        'Me.txtInsuredZipCode.Enabled = False

        '9

        'Me.txtOtherInsuredEmployerName.Enabled = False
        Me.txtOtherInsuredName.Enabled = False
        'Me.txtOtherInsuredPolicy.Enabled = False
        'Me.txtRefferingProviderName.Enabled = False
        'Me.txtRefferingProviderNPI.Enabled = False

        '17
        Me.txtRefferingProviderName.Enabled = False
        'Me.txtReservedField19.Enabled = False
        '24(a)


        '25
        Me.txtFederalTaxID.Enabled = False
        '26
        Me.rdoIsSSNNo.Enabled = False
        Me.rdoIsSSNYes.Enabled = False

        Me.txtTotalCharges1.Enabled = False
        Me.txtAmountPaid1.Enabled = False
        Me.txtBalanceDue1.Enabled = False

        Me.chkMedicare.Enabled = True
        Me.chkMedicaid.Enabled = True
        Me.chkTricare.Enabled = True
        Me.chkChampva.Enabled = True
        Me.chkGroupHealth.Enabled = True
        Me.chkFecaBuklung.Enabled = True
        Me.chkOther.Enabled = True



    End Sub

    Public Sub MakeCptAreaEditable()
        Dim lPatientCPT As DataSet
        Dim lTextBox = New TextBox
        Dim lCombo = New DropDownList

        Dim lDatePicker = New Telerik.WebControls.RadDatePicker
        
        lPatientCPT = HCFAMethods.GetCPTForHCFA("", txtPSBID.Text)
        Dim lTotalCharges As Double = 0


        For lCounter As Int32 = 1 To 6
            lTextBox = CType(pnlAjaxHCFA.FindControl("txtCPTCode" & lCounter), TextBox)
            '*************************************************************************
            '************************Lines where CPT code exist **********************
            '*************************************************************************
            If (lTextBox.Text <> "") Then
                lDatePicker = CType(pnlAjaxHCFA.FindControl("dtDateOfServiceFrom" & lCounter), RadDatePicker)
                lDatePicker.Enabled = False

                lDatePicker = CType(pnlAjaxHCFA.FindControl("dtDateOfServiceTo" & lCounter), RadDatePicker)
                'DOS is always disabled.
                lDatePicker.Enabled = False

                lTextBox = CType(pnlAjaxHCFA.FindControl("txtCPTCode" & lCounter), TextBox)
                lTextBox.enabled = False




                'Have to be replace with the combo Loaded with facilityName later on using facilityCode.
                lTextBox = CType(pnlAjaxHCFA.FindControl("txtPlaceOfService" & lCounter), TextBox)
                lTextBox.enabled = True

                lTextBox = CType(pnlAjaxHCFA.FindControl("txtModifierA" & lCounter), TextBox)
                lTextBox.enabled = False

                lTextBox = CType(pnlAjaxHCFA.FindControl("txtModifierB" & lCounter), TextBox)
                lTextBox.enabled = False

                lTextBox = CType(pnlAjaxHCFA.FindControl("txtModifierC" & lCounter), TextBox)
                lTextBox.enabled = False

                lTextBox = CType(pnlAjaxHCFA.FindControl("txtModifierD" & lCounter), TextBox)
                lTextBox.enabled = False


                lTextBox = CType(pnlAjaxHCFA.FindControl("txtDignosisPointer" & lCounter), TextBox)
                lTextBox.Enabled = True



                lTextBox = CType(pnlAjaxHCFA.FindControl("txtChargesWhole" & lCounter), TextBox)
                lTextBox.enabled = False

                lTextBox = CType(pnlAjaxHCFA.FindControl("txtDays" & lCounter), TextBox)
                lTextBox.enabled = False



                lTextBox = CType(pnlAjaxHCFA.FindControl("txtNPI" & lCounter), TextBox)
                lTextBox.Enabled = True


                lTextBox = CType(pnlAjaxHCFA.FindControl("txtEPSDT" & lCounter), TextBox)
                lTextBox.enabled = False


                lTextBox = CType(pnlAjaxHCFA.FindControl("txtEmergency" & lCounter), TextBox)
                lTextBox.enabled = False



                lTextBox = CType(pnlAjaxHCFA.FindControl("txtPrescriberLicenseID" & lCounter), TextBox)
                lTextBox.enabled = False

                lCombo = CType(pnlAjaxHCFA.FindControl("cmbCOB" & lCounter), DropDownList)
                lCombo.enabled = False

            Else
                '*************************************************************************
                '************************Lines where CPT code does not exist **********************
                '*************************************************************************
                lDatePicker = CType(pnlAjaxHCFA.FindControl("dtDateOfServiceFrom" & lCounter), RadDatePicker)
                lDatePicker.Enabled = False
                lDatePicker = CType(pnlAjaxHCFA.FindControl("dtDateOfServiceTo" & lCounter), RadDatePicker)
                lDatePicker.Enabled = False
                lTextBox = CType(pnlAjaxHCFA.FindControl("txtCPTCode" & lCounter), TextBox)
                lTextBox.enabled = False
                'Have to be replace with the combo Loaded with facilityName later on using facilityCode.
                lTextBox = CType(pnlAjaxHCFA.FindControl("txtPlaceOfService" & lCounter), TextBox)
                lTextBox.enabled = False
                lTextBox = CType(pnlAjaxHCFA.FindControl("txtModifierA" & lCounter), TextBox)
                lTextBox.enabled = False

                lTextBox = CType(pnlAjaxHCFA.FindControl("txtModifierB" & lCounter), TextBox)
                lTextBox.enabled = False

                lTextBox = CType(pnlAjaxHCFA.FindControl("txtModifierC" & lCounter), TextBox)
                lTextBox.enabled = False

                lTextBox = CType(pnlAjaxHCFA.FindControl("txtModifierD" & lCounter), TextBox)
                lTextBox.enabled = False
                lTextBox = CType(pnlAjaxHCFA.FindControl("txtDignosisPointer" & lCounter), TextBox)
                lTextBox.enabled = False


                lTextBox = CType(pnlAjaxHCFA.FindControl("txtChargesWhole" & lCounter), TextBox)
                lTextBox.enabled = False

                lTextBox = CType(pnlAjaxHCFA.FindControl("txtDays" & lCounter), TextBox)
                lTextBox.enabled = False

                lTextBox = CType(pnlAjaxHCFA.FindControl("txtNPI" & lCounter), TextBox)
                lTextBox.enabled = False

                lTextBox = CType(pnlAjaxHCFA.FindControl("txtEPSDT" & lCounter), TextBox)

                lTextBox.enabled = False
                lTextBox = CType(pnlAjaxHCFA.FindControl("txtEmergency" & lCounter), TextBox)
                lTextBox.enabled = False


                lCombo = CType(pnlAjaxHCFA.FindControl("cmbCOB" & lCounter), DropDownList)
                lCombo.enabled = False
            End If

        Next
        

    End Sub

    Private Function GetHCADetailForUpdate() As HCFADetailCollUpdated
        Dim lTextBox As TextBox
        Dim lDatePicker = New Telerik.WebControls.RadDatePicker
        Dim lHCFADetailCollUpdated As HCFADetailCollUpdated
        lHCFADetailCollUpdated = CType(Session("HCFADtlCol"), HCFADetailCollUpdated)

        Dim lCounter As Integer = 1

        For Each Item As HCFADetailDBUpdated In lHCFADetailCollUpdated

            With Item
                lTextBox = CType(pnlAjaxHCFA.FindControl("txtPlaceOfService" & lCounter), TextBox)
                .ServiceFacility.FacilityCode = lTextBox.Text.ToString


                lTextBox = CType(pnlAjaxHCFA.FindControl("txtDignosisPointer" & lCounter), TextBox)
                .DignosisPointer = lTextBox.Text

                lTextBox = CType(pnlAjaxHCFA.FindControl("txtNPI" & lCounter), TextBox)
                If (lTextBox.Text <> "") Then
                    .RenderingProvider.NPI = lTextBox.Text
                Else
                    .RenderingProvider.NPI = ""
                End If

            End With
            lCounter = lCounter + 1
        Next

        Session("HCFADtlCol") = lHCFADetailCollUpdated
        Return lHCFADetailCollUpdated
    End Function

    Public Sub LoadHCFASendDate()
        Dim lHCFAUpdated As HCFADBUpdated
        lHCFAUpdated = CType(Session("HCFADBUpdated"), HCFADBUpdated)
        If lHCFAUpdated.IsBatch = "Y" Then
            Me.rdpSendByOtherMeans.DbSelectedDate = ClaimMethods.GetClaimSendDate(lHCFAUpdated.HCFAID)
        Else
            Me.rdpSendByOtherMeans.DbSelectedDate = Nothing
        End If

    End Sub

    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload

    End Sub

    Protected Sub btnEditRenPvd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnEditRenPvd.Click
        Dim lHCFADBUpdated As HCFADBUpdated
        If (Session("HCFADBUpdated") Is Nothing) Then
            Exit Sub
        Else

            lHCFADBUpdated = CType(Session("HCFADBUpdated"), HCFADBUpdated)

        End If
        With lHCFADBUpdated

            Me.txtProviderName.Text = vbCrLf & .RenderingProvider.LastName & " " & .RenderingProvider.FirstName & " " & .RenderingProvider.MiddleName & " " & .RenderingProvider.Degree
         
        End With
    End Sub

    Public Sub PageExpire()
        Response.Buffer = True
        Response.ExpiresAbsolute = Now.Subtract(New TimeSpan(1, 0, 0, 0))
        Response.Expires = 0
        Response.CacheControl = "no-cache"
    End Sub
End Class
