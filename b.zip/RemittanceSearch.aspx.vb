Imports Telerik.WebControls
Imports System.xml
Imports System.IO
Imports Rebex.Net
Imports System.Diagnostics
Imports System.Threading
Partial Class Billing_RemittanceSearch
    Inherits System.Web.UI.Page

#Region "Search Claims"
    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSearch.Click
        Try
            'txtPatientID.Text = ""
            'btnBackPS.Visible = False
            grdSearch.Rebind()
        Catch ex As Exception
            lblErrorMsg.Text = ex.Message
            lblErrorMsg.Visible = True
        End Try
    End Sub
    Protected Sub grdSearch_ItemDataBound(ByVal sender As Object, ByVal e As Telerik.WebControls.GridItemEventArgs) Handles grdSearch.ItemDataBound


        Try
            If (e.Item.ItemType = GridItemType.Item Or e.Item.ItemType = GridItemType.AlternatingItem) Then

                Dim lItem As GridDataItem = CType(e.Item, GridDataItem)
                Dim lImgBtn As ImageButton

                Dim lDataItem As GridDataItem = CType(e.Item, GridDataItem)
                Dim lHyplnk As HyperLink = CType(lDataItem.Cells(9).Controls(0), HyperLink)
                Dim ldate As Date = e.Item.Cells(3).Text
                e.Item.Cells(3).Text = ldate.Date
                If (e.Item.Cells(12).Text.ToUpper = "Y") Then
                    lImgBtn = CType(lItem("PostPayment").Controls(0), ImageButton)
                    lImgBtn.ImageUrl = "../Images/Posted.gif"
                    lImgBtn.Enabled = False
                    lImgBtn.Style.Add("cursor", "default")
                    lImgBtn.ToolTip = "Payment already posted"
                ElseIf (e.Item.Cells(12).Text.ToUpper = "N") Then
                    lImgBtn = CType(lItem("PostPayment").Controls(0), ImageButton)
                    lImgBtn.ImageUrl = "../Images/post.gif"
                    lImgBtn.Enabled = True
                    lImgBtn.Style.Add("cursor", "default")
                    lImgBtn.ToolTip = "Post remittance"
                ElseIf (e.Item.Cells(12).Text.ToUpper = "NA") Then
                    lImgBtn = CType(lItem("PostPayment").Controls(0), ImageButton)
                    lImgBtn.ImageUrl = "../Images/Not-Allowed.gif"
                    lImgBtn.Enabled = False
                    lImgBtn.Style.Add("cursor", "default")
                    lImgBtn.ToolTip = "Payment not applicable"
                End If
                'lHyplnk.NavigateUrl = "RemittanceReport.aspx" + ElixirLibrary.Encryption.EncryptQueryString("rid=" & e.Item.Cells(2).Text)
            End If
        Catch ex As Exception
        End Try
    End Sub
    Protected Sub grdSearch_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdSearch.NeedDataSource
        'If (Not Page.IsPostBack) Then
        '    Exit Sub
        'End If

        Dim lConditon As String = ""
        Dim lRemittanceMethod As New RemittanceMethods
        Dim lds As New DataSet
        Dim lUser As New User
        Try
            If (txtPayeeName.Text <> "") Then
                lConditon += " and hdr.PayeeName like'%" + Utility.AdjustApostrophie(txtPayeeName.Text) + "%'"
            End If
            If (txtPayerName.Text <> "") Then
                lConditon += " and hdr.PayerName like'%" + Utility.AdjustApostrophie(txtPayerName.Text) + "%'"
            End If
            If (txtChequeNo.Text <> "") Then
                lConditon += " and hdr.CheckNumber='" + Utility.AdjustApostrophie(txtChequeNo.Text) + "'"
            End If
            '''''by madiha''''
            If (rdpFrom.SelectedDate.HasValue) Then
                lConditon += " and hdr.CheckDate between '" & rdpFrom.SelectedDate.GetValueOrDefault & "' and '" & rdpTo.SelectedDate.GetValueOrDefault & "'"
            End If
            If (txtcheckAmount.Text <> "") Then
                lConditon += " and hdr.CheckAmount='" + Utility.AdjustApostrophie(txtcheckAmount.Text) + "'"
            End If
            If (cmbPatient.Text <> "") Then
                'lConditon += " and Cdtl.PatientLastName + ',' + Cdtl.PatientFirstName='" + Utility.AdjustApostrophie(cmbPatient.Text) + "'"
                Dim lPatientName As String = String.Empty
                lPatientName = cmbPatient.Text.Replace(", ", ",")
                lConditon += "  and hdr.RemittanceId IN(select Cdtl.RemittanceId from [dbo].[RemittanceClaimDtl] Cdtl where hdr.RemittanceId=Cdtl.RemittanceId  and  Cdtl.PatientLastName + ',' + Cdtl.PatientFirstName='" + Utility.AdjustApostrophie(lPatientName) + "')"

            End If
            If (txtClaimId.Text <> "") Then
                Dim ltemp() As String
                Dim lclaimId As String = String.Empty
                Try
                    lUser = Session("User")
                    ltemp = txtClaimId.Text.Split("-")
                    'lclaimId = ltemp(1) + ltemp(2) + ltemp(3)
                    'lConditon += " and Sdtl.RemittanceClaimId='" + Utility.AdjustApostrophie(lclaimId) + "'"
                    lclaimId = "CL" + lUser.ClinicId + "H" + ltemp(1) + ltemp(2) + ltemp(3)
                    lConditon += " and hdr.RemittanceId IN(select Cdtl.RemittanceId from [dbo].[RemittanceClaimDtl] Cdtl where hdr.RemittanceId=Cdtl.RemittanceId and Cdtl.RemittanceClaimId='" + Utility.AdjustApostrophie(lclaimId) + "')"

                Catch ex As Exception

                End Try
                
            End If
            ''''''''''''''''''

            lds = lRemittanceMethod.loadGrid(lConditon)
            grdSearch.DataSource = lds
            If (lds Is Nothing) Then
                lblErrorMsg.Text = "Error Loading Grid"
                lblErrorMsg.Visible = True
            End If
        Catch ex As Exception
            lblErrorMsg.Text = ex.Message
            lblErrorMsg.Visible = True
        End Try
    End Sub
    Protected Sub grdSearch_PageIndexChanged(ByVal source As Object, ByVal e As Telerik.WebControls.GridPageChangedEventArgs) Handles grdSearch.PageIndexChanged
        Try
            grdSearch.CurrentPageIndex = e.NewPageIndex
            grdSearch.Rebind()
        Catch ex As Exception
        End Try
    End Sub
#End Region

#Region "Get New Remittance Files From Gateway Work"


    'Private Function DecryptRemittanceFiles(ByVal pPath As String) As String
    '    Dim lDirectoryinfo As DirectoryInfo
    '    Dim lFileInfo() As FileInfo
    '    Dim lUser As User
    '    Dim lKeyFile As String = CType(ConfigurationManager.AppSettings("ClaimResponsePath"), String)
    '    Dim lStatus As Boolean
    '    Dim lResult As String = ""

    '    Try
    '        lUser = CType(HttpContext.Current.Session.Item("User"), User)
    '        lKeyFile = lKeyFile & lUser.ClinicId & "\key\" & lUser.ClinicId & ".key"

    '        lDirectoryinfo = New DirectoryInfo(pPath)
    '        lFileInfo = lDirectoryinfo.GetFiles("*.enc")

    '        For Each lFile As FileInfo In lFileInfo
    '            lStatus = DecryptFile(lFile.FullName, lKeyFile)
    '            If Not lStatus Then
    '                lResult += lFile.FullName
    '            End If
    '        Next
    '        If lResult = "" Then
    '            Return "Successfully decrypted all files"
    '        Else
    '            Return "Can not decrypt following file(s) :" & lResult
    '        End If


    '    Catch ex As Exception
    '        Return "Error Decrypting files"
    '    End Try
    'End Function

    Private Function DecryptFile(ByVal lFileName As String, ByVal lKeyFileName As String) As Boolean

        Try
            Dim lOutputFileName As String
            Dim lProcessStartInfo As New ProcessStartInfo("cmd.exe")
            lProcessStartInfo.UseShellExecute = False
            lProcessStartInfo.RedirectStandardOutput = True
            lProcessStartInfo.RedirectStandardInput = True
            lProcessStartInfo.RedirectStandardError = True
            lProcessStartInfo.WorkingDirectory = "c:\"


            Dim lProcess As Process = Process.Start(lProcessStartInfo)

            'Dim lStreamReader As StreamReader = lProcess.StandardOutput
            Dim lStreamWriter As StreamWriter = lProcess.StandardInput

            lOutputFileName = Left(lFileName, lFileName.Length - 4)

            lStreamWriter.WriteLine("java decode " & lFileName & " " & lKeyFileName & " " & lOutputFileName)

            lProcess.CloseMainWindow()

            'lStreamReader.Close()
            lStreamWriter.Close()

            Return True
            

        Catch ex As Exception
            Return False
        End Try

    End Function

    Protected Sub ibtnGetRemittanceFiles_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ibtnGetRemittanceFiles.Click

        Dim lFtpClaimResponseGetResult As Boolean = False

        Try
            lFtpClaimResponseGetResult = GetFilesFromGatewayFtp()
            If (lFtpClaimResponseGetResult) Then
                Response.Write("<script>alert('New claim response files saved sucessfully.')</script>")
            Else
                Response.Write("<script>alert('Error saving new claim response files.')</script>")
            End If
            grdSearch.Rebind()



        Catch ex As Exception
            Response.Write("<script>alert('Error saving new claim response files.')</script>")
        End Try

    End Sub
    Public Function GetFilesFromGatewayFtp() As Boolean
        Dim lGatewayFtpLink As String = ""
        Dim lGatewayFtpUserID As String = ""
        Dim lGatewayFtpPassword As String = ""
        Dim lGatewayFtpClaimResponsePath As String = ""
        Dim lClient As Rebex.Net.Sftp
        Dim lFileDownloadPath As String = ""
        Dim lClinic As Clinic
        Dim lUser As User
        Dim lFtpFileList As SftpItemCollection
        Dim lFtpFileDeletePath As String = ""
        Dim lRemittanceHdrEntryResult As Boolean = False
        'Dim lAlreadyDownloadedFiles As ArrayList
        Dim lRemitanceMethod As RemittanceMethods

        Try
            lUser = CType(HttpContext.Current.Session("User"), User)
            lClient = New Rebex.Net.Sftp
            lClinic = New Clinic(lUser.ConnectionString)
            lFileDownloadPath = GetLocalClaimResponseSavePath()
            'lAlreadyDownloadedFiles = New ArrayList
            lRemitanceMethod = New RemittanceMethods
            'lAlreadyDownloadedFiles = lRemitanceMethod.GetAlreadyDownloadedFiles()
            lClinic.Clinic.ClinicId = lUser.ClinicId
            lClinic.GetRecordByID()
            lGatewayFtpUserID = lClinic.Clinic.GatewayFtpUserID
            lGatewayFtpPassword = lClinic.Clinic.GatewayFtpPassword
            lGatewayFtpClaimResponsePath = CType(ConfigurationManager.AppSettings("GatewayFtpClaimResponsePath"), String)
            lGatewayFtpLink = CType(ConfigurationManager.AppSettings("GatewayFtpLink"), String)
            lClient.Connect(lGatewayFtpLink)
            lClient.Login(lGatewayFtpUserID, lGatewayFtpPassword)
            lClient.GetFiles(lGatewayFtpClaimResponsePath & "*", lFileDownloadPath, SftpBatchTransferOptions.Recursive, SftpActionOnExistingFiles.OverwriteAll)
            lClient.ChangeDirectory(lGatewayFtpClaimResponsePath)
            lFtpFileList = lClient.GetList()
            For Each lListItem As SftpItem In lFtpFileList
                lFtpFileDeletePath = lGatewayFtpClaimResponsePath & lListItem.Name '"/remits/" & lTest
                'If (Not lAlreadyDownloadedFiles.Contains(lListItem.Name)) Then
                lRemittanceHdrEntryResult = RemittanceHdrDtlEntry(lFileDownloadPath & "\" & lListItem.Name)
                'Else
                'lRemittanceHdrEntryResult = True
                'End If
                'lRemittanceHdrEntryResult = RemittanceHdrDtlEntry(lFileDownloadPath & "\notOurs.rmt")      


                If (lRemittanceHdrEntryResult) Then
                    lClient.DeleteFile(lFtpFileDeletePath)
                    lRemittanceHdrEntryResult = False
                End If
            Next
            Return True
        Catch ex As Exception
            Return False
        Finally
            If (lClient IsNot Nothing) Then
                If (lClient.State = SftpState.Connected) Then
                    lClient.Disconnect()
                    lClient.Dispose()
                End If
            End If
        End Try
    End Function
    Public Function GetLocalClaimResponseSavePath() As String
        Dim lPath As String = ""
        Dim lUser As User
        Dim lDirectoryInfo As DirectoryInfo
        Try
            lUser = CType(HttpContext.Current.Session.Item("User"), User)
            lPath = CType(ConfigurationManager.AppSettings("ClaimResponsePath"), String)
            lDirectoryInfo = New DirectoryInfo(lPath)
            If Not lDirectoryInfo.Exists Then
                lDirectoryInfo.Create()
            End If
            lPath = CType(ConfigurationManager.AppSettings("ClaimResponsePath"), String) + lUser.ClinicId
            lDirectoryInfo = New DirectoryInfo(lPath)
            If Not lDirectoryInfo.Exists Then
                lDirectoryInfo.Create()
            End If
            lPath = CType(ConfigurationManager.AppSettings("ClaimResponsePath"), String) + lUser.ClinicId + "\ClaimResponse835"
            lDirectoryInfo = New DirectoryInfo(lPath)
            If Not lDirectoryInfo.Exists Then
                lDirectoryInfo.Create()
            End If
            Return lPath
        Catch ex As Exception
            Return ""
        End Try
    End Function
#End Region

#Region "Remittance Header Detail Entry code"
    Public Function RemittanceHdrDtlEntry(ByVal pFilePath As String) As Boolean
        Dim lStrPath As String
        Dim lStrReader As StreamReader
        Dim lStrEdi835 As String
        Dim lRemittanceHdrPostingResult As Boolean = False
        Dim lStatus As Boolean
        Dim lKeyFile As String = CType(ConfigurationManager.AppSettings("ClaimResponsePath"), String)
        Dim lUser As User
        Dim lFileInfo As FileInfo

        Try


            lUser = CType(HttpContext.Current.Session.Item("User"), User)
            lKeyFile = lKeyFile & lUser.ClinicId & "\key\" & lUser.ClinicId & ".key"

            lStrPath = pFilePath
            If pFilePath.ToUpper.Contains(".ENC") Then
                lStatus = DecryptFile(pFilePath, lKeyFile)
                lStrPath = Left(pFilePath, pFilePath.Length - 4)
                Thread.Sleep(1000)
            End If



            lStrReader = New StreamReader(lStrPath)
            lStrEdi835 = lStrReader.ReadToEnd
            lStrReader.Close()
            If (lStrEdi835 <> "") Then
                lRemittanceHdrPostingResult = PostRemittanceHdr(lStrPath, lStrEdi835)
            Else
                Return False
            End If

            If pFilePath.ToUpper.Contains(".ENC") Then
                lFileInfo = New FileInfo(pFilePath)
                lFileInfo.Delete()
            End If



            Return lRemittanceHdrPostingResult
        Catch ex As Exception
            Return False
        End Try
    End Function
    Protected Function PostRemittanceHdr(ByVal pStrFileNameAndPath As String, ByVal pEdi835 As String) As Boolean
        Dim lBoolResult As Boolean
        Dim lRemitanceMethods As RemittanceMethods
        Dim lStrRTN As String = ""
        Dim lStrVersion As String = ""
        Try
            lRemitanceMethods = New RemittanceMethods()
            lStrVersion = lRemitanceMethods.CheckVersion(pEdi835)

            If (lStrVersion = "5010") Then
                lStrRTN = lRemitanceMethods.GetRTN5010(pEdi835)
            ElseIf (lStrVersion = "4010") Then
                lStrRTN = lRemitanceMethods.GetRTN(pEdi835)
            End If
            If (lStrRTN <> "") Then
                If (lRemitanceMethods.CheckIfExist(lStrRTN) AndAlso lRemitanceMethods.IsContentExist(pEdi835)) Then
                    'lRemitanceMethods.MoveFiles(pStrFileNameAndPath, pStrFileNameAndPath.Replace("ClaimResponse835", "ClaimResponse835Archive"))
                    lBoolResult = True
                Else
                    If (lStrVersion = "5010") Then
                        lBoolResult = lRemitanceMethods.PostRemittanceHeaderOnly(pStrFileNameAndPath, pEdi835, True)
                    ElseIf (lStrVersion = "4010") Then
                        lBoolResult = lRemitanceMethods.PostRemittanceHeaderOnly(pStrFileNameAndPath, pEdi835, False)
                    End If
                End If
            Else
                Return False
            End If
            Return lBoolResult
        Catch ex As Exception
            Return False
        End Try
    End Function
#End Region

#Region "Post Payment"
    Protected Sub grdSearch_ItemCommand(ByVal source As Object, ByVal e As Telerik.WebControls.GridCommandEventArgs) Handles grdSearch.ItemCommand
        Dim lStrPath As String = ""
        Dim lStrReader As StreamReader
        Dim lStrEdi835 As String
        Dim lpath As String
        Dim lUser As User

        Try

            If (e.CommandName = "PostPayment") Then
                Dim lRemittanceId As String = e.Item.Cells(2).Text
                'lUser = CType(Session.Item("User"), User)
                'lpath = System.Configuration.ConfigurationManager.AppSettings("ClaimRquestPath").ToString() & lUser.ClinicId.ToString & "\" & "ClaimResponse835\"
                'lStrPath = lpath & e.Item.Cells(8).Text
                'If File.Exists(lStrPath) Then
                'lStrReader = New StreamReader(lStrPath)
                lRemittanceId = e.Item.Cells(2).Text
                lStrEdi835 = GetRemittanceContent(lRemittanceId) 'lStrReader.ReadToEnd
                'lStrReader.Close()
                If (lStrEdi835 <> "") Then
                    PostPayment(lStrPath, lStrEdi835, e.Item.Cells(13).Text, e.Item.Cells(3).Text)
                Else
                    Response.Write("<script language='javascript'>alert('No file found.');history.go(-(history.length));window.location='RemittanceSearch.aspx';</script>")
                End If
                'Else
                '    'Response.Write("<script>alert('No file found.');</script>")
                '    Response.Write("<script language='javascript'>alert('No file found.');history.go(-(history.length));window.location='RemittanceSearch.aspx';</script>")

            End If
            'End If


        Catch ex As Exception
            Response.Write("<script>alert('An error has occured while processing the request.');</script>")
        End Try
    End Sub
    Protected Sub PostPayment(ByVal pStrFileNameAndPath As String, ByVal pEdi835 As String, ByVal pPayerID As String, ByVal pTRN As String)
        Dim lBoolResult As Boolean
        Dim lRemitanceMethods As RemittanceMethods
        Dim lStrRTN As String = ""
        Dim lPatymentID As String = ""
        Dim lDSFavInsurance As DataSet
        Dim lInsurance As Insurance
        Dim lPayerId As String = ""
        Dim lUser As User
        Dim lStrVersion As String = ""

        Try
            lRemitanceMethods = New RemittanceMethods()

            lStrVersion = lRemitanceMethods.CheckVersion(pEdi835)

            lUser = CType(Session("User"), User)
            lInsurance = New Insurance(lUser.ConnectionString)

            lDSFavInsurance = New DataSet
            lDSFavInsurance = lInsurance.GetInsuranceRecords(" And PayerID='" & pPayerID & "'")
            If (lDSFavInsurance.Tables(0).Rows.Count > 0) Then
                lPayerId = lDSFavInsurance.Tables(0).Rows(0).Item("FavouriteInsuranceID").ToString
            End If

            lPatymentID = lRemitanceMethods.CheckIfAlreadyPosted(lPayerId, pTRN)
            If (lPatymentID <> "0") Then
                'Response.Write("<script>function DuplicateCheck(){var lResult = confirm('Pament already posted,do you want to change the flag?');" _
                '                & " If (lResult) Then {  var oButton = document.getElementById('<%=btnPostPaymentHidden.ClientID%>');  oButton.click(); }}</script>")
                'Response.Write("<script>alert('Payement already posted.'); </script>")
                Response.Write("<script language='javascript'>alert('Payement already posted.');history.go(-(history.length));window.location='RemittanceSearch.aspx';</script>")

            Else
                If (lStrVersion = "5010") Then
                    lBoolResult = lRemitanceMethods.PostRemittance5010(pStrFileNameAndPath, pEdi835, True)
                ElseIf (lStrVersion = "4010") Then
                    lBoolResult = lRemitanceMethods.PostRemittance(pStrFileNameAndPath, pEdi835)
                End If

                If lBoolResult = True Then
                    'Response.Write("<script>alert('Payement posted successfully.');</script>")
                    Response.Write("<script language='javascript'>alert('Payement posted successfully.');history.go(-(history.length));window.location='RemittanceSearch.aspx';</script>")

                Else
                    'Response.Write("<script>alert('An error has occured while processing the request.');</script>")
                    Response.Write("<script language='javascript'>alert('An error has occured while processing the request.');history.go(-(history.length));window.location='RemittanceSearch.aspx';</script>")

                End If
                '    End If
                'End If
                grdSearch.Rebind()
            End If
            'lStrRTN = lRemitanceMethods.GetRTN(pEdi835)
            'If (lStrRTN <> "") Then
            '    If (lRemitanceMethods.CheckIfExist(lStrRTN)) Then
            '        Response.Write("<script>alert('Payement already posted.');</script>")
            '        lRemitanceMethods.MoveFiles(pStrFileNameAndPath, pStrFileNameAndPath.Replace("ClaimResponse835", "ClaimResponse835Archive"))
            '    Else
        Catch ex As Exception
            Response.Write("<script>alert('An error has occured while processing the request.');</script>")
        End Try
    End Sub
    Public Function GetRemittanceContent(ByVal pRemittanceId As String) As String
        Dim lRemittanceHdr As RemittanceHdr
        Dim lUser As OASystems.User
        Dim lEdiContent As String = ""
        Try
            lUser = CType(Session("User"), User)
            lRemittanceHdr = New RemittanceHdr(lUser.ConnectionString)
            lRemittanceHdr.RemittanceHdr.RemittanceId = pRemittanceId
            lRemittanceHdr.GetRecordByID()
            lEdiContent = lRemittanceHdr.RemittanceHdr.FileContent
        Catch ex As Exception
            lEdiContent = ""
        End Try
        Return lEdiContent
    End Function
#End Region

    Protected Sub btnPostPaymentHidden_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnPostPaymentHidden.Click

        Try

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim queryString As NameValueCollection = Nothing
        Dim lPatientID As String
        Try
            If IsPostBack = False Then

                chk5010.Visible = False
                If (ConfigurationManager.AppSettings.Item("EdiVersion").ToString = "5010") Then
                    chk5010.Checked = True
                Else
                    chk5010.Checked = False
                End If

                Dim lUser As User
                lUser = CType(Session("User"), User)
                rdpTo.SelectedDate = Date.Now
                rdpFrom.SelectedDate = Date.Now.AddMonths(-6)
                If (Request.QueryString.Count > 0) Then
                    queryString = Encryption.DecryptQueryString(Request.QueryString.ToString())
                    If (queryString IsNot Nothing) Then
                        lPatientID = queryString("id").ToString
                        txtPatientID.Text = lPatientID
                        Dim lPatient As New PatientDBExtended
                        lPatient = PatientMethods.LoadPatientsById(lPatientID, lUser)
                        cmbPatient.Text = lPatient.LastName & "," & lPatient.FirstName
                        grdSearch.Rebind()
                        btnBackPS.Visible = True

                    End If
                End If
            End If
        Catch ex As Exception

        End Try

    End Sub

    Protected Sub btnMirror_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnMirror.Click
        Dim newWindow As RadWindow
        Try
            newWindow = New RadWindow()
            If (cmbPatient.Text.ToString.Split(",").Length = 1) Then
                newWindow.NavigateUrl = "PatientSearch.aspx?srch=" & Utility.AdjustApostrophie(Me.cmbPatient.Text.ToString.Split(",")(0)) & "|" & "" & ""
            ElseIf (cmbPatient.Text.ToString.Split(",").Length > 1) Then
                newWindow.NavigateUrl = "PatientSearch.aspx?srch=" & Utility.AdjustApostrophie(Me.cmbPatient.Text.ToString.Split(",")(0)) & "|" & Me.cmbPatient.Text.ToString.Split(",")(1) & ""
            Else

            End If
            newWindow.ID = "rwPrimaryInsurer"
            newWindow.VisibleOnPageLoad = True
            newWindow.Top = 220
            newWindow.Left = 280
            newWindow.Width = Unit.Pixel(697)
            newWindow.Height = Unit.Pixel(400)
            newWindow.VisibleTitlebar = False
            newWindow.VisibleStatusbar = False
            newWindow.BorderStyle = BorderStyle.Solid
            newWindow.ReloadOnShow = True
            newWindow.BackColor = Drawing.Color.Transparent
            newWindow.ClientCallBackFunction = "PatientSearchCallBackFunction"
            newWindow.Enabled = True
            newWindow.Visible = True
            rwmSuperBill.Windows.Add(newWindow)
        Catch ex As Exception
            Dim lLogID As String = String.Empty
            lLogID = ErrorLogMethods.LogError(ex, " Billing_PatientLedgerPage.aspx\btnMirror_Click() ")
            Response.Redirect("~/ErrorPage.aspx?LogID=" & lLogID, False)
        End Try
    End Sub

    Protected Sub btnBackPS_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnBackPS.Click
        Dim lPatientID As String
        Try
            lPatientID = ElixirLibrary.Encryption.EncryptQueryString("id=" & txtPatientID.Text)
            Response.Redirect("selectpatient.aspx" & lPatientID)
        Catch ex As Exception

        End Try
    End Sub
End Class
