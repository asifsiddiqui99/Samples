Imports Telerik.WebControls
Partial Class Billing_EditPatientSuperBill
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim lID As String = String.Empty
        Dim queryString As NameValueCollection = Nothing
        tsGenerateSuperBill.SelectedIndex = 0
        mpGenerateSuperBill.SelectedIndex = 0
        '**Define Datasource to Modifiers
        If (Not Page.IsPostBack) Then
            LoadModifierCombos()
        End If

        Try 'USED THIS BECAUSE LOAD WAS BEING CALLED WHEN THE ICD WAS SELECTED, AND IT LED TO THE DECRYPTION CRASHING. POSTBACK WAS CREATING PROBLEMS
            queryString = Encryption.DecryptQueryString(Request.QueryString.ToString())
        Catch ex As Exception
            Return
        End Try


        If queryString Is Nothing OrElse queryString("sid") Is Nothing Then
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "scrollview", "<script type='text/javascript'>FirstRowEmpty();</script>")
            Return
        Else : lID = queryString("sid").ToString
        End If

        txtPatientSuperBillId.Text = lID.Split("|")(0)
        txtSuperBillTemplateId.Text = lID.Split("|")(2)
        txtPatientID.Text = lID.Split("|")(1)


        If Not Page.IsPostBack Then
            Me.dtVisitDisplayDate.MaxDate = Date.Now.Date
            EmployeeMethods.LoadDoctorsCombo(cmbProvider)
            LoadClinic()
            LoadPatient(txtPatientSuperBillId.Text)
            LoadSuperBillOrderInformation()
            SelectProviderComboItem()
            LoadRefferingProviderCombo()

            setMaxDate()

            Me.ucntrlPatientBanner.SetBannerValues(txtPatientID.Text)
            Me.dtVisitDisplayDate.MaxDate = DateTime.Today
        End If


        ''Check if controls have to be disabled to make this page available for viewing only (in case of Approved Superbill) or for editing
        If ((lID.Split("|")(4)) = "A") Then
            hdrBar.Visible = True
            'DisableControls(LowerPanel)
            DisableControls(pnlMain)
            btnSave.Enabled = False
            btnSaveCopy.Enabled = False
            'btnSavenPrint.Enabled = False
            checkapprove.Disabled = True
            checkapprove.Checked = True
            txtApproved.Text = "A"
            btnEditVisit.Enabled = True
            btnEditVisit.ImageUrl = "~/Images/make-editable-off.gif"
            dtVisitDisplayDate.Enabled = False
            For index As Int16 = 1 To 6
                CType(FindControl("ctl00$ContentPlaceHolder1$imgRev" & index), ImageButton).Enabled = False
                CType(FindControl("ctl00$ContentPlaceHolder1$imgRev" & index), ImageButton).ImageUrl = "../Images/reverse-disable.gif"
                CType(FindControl("ctl00$ContentPlaceHolder1$imgRev" & index), ImageButton).Style.Add("cursor:default", "cursor:default")
            Next
            For index As Int16 = 1 To 6
                CType(FindControl("ctl00$ContentPlaceHolder1$imgBtn" & index), ImageButton).Enabled = False
                CType(FindControl("ctl00$ContentPlaceHolder1$imgBtn" & index), ImageButton).ImageUrl = "../Images/false-ico-disable.gif"
                CType(FindControl("ctl00$ContentPlaceHolder1$imgBtn" & index), ImageButton).Style.Add("cursor:default", "cursor:default")
            Next
        Else

            checkapprove.Disabled = False
            txtApproved.Text = "U"
            btnEditVisit.Enabled = False
            btnEditVisit.ImageUrl = "~/Images/make-editable-disable.gif"
            btnEditVisit.Style.Add("cursor:default", "cursor:default")
            dtVisitDisplayDate.Enabled = True
            txtLineId1.Text = "0"
            txtLineId2.Text = "0"
            txtLineId3.Text = "0"
            txtLineId4.Text = "0"
            txtLineId5.Text = "0"
            txtLineId6.Text = "0"
            For index As Int16 = 1 To 6
                CType(FindControl("ctl00$ContentPlaceHolder1$imgRev" & index), ImageButton).Enabled = False
                CType(FindControl("ctl00$ContentPlaceHolder1$imgRev" & index), ImageButton).ImageUrl = "../Images/reverse-disable.gif"
                CType(FindControl("ctl00$ContentPlaceHolder1$imgRev" & index), ImageButton).Style.Add("cursor:default", "cursor:default")
            Next
        End If
        If (Page.IsPostBack <> True) Then
            lblMessage.Text = "<script>display()</Script>"
        End If

        ' Me.btnCancel.OnClientClick = "javascript:window.history.go(-1);return false;"

    End Sub
    Private Sub LoadSuperBillOrderInformation()
        Dim lUser As User
        Dim lSuperBill As SuperBill
        Dim lResult As Boolean
        Dim lDS As DataSet = Nothing

        lUser = CType(Session.Item("User"), User)


        lSuperBill = New SuperBill(lUser.ConnectionString)
        lSuperBill.SuperBill.SuperBillId = txtSuperBillTemplateId.Text
        lResult = lSuperBill.GetRecordByID()

        If Not lResult Then
            Return
        End If

        With lSuperBill.SuperBill
            txtOrderBy.Text = lSuperBill.SuperBill.ICDSortBy & "|" & lSuperBill.SuperBill.ICDSortOrder & "|" & _
                                       lSuperBill.SuperBill.CPTSortBy & "|" & lSuperBill.SuperBill.CPTSortOrder
        End With


        loadICD9BillingGrid()
        LoadCPTBillingGrid()

    End Sub
    Private Sub LoadCPTBillingGrid()
        Dim lDS As DataSet = Nothing
        lDS = ClaimMethods.GetCPTForBillingGrid(txtPatientSuperBillId.Text)

        lDS.Tables(0).Columns.Add("Enabled", GetType(Boolean))

        Dim i As Integer
        For i = 0 To lDS.Tables(0).Rows.Count - 1
            lDS.Tables(0).Rows(i).Item("Enabled") = False
            If (Not IsDBNull(lDS.Tables(0).Rows(i).Item("NPI"))) Then
                Me.txtRenderringProviderNPI.Text = lDS.Tables(0).Rows(i).Item("NPI")
            End If
        Next

        'lDS.Tables(0).Rows.Add()
        'lDS.Tables(0).Rows(lDS.Tables(0).Rows.Count - 1).Item("CPTDate") = Now.Date
        'lDS.Tables(0).Rows(lDS.Tables(0).Rows.Count - 1).Item("Charges") = 0.0
        'lDS.Tables(0).Rows(lDS.Tables(0).Rows.Count - 1).Item("Fees") = 0.0
        'lDS.Tables(0).Rows(lDS.Tables(0).Rows.Count - 1).Item("DateOfServiceTo") = Now.Date
        'lDS.Tables(0).Rows(lDS.Tables(0).Rows.Count - 1).Item("DateOfServiceFrom") = Now.Date
        'lDS.Tables(0).Rows(lDS.Tables(0).Rows.Count - 1).Item("Enabled") = True
        'lDS.Tables(0).Rows(lDS.Tables(0).Rows.Count - 1).Item("Days") = 1
        'lDS.Tables(0).Rows(lDS.Tables(0).Rows.Count - 1).Item("Pointer") = 1
        'lDS.Tables(0).Rows(lDS.Tables(0).Rows.Count - 1).Item("LineId") = 0

        LoadModifier(lDS)

        If lDS.Tables(0).Rows.Count <= 1 Then
            hdnText.Text = 0
        Else
            hdnText.Text = lDS.Tables(0).Rows.Count - 1
        End If


    End Sub
    Private Sub LoadClinic()
        Dim lUser As User
        Dim lClinic As ClinicDB
        Dim lState As StateDB
        Dim lPatientSuperBill As PatientSuperBill
        Dim lFormatedSuperBillId As String
        lUser = CType(Session("User"), User)
        If (lUser IsNot Nothing) Then


            lClinic = ClinicMethods.GetClinic(lUser)
            lPatientSuperBill = New PatientSuperBill(lUser.ConnectionString)

            If (lClinic IsNot Nothing) Then
                lblClinicName.Text = lClinic.ClinicName
                lblClinicAddress.Text = lClinic.AddressLine1
                lblClinicCity.Text = lClinic.City
                If lClinic.ZipCode.Length > 5 Then
                    lblClinicZipCode.Text = lClinic.ZipCode.ToString.Substring(0, 5) + "-" + lClinic.ZipCode.ToString.Substring(5, 4)
                Else
                    lblClinicZipCode.Text = lClinic.ZipCode
                End If

                lState = StateMethods.GetState(lClinic.StateId)
                lblClinicState.Text = lState.Abbr

                LoadFacilityCombo(lUser, lClinic.FacilityId)
            End If

            lPatientSuperBill.PatientSuperBill.PatientSuperBillID = txtPatientSuperBillId.Text
            lPatientSuperBill.GetRecordByID()

            lFormatedSuperBillId = Date.Parse(lPatientSuperBill.PatientSuperBill.EntryDate).Year & "-" & Date.Parse(lPatientSuperBill.PatientSuperBill.EntryDate).ToString("MM") & "-" & lPatientSuperBill.PatientSuperBill.PatientSuperBillDisplayID.PadLeft(5, "0")
            lblSuperBillID.Text = "SB-" & lFormatedSuperBillId

            Me.txtRefferingProviderNPI.Text = lPatientSuperBill.PatientSuperBill.ReferringProviderNPI
        End If
    End Sub
    Private Sub LoadPatient(ByVal pPatientSuperBillID As String)
        Dim lDataSet As DataSet = Nothing
        lDataSet = SuperBillMethods.GetPatientSuperBill(pPatientSuperBillID)
        Dim lUser As User = CType(Session("User"), User)
        Dim lItem As New RadComboBoxItem
        Dim lFacility As Facility
        lFacility = New Facility(lUser.ConnectionString)

        If (lUser IsNot Nothing) Then
            If (lDataSet IsNot Nothing) AndAlso (lDataSet.Tables(0).Rows.Count > 0) Then
                txtHdnPatPriInsID.Text = lDataSet.Tables(0).Rows(0).Item("PrimaryInsuranceCompanyId").ToString().Trim()

                If Session("InsuranceCompanyID") IsNot Nothing Then
                    Session("InsuranceCompanyID") = txtHdnPatPriInsID.Text.Trim()
                Else
                    Session.Add("InsuranceCompanyID", txtHdnPatPriInsID.Text.Trim())
                End If

                lblPatientName.Text = lDataSet.Tables(0).Rows(0).Item("PatientName").ToString
                lblPatientDOB.Text = lDataSet.Tables(0).Rows(0).Item("DOB").ToString.Split(" ")(0)
                lblPatientAddress.Text = lDataSet.Tables(0).Rows(0).Item("Address").ToString
                lblPatientCity.Text = lDataSet.Tables(0).Rows(0).Item("City").ToString
                lblPatientState.Text = lDataSet.Tables(0).Rows(0).Item("State").ToString
                lblPatientZipCode.Text = lDataSet.Tables(0).Rows(0).Item("ZipCode").ToString
                lblPrimaryInsuranceCompany.Text = lDataSet.Tables(0).Rows(0).Item("PrimaryInsuranceCompanyName").ToString
                lblSecondaryInsuranceCompany.Text = lDataSet.Tables(0).Rows(0).Item("SecondryInsuranceCompanyName").ToString
                lblGuarantorName.Text = lDataSet.Tables(0).Rows(0).Item("GuarantorName").ToString
                lblBalance.Text = lDataSet.Tables(0).Rows(0).Item("Balance").ToString
                Me.txtCopayAmount.Text = lDataSet.Tables(0).Rows(0).Item("CopayAmount").ToString
                lblCopayAmount.Text = IIf(lDataSet.Tables(0).Rows(0).Item("PaymentMethod").Equals(""), "", lDataSet.Tables(0).Rows(0).Item("CopayAmount").ToString)
                Utility.SelectComboItem(Me.cmbPaymentMethod, lDataSet.Tables(0).Rows(0).Item("PaymentMethod").ToString, False)
                lblPaymentMethod.Text = lDataSet.Tables(0).Rows(0).Item("PaymentMethod").ToString
                If (lDataSet.Tables(0).Rows(0).Item("PaymentMethod").ToString = "Cheque") Then
                    Me.dtChequeDate.Enabled = True
                    Me.txtChequeNumber.Enabled = True
                Else
                    Me.dtChequeDate.Enabled = False
                    Me.txtChequeNumber.Enabled = False
                End If
                Me.txtChequeNumber.Text = lDataSet.Tables(0).Rows(0).Item("ChequeNumber").ToString
                lblChequeNumber.Text = lDataSet.Tables(0).Rows(0).Item("ChequeNumber").ToString
                Me.dtChequeDate.SelectedDate = lDataSet.Tables(0).Rows(0).Item("ChequeDate").ToString
                If (lDataSet.Tables(0).Rows(0).Item("ChequeDate").ToString = "1/1/1900 12:00:00 AM") Then
                    lblChequeDate.Text = ""
                Else
                    lblChequeDate.Text = lDataSet.Tables(0).Rows(0).Item("ChequeDate").ToString.Split(" ")(0)
                End If
                lblDateOfService.Text = lDataSet.Tables(0).Rows(0).Item("DateOfService").ToString.Split(" ")(0) ' This was done to ensure that time does not get appended to the date: cudnt do it in the query cuz it was generalized
                Me.dtVisitDisplayDate.SelectedDate = lDataSet.Tables(0).Rows(0).Item("VisitDisplayDate").ToString
                txtSuperBillTemplateId.Text = lDataSet.Tables(0).Rows(0).Item("SuperBillTemplateID").ToString
                '' By Fareed for dispaly of Pateint Last VisitID "28 Nov 2008"
                '' Should be correct later
                Dim lQuery As String = "Select LastVisitDate=convert(varchar,max(DateofService),101) from patientsuperbill where patientid=" & lDataSet.Tables(0).Rows(0).Item("PatientId").ToString & "and patientsuperbillid<" & pPatientSuperBillID & "group by patientid"
                Dim lConnection As New Connection(lUser.ConnectionString)
                Dim lDs As DataSet = Nothing
                lDs = lConnection.ExecuteQuery(lQuery)
                If ((lDs IsNot Nothing) AndAlso (lDs.Tables(0).Rows.Count > 0)) Then
                    Me.lblLastVisitDate.Text = lDs.Tables(0).Rows(0).Item("LastVisitDate").ToString
                Else
                    Me.lblLastVisitDate.Text = ""
                End If
                '' Should be correct later
                Dim lEmployeeDs As New DataSet
                lEmployeeDs = EmployeeMethods.GetEmployeeByID(lUser, lDataSet.Tables(0).Rows(0).Item("PrescriberID").ToString)
                'lblPrescriberName.Text = EmployeeMethods.GetEmployeeByID(lUser, lDataSet.Tables(0).Rows(0).Item("PrescriberID").ToString).Tables(0).Rows(0).Item("EmployeeName")
                If (lEmployeeDs.Tables.Count > 0 AndAlso lEmployeeDs.Tables(0).Rows.Count > 0) Then
                    lblPrescriberName.Text = lEmployeeDs.Tables(0).Rows(0).Item("EmployeeName")
                Else
                    lblPrescriberName.Text = ""
                End If
                If (Me.txtRenderringProviderNPI.Text <> "" And Not Me.txtRenderringProviderNPI.Text Is Nothing) Then
                    cmbProvider.SelectedValue = lDataSet.Tables(0).Rows(0).Item("PrescriberID") & "|" & Me.txtRenderringProviderNPI.Text
                Else
                    If (lEmployeeDs.Tables.Count > 0 AndAlso lEmployeeDs.Tables(0).Rows.Count > 0) Then
                        cmbProvider.SelectedValue = lDataSet.Tables(0).Rows(0).Item("PrescriberID") & "|" & lEmployeeDs.Tables(0).Rows(0).Item("ID").ToString.Split("|")(1)
                    End If
                End If
                ViewState.Add("FavouriteInsuranceID", lDataSet.Tables(0).Rows(0).Item("PrimaryInsuranceCompanyId").ToString)
                LoadBillingProviderCombo(lUser, lDataSet.Tables(0).Rows(0).Item("PrimaryInsuranceCompanyId").ToString)

                If (lDataSet.Tables(0).Rows(0).Item("BillingProviderId").ToString <> "") Then
                    cmbBillingProvider.SelectedIndex = cmbBillingProvider.FindItemIndexByValue(lDataSet.Tables(0).Rows(0).Item("BillingProviderId").ToString)
                End If

                If (lDataSet.Tables(0).Rows(0).Item("FacilityID").ToString <> "") Then
                    If (cmbFacility.Items.FindByValue(lDataSet.Tables(0).Rows(0).Item("FacilityID").ToString) IsNot Nothing) Then
                        cmbFacility.SelectedIndex = cmbFacility.Items.IndexOf(cmbFacility.Items.FindByValue(lDataSet.Tables(0).Rows(0).Item("FacilityID").ToString))
                    Else
                        LoadFacilityCombo(lUser, lDataSet.Tables(0).Rows(0).Item("FacilityID").ToString)
                        cmbFacility.SelectedIndex = cmbFacility.Items.IndexOf(cmbFacility.Items.FindByValue(lDataSet.Tables(0).Rows(0).Item("FacilityID").ToString))
                    End If
                    SelectPosFacilityComboItem()
                End If

            End If
        End If
    End Sub
    Protected Sub grdCPT1_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdCPT1.NeedDataSource
        If Not (String.IsNullOrEmpty(txtPatientSuperBillId.Text) And String.IsNullOrEmpty(txtSuperBillTemplateId.Text) And String.IsNullOrEmpty(txtOrderBy.Text)) Then
            ClaimMethods.LoadClaimCPTGrid(grdCPT1, txtPatientSuperBillId.Text, txtSuperBillTemplateId.Text, txtOrderBy.Text, 0)
        End If
    End Sub
    Protected Sub grdCPT2_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdCPT2.NeedDataSource
        If Not (String.IsNullOrEmpty(txtPatientSuperBillId.Text) And String.IsNullOrEmpty(txtSuperBillTemplateId.Text) And String.IsNullOrEmpty(txtOrderBy.Text)) Then
            ClaimMethods.LoadClaimCPTGrid(grdCPT2, txtPatientSuperBillId.Text, txtSuperBillTemplateId.Text, txtOrderBy.Text, 1)
        End If
    End Sub
    Protected Sub grdCPT3_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdCPT3.NeedDataSource
        If Not (String.IsNullOrEmpty(txtPatientSuperBillId.Text) And String.IsNullOrEmpty(txtSuperBillTemplateId.Text) And String.IsNullOrEmpty(txtOrderBy.Text)) Then
            ClaimMethods.LoadClaimCPTGrid(grdCPT3, txtPatientSuperBillId.Text, txtSuperBillTemplateId.Text, txtOrderBy.Text, 2)
        End If
    End Sub
    Private Sub loadICD9BillingGrid()
        Dim lDS As DataSet
        lDS = ClaimMethods.GetICDForBillingGrid(txtPatientSuperBillId.Text)

        For x As Integer = 1 To 4
            If Not lDS.Tables(0).Rows.Count > x - 1 Then
                Exit For
            End If

            CType(pnlBillingInfo.FindControl("cmbICD" & x.ToString), RadComboBox).Text = lDS.Tables(0).Rows(x - 1).Item(0)
            CType(pnlBillingInfo.FindControl("txtICDDescription" & x.ToString), TextBox).Text = lDS.Tables(0).Rows(x - 1).Item(1)
            CType(pnlBillingInfo.FindControl("txtICDFromGrid" & x.ToString), TextBox).Text = lDS.Tables(0).Rows(x - 1).Item(2)
            CType(pnlBillingInfo.FindControl("txtIMO" & x.ToString), TextBox).Text = lDS.Tables(0).Rows(x - 1).Item("IMOCode")
        Next


        Select Case lDS.Tables(0).Rows.Count
            Case 1
                cmbICD1.Text = lDS.Tables(0).Rows(0).Item(0)
                txtICDDescription1.Text = lDS.Tables(0).Rows(0).Item(1)
                txtICDFromGrid1.Text = lDS.Tables(0).Rows(0).Item(2)
                txtIMO1.Text = lDS.Tables(0).Rows(0).Item("IMOCode")
            Case 2
                cmbICD1.Text = lDS.Tables(0).Rows(0).Item(0)
                txtICDDescription1.Text = lDS.Tables(0).Rows(0).Item(1)
                txtICDFromGrid1.Text = lDS.Tables(0).Rows(0).Item(2)
                txtIMO1.Text = lDS.Tables(0).Rows(0).Item("IMOCode")

                cmbICD2.Text = lDS.Tables(0).Rows(1).Item(0)
                txtICDDescription2.Text = lDS.Tables(0).Rows(1).Item(1)
                txtICDFromGrid2.Text = lDS.Tables(0).Rows(1).Item(2)
                txtIMO2.Text = lDS.Tables(0).Rows(1).Item("IMOCode")
            Case 3
                cmbICD1.Text = lDS.Tables(0).Rows(0).Item(0)
                txtICDDescription1.Text = lDS.Tables(0).Rows(0).Item(1)
                txtICDFromGrid1.Text = lDS.Tables(0).Rows(0).Item(2)
                txtIMO1.Text = lDS.Tables(0).Rows(0).Item("IMOCode")

                cmbICD2.Text = lDS.Tables(0).Rows(1).Item(0)
                txtICDDescription2.Text = lDS.Tables(0).Rows(1).Item(1)
                txtICDFromGrid1.Text = lDS.Tables(0).Rows(1).Item(2)
                txtIMO2.Text = lDS.Tables(0).Rows(1).Item("IMOCode")

                cmbICD3.Text = lDS.Tables(0).Rows(2).Item(0)
                txtICDDescription3.Text = lDS.Tables(0).Rows(2).Item(1)
                txtICDFromGrid3.Text = lDS.Tables(0).Rows(2).Item(2)
                txtIMO3.Text = lDS.Tables(0).Rows(2).Item("IMOCode")
            Case 4
                cmbICD1.Text = lDS.Tables(0).Rows(0).Item(0)
                txtICDDescription1.Text = lDS.Tables(0).Rows(0).Item(1)
                txtICDFromGrid1.Text = lDS.Tables(0).Rows(0).Item(2)
                txtIMO1.Text = lDS.Tables(0).Rows(0).Item("IMOCode")

                cmbICD2.Text = lDS.Tables(0).Rows(1).Item(0)
                txtICDDescription2.Text = lDS.Tables(0).Rows(1).Item(1)
                txtICDFromGrid2.Text = lDS.Tables(0).Rows(1).Item(2)
                txtIMO2.Text = lDS.Tables(0).Rows(1).Item("IMOCode")

                cmbICD3.Text = lDS.Tables(0).Rows(2).Item(0)
                txtICDDescription3.Text = lDS.Tables(0).Rows(2).Item(1)
                txtICDFromGrid3.Text = lDS.Tables(0).Rows(2).Item(2)
                txtIMO3.Text = lDS.Tables(0).Rows(2).Item("IMOCode")

                cmbICD4.Text = lDS.Tables(0).Rows(3).Item(0)
                txtICDDescription4.Text = lDS.Tables(0).Rows(3).Item(1)
                txtICDFromGrid4.Text = lDS.Tables(0).Rows(3).Item(2)
                txtIMO4.Text = lDS.Tables(0).Rows(3).Item("IMOCode")
        End Select

    End Sub
    Protected Sub grdICD1_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdICD1.NeedDataSource
        If Not (String.IsNullOrEmpty(txtPatientSuperBillId.Text) And String.IsNullOrEmpty(txtSuperBillTemplateId.Text) And String.IsNullOrEmpty(txtOrderBy.Text)) Then
            ClaimMethods.LoadICDGridForClaim(grdICD1, txtPatientSuperBillId.Text, txtSuperBillTemplateId.Text, txtOrderBy.Text, 0)
        End If
    End Sub
    Protected Sub grdICD2_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdICD2.NeedDataSource
        If Not (String.IsNullOrEmpty(txtPatientSuperBillId.Text) And String.IsNullOrEmpty(txtSuperBillTemplateId.Text) And String.IsNullOrEmpty(txtOrderBy.Text)) Then
            ClaimMethods.LoadICDGridForClaim(grdICD2, txtPatientSuperBillId.Text, txtSuperBillTemplateId.Text, txtOrderBy.Text, 1)
        End If
    End Sub
    Protected Sub grdICD3_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdICD3.NeedDataSource
        If Not (String.IsNullOrEmpty(txtPatientSuperBillId.Text) And String.IsNullOrEmpty(txtSuperBillTemplateId.Text) And String.IsNullOrEmpty(txtOrderBy.Text)) Then
            ClaimMethods.LoadICDGridForClaim(grdICD3, txtPatientSuperBillId.Text, txtSuperBillTemplateId.Text, txtOrderBy.Text, 2)
        End If
    End Sub
    Protected Sub grdICD_ItemDataBound(ByVal sender As Object, ByVal e As Telerik.WebControls.GridItemEventArgs) Handles grdICD1.ItemDataBound, grdICD2.ItemDataBound, grdICD3.ItemDataBound
        Dim lCheckBox As CheckBox = Nothing
        Dim litem As GridDataItem

        If e.Item.ItemType = GridItemType.Item Or e.Item.ItemType = GridItemType.AlternatingItem Then
            litem = e.Item
            lCheckBox = litem("CheckboxSelectColumn").Controls(0)
            'lCheckBox = litem.FindControl("cbICD")


            If e.Item.Cells(5).Text.ToString.Equals("Y") Then
                lCheckBox.Checked = True
                litem.Selected = True
            End If
        End If
    End Sub
    Protected Sub grdICD1_ItemCreated(ByVal sender As Object, ByVal e As Telerik.WebControls.GridItemEventArgs) Handles grdICD1.ItemCreated, grdICD2.ItemCreated, grdICD3.ItemCreated
        Dim lcheckBox As CheckBox
        Dim litem As GridHeaderItem

        If e.Item.ItemType = GridItemType.Header Then
            litem = e.Item
            lcheckBox = litem("CheckboxSelectColumn").Controls(0)
            lcheckBox.Visible = False
        End If
    End Sub
    Private Sub OpenWindow(ByVal pNavigateUrl As String, ByVal pWindowId As String, ByVal pCallBackFunction As String)
        Dim newWindow As New RadWindow()

        newWindow.NavigateUrl = pNavigateUrl
        newWindow.ID = pWindowId
        newWindow.VisibleOnPageLoad = True
        newWindow.Top = 150
        newWindow.Left = 14
        newWindow.Width = Unit.Pixel(700)
        newWindow.Height = Unit.Pixel(400)
        newWindow.VisibleTitlebar = False
        newWindow.VisibleStatusbar = False
        newWindow.BorderStyle = BorderStyle.Solid
        newWindow.ReloadOnShow = True
        newWindow.BackColor = Drawing.Color.Transparent
        newWindow.ClientCallBackFunction = pCallBackFunction
        newWindow.Enabled = True
        newWindow.Visible = True
        'newWindow.Modal = True
        rwmGenerateSuperBill.Windows.Add(newWindow)
    End Sub
    Protected Sub grdCPT1_ItemDataBound(ByVal sender As Object, ByVal e As Telerik.WebControls.GridItemEventArgs) Handles grdCPT1.ItemDataBound, grdCPT2.ItemDataBound, grdCPT3.ItemDataBound
        Dim lCheckBox As CheckBox = Nothing
        Dim litem As GridDataItem

        If e.Item.ItemType = GridItemType.Item Or e.Item.ItemType = GridItemType.AlternatingItem Then
            litem = e.Item

            lCheckBox = litem("Select").Controls(0)

            If e.Item.Cells(8).Text.ToString.Equals("Y") Then
                lCheckBox.Checked = True
                litem.Selected = True
            End If
        End If
    End Sub
    Private Function SavePatientSuperBill() As Integer
        Dim lOldCommentsDs As New DataSet
        Dim lUser As User
        Dim lMinimunCptDate As Date
        Dim lDatepicker As RadDatePicker
        Dim lHaveCpt As Boolean = False
        lUser = CType(Session.Item("User"), User)

        Dim lPatientSuperBillDB As New PatientSuperBillDB()
        Dim lResult As Boolean = False
        Dim lStatus As String = String.Empty

        If checkapprove.Checked Then
            lStatus = "Approved"
        Else
            lStatus = "UnApproved"
        End If

        lPatientSuperBillDB.PatientSuperBillID = txtPatientSuperBillId.Text
        lPatientSuperBillDB.Status = lStatus
        Try
            lPatientSuperBillDB.CopayAmount = CType(Me.txtCopayAmount.Text, Double)
        Catch ex As Exception
            lPatientSuperBillDB.CopayAmount = 0.0
        End Try
        lPatientSuperBillDB.PaymentMethod = Me.cmbPaymentMethod.Text
        lPatientSuperBillDB.ChequeNumber = Me.txtChequeNumber.Text
        If (Me.dtChequeDate.SelectedDate.ToString <> "") Then
            lPatientSuperBillDB.ChequeDate = Me.dtChequeDate.SelectedDate
        End If

        lMinimunCptDate = Date.Now.Date
        For lIndex As Int16 = 1 To 6
            If (CType(Me.FindControl("ctl00$ContentPlaceHolder1$cmbCPT" & lIndex), RadComboBox).Text <> "") Then
                lHaveCpt = True
                lDatepicker = Me.FindControl("ctl00$ContentPlaceHolder1$dtDate" & lIndex & "1")
                If (lMinimunCptDate > lDatepicker.DbSelectedDate()) Then
                    lMinimunCptDate = lDatepicker.DbSelectedDate()
                End If
            End If
        Next

        If (Not lHaveCpt) Then
            lMinimunCptDate = dtVisitDisplayDate.DbSelectedDate()
        End If

        With lPatientSuperBillDB
            .PatientId = txtPatientID.Text
            '.DateOfService = lblDateOfService.Text
            '.DateOfService = Me.dtVisitDisplayDate.DbSelectedDate()  'For report date, defect id 370 19th Oct 2010
            .DateOfService = lMinimunCptDate & "|" & IIf(dtVisitDisplayDate.Enabled, False, True)  'for incorporation of hospital visit, 21st feb 2011
            .PatientSuperBillID = txtPatientSuperBillId.Text
            .Status = lStatus
            .ReferringProviderNPI = txtRefferingProviderNPI.Text
            .VisitDisplayDATE = lMinimunCptDate
            .BillingProviderId = Me.cmbBillingProvider.SelectedValue.ToString
            .FacilityID = Me.cmbFacility.SelectedValue.ToString
            .PrescriberID = cmbProvider.SelectedItem.Value.Split("|")(0)
            .Comments = hdComment.Value.Replace(vbCr, " ")
            'If (hdComment.Value.ToString.TrimEnd.TrimStart <> "") Then
            '    lOldCommentsDs = PatientSuperBillMethods.LoadComment(Nothing, txtPatientSuperBillId.Text)
            '    If (lOldCommentsDs.Tables.Count > 0 AndAlso lOldCommentsDs.Tables(0).Rows.Count > 0) Then
            '        If (lOldCommentsDs.Tables(0).Rows(0).Item("Comments").ToString = hdComment.Value) Then
            '            .Comments = hdComment.Value
            '        Else
            '            If (hdComment.Value.Length < lOldCommentsDs.Tables(0).Rows(0).Item("Comments").ToString.Length) Then
            '                .Comments = hdComment.Value
            '                .PatientSuperBillID = txtPatientSuperBillId.Text
            '            Else
            '                .Comments = hdComment.Value & " :By " & lUser.FirstName & " " & lUser.LastName & "[" & lUser.LoginId & "] On " & Date.Today.Date & " "
            '            End If
            '        End If
            '    Else
            '        .Comments = hdComment.Value & " :By " & lUser.FirstName & " " & lUser.LastName & "[" & lUser.LoginId & "] On " & Date.Today.Date & " "
            '    End If
            'Else
            '    .Comments = ""
            'End If
            'If (hdComment.Value.ToString <> "") Then
            '    .Comments = hdComment.Value.ToString & "  By " & lUser.FirstName & " " & lUser.LastName & " On " & Date.Today.Date & vbCr
            'Else
            '    .Comments = ""
            'End If
        End With

        lResult = GenerateSuperBillMethods.EditPatientSuperBill(lPatientSuperBillDB, pnlBillingInfo, Request.Url.AbsoluteUri, cmbProvider.SelectedItem.Value.Split("|")(1))

        'If ((checkapprove.Checked = True) And lResult) Then
        '    PatientLedgerMethods.SavePatientLedger(pnlBillingInfo, lPatientSuperBillDB)
        'End If

        Return lResult

    End Function
    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSave.Click
        Dim lResult As Boolean

        Try

            'If (Me.checkapprove.Checked AndAlso cmbRefferingProvider.SelectedValue = "") Then
            '    Me.RadAjaxManager1.Alert("Must select Referring Provider for approved Visit")
            '    Exit Sub
            'End If

            lResult = SavePatientSuperBill()
            If lResult = True Then
                'PageExpire()
                'Response.Write("<script>location.href = 'VisitSearch.aspx';</script>")

                Response.Write("<script language='javascript'> history.go(-(history.length));window.location='VisitSearch.aspx?ParentPage=EditPatientSuperBill';</script>")



                'Response.Redirect("VisitSearch.aspx")
            Else
                Me.RadAjaxManager1.Alert("Error Updating Superbill, try again later")
                'lblMessage.Text = "Error Updating Superbill, try again later"
            End If

        Catch ArgEx As ArgumentException 'THIS EXCEPTION CATCHES THE WRONG CPT CODE ENTERED
            Me.RadAjaxManager1.Alert("CPT Code  " & ArgEx.Message.Split("|")(1) & " is not correct")
        End Try


    End Sub
    Protected Sub btnSaveNPrint_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSavenPrint.Click





        Dim lResult As Boolean

        Dim lEncryptedPart As String = ElixirLibrary.Encryption.EncryptQueryString("sid=" & txtPatientSuperBillId.Text)
        Dim lScript As String = "javascript:OpenPopUpWindowVisitSummary('PSBPrint.aspx" & lEncryptedPart & "');history.go(-(history.length));"


        If (txtApproved.Text.Equals("A") And Me.btnSave.Enabled = False) Then
            lResult = True
        Else
            If (Me.checkapprove.Checked And Me.txtRefferingProviderNPI.Text = "") Then
                Me.RadAjaxManager1.Alert("Must select Referring Provider for approved Visit")
                Exit Sub
            End If
            lResult = SavePatientSuperBill()
        End If

        If lResult = True Then
            RadAjaxManager1.ResponseScripts.Add(lScript)


            RadAjaxManager1.Redirect("../Billing/VisitSearch.aspx?ParentPage=EditPatientSuperBill")

        Else
            Me.RadAjaxManager1.Alert("Error Updating Superbill, try again later")
        End If
    End Sub
    Private Sub EnableControls(ByVal pControl As Control)
        If TypeOf pControl Is WebControl Then
            CType(pControl, WebControl).Enabled = True
        End If

        For Each child As Control In pControl.Controls
            EnableControls(child)
        Next
    End Sub
    Private Sub DisableControls(ByVal pControl As Control)
        If TypeOf pControl Is WebControl Then
            CType(pControl, WebControl).Enabled = False
        End If

        For Each child As Control In pControl.Controls
            DisableControls(child)
        Next
    End Sub
    Private Sub LoadModifier(ByVal pDS As DataSet)
        Dim i As Integer
        txtHidden.Text = pDS.Tables(0).Rows.Count - 1
        'hdnText.Text = pDS.Tables(0).Rows.Count - 1


        For i = 1 To pDS.Tables(0).Rows.Count
            CType(pnlBillingInfo.FindControl("txtCharges" & i), TextBox).Text = pDS.Tables(0).Rows(i - 1).Item("Charges")
            CType(pnlBillingInfo.FindControl("cmbCPT" & i), RadComboBox).Text = pDS.Tables(0).Rows(i - 1).Item("Code")
            CType(pnlBillingInfo.FindControl("cmbPOS" & i), DropDownList).SelectedValue = pDS.Tables(0).Rows(i - 1).Item("FacilityId")
            CType(pnlBillingInfo.FindControl("dtDate" & i & "1"), RadDatePicker).SelectedDate = pDS.Tables(0).Rows(i - 1).Item("DateOfServiceFrom")
            CType(pnlBillingInfo.FindControl("dtDate" & i & "2"), RadDatePicker).SelectedDate = pDS.Tables(0).Rows(i - 1).Item("DateOfServiceTo")
            CType(pnlBillingInfo.FindControl("txtDescription" & i), TextBox).Text = pDS.Tables(0).Rows(i - 1).Item("Description")
            CType(pnlBillingInfo.FindControl("txtFromGrid" & i), TextBox).Text = pDS.Tables(0).Rows(i - 1).Item("IsGridItem")
            CType(pnlBillingInfo.FindControl("txtHeading" & i), TextBox).Text = pDS.Tables(0).Rows(i - 1).Item("Heading")
            CType(pnlBillingInfo.FindControl("txtDays" & i), TextBox).Text = pDS.Tables(0).Rows(i - 1).Item("Days")



            CType(pnlBillingInfo.FindControl("txtA" & i), DropDownList).Items.Insert(0, "")
            CType(pnlBillingInfo.FindControl("txtB" & i), DropDownList).Items.Insert(0, "")
            CType(pnlBillingInfo.FindControl("txtC" & i), DropDownList).Items.Insert(0, "")
            CType(pnlBillingInfo.FindControl("txtD" & i), DropDownList).Items.Insert(0, "")




            Utility.SelectComboItem(CType(pnlBillingInfo.FindControl("txtA" & i), DropDownList), pDS.Tables(0).Rows(i - 1).Item("ModifierA"), False)
            Utility.SelectComboItem(CType(pnlBillingInfo.FindControl("txtB" & i), DropDownList), pDS.Tables(0).Rows(i - 1).Item("ModifierB"), False)
            Utility.SelectComboItem(CType(pnlBillingInfo.FindControl("txtC" & i), DropDownList), pDS.Tables(0).Rows(i - 1).Item("ModifierC"), False)
            Utility.SelectComboItem(CType(pnlBillingInfo.FindControl("txtD" & i), DropDownList), pDS.Tables(0).Rows(i - 1).Item("ModifierD"), False)


            CType(pnlBillingInfo.FindControl("txtPointer" & i), TextBox).Text = pDS.Tables(0).Rows(i - 1).Item("Pointer")
            'CType(pnlBillingInfo.FindControl("btnCPTSearch" & i), ImageButton).Enabled = False
            CType(pnlBillingInfo.FindControl("cmbIMO" & i), TextBox).Text = pDS.Tables(0).Rows(i - 1).Item("IMOCode")

            CType(pnlBillingInfo.FindControl("txtLineId" & i), TextBox).Text = pDS.Tables(0).Rows(i - 1).Item("LineId")


        Next



        'This loop adds the Current Date to all the unfilled date pickers
        If (pDS.Tables(0).Rows.Count = 1) Then
            For i = 1 To 17
                CType(pnlBillingInfo.FindControl("dtDate" & i + 1 & "1"), RadDatePicker).SelectedDate = dtVisitDisplayDate.SelectedDate
                CType(pnlBillingInfo.FindControl("dtDate" & i + 1 & "2"), RadDatePicker).SelectedDate = dtVisitDisplayDate.SelectedDate
            Next
        Else
            For i = pDS.Tables(0).Rows.Count To 17
                'If (i > 0) Then
                CType(pnlBillingInfo.FindControl("dtDate" & i + 1 & "1"), RadDatePicker).SelectedDate = dtVisitDisplayDate.SelectedDate
                CType(pnlBillingInfo.FindControl("dtDate" & i + 1 & "2"), RadDatePicker).SelectedDate = dtVisitDisplayDate.SelectedDate
                'End If
            Next
        End If


        'For i = pDS.Tables(0).Rows.Count To 18
        '    If (pDS.Tables(0).Rows.Count > 0) Then
        '        CType(pnlBillingInfo.FindControl("txtA" & i), DropDownList).Items.Insert(0, "")
        '        CType(pnlBillingInfo.FindControl("txtB" & i), DropDownList).Items.Insert(0, "")
        '        CType(pnlBillingInfo.FindControl("txtC" & i), DropDownList).Items.Insert(0, "")
        '        CType(pnlBillingInfo.FindControl("txtD" & i), DropDownList).Items.Insert(0, "")

        '    End If
        'Next
        For i = 1 To 6
            CType(pnlBillingInfo.FindControl("txtA" & i), DropDownList).Items.Insert(0, "")
            CType(pnlBillingInfo.FindControl("txtB" & i), DropDownList).Items.Insert(0, "")
            CType(pnlBillingInfo.FindControl("txtC" & i), DropDownList).Items.Insert(0, "")
            CType(pnlBillingInfo.FindControl("txtD" & i), DropDownList).Items.Insert(0, "")
        Next







    End Sub
    'THIS FUNCTION WOULD OPEN THE SEARCH WINDOW FOR THE CPT
    Protected Sub btnCPTSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnCPTSearch1.Click, _
        btnCPTSearch2.Click, _
        btnCPTSearch3.Click, _
        btnCPTSearch4.Click, _
        btnCPTSearch5.Click, _
        btnCPTSearch6.Click, _
        btnCPTSearch7.Click, _
        btnCPTSearch8.Click, _
        btnCPTSearch9.Click, _
        btnCPTSearch10.Click, _
        btnCPTSearch11.Click, _
        btnCPTSearch12.Click, _
        btnCPTSearch13.Click, _
        btnCPTSearch14.Click, _
        btnCPTSearch15.Click, _
        btnCPTSearch16.Click, _
        btnCPTSearch17.Click, _
        btnCPTSearch18.Click


        Dim lSenderID As String = sender.id.ToString

        Select Case lSenderID
            Case "btnCPTSearch1"
                OpenWindow("SearchCPT.aspx?CPT=" & cmbCPT1.Text & "&lid=1", "rwCPTSearch", "CPTCallBackFunction")
            Case "btnCPTSearch2"

                OpenWindow("SearchCPT.aspx?CPT=" & cmbCPT2.Text & "&lid=2", "rwCPTSearch", "CPTCallBackFunction")

            Case "btnCPTSearch3"

                OpenWindow("SearchCPT.aspx?CPT=" & cmbCPT3.Text & "&lid=3", "rwCPTSearch", "CPTCallBackFunction")

            Case "btnCPTSearch4"

                OpenWindow("SearchCPT.aspx?CPT=" & cmbCPT4.Text & "&lid=4", "rwCPTSearch", "CPTCallBackFunction")

            Case "btnCPTSearch5"

                OpenWindow("SearchCPT.aspx?CPT=" & cmbCPT5.Text & "&lid=5", "rwCPTSearch", "CPTCallBackFunction")

            Case "btnCPTSearch6"

                OpenWindow("SearchCPT.aspx?CPT=" & cmbCPT6.Text & "&lid=6", "rwCPTSearch", "CPTCallBackFunction")

            Case "btnCPTSearch7"

                OpenWindow("SearchCPT.aspx?CPT=" & cmbCPT7.Text & "&lid=7", "rwCPTSearch", "CPTCallBackFunction")

            Case "btnCPTSearch8"

                OpenWindow("SearchCPT.aspx?CPT=" & cmbCPT8.Text & "&lid=8", "rwCPTSearch", "CPTCallBackFunction")

            Case "btnCPTSearch9"

                OpenWindow("SearchCPT.aspx?CPT=" & cmbCPT9.Text & "&lid=9", "rwCPTSearch", "CPTCallBackFunction")

            Case "btnCPTSearch10"

                OpenWindow("SearchCPT.aspx?CPT=" & cmbCPT10.Text & "&lid=10", "rwCPTSearch", "CPTCallBackFunction")

            Case "btnCPTSearch11"

                OpenWindow("SearchCPT.aspx?CPT=" & cmbCPT11.Text & "&lid=11", "rwCPTSearch", "CPTCallBackFunction")

            Case "btnCPTSearch12"

                OpenWindow("SearchCPT.aspx?CPT=" & cmbCPT12.Text & "&lid=12", "rwCPTSearch", "CPTCallBackFunction")

            Case "btnCPTSearch13"

                OpenWindow("SearchCPT.aspx?CPT=" & cmbCPT13.Text & "&lid=13", "rwCPTSearch", "CPTCallBackFunction")

            Case "btnCPTSearch14"

                OpenWindow("SearchCPT.aspx?CPT=" & cmbCPT14.Text & "&lid=14", "rwCPTSearch", "CPTCallBackFunction")

            Case "btnCPTSearch15"

                OpenWindow("SearchCPT.aspx?CPT=" & cmbCPT15.Text & "&lid=15", "rwCPTSearch", "CPTCallBackFunction")

            Case "btnCPTSearch16"

                OpenWindow("SearchCPT.aspx?CPT=" & cmbCPT16.Text & "&lid=16", "rwCPTSearch", "CPTCallBackFunction")

            Case "btnCPTSearch17"

                OpenWindow("SearchCPT.aspx?CPT=" & cmbCPT17.Text & "&lid=17", "rwCPTSearch", "CPTCallBackFunction")

            Case "btnCPTSearch18"
                OpenWindow("SearchCPT.aspx?CPT=" & cmbCPT18.Text & "&lid=18", "rwCPTSearch", "CPTCallBackFunction")
        End Select

    End Sub

    Protected Sub btnICDSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnICD1Search.Click, btnICD2Search.Click, btnICD3Search.Click, btnICD4Search.Click
        Dim lSenderID As String = sender.id.ToString

        Select Case lSenderID
            Case "btnICD1Search"
                OpenWindow("SearchICD9.aspx?icd=" & cmbICD1.Text & "&lid=1", "rwICD9Search", "ICDCallBackFunction")
            Case "btnICD2Search"
                OpenWindow("SearchICD9.aspx?icd=" & cmbICD2.Text & "&lid=2", "rwICD9Search", "ICDCallBackFunction")
            Case "btnICD3Search"
                OpenWindow("SearchICD9.aspx?icd=" & cmbICD3.Text & "&lid=3", "rwICD9Search", "ICDCallBackFunction")
            Case "btnICD4Search"
                OpenWindow("SearchICD9.aspx?icd=" & cmbICD4.Text & "&lid=4", "rwICD9Search", "ICDCallBackFunction")
        End Select
    End Sub

    Protected Sub grdCPT_ItemCreated(ByVal sender As Object, ByVal e As Telerik.WebControls.GridItemEventArgs) Handles grdCPT1.ItemCreated, grdCPT2.ItemCreated, grdCPT3.ItemCreated
        Dim lcheckBox As CheckBox
        Dim litem As GridHeaderItem

        If e.Item.ItemType = GridItemType.Header Then
            litem = e.Item
            lcheckBox = litem("Select").Controls(0)
            lcheckBox.Visible = False
        End If
    End Sub
    Protected Sub grdCPT_ItemDataBound(ByVal sender As Object, ByVal e As Telerik.WebControls.GridItemEventArgs) Handles grdCPT1.ItemDataBound, grdCPT2.ItemDataBound, grdCPT3.ItemDataBound
        If e.Item.ItemType = GridItemType.GroupHeader Then
            e.Item.Cells(1).Text = e.Item.Cells(1).Text.ToString().Substring(e.Item.Cells(1).Text.IndexOf(":") + 1)
        End If
    End Sub

    Protected Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnCancel.Click
        Response.Redirect("VisitSearch.aspx")
    End Sub


    'Protected Sub cmbICD1_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbICD1.ItemsRequested, _
    '                                                                                                                                   cmbICD2.ItemsRequested, _
    '                                                                                                                                   cmbICD3.ItemsRequested, _
    '                                                                                                                                   cmbICD4.ItemsRequested


    '    Try

    '        Select Case o.id
    '            Case "cmbICD1"
    '                SuperBillMethods.LoadICDForCombo(cmbICD1, e.Text)
    '            Case "cmbICD2"
    '                SuperBillMethods.LoadICDForCombo(cmbICD2, e.Text)
    '            Case "cmbICD3"
    '                SuperBillMethods.LoadICDForCombo(cmbICD3, e.Text)
    '            Case "cmbICD4"
    '                SuperBillMethods.LoadICDForCombo(cmbICD4, e.Text)
    '        End Select


    '    Catch ex As Exception
    '        Dim lLogID As Integer
    '        lLogID = ErrorLogMethods.LogError(ex, "EditPatientSuperBill.aspx\cmbICD1_ItemsRequested :")
    '    End Try
    'End Sub



    'Protected Sub cmbCPT_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbCPT1.ItemsRequested, _
    '                                                                                                                                  cmbCPT2.ItemsRequested, _
    '                                                                                                                                  cmbCPT3.ItemsRequested, _
    '                                                                                                                                  cmbCPT4.ItemsRequested, _
    '                                                                                                                                  cmbCPT5.ItemsRequested, _
    '                                                                                                                                  cmbCPT6.ItemsRequested, _
    '                                                                                                                                  cmbCPT7.ItemsRequested, _
    '                                                                                                                                  cmbCPT8.ItemsRequested, _
    '                                                                                                                                  cmbCPT9.ItemsRequested, _
    '                                                                                                                                  cmbCPT10.ItemsRequested, _
    '                                                                                                                                  cmbCPT11.ItemsRequested, _
    '                                                                                                                                  cmbCPT12.ItemsRequested, _
    '                                                                                                                                  cmbCPT13.ItemsRequested, _
    '                                                                                                                                  cmbCPT14.itemsRequested, _
    '                                                                                                                                  cmbCPT15.itemsRequested, _
    '                                                                                                                                  cmbcpt16.itemsrequested, _
    '                                                                                                                                  cmbcpt17.itemsrequested, _
    '                                                                                                                                  cmbcpt18.itemsrequested


    '    Try

    '        Select Case o.id
    '            Case "cmbCPT1"
    '                SuperBillMethods.LoadCPTForCombo(cmbCPT1, e.Text)
    '            Case "cmbCPT2"
    '                SuperBillMethods.LoadCPTForCombo(cmbCPT2, e.Text)
    '            Case "cmbCPT3"
    '                SuperBillMethods.LoadCPTForCombo(cmbCPT3, e.Text)
    '            Case "cmbCPT4"
    '                SuperBillMethods.LoadCPTForCombo(cmbCPT4, e.Text)
    '            Case "cmbCPT5"
    '                SuperBillMethods.LoadCPTForCombo(cmbCPT5, e.Text)
    '            Case "cmbCPT6"
    '                SuperBillMethods.LoadCPTForCombo(cmbCPT6, e.Text)
    '            Case "cmbCPT7"
    '                SuperBillMethods.LoadCPTForCombo(cmbCPT7, e.Text)
    '            Case "cmbCPT8"
    '                SuperBillMethods.LoadCPTForCombo(cmbCPT8, e.Text)
    '            Case "cmbCPT9"
    '                SuperBillMethods.LoadCPTForCombo(cmbCPT9, e.Text)
    '            Case "cmbCPT10"
    '                SuperBillMethods.LoadCPTForCombo(cmbCPT10, e.Text)
    '            Case "cmbCPT11"
    '                SuperBillMethods.LoadCPTForCombo(cmbCPT11, e.Text)
    '            Case "cmbCPT12"
    '                SuperBillMethods.LoadCPTForCombo(cmbCPT12, e.Text)
    '            Case "cmbCPT13"
    '                SuperBillMethods.LoadCPTForCombo(cmbCPT13, e.Text)
    '            Case "cmbCPT14"
    '                SuperBillMethods.LoadCPTForCombo(cmbCPT14, e.Text)
    '            Case "cmbCPT15"
    '                SuperBillMethods.LoadCPTForCombo(cmbCPT15, e.Text)
    '            Case "cmbCPT16"
    '                SuperBillMethods.LoadCPTForCombo(cmbCPT16, e.Text)
    '            Case "cmbCPT17"
    '                SuperBillMethods.LoadCPTForCombo(cmbCPT17, e.Text)
    '            Case "cmbCPT18"
    '                SuperBillMethods.LoadCPTForCombo(cmbCPT18, e.Text)
    '        End Select


    '    Catch ex As Exception
    '        Dim lLogID As Integer
    '        lLogID = ErrorLogMethods.LogError(ex, "EditPatientSuperBill.aspx\cmbCPT_ItemsRequested :")
    '    End Try
    'End Sub
    '' Created by Fareed 28th Jan 2009
    '' To fill Referring Provider Combo with combo text field  as First + Middle + last name
    '' combo value field  as Reffering Provider Id | Referring provider NPI
    Private Sub LoadRefferingProviderCombo()
        Dim lUser As User
        Dim lRefferingProvider As ReferringProvider
        Dim lNPI As String

        lUser = CType(Session.Item("User"), User)
        lRefferingProvider = New ReferringProvider(lUser.ConnectionString)

        Me.cmbRefferingProvider.DataSource = lRefferingProvider.GetRefferingProviderForCombo()
        Me.cmbRefferingProvider.DataBind()

        If (Me.txtRefferingProviderNPI.Text <> "") Then
            Utility.SelectComboItem(cmbRefferingProvider, txtRefferingProviderNPI.Text, True)
            If (cmbRefferingProvider.SelectedItem Is Nothing) Then
                Me.txtRefferingProviderNPI.Text = ""
            End If
        Else
            If (cmbProvider.SelectedValue.Contains("|")) Then
                lNPI = cmbProvider.SelectedValue.Split("|")(1)
                If (cmbRefferingProvider.FindItemIndexByValue(lNPI) <> -1) Then
                    txtRefferingProviderNPI.Text = lNPI
                Else
                    Me.txtRefferingProviderNPI.Text = ""
                End If
            End If
            Utility.SelectComboItem(cmbRefferingProvider, txtRefferingProviderNPI.Text, True)
            If (cmbRefferingProvider.SelectedItem IsNot Nothing) Then
                Me.txtRefferingProviderNPI.Text = cmbRefferingProvider.SelectedItem.Value
            Else
                Me.txtRefferingProviderNPI.Text = ""
            End If
        End If
    End Sub
    Protected Sub cmbRefferingProvider_SelectedIndexChanged(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxSelectedIndexChangedEventArgs) Handles cmbRefferingProvider.SelectedIndexChanged
        Me.txtRefferingProviderNPI.Text = Me.cmbRefferingProvider.SelectedItem.Value
        Try
            ChangeControlsStates("0")
        Catch ex As Exception

        End Try
    End Sub
    'Protected Sub btnCheckNecessity_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnCheckNecessity.Click
    '    Dim lICDCodes As String = String.Empty
    '    Dim lCPTCodes As String = String.Empty
    '    Dim lLineNumber As Integer = 1

    '    Dim lXmlDoc As New XmlDocument
    '    Dim lResult As String = String.Empty
    '    Dim lXmlDataString As String = String.Empty



    '    lblMsg.Style("display") = ""


    '    ''ICD Section.........
    '    For lLineNumber = 1 To 4
    '        If Not String.IsNullOrEmpty(CType(pnlBillingInfo.FindControl("cmbICD" & lLineNumber.ToString), TextBox).Text) Then
    '            lICDCodes = lICDCodes & "," & CType(pnlBillingInfo.FindControl("cmbICD" & lLineNumber.ToString), TextBox).Text
    '        End If
    '    Next

    '    If (Not String.IsNullOrEmpty(lICDCodes)) Then
    '        lICDCodes = lICDCodes.Remove(0, 1)
    '    Else
    '        lblMsg.Text = "Please enter atleast one ICD code"
    '        lnkMoreDetails.Style("display") = "none"
    '        Exit Sub
    '    End If



    '    ''CPT Section.........
    '    For lLineNumber = 1 To 18
    '        If Not String.IsNullOrEmpty(CType(pnlBillingInfo.FindControl("cmbCPT" & lLineNumber.ToString), TextBox).Text) Then
    '            lCPTCodes = lCPTCodes & "," & CType(pnlBillingInfo.FindControl("cmbCPT" & lLineNumber.ToString), TextBox).Text
    '        End If
    '    Next

    '    If (Not String.IsNullOrEmpty(lCPTCodes)) Then
    '        lCPTCodes = lCPTCodes.Remove(0, 1)
    '    Else
    '        lblMsg.Text = "Please enter atleast one CPT code"
    '        lnkMoreDetails.Style("display") = "none"
    '        Exit Sub
    '    End If



    '    lXmlDataString = IMOMethods.CheckMedicalNecassity(lICDCodes, lCPTCodes, "01192")


    '    If (lXmlDataString <> "" AndAlso lXmlDataString(0) = "<" AndAlso lXmlDataString.IndexOf("</items>") > -1) Then
    '        lXmlDoc.LoadXml(lXmlDataString)

    '        lblMsg.Style("display") = ""
    '        lnkMoreDetails.Style("display") = ""

    '        If (Not lXmlDoc.SelectSingleNode("items/result") Is Nothing) Then
    '            lResult = lXmlDoc.SelectSingleNode("items/result").Attributes("check").Value
    '        Else
    '            lResult = "No result status available"
    '        End If

    '        Session("XmlDataString") = lXmlDataString

    '        lblMsg.Text = lResult
    '        lblMsg.Visible = True
    '    Else
    '        lblMsg.Text = "You are not authorized to use this service"
    '    End If

    'End Sub
    Private Sub LoadBillingProviderCombo(ByVal pUser As User, ByVal pFavInsId As String)
        Dim lBillingProvider As BillingProvider
        Dim lDefaultBillingProviderID As String = ""
        Dim lDS As New DataSet
        lBillingProvider = New BillingProvider(pUser.ConnectionString)
        Me.cmbBillingProvider.DataSource = lBillingProvider.LoadBillingProvider()
        Me.cmbBillingProvider.DataBind()

        lDS = lBillingProvider.GetBillingProvider(Convert.ToInt32(cmbProvider.SelectedValue.Split("|").GetValue(0).ToString()), pFavInsId)
        If (lDS.Tables.Count > 0 AndAlso lDS.Tables(0).Rows.Count > 0) Then
            ElixirLibrary.Utility.SelectComboItem(cmbBillingProvider, lDS.Tables(0).Rows(0).Item("BillingProviderId").ToString, True)
            'cmbBillingProvider.SelectedIndex = cmbBillingProvider.FindItemIndexByValue(lDS.Tables(0).Rows(0).Item("BillingProviderId").ToString)
        End If
    End Sub
    Private Sub LoadFacilityCombo(ByVal pUser As User, ByVal pFacilityId As String)
        Dim lItem As DataRow
        Dim lDS As New DataSet
        Dim lFacility As Facility
        lFacility = New Facility(pUser.ConnectionString)
        lDS = lFacility.GetActiveFacilityList()

        If (lDS.Tables.Count > 0 AndAlso lDS.Tables(0).Rows.Count > 0) Then
            lFacility.GetFacilityById("FacilityID='" & pFacilityId & "'")
            If Not (lDS.GetXml.Contains(lFacility.FacilityDB.FacilityName) AndAlso lDS.GetXml.Contains(lFacility.FacilityDB.FacilityID)) Then
                'lFacility.GetFacilityById("FacilityID='" & pFacilityId & "'")
                lItem = lDS.Tables(0).NewRow()
                lItem("FacilityID") = lFacility.FacilityDB.FacilityID
                lItem("FacilityName") = lFacility.FacilityDB.FacilityName
                lDS.Tables(0).Rows.Add(lItem)
                lDS.Tables(0).AcceptChanges()
            End If
        End If

        cmbFacility.DataSource = Nothing
        cmbFacility.DataSource = lDS
        cmbFacility.DataBind()

        cmbPOS1.DataSource = Nothing
        cmbPOS1.DataSource = lDS
        cmbPOS1.DataBind()

        cmbPOS2.DataSource = Nothing
        cmbPOS2.DataSource = lDS
        cmbPOS2.DataBind()

        cmbPOS3.DataSource = Nothing
        cmbPOS3.DataSource = lDS
        cmbPOS3.DataBind()

        cmbPOS4.DataSource = Nothing
        cmbPOS4.DataSource = lDS
        cmbPOS4.DataBind()

        cmbPOS5.DataSource = Nothing
        cmbPOS5.DataSource = lDS
        cmbPOS5.DataBind()

        cmbPOS6.DataSource = Nothing
        cmbPOS6.DataSource = lDS
        cmbPOS6.DataBind()

        'cmbFacility.ClearSelection()
        'cmbFacility.SelectedIndex = cmbFacility.Items.IndexOf(cmbFacility.Items.FindByValue(pFacilityId))

        'cmbFacility.Items.FindByValue(pFacilityId).Selected = True

        'If (pFacilityId <> "") Then
        'ElixirLibrary.Utility.SelectComboItem(cmbFacility, pFacilityId, True)
        SelectPosFacilityComboItem()
        '    'cmbBillingProvider.SelectedIndex = cmbBillingProvider.FindItemIndexByValue(lDS.Tables(0).Rows(0).Item("BillingProviderId").ToString)
        'End If
    End Sub

    Public Sub SelectPosFacilityComboItem()

        Try
            If (cmbFacility.SelectedIndex > -1) Then
                If (cmbPOS1.Enabled = True) Then
                    cmbPOS1.ClearSelection()
                    cmbPOS1.SelectedIndex = cmbPOS1.Items.IndexOf(cmbPOS1.Items.FindByValue(cmbFacility.SelectedValue))
                End If

                If (cmbPOS2.Enabled = True) Then
                    cmbPOS2.ClearSelection()
                    cmbPOS2.SelectedIndex = cmbPOS2.Items.IndexOf(cmbPOS2.Items.FindByValue(cmbFacility.SelectedValue))
                End If

                If (cmbPOS3.Enabled = True) Then
                    cmbPOS3.ClearSelection()
                    cmbPOS3.SelectedIndex = cmbPOS3.Items.IndexOf(cmbPOS3.Items.FindByValue(cmbFacility.SelectedValue))
                End If

                If (cmbPOS4.Enabled = True) Then
                    cmbPOS4.ClearSelection()
                    cmbPOS4.SelectedIndex = cmbPOS4.Items.IndexOf(cmbPOS4.Items.FindByValue(cmbFacility.SelectedValue))
                End If

                If (cmbPOS5.Enabled = True) Then
                    cmbPOS5.ClearSelection()
                    cmbPOS5.SelectedIndex = cmbPOS5.Items.IndexOf(cmbPOS5.Items.FindByValue(cmbFacility.SelectedValue))
                End If

                If (cmbPOS6.Enabled = True) Then
                    cmbPOS6.ClearSelection()
                    cmbPOS6.SelectedIndex = cmbPOS6.Items.IndexOf(cmbPOS6.Items.FindByValue(cmbFacility.SelectedValue))
                End If

                'Else
                '    Dim lFacility As Facility
                '    lFacility = New Facility(CType(Session("User"), User).ConnectionString)
                '    lFacility.GetFacilityById("FacilityID='" & cmbFacility.SelectedValue & "'")
                '    lItem.Text = lFacility.FacilityDB.FacilityName
                '    lItem.Value = lFacility.FacilityDB.FacilityID
                '    cmbPOS1.Items.Insert(0, lItem)

            End If
        Catch ex As Exception

        End Try
    End Sub
    Public Sub SelectProviderComboItem()
        Try
            EmployeeMethods.LoadDoctorsCombo(cmbProvider1)
            EmployeeMethods.LoadDoctorsCombo(cmbProvider2)
            EmployeeMethods.LoadDoctorsCombo(cmbProvider3)
            EmployeeMethods.LoadDoctorsCombo(cmbProvider4)
            EmployeeMethods.LoadDoctorsCombo(cmbProvider5)
            EmployeeMethods.LoadDoctorsCombo(cmbProvider6)
            If (cmbProvider.SelectedIndex > -1) Then
                Utility.SelectComboItem(cmbProvider1, cmbProvider.SelectedValue, True)
                Utility.SelectComboItem(cmbProvider2, cmbProvider.SelectedValue, True)
                Utility.SelectComboItem(cmbProvider3, cmbProvider.SelectedValue, True)
                Utility.SelectComboItem(cmbProvider4, cmbProvider.SelectedValue, True)
                Utility.SelectComboItem(cmbProvider5, cmbProvider.SelectedValue, True)
                Utility.SelectComboItem(cmbProvider6, cmbProvider.SelectedValue, True)
            End If
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub btnEditVisit_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnEditVisit.Click
        Try
            ChangeControlsStates("0")
            hdrBar.Visible = False
            LoadPatient(txtPatientSuperBillId.Text)
        Catch ex As Exception

        End Try
    End Sub
    Public Sub ReversalEntryFunction()
        Try

        Catch ex As Exception

        End Try
    End Sub
    'Protected Sub imgRev_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgRev1.Click, imgRev2.Click, imgRev3.Click, imgRev4.Click, imgRev5.Click, imgRev6.Click
    '    Try
    '        Dim lSenderID As String = sender.id.ToString

    '        Select Case lSenderID
    '            Case "imgRev1"
    '                OpenWindow("CommentsPage.aspx?lid=1", "rwComments", "CommentzCallBackFunction")
    '            Case "imgRev2"
    '                OpenWindow("CommentsPage.aspx?lid=2", "rwComments", "CommentzCallBackFunction")
    '            Case "imgRev3"
    '                OpenWindow("CommentsPage.aspx?lid=3", "rwComments", "CommentzCallBackFunction")
    '            Case "imgRev4"
    '                OpenWindow("CommentsPage.aspx?lid=4", "rwComments", "CommentzCallBackFunction")
    '            Case "imgRev5"
    '                OpenWindow("CommentsPage.aspx?lid=5", "rwComments", "CommentzCallBackFunction")
    '            Case "imgRev6"
    '                OpenWindow("CommentsPage.aspx?lid=6", "rwComments", "CommentzCallBackFunction")
    '        End Select

    '        EnableControls(btnSave)

    '    Catch ex As Exception

    '    End Try
    'End Sub
    Public Sub LoadModifierCombos()
        Dim lDS As DataSet
        Try
            'txtA1.Attributes.Add("onChange", "return ('" + txtA1.ClientID + "',1);")
            'txtB1.Attributes.Add("onChange", "return CheckModSeq('" + txtB1.ClientID + "',1);")

            lDS = New DataSet
            lDS = SuperBillMethods.GetModifier()

            txtA1.DataSource = lDS
            txtA1.DataTextField = "ModifierName"
            txtA1.DataValueField = "ModifierID"
            txtA1.DataBind()
            txtB1.DataSource = lDS
            txtB1.DataTextField = "ModifierName"
            txtB1.DataValueField = "ModifierID"
            txtB1.DataBind()
            txtC1.DataSource = lDS
            txtC1.DataTextField = "ModifierName"
            txtC1.DataValueField = "ModifierID"
            txtC1.DataBind()
            txtD1.DataSource = lDS
            txtD1.DataTextField = "ModifierName"
            txtD1.DataValueField = "ModifierID"
            txtD1.DataBind()
            txtA2.DataSource = lDS
            txtA2.DataTextField = "ModifierName"
            txtA2.DataValueField = "ModifierID"
            txtA2.DataBind()
            txtB2.DataSource = lDS
            txtB2.DataTextField = "ModifierName"
            txtB2.DataValueField = "ModifierID"
            txtB2.DataBind()
            txtC2.DataSource = lDS
            txtC2.DataTextField = "ModifierName"
            txtC2.DataValueField = "ModifierID"
            txtC2.DataBind()
            txtD2.DataSource = lDS
            txtD2.DataTextField = "ModifierName"
            txtD2.DataValueField = "ModifierID"
            txtD2.DataBind()
            txtA3.DataSource = lDS
            txtA3.DataTextField = "ModifierName"
            txtA3.DataValueField = "ModifierID"
            txtA3.DataBind()
            txtB3.DataSource = lDS
            txtB3.DataTextField = "ModifierName"
            txtB3.DataValueField = "ModifierID"
            txtB3.DataBind()
            txtC3.DataSource = lDS
            txtC3.DataTextField = "ModifierName"
            txtC3.DataValueField = "ModifierID"
            txtC3.DataBind()
            txtD3.DataSource = lDS
            txtD3.DataTextField = "ModifierName"
            txtD3.DataValueField = "ModifierID"
            txtD3.DataBind()
            txtA4.DataSource = lDS
            txtA4.DataTextField = "ModifierName"
            txtA4.DataValueField = "ModifierID"
            txtA4.DataBind()
            txtB4.DataSource = lDS
            txtB4.DataTextField = "ModifierName"
            txtB4.DataValueField = "ModifierID"
            txtB4.DataBind()
            txtC4.DataSource = lDS
            txtC4.DataTextField = "ModifierName"
            txtC4.DataValueField = "ModifierID"
            txtC4.DataBind()
            txtD4.DataSource = lDS
            txtD4.DataTextField = "ModifierName"
            txtD4.DataValueField = "ModifierID"
            txtD4.DataBind()
            txtA5.DataSource = lDS
            txtA5.DataTextField = "ModifierName"
            txtA5.DataValueField = "ModifierID"
            txtA5.DataBind()
            txtB5.DataSource = lDS
            txtB5.DataTextField = "ModifierName"
            txtB5.DataValueField = "ModifierID"
            txtB5.DataBind()
            txtC5.DataSource = lDS
            txtC5.DataTextField = "ModifierName"
            txtC5.DataValueField = "ModifierID"
            txtC5.DataBind()
            txtD5.DataSource = lDS
            txtD5.DataTextField = "ModifierName"
            txtD5.DataValueField = "ModifierID"
            txtD5.DataBind()
            txtA6.DataSource = lDS
            txtA6.DataTextField = "ModifierName"
            txtA6.DataValueField = "ModifierID"
            txtA6.DataBind()
            txtB6.DataSource = lDS
            txtB6.DataTextField = "ModifierName"
            txtB6.DataValueField = "ModifierID"
            txtB6.DataBind()
            txtC6.DataSource = lDS
            txtC6.DataTextField = "ModifierName"
            txtC6.DataValueField = "ModifierID"
            txtC6.DataBind()
            txtD6.DataSource = lDS
            txtD6.DataTextField = "ModifierName"
            txtD6.DataValueField = "ModifierID"
            txtD6.DataBind()
            txtA7.DataSource = lDS
            txtA7.DataTextField = "ModifierName"
            txtA7.DataValueField = "ModifierID"
            txtA7.DataBind()
            txtB7.DataSource = lDS
            txtB7.DataTextField = "ModifierName"
            txtB7.DataValueField = "ModifierID"
            txtB7.DataBind()
            txtC7.DataSource = lDS
            txtC7.DataTextField = "ModifierName"
            txtC7.DataValueField = "ModifierID"
            txtC7.DataBind()
            txtD7.DataSource = lDS
            txtD7.DataTextField = "ModifierName"
            txtD7.DataValueField = "ModifierID"
            txtD7.DataBind()
            txtA8.DataSource = lDS
            txtA8.DataTextField = "ModifierName"
            txtA8.DataValueField = "ModifierID"
            txtA8.DataBind()
            txtB8.DataSource = lDS
            txtB8.DataTextField = "ModifierName"
            txtB8.DataValueField = "ModifierID"
            txtB8.DataBind()
            txtC8.DataSource = lDS
            txtC8.DataTextField = "ModifierName"
            txtC8.DataValueField = "ModifierID"
            txtC8.DataBind()
            txtD8.DataSource = lDS
            txtD8.DataTextField = "ModifierName"
            txtD8.DataValueField = "ModifierID"
            txtD8.DataBind()
            txtA9.DataSource = lDS
            txtA9.DataTextField = "ModifierName"
            txtA9.DataValueField = "ModifierID"
            txtA9.DataBind()
            txtB9.DataSource = lDS
            txtB9.DataTextField = "ModifierName"
            txtB9.DataValueField = "ModifierID"
            txtB9.DataBind()
            txtC9.DataSource = lDS
            txtC9.DataTextField = "ModifierName"
            txtC9.DataValueField = "ModifierID"
            txtC9.DataBind()
            txtD9.DataSource = lDS
            txtD9.DataTextField = "ModifierName"
            txtD9.DataValueField = "ModifierID"
            txtD9.DataBind()
            txtA10.DataSource = lDS
            txtA10.DataTextField = "ModifierName"
            txtA10.DataValueField = "ModifierID"
            txtA10.DataBind()
            txtB10.DataSource = lDS
            txtB10.DataTextField = "ModifierName"
            txtB10.DataValueField = "ModifierID"
            txtB10.DataBind()
            txtC10.DataSource = lDS
            txtC10.DataTextField = "ModifierName"
            txtC10.DataValueField = "ModifierID"
            txtC10.DataBind()
            txtD10.DataSource = lDS
            txtD10.DataTextField = "ModifierName"
            txtD10.DataValueField = "ModifierID"
            txtD10.DataBind()
            txtA11.DataSource = lDS
            txtA11.DataTextField = "ModifierName"
            txtA11.DataValueField = "ModifierID"
            txtA11.DataBind()
            txtB11.DataSource = lDS
            txtB11.DataTextField = "ModifierName"
            txtB11.DataValueField = "ModifierID"
            txtB11.DataBind()
            txtC11.DataSource = lDS
            txtC11.DataTextField = "ModifierName"
            txtC11.DataValueField = "ModifierID"
            txtC11.DataBind()
            txtD11.DataSource = lDS
            txtD11.DataTextField = "ModifierName"
            txtD11.DataValueField = "ModifierID"
            txtD11.DataBind()
            txtA12.DataSource = lDS
            txtA12.DataTextField = "ModifierName"
            txtA12.DataValueField = "ModifierID"
            txtA12.DataBind()
            txtB12.DataSource = lDS
            txtB12.DataTextField = "ModifierName"
            txtB12.DataValueField = "ModifierID"
            txtB12.DataBind()
            txtC12.DataSource = lDS
            txtC12.DataTextField = "ModifierName"
            txtC12.DataValueField = "ModifierID"
            txtC12.DataBind()
            txtD12.DataSource = lDS
            txtD12.DataTextField = "ModifierName"
            txtD12.DataValueField = "ModifierID"
            txtD12.DataBind()
            txtA13.DataSource = lDS
            txtA13.DataTextField = "ModifierName"
            txtA13.DataValueField = "ModifierID"
            txtA13.DataBind()
            txtB13.DataSource = lDS
            txtB13.DataTextField = "ModifierName"
            txtB13.DataValueField = "ModifierID"
            txtB13.DataBind()
            txtC13.DataSource = lDS
            txtC13.DataTextField = "ModifierName"
            txtC13.DataValueField = "ModifierID"
            txtC13.DataBind()
            txtD13.DataSource = lDS
            txtD13.DataTextField = "ModifierName"
            txtD13.DataValueField = "ModifierID"
            txtD13.DataBind()
            txtA14.DataSource = lDS
            txtA14.DataTextField = "ModifierName"
            txtA14.DataValueField = "ModifierID"
            txtA14.DataBind()
            txtB14.DataSource = lDS
            txtB14.DataTextField = "ModifierName"
            txtB14.DataValueField = "ModifierID"
            txtB14.DataBind()
            txtC14.DataSource = lDS
            txtC14.DataTextField = "ModifierName"
            txtC14.DataValueField = "ModifierID"
            txtC14.DataBind()
            txtD14.DataSource = lDS
            txtD14.DataTextField = "ModifierName"
            txtD14.DataValueField = "ModifierID"
            txtD14.DataBind()
            txtA15.DataSource = lDS
            txtA15.DataTextField = "ModifierName"
            txtA15.DataValueField = "ModifierID"
            txtA15.DataBind()
            txtB15.DataSource = lDS
            txtB15.DataTextField = "ModifierName"
            txtB15.DataValueField = "ModifierID"
            txtB15.DataBind()
            txtC15.DataSource = lDS
            txtC15.DataTextField = "ModifierName"
            txtC15.DataValueField = "ModifierID"
            txtC15.DataBind()
            txtD15.DataSource = lDS
            txtD15.DataTextField = "ModifierName"
            txtD15.DataValueField = "ModifierID"
            txtD15.DataBind()
            txtA16.DataSource = lDS
            txtA16.DataTextField = "ModifierName"
            txtA16.DataValueField = "ModifierID"
            txtA16.DataBind()
            txtB16.DataSource = lDS
            txtB16.DataTextField = "ModifierName"
            txtB16.DataValueField = "ModifierID"
            txtB16.DataBind()
            txtC16.DataSource = lDS
            txtC16.DataTextField = "ModifierName"
            txtC16.DataValueField = "ModifierID"
            txtC16.DataBind()
            txtD16.DataSource = lDS
            txtD16.DataTextField = "ModifierName"
            txtD16.DataValueField = "ModifierID"
            txtD16.DataBind()
            txtA17.DataSource = lDS
            txtA17.DataTextField = "ModifierName"
            txtA17.DataValueField = "ModifierID"
            txtA17.DataBind()
            txtB17.DataSource = lDS
            txtB17.DataTextField = "ModifierName"
            txtB17.DataValueField = "ModifierID"
            txtB17.DataBind()
            txtC17.DataSource = lDS
            txtC17.DataTextField = "ModifierName"
            txtC17.DataValueField = "ModifierID"
            txtC17.DataBind()
            txtD17.DataSource = lDS
            txtD17.DataTextField = "ModifierName"
            txtD17.DataValueField = "ModifierID"
            txtD17.DataBind()
            txtA18.DataSource = lDS
            txtA18.DataTextField = "ModifierName"
            txtA18.DataValueField = "ModifierID"
            txtA18.DataBind()
            txtB18.DataSource = lDS
            txtB18.DataTextField = "ModifierName"
            txtB18.DataValueField = "ModifierID"
            txtB18.DataBind()
            txtC18.DataSource = lDS
            txtC18.DataTextField = "ModifierName"
            txtC18.DataValueField = "ModifierID"
            txtC18.DataBind()
            txtD18.DataSource = lDS
            txtD18.DataTextField = "ModifierName"
            txtD18.DataValueField = "ModifierID"
            txtD18.DataBind()
        Catch ex As Exception

        End Try
    End Sub
    Public Function LoadFeesSch(ByVal pCPTCode As String) As String
        Dim lDS As New DataSet
        Dim lFees As Double = 0.0
        Try
            lDS = New DataSet
            If (txtHdnPatPriInsID.Text <> "") Then
                lDS = PatientSuperBillMethods.GetFeesSchForCPT(txtHdnPatPriInsID.Text, pCPTCode)
                If (lDS.Tables.Count > 0 AndAlso lDS.Tables(0).Rows.Count > 0) Then
                    lFees = lDS.Tables(0).Rows(0).Item("Fees").ToString
                    Return lFees
                Else
                    Return "NA"
                End If
            Else
                Return "NA"
            End If

        Catch ex As Exception
            Return lFees
        End Try
    End Function
    Protected Sub btnFees_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnFees1.Click, btnFees2.Click, btnFees3.Click, btnFees4.Click, btnFees5.Click, btnFees6.Click
        Dim lFees As Double
        Dim lResult As String
        hdrBar.Visible = False
        Try
            Dim lID As String = sender.ID
            If (lID = "btnFees1") Then
                lResult = LoadFeesSch(cmbCPT1.Text)
                If (lResult <> "NA") Then
                    lFees = CType(lResult, Double)
                    txtCharges1.Text = String.Format("{0:0.00}", lFees)
                End If
                cmbPOS1.SelectedIndex = cmbFacility.SelectedIndex
                ChangeControlsStates("1")
            ElseIf (lID = "btnFees2") Then
                lResult = LoadFeesSch(cmbCPT2.Text)
                If (lResult <> "NA") Then
                    lFees = CType(lResult, Double)
                    txtCharges2.Text = String.Format("{0:0.00}", lFees)
                End If
                cmbPOS2.SelectedIndex = cmbFacility.SelectedIndex
                ChangeControlsStates("2")
            ElseIf (lID = "btnFees3") Then
                lResult = LoadFeesSch(cmbCPT3.Text)
                If (lResult <> "NA") Then
                    lFees = CType(lResult, Double)
                    txtCharges3.Text = String.Format("{0:0.00}", lFees)
                End If
                cmbPOS3.SelectedIndex = cmbFacility.SelectedIndex
                ChangeControlsStates("3")
            ElseIf (lID = "btnFees4") Then
                lResult = LoadFeesSch(cmbCPT4.Text)
                If (lResult <> "NA") Then
                    lFees = CType(lResult, Double)
                    txtCharges4.Text = String.Format("{0:0.00}", lFees)
                End If
                cmbPOS4.SelectedIndex = cmbFacility.SelectedIndex
                ChangeControlsStates("4")
            ElseIf (lID = "btnFees5") Then
                lResult = LoadFeesSch(cmbCPT5.Text)
                If (lResult <> "NA") Then
                    lFees = CType(lResult, Double)
                    txtCharges5.Text = String.Format("{0:0.00}", lFees)
                End If
                cmbPOS5.SelectedIndex = cmbFacility.SelectedIndex
                ChangeControlsStates("5")
            ElseIf (lID = "btnFees6") Then
                lResult = LoadFeesSch(cmbCPT6.Text)
                If (lResult <> "NA") Then
                    lFees = CType(lResult, Double)
                    txtCharges6.Text = String.Format("{0:0.00}", lFees)
                End If
                cmbPOS6.SelectedIndex = cmbFacility.SelectedIndex
                ChangeControlsStates("6")
            End If

        Catch ex As Exception

        End Try
    End Sub
    Public Sub ChangeControlsStates(ByVal pNewlyAddedLineNo As String)
        Try
            'txtApproved.Text = "U"
            'btnEditVisit.Enabled = False
            'btnSavenPrint.Enabled = True
            'txtApproved.Text = "A"
            'EnableControls(pnlMain)
            'EnableControls(btnSave)
            'EnableControls(btnSavenPrint)
            'checkapprove.Disabled = True

            setMaxDate()

            If (txtApproved.Text = "U") Then
                checkapprove.Disabled = False
                btnEditVisit.Enabled = False
                btnEditVisit.ImageUrl = "~/Images/make-editable-disable.gif"
                btnEditVisit.Style.Add("cursor:default", "cursor:default")
                EnableControls(pnlMain)
                btnSave.Enabled = True
                btnSaveCopy.Enabled = True
                dtVisitDisplayDate.Enabled = True
                txtLineId1.Text = "0"
                txtLineId2.Text = "0"
                txtLineId3.Text = "0"
                txtLineId4.Text = "0"
                txtLineId5.Text = "0"
                txtLineId6.Text = "0"

                'CType(FindControl("ctl00$ContentPlaceHolder1$dtDate11"), RadDatePicker).Enabled = False
                'CType(FindControl("ctl00$ContentPlaceHolder1$dtDate21"), RadDatePicker).Enabled = False
                'CType(FindControl("ctl00$ContentPlaceHolder1$dtDate31"), RadDatePicker).Enabled = False
                'CType(FindControl("ctl00$ContentPlaceHolder1$dtDate41"), RadDatePicker).Enabled = False
                'CType(FindControl("ctl00$ContentPlaceHolder1$dtDate51"), RadDatePicker).Enabled = False
                'CType(FindControl("ctl00$ContentPlaceHolder1$dtDate61"), RadDatePicker).Enabled = False

                'dtDate11.Enabled = False
                'dtDate21.Enabled = False
                'dtDate31.Enabled = False
                'dtDate41.Enabled = False
                'dtDate51.Enabled = False
                'dtDate61.Enabled = False

                'If (cmbCPT1.Text <> "") Then
                '    dtDate11.SelectedDate = dtDate12.SelectedDate
                'End If
                'If (cmbCPT2.Text <> "") Then
                '    dtDate21.SelectedDate = dtDate22.SelectedDate
                'End If
                'If (cmbCPT3.Text <> "") Then
                '    dtDate31.SelectedDate = dtDate32.SelectedDate
                'End If
                'If (cmbCPT4.Text <> "") Then
                '    dtDate41.SelectedDate = dtDate42.SelectedDate
                'End If
                'If (cmbCPT5.Text <> "") Then
                '    dtDate51.SelectedDate = dtDate52.SelectedDate
                'End If
                'If (cmbCPT6.Text <> "") Then
                '    dtDate61.SelectedDate = dtDate62.SelectedDate
                'End If

                For index As Int16 = 1 To 6
                    CType(FindControl("ctl00$ContentPlaceHolder1$imgRev" & index), ImageButton).Enabled = False
                    CType(FindControl("ctl00$ContentPlaceHolder1$imgRev" & index), ImageButton).ImageUrl = "../Images/reverse-disable.gif"
                    CType(FindControl("ctl00$ContentPlaceHolder1$imgRev" & index), ImageButton).Style.Add("cursor:default", "cursor:default")
                Next
            Else
                hdrBar.Visible = False
                EnableControls(pnlMain)
                btnSave.Enabled = True
                btnSaveCopy.Enabled = True
                checkapprove.Disabled = True
                btnEditVisit.Enabled = True
                btnEditVisit.ImageUrl = "~/Images/make-editable-off.gif"
                dtVisitDisplayDate.Enabled = False
                For lineNo As Int16 = 1 To 6
                    If (CType(FindControl("ctl00$ContentPlaceHolder1$txtLineId" & lineNo), TextBox).Text = "0" Or CType(FindControl("ctl00$ContentPlaceHolder1$txtLineId" & lineNo), TextBox).Text = "R") Then
                        'CType(FindControl("ctl00$ContentPlaceHolder1$pnlRow" & lineNo), Panel).Enabled = True
                        CType(FindControl("ctl00$ContentPlaceHolder1$dtDate" & lineNo & "1"), RadDatePicker).Enabled = True
                        CType(FindControl("ctl00$ContentPlaceHolder1$dtDate" & lineNo & "2"), RadDatePicker).Enabled = True
                        CType(FindControl("ctl00$ContentPlaceHolder1$cmbPOS" & lineNo), DropDownList).Enabled = True
                        'Dim radcom As RadComboBox = CType(FindControl("ctl00$ContentPlaceHolder1$cmbCPT" & lineNo), RadComboBox)
                        'radcom.Items.Clear()
                        CType(FindControl("ctl00$ContentPlaceHolder1$cmbCPT" & lineNo), RadComboBox).Enabled = True

                        If CType(FindControl("ctl00$ContentPlaceHolder1$hdIsDeleted" & lineNo), TextBox).Text = "Y" Then
                            CType(FindControl("ctl00$ContentPlaceHolder1$cmbCPT" & lineNo), RadComboBox).Text = ""
                        End If

                        'CType(FindControl("ctl00$ContentPlaceHolder1$cmbCPT" & lineNo), RadComboBox).Items.Clear()
                        CType(FindControl("ctl00$ContentPlaceHolder1$btnCPTSearch" & lineNo), ImageButton).Enabled = True
                        CType(FindControl("ctl00$ContentPlaceHolder1$cmbIMO" & lineNo), TextBox).Enabled = True
                        CType(FindControl("ctl00$ContentPlaceHolder1$txtA" & lineNo), DropDownList).Enabled = True
                        CType(FindControl("ctl00$ContentPlaceHolder1$txtB" & lineNo), DropDownList).Enabled = True
                        CType(FindControl("ctl00$ContentPlaceHolder1$txtC" & lineNo), DropDownList).Enabled = True
                        CType(FindControl("ctl00$ContentPlaceHolder1$txtD" & lineNo), DropDownList).Enabled = True
                        CType(FindControl("ctl00$ContentPlaceHolder1$txtPointer" & lineNo), TextBox).Enabled = True
                        CType(FindControl("ctl00$ContentPlaceHolder1$txtDays" & lineNo), TextBox).Enabled = True
                        CType(FindControl("ctl00$ContentPlaceHolder1$txtCharges" & lineNo), TextBox).Enabled = True
                        CType(FindControl("ctl00$ContentPlaceHolder1$txtFromGrid" & lineNo), TextBox).Enabled = True
                        CType(FindControl("ctl00$ContentPlaceHolder1$txtHeading" & lineNo), TextBox).Enabled = True
                        CType(FindControl("ctl00$ContentPlaceHolder1$imgBtn" & lineNo), ImageButton).Enabled = True
                        CType(FindControl("ctl00$ContentPlaceHolder1$imgBtn" & lineNo), ImageButton).ImageUrl = "../Images/false-ico.gif"
                        CType(FindControl("ctl00$ContentPlaceHolder1$imgBtn" & lineNo), ImageButton).Style.Add("cursor:pointer;cursor:hand", "cursor:pointer;cursor:hand")
                        CType(FindControl("ctl00$ContentPlaceHolder1$imgRev" & lineNo), ImageButton).Enabled = False
                        CType(FindControl("ctl00$ContentPlaceHolder1$imgRev" & lineNo), ImageButton).ImageUrl = "../Images/reverse-disable.gif"
                        CType(FindControl("ctl00$ContentPlaceHolder1$imgRev" & lineNo), ImageButton).Style.Add("cursor:default", "cursor:default")
                    Else
                        'CType(FindControl("ctl00$ContentPlaceHolder1$pnlRow" & lineNo), Panel).Enabled = False
                        CType(FindControl("ctl00$ContentPlaceHolder1$dtDate" & lineNo & "1"), RadDatePicker).Enabled = False
                        CType(FindControl("ctl00$ContentPlaceHolder1$dtDate" & lineNo & "2"), RadDatePicker).Enabled = False
                        CType(FindControl("ctl00$ContentPlaceHolder1$cmbPOS" & lineNo), DropDownList).Enabled = False
                        'Dim radcom As RadComboBox = CType(FindControl("ctl00$ContentPlaceHolder1$cmbCPT" & lineNo), RadComboBox)
                        'radcom.Enabled = False
                        CType(FindControl("ctl00$ContentPlaceHolder1$cmbCPT" & lineNo), RadComboBox).Enabled = False
                        CType(FindControl("ctl00$ContentPlaceHolder1$btnCPTSearch" & lineNo), ImageButton).Enabled = False
                        CType(FindControl("ctl00$ContentPlaceHolder1$cmbIMO" & lineNo), TextBox).Enabled = False
                        CType(FindControl("ctl00$ContentPlaceHolder1$txtA" & lineNo), DropDownList).Enabled = False
                        CType(FindControl("ctl00$ContentPlaceHolder1$txtB" & lineNo), DropDownList).Enabled = False
                        CType(FindControl("ctl00$ContentPlaceHolder1$txtC" & lineNo), DropDownList).Enabled = False
                        CType(FindControl("ctl00$ContentPlaceHolder1$txtD" & lineNo), DropDownList).Enabled = False
                        CType(FindControl("ctl00$ContentPlaceHolder1$txtPointer" & lineNo), TextBox).Enabled = False
                        CType(FindControl("ctl00$ContentPlaceHolder1$txtDays" & lineNo), TextBox).Enabled = False
                        CType(FindControl("ctl00$ContentPlaceHolder1$txtCharges" & lineNo), TextBox).Enabled = False
                        CType(FindControl("ctl00$ContentPlaceHolder1$txtFromGrid" & lineNo), TextBox).Enabled = False
                        CType(FindControl("ctl00$ContentPlaceHolder1$txtHeading" & lineNo), TextBox).Enabled = False
                        CType(FindControl("ctl00$ContentPlaceHolder1$imgBtn" & lineNo), ImageButton).Enabled = False
                        CType(FindControl("ctl00$ContentPlaceHolder1$imgBtn" & lineNo), ImageButton).ImageUrl = "../Images/false-ico-disable.gif"
                        CType(FindControl("ctl00$ContentPlaceHolder1$imgBtn" & lineNo), ImageButton).Style.Add("cursor:default", "cursor:default")
                        CType(FindControl("ctl00$ContentPlaceHolder1$imgRev" & lineNo), ImageButton).Enabled = True
                        CType(FindControl("ctl00$ContentPlaceHolder1$imgRev" & lineNo), ImageButton).ImageUrl = "../Images/reverse.gif"
                        CType(FindControl("ctl00$ContentPlaceHolder1$imgRev" & lineNo), ImageButton).Style.Add("cursor:pointer;cursor:hand", "cursor:pointer;cursor:hand")
                    End If
                Next
                If (pNewlyAddedLineNo <> "0") Then
                    'CType(FindControl("ctl00$ContentPlaceHolder1$pnlRow" & pNewlyAddedLineNo), Panel).Enabled = True
                    CType(FindControl("ctl00$ContentPlaceHolder1$dtDate" & pNewlyAddedLineNo & "1"), RadDatePicker).Enabled = True
                    CType(FindControl("ctl00$ContentPlaceHolder1$dtDate" & pNewlyAddedLineNo & "2"), RadDatePicker).Enabled = True
                    CType(FindControl("ctl00$ContentPlaceHolder1$cmbPOS" & pNewlyAddedLineNo), DropDownList).Enabled = True
                    CType(FindControl("ctl00$ContentPlaceHolder1$cmbCPT" & pNewlyAddedLineNo), RadComboBox).Enabled = True
                    CType(FindControl("ctl00$ContentPlaceHolder1$btnCPTSearch" & pNewlyAddedLineNo), ImageButton).Enabled = True
                    CType(FindControl("ctl00$ContentPlaceHolder1$cmbIMO" & pNewlyAddedLineNo), TextBox).Enabled = True
                    CType(FindControl("ctl00$ContentPlaceHolder1$txtA" & pNewlyAddedLineNo), DropDownList).Enabled = True
                    CType(FindControl("ctl00$ContentPlaceHolder1$txtB" & pNewlyAddedLineNo), DropDownList).Enabled = True
                    CType(FindControl("ctl00$ContentPlaceHolder1$txtC" & pNewlyAddedLineNo), DropDownList).Enabled = True
                    CType(FindControl("ctl00$ContentPlaceHolder1$txtD" & pNewlyAddedLineNo), DropDownList).Enabled = True
                    CType(FindControl("ctl00$ContentPlaceHolder1$txtPointer" & pNewlyAddedLineNo), TextBox).Enabled = True
                    CType(FindControl("ctl00$ContentPlaceHolder1$txtDays" & pNewlyAddedLineNo), TextBox).Enabled = True
                    CType(FindControl("ctl00$ContentPlaceHolder1$txtCharges" & pNewlyAddedLineNo), TextBox).Enabled = True
                    CType(FindControl("ctl00$ContentPlaceHolder1$txtFromGrid" & pNewlyAddedLineNo), TextBox).Enabled = True
                    CType(FindControl("ctl00$ContentPlaceHolder1$txtHeading" & pNewlyAddedLineNo), TextBox).Enabled = True
                    CType(FindControl("ctl00$ContentPlaceHolder1$imgBtn" & pNewlyAddedLineNo), ImageButton).Enabled = True
                    CType(FindControl("ctl00$ContentPlaceHolder1$imgBtn" & pNewlyAddedLineNo), ImageButton).ImageUrl = "../Images/false-ico.gif"
                    CType(FindControl("ctl00$ContentPlaceHolder1$imgBtn" & pNewlyAddedLineNo), ImageButton).Style.Add("cursor:pointer;cursor:hand", "cursor:pointer;cursor:hand")
                    CType(FindControl("ctl00$ContentPlaceHolder1$imgRev" & pNewlyAddedLineNo), ImageButton).Enabled = False
                    CType(FindControl("ctl00$ContentPlaceHolder1$imgRev" & pNewlyAddedLineNo), ImageButton).ImageUrl = "../Images/reverse-disable.gif"
                    CType(FindControl("ctl00$ContentPlaceHolder1$imgRev" & pNewlyAddedLineNo), ImageButton).Style.Add("cursor:default", "cursor:default")
                End If
            End If
            'EnableControls(LowerPanel)
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub cmbProvider_SelectedIndexChanged(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxSelectedIndexChangedEventArgs) Handles cmbProvider.SelectedIndexChanged
        Try
            ChangeControlsStates("0")
            Me.hdrBar.Visible = False
            Utility.SelectComboItem(cmbProvider1, cmbProvider.SelectedValue, True)
            Utility.SelectComboItem(cmbProvider2, cmbProvider.SelectedValue, True)
            Utility.SelectComboItem(cmbProvider3, cmbProvider.SelectedValue, True)
            Utility.SelectComboItem(cmbProvider4, cmbProvider.SelectedValue, True)
            Utility.SelectComboItem(cmbProvider5, cmbProvider.SelectedValue, True)
            Utility.SelectComboItem(cmbProvider6, cmbProvider.SelectedValue, True)

            LoadBillingProviderCombo(DirectCast(Session("User"), User), ViewState("FavouriteInsuranceID"))
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub cmbFacility_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbFacility.SelectedIndexChanged
        Try
            'SelectPosFacilityComboItem()
            ChangeControlsStates("0")
            'SelectPosFacilityComboItem()
            Me.hdrBar.Visible = False
            If (cmbFacility.SelectedIndex > -1) Then
                If (cmbCPT1.Text = "") Then
                    cmbPOS1.ClearSelection()
                    cmbPOS1.SelectedIndex = cmbPOS1.Items.IndexOf(cmbPOS1.Items.FindByValue(cmbFacility.SelectedValue))
                End If

                If (cmbCPT2.Text = "") Then
                    cmbPOS2.ClearSelection()
                    cmbPOS2.SelectedIndex = cmbPOS1.Items.IndexOf(cmbPOS1.Items.FindByValue(cmbFacility.SelectedValue))
                End If

                If (cmbCPT3.Text = "") Then
                    cmbPOS3.ClearSelection()
                    cmbPOS3.SelectedIndex = cmbPOS1.Items.IndexOf(cmbPOS1.Items.FindByValue(cmbFacility.SelectedValue))
                End If

                If (cmbCPT4.Text = "") Then
                    cmbPOS4.ClearSelection()
                    cmbPOS4.SelectedIndex = cmbPOS1.Items.IndexOf(cmbPOS1.Items.FindByValue(cmbFacility.SelectedValue))
                End If

                If (cmbCPT5.Text = "") Then
                    cmbPOS5.ClearSelection()
                    cmbPOS5.SelectedIndex = cmbPOS1.Items.IndexOf(cmbPOS1.Items.FindByValue(cmbFacility.SelectedValue))
                End If

                If (cmbCPT6.Text = "") Then
                    cmbPOS6.ClearSelection()
                    cmbPOS6.SelectedIndex = cmbPOS1.Items.IndexOf(cmbPOS1.Items.FindByValue(cmbFacility.SelectedValue))
                End If
            End If

        Catch ex As Exception

        End Try
    End Sub
    Public Sub PageExpire()
        Response.Buffer = True
        Response.ExpiresAbsolute = Now.Subtract(New TimeSpan(1, 0, 0, 0))
        Response.Expires = 0
        Response.CacheControl = "no-cache"
    End Sub
    Public Sub setMaxDate()
        dtDate11.MaxDate = Date.Now.Date
        dtDate21.MaxDate = Date.Now.Date
        dtDate31.MaxDate = Date.Now.Date
        dtDate41.MaxDate = Date.Now.Date
        dtDate51.MaxDate = Date.Now.Date
        dtDate61.MaxDate = Date.Now.Date
        dtDate12.MaxDate = Date.Now.Date
        dtDate22.MaxDate = Date.Now.Date
        dtDate32.MaxDate = Date.Now.Date
        dtDate42.MaxDate = Date.Now.Date
        dtDate52.MaxDate = Date.Now.Date
        dtDate62.MaxDate = Date.Now.Date
    End Sub
    Protected Sub imgRev1Copy_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgRev1Copy.Click
        Try
            ChangeControlsStates(1)
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub imgRev2Copy_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgRev2Copy.Click
        Try
            ChangeControlsStates(2)
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub imgRev3Copy_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgRev3Copy.Click
        Try
            ChangeControlsStates(3)
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub imgRev4Copy_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgRev4Copy.Click
        Try
            ChangeControlsStates(4)
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub imgRev5Copy_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgRev5Copy.Click
        Try
            ChangeControlsStates(5)
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub imgRev6Copy_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgRev6Copy.Click
        Try
            ChangeControlsStates(6)
        Catch ex As Exception

        End Try
    End Sub
End Class
