
Partial Class Billing_AddNewFacility
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim lIsAuthorize As Boolean
        Dim lUser As User
        Dim lUserRoles As UserRoles



        If Not Page.IsPostBack Then

            lUser = CType(Session.Item("User"), User)
            lUserRoles = New UserRoles(lUser.ConnectionString)


            '********* Check User Validity ************
            lIsAuthorize = lUserRoles.CheckPageAuthorization(lUser.UserId, "AddEmployee.aspx")
            If Not lIsAuthorize Then
                Response.Redirect("unauthorization.aspx")
            End If
            tsFacility.SelectedIndex = 0
            mpFacility.SelectedIndex = 0

            'StateMethods.Load_States(cmbState, lUser)

        End If

    End Sub
    Protected Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnCancel.Click
        Response.Redirect("FacilitySetup.aspx")
    End Sub

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSave.Click


        Dim a As String
        a = "'"
        Dim lFacilityDB As FacilityDB = New FacilityDB
        With lFacilityDB
            .FacilityName = txtFacilityName.Text
            .NPI = txtNPI.Text
            .AddressLine1 = txtAddressLine1.Text
            .AddressLine2 = txtAddressLine2.Text
            .Fax = mtbFax.Text
            .Phone = mtbHomePhone.Text
            .ZipCode = mtbZipCode.Text
            .State = cmbState.Text
            .City = txtCity.Text
            .FacilityCode = txtFacilityCode.Text
        End With

        If FacilityMethods.AddFacility(lFacilityDB) Then
            Me.RadAjaxManager1.Alert("Facility Added Successfully")
            Me.RadAjaxManager1.Redirect("FacilitySetup.aspx")
            'lblMessage.Text = "Facility Added Successfully"
        Else
            Me.RadAjaxManager1.Alert("Facility Not Added - Please Try again")
            'lblMessage.Text = "Facility Not Added - Please Try again"
        End If

    End Sub

    Protected Sub cmbState_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbState.ItemsRequested
        Dim lUser As User
        lUser = CType(Session.Item("User"), User)

        Dim lCond As String
        lCond = "And Abbr Like '" & Utility.AdjustApostrophie(e.Text) & "%' "

        If (e.Text = "") Then
            Exit Sub
        End If

        StateMethods.Load_States(cmbState, lUser, lCond)
    End Sub
End Class
