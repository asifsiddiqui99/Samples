
Partial Class Billing_PaymentRemitanceDetail
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim lUser As New User
        lUser = CType(Session("User"), User)
        Dim queryString As NameValueCollection

        Dim lRemDtl As New RemittanceClaimDtl(lUser.ConnectionString)
        queryString = Encryption.DecryptQueryString(Request.QueryString.ToString)
        lRemDtl.RemittanceClaimDtl.RemittanceId = queryString("RemID")
        grdRemitance.DataSource = lRemDtl.GetRemitanceDetailForGrid()
        grdRemitance.DataBind()
    End Sub
End Class
