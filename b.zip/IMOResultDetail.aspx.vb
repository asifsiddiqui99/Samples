
Partial Class Billing_IMOResultDetail
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If (Session("XmlDataString") <> Nothing) Then

            Me.xmlSrcMedNec.Data = Session("XmlDataString")
            'Me.xmlSrcMedNec.Data = "<?xml version=""1.0"" standalone=""yes""?><items elapsed=""0.000s"" size=""4"" totalsize=""4"" inception=""07/07/2009 21:28"" softexpiration=""12/01/2010"" hardexpiration=""12/01/2010"" licenseexpiration=""12/01/2020"" source=""Medical Necessity"" context=""National"" datasetversion=""IMOMedicalNecessity"" minversion=""1.5.0.3"" searchmode=""Stem"" searchstring=""search^1^48|786.2,786.2|D9430,D9440""><item type=""1to2"" code=""786.2"" matchedcode="""" check="""" reference=""10918,28544,28723,19684"" /><item type=""1to2"" code=""786.2"" matchedcode="""" check="""" reference=""10918,28544,28723,19684"" /><item type=""2to1"" code=""D9430"" matchedcode="""" check=""insufficient information"" reference="""" /><item type=""2to1"" code=""D9440"" matchedcode="""" check=""insufficient information"" reference="""" /></items>"
            Me.grdResult.DataSource = xmlSrcMedNec
            grdResult.DataBind()
        End If

    End Sub
End Class
