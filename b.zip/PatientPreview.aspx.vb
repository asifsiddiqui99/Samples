Imports Telerik.WebControls
Partial Class Billing_PatientPreview
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        

        ' Dim lRadWindow As RadWindow

        RadTabStrip1.SelectedIndex = 0
        mpPatient.SelectedIndex = 0

        If (Session("EditPatientID") Is Nothing) Then
            Session("EditPatientID") = ""
        End If


      ''for report purpose........
        '        If (Request.QueryString("PopupRedirect") <> Nothing) Then

        'Dim popupScript As String = "<script language='javascript'>" & _
        '  "window.open('PSBPrint.aspx?sid=" & Request.QueryString.Get(0).ToString() & "', 'PSBPrint' )" & _
        '  "</script>"
        '                  Page.RegisterStartupScript("PopupScript", popupScript)
        '        End If

        Dim lUser As User
        Dim lIsAuthorize As Boolean
        Dim lUserRoles As UserRoles
        Dim lLogId As Int32 = 0

        If Not Page.IsPostBack Then

            Try
                lUser = CType(Session.Item("User"), User)
                lUserRoles = New UserRoles(lUser.ConnectionString)


                Try
                    '********* Check User Validity ************
                    lIsAuthorize = lUserRoles.CheckPageAuthorization(lUser.UserId, "EditPatientTS.aspx")
                    If Not lIsAuthorize Then
                        Response.Redirect("unauthorization.aspx")
                    End If
                Catch ex As Exception
                    ErrorLogMethods.LogError(ex, "PatientPreview.aspx\Page_Load().CheckPageAuthorization()")
                    Response.Redirect("unauthorization.aspx")
                End Try

                RadTabStrip1.SelectedIndex = 0
                mpPatient.SelectedIndex = 0
                Me.dtDOB.MaxDate = DateTime.Today
                Me.dtSignatureDate.MaxDate = DateTime.Today

                '***** Get EmployeeId from Query String ********
                'If Request.QueryString("EditID") Is Nothing Then
                'Return
                'End If

                'Request.QueryString.Add("EditID", "10")
                'Request.QueryString("EditID").ToString()
                '***** Get EmployeeId from Query String ********

                'Me.btnUpdate.Attributes.Add("onclick", "return confirm('Are you sure you want to Update?');")
                'Me.btnInsuranceSave.Attributes.Add("onclick", "return confirm('Are you sure you want to Update?');")
                'Me.btnAllergySave.Attributes.Add("onclick", "return confirm('Are you sure you want to Update?');")


                '*********** Load States Combo ****************
                Dim lCommonMethods As New CommonMethods(lUser.ConnectionString)
                'StateMethods.Load_States(cmbState, lUser)
                lCommonMethods.Load_States(cmbState)
                'lCommonMethods.Load_States(Me.cmbEmployerState)
                'lCommonMethods.Load_States(Me.cmbEmergencyState)
                lCommonMethods.Load_States(Me.cmbResponsibleState)

                '*********** Load patient ***********'
                'LoadPatient("")

                '*********** Load SuperBill Combo ***********'
                LoadSuperBillCombo()
            Catch ex As Exception
                lLogId = ErrorLogMethods.LogError(ex, "PatientPreview.aspx\Page_Load()")
                Response.Redirect("ErrorPage.aspx?LogId=" & lLogId)
            End Try
            
        End If

        '' ''lRadWindow = CType(rwmSuperBill.FindControl("rwICD9Search"), RadWindow)
        '' ''lRadWindow.NavigateUrl = "PatientSearch.aspx"
        '' ''lRadWindow.OffsetElementId = Me.btnPrimaryInsurerSearch.ClientID

        '' ''lRadWindow = CType(rwmSuperBill.FindControl("rwCPTSearch"), RadWindow)
        '' ''lRadWindow.NavigateUrl = "PatientSearch.aspx"
        '' ''lRadWindow.OffsetElementId = Me.ImageButton1.ClientID

        '' ''lRadWindow = CType(rwmSuperBill.FindControl("rwPreviewSearch"), RadWindow)
        '' ''lRadWindow.NavigateUrl = "PatientSearch.aspx"
        '' ''lRadWindow.OffsetElementId = Me.btnSearch.ClientID

    End Sub
    Private Sub LoadPatient(ByVal pPatientId As String)
        Dim lUser As User
        Dim lResult As Boolean
        Dim lResultPrimaryInsurance As Boolean
        Dim lResultSecondaryInsurance As Boolean
        Dim lPatient As PatientExtended
        Dim lPatientInsurancePrimary As PatientInsurance
        Dim lPatientInsuranceSecondary As PatientInsurance
        Dim lLogId As Int32 = 0
        Me.lblReturnedPrimaryInsurerInfo.Text = ""
        Me.lblSecInsurerStatus.Text = ""
        Dim lPatientId As String = pPatientId


        Try
            ResetPrimaryInsurance(False)
            ResetSecondaryInsurance(False)
            'If Request.QueryString("EditID") Is Nothing Then
            'Exit Sub
            'End If
            'Dim lPatientId As String = Request.QueryString("EditID").ToString()

            lUser = CType(Session.Item("User"), User)
            lPatient = New PatientExtended(lUser.ConnectionString)
            lPatient.Patient.PatientID = lPatientId
            lResult = lPatient.GetRecordByID()
            'lResult = lPatient.GetPatientWithDetailsByID()

            If Not lResult Then
                lPatientId = ""
                Return
            End If

            lPatientInsurancePrimary = New PatientInsurance(lUser.ConnectionString)
            lPatientInsurancePrimary.PatientInsurance.PatientID = lPatientId
            lPatientInsurancePrimary.PatientInsurance.Type = "P"
            lResultPrimaryInsurance = lPatientInsurancePrimary.GetRecordByID()

            lPatientInsuranceSecondary = New PatientInsurance(lUser.ConnectionString)
            lPatientInsuranceSecondary.PatientInsurance.PatientID = lPatientId
            lPatientInsuranceSecondary.PatientInsurance.Type = "S"
            lResultSecondaryInsurance = lPatientInsuranceSecondary.GetRecordByID()

            With lPatient.Patient
                'Personal
                'Utility.SelectComboItem(cmbTitle, .Title, False)
                'Utility.SelectComboItem(Me.cmbMaritialStatus, .MartialStatus, False)
                txtFirstName.Text = .FirstName
                txtMiddleName.Text = .MiddleName
                txtLastName.Text = .LastName
                Utility.SelectComboItem(cmbGender, .Gender, False)
                dtDOB.SelectedDate = .DOB
                txtAddressLine1.Text = .AddressLine1
                txtAddressLine2.Text = .AddressLine2
                txtCity.Text = .City
                Utility.SelectComboItem(cmbState, .StateID, True)
                Me.mtbZipCode.Text = .ZipCode
                mtbHousePhone.Text = .HomePhone
                'mtbWorkPhone.Text = .WorkPhone
                'txtExtension.Text = .WorkPhoneExtension
                'mtbFax.Text = .Fax
                'txtEmail.Text = .Email
                'Me.mtbSSN.Text = .SSN
                'Me.txtOccupation.Text = .Occupation

                'Emergency
                'Me.txtEmergencyContactName.Text = .EmergencyContactName
                'Me.txtEmergencyRelationship.Text = .EmergencyContactRelationship
                'Me.mtbEmergencyPhoneNumber.Text = .EmergencyContactPhone
                'Me.txtEmergencyAddress.Text = .EmergencyContactAddress
                'Me.txtEmergencyCity.Text = .EmergencyContactCity
                'Utility.SelectComboItem(Me.cmbEmergencyState, .EmergencyContactState, True)

                'Responsible
                Me.txtResponsibleName.Text = .ResponsibleName
                Me.txtResponsibleCity.Text = .ResponsibleCity
                Me.txtResponsibleAddress.Text = .ResponsibleAddress
                Me.mtbResponsibleHomePhone.Text = .ResponsibleHomePhone
                Me.mtbResponsibleSSN.Text = .ResponsibleSSN
                Me.mtbResponsibleWorkPhone.Text = .ResponsibleWorkPhone
                Me.mtbResponsibleZip.Text = .ResponsibleZip
                Utility.SelectComboItem(Me.cmbResponsibleState, .ResponsibleState, True)
                Utility.SelectComboItem(Me.cmbResponsibleRelationship, .ResponsibleRelationship, True)


                'Employement Info
                'Me.txtEmployerName.Text = .EmployerName
                'Utility.SelectComboItem(Me.cmbEmploymentStatus, .EmploymentStatus, False)
                'Me.txtEmployerAddressline1.Text = .EmployerAddressLine1
                'Me.txtEmployerAddressline2.Text = .EmployerAddressLine2
                'Me.mtbEmployerPhoneNo.Text = .EmployerPhoneNumber
                'Me.mtbEmployerZipCode.Text = .EmployerZip
                'Me.txtEmployerCity.Text = .EmployerCity
                'Utility.SelectComboItem(Me.cmbEmployerState, .EmploymentStatus, False)

                'Pharmacy
                'lblPharmacyId.Text = .NCPDPID
                'lblPharmacyName.Text = .PharmacyName
                'lblPharmacyProvider.Text = .PharmacyProvider
                'Me.lblCurrentPharmacy.Text = .PharmacyName
                'If (.PictureFilePath <> "") Then
                '    Me.imgPatient.ImageUrl = .PictureFilePath
                '    Me.lblImagePath.Text = .PictureFilePath
                'End If

            End With

            ''Primary Insurance
            If (lResultPrimaryInsurance) Then
                With lPatientInsurancePrimary.PatientInsurance
                    If (.InsurerId = 0) Then
                        Me.txtInsuranceCompanyId.Text = .InsuranceCompanyID
                        Me.lblPayerId.Text = .PayerId
                        LoadInsuranceCombo(.InsuranceCompanyName, Me.cmbInsuranceCompany)
                        Utility.SelectComboItem(Me.cmbInsuranceCompany, .InsuranceCompanyName, False)
                        Me.cmbInsuranceCompany.Enabled = True



                    Else
                        Dim lTempResult As Boolean
                        Dim lTempPatient As New Patient(lUser.ConnectionString)
                        lTempPatient.Patient.PatientID = .InsurerId

                        Dim lTempPatientInsurance As New PatientInsurance(lUser.ConnectionString)
                        lTempPatientInsurance.PatientInsurance.PatientID = .InsurerId
                        lTempPatientInsurance.PatientInsurance.Type = "P"

                        lTempResult = lTempPatientInsurance.GetRecordByID()
                        lTempResult = lTempPatient.GetRecordByID()

                        Me.txtInsurerLastName.Text = lTempPatient.Patient.LastName
                        LoadInsurerCombo(Me.RadComboBox1, Me.txtInsurerLastName.Text)
                        Me.txtInsurerFirstName.Text = lTempPatient.Patient.FirstName
                        Me.txtPrimaryInsurerId.Text = .InsurerId

                        Me.txtInsuranceCompanyId.Text = lTempPatientInsurance.PatientInsurance.InsuranceCompanyID
                        Me.lblPayerId.Text = lTempPatientInsurance.PatientInsurance.PayerId
                        LoadInsuranceCombo(lTempPatientInsurance.PatientInsurance.InsuranceCompanyName, Me.cmbInsuranceCompany)
                        Utility.SelectComboItem(Me.cmbInsuranceCompany, lTempPatientInsurance.PatientInsurance.InsuranceCompanyName, False)
                        Me.cmbInsuranceCompany.Enabled = False
                        Me.btnPrimaryInsurerSearch.Enabled = True
                        Me.RadComboBox1.Enabled = True
                    End If
                    Utility.SelectComboItem(Me.cmbRelationshipPrimaryInsurer, .RelationshipToPrimaryInsurer, False)
                    Me.txtSubscriberId.Text = .SubscriberID
                    Me.txtGroupNo.Text = .GroupNo
                    Me.txtPlanName.Text = .PlanName
                    Me.txtDeductable.Text = .Deductable
                    Me.txtVisitCopayment.Text = .VisitCopayment

                    Utility.SelectComboItem(Me.cmbInsuredAuthorization, .InsuredAuthorization, False)
              
                    Utility.SelectComboItem(Me.cmbSignature, .SignatureOfFile, False)
                    If (.SignatureDate <> "") Then
                        Me.dtSignatureDate.SelectedDate = .SignatureDate
                    End If
                End With
            Else
                ResetPrimaryInsurance(False)
            End If

            ''Secondary Insurance
            If (lResultSecondaryInsurance) Then
                With lPatientInsuranceSecondary.PatientInsurance
                    If (.InsurerId = 0) Then
                        Me.txtSecInsuranceCompanyID.Text = .InsuranceCompanyID
                        Me.lblSecPayerId.Text = .PayerId
                        LoadInsuranceCombo(.InsuranceCompanyName, Me.cmbSecInsuranceCompany)
                        Utility.SelectComboItem(Me.cmbSecInsuranceCompany, .InsuranceCompanyName, False)
                        Me.cmbSecInsuranceCompany.Enabled = True
                    Else
                        Dim lTempResult As Boolean
                        Dim lTempPatient As New Patient(lUser.ConnectionString)
                        lTempPatient.Patient.PatientID = .InsurerId

                        Dim lTempPatientInsurance As New PatientInsurance(lUser.ConnectionString)
                        lTempPatientInsurance.PatientInsurance.PatientID = .InsurerId
                        lTempPatientInsurance.PatientInsurance.Type = "S"

                        lTempResult = lTempPatientInsurance.GetRecordByID()
                        lTempResult = lTempPatient.GetRecordByID()

                        Me.txtSecInsurerLastName.Text = lTempPatient.Patient.LastName
                        LoadInsurerCombo(Me.RadComboBox3, Me.txtSecInsurerLastName.Text)
                        Me.txtSecInsurerFirstName.Text = lTempPatient.Patient.FirstName
                        Me.txtSecondaryInsurerId.Text = .InsurerId

                        Me.txtSecInsuranceCompanyID.Text = lTempPatientInsurance.PatientInsurance.InsuranceCompanyID
                        Me.lblSecPayerId.Text = lTempPatientInsurance.PatientInsurance.PayerId
                        LoadInsuranceCombo(lTempPatientInsurance.PatientInsurance.InsuranceCompanyName, Me.cmbSecInsuranceCompany)
                        Utility.SelectComboItem(Me.cmbSecInsuranceCompany, lTempPatientInsurance.PatientInsurance.InsuranceCompanyName, False)
                        Me.cmbSecInsuranceCompany.Enabled = False
                        Me.ImageButton1.Enabled = True
                        Me.RadComboBox3.Enabled = True
                    End If
                    Utility.SelectComboItem(Me.cmbRelationshipSecondaryInsurer, .RelationshipToPrimaryInsurer, False)
                    Me.txtSecSubscriberId.Text = .SubscriberID
                    Me.txtSecGroupNo.Text = .GroupNo
                    Me.txtSecPlanName.Text = .PlanName
                    Me.txtSecDeductable.Text = .Deductable
                    Me.txtSecVisitCopayment.Text = .VisitCopayment
                    Utility.SelectComboItem(Me.cmbSecInsuredAuthorization, .InsuredAuthorization, False)
                
                End With
            Else
                ResetSecondaryInsurance(False)
            End If
        Catch ex As Exception
            lLogId = ErrorLogMethods.LogError(ex, "PatientPreview.aspx\LoadPatient(ByVal pPatientId As String)")
            Response.Redirect("ErrorPage.aspx?LogId=" & lLogId)
        End Try

        

    End Sub
    Public Sub LoadInsuranceCombo(ByVal lCurrentInsurance As String, ByVal lCombo As Telerik.WebControls.RadComboBox)
        If lCurrentInsurance = "" Then
            Exit Sub
        End If
        Dim lDs As New DataSet
        Dim lUser As User
        Dim lLogId As Int32 = 0
        lUser = CType(Session.Item("User"), User)
        'Dim lobjPharmacyDb As New PharmacyDB
        'lobjPharmacyDb.ZipCode = e.Text
        Try
            lUser = CType(Session.Item("User"), User)
            lCombo.DataSource = Nothing
            'lDs = PharmacyMethods.GetPharmacy(lobjPharmacyDb, lUser, Request.Url.AbsoluteUri)
            lDs = InsuranceMethods.GetInsuranceForCombo(lCurrentInsurance, lUser)
            lCombo.DataSource = lDs
            lCombo.DataBind()
            'cmbInsuranceCompany.SelectedIndex = 0
        Catch ex As Exception
            lLogId = ErrorLogMethods.LogError(ex, "PatientPreview.aspx\LoadInsuranceCombo()")
            Response.Redirect("ErrorPage.aspx?LogId=" & lLogId)
        Finally
            lDs.Dispose()
        End Try

    End Sub

    Protected Sub cmbInsuranceCompany_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbInsuranceCompany.ItemsRequested
        If e.Text = "" Then
            Exit Sub
        End If
        Dim lDs As New DataSet
        Dim lUser As User
        Dim lLogId As Int32 = 0

        'Dim lobjPharmacyDb As New PharmacyDB
        'lobjPharmacyDb.ZipCode = e.Text
        Try
            lUser = CType(Session.Item("User"), User)
            'lDs = PharmacyMethods.GetPharmacy(lobjPharmacyDb, lUser, Request.Url.AbsoluteUri)
            lDs = InsuranceMethods.GetInsuranceForCombo(e.Text, lUser)
            cmbInsuranceCompany.DataSource = lDs
            cmbInsuranceCompany.DataBind()
            'cmbInsuranceCompany.SelectedIndex = 0
        Catch ex As Exception
            lLogId = ErrorLogMethods.LogError(ex, "PatientPreview.aspx\cmbInsuranceCompany_ItemsRequested()")
            Response.Redirect("ErrorPage.aspx?LogId=" & lLogId)
        Finally
            lDs.Dispose()
        End Try

    End Sub

    Protected Sub cmbInsuranceCompany_SelectedIndexChanged(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxSelectedIndexChangedEventArgs) Handles cmbInsuranceCompany.SelectedIndexChanged
        'Me.txtInsuranceCompanyId.Text = Me.cmbInsuranceCompany.SelectedValue.ToString
        'Dim lIndex As Integer
        'LoadInsuranceCombo(cmbInsuranceCompany.Text, Me.cmbSecInsuranceCompany)
        'lIndex = cmbInsuranceCompany.FindItemIndexByText(cmbInsuranceCompany.Text)
        'Utility.SelectComboItem(Me.cmbInsuranceCompany, cmbInsuranceCompany.Text, False)
        'If (Not Me.cmbInsuranceCompany.SelectedItem Is Nothing And cmbInsuranceCompany.Value <> "") Then
        'Me.cmbInsuranceCompany.SelectedItem.Text = cmbInsuranceCompany.Text
        Try
            Me.txtInsuranceCompanyId.Text = cmbInsuranceCompany.Value.ToString.Split("|")(0)
            Me.lblPayerId.Text = cmbInsuranceCompany.Value.ToString.Split("|")(1)
        Catch ex As Exception
            ErrorLogMethods.LogError(ex, "PatientPreview.aspx\cmbInsuranceCompany_ItemsRequested()")
            'Response.Redirect("ErrorPage.aspx?LogId=" & lLogId)
        End Try
        
        'End If
        
    End Sub
    'Protected Sub cmbInsuranceCompany_ItemDataBound(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemDataBoundEventArgs) Handles cmbInsuranceCompany.ItemDataBound
    '    e.Item.Text = CType(e.Item.DataItem, DataRowView)("CompanyName").ToString
    'End Sub

    Protected Sub btnPrimaryInsurerSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnPrimaryInsurerSearch.Click
        'Me.apnlInsurance.ResponseScripts.Add("window.radopen('PatientSearch.aspx','wndInsurer');")
        Me.AjxMPatientPreview.ResponseScripts.Add("window.radopen('PatientSearch.aspx?srch=" & Me.RadComboBox1.Text & "|" & Me.txtInsurerFirstName.Text & "','rwICD9Search');")
    End Sub

    Protected Sub cmbSecInsuranceCompany_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbSecInsuranceCompany.ItemsRequested
        If e.Text = "" Then
            Exit Sub
        End If
        Dim lDs As New DataSet
        Dim lUser As User
        Dim lLogId As Int32 = 0

        'Dim lobjPharmacyDb As New PharmacyDB
        'lobjPharmacyDb.ZipCode = e.Text
        Try
            lUser = CType(Session.Item("User"), User)
            'lDs = PharmacyMethods.GetPharmacy(lobjPharmacyDb, lUser, Request.Url.AbsoluteUri)
            lDs = InsuranceMethods.GetInsuranceForCombo(e.Text, lUser)
            cmbSecInsuranceCompany.DataSource = lDs
            cmbSecInsuranceCompany.DataBind()
            'cmbInsuranceCompany.SelectedIndex = 0
        Catch ex As Exception
            lLogId = ErrorLogMethods.LogError(ex, "PatientPreview.aspx\cmbSecInsuranceCompany_ItemsRequested()")
            Response.Redirect("ErrorPage.aspx?LogId=" & lLogId)
        Finally
            lDs.Dispose()
        End Try
    End Sub

    Protected Sub cmbSecInsuranceCompany_SelectedIndexChanged(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxSelectedIndexChangedEventArgs) Handles cmbSecInsuranceCompany.SelectedIndexChanged
        Dim lLogId As Int32 = 0
        'If (Not Me.cmbSecInsuranceCompany.SelectedItem Is Nothing And cmbSecInsuranceCompany.Value <> "") Then
        'Me.cmbSecInsuranceCompany.SelectedItem.Text = Me.cmbSecInsuranceCompany.Text
        Try
            Me.txtSecInsuranceCompanyID.Text = cmbSecInsuranceCompany.Value.ToString.Split("|")(0)
            Me.lblSecPayerId.Text = cmbSecInsuranceCompany.Value.ToString.Split("|")(1)
        Catch ex As Exception
            lLogId = ErrorLogMethods.LogError(ex, "PatientPreview.aspx\cmbSecInsuranceCompany_SelectedIndexChanged()")
            Response.Redirect("ErrorPage.aspx?LogId=" & lLogId)
        End Try

        'End If

    End Sub

    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        Me.AjxMPatientPreview.ResponseScripts.Add("window.radopen('PatientSearch.aspx?srch=" & Me.RadComboBox3.Text & "|" & Me.txtSecInsurerFirstName.Text & "','rwCPTSearch');")
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim lLogId As Int32 = 0
        Try
            Me.txtInsurerLastName.Text = Me.txtPrimaryInsurerId.Text.Split("|")(1)
            Me.txtInsurerFirstName.Text = Me.txtPrimaryInsurerId.Text.Split("|")(2)
            Me.txtPrimaryInsurerId.Text = Me.txtPrimaryInsurerId.Text.Split("|")(0)
            LoadInsurerCombo(Me.RadComboBox1, Me.txtInsurerLastName.Text)
            GetInsurerInsurance(Me.txtPrimaryInsurerId.Text.Split("|")(0), "P")
        Catch ex As Exception
            lLogId = ErrorLogMethods.LogError(ex, "PatientPreview.aspx\Button1_Click()")
            Response.Redirect("ErrorPage.aspx?LogId=" & lLogId)
        End Try

    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim lLogId As Int32 = 0
        Try
            Me.txtSecInsurerLastName.Text = Me.txtSecondaryInsurerId.Text.Split("|")(1)
            Me.txtSecInsurerFirstName.Text = Me.txtSecondaryInsurerId.Text.Split("|")(2)
            Me.txtSecondaryInsurerId.Text = Me.txtSecondaryInsurerId.Text.Split("|")(0)
            LoadInsurerCombo(Me.RadComboBox1, Me.txtSecInsurerLastName.Text)
            GetInsurerInsurance(Me.txtSecondaryInsurerId.Text.Split("|")(0), "S")
        Catch ex As Exception
            lLogId = ErrorLogMethods.LogError(ex, "PatientPreview.aspx\Button2_Click()")
            Response.Redirect("ErrorPage.aspx?LogId=" & lLogId)
        End Try
        
    End Sub

    Protected Sub cmbRelationshipPrimaryInsurer_SelectedIndexChanged(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxSelectedIndexChangedEventArgs) Handles cmbRelationshipPrimaryInsurer.SelectedIndexChanged
        'ResetPrimaryInsurance()
        If (cmbRelationshipPrimaryInsurer.Text <> "Self") Then
            Me.btnPrimaryInsurerSearch.Enabled = True
            Me.cmbInsuranceCompany.Items.Clear()
            Me.cmbInsuranceCompany.Text = ""
            Me.cmbInsuranceCompany.Value = ""
            Me.cmbInsuranceCompany.Enabled = False
            'If (Not Me.cmbInsuranceCompany.SelectedItem Is Nothing) Then
            '    Me.cmbInsuranceCompany.SelectedItem.Text = ""
            '    Me.cmbInsuranceCompany.SelectedItem.Value = ""
            'End If
            'Me.cmbInsuranceCompany.ClearSelection()
            'Me.cmbInsuranceCompany.Items.Clear()
            'Me.cmbInsuranceCompany.DataBind()
            Me.txtInsuranceCompanyId.Text = 0
            Me.txtPrimaryInsurerId.Text = 0
            Me.lblPayerId.Text = ""
            Me.txtInsurerLastName.Text = ""
            Me.txtInsurerFirstName.Text = ""
            Me.RadComboBox1.Enabled = True
            Me.txtInsurerFirstName.Enabled = True
            Me.RadComboBox1.ClearSelection()
            Me.RadComboBox1.Items.Clear()
            Me.RadComboBox1.Text = ""
            Me.RadComboBox1.Value = ""

            Me.txtSubscriberId.Text = ""
            Me.txtPlanName.Text = ""
            Me.txtVisitCopayment.Text = ""
            Me.txtGroupNo.Text = ""
            Me.txtDeductable.Text = ""

        Else
            'If (Not Me.cmbInsuranceCompany.SelectedItem Is Nothing) Then
            '    Me.cmbInsuranceCompany.SelectedItem.Text = ""
            '    Me.cmbInsuranceCompany.SelectedItem.Value = ""
            'End If
            'Me.cmbInsuranceCompany.DataSource = Nothing
            'Me.cmbInsuranceCompany.DataBind()
            'Me.cmbInsuranceCompany.ClearSelection()
            Me.cmbInsuranceCompany.Items.Clear()
            Me.cmbInsuranceCompany.Text = ""
            Me.cmbInsuranceCompany.Value = ""
            Me.cmbInsuranceCompany.Enabled = True
            Me.btnPrimaryInsurerSearch.Enabled = False
            Me.txtInsuranceCompanyId.Text = 0
            Me.txtPrimaryInsurerId.Text = 0
            Me.txtInsurerLastName.Text = ""
            Me.txtInsurerFirstName.Text = ""
            Me.lblPayerId.Text = ""
            Me.RadComboBox1.Enabled = False
            Me.txtInsurerFirstName.Enabled = False
            Me.RadComboBox1.ClearSelection()
            Me.RadComboBox1.Items.Clear()
            Me.RadComboBox1.Text = ""
            Me.RadComboBox1.Value = ""


            Me.txtSubscriberId.Text = ""
            Me.txtPlanName.Text = ""
            Me.txtVisitCopayment.Text = ""
            Me.txtGroupNo.Text = ""
            Me.txtDeductable.Text = ""

        End If
    End Sub
    Protected Sub cmbRelationshipSecondaryInsurer_SelectedIndexChanged(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxSelectedIndexChangedEventArgs) Handles cmbRelationshipSecondaryInsurer.SelectedIndexChanged
        'ResetSecondaryInsurance()
        If (cmbRelationshipSecondaryInsurer.Text <> "Self") Then
            Me.ImageButton1.Enabled = True
            Me.cmbSecInsuranceCompany.Items.Clear()
            Me.cmbSecInsuranceCompany.Text = ""
            Me.cmbSecInsuranceCompany.Value = ""
            Me.cmbSecInsuranceCompany.Enabled = False
            'If (Not Me.cmbSecInsuranceCompany.SelectedItem Is Nothing) Then
            '    Me.cmbSecInsuranceCompany.SelectedItem.Text = ""
            '    Me.cmbSecInsuranceCompany.SelectedItem.Value = ""
            'End If
            Me.txtSecInsuranceCompanyID.Text = 0
            Me.txtSecInsurerLastName.Text = ""
            Me.txtSecInsurerFirstName.Text = ""
            Me.txtSecondaryInsurerId.Text = 0
            Me.lblSecPayerId.Text = ""
            Me.cmbSecInsuranceCompany.DataSource = Nothing
            Me.RadComboBox3.Enabled = True
            Me.txtSecInsurerFirstName.Enabled = True
            Me.RadComboBox3.ClearSelection()
            Me.RadComboBox3.Items.Clear()
            Me.RadComboBox3.Text = ""
            Me.RadComboBox3.Value = ""

            Me.txtSecSubscriberId.Text = ""
            Me.txtSecPlanName.Text = ""
            Me.txtSecVisitCopayment.Text = ""
            Me.txtSecGroupNo.Text = ""
            Me.txtSecDeductable.Text = ""

        Else
            'If (Not Me.cmbSecInsuranceCompany.SelectedItem Is Nothing) Then
            '    Me.cmbSecInsuranceCompany.SelectedItem.Text = ""
            '    Me.cmbSecInsuranceCompany.SelectedItem.Value = ""
            'End If
            Me.cmbSecInsuranceCompany.Enabled = True
            Me.cmbSecInsuranceCompany.Items.Clear()
            Me.cmbSecInsuranceCompany.Text = ""
            Me.cmbSecInsuranceCompany.Value = ""
            'Me.cmbSecInsuranceCompany.DataSource = Nothing
            'Me.cmbSecInsuranceCompany.ClearSelection()



            Me.txtSecSubscriberId.Text = ""
            Me.txtSecPlanName.Text = ""
            Me.txtSecVisitCopayment.Text = ""
            Me.txtSecGroupNo.Text = ""
            Me.txtSecDeductable.Text = ""

            Me.ImageButton1.Enabled = False
            Me.txtSecInsuranceCompanyID.Text = 0
            Me.txtSecondaryInsurerId.Text = 0
            Me.txtSecInsurerLastName.Text = ""
            Me.txtSecInsurerFirstName.Text = ""
            Me.lblSecPayerId.Text = ""
            Me.RadComboBox3.Enabled = False
            Me.RadComboBox3.ClearSelection()
            Me.RadComboBox3.Items.Clear()
            Me.RadComboBox3.Text = ""
            Me.RadComboBox3.Value = ""
            Me.txtSecInsurerFirstName.Enabled = False
        End If
    End Sub

    Private Function UpdatePatient() As Boolean
        'Dim UpdateXml As String = ""
        Dim lUser As User
        Dim lLogId As Int32 = 0


        Dim lobjPatientDb As New PatientDBExtended()
        Dim lobjPatientInsuranceDbPrimary As New PatientInsuranceDB()
        Dim lobjPatientInsuranceDbSecondary As New PatientInsuranceDB()
        Dim lResult As Boolean

        Try
            Dim lPatientId As String = Me.txtPreviewId.Text.Split("|")(0)
            'If (Not Session("EditPatientID") Is Nothing) Then
            'lPatientId = Session("EditPatientID").ToString()
            'Else
            'Exit Function
            'End If
            If lPatientId = "" Then
                Return False
            End If

            lUser = CType(Session.Item("User"), User)
            With lobjPatientDb

                ''''''' Personal''''''''''
                .PatientID = lPatientId
                .FirstName = Utility.ChangeCase(Utility.AdjustApostrophie(Me.txtFirstName.Text))
                .MiddleName = Utility.ChangeCase(Utility.AdjustApostrophie(Me.txtMiddleName.Text))
                .LastName = Utility.ChangeCase(Utility.AdjustApostrophie(Me.txtLastName.Text))
                '   .Title = Me.cmbTitle.SelectedValue
                '  .MartialStatus = Me.cmbMaritialStatus.Text
                .Gender = Me.cmbGender.SelectedValue
                .DOB = Me.dtDOB.DbSelectedDate
                .AddressLine1 = Utility.ChangeCase(Utility.AdjustApostrophie(Me.txtAddressLine1.Text))
                .AddressLine2 = Utility.ChangeCase(Utility.AdjustApostrophie(Me.txtAddressLine2.Text))
                .City = Utility.ChangeCase(Utility.AdjustApostrophie(Me.txtCity.Text))
                .StateID = Me.cmbState.SelectedValue
                .ZipCode = Me.mtbZipCode.Text
                ' .Email = Me.txtEmail.Text
                '.Occupation = Utility.ChangeCase(Me.txtOccupation.Text)
                '.Fax = Me.mtbFax.Text
                .HomePhone = Utility.AdjustApostrophie(Me.mtbHousePhone.Text)
                '.WorkPhone = Me.mtbWorkPhone.Text
                '.WorkPhoneExtension = Me.txtExtension.Text
                '.SSN = Me.mtbSSN.Text
                .IsDeleted = "N"
                '.PictureFilePath = Me.lblImagePath.Text

                '' End Personal'''

                'Emergency Contact
                '.EmergencyContactName = Utility.ChangeCase(Me.txtEmergencyContactName.Text)
                '.EmergencyContactRelationship = Me.txtEmergencyRelationship.Text
                '.EmergencyContactPhone = Me.mtbEmergencyPhoneNumber.Text
                '.EmergencyContactZip = Me.mtbEmergencyZip.Text
                '.EmergencyContactState = Me.cmbEmergencyState.SelectedValue
                '.EmergencyContactAddress = Me.txtEmergencyAddress.Text
                'End Emergency Contact

                'Responsible Party
                .ResponsibleName = Utility.ChangeCase(Utility.AdjustApostrophie(Me.txtResponsibleName.Text))
                .ResponsibleCity = Utility.ChangeCase(Utility.AdjustApostrophie(Me.txtResponsibleCity.Text))
                .ResponsibleAddress = Utility.ChangeCase(Utility.AdjustApostrophie(Me.txtResponsibleCity.Text))
                .ResponsibleHomePhone = Utility.AdjustApostrophie(Me.mtbResponsibleHomePhone.Text)
                .ResponsibleWorkPhone = Utility.AdjustApostrophie(Me.mtbResponsibleWorkPhone.Text)
                .ResponsibleRelationship = Utility.AdjustApostrophie(Me.cmbResponsibleRelationship.Text)
                .ResponsibleSSN = Utility.AdjustApostrophie(Me.mtbResponsibleSSN.Text)
                .ResponsibleState = Utility.AdjustApostrophie(Me.cmbResponsibleState.SelectedValue)
                .ResponsibleZip = Utility.AdjustApostrophie(Me.mtbResponsibleZip.Text)
                'Responsible Party

                'End Emergency Contact

                'Employment information
                '.EmployerName = Utility.ChangeCase(Me.txtEmployerName.Text)
                '.EmploymentStatus = Me.cmbEmploymentStatus.SelectedItem.Text
                '.EmployerAddressLine1 = Me.txtEmployerAddressline1.Text
                '.EmployerAddressLine2 = Me.txtEmployerAddressline2.Text
                '.EmployerPhoneNumber = Me.mtbEmployerPhoneNo.Text
                '.EmployerCity = Me.txtEmployerCity.Text
                '.EmployerState = Me.cmbEmployerState.SelectedValue
                '.EmployerZip = Me.mtbEmployerZipCode.Text
                'end Employment information

                ''Patient Primary Insurance
                With lobjPatientInsuranceDbPrimary
                    .Type = "P"
                    .RelationshipToPrimaryInsurer = Me.cmbRelationshipPrimaryInsurer.SelectedItem.Text
                    If (Me.cmbRelationshipPrimaryInsurer.SelectedItem.Text = "Self") Then
                        If (Me.txtInsuranceCompanyId.Text <> "") Then
                            .InsuranceCompanyID = Convert.ToInt32(Me.txtInsuranceCompanyId.Text)
                        End If
                        .InsuranceCompanyName = Me.cmbInsuranceCompany.Text
                        'If (Me.txtPrimaryInsurerId.Text <> "") Then
                        '    .InsurerId = Me.txtPrimaryInsurerId.Text
                        'End If
                        .PayerId = Me.lblPayerId.Text
                    Else
                        If (Me.txtPrimaryInsurerId.Text <> "") Then
                            .InsurerId = Me.txtPrimaryInsurerId.Text
                        End If
                    End If
                    'If (Me.txtSubscriberId.Text <> "") Then
                    .SubscriberID = Utility.AdjustApostrophie(Me.txtSubscriberId.Text)
                    'End If
                    .GroupNo = Utility.AdjustApostrophie(Me.txtGroupNo.Text)
                    .PlanName = Utility.AdjustApostrophie(Me.txtPlanName.Text)
                    .InsuredAuthorization = Me.cmbInsuredAuthorization.Text
                    .Deductable = Me.txtDeductable.Text
                    .VisitCopayment = Me.txtVisitCopayment.Text
                    .SignatureOfFile = Me.cmbSignature.SelectedItem.Value
                    .SignatureDate = Me.dtSignatureDate.DbSelectedDate
                End With

                ''Patient Secondary Insurance
                With lobjPatientInsuranceDbSecondary
                    .Type = "S"
                    .RelationshipToPrimaryInsurer = Me.cmbRelationshipSecondaryInsurer.SelectedItem.Text
                    If (Me.cmbRelationshipSecondaryInsurer.SelectedItem.Text = "Self") Then
                        If (Me.txtSecInsuranceCompanyID.Text <> "") Then
                            .InsuranceCompanyID = Convert.ToInt32(Me.txtSecInsuranceCompanyID.Text)
                        End If
                        .InsuranceCompanyName = Me.cmbSecInsuranceCompany.Text
                        .PayerId = Me.lblSecPayerId.Text
                        'If (Me.txtSecondaryInsurerId.Text <> "") Then
                        '    .InsurerId = Convert.ToInt32(Me.txtSecondaryInsurerId.Text)
                        'End If
                    Else
                        If (Me.txtSecondaryInsurerId.Text <> "") Then
                            .InsurerId = Convert.ToInt32(Me.txtSecondaryInsurerId.Text)
                        End If
                    End If
                    'If (Me.txtSecSubscriberId.Text <> "") Then
                    .SubscriberID = Utility.AdjustApostrophie(Me.txtSecSubscriberId.Text)
                    'End If
                    .GroupNo = Utility.AdjustApostrophie(Me.txtSecGroupNo.Text)
                    .PlanName = Utility.AdjustApostrophie(Me.txtSecPlanName.Text)
                    .InsuredAuthorization = Me.cmbSecInsuredAuthorization.Text
                    .Deductable = Me.txtSecDeductable.Text
                    .VisitCopayment = Me.txtSecVisitCopayment.Text
                    .Active = "Y"
                    .SignatureOfFile = ""
                    .SignatureDate = ""
                End With

                ''Patient Pharmacy
                '.NCPDPID = Me.lblPharmacyId.Text
                '.PharmacyName = Me.lblPharmacyName.Text
                '.PharmacyProvider = Me.lblPharmacyProvider.Text
                ''End Patient Pharmacy


            End With

            'UpdateXml = Session("EditCurrentXml").ToString
            'If (Session("EditCurrentXml") Is Nothing) Then
            '    Session("EditCurrentXml") = ""
            'End If

            lResult = PatientMethodsExtended.UpdatePatientPreview(lobjPatientDb, lobjPatientInsuranceDbPrimary, lobjPatientInsuranceDbSecondary, lUser, Request.Url.AbsoluteUri)
            Return lResult
        Catch ex As Exception
            lLogId = ErrorLogMethods.LogError(ex, "PatientPreview.aspx\UpdatePatient()")
            Return False
        End Try

        
    End Function
    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSearch.Click
        Me.AjxMPatientPreview.ResponseScripts.Add("window.radopen('PatientSearch.aspx?srch=" & Me.txtLastName.Text & "|" & Me.txtFirstName.Text & "','rwPreviewSearch');")
    End Sub
    Protected Sub Button3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim lLogId As Int32 = 0
        Try
            If (Me.txtPreviewId.Text.Split("|")(0).ToString <> "") Then
                Me.txtPatientID.Text = Me.txtPreviewId.Text.Split("|")(0).ToString
                LoadPatient(Me.txtPreviewId.Text.Split("|")(0).ToString)
                LoadInsurerCombo(Me.RadComboBox2, Me.txtLastName.Text)
            End If
        Catch ex As Exception
            lLogId = ErrorLogMethods.LogError(ex, "PatientPreview.aspx\Button3_Click()")
            Response.Redirect("ErrorPage.aspx?LogId=" & lLogId)
        End Try

    End Sub
    Public Sub LoadSuperBillCombo()
        Dim lDs As New DataSet
        Dim lUser As User
        Dim lLogId As Int32 = 0

        Dim lObjSuperBill As SuperBill
        Try
            lUser = CType(Session.Item("User"), User)
            lObjSuperBill = New SuperBill(lUser.ConnectionString)
            lDs = lObjSuperBill.GetAllRecords()
            cmbSuperBill.DataSource = lDs
            cmbSuperBill.DataBind()
        Catch ex As Exception
            lLogId = ErrorLogMethods.LogError(ex, "PatientPreview.aspx\LoadSuperBillCombo()")
            Response.Redirect("ErrorPage.aspx?LogId=" & lLogId)
            'Me.cmbSuperBill.DataSource = Nothing
        Finally
            lDs.Dispose()
        End Try

    End Sub

    Protected Sub ibtnLaunchSuperBill_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ibtnLaunchSuperBill.Click
        Dim lUser As User
        lUser = CType(Session.Item("User"), User)

        Dim lScript As String = "var lResult = confirm('Duplicate Patient, Proceed?'); " _
                       & "  if(lResult) " _
                       & "  {  var oButton = document.getElementById('ctl00$ContentPlaceHolder1$Button5'); " _
                       & "  oButton.click(); }  "


        If (PatientMethods.CheckPatientExistenceEdit(Utility.ChangeCase(Me.txtFirstName.Text), Utility.ChangeCase(Me.txtLastName.Text), Me.dtDOB.DbSelectedDate, lUser, Request.Url.AbsoluteUri, Me.txtPatientID.Text) = "1") Then
            Me.AjxMPatientPreview.ResponseScripts.Add(lScript)
        Else
            Dim lResult As Boolean = UpdatePatient()
            Dim lResult2 As Integer
            Dim lLaunchBillUrl As String = ""

            If lResult = True Then
                lResult2 = SavePatientSuperBill()
            End If

            ''THIS CHECKS WHETHER A TEMPLATE HAS BEEN CREATED OR NOT
            If cmbSuperBill.SelectedIndex = -1 Then
                Me.AjxMPatientPreview.Alert("Please create Super Bill Template before proceeding")
                Return
            End If


            Try
                Dim lPatientId As String = Convert.ToString(Me.txtPreviewId.Text.Split("|")(0))
                Dim lquerystring As String = ElixirLibrary.Encryption.EncryptQueryString("sid=" & lResult2.ToString() & "|" & lPatientId & "|" & cmbSuperBill.SelectedValue.ToString() & "|0" & "|U")

                'lLaunchBillUrl = "EditPatientSuperBill.aspx?sid=" & lResult2.ToString() & "|" & lPatientId & "|" & cmbSuperBill.SelectedValue.ToString() & "|0" & "|U"
                lLaunchBillUrl = "EditPatientSuperBill.aspx" + lquerystring

            Catch ex As Exception
                ErrorLogMethods.LogError(ex, "PatientPreview.aspx\ibtnLaunchSuperBill_Click()")
                lResult = False
            End Try

            If lResult And lResult2 <> 0 Then
                'Me.AjxMPatientPreview.Alert("Patient Updated Sucessfully")
                Me.AjxMPatientPreview.Redirect(lLaunchBillUrl)
                'LoadPatient(Me.txtPreviewId.Text.Split("|")(0))
                'Response.Redirect("PatientPreview.aspx")
            Else
                Me.AjxMPatientPreview.Alert("Failed to Update Patient/Launch SuperBill")
            End If
        End If
        'Response.Redirect(lLaunchBillUrl)
    End Sub

    Public Sub GetInsurerInsurance(ByVal pPatientId As String, ByVal pType As String)
        Dim lTempResult As Boolean
        Dim lUser As User = CType(Session.Item("User"), User)
        Dim lTempPatientInsurance As PatientInsurance
        Dim lLogId As Int32 = 0


        Try
            lUser = CType(Session.Item("User"), User)
            lTempPatientInsurance = New PatientInsurance(lUser.ConnectionString)
            lTempPatientInsurance.PatientInsurance.PatientID = pPatientId
            lTempPatientInsurance.PatientInsurance.Type = pType

            lTempResult = lTempPatientInsurance.CheckSelfInsurance()

            If (lTempResult) Then
                If (pType = "P") Then
                    Me.txtInsuranceCompanyId.Text = lTempPatientInsurance.PatientInsurance.InsuranceCompanyID
                    Me.lblPayerId.Text = lTempPatientInsurance.PatientInsurance.PayerId

                    Me.txtSubscriberId.Text = lTempPatientInsurance.PatientInsurance.SubscriberID
                    Me.txtPlanName.Text = lTempPatientInsurance.PatientInsurance.PlanName
                    Me.txtVisitCopayment.Text = lTempPatientInsurance.PatientInsurance.VisitCopayment
                    Me.txtGroupNo.Text = lTempPatientInsurance.PatientInsurance.GroupNo
                    Me.txtDeductable.Text = lTempPatientInsurance.PatientInsurance.Deductable


                    LoadInsuranceCombo(lTempPatientInsurance.PatientInsurance.InsuranceCompanyName, Me.cmbInsuranceCompany)
                    Utility.SelectComboItem(Me.cmbInsuranceCompany, lTempPatientInsurance.PatientInsurance.InsuranceCompanyName, False)
                    Me.cmbInsuranceCompany.Enabled = False
                ElseIf (pType = "S") Then
                    Me.txtSecInsuranceCompanyID.Text = lTempPatientInsurance.PatientInsurance.InsuranceCompanyID
                    Me.lblSecPayerId.Text = lTempPatientInsurance.PatientInsurance.PayerId


                    Me.txtSecSubscriberId.Text = lTempPatientInsurance.PatientInsurance.SubscriberID
                    Me.txtSecPlanName.Text = lTempPatientInsurance.PatientInsurance.PlanName
                    Me.txtSecVisitCopayment.Text = lTempPatientInsurance.PatientInsurance.VisitCopayment
                    Me.txtSecGroupNo.Text = lTempPatientInsurance.PatientInsurance.GroupNo
                    Me.txtSecDeductable.Text = lTempPatientInsurance.PatientInsurance.Deductable





                    LoadInsuranceCombo(lTempPatientInsurance.PatientInsurance.InsuranceCompanyName, Me.cmbSecInsuranceCompany)
                    Utility.SelectComboItem(Me.cmbSecInsuranceCompany, lTempPatientInsurance.PatientInsurance.InsuranceCompanyName, False)
                    Me.cmbSecInsuranceCompany.Enabled = False
                End If
                Me.lblSecInsurerStatus.Text = ""
                Me.lblReturnedPrimaryInsurerInfo.Text = ""
            Else
                If (pType = "P") Then
                    ResetPrimaryInsurance(True)
                ElseIf (pType = "S") Then
                    ResetSecondaryInsurance(True)
                End If
            End If
        Catch ex As Exception
            lLogId = ErrorLogMethods.LogError(ex, "PatientPreview.aspx\GetInsurerInsurance()")
            Response.Redirect("ErrorPage.aspx?LogId=" & lLogId)
        End Try

    End Sub

    Protected Sub btnPersonalSave_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnPersonalSave.Click
        Dim lResult As Boolean = UpdatePatient()

        If lResult Then
            Me.AjxMPatientPreview.Alert("Patient Updated Sucessfully")
            'Me.AjxMPatientPreview.Redirect("PatientPreview.aspx")
            'LoadPatient(Me.txtPreviewId.Text.Split("|")(0))
            'Response.Redirect("PatientPreview.aspx")
        Else
            Me.AjxMPatientPreview.Alert("Failed to Update Patient")
        End If
    End Sub

    Public Sub ResetPrimaryInsurance(ByVal flag As Boolean)

        Me.cmbInsuranceCompany.Enabled = True
        Me.cmbInsuranceCompany.Items.Clear()
        Me.cmbInsuranceCompany.Text = ""
        Me.cmbInsuranceCompany.Value = ""
        Me.txtInsuranceCompanyId.Text = 0
        Me.lblPayerId.Text = ""
        'If (Not Me.cmbInsuranceCompany.SelectedItem Is Nothing) Then
        '    Me.cmbInsuranceCompany.SelectedItem.Text = ""
        '    Me.cmbInsuranceCompany.Value = ""
        '    Me.cmbInsuranceCompany.SelectedItem.Value = ""
        'End If
        'Me.cmbInsuranceCompany.ClearSelection()
        'Me.cmbInsuranceCompany.Text = ""
        Me.cmbInsuranceCompany.Enabled = True
        Me.btnPrimaryInsurerSearch.Enabled = False

        Me.txtInsurerLastName.Text = ""
        Me.txtInsurerFirstName.Text = ""
        Me.txtPrimaryInsurerId.Text = 0
        Me.btnPrimaryInsurerSearch.Enabled = False

        Me.txtSubscriberId.Text = ""
        Me.txtPlanName.Text = ""
        Me.txtVisitCopayment.Text = ""
        Me.txtGroupNo.Text = ""

        'Me.cmbRelationshipPrimaryInsurer.ClearSelection()
        Utility.SelectComboItem(Me.cmbRelationshipPrimaryInsurer, "Self", False)
        Me.txtSubscriberId.Text = ""
        Me.txtGroupNo.Text = ""
        Me.txtPlanName.Text = ""
        Utility.SelectComboItem(Me.cmbInsuredAuthorization, "Yes", False)
        Me.txtDeductable.Text = ""
        Me.txtVisitCopayment.Text = ""
        Me.cmbSignature.ClearSelection()
        Me.RadComboBox1.ClearSelection()
        Me.RadComboBox1.Items.Clear()
        Me.RadComboBox1.Text = ""
        Me.RadComboBox1.Value = ""
        Me.RadComboBox1.Enabled = False
        Me.txtInsurerFirstName.Enabled = False
        Me.dtSignatureDate.SelectedDate = Nothing
        If (flag) Then
            Me.lblReturnedPrimaryInsurerInfo.Text = "No Primary/Self Insurance"
        Else
            Me.lblReturnedPrimaryInsurerInfo.Text = ""
        End If
    End Sub
    Public Sub ResetSecondaryInsurance(ByVal flag As Boolean)
        ''Me.cmbSecInsuranceCompany.DataSource = Nothing
        Me.cmbSecInsuranceCompany.Enabled = True
        Me.cmbSecInsuranceCompany.Items.Clear()
        Me.cmbSecInsuranceCompany.Text = ""
        Me.cmbSecInsuranceCompany.Value = ""
        Me.txtSecInsuranceCompanyID.Text = 0
        Me.lblSecPayerId.Text = ""
        'If (Not Me.cmbSecInsuranceCompany.SelectedItem Is Nothing) Then
        '    Me.cmbSecInsuranceCompany.SelectedItem.Text = ""
        '    Me.cmbSecInsuranceCompany.Value = ""
        '    Me.cmbSecInsuranceCompany.SelectedItem.Value = ""
        'End If
        'Me.cmbSecInsuranceCompany.ClearSelection()
        Me.ImageButton1.Enabled = False

        Me.txtSecInsurerLastName.Text = ""
        Me.txtSecInsurerFirstName.Text = ""
        Me.txtSecondaryInsurerId.Text = 0
        Me.ImageButton1.Enabled = False
        Me.txtSecDeductable.Text = ""

        Me.txtSecSubscriberId.Text = ""
        Me.txtSecPlanName.Text = ""
        Me.txtSecVisitCopayment.Text = ""
        Me.txtSecGroupNo.Text = ""



        'Me.cmbRelationshipSecondaryInsurer.ClearSelection()
        Utility.SelectComboItem(Me.cmbRelationshipSecondaryInsurer, "Self", False)
        Me.txtSecSubscriberId.Text = ""
        Me.txtSecGroupNo.Text = ""
        Me.txtSecPlanName.Text = ""
        Utility.SelectComboItem(Me.cmbSecInsuredAuthorization, "Yes", False)
        Me.txtSecDeductable.Text = ""
        Me.txtSecVisitCopayment.Text = ""
        Me.RadComboBox3.ClearSelection()
        Me.RadComboBox3.Items.Clear()
        Me.RadComboBox3.Text = ""
        Me.RadComboBox3.Value = ""
        Me.RadComboBox3.Enabled = False
        Me.txtSecInsurerFirstName.Enabled = False
        If (flag) Then
            Me.lblSecInsurerStatus.Text = "No Secondary/Self Insurance"
        Else
            Me.lblSecInsurerStatus.Text = ""
        End If

    End Sub

    Protected Sub btnPersonalCancel_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnPersonalCancel.Click
        Response.Redirect("../PatientSetup.aspx")
    End Sub

    'Protected Sub btnPrint_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnPrint.Click
    '    Dim lResult As Boolean = UpdatePatient()
    '    Dim lResult2 As Integer = SavePatientSuperBill()
    '    If txtCopayAmount.Text <> "" Then
    '        saveCopayInPaymentHdr()
    '    End If

    '    If lResult = True And lResult2 <> 0 Then
    '        Me.AjxMPatientPreview.ResponseScripts.Add("window.open('PSBPrint.aspx?sid=" & lResult2.ToString() & "');")
    '    Else
    '        Me.AjxMPatientPreview.Alert("Failed to Update Patient")
    '    End If

    '    '    Me.AjxMPatientPreview.Alert("Patient Updated Sucessfully")
    '    '    'Me.AjxMPatientPreview.Redirect("PatientPreview.aspx")
    '    '    'LoadPatient(Me.txtPreviewId.Text.Split("|")(0))
    '    '    'Response.Redirect("PatientPreview.aspx")
    '    '
    '    'End If

    '    ' If Not lResult2 = 0 Then
    '    '    If CType(sender, ImageButton).ID = "btnSavenPrint" Then
    '    '        Response.Redirect("PSBPrint.aspx?sid=" & lResult.ToString)
    '    '    Else
    '    '        Response.Redirect("Main.aspx")
    '    '    End If
    '    'Else
    '    '    lblMessage.Text = "Error Generating Superbill, try agin later"
    '    'End If
    ' End Sub

    Private Function SavePatientSuperBill() As Integer
        'System.Threading.Thread.Sleep(10000)
        Dim lUser As User
        Dim lPaymentHdr As New PaymentHdrDB()
        Dim lPatientSuperBillDB As New PatientSuperBillDB()
        Dim lResult As Integer
        Dim lLogId As Int32 = 0

        Try
            lUser = CType(Session.Item("User"), User)
            Dim lPatientId As String = Me.txtPatientID.Text
            With lPatientSuperBillDB
                .DateOfService = Date.Today.Date
                .VisitDisplayDATE = Date.Now.Date
                .SuperBillTemplateID = cmbSuperBill.SelectedValue.ToString()
                .PatientId = lPatientId
                .PatientName = Utility.AdjustApostrophie(txtLastName.Text) & "," & Utility.AdjustApostrophie(txtFirstName.Text)
                .DOB = dtDOB.DbSelectedDate
                .Address = Utility.AdjustApostrophie(txtAddressLine1.Text) & " " & Utility.AdjustApostrophie(txtAddressLine2.Text)
                .City = Utility.AdjustApostrophie(txtCity.Text)
                .State = cmbState.SelectedItem.Text
                .ZipCode = mtbZipCode.Text
                If (Me.cmbRelationshipPrimaryInsurer.Text.ToUpper = "SELF" And Me.txtInsuranceCompanyId.Text <> "") Then
                    .PrimaryInsuranceCompanyId = txtInsuranceCompanyId.Text
                    .PrimaryInsuranceCompanyName = Me.cmbInsuranceCompany.Text
                    .GuarantorName = "Self"
                    .GuarantorID = "0"
                ElseIf (Me.cmbRelationshipPrimaryInsurer.Text.ToUpper <> "SELF" And Me.txtPrimaryInsurerId.Text <> "0") Then
                    .PrimaryInsuranceCompanyName = Me.cmbInsuranceCompany.Text
                    .GuarantorName = Utility.ChangeCase(Me.RadComboBox1.Text) & "," & Utility.ChangeCase(Utility.AdjustApostrophie(Me.txtInsurerFirstName.Text))
                    .GuarantorID = Me.txtPrimaryInsurerId.Text
                End If
                If (Me.txtSecInsuranceCompanyID.Text <> "") Then
                    .SecondryInsuranceCompanyId = Convert.ToInt32(Me.txtSecInsuranceCompanyID.Text)
                    .SecondryInsuranceCompanyName = Me.cmbSecInsuranceCompany.Text
                ElseIf (Me.txtSecondaryInsurerId.Text <> "0") Then
                    .SecondryInsuranceCompanyName = Me.cmbSecInsuranceCompany.Text
                End If
                .Balance = "0"

                If Me.txtCopayAmount.Text.Equals("") Then
                    .CopayAmount = "0"
                    .PaymentMethod = ""
                Else
                    .CopayAmount = Me.txtCopayAmount.Text
                    .PaymentMethod = Me.cmbPaymentMethod.Text
                End If


                .ChequeNumber = Utility.AdjustApostrophie(Me.txtChequeNumber.Text)
                If (Me.dtChequeDate.DbSelectedDate IsNot Nothing) Then
                    .ChequeDate = Me.dtChequeDate.SelectedDate
                End If
                .PrescriberID = lUser.UserId
                ''line add by talha for approve check box.........
                'If (checkapprove.Checked = True) Then
                '    .Status = "Approved"
                'Else
                '    .Status = "UnApproved"
                'End If
                .Status = "UnApproved"
                .IsDeleted = "N"
            End With
            If (txtCopayAmount.Text <> "") Then
                With lPaymentHdr
                    .PaymentDate = Date.Today
                    .PaymentDispDate = Date.Today
                    .PayerType = "P"
                    .PaymentMode = Utility.AdjustApostrophie(cmbPaymentMethod.SelectedItem.Text)
                    .CheckNumber = Utility.AdjustApostrophie(txtChequeNumber.Text)
                    .CheckDate = dtChequeDate.DbSelectedDate
                    .Amount = Utility.AdjustApostrophie(txtCopayAmount.Text)
                    .Description = "Copay"
                    .UserID = lUser.UserId
                    .PayerName = Utility.AdjustApostrophie(txtLastName.Text) & "," & Utility.AdjustApostrophie(txtFirstName.Text)
                End With
            End If
            lResult = GenerateSuperBillMethods.AddPatientSuperBill(lPatientSuperBillDB, lPaymentHdr, Request.Url.AbsoluteUri, lUser.UserId)
            Return lResult
        Catch ex As Exception
            lLogId = ErrorLogMethods.LogError(ex, "PatientPreview.aspx\GetInsurerInsurance()")
            Return 0
        End Try
        

    End Function
    'Private Sub saveCopayInPaymentHdr()
    '    Dim lUser As User
    '    Dim lPaymentId As String = ""
    '    Dim lPaymentHdr As New PaymentHdrDB()
    '    ' Dim lPatientLedgerInsert As Boolean
    '    lUser = CType(Session.Item("User"), User)

    '    'If Session("SelectedClaims") Is Nothing Then
    '    '    Return
    '    'End If
    '    ' fgSelectedClaims = Session("SelectedClaims")
    '    With lPaymentHdr
    '        .PaymentDate = Date.Today
    '        .PaymentDispDate = Date.Today
    '        .PayerType = "P"
    '        .PaymentMode = cmbPaymentMethod.SelectedItem.Text
    '        .ChequeNumber = txtChequeNumber.Text
    '        .ChequeDate = dtChequeDate.SelectedDate
    '        .Amount = txtCopayAmount.Text
    '        .NumberOfPatients = "1"
    '        .Description = "Copay"
    '        .UserID = lUser.UserId
    '        .IsDeleted = "N"
    '        .PayerName = txtLastName.Text & "," & txtFirstName.Text
    '    End With
    '    lPaymentId = PaymentMethods.AddPayment(lPaymentHdr, Request.Url.AbsoluteUri)
    '    lPaymentHdr.PaymentID = lPaymentId
    '    'lPatientLedgerInsert = PatientLedgerMethods.SavePatientLedgerForPayment(lPaymentHdr, fgSelectedClaims)
    '    If lPaymentId = "" Then
    '        Response.Write("<script>alert('Error Adding Payment');</script>")
    '    Else
    '        lPaymentId = CDate(lPaymentHdr.PaymentDate).Year.ToString() & "-" & CDate(lPaymentHdr.PaymentDate).Month.ToString() & "-" & lPaymentId.PadLeft(5, "0")
    '        Response.Write("<script>alert('Payment Added Successfully With ID: " & lPaymentId & "');window.location='Main.aspx';</script>")
    '    End If
    'End Sub

    Protected Sub btnPrnt_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnPrnt.Click
        'System.Threading.Thread.Sleep(10000)
        Dim lUser As User
        lUser = CType(Session.Item("User"), User)

        Dim lScript As String = "var lResult = confirm('Duplicate Patient, Proceed?'); " _
                       & "  if(lResult) " _
                       & "  {  var oButton = document.getElementById('ctl00$ContentPlaceHolder1$Button4'); " _
                       & "  oButton.click(); }  "

        If (PatientMethods.CheckPatientExistenceEdit(Utility.ChangeCase(Me.txtFirstName.Text), Utility.ChangeCase(Me.txtLastName.Text), Me.dtDOB.DbSelectedDate, lUser, Request.Url.AbsoluteUri, Me.txtPatientID.Text) = "1") Then
            Me.AjxMPatientPreview.ResponseScripts.Add(lScript)
        Else
            Dim lResult As Boolean = UpdatePatient()
            Dim lResult2 As Integer
            If lResult = True Then
                lResult2 = SavePatientSuperBill()
            End If
            If lResult = True And lResult2 <> 0 Then
                If (CType(sender, ImageButton).ID = "btnPrnt") Then
                    'Me.AjxMPatientPreview.Alert("Record Updated Successfully")
                    Dim lquerystring As String = ElixirLibrary.Encryption.EncryptQueryString("sid=" & lResult2.ToString())

                    Me.AjxMPatientPreview.ResponseScripts.Add("window.open('PSBPrint.aspx" & lquerystring & "');window.location=""VisitSearch.aspx"";")
                End If
            Else
                Me.AjxMPatientPreview.Alert("Failed to Update Patient")

            End If
        End If
        ' Me.AjxMPatientPreview.ResponseScripts.Add("window.open('Main.aspx');")
        'Me.AjxMPatientPreview.ResponseScripts.Add("window.open('PSBPrint.aspx?sid=" & lResult2.ToString() & "');")
    End Sub

    Protected Sub RadComboBox1_SelectedIndexChanged(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxSelectedIndexChangedEventArgs) Handles RadComboBox1.SelectedIndexChanged
        Try
            Me.txtPrimaryInsurerId.Text = RadComboBox1.Value.Split("|")(0)
            Me.txtInsurerFirstName.Text = RadComboBox1.Value.Split("|")(1)
            GetInsurerInsurance(RadComboBox1.Value.Split("|")(0), "P")
            If (RadComboBox1.Text <> "") Then
                LoadInsurerCombo(RadComboBox1, RadComboBox1.Text)
            End If
        Catch ex As Exception
            ErrorLogMethods.LogError(ex, "PatientPreview.aspx\RadComboBox1_SelectedIndexChanged()")
        End Try
    End Sub

    Protected Sub RadComboBox3_SelectedIndexChanged(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxSelectedIndexChangedEventArgs) Handles RadComboBox3.SelectedIndexChanged
        Try
            Me.txtSecondaryInsurerId.Text = RadComboBox3.Value.Split("|")(0)
            Me.txtSecInsurerFirstName.Text = RadComboBox3.Value.Split("|")(1)
            GetInsurerInsurance(RadComboBox3.Value.Split("|")(0), "S")
            If (RadComboBox3.Text <> "") Then
                LoadInsurerCombo(RadComboBox3, RadComboBox3.Text)
            End If
        Catch ex As Exception
            ErrorLogMethods.LogError(ex, "PatientPreview.aspx\RadComboBox3_SelectedIndexChanged()")
        End Try
    End Sub
    Public Sub LoadInsurerCombo(ByVal pCmb As Telerik.WebControls.RadComboBox, ByVal pText As String)
        Dim lDs As DataSet
        Dim lUser As User = CType(Session.Item("User"), User)
        lDs = PatientMethods.LoadPatientsLastName(pText, lUser)
        pCmb.DataSource = lDs
        pCmb.DataBind()
        pCmb.FindItemByText(pText).Selected = True
    End Sub
    Protected Sub RadComboBox2_SelectedIndexChanged(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxSelectedIndexChangedEventArgs) Handles RadComboBox2.SelectedIndexChanged
        Dim lLogId As Int32 = 0
        Try
            Me.txtPatientID.Text = RadComboBox2.Value
            LoadPatient(RadComboBox2.Value)
            LoadInsurerCombo(RadComboBox2, RadComboBox2.Text)
            Me.txtPreviewId.Text = Me.txtPatientID.Text & "|" & txtLastName.Text & "|" & txtFirstName.Text
        Catch ex As Exception
            lLogId = ErrorLogMethods.LogError(ex, "PatientPreview.aspx\RadComboBox2_SelectedIndexChanged()")
            Response.Redirect("ErrorPage.aspx?LogId=" & lLogId)
        End Try

    End Sub

    Protected Sub Button4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button4.Click
        Dim lResult As Boolean = UpdatePatient()
        Dim lResult2 As Integer
        If lResult = True Then
            lResult2 = SavePatientSuperBill()
        End If
        If lResult = True And lResult2 <> 0 Then
            If (CType(sender, ImageButton).ID = "btnPrnt") Then
                'Me.AjxMPatientPreview.Alert("Record Updated Successfully")
                Me.AjxMPatientPreview.ResponseScripts.Add("window.open('PSBPrint.aspx?sid=" & lResult2.ToString() & "');window.location=""PatientPreview.aspx"";")
            End If
        Else
            Me.AjxMPatientPreview.Alert("Failed to Update Patient")

        End If
    End Sub

    Protected Sub Button5_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button5.Click
        Dim lResult As Boolean = UpdatePatient()
        Dim lResult2 As Integer
        Dim lLaunchBillUrl As String = ""

        If lResult = True Then
            lResult2 = SavePatientSuperBill()
        End If

        ''THIS CHECKS WHETHER A TEMPLATE HAS BEEN CREATED OR NOT
        If cmbSuperBill.SelectedIndex = -1 Then
            Me.AjxMPatientPreview.Alert("Please create Super Bill Template before proceeding")
            Return
        End If


        Try
            Dim lPatientId As String = Convert.ToString(Me.txtPreviewId.Text.Split("|")(0))
            lLaunchBillUrl = "EditPatientSuperBill.aspx?sid=" & lResult2.ToString() & "|" & lPatientId & "|" & cmbSuperBill.SelectedValue.ToString() & "|0" & "|U"
        Catch ex As Exception
            ErrorLogMethods.LogError(ex, "PatientPreview.aspx\ibtnLaunchSuperBill_Click()")
            lResult = False
        End Try

        If lResult And lResult2 <> 0 Then
            'Me.AjxMPatientPreview.Alert("Patient Updated Sucessfully")
            Me.AjxMPatientPreview.Redirect(lLaunchBillUrl)
            'LoadPatient(Me.txtPreviewId.Text.Split("|")(0))
            'Response.Redirect("PatientPreview.aspx")
        Else
            Me.AjxMPatientPreview.Alert("Failed to Update Patient/Launch SuperBill")
        End If
        'Response.Redirect(lLaunchBillUrl)
    End Sub

   
End Class
