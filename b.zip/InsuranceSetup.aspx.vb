Imports Telerik.WebControls
Partial Class Billing_InsuranceSetup
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim lUser As User
        tsEmployee.SelectedIndex = 0
        mpEmployee.SelectedIndex = 0

        lUser = CType(Session.Item("User"), User)

        If (Not Page.IsPostBack) Then
            'InsuranceMethods.GetCompanyName(cmbCompanyName)
            'cmbCompanyName.Items.Insert(0, New RadComboBoxItem("All"))

            'StateMethods.Load_States(cmbState, lUser)
            'cmbState.Items.Insert(0, New RadComboBoxItem("All"))
        End If

    End Sub

    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSearch.Click

        Try
            
            grdEmployee.Rebind()

        Catch ex As Exception
            'lErrorLog.HandleError(ex, pobjUser, pPageUrl)
        End Try

    End Sub

    Protected Sub grdEmployee_DeleteCommand(ByVal source As Object, ByVal e As Telerik.WebControls.GridCommandEventArgs) Handles grdEmployee.DeleteCommand
        Dim lInsurance As New InsuranceDB
        Dim lResult As Boolean

        With lInsurance
            .FavouriteInsuranceID = CType(e.Item.Cells(2).Text, Integer)
        End With

        lResult = InsuranceMethods.DeleteInsurance(lInsurance)       
    End Sub

    Protected Sub ImgAddEmployee_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImgAddEmployee.Click
        Response.Redirect("AddInsuranceCompany.aspx")
    End Sub

    Protected Sub cmbLastName_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbCompanyName.ItemsRequested
        Dim lCond As String
        lCond = "And CompanyName Like '" & Utility.AdjustApostrophie(e.Text) & "%' "

        If (e.Text = "") Then
            Exit Sub
        End If

        InsuranceMethods.GetCompanyName(cmbCompanyName, lCond)
    End Sub

    Protected Sub cmbState_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbState.ItemsRequested
        Dim lUser As User
        lUser = CType(Session.Item("User"), User)
        Dim lCond As String
        lCond = "And Abbr Like '" & Utility.AdjustApostrophie(e.Text) & "%' "

        If (e.Text = "") Then
            Exit Sub
        End If

        StateMethods.Load_States(cmbState, lUser, lCond)
        'cmbState.Items.Insert(0, New RadComboBoxItem("All"))
    End Sub

    Protected Sub grdEmployee_ItemDataBound(ByVal sender As Object, ByVal e As Telerik.WebControls.GridItemEventArgs) Handles grdEmployee.ItemDataBound
        If (e.Item.ItemType = GridItemType.Item Or e.Item.ItemType = GridItemType.AlternatingItem) Then


            Try

                If (e.Item.Cells(7).Text <> "" And (e.Item.Cells(7).Text.Length = 9)) Then


                    e.Item.Cells(7).Text = String.Format("{0:#####-####}", Double.Parse(e.Item.Cells(7).Text))
                End If


            Catch ex As Exception
            End Try

            Dim lDataItem As GridDataItem = CType(e.Item, GridDataItem)
            Dim lHyplnk As HyperLink = CType(lDataItem("Column1").Controls(0), HyperLink)
            Dim lID As String = lDataItem("Column6").Text

            lHyplnk.NavigateUrl = "EditInsuranceCompany.aspx" + ElixirLibrary.Encryption.EncryptQueryString("eid=" & lID)

        End If
    End Sub

    Protected Sub grdEmployee_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdEmployee.NeedDataSource
        Dim whereClause As String = ""

        Dim lds As New DataSet

        Dim lCompanyName As String = cmbCompanyName.Text
        Dim lState As String = cmbState.Text
        Dim lCity As String = txtCity.Text
        Dim lZip As String = mtbZipCode.Text

        If lCompanyName = "" Then
            whereClause = whereClause
        Else
            whereClause = whereClause & " And CompanyName = '" & cmbCompanyName.Text & "'"
        End If


        If lState = "" Then
            whereClause = whereClause
        Else
            whereClause = whereClause & " And State = '" & cmbState.Text & "'"
        End If


        If lCity <> "" Then
            whereClause = whereClause & " And City = '" & Utility.AdjustApostrophie(txtCity.Text) & "' "
        End If

        If lZip <> "" Then
            whereClause = whereClause & " And ZipCode = '" & mtbZipCode.Text & "' "
        End If

        whereClause = whereClause & " And IsDelete='N'"

        lds = InsuranceMethods.GetInsuranceRecords(whereClause)

        pnlGrid.Visible = True
        grdEmployee.DataSource = lds

    End Sub
End Class
