
Partial Class Billing_BillingProviderSetup
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not (Page.IsPostBack) Then
            cbBillingProviderType.Focus()
            LoadProviderCombo()
        End If
    End Sub

    Public Sub LoadProviderCombo()
        Dim lDS As New DataSet
        Dim lUser As User
        Try
            lUser = CType(Session.Item("User"), User)
            lDS = BillingProviderMethods.LoadAllProviders(lUser, "select EmployeeID=0,Names='ALL' union all ")
            cbProvider.DataSource = lDS.Tables(0)
            cbProvider.DataBind()
        Catch ex As Exception

        End Try
    End Sub

    Public Function GenerateCondition() As String
        Dim lCondition As String = ""

        If (cbBillingProviderType.SelectedItem.Text = "ALL") Then
            If (cbProvider.SelectedItem.Text <> "ALL") Then
                lCondition = lCondition & " and ProviderID='" & cbProvider.SelectedValue & "'"
            End If
            If (cbInsuranceType.SelectedItem.Text <> "ALL") Then
                lCondition = lCondition & " and EntryInsuranceTypeCode='" & cbInsuranceType.SelectedValue & "'"
            End If
        ElseIf (cbBillingProviderType.SelectedValue = "G") Then
            lCondition = lCondition & " and EntryType='" & cbBillingProviderType.SelectedValue & "'"
        ElseIf (cbBillingProviderType.SelectedValue = "S") Then
            lCondition = lCondition & " and EntryType='" & cbBillingProviderType.SelectedValue & "'"
            If (cbProvider.SelectedItem.Text <> "ALL") Then
                lCondition = lCondition & " and ProviderID='" & cbProvider.SelectedValue & "'"
            End If
            If (cbInsuranceType.SelectedItem.Text <> "ALL") Then
                lCondition = lCondition & " and EntryInsuranceTypeCode='" & cbInsuranceType.SelectedValue & "'"
            End If
        End If

        Return lCondition

    End Function

    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSearch.Click
       
        grdBillingProvider.Rebind()

    End Sub

    Protected Sub grdBillingProvider_DeleteCommand(ByVal source As Object, ByVal e As Telerik.WebControls.GridCommandEventArgs) Handles grdBillingProvider.DeleteCommand
        Dim lUser As User
        Try
            lUser = CType(Session.Item("User"), User)
            If (BillingProviderMethods.DeleteBillingProvider(lUser, e.Item.Cells(16).Text, e.Item.Cells(19).Text)) Then
                Response.Write("<script>alert('Billing Provider Deleted Successfully');</script>")
                grdBillingProvider.Rebind()
            End If
        Catch ex As Exception

        End Try

    End Sub

    Protected Sub grdBillingProvider_ItemDataBound(ByVal sender As Object, ByVal e As Telerik.WebControls.GridItemEventArgs) Handles grdBillingProvider.ItemDataBound
        If (e.Item.ItemType = Telerik.WebControls.GridItemType.Item Or e.Item.ItemType = Telerik.WebControls.GridItemType.AlternatingItem) Then


            Try

                If (e.Item.Cells(8).Text <> "" And (e.Item.Cells(8).Text.Length = 9)) Then


                    e.Item.Cells(8).Text = e.Item.Cells(8).Text.Substring(0, 5) & "-" & e.Item.Cells(8).Text.Substring(5, 4)
                End If


            Catch ex As Exception
            End Try


            Dim lImageButton As ImageButton
            lImageButton = CType(e.Item.Cells(21).FindControl("DeleteImg"), ImageButton)
            If (e.Item.Cells(18).Text = "General") Then
                lImageButton.Enabled = False
            Else
                lImageButton.Enabled = True
            End If

            Dim lDataItem As Telerik.WebControls.GridDataItem = CType(e.Item, Telerik.WebControls.GridDataItem)
            Dim lHyplnk As HyperLink = CType(lDataItem("Name").Controls(0), HyperLink)
            Dim lBillingProviderId As String = lDataItem("BillingProviderId").Text
            lHyplnk.NavigateUrl = "EditBillingProvider.aspx" & Encryption.EncryptQueryString("ID=" & lBillingProviderId)

        End If
    End Sub

    Protected Sub grdBillingProvider_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdBillingProvider.NeedDataSource
        Dim lcondition As String
        Dim lDs As New DataSet
        Dim lUser As User
        Try
            lUser = CType(Session.Item("User"), User)
            lcondition = GenerateCondition()
            lDs = BillingProviderMethods.SearchBillingProvider(lUser, lcondition)
            grdBillingProvider.DataSource = lDs.Tables(0)
            grdBillingProvider.DataBind()
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub ImgAddBillingProvider_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImgAddBillingProvider.Click
        Response.Redirect("AddBillingProvider.aspx")
    End Sub
End Class
