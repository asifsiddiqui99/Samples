Partial Class Billing_PatientSearchForPayment
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'Dim lUser As User
        'Dim lIsAuthorize As Boolean
        'Dim lUserRoles As UserRoles

        'If Not Page.IsPostBack Then

        '    lUser = CType(Session.Item("User"), User)
        '    lUserRoles = New UserRoles(lUser.ConnectionString)


        '    '********* Check User Validity ************
        '    lIsAuthorize = lUserRoles.CheckPageAuthorization(lUser.UserId, "PatientSetup.aspx")
        '    If Not lIsAuthorize Then
        '        Response.Redirect("unauthorization.aspx")
        '    End If


        'End If

    End Sub
    Protected Sub grdPatient_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdPatient.NeedDataSource
        grdPatient.AutoGenerateColumns = False

        If Not Page.IsPostBack Then
            LoadPatientGridFirstTime()
        Else
            LoadPatientGrid()
        End If
    End Sub
    Private Sub LoadPatientGrid()
        Dim lUser As User
        Dim lobjPatientDb As New PatientDB
        lUser = CType(Session.Item("User"), User)
        Dim lDs As DataSet
        lobjPatientDb.LastName = Utility.AdjustApostrophie(Me.txtLastName.Text)
        lobjPatientDb.FirstName = Utility.AdjustApostrophie(Me.txtFirstName.Text)

        If (Not Request.QueryString("srch") Is Nothing) Then
            If (Request.QueryString("srch").ToString <> "" And Not Page.IsPostBack) Then
                lobjPatientDb.LastName = Request.QueryString("srch").ToString.Split("|")(0)
                lobjPatientDb.FirstName = Request.QueryString("srch").ToString.Split("|")(1)
            End If
        End If
        lDs = PatientMethods.SearchPatientForPayment(lobjPatientDb, lUser, Request.Url.AbsoluteUri.ToString)
        grdPatient.DataSource = lDs
    End Sub
    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSearch.Click
        grdPatient.Rebind()
    End Sub
    Protected Sub grdPatient_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdPatient.SelectedIndexChanged
        Dim lString As String

        lString = grdPatient.SelectedItems.Item(0).Cells(2).Text & "|" & _
        grdPatient.SelectedItems.Item(0).Cells(4).Text & "|" & _
        grdPatient.SelectedItems.Item(0).Cells(5).Text

        lString = grdPatient.SelectedItems.Item(0).Cells(2).Text & "|" & grdPatient.SelectedItems.Item(0).Cells(4).Text & "," & grdPatient.SelectedItems.Item(0).Cells(5).Text
        'Cache("PatientInformation") = lString

        InjectScript.Text = "<script>CloseOnReload('" & lString & "')</Script>"

    End Sub

    Protected Sub btnClose_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnClose.Click
        InjectScript.Text = "<script>CloseOnly()</Script>"
    End Sub

    Private Sub LoadPatientGridFirstTime()
        Dim lUser As User
        Dim lobjPatientDb As New PatientDB
        lUser = CType(Session.Item("User"), User)
        Dim lDs As DataSet

        If (Request.QueryString("Srch") <> Nothing) Then
            lobjPatientDb.LastName = Request.QueryString.Get("Srch").ToString
            Me.txtLastName.Text = Request.QueryString.Get("Srch").ToString
            lDs = PatientMethods.SearchPatientForPayment(lobjPatientDb, lUser, Request.Url.AbsoluteUri.ToString)
            grdPatient.DataSource = lDs.Tables(0)
        End If


    End Sub
End Class
