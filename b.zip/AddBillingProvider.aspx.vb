
Partial Class Billing_AddBillingProvider
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim lUser As User
        Dim lIsAuthorize As Boolean
        Dim lUserRoles As UserRoles
        lUser = CType(Session.Item("User"), User)
        If IsPostBack = False Then
            lUserRoles = New UserRoles(lUser.ConnectionString)
            '********* Check User Validity ************
            lIsAuthorize = lUserRoles.CheckPageAuthorization(lUser.UserId, "ClinicSetup.aspx")
            If Not lIsAuthorize Then
                Response.Redirect("unauthorization.aspx", False)
            End If
            '********* Load Authorized Tabs Only ***********
            StateMethods.Load_States(cbState, lUser)
            'FillInformationFromObject(BillingProviderMethods.GetBillingProvider(lUser))
            LoadTypeCombo()
            LoadProvider()
        End If

    End Sub
    'Public Sub FillInformationFromObject(ByVal pBillingProviderDB As BillingProviderDB)

    '    If (pBillingProviderDB.FirstName = "") Then
    '        txtOrganizationName.Text = pBillingProviderDB.LastName
    '    Else
    '        txtFirstName.Text = pBillingProviderDB.FirstName
    '        txtMiddleName.Text = pBillingProviderDB.MiddleName
    '        txtLastName.Text = pBillingProviderDB.LastName
    '    End If
    '    txtBillingProviderID.Text = pBillingProviderDB.BillingProviderId
    '    txtAddressOne.Text = pBillingProviderDB.AddressLine1
    '    txtAddressTwo.Text = pBillingProviderDB.AddressLine2
    '    txtCity.Text = pBillingProviderDB.City
    '    Utility.SelectComboItem(cbState, pBillingProviderDB.State, False)
    '    txtZipCode.Text = pBillingProviderDB.ZipCode
    '    txtPhoneOne.Text = pBillingProviderDB.Phone1
    '    txtPhoneTwo.Text = pBillingProviderDB.Phone2
    '    txtFax.Text = pBillingProviderDB.Fax
    '    txtEmail.Text = pBillingProviderDB.Email
    '    txtNPI.Text = pBillingProviderDB.NPI
    '    txtTaxID.Text = pBillingProviderDB.TaxID
    '    mtbSSN.Text = pBillingProviderDB.SSN
    'End Sub
    Public Function SaveInformationToObject() As BillingProviderDB
        Dim lBillingProviderDB As New BillingProviderDB
        With lBillingProviderDB
            If (txtOrganizationName.Text <> "") Then
                .LastName = Utility.ChangeCase(Utility.AdjustApostrophie(txtOrganizationName.Text))
            Else
                .LastName = Utility.ChangeCase(Utility.AdjustApostrophie(txtLastName.Text))
            End If
            .FirstName = Utility.ChangeCase(Utility.AdjustApostrophie(txtFirstName.Text))
            .MiddleName = Utility.ChangeCase(Utility.AdjustApostrophie(txtMiddleName.Text))
            .BillingProviderId = txtBillingProviderID.Text
            .AddressLine1 = Utility.AdjustApostrophie(txtAddressOne.Text)
            .AddressLine2 = Utility.AdjustApostrophie(txtAddressTwo.Text)
            .City = Utility.ChangeCase(Utility.AdjustApostrophie(txtCity.Text))
            .State = cbState.SelectedItem.Text
            .ZipCode = Utility.AdjustApostrophie(txtZipCode.Text)
            .Phone1 = Utility.AdjustApostrophie(txtPhoneOne.Text)
            .Phone2 = Utility.AdjustApostrophie(txtPhoneTwo.Text)
            .Fax = Utility.AdjustApostrophie(txtFax.Text)
            .Email = Utility.AdjustApostrophie(txtEmail.Text)
            .TaxID = Utility.AdjustApostrophie(txtTaxID.Text)
            .NPI = Utility.AdjustApostrophie(txtNPI.Text)
            .SSN = Utility.AdjustApostrophie(mtbSSN.Text)
            .ProviderID = Utility.AdjustApostrophie(cbProvider.SelectedValue.Split("|")(0))
            .ProviderNPI = Utility.AdjustApostrophie(cbProvider.SelectedValue.Split("|")(1))
            .EntryType = Utility.AdjustApostrophie(cbBillingProviderType.SelectedValue)
            .EntryInsuranceTypeCode = Utility.AdjustApostrophie(cbInsuranceType.SelectedValue)
            .EntryInsuranceTypeValue = Utility.AdjustApostrophie(cbInsuranceType.SelectedItem.Text)
        End With
        Return lBillingProviderDB
    End Function
    Protected Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnCancel.Click
        Response.Redirect("BillingProviderSetup.aspx")
    End Sub
    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSave.Click
        'If (txtBillingProviderID.Text <> "") Then
        '    UpdateBillingProvider(SaveInformationToObject)
        'Else
        'InsertBillingProvider(SaveInformationToObject)
        'End If
        If (cbBillingProviderType.SelectedValue = "G") Then
            InsertBillingProvider(SaveInformationToObjectForGeneral, False)
        Else
            CheckExistingRecords()
        End If


    End Sub
    'Public Sub UpdateBillingProvider(ByVal pBillingProviderDB As BillingProviderDB)
    '    Dim lUser As User
    '    lUser = CType(Session.Item("User"), User)
    '    If (BillingProviderMethods.UpdateBillingProvider(pBillingProviderDB, lUser)) Then
    '        Response.Write("<script>alert('Billing Provider Saved Successfully');</script>")
    '        Response.Write("<script>location.href = '../Dashboard.aspx';</script>")
    '    Else
    '        Response.Write("<script>alert('Failed To Save Billing Provider');</script>")
    '    End If
    'End Sub
    Public Sub InsertBillingProvider(ByVal pBillingProviderDB As BillingProviderDB, ByVal pDelete As Boolean)
        Dim lUser As User
        lUser = CType(Session.Item("User"), User)
        If (pDelete) Then
            If (BillingProviderMethods.DeleteInsertBillingProvider(pBillingProviderDB, lUser)) Then
                Response.Write("<script>alert('Billing Provider Saved Successfully');</script>")
                Response.Write("<script>location.href = 'BillingProviderSetup.aspx';</script>")
            Else
                Response.Write("<script>alert('Failed To Save Billing Provider');</script>")
            End If
        Else
            If (BillingProviderMethods.InsertBillingProvider(pBillingProviderDB, lUser)) Then
                Response.Write("<script>alert('Billing Provider Saved Successfully');</script>")
                Response.Write("<script>location.href = 'BillingProviderSetup.aspx';</script>")
            Else
                Response.Write("<script>alert('Failed To Save Billing Provider');</script>")
            End If
        End If
       
    End Sub
    Public Sub LoadTypeCombo()
        If (txtOrganizationName.Text <> "") Then
            cbType.SelectedValue = 1
            txtFirstName.Enabled = False
            txtMiddleName.Enabled = False
            txtLastName.Enabled = False
            txtOrganizationName.Enabled = True
        End If
    End Sub
    Public Sub LoadProvider()
        Dim lDS As New DataSet
        Dim lUser As User
        Try
            lUser = CType(Session.Item("User"), User)
            lDS = BillingProviderMethods.LoadAllProviders(lUser)
            If (lDS.Tables(0).Rows.Count > 0) Then
                cbProvider.DataSource = lDS.Tables(1)
                cbProvider.DataBind()
                Utility.SelectComboItem(cbBillingProviderType, "S", True)
                cbBillingProviderType.Enabled = False
                cbProvider.Enabled = True
                cbInsuranceType.Enabled = True
            Else
                Utility.SelectComboItem(cbBillingProviderType, "G", True)
                cbBillingProviderType.Enabled = False
                cbProvider.Enabled = False
                cbInsuranceType.Enabled = False
            End If
        Catch ex As Exception

        End Try
    End Sub
    Public Sub InsertBillingProviderALL(ByVal pBillingProviderDB As BillingProviderDB, ByVal pDelete As Boolean)
        Dim lXmlDocument As New XmlDocument
        Dim lXmlElement As XmlElement
        Dim lUser As User
        Dim lInsuranceTypeIDs As String = ""
        lUser = CType(Session.Item("User"), User)
        lXmlDocument.LoadXml("<BillingProviders></BillingProviders>")
        lXmlElement = lXmlDocument.CreateElement("BillingProvider")

        For Each lComboItem As Telerik.WebControls.RadComboBoxItem In cbInsuranceType.Items
            If (lComboItem.Text <> "ALL") Then
                With lXmlElement
                    .SetAttribute(("FirstName"), pBillingProviderDB.FirstName)
                    .SetAttribute(("MiddleName"), pBillingProviderDB.MiddleName)
                    .SetAttribute(("LastName"), pBillingProviderDB.LastName)
                    .SetAttribute(("AddressLine1"), pBillingProviderDB.AddressLine1)
                    .SetAttribute(("AddressLine2"), pBillingProviderDB.AddressLine2)
                    .SetAttribute(("City"), pBillingProviderDB.City)
                    .SetAttribute(("State"), pBillingProviderDB.State)
                    .SetAttribute(("ZipCode"), pBillingProviderDB.ZipCode)
                    .SetAttribute(("Phone1"), pBillingProviderDB.Phone1)
                    .SetAttribute(("Phone2"), pBillingProviderDB.Phone2)
                    .SetAttribute(("Fax"), pBillingProviderDB.Fax)
                    .SetAttribute(("Email"), pBillingProviderDB.Email)
                    .SetAttribute(("NPI"), pBillingProviderDB.NPI)
                    .SetAttribute(("TaxID"), pBillingProviderDB.TaxID)
                    .SetAttribute(("SSN"), pBillingProviderDB.SSN)
                    .SetAttribute(("ProviderID"), pBillingProviderDB.ProviderID)
                    .SetAttribute(("ProviderNPI"), pBillingProviderDB.ProviderNPI)
                    .SetAttribute(("EntryType"), pBillingProviderDB.EntryType)
                    .SetAttribute(("EntryInsuranceTypeCode"), lComboItem.Value)
                    .SetAttribute(("EntryInsuranceTypeValue"), lComboItem.Text)
                End With
                lXmlDocument.DocumentElement.AppendChild(lXmlElement.CloneNode(True))
            End If
        Next


        If (pDelete) Then
            'lInsuranceTypeIDs = BillingProviderMethods.CheckBillingProvider(lUser, cbProvider.SelectedValue, cbInsuranceType.SelectedValue)
            'If (lInsuranceTypeIDs.Contains("|")) Then
            '    lInsuranceTypeIDs = lInsuranceTypeIDs.Remove(lInsuranceTypeIDs.IndexOf("|"), 1)
            'End If
            If (BillingProviderMethods.DeleteInsertBillingProviderALL(lXmlDocument.InnerXml.ToString, lUser, txtHiddenInsuranceIDs.Text, cbProvider.SelectedValue)) Then
                Response.Write("<script>alert('Billing Provider Saved Successfully');</script>")
                Response.Write("<script>location.href = 'BillingProviderSetup.aspx';</script>")
            Else
                Response.Write("<script>alert('Failed To Save Billing Provider');</script>")
            End If
        Else
            If (BillingProviderMethods.InsertBillingProviderALL(lXmlDocument.InnerXml.ToString, lUser)) Then
                Response.Write("<script>alert('Billing Provider Saved Successfully');</script>")
                Response.Write("<script>location.href = 'BillingProviderSetup.aspx';</script>")
            Else
                Response.Write("<script>alert('Failed To Save Billing Provider');</script>")
            End If
        End If

    End Sub
    Public Sub CheckExistingRecords()
        Dim lUser As User
        Dim lResult As String
        lUser = CType(Session.Item("User"), User)
        lResult = BillingProviderMethods.CheckBillingProvider(lUser, cbProvider.SelectedValue, cbInsuranceType.SelectedValue)
        txtHiddenInsuranceIDs.Text = lResult
        If (lResult.Contains("|")) Then
            lResult = lResult.Remove(lResult.IndexOf("|"), 1)
            txtHiddenInsuranceIDs.Text = lResult
            Dim strScript As String = "<script language=javascript id='CheckRecord'>RecordCheck();</script>"
            Page.RegisterStartupScript("callDuplicateCheck", strScript)
        Else
            Dim strScript As String = "<script language=javascript id='CheckRecord'>RecordInsert();</script>"
            Page.RegisterStartupScript("callDuplicateCheck", strScript)
        End If

    End Sub
    'Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
    '    If (cbInsuranceType.SelectedItem.Text = "ALL") Then
    '        InsertBillingProviderALL(SaveInformationToObject)
    '    Else
    '        InsertBillingProvider(SaveInformationToObject)
    '    End If
    'End Sub
    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        If (cbInsuranceType.SelectedItem.Text = "ALL") Then
            InsertBillingProviderALL(SaveInformationToObject, False)
        Else
            InsertBillingProvider(SaveInformationToObject, False)
        End If
    End Sub
    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        If (cbInsuranceType.SelectedItem.Text = "ALL") Then
            InsertBillingProviderALL(SaveInformationToObject, True)
        Else
            InsertBillingProvider(SaveInformationToObject, True)
        End If
    End Sub
    Public Function SaveInformationToObjectForGeneral() As BillingProviderDB
        Dim lBillingProviderDB As New BillingProviderDB
        With lBillingProviderDB
            If (txtOrganizationName.Text <> "") Then
                .LastName = Utility.ChangeCase(Utility.AdjustApostrophie(txtOrganizationName.Text))
            Else
                .LastName = Utility.ChangeCase(Utility.AdjustApostrophie(txtLastName.Text))
            End If
            .FirstName = Utility.ChangeCase(Utility.AdjustApostrophie(txtFirstName.Text))
            .MiddleName = Utility.ChangeCase(Utility.AdjustApostrophie(txtMiddleName.Text))
            .BillingProviderId = txtBillingProviderID.Text
            .AddressLine1 = Utility.AdjustApostrophie(txtAddressOne.Text)
            .AddressLine2 = Utility.AdjustApostrophie(txtAddressTwo.Text)
            .City = Utility.ChangeCase(Utility.AdjustApostrophie(txtCity.Text))
            .State = cbState.SelectedItem.Text
            .ZipCode = Utility.AdjustApostrophie(txtZipCode.Text)
            .Phone1 = Utility.AdjustApostrophie(txtPhoneOne.Text)
            .Phone2 = Utility.AdjustApostrophie(txtPhoneTwo.Text)
            .Fax = Utility.AdjustApostrophie(txtFax.Text)
            .Email = Utility.AdjustApostrophie(txtEmail.Text)
            .TaxID = Utility.AdjustApostrophie(txtTaxID.Text)
            .NPI = Utility.AdjustApostrophie(txtNPI.Text)
            .SSN = Utility.AdjustApostrophie(mtbSSN.Text)
            .ProviderID = "0"
            .ProviderNPI = ""
            .EntryType = "G"
            .EntryInsuranceTypeCode = "0"
            .EntryInsuranceTypeValue = ""
        End With
        Return lBillingProviderDB
    End Function
End Class
