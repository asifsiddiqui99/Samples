
Partial Class Billing_EditHCFAWindow
    Inherits System.Web.UI.Page

    Dim mqueryString As String
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Page.IsPostBack = False Then


            Dim lHCFADBUpdated As HCFADBUpdated

            Try
                If (Session("HCFADBUpdated") Is Nothing) Then
                    Exit Sub
                Else

                    lHCFADBUpdated = CType(Session("HCFADBUpdated"), HCFADBUpdated)

                    With lHCFADBUpdated
                        txtEmployeeID.Text = .RenderingProvider.EmployeeID
                        txtFirstName.Text = .RenderingProvider.FirstName
                        txtLastName.Text = .RenderingProvider.LastName
                        txtMiddleName.Text = .RenderingProvider.MiddleName
                        txtDegree.Text = .RenderingProvider.Degree
                    End With


                End If
            Catch ex As Exception

                Return
            End Try
        End If

        

    End Sub

    

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim lHCFADBUpdated As HCFADBUpdated
        lHCFADBUpdated = CType(Session("HCFADBUpdated"), HCFADBUpdated)


        Try

            With lHCFADBUpdated.RenderingProvider
                .EmployeeID = txtEmployeeID.Text
                .FirstName = Utility.AdjustApostrophie(txtFirstName.Text)
                .LastName = Utility.AdjustApostrophie(txtLastName.Text)
                .MiddleName = Utility.AdjustApostrophie(txtMiddleName.Text)
                .Degree = Utility.AdjustApostrophie(txtDegree.Text)

            End With


            Session("HCFADBUpdated") = lHCFADBUpdated
            Response.Write("<script language=javascript>parent.questionwindow4.hide();</script>")


        Catch ex As Exception

        End Try


       
    End Sub
End Class
