
Partial Class Billing_SearchGeneralLedger
    Inherits System.Web.UI.Page

    Protected Sub btnViewGeneralLedger_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnViewGeneralLedger.Click
        Response.Write("<script>window.open('GeneralLedger.aspx?" & Me.dtGeneralFrom.SelectedDate.GetValueOrDefault & "|" & Me.dtGeneralTo.SelectedDate.GetValueOrDefault & "','456')</script>")
    End Sub

End Class
