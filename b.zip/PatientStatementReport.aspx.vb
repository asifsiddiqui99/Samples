
Partial Class Billing_PatientStatementReport
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        BindReport()
    End Sub

    Private Sub BindReport()

        Dim lDs As New DataSet()
        Dim lReportDocument As CrystalDecisions.CrystalReports.Engine.ReportDocument
        Dim lUser As User = CType(HttpContext.Current.Session("User"), User)
        Dim lConnection As New Connection(lUser.ConnectionString)
        Dim lClinic As New Clinic(lUser.ConnectionString)
        Dim lClinicDS As DataSet = Nothing
        Dim lCondition As String = String.Empty
        Dim lPatientID As String
        Dim lCurrent As String
        Dim lSixty As String
        Dim lAboveNinty As String
        Dim lNinty As String
        Dim lAmmountDue As String
        Dim queryString As NameValueCollection
        queryString = Encryption.DecryptQueryString(Request.QueryString.ToString())

        If queryString.GetValues("PatientID") IsNot Nothing Then
            lPatientID = queryString.GetValues("PatientID")(0)
        End If
        If queryString.GetValues("Current") IsNot Nothing Then
            lCurrent = queryString.GetValues("Current")(0)
        End If
        If queryString.GetValues("60") IsNot Nothing Then
            lSixty = queryString.GetValues("60")(0)
        End If
        If queryString.GetValues("90") IsNot Nothing Then
            lNinty = queryString.GetValues("90")(0)
        End If
        If queryString.GetValues("Above") IsNot Nothing Then
            lAboveNinty = queryString.GetValues("Above")(0)
        End If
        If queryString.GetValues("TotalPR") IsNot Nothing Then
            lAmmountDue = queryString.GetValues("TotalPR")(0)
        End If


        Try


            RemoveReportDoc()

            If Session("ReportDocument") Is Nothing Then
                lReportDocument = New CrystalDecisions.CrystalReports.Engine.ReportDocument()
            Else
                lReportDocument = CType(Session("ReportDocument"), CrystalDecisions.CrystalReports.Engine.ReportDocument)
            End If

            '  lCondition = Me.CreateCondition(Utility.AdjustApostrophie(cmbPayer.Text), Utility.AdjustApostrophie(txtCPTCodeFrom.Text).Trim, Utility.AdjustApostrophie(txtCPTCodeTo.Text).Trim)
            If lCondition Is Nothing Then
                Exit Sub
            End If


            Dim lDatatable As New DataTable("PatientStatement")
            lDatatable = PatientMethodsExtended.GetPatientStatementinfo(lPatientID).Tables(0)
            'lDatatable.TableName = "PatientStatement"

            lDs = PatientMethodsExtended.GetPatientStatementinfo(lPatientID)
            lDs.Tables(0).TableName = "PatientStatement"
            Dim lData As New DataTable("PatientStatementDtl")
            lData = PatientMethodsExtended.GetPatientStatementView(lPatientID).Tables(0)
            lDs.Tables.Add(lData.Copy())
            lDs.Tables(1).TableName = "PatientStatementDtl"

            If lDs.Tables(0).Rows.Count > 0 Then

                ' Me.pnlReportViewer.Style("display") = "block"

                lClinicDS = New DataSet
                lClinicDS = lClinic.GetClinicInfoForReports(lUser.ClinicId)

                lReportDocument.Load(Server.MapPath("Reports/PatientStatementRpt.rpt"))
                lReportDocument.SetDataSource(lDs)

                lReportDocument.SetParameterValue("Current", lCurrent)
                lReportDocument.SetParameterValue("Sixty", lSixty)
                lReportDocument.SetParameterValue("Ninty", lNinty)
                lReportDocument.SetParameterValue("AboveNinty", lAboveNinty)
                lReportDocument.SetParameterValue("AmmountDue", lAmmountDue)


                Me.CrystalReportViewer1.ReportSource = lReportDocument
                Me.CrystalReportViewer1.DataBind()
                Session.Add("ReportDocument", lReportDocument)
                Me.CrystalReportViewer1.Zoom(100)
                Me.CrystalReportViewer1.BestFitPage = False
                Me.CrystalReportViewer1.DisplayGroupTree = False
                Me.CrystalReportViewer1.HasViewList = False
                Me.CrystalReportViewer1.HasDrillUpButton = False
                Me.CrystalReportViewer1.HasZoomFactorList = False
                Me.CrystalReportViewer1.HasExportButton = False
                Me.CrystalReportViewer1.HasSearchButton = False
                Me.CrystalReportViewer1.HasPageNavigationButtons = True
                Me.CrystalReportViewer1.HasToggleGroupTreeButton = False
                Me.CrystalReportViewer1.HasCrystalLogo = False
                Me.CrystalReportViewer1.HasDrillUpButton = False
                Me.CrystalReportViewer1.HasGotoPageButton = False
                Me.CrystalReportViewer1.EnableDrillDown = False
                Me.CrystalReportViewer1.Width = New Unit("100%")
                Me.CrystalReportViewer1.Height = New Unit("1500")
                Me.CrystalReportViewer1.DataBind()
                'Me.crvFeeScheduleReport.PrintMode = CrystalDecisions.Web.PrintMode.ActiveX
                'lblMessage.Text = ""


            Else
                ' lblMessage.Text = "No Records Found!"
                ' Me.pnlReportViewer.Style("display") = "none"
            End If





        Catch ex As Exception

        End Try
    End Sub

    Private Sub RemoveReportDoc()
        Dim myReportDocument As CrystalDecisions.CrystalReports.Engine.ReportDocument
        Try
            If Session("ReportDocument") IsNot Nothing Then
                myReportDocument = CType(Session("ReportDocument"), CrystalDecisions.CrystalReports.Engine.ReportDocument)
                myReportDocument.Close()
                myReportDocument.Dispose()
                Session.Remove("ReportDocument")

            End If
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload
        Try
            Dim myReportDocument As CrystalDecisions.CrystalReports.Engine.ReportDocument
            RemoveReportDoc()
            If Session("ReportDocument") IsNot Nothing Then
                myReportDocument = CType(Session("ReportDocument"), CrystalDecisions.CrystalReports.Engine.ReportDocument)
                myReportDocument.Close()
                myReportDocument.Dispose()
                Session.Remove("ReportDocument")

            End If
            CrystalReportViewer1.Dispose()
            CrystalReportViewer1 = Nothing
        Catch ex As Exception

        End Try
    End Sub
End Class
