Imports Telerik.WebControls
Partial Class Billing_FeeSchedule
    Inherits System.Web.UI.Page




    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


        If Not Page.IsPostBack Then

            cmbFeeSchedule.Focus()
            FillGrid()

        End If
    End Sub


    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSearch.Click

        Dim lInsuranceId As Integer = 0
        Dim lString As String = String.Empty
        Dim lDS As DataSet
        Try
            grdFeeSchedule.Columns(0).Visible = True



            If cmbFeeSchedule.Text.Equals("") Or cmbFeeSchedule.Text.ToUpper.Equals("ALL") Then
                lDS = FeeScheduleMethod.GetAllFeeSchedule(Session.Item("User"))
            Else

                lString = cmbFeeSchedule.Value
                If lString.Trim.Equals("") Then
                    grdFeeSchedule.DataSource = Nothing
                    grdFeeSchedule.DataBind()
                    Page.RegisterStartupScript("testscript", "<script language='javascript'>alert('No records found');</script>")
                    btnDelete.Enabled = False
                    Return
                End If
                lInsuranceId = Convert.ToInt32(lString)
                lDS = FeeScheduleMethod.SearchFeeSchedule(Session.Item("User"), lInsuranceId)
               
            End If
            grdFeeSchedule.DataSource = Nothing

            If (lDS.Tables(0).Rows.Count > 0) Then

                grdFeeSchedule.DataSource = lDS
                grdFeeSchedule.DataBind()
                grdFeeSchedule.Columns(0).Visible = False
                btnDelete.Enabled = True
            Else
                grdFeeSchedule.DataSource = Nothing
                grdFeeSchedule.DataBind()
                Page.RegisterStartupScript("testscript", "<script language='javascript'>alert('No records found');</script>")
                btnDelete.Enabled = False
            End If
          
        Catch ex As Exception

        End Try


    End Sub


    Protected Sub cmbFeeSchedule_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbFeeSchedule.ItemsRequested
        Dim lDS As DataSet

        Try
            lDS = FeeScheduleMethod.AutocompeteQuery(Session.Item("User"), e.Text)
            cmbFeeSchedule.DataSource = Nothing
            cmbFeeSchedule.DataSource = lDS
            cmbFeeSchedule.DataTextField = "CompanyName"
            cmbFeeSchedule.DataValueField = "FavInsuranceId"
            cmbFeeSchedule.DataBind()
            btnSearch.Focus()
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub grdFeeSchedule_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles grdFeeSchedule.PageIndexChanging
        grdFeeSchedule.PageIndex = e.NewPageIndex
        Me.FillGrid()
    End Sub

    Protected Sub grdFeeSchedule_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles grdFeeSchedule.RowCommand

        Dim lId As Integer = 0
        Dim lString As String = String.Empty
        Dim lBoolean As Boolean
        Dim lGridViewRow As GridViewRow = Nothing
        Dim lRowIndex As Integer = 0
        Dim luser As User = CType(Session.Item("User"), User)
        Try

            Select Case e.CommandName
                Case "Delete"

                    lString = e.CommandArgument.ToString()
                    lId = CInt(lString)
                    lBoolean = FeeScheduleMethod.DeleteFeeScheduleByHdrID(luser, lId)
                    FillGrid()

                Case "Clone"

                    lString = e.CommandArgument.ToString()
                    lId = Convert.ToInt32(lString)
                    Response.Redirect("FeeScheduleClone.aspx" + ElixirLibrary.Encryption.EncryptQueryString("PID=" & lString))


                Case "AddFeeSchedule"
                    lString = e.CommandArgument.ToString()
                    lGridViewRow = DirectCast(DirectCast(e.CommandSource, LinkButton).NamingContainer, GridViewRow)
                    lRowIndex = lGridViewRow.RowIndex
                    lId = Convert.ToInt32(lString)
                    Session("sCompanyName") = CType(grdFeeSchedule.Rows(lRowIndex).Cells(0).FindControl("LinkButton1"), LinkButton).Text

                    Response.Redirect("AddFeeSchedule.aspx" + ElixirLibrary.Encryption.EncryptQueryString("PID=" & lString))

                    Exit Select
            End Select



        Catch ex As Exception

        End Try
    End Sub


    Public Sub FillGrid()
        grdFeeSchedule.Columns(0).Visible = True
        Dim lDS As DataSet = Nothing
        Dim lInsuranceID As Integer = 0

        Try

            If cmbFeeSchedule.Value.Equals("") Then
                lDS = FeeScheduleMethod.GetAllFeeSchedule(Session.Item("User"))
            Else
                lInsuranceID = CInt(cmbFeeSchedule.Value)
                lDS = FeeScheduleMethod.SearchFeeSchedule(Session.Item("User"), lInsuranceID)
            End If

            grdFeeSchedule.DataSource = lDS
            grdFeeSchedule.DataBind()
            grdFeeSchedule.Columns(0).Visible = False
        Catch ex As Exception

        End Try

    End Sub


    Protected Sub btnAdd_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnAdd.Click
        Response.Redirect("AddFeeSchedule.aspx")
    End Sub

    Protected Sub grdFeeSchedule_RowDeleting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewDeleteEventArgs) Handles grdFeeSchedule.RowDeleting
        'THIS WAS REQUIRED BY THE PAGE WITHOUT ANY IMPLEMENTATION. DO NOT REMOVE
    End Sub
    Protected Sub btnImport_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnImport.Click
        Response.Redirect("ImportFeeSchedule.aspx")
    End Sub

    Protected Sub btnDelete_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnDelete.Click
        Dim chk As CheckBox
        Dim lds As DataSet
        lds = Session("DataSet")
        Dim lDataRow As DataRow
        Dim lBoolean As Boolean
        Dim luser As User = CType(Session.Item("User"), User)
        grdFeeSchedule.Columns(0).Visible = True
        For Each row As GridViewRow In grdFeeSchedule.Rows
            chk = CType(row.FindControl("chkFeeItem"), CheckBox)
            If chk.Checked = True Then
                Dim lHdrID = row.Cells(0).Text
                lBoolean = FeeScheduleMethod.DeleteFeeScheduleByHdrID(luser, lHdrID)
                Me.FillGrid()
            End If
        Next
        If (grdFeeSchedule.Rows.Count > 0) Then
        Else

            btnDelete.Enabled = False
        End If

        Session("DataSet") = lds
    End Sub
End Class
