Imports Telerik.WebControls

Partial Class InsuranceList
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim lInsuranceName As String = String.Empty
        Dim lstate As String = ""
        If (Page.IsPostBack = True) Then
            'If Server.UrlDecode(Request.QueryString("InsuranceName").ToString) IsNot Nothing Then
            '    lInsuranceName = Server.UrlDecode(Request.QueryString("InsuranceName").ToString)
            'Else
            '    lInsuranceName = ""
            'End If
            'lInsuranceName = txtPayerName.Text
            'lstate = cmbState.Text
            RGInsuranceList.DataBind()
            'InsuranceMethods.LoadInsuranceListGridForPayment(RGInsuranceList, lInsuranceName, lstate)
        Else
            If (Request.QueryString("InsuranceName") IsNot Nothing) Then
                txtPayerName.Text = Request.QueryString("InsuranceName").ToString
            End If
        End If
    End Sub
    ''changes made by talha...
    Protected Sub RGInsuranceList_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles RGInsuranceList.NeedDataSource
        Dim lInsuranceName As String = String.Empty
        Dim lstate As String = String.Empty
        If Not String.IsNullOrEmpty(txtPayerName.Text) Then
            lInsuranceName = txtPayerName.Text
            'ElseIf Request.QueryString("InsuranceName") IsNot Nothing Then
            '    lInsuranceName = Request.QueryString("InsuranceName").ToString
        End If
        lstate = cmbState.Text
        InsuranceMethods.LoadInsuranceListGridForPayment(RGInsuranceList, lInsuranceName, lstate)
    End Sub
    Protected Sub RGInsuranceList_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles RGInsuranceList.SelectedIndexChanged
        Dim lString As String
        lString = RGInsuranceList.SelectedItems(0).Cells(3).Text & "|" & RGInsuranceList.SelectedItems.Item(0).Cells(4).Text & _
        "|" & RGInsuranceList.SelectedItems.Item(0).Cells(6).Text & "|" & RGInsuranceList.SelectedItems.Item(0).Cells(7).Text
        Session("InsuranceInformation") = lString
        InjectScript.Text = "<Script>CloseAndReload();</Script>"
    End Sub
    Protected Sub btnClose_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnClose.Click
        lblClose.Text = "<script>CloseOnly()</Script>"
    End Sub
    Protected Sub cmbState_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbState.ItemsRequested
        Dim lUser As User
        lUser = CType(Session.Item("User"), User)
        Dim lCond As String
        lCond = "And Abbr Like '" & Utility.AdjustApostrophie(e.Text) & "%' "
        If (e.Text = "") Then
            Exit Sub
        End If
        StateMethods.Load_States(cmbState, lUser, lCond)
    End Sub
End Class
