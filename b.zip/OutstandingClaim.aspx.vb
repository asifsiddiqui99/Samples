Imports Telerik.WebControls
Partial Class Billing_Default3
    Inherits System.Web.UI.Page
    Protected Sub cmbPayer_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbPayer.ItemsRequested
        Dim lDS As DataSet
        Dim lUser As User
        lUser = CType(Session.Item("User"), User)
        Dim lBillingProvider As New BillingProvider(lUser.ConnectionString)
        Try
            lDS = PaymentMethods.GetPayerName("Insurance")
            cmbPayer.DataSource = Nothing
            cmbPayer.DataSource = lDS
            cmbPayer.DataTextField = "CompanyName"
            cmbPayer.DataValueField = "PayerID"
            cmbPayer.DataBind()
        Catch ex As Exception

        End Try
    End Sub
    Public Sub RemoveReportDoc()
        Dim myReportDocument As CrystalDecisions.CrystalReports.Engine.ReportDocument
        Try
            If Session("ReportDocument") IsNot Nothing Then
                myReportDocument = CType(Session("ReportDocument"), CrystalDecisions.CrystalReports.Engine.ReportDocument)
                myReportDocument.Close()
                myReportDocument.Dispose()
                Session.Remove("ReportDocument")

            End If
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub btnSearchPatient_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSearchPatient.Click
        Try
            RemoveReportDoc()
            LoadReport()
        Catch ex As Exception

        End Try
    End Sub
    Public Sub LoadReport()
        Try
           
            BindReport("patient")
           

            'If Me.pnlPayer.Visible = True Then
            '    BindReport("payer")
            'ElseIf (Me.pnlDOS.Visible = True) Then
            '    BindReport("dos")
            'ElseIf (Me.pnlAccount.Visible = True) Then
            '    BindReport("account")
            'ElseIf (Me.pnlPatient.Visible = True) Then
            '    BindReport("patient")
            'End If
        Catch ex As Exception

        End Try
    End Sub
    Public Sub BindReport(ByVal pCriteria As String)
        Dim myReportDocument As New CrystalDecisions.CrystalReports.Engine.ReportDocument()
        Dim lDs As DataSet
        Dim lClinicDS As DataSet
        Dim lUser As User
        Dim lConnection As Connection
        Dim lClinic As Clinic
        Dim lAgingRp As AgingReportMethods
        Dim lDosMainCond As String = ""
        Dim lDosClPyCond As String = ""
        Dim lCond As String = ""
        lblMessage.Text = ""
        If Not dpTo.DateInput.Text = "" And Not dpFrom.DateInput.Text = "" Then
            lCond += "AND cast(convert(varchar(10),RefillingDate,101) as datetime) between '" & dpFrom.DateInput.DbSelectedDate & "' AND '" & dpTo.DateInput.DbSelectedDate & "'"
        End If

        If Not cmbPatientName.Text = "" Then

            ' lCond += "AND (Final.PatientName like '" & Utility.AdjustApostrophie(cmbPatientName.Text.Replace(" ", "")) & "%' or Final.PatientName like '" & Utility.AdjustApostrophie(cmbPatientName.Text) & "%' or Final.PatientName like '" & Utility.AdjustApostrophie(cmbPatientName.Text.Replace(",", ", ")) & "%') "
            lCond += "AND (Final.PatientName like '" & Utility.AdjustApostrophie(cmbPatientName.Text.Replace(", ", ",")) & "%' or Final.PatientName like '" & Utility.AdjustApostrophie(cmbPatientName.Text) & "%' or Final.PatientName like '" & Utility.AdjustApostrophie(cmbPatientName.Text.Replace(",", ", ")) & "%') "

            'lCond += "AND Final.PatientName like '" & Utility.AdjustApostrophie(cmbPatientName.Text) & "%'"

        End If

        If Not cmbPayer.Text = "" Then
            lCond += "AND PayerName like '" & Utility.AdjustApostrophie(cmbPayer.Text) & "%'"
        End If

        If Not txtClaim.Text = "" Then
            lCond += "AND Final.ClaimID='" & Utility.AdjustApostrophie(txtClaim.Text) & "'"
        End If

        'If cmbPatientName.Text.Contains(" ") Then
        '    lCond = "AND Final.PatientName like '" & cmbPatientName.Text.Trim(" ") & "%'" & _
        '                             "AND Final.ClaimID='" & txtClaim.Text & "'" & _
        '                             "AND RefillingDate between '" & dpFrom.SelectedDate.ToString & "' AND '" & dpFrom.SelectedDate.ToString & "'" & _
        '                             "AND PayerName like '" & cmbPayer.Text & " %'"
        'Else
        '    lCond = "AND Final.PatientName like '" & cmbPatientName.Text & "%'" & _
        '                   "AND Final.ClaimID='" & txtClaim.Text & "'" & _
        '                  "AND RefillingDate between '" & dpFrom.SelectedDate.ToString & "' AND '" & dpFrom.SelectedDate.ToString & "'" & _
        '                  "AND PayerName like '" & cmbPayer.Text & " %'"
        'End If

        Try
            If Session("ReportDocument") Is Nothing Then
                myReportDocument = New CrystalDecisions.CrystalReports.Engine.ReportDocument
            Else
                myReportDocument = CType(Session("ReportDocument"), CrystalDecisions.CrystalReports.Engine.ReportDocument)
            End If

            lUser = CType(HttpContext.Current.Session("User"), User)
            lConnection = New Connection(lUser.ConnectionString)
            lClinic = New Clinic(lUser.ConnectionString)
            lDs = New DataSet
            lClinicDS = New DataSet
            lClinicDS = lClinic.GetClinicInfoForReports(lUser.ClinicId)
            lAgingRp = New AgingReportMethods(lConnection)

            lDs = ClaimMethods.GetOutstandingClaim(lCond, lUser)


            'If (pCriteria = "payer") Then
            '    lDs.Tables(0).TableName = "AgingReportByPayer"
            '    myReportDocument.Load(Server.MapPath("Reports/AgingReportByPayer.rpt"))
            'ElseIf (pCriteria = "patient") Then
            '    lDs.Tables(0).TableName = "AgingReportByPatient"
            '    myReportDocument.Load(Server.MapPath("Reports/AgingReportByPatient.rpt"))
            'ElseIf (pCriteria = "account") Then
            '    lDs.Tables(0).TableName = "AgingReportByAccount"
            '    myReportDocument.Load(Server.MapPath("Reports/AgingReportByAccount.rpt"))
            'ElseIf (pCriteria = "dos") Then
            '    lDs.Tables(0).TableName = "AgingReportByDOS"
            '    myReportDocument.Load(Server.MapPath("Reports/AgingReportByDOS.rpt"))
            'End If

            If lDs.Tables(0).Rows.Count > 0 Then
                'lblMessage.Style("display") = "none"

                lDs.Tables(0).TableName = "OutStandingClaim"
                myReportDocument.Load(Server.MapPath("Reports/OutStandingClaimRpt.rpt"))

                myReportDocument.SetDataSource(lDs)
                myReportDocument.SetParameterValue("PClinicName", lClinicDS.Tables(0).Rows(0)("ClinicName"))

                myReportDocument.SetParameterValue("PClinicAddress", lClinicDS.Tables(0).Rows(0)("ClinicAddressLine1") + " " + lClinicDS.Tables(0).Rows(0)("ClinicCity") + " " + lClinicDS.Tables(0).Rows(0)("ClinicState") + " " + lClinicDS.Tables(0).Rows(0)("ClinicZipCode"))
                'If lClinicDS.Tables(0).Rows(0)("ClinicZipCode").ToString.Length > 5 Then
                '    myReportDocument.SetParameterValue("PClinicAddress", lClinicDS.Tables(0).Rows(0)("ClinicAddressLine1") + " " + lClinicDS.Tables(0).Rows(0)("ClinicCity") + " " + lClinicDS.Tables(0).Rows(0)("ClinicState") + " " + lClinicDS.Tables(0).Rows(0)("ClinicZipCode").ToString.Substring(0, 5) + "-" + lClinicDS.Tables(0).Rows(0)("ClinicZipCode").ToString.Substring(5, 4))
                'End If

                'Me.pnlReportViewer.Visible = True
                Me.pnlReportViewer.Style("display") = "block"
                Me.crvAgingByCriteria.ReportSource = myReportDocument
                Session.Add("ReportDocument", myReportDocument)
                Me.crvAgingByCriteria.Zoom(100)
                Me.crvAgingByCriteria.BestFitPage = False
                Me.crvAgingByCriteria.DisplayGroupTree = False
                Me.crvAgingByCriteria.HasViewList = False
                Me.crvAgingByCriteria.HasDrillUpButton = False
                Me.crvAgingByCriteria.HasZoomFactorList = False
                Me.crvAgingByCriteria.HasExportButton = False
                Me.crvAgingByCriteria.HasSearchButton = False
                Me.crvAgingByCriteria.HasPageNavigationButtons = True
                Me.crvAgingByCriteria.HasToggleGroupTreeButton = False
                Me.crvAgingByCriteria.HasCrystalLogo = False
                Me.crvAgingByCriteria.HasDrillUpButton = False
                Me.crvAgingByCriteria.HasGotoPageButton = False
                Me.crvAgingByCriteria.EnableDrillDown = False
                Me.crvAgingByCriteria.Width = New Unit("100%")
                Me.crvAgingByCriteria.Height = New Unit("550")

                Me.crvAgingByCriteria.DataBind()
                Me.crvAgingByCriteria.PrintMode = CrystalDecisions.Web.PrintMode.Pdf
            Else
                lblMessage.Style("display") = "block"
                lblMessage.Text = "No records found"

            End If
        Catch ex As Exception
            Response.Write("<script>alert('Error Generating Report, Contact your System administrator');</script>")
            RemoveReportDoc()
            Return
        End Try
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            dpTo.SelectedDate = Date.Now
            dpFrom.SelectedDate = Date.Now.AddMonths(-6)
        Else
            Me.LoadReport()
        End If

    End Sub

    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload
        Try
            RemoveReportDoc()
            crvAgingByCriteria.Dispose()
            crvAgingByCriteria = Nothing
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub btnMirror_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnMirror.Click
        Dim newWindow As RadWindow
        Try
            newWindow = New RadWindow()
            If (cmbPatientName.Text.ToString.Split(",").Length = 1) Then
                newWindow.NavigateUrl = "PatientSearch.aspx?srch=" & Utility.AdjustApostrophie(Me.cmbPatientName.Text.ToString.Split(",")(0)) & "|" & "" & ""
            ElseIf (cmbPatientName.Text.ToString.Split(",").Length > 1) Then
                newWindow.NavigateUrl = "PatientSearch.aspx?srch=" & Utility.AdjustApostrophie(Me.cmbPatientName.Text.ToString.Split(",")(0)) & "|" & Me.cmbPatientName.Text.ToString.Split(",")(1) & ""
            Else

            End If
            newWindow.ID = "rwPrimaryInsurer"
            newWindow.VisibleOnPageLoad = True
            newWindow.Top = 220
            newWindow.Left = 280
            newWindow.Width = Unit.Pixel(696)
            newWindow.Height = Unit.Pixel(390)
            newWindow.VisibleTitlebar = False
            newWindow.VisibleStatusbar = False
            newWindow.BorderStyle = BorderStyle.Solid
            newWindow.ReloadOnShow = True
            newWindow.BackColor = Drawing.Color.Transparent
            newWindow.ClientCallBackFunction = "PatientSearchCallBackFunction"
            newWindow.Enabled = True
            newWindow.Visible = True
            rwmSuperBill.Windows.Add(newWindow)
        Catch ex As Exception
            Dim lLogID As String = String.Empty
            lLogID = ErrorLogMethods.LogError(ex, " Billing_PatientLedgerPage.aspx\btnMirror_Click() ")
            Response.Redirect("~/ErrorPage.aspx?LogID=" & lLogID, False)
        End Try
    End Sub
End Class
