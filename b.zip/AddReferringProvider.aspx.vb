Imports Telerik.WebControls
Partial Class Billing_AddReferringProvider
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim lDs As DataSet
        Dim lUser As User
        
        If Not Page.IsPostBack Then

            lUser = CType(Session.Item("User"), User)
            tsEmployee.SelectedIndex = 0
            mpEmployee.SelectedIndex = 0

            lDs = ReferringMethods.GetSpeciality(ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString)
            Me.txtSpeciality.datasource = lDs
            Me.txtSpeciality.DataTextField = "SpecializationId"
            Me.txtSpeciality.DataValueField = "Code"
            Me.txtSpeciality.DataBind()


            'StateMethods.Load_States(cmbState, lUser)

            FacilityMethods.LoadFacilityNameCombo(cmbFacility, "")
            cmbFacility.Items.Insert(0, New RadComboBoxItem(""))
        End If

    End Sub

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSave.Click

        If (ReferringMethods.CheckExist(txtNPI.Text)) Then
            Me.RadAjaxManager1.Alert("Referring Provider With Same NPI Already Exists")
        Else
            Dim lResult As String
            Dim lReferringProviderDB As ReferringProviderDB = New ReferringProviderDB

            With lReferringProviderDB

                .FirstName = txtFirstName.Text
                .MiddleName = txtMiddleName.Text
                .LastName = txtLastName.Text
                .AddressLine1 = txtAddressLine1.Text
                .AddressLine2 = txtAddressLine2.Text
                .City = txtCity.Text
                .State = cmbState.Text
                .ZipCode = mtbZipCode.Text
                .WorkPhone = mtbWorkPhone.Text
                .Ext = mtbWorkPhoneExtension.Text
                .Fax = mtbFax.Text
                .Email = txtEmail.Text
                .NPI = txtNPI.Text
                .Speciality = txtSpeciality.Text
                .Degree = txtDegree.Text

                If (cmbFacility.Text <> "") Then
                    .Facility = cmbFacility.Value
                Else
                    .Facility = 0
                End If

            End With

            lResult = ReferringMethods.AddReferring(lReferringProviderDB)

            'lblMessage.Text = lResult
            Me.RadAjaxManager1.Alert(lResult)
            Me.RadAjaxManager1.Redirect("ReferringProviderSetup.aspx")
        End If

    End Sub

    Protected Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnCancel.Click
        Response.Redirect("ReferringProviderSetup.aspx")
    End Sub

    Protected Sub cmbState_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbState.ItemsRequested
        Dim lUser As User
        lUser = CType(Session.Item("User"), User)

        Dim lCond As String
        lCond = "And Abbr Like '" & Utility.AdjustApostrophie(e.Text) & "%' "

        If (e.Text = "") Then
            Exit Sub
        End If

        StateMethods.Load_States(cmbState, lUser, lCond)
    End Sub

    'Protected Sub cmbFacility_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbFacility.ItemsRequested
    '    Dim lCond As String
    '    Dim lds As New DataSet
    '    lCond = "And FacilityName Like '" & Utility.AdjustApostrophie(e.Text) & "%' "

    '    If (e.Text = "") Then
    '        Exit Sub
    '    End If

    '    FacilityMethods.LoadFacilityNameCombo(cmbFacility, lCond)

    'End Sub
End Class
