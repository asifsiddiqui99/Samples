
Partial Class Billing_LedgerReports
    Inherits System.Web.UI.Page

    Protected Sub btnViewPatientLedger_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnViewPatientLedger.Click
        Response.Write("<script>window.open('PatientLedger.aspx?" & Me.cmbPatientName.Text & "|" & Me.dtFrom.SelectedDate.GetValueOrDefault & "|" & Me.dtTo.SelectedDate.GetValueOrDefault & "','123')</script>")
    End Sub

    Protected Sub btnViewGeneralLedger_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnViewGeneralLedger.Click
        Response.Write("<script>window.open('GeneralLedger.aspx?" & Me.dtGeneralFrom.SelectedDate.GetValueOrDefault & "|" & Me.dtGeneralTo.SelectedDate.GetValueOrDefault & "','456')</script>")
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        
    End Sub
End Class
