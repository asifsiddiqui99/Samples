Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports System.Security.Cryptography
Imports System.Data
Imports ElixirLibrary
Imports System.Data.SqlClient
Imports BillingReportMethod
Partial Class DailyTransactionReport
    Inherits System.Web.UI.Page


    Protected Sub imgView_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgView.Click
        Try
            LoadReport()
        Catch ex As Exception
            Response.Write("<script>alert('Error Generating Report, Contact your System administrator');</script>")
            Return
        End Try

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            Me.crvDailyTransactionSummary.Width = New Unit("1075")
            dtMonth.MaxDate = Date.Now
            If (Not Page.IsPostBack) Then
                dtMonth.SelectedDate = DateTime.Now

            End If

            If (Page.IsPostBack) Then
                LoadReport()
            End If

        Catch ex As Exception
            Response.Write("<script>alert('Error Generating Report, Contact your System administrator');</script>")
            Return
        End Try
    End Sub

    Public Sub LoadReport()


        Dim lDs As New DataSet()
        Dim myReportDocument As ReportDocument
        Dim lUser As User = CType(HttpContext.Current.Session("User"), User)
        Dim lConnection As New Connection(lUser.ConnectionString)
        Dim lClinic As New Clinic(lUser.ConnectionString)
        Dim clinicTbl As DataTable
        Dim lDs2 As New DataSet()
        Dim lDate As DateTime

        Try

            RemoveReportDoc()
            ' Dim lQuery As String = "Select Items='Kanwal', Day='10', CurrentDay='Day', CurrentYear='2010' from ClinicInfo"

            'lSpParameter(0).ParameterName = "@pDate"
            'lSpParameter(0).ParameterType = ElixirLibrary.ParameterType.BigInt
            'lSpParameter(0).ParameterValue = dtMonth.SelectedDate.GetValueOrDefault.Date.ToString()

            'If lConnection.IsTransactionAlive() Then
            '    lDs = lConnection.ExecuteTransactionQuery("GetDailyTransactionReport", lSpParameter)
            'Else
            '    lDs = lConnection.ExecuteQuery("GetDailyTransactionReport", lSpParameter)
            'End If

            If Session("ReportDocument") Is Nothing Then
                myReportDocument = New ReportDocument()
            Else
                myReportDocument = CType(Session("ReportDocument"), ReportDocument)
            End If

            lDate = dtMonth.SelectedDate.GetValueOrDefault.Date.ToString()
            lDs2 = lClinic.GetClinicInfoForReports(lUser.ClinicId)
            lDs = GetDailyTransactionReport(lDate)
            lDs2.Tables(0).TableName = "ClinicInfo"
            clinicTbl = New DataTable("ClinicInfo")
            clinicTbl = lDs2.Tables(0).Copy()
            lDs.Tables.Add(clinicTbl)
            lDs.Tables(0).TableName = "DailyTransReport"
            lDs.Tables(1).TableName = "ClinicInfo"
            myReportDocument.Load(Server.MapPath("Reports/DailyTransactionSummaryDetails.rpt"))
            myReportDocument.SetDataSource(lDs)
            crvDailyTransactionSummary.ReportSource = myReportDocument
            Session.Add("ReportDocument", myReportDocument)
            crvDailyTransactionSummary.Zoom(100)
            crvDailyTransactionSummary.BestFitPage = False
            crvDailyTransactionSummary.DisplayGroupTree = False
            crvDailyTransactionSummary.HasViewList = False
            crvDailyTransactionSummary.HasDrillUpButton = False
            crvDailyTransactionSummary.HasZoomFactorList = False
            crvDailyTransactionSummary.HasExportButton = False
            crvDailyTransactionSummary.HasSearchButton = False
            crvDailyTransactionSummary.HasPageNavigationButtons = False
            crvDailyTransactionSummary.HasToggleGroupTreeButton = False
            crvDailyTransactionSummary.HasCrystalLogo = False
            crvDailyTransactionSummary.HasDrillUpButton = False
            crvDailyTransactionSummary.HasGotoPageButton = False
            crvDailyTransactionSummary.Width = New Unit("100%")
            crvDailyTransactionSummary.Height = New Unit("700")
            crvDailyTransactionSummary.DataBind()


        Catch ex As Exception
            Response.Write("<script>alert('Error Generating Report, Contact your System administrator');</script>")
            Return
        End Try
    End Sub

    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload
        Try
            Dim myReportDocument As ReportDocument
            If Session("ReportDocument") IsNot Nothing Then
                myReportDocument = CType(Session("ReportDocument"), ReportDocument)
                myReportDocument.Close()
                myReportDocument.Dispose()
                Session.Remove("ReportDocument")
             
            End If
            crvDailyTransactionSummary.Dispose()
            crvDailyTransactionSummary = Nothing
        Catch ex As Exception
            Response.Write("<script>alert('Error Generating Report, Contact your System administrator');</script>")
            Return
        End Try
    End Sub

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        Try
            If (Page.IsPostBack) Then
                LoadReport()
            End If
        Catch ex As Exception
            Response.Write("<script>alert('Error Generating Report, Contact your System administrator');</script>")
            Return
        End Try
    End Sub

    Private Sub RemoveReportDoc()
        Dim myReportDocument As ReportDocument
        Try
            If Session("ReportDocument") IsNot Nothing Then
                myReportDocument = CType(Session("ReportDocument"), ReportDocument)
                myReportDocument.Close()
                myReportDocument.Dispose()
                Session.Remove("ReportDocument")
            End If
        Catch ex As Exception

        End Try
    End Sub

End Class
