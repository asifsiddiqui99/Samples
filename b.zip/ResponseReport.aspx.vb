
Partial Class Billing_ResponseReport
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If (Not Page.IsPostBack) Then
            Dim lResponsePaymentDetailColl As New ResponsePaymentDetailColl
            Dim lClaimResponseDB As New ClaimResponseDB
            Dim lResponsePaymentDetail As New ResponsePaymentDetail
            ClaimResponse835.ParseResponse(lResponsePaymentDetailColl, lClaimResponseDB, "")
            lResponsePaymentDetail.Amount = lClaimResponseDB.PaymentAmount
            lResponsePaymentDetail.Item = "Total Payment"
            lResponsePaymentDetailColl.Add(lResponsePaymentDetail)
            Me.grdResponsePaymentDetail.DataSource = lResponsePaymentDetailColl
            Me.grdResponsePaymentDetail.DataBind()
            lblPayerName.Text = lClaimResponseDB.PayerName
            lblClaimDate.Text = lClaimResponseDB.ClaimDate
            lblPayerAddress.Text = lClaimResponseDB.PayerAddress
            lblPayerCityStateZip.Text = lClaimResponseDB.PayerCityStateZip
            lblPayTo.Text = lClaimResponseDB.PayTo
            lblPayment.Text = lClaimResponseDB.PaymentAmount
            lblPayeeName.Text = lClaimResponseDB.PayeeName
            lblPayeeAddress.Text = lClaimResponseDB.PayeeAddress
            lblPayeeCityStateZip.Text = lClaimResponseDB.PayeeCityStateZip
            lblPatientControlNumber2.Text = lClaimResponseDB.PatientControlNumber
            lblPayerControlNumber.Text = lClaimResponseDB.PayerControlNumber
            lblTransmissionDate.Text = lClaimResponseDB.TransmissionDate
            lblPatientControlNumber1.Text = lClaimResponseDB.PatientControlNumber
        End If

    End Sub

End Class
