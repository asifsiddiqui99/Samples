Imports CrystalDecisions.Shared
Imports CrystalDecisions.CrystalReports.Engine

Partial Class Billing_AgingDetailReport
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim lDs As New DataSet()
        Dim myReportDocument As New ReportDocument()
        Dim lUser As User = CType(HttpContext.Current.Session("User"), User)
        Dim lConnection As New Connection(lUser.ConnectionString)
        Dim lClinic As New Clinic(lUser.ConnectionString)
        Dim clinicTbl As DataTable
        Dim lDs2 As New DataSet()

        lDs = lConnection.ExecuteQuery("exec GetAgingreport")

        lDs2 = lClinic.GetClinicInfoForReports(lUser.ClinicId)
        lDs2.Tables(0).TableName = "ClinicInfo"
        clinicTbl = New DataTable("ClinicInfo")
        clinicTbl = lDs2.Tables(0).Copy()
        lDs.Tables.Add(clinicTbl)
        lDs.Tables(0).TableName = "AgingDetail"
        lDs.Tables(1).TableName = "ClinicInfo"

        myReportDocument.Load(Server.MapPath("Reports/AgingDetailReport.rpt"))
        myReportDocument.SetDataSource(lDs)

        'CrystalReportViewer1.ReportSource = myReportDocument


        Session.Add("ReportDocument", myReportDocument)

        Response.ClearContent()
        Response.ClearHeaders()
        Response.ContentType = "application/pdf"

        ' Export the document to PDF
        myReportDocument.ExportToHttpResponse(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat, Response, False, "")
        Response.Flush()
        Response.Close()


        'CrystalReportViewer1.Zoom(125)
        'CrystalReportViewer1.BestFitPage = False
        'CrystalReportViewer1.DisplayGroupTree = False
        'CrystalReportViewer1.HasViewList = False
        'CrystalReportViewer1.HasDrillUpButton = False
        'CrystalReportViewer1.Width = New Unit("100%")
        'CrystalReportViewer1.Height = New Unit("1500")

        'CrystalReportViewer1.DataBind()
    End Sub

    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload

        Dim myReportDocument As ReportDocument

        If Session("ReportDocument") IsNot Nothing Then
            myReportDocument = CType(Session("ReportDocument"), ReportDocument)
            myReportDocument.Close()
            myReportDocument.Dispose()
            Session.Remove("ReportDocument")
        End If
    End Sub
End Class
