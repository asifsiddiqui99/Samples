Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports System.Data
Imports ElixirLibrary
Imports System.Data.SqlClient
Partial Class Billing_ReportPatientLedger
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim queryString As NameValueCollection

        Dim lDs As New DataSet
        Dim lDstemp As New DataSet
        Dim lUser As User = CType(HttpContext.Current.Session("User"), User)
        Dim lConnection As New Connection(lUser.ConnectionString)

        Dim lParameterFields As New ParameterFields()
        Dim lParameterField As New ParameterField()
        Dim lParameterValue As New ParameterDiscreteValue()

        Dim lQuery As String = ""
        Dim lPatientId As String = ""
        Dim lFromDate As String = ""
        Dim lToDate As String = ""
        Dim lParameters() As String
        Dim myReportDocument As ReportDocument

        If (Request.QueryString Is Nothing) Then
            Exit Sub
        Else
            If Session("ReportDocument") Is Nothing Then
                myReportDocument = New ReportDocument()
            Else
                myReportDocument = CType(Session("ReportDocument"), ReportDocument)
            End If

            queryString = Encryption.DecryptQueryString(Request.QueryString.ToString())
            lParameters = queryString.GetValues("value")

            If (lParameters IsNot Nothing AndAlso lParameters.Length > 0) Then

      
                If (lParameters(0).Contains("|") AndAlso lParameters(0).Split("|").Length = 3) Then


                    lPatientId = lParameters(0).Split("|")(0) '"6502" '
                    lFromDate = Convert.ToDateTime(lParameters(0).Split("|")(1)).Date.ToShortDateString '"1/25/2010" '
                    lToDate = Convert.ToDateTime(lParameters(0).Split("|")(2)).Date.ToShortDateString  '"1/27/2010" '
                    ' ReferenceDisplayID2 & Reference To be used in Report as FromTransactionDate & ToTransactionDate
                    lQuery = "Select " & _
                          "PlPatientId=''," & _
                          "LineID='' ," & _
                          "ReferenceID='' ," & _
                          "ReferenceDate='" & Convert.ToDateTime(lFromDate).AddDays(-1).ToString("MM/dd/yyyy") & "'," & _
                          "ReferenceID2=''," & _
                          "ReferenceDate2=''," & _
                          "ReferenceDisplayID='', " & _
                          "ReferenceDisplayDate='', " & _
                          "ReferenceDisplayID2='" & lToDate & "', " & _
                          "TransactionType='', " & _
                          "Reference='" & lFromDate & "', " & _
                          "[Date]='" & Convert.ToDateTime(lFromDate).ToString("MM/dd/yyyy") & "'," & _
                          "[Description]='Opening Balance', " & _
                          "PaymentMethod='', " & _
                          "PayerName='', " & _
                          "PayerType='', " & _
                          "Debit=IsNull(sum(Debit),0),Credit=IsNull(sum(Credit),0)," & _
                          "Adjustment=IsNull((SELECT Balance=sum(Debit) - sum(Credit) FROM PatientLedger where PatientID='" & lPatientId & "' and [Date] <= '" & Date.Now.Date & "'),0), " & _
                          "ChequeNumber=''," & _
                          "ChequeDate=''," & _
                   "PatientID=max(Pt.PatientID), " & _
                   " Title=max(Pt.Title), " & _
                   " FirstName=max(Pt.FirstName), " & _
                   " MiddleName=max(Pt.MiddleName), " & _
                   " LastName=max(Pt.LastName), " & _
                   " PtAddressLine1=max(Pt.AddressLine1) + ', ' + max(Pt.AddressLine2), " & _
                   " PtAddressLine2=max(Pt.City) + ' ' + max([state].Abbr) + ' ' + max(Pt.ZipCode) , " & _
                   " City=max(Pt.City), " & _
                   " StateID=max(Pt.StateId), " & _
                   " ZipCode=max(Pt.ZipCode), " & _
                    " ZipCode=max(Pt.ZipCode), " & _
                  " HousePhone=max(Pt.HousePhone), " & _
                   " WorkPhone=max(Pt.WorkPhone), " & _
                   " WorkPhoneExtension=max(Pt.WorkPhoneExtension), " & _
                   " PtFax=max(Pt.Fax), " & _
                   " PtEmail=max(Pt.Email), " & _
                   " Occupation=max(Pt.Occupation), " & _
                   " DOB=max(Pt.DOB), " & _
                   " Gender=max(Pt.Gender), " & _
                   " InsuranceID=max(Pt.InsuranceID), " & _
                   " InsuranceName=max(Pt.InsuranceName), " & _
                   " NcpdpID=max(Pt.NcpdpID), " & _
                   " PharmacyName=max(Pt.PharmacyName), " & _
                   " IsDeleted=max(Pt.IsDeleted), " & _
                   " PictureFilePath=max(Pt.PictureFilePath), " & _
                   " SSN=max(Pt.SSN), " & _
                   " PharmacyProvider=max(Pt.PharmacyProvider), " & _
                   " MartialStatus=max(Pt.MartialStatus), " & _
                   " CellPhoneNumber=max(Pt.CellPhoneNumber), " & _
                   " EmergencyContactName=max(Pt.EmergencyContactName), " & _
                   " EmergencyContactRelationship=max(Pt.EmergencyContactRelationship), " & _
                   " EmergencyContactPhone=max(Pt.EmergencyContactPhone), " & _
                   " EmergencyContactAddress=max(Pt.EmergencyContactAddress), " & _
                   " EmergencyContactCity=max(Pt.EmergencyContactCity), " & _
                   " EmergencyContactZip=max(Pt.EmergencyContactZip), " & _
                   " EmergencyContactState=max(Pt.EmergencyContactState), " & _
                   " EmployerName=max(Pt.EmployerName), " & _
                   " EmploymentStatus=max(Pt.EmploymentStatus), " & _
                   " EmployerAddressLine1=max(Pt.EmployerAddressLine1), " & _
                   " EmployerAddressLine2=max(Pt.EmployerAddressLine2), " & _
                   " EmployerPhoneNumber=max(Pt.EmployerPhoneNumber), " & _
                   " EmployerCity=max(Pt.EmployerCity), " & _
                   " EmployerZip=max(Pt.EmployerZip), " & _
                   " EmployerState=max(Pt.EmployerState), " & _
                   " ResponsibleName=max(Pt.ResponsibleName), " & _
                   " ResponsibleRelationship=max(Pt.ResponsibleRelationship), " & _
                   " ResponsibleHomePhone=max(Pt.ResponsibleHomePhone), " & _
                   " ResponsibleWorkPhone=max(Pt.ResponsibleWorkPhone), " & _
                   " ResponsibleAddress=max(Pt.ResponsibleAddress), " & _
                   " ResponsibleSSN=max(Pt.ResponsibleSSN), " & _
                   " ResponsibleCity=max(Pt.ResponsibleCity), " & _
                   " ResponsibleState=max(Pt.ResponsibleState), " & _
                   " ResponsibleZip=max(Pt.ResponsibleZip), " & _
                   " NCPDPID2=max(Pt.NCPDPID2), " & _
                   " PharmacyName2=max(Pt.PharmacyName2), " & _
                   " PharmacyProvider2=max(Pt.PharmacyProvider2), " & _
                   " EmergencyContactName2=max(Pt.EmergencyContactName2), " & _
                   " EmergencyContactRelationship2=max(Pt.EmergencyContactRelationship2), " & _
                   " EmergencyContactPhone2=max(Pt.EmergencyContactPhone2), " & _
                   " PreferredHomePh=max(Pt.PreferredHomePh), " & _
                   " PreferredWorkPh=max(Pt.PreferredWorkPh), " & _
                   " PreferredCellPh=max(Pt.PreferredCellPh), " & _
                   " EmployeeDesignation=max(Pt.EmployeeDesignation), " & _
                          " PatientName=''," & _
                          " ClinicId=max(Cl.ClinicId)," & _
                          " ClinicName=max(Cl.ClinicName)," & _
                           " ClAddressLine1=max(Cl.AddressLine1)," & _
                          " ClAddressLine2=max(Cl.AddressLine2)," & _
                          " ClCity=max(Cl.City)," & _
                          " ClStateId=max(Cl.StateId)," & _
                          " ClZipCode=max(Cl.ZipCode)," & _
                          " ClFax=max(Cl.Fax)," & _
                          " ClEmail=max(Cl.Email), " & _
                          " Phone1=max(Cl.Phone1)," & _
                          " Phone2=max(Cl.Phone2)," & _
                          " NPI=max(Cl.NPI)," & _
                          " FacilityCode=max(Cl.FacilityCode)," & _
                          " ShowQuestion=max(Cl.ShowQuestion)," & _
                          " FacilityId=max(Cl.FacilityId) " & _
                          "from PatientLedger PL, Patient Pt, [state],(SELECT Top 1 [ClinicId] " & _
                                              ",[ClinicName]  ,[AddressLine1] ,[AddressLine2] ,[City]," & _
                  "  StateId = [State].[Abbr]" & _
                                               ",[ZipCode]  " & _
                                              " ,[Phone1] ,[Phone2] ,[Fax] ,[Email] " & _
                                                ",[NPI] ,[FacilityCode] ,[ShowQuestion] ,[FacilityId]   " & _
"FROM ClinicInfo, [State] where ClinicInfo.StateId=[state].Stateid) Cl  where Pl.PatientID= '" & lPatientId & "'" & _
 "And [Date] <'" & lFromDate & "' and Pt.PatientID*=Pl.PatientID and Pt.StateID*=[state].StateID and Pt.PatientID='" & lPatientId & "'" & _
                  " union all " & _
             "Select " & _
            "PL.PatientID as PlPatientId," & _
            "PL.LineID,PL.ReferenceID,ReferenceDate," & _
            "PL.ReferenceID2," & _
            "PL.ReferenceDate2," & _
            "convert(varchar(20),PL.ReferenceDisplayID,101) as ReferenceDisplayID, " & _
            "PL.ReferenceDisplayDate, " & _
            "PL.ReferenceDisplayID2, " & _
            "PL.TransactionType, " & _
            "PL.Reference, " & _
            "PL.[Date] as [Date]," & _
            "Case When PL.TransactionType = 'V' Then (PL.[Description] + ' : ' + PL.Reference) Else PL.[Description] End As [Description] , " & _
            "PL.PaymentMethod, " & _
            "PL.PayerName, " & _
            "PL.PayerType, " & _
            "PL.Debit, " & _
            "PL.Credit, " & _
            "PL.Adjustment, " & _
            "PL.ChequeNumber, " & _
            "ChequeDate=CASE WHEN TransactionType = 'V' THEN ReferenceDate WHEN TransactionType = 'P' THEN ReferenceDate2   WHEN TransactionType = 'A' and ReferenceDate2 = '1900-01-01 00:00:00'  THEN ReferenceDate  else ReferenceDate2 	END, " & _
                    "Pt.PatientID, " & _
                   " Pt.Title, " & _
                   " Pt.FirstName, " & _
                   " Pt.MiddleName, " & _
                   " Pt.LastName, " & _
                     "Pt.AddressLine1 as PtAddressLine1, Pt.AddressLine2 as PtAddressLine2," & _
                   " Pt.City, " & _
                   " Pt.StateID, " & _
                   "Pt.ZipCode, " & _
                   " Pt.ZipCode, " & _
                   " Pt.HousePhone, " & _
                   " Pt.WorkPhone, " & _
                   " Pt.WorkPhoneExtension, " & _
                     "Pt.Fax as PtFax,Pt.Email as PtEmail," & _
                   " Pt.Occupation, " & _
                   " Pt.DOB, " & _
                   " Pt.Gender, " & _
                   " Pt.InsuranceID, " & _
                   " Pt.InsuranceName, " & _
                   "Pt.NcpdpID, " & _
                   " Pt.PharmacyName, " & _
                   " Pt.IsDeleted, " & _
                   " Pt.PictureFilePath, " & _
                   " Pt.SSN, " & _
                   " Pt.PharmacyProvider, " & _
                   " Pt.MartialStatus, " & _
                   "Pt.CellPhoneNumber, " & _
                   " Pt.EmergencyContactName, " & _
                   " Pt.EmergencyContactRelationship, " & _
                   " Pt.EmergencyContactPhone, " & _
                   " Pt.EmergencyContactAddress, " & _
                   " Pt.EmergencyContactCity, " & _
                   "Pt.EmergencyContactZip, " & _
                   "Pt.EmergencyContactState, " & _
                   " Pt.EmployerName, " & _
                   " Pt.EmploymentStatus, " & _
                   " Pt.EmployerAddressLine1, " & _
                   " Pt.EmployerAddressLine2, " & _
                   " Pt.EmployerPhoneNumber, " & _
                   " Pt.EmployerCity, " & _
                   " Pt.EmployerZip, " & _
                   " Pt.EmployerState, " & _
                   "Pt.ResponsibleName, " & _
                   " Pt.ResponsibleRelationship, " & _
                   " Pt.ResponsibleHomePhone, " & _
                   " Pt.ResponsibleWorkPhone, " & _
                   " Pt.ResponsibleAddress, " & _
                   " Pt.ResponsibleSSN, " & _
                   " Pt.ResponsibleCity, " & _
                   "Pt.ResponsibleState, " & _
                   " Pt.ResponsibleZip, " & _
                   " Pt.NCPDPID2, " & _
                   " Pt.PharmacyName2, " & _
                   "Pt.PharmacyProvider2, " & _
                   " Pt.EmergencyContactName2, " & _
                   " Pt.EmergencyContactRelationship2, " & _
                   "Pt.EmergencyContactPhone2, " & _
                   "Pt.PreferredHomePh, " & _
                   "Pt.PreferredWorkPh, " & _
                   "Pt.PreferredCellPh, " & _
                   " Pt.EmployeeDesignation, " & _
                   "Pt.FirstName + ', ' + Pt.LastName + ' ' + Pt.MiddleName As PatientName," & _
            "Cl.ClinicId," & _
            "Cl.ClinicName," & _
            "Cl.AddressLine1 as ClAddressLine1," & _
            "Cl.AddressLine2 as ClAddressLine2," & _
            "Cl.City as ClCity," & _
            "ClStateId=Cl.StateId," & _
            "Cl.ZipCode as ClZipCode," & _
            "Cl.Fax as ClFax," & _
            "Cl.Email as ClEmail, " & _
            "Cl.Phone1," & _
            "Cl.Phone2," & _
            "Cl.NPI," & _
            "Cl.FacilityCode," & _
            "Cl.ShowQuestion," & _
            "Cl.FacilityId " & _
            "from PatientLedger PL inner join Patient Pt on " & _
            " PL.PatientID = Pt.PatientID,(SELECT Top 1 [ClinicId]" & _
     " ,[ClinicName] " & _
     " ,[AddressLine1]" & _
     " ,[AddressLine2]" & _
     " ,[City]" & _
 ",StateId=[State].[Abbr]" & _
    "  ,[ZipCode]" & _
    "  ,[Phone1]" & _
     " ,[Phone2]" & _
     " ,[Fax]" & _
       " ,[Email]" & _
      "  ,[NPI]" & _
       " ,[FacilityCode]" & _
       " ,[ShowQuestion]" & _
       " ,[FacilityId]" & _
                 "FROM ClinicInfo, [State] where ClinicInfo.StateId=[state].Stateid) Cl "

                End If


                lQuery = lQuery + " where PL.PatientID='" & lPatientId & "' And " & "[Date] between '" & lFromDate & "' And '" & lToDate & "' order by PL.Date"



            Else
                Exit Sub
            End If

        End If



        lDs = lConnection.ExecuteQuery(lQuery)
        lDs.Tables(0).TableName = "NewPatientLedger"


        CrystalReportViewer1.DisplayGroupTree = True
        CrystalReportViewer1.HasCrystalLogo = False
        CrystalReportViewer1.BestFitPage = True


        myReportDocument.Load(Server.MapPath("Reports/NewPatientLedger.rpt"))
        myReportDocument.SetDataSource(lDs)







        lParameterValue.Value = lFromDate
        'lParameterValue.Value = CType("04/09/2008", Date)
        lParameterField.Name = "PFromDate"
        lParameterField.CurrentValues.Add(lParameterValue)
        lParameterFields.Add(lParameterField)

        lParameterField = New ParameterField()
        lParameterValue = New ParameterDiscreteValue()

        lParameterValue.Value = lToDate
        'lParameterValue.Value = CType("04/09/2008", Date)
        lParameterField.Name = "PToDate"
        lParameterField.CurrentValues.Add(lParameterValue)
        lParameterFields.Add(lParameterField)

        

        CrystalReportViewer1.ParameterFieldInfo = lParameterFields






        Response.ClearContent()
        Response.ClearHeaders()
        Response.ContentType = "application/pdf"
        Session.Add("ReportDocument", myReportDocument)

        myReportDocument.ExportToHttpResponse(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat, Response, False, "")
        Response.Flush()
        Response.Close()





        ' CrystalReportViewer1.PrintMode = CrystalDecisions.Web.PrintMode.ActiveX
        'CrystalReportViewer1.ReportSource = myReportDocument
        'CrystalReportViewer1.DataBind()
    End Sub

    Public Sub ViewPdf(ByVal pPdfPath As String)
        Dim lClient As System.Net.WebClient = New System.Net.WebClient()
        Dim lBuffer As Byte() = lClient.DownloadData(pPdfPath)

        If (lBuffer IsNot Nothing) Then
            Response.ContentType = "application/pdf"
            Response.AddHeader("content-length", lBuffer.Length.ToString())
            Response.BinaryWrite(lBuffer)
        End If


    End Sub


    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload

        If Session("ReportDocument") IsNot Nothing Then
            Dim myReportDocument As ReportDocument
            myReportDocument = CType(Session("ReportDocument"), ReportDocument)
            myReportDocument.Close()
            myReportDocument.Dispose()
            Session.Remove("ReportDocument")
            CrystalReportViewer1.Dispose()
            CrystalReportViewer1 = Nothing
        End If
    End Sub
End Class
