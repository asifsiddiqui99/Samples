Imports System.Collections.Generic
Imports Telerik.WebControls
Imports BillingReportMethod
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared

Partial Class Billing_MonthlyTransDetail
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


        If (Page.IsPostBack) Then
            LoadReport("12/6/2010", "12/6/2009")
        End If
    End Sub

  

    Public Sub LoadReport(ByVal pCurrentYr As String, ByVal pLastYr As String)

        Dim lDs As New DataSet()
        Dim myReportDocument As New ReportDocument()
        Dim lUser As User = CType(HttpContext.Current.Session("User"), User)
        Dim lConnection As New Connection(lUser.ConnectionString)
        Dim lClinic As New Clinic(lUser.ConnectionString)
        Dim clinicTbl As DataTable
        Dim lDs2 As New DataSet()

        Try
            lDs2 = lClinic.GetClinicInfoForReports(lUser.ClinicId)
            lDs = GetMonthlyTransDetail("12/6/2010", "12/6/2009")
            lDs2.Tables(0).TableName = "ClinicInfo"
            clinicTbl = New DataTable("ClinicInfo")
            clinicTbl = lDs2.Tables(0).Copy()
            lDs.Tables.Add(clinicTbl)
            lDs.Tables(1).TableName = "ClinicInfo"
            lDs.Tables(0).TableName = "MonthlyTransDetail"

            myReportDocument.Load(Server.MapPath("Reports/MonthlyDailyTransDetailReport.rpt"))
            If lDs.Tables(0).Rows.Count > 0 Then
                myReportDocument.SetDataSource(lDs)
                Me.crvMonthlyTransDetail.ReportSource = myReportDocument
                Session.Add("ReportDocument", myReportDocument)
                Me.crvMonthlyTransDetail.Zoom(125)
                Me.crvMonthlyTransDetail.BestFitPage = False
                Me.crvMonthlyTransDetail.DisplayGroupTree = False
                Me.crvMonthlyTransDetail.HasViewList = False
                Me.crvMonthlyTransDetail.HasDrillUpButton = False
                Me.crvMonthlyTransDetail.HasZoomFactorList = False
                Me.crvMonthlyTransDetail.HasExportButton = False
                Me.crvMonthlyTransDetail.HasSearchButton = False
                Me.crvMonthlyTransDetail.HasPageNavigationButtons = True
                Me.crvMonthlyTransDetail.HasToggleGroupTreeButton = False
                Me.crvMonthlyTransDetail.HasCrystalLogo = False
                Me.crvMonthlyTransDetail.HasDrillUpButton = False
                Me.crvMonthlyTransDetail.HasGotoPageButton = False
                Me.crvMonthlyTransDetail.EnableDrillDown = True
                Me.crvMonthlyTransDetail.Width = New Unit("100%")
                Me.crvMonthlyTransDetail.Height = New Unit("1500")
                Me.crvMonthlyTransDetail.DataBind()
                Me.crvMonthlyTransDetail.PrintMode = CrystalDecisions.Web.PrintMode.ActiveX

            End If

        Catch ex As Exception

        End Try

    End Sub


    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload
        Try
            Dim myReportDocument As ReportDocument
            If Session("ReportDocument") IsNot Nothing Then
                myReportDocument = CType(Session("ReportDocument"), ReportDocument)
                myReportDocument.Close()
                myReportDocument.Dispose()
                Session.Remove("ReportDocument")
            End If
        Catch ex As Exception
            Response.Write("<script>alert('Error Generating Report, Contact your System administrator');</script>")
            Return
        End Try
    End Sub

    Protected Sub ibtnGenerateReport_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ibtnGenerateReport.Click
        Try
            LoadReport("12/6/2010", "12/6/2009")
        Catch ex As Exception
        End Try

    End Sub
End Class
