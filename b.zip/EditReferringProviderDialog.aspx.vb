
Partial Class Billing_EditReferringProviderDialog
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim lUser As User

        lUser = CType(Session.Item("User"), User)

        Dim lHCFADBUpdated As HCFADBUpdated



        If IsPostBack = False Then
            Try
                If (Session("HCFADBUpdated") Is Nothing) Then
                    Exit Sub
                Else

                    lHCFADBUpdated = CType(Session("HCFADBUpdated"), HCFADBUpdated)
                    Me.txtRefPvdId.Text = lHCFADBUpdated.ReferencePvd.ProviderID
                End If


            Catch ex As Exception

                Return
            End Try

            '********* Load Authorized Tabs Only ***********
            FacilityMethods.LoadFacilityNameCombo(Me.cmbFacility, lUser.ConnectionString)
            StateMethods.Load_States(Me.cmbState, lUser)
            LoadRProviderFromSession(lHCFADBUpdated.ReferencePvd)

        End If

       


    End Sub

    Private Function LoadRProviderFromSession(ByVal pRefPvd As ReferringProviderDB)
        Dim lUser As User

        lUser = CType(Session.Item("User"), User)
        Dim lds As New DataSet
        Dim lState, lfacility As String


        With pRefPvd
            txtLastName.Text = .LastName
            txtFirstName.Text = .FirstName
            txtMiddleName.Text = .MiddleName
            cmbState.SelectedIndex = cmbState.FindItemIndexByText(.State)
            txtAddressLine1.Text = .AddressLine1
            txtAddressLine2.Text = .AddressLine2
            txtCity.Text = .City
            lState = .State

            If (lState <> "") Then
                StateMethods.Load_States(cmbState, lUser)
                cmbState.SelectedIndex = cmbState.FindItemIndexByText(.State)
            End If

            mtbZipCode.Text = .ZipCode
            mtbWorkPhone.Text = .WorkPhone
            mtbFax.Text = .Fax
            txtEmail.Text = .Email
            txtNPI.Text = .NPI
            mtbWorkPhoneExtension.Text = .Ext
            lfacility = .Facility

            If (lfacility <> 0) Then
                FacilityMethods.LoadFacilityNameCombo(cmbFacility, "")
                cmbFacility.SelectedIndex = cmbFacility.FindItemIndexByValue(.Facility)
            End If

            txtSpeciality.Text = .Speciality
            txtDegree.Text = .Degree
        End With
    End Function
    Protected Sub cmbState_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbState.ItemsRequested
        Dim lUser As User

        lUser = CType(Session.Item("User"), User)

        Dim lCond As String
        lCond = "And Abbr Like '" & Utility.AdjustApostrophie(e.Text) & "%' "

        If (e.Text = "") Then
            Exit Sub
        End If


        StateMethods.Load_States(cmbState, lUser, lCond)

    End Sub

   

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSave.Click
        Dim lUser As User
        Dim lHCFADBUpdated As HCFADBUpdated
        lHCFADBUpdated = CType(Session("HCFADBUpdated"), HCFADBUpdated)
        Dim lReferringProvider As New ReferringProviderDB
        Try
            If (ReferringMethods.CheckExistEdit(txtNPI.Text, Me.txtRefPvdId.Text)) Then
                Me.RadAjaxManager1.Alert("Different Referring Provider With Same NPI Already Exists")
            Else
                lUser = CType(Session.Item("User"), User)


                With lReferringProvider

                    .LastName = Utility.AdjustApostrophie(txtLastName.Text)
                    .FirstName = Utility.AdjustApostrophie(txtFirstName.Text)
                    .MiddleName = Utility.AdjustApostrophie(txtMiddleName.Text)
                    .State = cmbState.Text
                    .AddressLine1 = Utility.AdjustApostrophie(txtAddressLine1.Text)
                    .AddressLine2 = Utility.AdjustApostrophie(txtAddressLine2.Text)
                    .City = Utility.AdjustApostrophie(txtCity.Text)
                    .ZipCode = mtbZipCode.Text
                    .WorkPhone = mtbWorkPhone.Text
                    .Ext = mtbWorkPhoneExtension.Text
                    .Fax = mtbFax.Text
                    .Email = txtEmail.Text
                    .NPI = Utility.AdjustApostrophie(txtNPI.Text)
                    .Speciality = Utility.AdjustApostrophie(txtSpeciality.Text)
                    .Degree = Utility.AdjustApostrophie(txtDegree.Text)

                    If (cmbFacility.Text <> "") Then
                        .Facility = cmbFacility.Value
                    Else
                        .Facility = 0
                    End If

                    .ProviderID = Me.txtRefPvdId.Text
                End With



                ''if user hasnt selected a state.......
                If (cmbState.Text = "") Then
                    cmbState.Items.Clear()
                End If

                If (cmbFacility.Text = "") Then
                    cmbFacility.Items.Clear()
                End If
            End If





            lHCFADBUpdated.ReferencePvd = lReferringProvider
            lHCFADBUpdated.ReferencePvd.ProviderID = txtRefPvdId.Text.ToString
            Session("HCFADBUpdated") = lHCFADBUpdated
        Catch ex As Exception

        End Try
























    End Sub

    Protected Sub cmbFacility_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbFacility.ItemsRequested
        Dim lCond As String
        lCond = "And FacilityName Like '" & Utility.AdjustApostrophie(e.Text) & "%' "

        If (e.Text = "") Then
            Exit Sub
        End If

        FacilityMethods.LoadFacilityNameCombo(cmbFacility, lCond)
    End Sub
End Class
