Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports System.Security.Cryptography
Imports System.Data
Imports ElixirLibrary
Imports System.Data.SqlClient

Partial Class DailyTransactionSummary
    Inherits System.Web.UI.Page

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        Try
            If (Page.IsPostBack) Then
                LoadReport()
            End If
        Catch ex As Exception
            Response.Write("<script>alert('Error Generating Report, Contact your System administrator');</script>")
            Return
        End Try
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.crvDailyTransactionSummary.Width = New Unit("100%")
        If (Not Page.IsPostBack) Then
            dtMonth.SelectedDate = DateTime.Now
            'dtMonth.DateInput.DateFormat = "ddHHmmJ MMM yy"
        End If
        dtMonth.DateInput.DateFormat = "MMM yyyy"
        If (Me.txtHidden.Text <> "0") Then
            LoadReport()
        End If

    End Sub

    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload
        Dim myReportDocument As ReportDocument

        If Session("ReportDocument") IsNot Nothing Then
            myReportDocument = CType(Session("ReportDocument"), ReportDocument)
            myReportDocument.Close()
            myReportDocument.Dispose()
            Session.Remove("ReportDocument")
        End If
    End Sub

    Protected Sub imgView_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgView.Click

        Try
            Me.txtHidden.Text = "1"
            LoadReport()
        Catch ex As Exception
            Response.Write("<script>alert('Error Generating Report, Contact your System administrator');</script>")
            Return
        End Try
    End Sub

    Public Sub LoadReport()

        Dim myReportDocument As New ReportDocument()
        Dim lSpParameter(2) As SpParameter
        Dim lDs As New DataSet()

        Dim lUser As User = CType(HttpContext.Current.Session("User"), User)
        Dim lConnection As New Connection(lUser.ConnectionString)
        Dim lClinic As New Clinic(lUser.ConnectionString)
        Dim clinicTbl As DataTable
        Dim lDs2 As New DataSet()

        Try
            lSpParameter(0).ParameterName = "@Month"
            lSpParameter(0).ParameterType = ElixirLibrary.ParameterType.BigInt
            lSpParameter(0).ParameterValue = dtMonth.SelectedDate.GetValueOrDefault.Month.ToString()

            lSpParameter(1).ParameterName = "@Year"
            lSpParameter(1).ParameterType = ElixirLibrary.ParameterType.BigInt
            lSpParameter(1).ParameterValue = dtMonth.SelectedDate.GetValueOrDefault.Year.ToString()

            If lConnection.IsTransactionAlive() Then
                lDs = lConnection.ExecuteTransactionQuery("GetDailyVisitTransactionSummaryReport", lSpParameter)
            Else
                lDs = lConnection.ExecuteQuery("GetDailyVisitTransactionSummaryReport", lSpParameter)
            End If

            'lDs2 = lClinic.GetClinicInfoForReports(lUser.ClinicId)
            'clinicTbl = New DataTable("ClinicInfo")
            'clinicTbl = lDs2.Tables(0).Copy()
            'lDs.Tables.Add(clinicTbl)
            'lDs.Tables(1).TableName = "ClinicInfo"

            lDs2 = lClinic.GetClinicInfoForReports(lUser.ClinicId)
            lDs2.Tables(0).TableName = "ClinicInfo"
            clinicTbl = New DataTable("ClinicInfo")
            clinicTbl = lDs2.Tables(0).Copy()
            lDs.Tables.Add(clinicTbl)
            lDs.Tables(0).TableName = "DailyTransactionSummary"
            lDs.Tables(1).TableName = "ClinicInfo"

            myReportDocument.Load(Server.MapPath("Reports/DailyTransactionSummary.rpt"))
            myReportDocument.SetDataSource(lDs)

            crvDailyTransactionSummary.ReportSource = myReportDocument
            Session.Add("ReportDocument", myReportDocument)

            crvDailyTransactionSummary.Zoom(100)
            crvDailyTransactionSummary.BestFitPage = False
            crvDailyTransactionSummary.DisplayGroupTree = False
            crvDailyTransactionSummary.HasViewList = False
            crvDailyTransactionSummary.HasDrillUpButton = False
            crvDailyTransactionSummary.HasZoomFactorList = False
            crvDailyTransactionSummary.HasExportButton = False
            crvDailyTransactionSummary.HasSearchButton = False
            crvDailyTransactionSummary.HasPageNavigationButtons = False
            crvDailyTransactionSummary.HasToggleGroupTreeButton = False
            crvDailyTransactionSummary.HasCrystalLogo = False
            crvDailyTransactionSummary.HasDrillUpButton = False
            crvDailyTransactionSummary.HasGotoPageButton = False
            crvDailyTransactionSummary.Width = New Unit("100%")
            crvDailyTransactionSummary.Height = New Unit("1500")

            crvDailyTransactionSummary.DataBind()

            crvDailyTransactionSummary.PrintMode = CrystalDecisions.Web.PrintMode.ActiveX
        Catch ex As Exception
            Response.Write("<script>alert('Error Generating Report, Contact your System administrator');</script>")
            Return
        End Try
    End Sub
End Class
