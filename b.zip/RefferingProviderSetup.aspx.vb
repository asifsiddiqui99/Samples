Imports System.Data

Partial Class Billing_RefferingProviderSetup
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        tsEmployee.SelectedIndex = 0
        mpEmployee.SelectedIndex = 0
    End Sub

    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSearch.Click
        pnlGrid.Visible = True
        grdEmployee.Rebind()
    End Sub

    Protected Sub grdEmployee_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdEmployee.NeedDataSource
        Dim lUser As User
        Dim lCond As String

        lUser = CType(Session.Item("User"), User)

        lCond = "And LastName Like '" & Utility.AdjustApostrophie(cmbLastName.Text) & "%' " _
              & "And FirstName Like '" & Utility.AdjustApostrophie(cmbFirstName.Text) & "%' " _
              & "And EmployeeId Not In(Select Distinct EmployeeId From EmployeeRoleDtl Where RoleId = 4) And 1= 2 "

        EmployeeMethods.Load_EmployeeGrid(grdEmployee, lCond, lUser)
    End Sub

    Protected Sub ImgAddEmployee_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImgAddEmployee.Click
        Response.Redirect("AddRefferingProvider.aspx")
    End Sub
End Class
