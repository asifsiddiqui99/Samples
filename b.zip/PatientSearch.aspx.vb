
Partial Class Billing_PatientSearch
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim lUser As User
        'Dim lIsAuthorize As Boolean
        'Dim lUserRoles As UserRoles

        If Not Page.IsPostBack Then

            Try
                txtLastName.Focus()

                lUser = CType(Session.Item("User"), User)
                'lUserRoles = New UserRoles(lUser.ConnectionString)
                'Try
                '    '********* Check User Validity ************
                '    lIsAuthorize = lUserRoles.CheckPageAuthorization(lUser.UserId, "PatientSetup.aspx")
                '    If Not lIsAuthorize Then
                '        Response.Redirect("unauthorization.aspx", False)
                '    End If
                'Catch ex As Exception
                '    ErrorLogMethods.LogError(ex, "PatientSearch.aspx\Page_Load().CheckPageAuthorization")
                '    Response.Redirect("unauthorization.aspx", False)
                'End Try
            Catch ex As Exception
                ErrorLogMethods.LogError(ex, "PatientSearch.aspx\Page_Load()")
            End Try
            Dim lQStringParametersArray As String()
            If (Not Request.QueryString("srch") Is Nothing) Then
                lQStringParametersArray = Request.QueryString("srch").ToString.Split("|")
                If (Request.QueryString("srch").ToString <> "" And Not Page.IsPostBack) Then
                    Me.txtLastName.Text = Utility.AdjustApostrophie(Request.QueryString("srch").ToString.Split("|")(0))
                    Me.txtFirstName.Text = Utility.AdjustApostrophie(Request.QueryString("srch").ToString.Split("|")(1))
                    If (lQStringParametersArray.Length > 2) Then
                        Me.txtPatientId.Text = Utility.AdjustApostrophie(Request.QueryString("srch").ToString.Split("|")(2))

                    End If
                End If
            End If

        End If

    End Sub
    Protected Sub grdPatient_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdPatient.NeedDataSource
        grdPatient.AutoGenerateColumns = False
        'If (txtFirstName.Text <> "" Or txtLastName.Text <> "" Or txtPhone.Text <> "") Or (dpDOB.DbSelectedDate IsNot Nothing AndAlso dpDOB.DbSelectedDate <> "") Then
        LoadPatientGrid()
        'End If

    End Sub
    Private Sub LoadPatientGrid()
        Dim lUser As User
        Dim lobjPatientDb As New PatientDB
        Dim lDs As New DataSet
        Try
            lUser = CType(Session.Item("User"), User)

            If (txtLastName.Text <> "") Then
                lobjPatientDb.LastName = Utility.AdjustApostrophie(Me.txtLastName.Text)
            End If

            If (Me.txtFirstName.Text <> "") Then
                lobjPatientDb.FirstName = Utility.AdjustApostrophie(Me.txtFirstName.Text)
            End If

            If dpDOB.DbSelectedDate IsNot Nothing AndAlso dpDOB.DbSelectedDate.ToString <> "" Then
                Dim lDate() As String = dpDOB.DbSelectedDate.ToString.Split(" ")
                If (lDate(0) <> "") Then
                    lobjPatientDb.DOB = lDate(0)
                End If
            End If

            If (txtPhone.Text <> "") Then
                lobjPatientDb.HomePhone = Me.txtPhone.Text
            End If


            lDs = PatientMethods.SearchPatient(lobjPatientDb, lUser, Request.Url.AbsoluteUri.ToString)
            grdPatient.DataSource = lDs

        Catch ex As Exception
            ErrorLogMethods.LogError(ex, "PatientSearch.aspx\LoadPatientGrid()")
        End Try
        
    End Sub
    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSearch.Click
        grdPatient.Rebind()
    End Sub
    Protected Sub grdPatient_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdPatient.SelectedIndexChanged
        Dim lString As String
        Try
            lString = grdPatient.SelectedItems.Item(0).Cells(2).Text & "|" & _
                    grdPatient.SelectedItems.Item(0).Cells(4).Text & "|" & _
                    grdPatient.SelectedItems.Item(0).Cells(5).Text & "|" & _
                    grdPatient.SelectedItems.Item(0).Cells(6).Text & "|" & _
                    grdPatient.SelectedItems.Item(0).Cells(11).Text & "|" & _
                    grdPatient.SelectedItems.Item(0).Cells(9).Text & "|" & _
                     grdPatient.SelectedItems.Item(0).Cells(8).Text & "|" & _
                    grdPatient.SelectedItems.Item(0).Cells(10).Text & "|" & _
                    grdPatient.SelectedItems.Item(0).Cells(7).Text & "|" & _
                    grdPatient.SelectedItems.Item(0).Cells(12).Text & "|" & _
                    grdPatient.SelectedItems.Item(0).Cells(13).Text & "|" & _
                    grdPatient.SelectedItems.Item(0).Cells(14).Text & "|" & _
                    grdPatient.SelectedItems.Item(0).Cells(15).Text & "|" & _
                    grdPatient.SelectedItems.Item(0).Cells(16).Text & "|" & _
                    grdPatient.SelectedItems.Item(0).Cells(17).Text





            lString = lString.Replace("'", "")

            InjectScript.Text = "<script>CloseOnReload('" & lString & "')</Script>"
            'clear the session value for Ruleid's as new user is selected
            Session("PatientRulesArray") = Nothing
        Catch ex As Exception
            ErrorLogMethods.LogError(ex, "PatientSearch.aspx\grdPatient_SelectedIndexChanged()")
        End Try

      

      
    End Sub

    Protected Sub btnClose_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnClose.Click
        InjectScript.Text = "<script>CloseOnly()</Script>"
    End Sub

    Public Function FormatString(pKey As String, pValue As String)
        Dim lValue As String
        lValue = pValue

        If (pKey.Equals("ZipCode")) Then
            If (pValue.Length > 5) Then
                lValue = pValue.Insert(5, "-")
            End If
        ElseIf (pKey.Equals("HousePhone")) Then
            If (pValue.Length = 10) Then
                lValue = pValue.Insert(0, "(").Insert(4, ")-").Insert(9, "-")
            End If

        End If

        Return lValue

    End Function
End Class
