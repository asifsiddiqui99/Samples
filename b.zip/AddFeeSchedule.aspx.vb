Imports System.Collections.Generic

Partial Class AddFeeStructure
    Inherits System.Web.UI.Page


#Region "Fields"
    Dim mCPTlist As List(Of FeeSchedule)
#End Region

#Region "Events"
    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSearch.Click


        'Dim lResultXmlData As String
        Dim lDS = New DataSet
        Dim lUser = New User

        Try

            'lResultXmlData = IMOMethods.SearchCPT(txtCPT.Text)
            lUser = CType(Session("User"), User)
            lDS = IMOMethods.SearchCPT(lUser, txtCPT.Text)

            If (lDS IsNot Nothing) Then
                'Me.xmlSrcCPT.Data = lResultXmlData

                Panel1.Visible = True
                Me.grdSearchCPT.DataSource = lDS
                Me.grdSearchCPT.DataBind()
                'btnDown.Enabled = True
            Else
                Panel1.Visible = False
                grdSearchCPT.DataSource = ""
                'btnDown.Enabled = False
            End If

            If grdSearchCPT.Rows.Count > 0 Then
                Panel1.Visible = True
                lblMessage.Enabled = False
            Else
                Panel1.Visible = False
                lblMessage.Enabled = True
                lblMessage.Text = "No record(s) found for the searched CPT"
            End If
        Catch ex As Exception
            Panel1.Visible = False
            grdSearchCPT.DataSource = ""

        End Try

        btnSearch.Focus()
    End Sub

    Protected Sub cbInsurance_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cbInsurance.ItemsRequested

        Dim lDS As DataSet = Nothing

        Try
            lDS = FeeScheduleMethod.AutocompeteQueryForAddFeeSch(Session.Item("User"), e.Text)
            cbInsurance.DataSource = Nothing
            cbInsurance.DataSource = lDS
            cbInsurance.DataTextField = "CompanyName"
            cbInsurance.DataValueField = "FavouriteInsuranceID"
            cbInsurance.DataBind()


        Catch ex As Exception

        End Try


    End Sub



    Protected Sub btnDown_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnDown.Click

        Dim lDS As DataSet = Nothing
        Dim lDataTable As DataTable = Nothing
        Dim cmb As CheckBox = Nothing
        Dim cmbMod As Telerik.WebControls.RadComboBox
        Dim i As Integer = 0
        Dim lSessionDS As DataSet

        Try
            GridRetain()
            mCPTlist = New List(Of FeeSchedule)
            lDS = New DataSet
            lDataTable = New DataTable

            lDataTable.Columns.Add("CPTCode")
            lDataTable.Columns.Add("Description")
            lDataTable.Columns.Add("Fee")
            lDataTable.Columns.Add("Modifiers")


            For Each row As GridViewRow In grdSearchCPT.Rows
                cmb = CType(row.FindControl("chkItem"), CheckBox)
                cmbMod = CType(row.FindControl("cmbModifiers"), Telerik.WebControls.RadComboBox)
                If cmb.Checked = True Then
                    Dim lDatarow As DataRow
                    lDatarow = lDataTable.NewRow()
                    lDatarow("CPTCode") = row.Cells(1).Text.Trim()
                    lDatarow("Description") = row.Cells(2).Text.Replace("amp;", "")
                    lDatarow("Modifiers") = cmbMod.Text.Replace("&nbsp;", "").Replace("amp;", "")
                    lDatarow("Fee") = "0.00"
                    lDataTable.Rows.Add(lDatarow)

                End If
            Next



            If Session("DataSource") Is Nothing Then
                lDS.Tables.Add(lDataTable)
            Else
                
                lSessionDS = Session("DataSource")
                lDS.Tables.Add(lDataTable)

                For index As Integer = 0 To lSessionDS.Tables(0).Rows.Count - 1
                    If lDS.Tables(0).Select("Modifiers ='" & lSessionDS.Tables(0).Rows(index)("Modifiers").Replace("&nbsp;", "").Replace("amp;", "") & "' and CPTCode = '" & lSessionDS.Tables(0).Rows(index)("CPTCode") & "'").Length > 0 Then
                        Page.RegisterStartupScript("testscript", "<script language='javascript'>alert('One of the selected record is already in the list');</script>")
                        Return

                    End If

                    lDS.Tables(0).Rows.Add( _
                    lSessionDS.Tables(0).Rows(index)("CPTCode"), lSessionDS.Tables(0).Rows(index)("Description"), lSessionDS.Tables(0).Rows(index)("Fee"), lSessionDS.Tables(0).Rows(index)("Modifiers").ToString.Replace("&nbsp;", "").Replace("amp;", ""))
                Next
            End If


            'If Session("DataSource") IsNot Nothing Then
            '    lds = Session("DataSource")
            'End If

            pnlFeeSchedule.Visible = True
            grdFeeSchedule.DataSource = Nothing
            grdFeeSchedule.DataSource = lDS
            grdFeeSchedule.DataBind()

            Session("DataSource") = lDS


        Catch ex As Exception

        End Try


    End Sub

  

   


    'Protected Sub grdFeeSchedule_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdFeeSchedule.NeedDataSource
    '    Dim lUser As User
    '    Dim lCondition As String = ""

    '    'If IsPostBack Then
    '    CreateCondition(lCondition)

    '    lUser = CType(Session.Item("User"), User)
    '    ClaimMethods.LoadClaimGridNew(grdClaim, lCondition, lUser)
    '    'End If
    'End Sub


    Protected Sub GridView2_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles grdFeeSchedule.RowCommand

        Dim lGridViewRow As GridViewRow = Nothing
        Dim lRowIndex As Integer = 0
        Dim lDS As DataSet = Nothing
        Dim i As Integer = 0
        Dim lDataRow() As DataRow = Nothing

        Try

            If e.CommandName = "Delete" Then
                lGridViewRow = DirectCast(DirectCast(e.CommandSource, ImageButton).NamingContainer, GridViewRow)
                lRowIndex = lGridViewRow.RowIndex

                GridRetain()
                lDS = Session("DataSource")

                lDataRow = lDS.Tables(0).Select("CPTCode='" & lGridViewRow.Cells(1).Text.Replace("&nbsp;", "").Replace("amp;", "") & "' and Modifiers ='" & lGridViewRow.Cells(3).Text.Replace("&nbsp;", "").Replace("amp;", "") & "'")
                lDataRow(0).Delete()
                lDS.Tables(0).AcceptChanges()



                If lDS.Tables(0).Rows.Count = 0 Then
                    pnlFeeSchedule.Visible = False
                Else
                    pnlFeeSchedule.Visible = True


                End If
                grdFeeSchedule.DataSource = lDS
                grdFeeSchedule.DataBind()

                Session("DataSource") = lDS
                
                '' check if delete is done from filter view or ALL view
                If (txtFilterCptCode.Text <> "" Or txtFilterCptDesc.Text <> "") Then
                    FilterGrid()
                Else
                    grdFeeSchedule.DataSource = lDS
                    grdFeeSchedule.DataBind()
                End If

            End If

        Catch ex As Exception

        End Try

    End Sub


    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSave.Click
        lblMessage.Text = ""
        Dim lUser As User = Nothing
        Dim lFeeSchedule As FeeSchedule = Nothing
        Dim lGrid As New GridView
        GridRetain()
        lGrid.DataSource = Session("DataSource")
        lGrid.DataBind()
        Session("FeeScheduleID") = Nothing
        Try

            If cbInsurance.Text.Equals("") Or cbInsurance.Text = "Select Insurance Company" Then
                Page.RegisterStartupScript("testscript", "<script language='javascript'>alert('Please select an Inurance Company');</script>")
                Return
            ElseIf Session("DataSource") Is Nothing OrElse CType(Session("DataSource"), DataSet).Tables(0).Rows.Count = 0 Then
                'lblMessage.Text = "No records to add"
                Page.RegisterStartupScript("testscript", "<script language='javascript'>alert('No records to add');</script>")
                Return
            End If

            lUser = CType(Session.Item("User"), User)
            lFeeSchedule = New FeeSchedule(lUser.ConnectionString)

            Dim queryString As NameValueCollection

            If (Not Request.QueryString.Count > 0) Then
                queryString = Encryption.DecryptQueryString(Request.QueryString.ToString)

                'If Request.QueryString.Count > 0 Then
                If lFeeSchedule.InsuranceCompanyExists(Me.cbInsurance.Value, Me.cbInsurance.Text.ToUpper) > 0 Then
                    Session("FeeScheduleID") = lFeeSchedule.InsuranceCompanyExists(Me.cbInsurance.Value, Me.cbInsurance.Text.ToUpper)
                End If


                If Session("FeeScheduleID") IsNot Nothing Then

                    Response.Write("<script>alert('Fee scheduler already exists, please select some other company');</script>")
                    Return

                Else
                    FeeScheduleMethod.SaveFeeSchedules(lUser, lGrid, cbInsurance.Value, cbInsurance.Text, 0, "Save")

                    'Page.RegisterStartupScript("testscript", "<script language='javascript'>alert('Saved Successfully');window.location='FeeSchedule.aspx';</script>")


                    Response.Write("<script>alert('Saved Successfully');</script>")
                    PageExpire()
                    Response.Write("<script>location.href = 'FeeSchedule.aspx';</script>")


                End If


            Else
                queryString = Encryption.DecryptQueryString(Request.QueryString.ToString)
                If FeeScheduleMethod.SaveFeeSchedules(lUser, lGrid, cbInsurance.Value, cbInsurance.Text, queryString("PID"), "Update") Then
                    'Page.RegisterStartupScript("testscript", "<script language='javascript'>alert('Updated Successfully');window.location='FeeSchedule.aspx';</script>")

                    Response.Write("<script>alert('Updated Successfully');</script>")
                    PageExpire()
                    Response.Write("<script>location.href = 'FeeSchedule.aspx';</script>")

                Else

                    Page.RegisterStartupScript("testscript", "<script language='javascript'>alert('Update Unsuccessful');</script>")

                End If
            End If



                Session("DataSource") = Nothing



        Catch ex As Exception

        End Try
    End Sub
#End Region


#Region "Page Load"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim lUser As User = Nothing
        lblMessage.Text = ""

        Try

       
            If Not IsPostBack Then
                cbInsurance.Focus()
                lUser = CType(Session.Item("User"), User)
                Dim lFeeScheduleDAL As New FeeSchedule(lUser.ConnectionString)
                cbInsurance.DataSource = FeeScheduleMethod.GetFavouriteInsurance(lUser)
                cbInsurance.DataTextField = "CompanyName"
                cbInsurance.DataValueField = "FavouriteInsuranceID"
                cbInsurance.DataBind()
                Dim cbItem As New Telerik.WebControls.RadComboBoxItem
                cbItem.Value = "0"
                cbItem.Text = "Select Insurance Company"
                cbInsurance.Items.Insert(0, cbItem)
                ImgBtnPrnt.Enabled = False
                Me.ImgBtnExport.Enabled = False
                ImgBtnPrnt.ImageUrl = "../Imgbutton/disableprinterfriendly.gif"
                ImgBtnExport.ImageUrl = "../Imgbutton/export-disable.gif"
                Dim queryString As NameValueCollection

                If (Request.QueryString.Count > 0) Then
                    queryString = Encryption.DecryptQueryString(Request.QueryString.ToString)
                    pnlFeeSchedule.Visible = True
                    grdFeeSchedule.DataSource = FeeScheduleMethod.GetFeeSchedule(lUser, queryString("PID"))
                    grdFeeSchedule.DataBind()
                    Session("DataSource") = grdFeeSchedule.DataSource
                    'Session("Fees") = grdFeeSchedule

                    cbInsurance.Text = Session("sCompanyName")
                    cbInsurance.Value = lFeeScheduleDAL.GetFavIDByHdrID(queryString("PID"))
                    cbInsurance.Enabled = False
                    ImgBtnPrnt.Enabled = True
                    Me.ImgBtnExport.Enabled = True
                    ImgBtnPrnt.ImageUrl = "../Imgbutton/btnprintfriver-off.gif"
                    ImgBtnExport.ImageUrl = "../Imgbutton/export-off.gif"
                Else
                    Session("DataSource") = Nothing
                End If


            End If
        Catch ex As Exception

        End Try

        Me.btnCancel.OnClientClick = "javascript:window.history.go(-1);return false;"
    End Sub

  
#End Region

    'Protected Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnCancel.Click
    '    Response.Redirect("FeeSchedule.aspx")
    'End Sub

    Protected Sub grdFeeSchedule_RowDeleting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewDeleteEventArgs) Handles grdFeeSchedule.RowDeleting
        'NO IMPLEMENTATION. DO NOT REMOVE
    End Sub

    Protected Sub btnAddInsurance_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim lUser As User
        Dim lGrid As New GridView
        GridRetain()
        lGrid.DataSource = Session("DataSource")
        lGrid.DataBind()
        Dim lFeeSchedule As FeeSchedule = Nothing
        Try
            lUser = Session("User")
            lFeeSchedule = New FeeSchedule(lUser.ConnectionString)
            If lFeeSchedule.InsuranceCompanyExists(Me.cbInsurance.Value, Me.cbInsurance.Text.ToUpper) > 0 Then
                Response.Write("<script>alert('Fee scheduler already exists, please select some other company');</script>")
                Return
            End If

            grdFeeSchedule.Columns(0).Visible = False
            If FeeScheduleMethod.SaveFeeSchedules(lUser, lGrid, cbInsurance.SelectedItem.Value, cbInsurance.SelectedItem.Text, Session("FeeScheduleID"), "Update") Then

                'Page.RegisterStartupScript("testscript", "<script language='javascript'>alert('Saved Successfully');window.location='FeeSchedule.aspx';</script>")

                Response.Write("<script>alert('Saved Successfully');</script>")
                PageExpire()

                Response.Write("<script>location.href = 'FeeSchedule.aspx';</script>")

            Else
                Page.RegisterStartupScript("testscript", "<script language='javascript'>alert('Save Failed');</script>")
            End If


        Catch ex As Exception

        End Try
    End Sub


    Protected Sub ImgBtnExport_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImgBtnExport.Click

        ''convert into CSV

        Response.Clear()

        Response.Buffer = True

        Response.AddHeader("content-disposition", "attachment;filename=GridViewExport.csv")

        Response.Charset = ""

        Response.ContentType = "application/text"


        GridRetain()
        grdFeeSchedule.AllowPaging = False
        grdFeeSchedule.DataSource = Session("DataSource")
        grdFeeSchedule.DataBind()



        Dim sb As New StringBuilder()

        For k As Integer = 1 To grdFeeSchedule.Columns.Count - 2



            sb.Append(grdFeeSchedule.Columns(k).HeaderText + ","c)

        Next



        sb.Append(vbCr & vbLf)
        Dim lds As DataSet = Session("DataSource")

        'For i As Integer = 0 To lds.Tables (0).Rows.Count - 1
        For i As Integer = 0 To grdFeeSchedule.Rows.Count - 1
            'For k As Integer = 0 To grdFeeSchedule.Columns.Count - 1



            sb.Append("=" & """" & grdFeeSchedule.Rows(i).Cells(1).Text.Replace("&nbsp;", "") & """" & ","c)
            sb.Append("""" & grdFeeSchedule.Rows(i).Cells(2).Text.Replace("&nbsp;", "") + """" + ","c)
            sb.Append("""" & grdFeeSchedule.Rows(i).Cells(3).Text.Replace("&nbsp;", "") + """" + ","c)

            If CType(grdFeeSchedule.Rows(i).Cells(2).FindControl("TextBox2"), TextBox).Text.Equals("") Then
                sb.Append(CType(grdFeeSchedule.Rows(i).Cells(2).FindControl("TextBox2"), TextBox).Text = "0")
            End If
            sb.Append(CType(grdFeeSchedule.Rows(i).Cells(2).FindControl("TextBox2"), TextBox).Text())

            'sb.Append(lds.Tables(0).Rows(i)(k).Text + ","c)
            'Next


            sb.Append(vbCr & vbLf)

        Next

        grdFeeSchedule.AllowPaging = True
        grdFeeSchedule.DataSource = Session("DataSource")
        grdFeeSchedule.DataBind()
        Response.Output.Write(sb.ToString())

        Response.Flush()

        Response.End()


    End Sub

    Protected Sub ImgBtnPrnt_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImgBtnPrnt.Click
        Dim lds As DataSet
        Dim lCompanyName As String = Session("sCompanyName").ToString

        Dim lScript As String = "window.open('FeeSchedulePrint.aspx?CompanyName=" & lCompanyName & "','Edit','scrollbars=yes,resizable=no,width=610,height=350, top=200, left=350');"

        Try
            lds = New DataSet
            GridRetain()
            Session("FeeSchedule") = grdFeeSchedule
            lds = Session("DataSource")
            Response.Write("<script>" & lScript & ";</script>")
        Catch ex As Exception

        End Try
    End Sub
    Public Overrides Sub VerifyRenderingInServerForm(ByVal control As Control)

    End Sub
    Public Sub GridRetain()
        Dim lDS As DataSet = Nothing
        Dim lDataTable As DataTable = Nothing
        lDS = New DataSet
        lDataTable = New DataTable
        Dim txtFee As TextBox
        Dim i As Integer
        lDS = Session("DataSource")
        lDataTable.Columns.Add("CPTCode")
        lDataTable.Columns.Add("Description")
        lDataTable.Columns.Add("Fee")
        lDataTable.Columns.Add("Modifiers")
        If Me.grdFeeSchedule.Rows.Count > 0 Then



            For Each row As GridViewRow In grdFeeSchedule.Rows

                txtFee = CType(row.FindControl("TextBox2"), TextBox)
                Dim lDatarow() As DataRow
                Dim lDatarow1 As DataRow
                lDatarow1 = lDataTable.NewRow()
                lDatarow = lDS.Tables(0).Select("CPTCode='" & row.Cells(1).Text & "' and Modifiers='" & row.Cells(3).Text.Replace("&nbsp;", "").Replace("amp;", "") & "'")
                lDatarow(0)("CPTCode") = row.Cells(1).Text.Replace("&nbsp;", "")
                lDatarow(0)("Description") = row.Cells(2).Text.Replace("&nbsp;", "")
                lDatarow(0)("Modifiers") = row.Cells(3).Text.Replace("&nbsp;", "").Replace("amp;", "")
                If txtFee.Text.Trim().Equals("") Then
                    lDatarow(0)("Fee") = "0.00"
                Else
                    lDatarow(0)("Fee") = txtFee.Text.Trim()
                End If


                lDS.Tables(0).AcceptChanges()
                'lDataTable.Rows.Add(lDatarow1)

            Next
            'For i = 0 To lDataTable.Rows.Count - 1

            '    lDS.Tables(0).Rows.Add( _
            '       lDataTable.Rows(i)("CPTCode"), lDataTable.Rows(i)("Description"), lDataTable.Rows(i)("Fee"), lDataTable.Rows(i)("Modifiers").ToString.Replace("&nbsp;", "").Replace("amp;", ""))
            'Next



            Session("DataSource") = lDS

        End If
    End Sub

    Protected Sub btnDelete_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        Dim chk As CheckBox
        Dim lds As DataSet
        lds = Session("DataSource")
        Dim lDataRow() As DataRow
        For Each row As GridViewRow In grdFeeSchedule.Rows
            chk = CType(row.FindControl("chkFeeItem"), CheckBox)

            If chk.Checked = True Then

                lDataRow = lds.Tables(0).Select("CPTCode='" & row.Cells(1).Text.Replace("&nbsp;", "").Replace("amp;", "") & "' and Modifiers ='" & row.Cells(3).Text.Replace("&nbsp;", "").Replace("amp;", "") & "'")
                lDataRow(0).Delete()


            End If
        Next
        lds.Tables(0).AcceptChanges()
        ' grdFeeSchedule.DataSource = lds
        'grdFeeSchedule.DataBind()

        Session("DataSource") = lds
        '' check if delete is done from filter view or ALL view
        If (txtFilterCptCode.Text <> "" Or txtFilterCptDesc.Text <> "") Then
            FilterGrid()
        Else
            grdFeeSchedule.DataSource = lds
            grdFeeSchedule.DataBind()
        End If

        If Not lds.Tables(0).Rows.Count > 0 Then
            pnlFeeSchedule.Visible = False
        Else
            pnlFeeSchedule.Visible = True
        End If

    End Sub
    Protected Sub grdFeeSchedule_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles grdFeeSchedule.PageIndexChanging
        grdFeeSchedule.PageIndex = e.NewPageIndex
        GridRetain()
        grdFeeSchedule.DataSource = Session("DataSource")
        grdFeeSchedule.DataBind()
        '' check if delete is done from filter view or ALL view
        If (txtFilterCptCode.Text <> "" Or txtFilterCptDesc.Text <> "") Then
            FilterGrid()
        Else
            grdFeeSchedule.DataSource = Session("DataSource")
            grdFeeSchedule.DataBind()
        End If
    End Sub

    Public Sub PageExpire()
        Response.Buffer = True
        Response.ExpiresAbsolute = Now.Subtract(New TimeSpan(1, 0, 0, 0))
        Response.Expires = 0
        Response.CacheControl = "no-cache"
    End Sub
    Protected Sub ibtnFilter_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ibtnFilter.Click
        FilterGrid()
    End Sub
    Protected Sub ibtnShowAll_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ibtnShowAll.Click
        ShowAll()
    End Sub
    Public Sub FilterGrid()
        Dim lDs As New DataSet
        Dim lDv As DataView
        Dim lFilter As String = ""
        GridRetain()
        If (Session("DataSource") IsNot Nothing AndAlso (txtFilterCptCode.Text <> "" Or txtFilterCptDesc.Text <> "")) Then
            lDs = CType(Session("DataSource"), DataSet)
            lDv = New DataView(lDs.Tables(0))
            If (txtFilterCptCode.Text <> "" And txtFilterCptDesc.Text <> "") Then
                lFilter = "CPTCode like '" & txtFilterCptCode.Text & "%' AND Description like '" & txtFilterCptDesc.Text & "%'"
            ElseIf (txtFilterCptCode.Text <> "" And txtFilterCptDesc.Text = "") Then
                lFilter = "CPTCode like '" & txtFilterCptCode.Text & "%'"
            ElseIf (txtFilterCptCode.Text = "" And txtFilterCptDesc.Text <> "") Then
                lFilter = "Description like '" & txtFilterCptDesc.Text & "%'"
            End If
            lDv.RowFilter = lFilter '"CPTCode like '" & txtFilterCptCode.Text & "%' OR Description like '" & txtFilterCptDesc.Text & "%'"
            grdFeeSchedule.DataSource = lDv
            grdFeeSchedule.DataBind()
        End If

    End Sub
    Public Sub ShowAll()
        txtFilterCptCode.Text = ""
        txtFilterCptDesc.Text = ""
        Dim lDs As New DataSet
        GridRetain()
        If (Session("DataSource") IsNot Nothing) Then
            lDs = CType(Session("DataSource"), DataSet)
            grdFeeSchedule.DataSource = lDs
            grdFeeSchedule.DataBind()
        End If
    End Sub

  
End Class