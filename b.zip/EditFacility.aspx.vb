Imports Telerik.WebControls
Partial Class Billing_EditFacility
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load



















        Try

      
            If (Not Page.IsPostBack) Then

                Dim lIsAuthorize As Boolean
                Dim lUser As User
                Dim lUserRoles As UserRoles

                lUser = CType(Session.Item("User"), User)
                lUserRoles = New UserRoles(lUser.ConnectionString)

                '********* Check User Validity ************
                lIsAuthorize = lUserRoles.CheckPageAuthorization(lUser.UserId, "EmployeeSetup.aspx")
                If Not lIsAuthorize Then
                    Response.Redirect("unauthorization.aspx")
                End If

                '********* Load Authorized Tabs Only ***********


                'lUserRoles.LoadUserRights(tsRxEntry, lUser.UserId, "RxEntry.aspx")
                tsFacility.SelectedIndex = 0
                mpFacility.SelectedIndex = 0
                '*********************

                LoadData()

            End If
            Me.btnCancel.OnClientClick = "javascript:window.history.go(-1);return false;"
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub btnEdit_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnEdit.Click
        Dim lUser As User
        lUser = CType(Session.Item("User"), User)


        Dim lFacility As New FacilityDB
        Dim lResult As Boolean

       

        With lFacility

            .FacilityName = Utility.AdjustApostrophie(txtFacilityName.Text)
            .NPI = Utility.AdjustApostrophie(txtNPI.Text)
            .AddressLine1 = Utility.AdjustApostrophie(txtAddressLine1.Text)
            .AddressLine2 = Utility.AdjustApostrophie(txtAddressLine2.Text)
            .City = Utility.AdjustApostrophie(txtCity.Text)
            .ZipCode = mtbZipCode.Text
            .Phone = mtbHomePhone.Text
            .Fax = mtbFax.Text
            .State = cmbState.Text
            .FacilityID = ViewState("FacilityID")
            .FacilityCode = txtFacilityCode.Text

        End With

        lResult = FacilityMethods.EditFacility(lFacility)

        If (lResult = True) Then
            'Me.RadAjaxManager1.Alert("Facility Updated Successfully")
            'Me.RadAjaxManager1.Redirect("FacilitySetup.aspx")
            'lblMessage.Text = "Facility Updated Successfully"

            Response.Write("<script>alert('Facility Updated Successfully');</script>")
            PageExpire()

            Response.Write("<script>location.href = 'FacilitySetup.aspx';</script>")

        End If

        ''if user hasnt selected a state.......
        If (cmbState.Text = "") Then
            cmbState.Items.Clear()
        End If


    End Sub

    Private Sub LoadData()


        Dim queryString As NameValueCollection
        Try
            If (Request.QueryString Is Nothing) Then
                Exit Sub
            Else
                queryString = Encryption.DecryptQueryString(Request.QueryString.ToString())
                ViewState("FacilityID") = queryString("FacilityID")

            End If


        Catch ex As Exception
            ErrorLogMethods.LogError(ex, "EditFacility.aspx\Encryption.DecryptQueryString(Request.QueryString.ToString())")
            Return
        End Try



        Dim lUser As User
        lUser = CType(Session.Item("User"), User)
        Dim lState As String

        Dim lDs As New DataSet

        lDs = FacilityMethods.GetAllRecords(ViewState("FacilityID"))


        If (lDs.Tables(0).Rows.Count <> 0) Then
            With lDs.Tables(0).Rows(0)
                txtFacilityName.Text = .Item("FacilityName")
                txtNPI.Text = .Item("NPI")
                txtAddressLine1.Text = .Item("AddressLine1")
                txtAddressLine2.Text = .Item("AddressLine2")
                txtCity.Text = .Item("City")
                txtFacilityCode.Text = .Item("FacilityCode")

                mtbHomePhone.Text = .Item("Phone")
                mtbFax.Text = .Item("Fax")
                lState = .Item("State")

                ''for drop down loading and selection.......
                If (lState <> "") Then
                    StateMethods.Load_States(cmbState, lUser)
                    cmbState.SelectedIndex = cmbState.FindItemIndexByText(.Item("State"))
                End If

                mtbZipCode.Text = .Item("ZipCode")
            End With
        End If



    End Sub

    'Protected Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnCancel.Click
    '    Response.Redirect("FacilitySetup.aspx")
    'End Sub

    Protected Sub cmbState_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbState.ItemsRequested
        Dim lUser As User
        lUser = CType(Session.Item("User"), User)

        Dim lCond As String
        lCond = "And Abbr Like '" & Utility.AdjustApostrophie(e.Text) & "%' "

        If (e.Text = "") Then
            Exit Sub
        End If

        StateMethods.Load_States(cmbState, lUser, lCond)
    End Sub

    Public Sub PageExpire()
        Response.Buffer = True
        Response.ExpiresAbsolute = Now.Subtract(New TimeSpan(1, 0, 0, 0))
        Response.Expires = 0
        Response.CacheControl = "no-cache"
    End Sub
End Class
