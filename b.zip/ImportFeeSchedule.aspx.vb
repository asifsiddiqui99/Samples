Imports System.IO
Partial Class Billing_ImportFeeSchedule
    Inherits System.Web.UI.Page

    Protected Sub btnUpdate_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnUpdate.Click
        Dim lUser As User = CType(Session("User"), User)
        Dim lFilename As String = lUser.FirstName & lUser.ClinicId & Date.Now.ToString("ddMMyyyyHHmmss")
        ViewState("FileName") = lFilename
        If (fupload.HasFile) Then
            fupload.SaveAs(ConfigurationSettings.AppSettings("ImportPath").ToString & lFilename & ".txt")
        End If
        lbError.Visible = False
        'If cmbInsuranceCompany.SelectedIndex = -1 Then
        '    lblComboError.Text = "*"
        '    lblComboError.Visible = True
        'Else
        Import()
        'End If


    End Sub

    Public Sub Import()
        Dim lUser As User = CType(Session("User"), User)
        Dim lFilename As String = ViewState("FileName").ToString
        Dim lNotFound As Boolean = False
        Dim filePath As String = ConfigurationSettings.AppSettings("ImportPath").ToString & lFilename & ".txt"
        Dim line As String
        Dim XmlDoc As XmlDocument
        Dim lNode As XmlElement
        Dim lModifiers As String
        Dim lLineNumber As Integer = 0
        Dim lLocality As String
        Dim lType As String = "Medicare"
        Dim lint As Integer = 0
        Dim isLogged As Boolean = False
        Dim lStringBuilder As New StringBuilder
        Dim CPTCode As String
        Dim lConnection As Connection

        If File.Exists(filePath) Then

            Dim file__1 As IO.StreamReader = Nothing
            Try
                file__1 = New IO.StreamReader(filePath)
                XmlDoc = New XmlDocument
                XmlDoc.LoadXml("<FeeSchedules FavInsuranceId='" & cmbInsuranceCompany.Value & "' CompanyName='" & cmbInsuranceCompany.Text.Replace("&", "&amp;") & "' CreateDate='" & Date.Now() & "' ModifiedDate='" & Date.Now() & "' > </FeeSchedules>")
                While (file__1.Peek() <> -1)
                    lLineNumber += 1
                    line = file__1.ReadLine()
                    Dim splitLine() As String
                    If Not line Is Nothing Then
                        splitLine = line.Split(",")
                    End If
                    If lint = 2 Then
                        lint = 0
                    End If


                    If Not splitLine.Length < 10 Then

                        lNode = XmlDoc.CreateElement("FeeSchedule")
                        lLocality = splitLine(2).ToString.Replace("""", "")

                        lModifiers = splitLine(4).ToString.Replace("""", "")

                        CPTCode = splitLine(3).ToString.Replace("""", "")

                        If Me.SyntaxChecker(splitLine) Then

                            If lLocality = txtLocality.Text Then
                                lNotFound = True
                                lNode.SetAttribute("Locality", lLocality)
                                lNode.SetAttribute("CPTCode", CPTCode)
                                If lModifiers.Equals(",,") Then
                                    lModifiers = "NULL"     'if Modifirs is empty then it put NULL as a string
                                End If
                                lNode.SetAttribute("Modifiers", lModifiers)
                                lNode.SetAttribute("Description", "")
                                lNode.SetAttribute("Fee", splitLine(5).ToString.Replace("""", ""))
                                XmlDoc.DocumentElement.AppendChild(lNode)

                                'Check the Dublicate 
                                lint = XmlDoc.DocumentElement.SelectNodes("//FeeSchedule[@Locality= '" & lLocality & "' and @CPTCode='" & CPTCode & "' and @Modifiers ='" & lModifiers & "']").Count

                                If lint > 1 Then
                                    lStringBuilder.AppendLine("Error on Line " & lLineNumber & ":" & line)    'Add line for Loggin purpose
                                    isLogged = True
                                End If

                            End If

                        Else
                            If Not (line.StartsWith("""TRL-")) Then
                                lStringBuilder.AppendLine("Error on Line " & lLineNumber & ":" & line)
                                isLogged = True
                            End If

                        End If
                    Else
                        If Not (line.StartsWith("""TRL-")) Then
                            lStringBuilder.AppendLine("Error on Line " & lLineNumber & ":" & line)
                            isLogged = True
                        End If

                    End If

                End While
                If lNotFound = False Then
                    Page.RegisterStartupScript("testscript", "<script language='javascript'>alert('Given locality not found');</script>")
                Else
                    If isLogged = False Then
                        lConnection = New Connection(lUser.ConnectionString)
                        lConnection.BeginTrans()
                        FeeScheduleMethod.DeleteFeeScheduleImport(lConnection, cmbInsuranceCompany.Value)
                        FeeScheduleMethod.SaveFeeSchedules(lConnection, XmlDoc.DocumentElement.OuterXml.ToString())
                        lConnection.CommitTrans()

                        Page.RegisterStartupScript("testscript", "<script language='javascript'>alert('Imported Successfully');window.location='FeeSchedule.aspx';</script>")

                    Else
                        'Write all Dublicate Lines on TextFile

                        File.Create(ConfigurationSettings.AppSettings("ImportLogPath").ToString & lFilename & "Log.txt").Close()

                        Dim loutFile As New StreamWriter(ConfigurationSettings.AppSettings("ImportLogPath").ToString & lFilename & "Log.txt")
                        loutFile.Write(lStringBuilder.ToString)
                        loutFile.Close()
                        lbError.Visible = True
                        Page.RegisterStartupScript("testscript", "<script language='javascript'>alert('Errors Found in the file. Please see the log file for details.');</script>")


                    End If
                End If


            Catch

                If lConnection IsNot Nothing AndAlso lConnection.IsTransactionAlive() Then
                    lConnection.RollBackTrans()

                End If

            Finally
                If file__1 IsNot Nothing Then

                    file__1.Close()

                End If

            End Try
        End If
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        rdoMed.Checked = True
        If rdoMed.Checked = True Then
            Session("Type") = "Medicare"
        End If
        '  fupload.Attributes.Add("onchange", "return checkFileExtension(this);")
        'If Not IsPostBack Then
        '    Me.cmbInsuranceCompany.DataSouce = PaymentMethods.GetPayerName("Insurance")
        '    Me.cmbInsuranceCompany.DataTextField = "CompanyName"
        '    Me.cmbInsuranceCompany.DataValueField = "FavouriteInsuranceID"
        '    Me.cmbInsuranceCompany.DataBind()
        'End If

        Me.btnCancel.OnClientClick = "javascript:window.history.go(-1);return false;"

    End Sub

    Protected Sub lbError_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lbError.Click
        Dim lUser As User = CType(Session("User"), User)
        Dim lFilename As String = ViewState("FileName").ToString
        Dim filePath As String = ConfigurationSettings.AppSettings("ImportLogPath").ToString & lFilename & "Log.txt"


        '    ' Get the physical Path of the file(test.doc) 
        filePath = Utility.AdjustApostrophie(filePath)
        '    ' Create New instance of FileInfo class to get the properties of the file being downloaded 
        Dim file As New FileInfo(filePath)

        '    ' Checking if file exists 
        If file.Exists Then
            '        ' Clear the content of the response 
            Response.ClearContent()


            '        ' LINE1: Add the file name and attachment, which will force the open/cance/save dialog to show, to the header 
            Response.AddHeader("Content-Disposition", "attachment; filename=" + file.Name)

            '        ' Add the file size into the response header 
            Response.AddHeader("Content-Length", file.Length.ToString())

            '        ' Set the ContentType 
            Response.ContentType = "text/plain"

            '        ' Write the file into the response (TransmitFile is for ASP.NET 2.0. In ASP.NET 1.1 you have to use WriteFile instead) 
            Response.TransmitFile(file.FullName)

            '        ' End the response 
            Response.[End]()
        End If


    End Sub
    Public Function SyntaxChecker(ByVal pLine() As String) As Boolean
        Dim isNum As Boolean = True

        For index As Integer = 0 To pLine.Length - 1
            If pLine(0).Length = 6 And pLine(1).Length = 7 And pLine(2).Length = 4 _
           And pLine(3).Length = 7 And pLine(4).ToString.Replace("  ", ",,").Length = 4 And pLine(5).Length = 12 _
                 And pLine(5).Length = 12 And pLine(7).Length = 3 And pLine(8).Length = 3 And pLine(9).Length = 3 Then


                If pLine(0).Replace("""", "").Length = 4 And pLine(1).Replace("""", "").Length = 5 And pLine(2).Replace("""", "").Length = 2 _
                 And pLine(3).Replace("""", "").Length = 5 And pLine(4).ToString.Replace("""", "").Replace("  ", ",,").Length = 2 And pLine(5).Replace("""", "").Length = 10 _
                       And pLine(5).Replace("""", "").Length = 10 And pLine(7).Replace("""", "").Length = 1 And pLine(8).Replace("""", "").Length = 1 And pLine(9).Replace("""", "").Length = 1 Then

                    For index1 As Integer = 0 To pLine(5).Replace("""", "").Length - 1
                        If (Not Char.IsDigit(pLine(5).Replace("""", "")(index1))) Then
                            If Not pLine(5).Replace("""", "")(index1) = "." Then
                                isNum = False
                            End If


                        End If
                    Next
                    For index1 As Integer = 0 To pLine(5).Replace("""", "").Length - 1
                        If Not Char.IsDigit(pLine(5).Replace("""", "")(index1)) Then
                            If Not pLine(5).Replace("""", "")(index1) = "." Then
                                isNum = False
                            End If

                        End If
                    Next

                    Return isNum
                Else
                    Return False

                End If
            End If
        Next

    End Function


    'Protected Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnCancel.Click
    '    Response.Redirect("FeeSchedule.aspx")
    'End Sub
End Class

