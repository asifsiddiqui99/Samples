Imports Telerik.WebControls
Partial Class Billing_PatientSearch
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim lUser As User
        'Dim lIsAuthorize As Boolean
        'Dim lUserRoles As UserRoles
        grdPatientInsurance.Visible = False
        If Not Page.IsPostBack Then
            txtLastName.Focus()
            Try
                lUser = CType(Session.Item("User"), User)
                'lUserRoles = New UserRoles(lUser.ConnectionString)
                'Try
                '    '********* Check User Validity ************
                '    lIsAuthorize = lUserRoles.CheckPageAuthorization(lUser.UserId, "PatientSetup.aspx")
                '    If Not lIsAuthorize Then
                '        Response.Redirect("unauthorization.aspx", False)
                '    End If
                'Catch ex As Exception
                '    ErrorLogMethods.LogError(ex, "PatientSearch.aspx\Page_Load().CheckPageAuthorization")
                '    Response.Redirect("unauthorization.aspx", False)
                'End Try
            Catch ex As Exception
                ErrorLogMethods.LogError(ex, "PatientSearch.aspx\Page_Load()")
            End Try

            Dim lQStringParametersArray As String() = Request.QueryString("srch").ToString.Split("|")

            If (Not Request.QueryString("srch") Is Nothing) Then
                If (Request.QueryString("srch").ToString <> "" And Not Page.IsPostBack) Then
                    Me.txtLastName.Text = Utility.AdjustApostrophie(Request.QueryString("srch").ToString.Split("|")(0))
                    Me.txtFirstName.Text = Utility.AdjustApostrophie(Request.QueryString("srch").ToString.Split("|")(1))
                    If (lQStringParametersArray.Length > 2) Then
                        Me.txtPatientId.Text = Utility.AdjustApostrophie(Request.QueryString("srch").ToString.Split("|")(2))

                    End If
                End If
            End If

        End If

    End Sub

    Protected Sub grdPatient_ItemDataBound(ByVal sender As Object, ByVal e As Telerik.WebControls.GridItemEventArgs) Handles grdPatient.ItemDataBound
        Try
            If e.Item.ItemType = GridItemType.Item Or e.Item.ItemType = GridItemType.AlternatingItem Then





                If (e.Item.Cells(10).Text <> "" And (e.Item.Cells(10).Text.Length = 9)) Then


                    e.Item.Cells(10).Text = String.Format("{0:#####-####}", Double.Parse(e.Item.Cells(10).Text))
                End If

                If (e.Item.Cells(11).Text <> "" And e.Item.Cells(11).Text.Length > 7) Then

                    e.Item.Cells(11).Text = String.Format("{0:(###) ###-####}", Int64.Parse(e.Item.Cells(11).Text))

                End If





            End If




        Catch ex As Exception
            Dim myparent As Page = Me.Page
            Dim lLogID As String
            lLogID = ErrorLogMethods.LogError(ex, "PatientSearchInsurance.aspx\Page_Load.CheckPageAuthorization")
            Response.Redirect("ErrorPage.aspx?LogID=" & lLogID, False)
        End Try
    End Sub
    Protected Sub grdPatient_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdPatient.NeedDataSource
        grdPatient.AutoGenerateColumns = False
        Dim lQStringParametersArray As String() = Request.QueryString("srch").ToString.Split("|")
        'If (lQStringParametersArray.Length > 0) Then
        If (txtFirstName.Text <> "" Or txtLastName.Text <> "" Or txtPhone.Text <> "") Or (dpDOB.DbSelectedDate IsNot Nothing AndAlso dpDOB.DbSelectedDate.ToString <> "") Then

            LoadPatientGrid()


        End If


    End Sub
    Private Sub LoadPatientGrid()
        Dim lEmptySource = New DataTable
        Dim lUser As User
        Dim lobjPatientDb As New PatientDB
        Dim lDs As New DataSet
        Try
            lUser = CType(Session.Item("User"), User)
            If (Me.txtPatientId.Text <> "") Then
                lobjPatientDb.PatientID = Utility.AdjustApostrophie(Me.txtPatientId.Text)
          
            End If

            lobjPatientDb.LastName = Utility.AdjustApostrophie(Me.txtLastName.Text)
            lobjPatientDb.FirstName = Utility.AdjustApostrophie(Me.txtFirstName.Text)


            If dpDOB.DbSelectedDate IsNot Nothing AndAlso dpDOB.DbSelectedDate.ToString <> "" Then

                Dim lDate() As String = dpDOB.DbSelectedDate.ToString.Split(" ")
                If (lDate(0) <> "") Then
                    lobjPatientDb.DOB = lDate(0)
                End If
            End If


            If (txtPhone.Text <> "") Then
                lobjPatientDb.HomePhone = Me.txtPhone.Text
            End If

            lDs = PatientMethods.SearchPatientForInsurance(lobjPatientDb, lUser, Request.Url.AbsoluteUri.ToString)
            If lDs.Tables(0).Rows.Count > 0 Then
                grdPatient.DataSource = lDs
            Else
                grdPatient.DataSource = lEmptySource
            End If
        Catch ex As Exception
            ErrorLogMethods.LogError(ex, "PatientSearch.aspx\LoadPatientGrid()")
        End Try

    End Sub

    Private Sub LoadPatientInsuranceGrid()

        Dim lEmptySource = New DataTable
        Dim lUser As User
        Dim lobjPatientInsuranceDb As New PatientInsuranceDB
        Dim lDs As New DataSet
        Try
            lUser = CType(Session.Item("User"), User)
            If (txtReturnValue.Text <> "") Then
                lobjPatientInsuranceDb.PatientID = txtReturnValue.Text.Split("|")(0)
                lDs = PatientMethods.LoadPatientInsurance(lobjPatientInsuranceDb, lUser)
                If lDs.Tables(0).Rows.Count > 0 Then
                    grdPatientInsurance.DataSource = lDs
                Else
                    grdPatientInsurance.DataSource = lEmptySource
                End If
            End If


        Catch ex As Exception
            ErrorLogMethods.LogError(ex, "PatientSearch.aspx\LoadPatientGrid()")
        End Try

    End Sub
    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSearch.Click
        Dim lEmptySource = New DataTable
        grdPatient.Rebind()
        grdPatientInsurance.Visible = False
        grdPatientInsurance.DataSource = lEmptySource

    End Sub

    Protected Sub grdPatient_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdPatient.SelectedIndexChanged
        Dim lString As String
        Try

            lString = grdPatient.SelectedItems.Item(0).Cells(2).Text & "|" & _
                    grdPatient.SelectedItems.Item(0).Cells(4).Text & "|" & _
                    grdPatient.SelectedItems.Item(0).Cells(5).Text
            lString = lString.Replace("'", "")
            txtReturnValue.Text = lString ' grdPatient.SelectedItems.Item(0).Cells(2).Text 
            grdPatientInsurance.Rebind()
            grdPatientInsurance.Visible = True
        Catch ex As Exception
            ErrorLogMethods.LogError(ex, "PatientSearch.aspx\grdPatient_SelectedIndexChanged()")
        End Try
        
        
    End Sub
    Protected Sub btnClose_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnClose.Click
        InjectScript.Text = "<script>CloseOnly()</Script>"
    End Sub
    Protected Sub grdPatientInsurance_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdPatientInsurance.NeedDataSource
        grdPatientInsurance.AutoGenerateColumns = False

        LoadPatientInsuranceGrid()


    End Sub

    Protected Sub grdPatientInsurance_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdPatientInsurance.SelectedIndexChanged
        Dim lString As String
        Dim lPatInsId As String = ""
        Dim lReturnValue As String = ""
        Try

            lString = grdPatientInsurance.SelectedItems.Item(0).Cells(10).Text
            lPatInsId = grdPatientInsurance.SelectedItems.Item(0).Cells(13).Text
            lReturnValue = txtReturnValue.Text & "|" & lString & "|" & lPatInsId
            InjectScript.Text = "<script>CloseOnReload('" & lReturnValue & "')</Script>"
        Catch ex As Exception
            ErrorLogMethods.LogError(ex, "PatientSearch.aspx\grdPatient_SelectedIndexChanged()")
        End Try

    End Sub
End Class
