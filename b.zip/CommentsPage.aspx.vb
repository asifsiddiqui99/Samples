
Partial Class Billing_CommentsPage
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnOK.Click

        Try

            Dim lineId As String = Request.QueryString("lid")
            
            Dim ltxt As String = TextBox1.Text & "|" & lineId


            lblClose.Text = "<script>CloseOnReload('" & ltxt & "')</Script>"
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub btnClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClose.Click
        lblClose.Text = "<script>CloseOnly()</Script>"
    End Sub
End Class
