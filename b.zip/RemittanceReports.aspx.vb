Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Partial Class Billing_RemittanceReports
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            LoadReport()
        Catch ex As Exception
            lblErrorMessage.Text = "Error generating report"
            lblErrorMessage.Visible = True
        End Try
    End Sub

    Public Sub LoadReport()
        Dim Rid As String = ""
        Dim queryString As NameValueCollection
        Dim lStrQS As String = ""
        Dim lStrUrl As String = ""
        Try
           
            queryString = Encryption.DecryptQueryString(Request.QueryString.ToString())
            If (Not queryString("rid") Is Nothing) Then
                Rid = queryString("rid").ToString()
                If (rdlistReport.SelectedValue.ToUpper = "S") Then
                    lStrUrl = "RemittanceReport.aspx?rid=" & Rid & "|S"
                    'lStrQS = ElixirLibrary.Encryption.EncryptQueryString("rid=" & Rid & "|S")
                ElseIf (rdlistReport.SelectedValue.ToUpper = "M") Then
                    lStrUrl = "RemittanceReport.aspx?rid=" & Rid & "|M"
                    'lStrQS = ElixirLibrary.Encryption.EncryptQueryString("rid=" & Rid & "|M")
                End If
                'lStrUrl = "RemittanceReport.aspx" & lStrQS
                fRemittanceReport.Attributes("src") = lStrUrl
            End If
        Catch ex As Exception
            lblErrorMessage.Text = "Error generating report"
            lblErrorMessage.Visible = True
        End Try
    End Sub
End Class
