Imports Telerik.WebControls

Partial Class Billing_AddSuperBill
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim lRadWindow As RadWindow
        Dim lData As String()

        ' Me.btnCPTSave.Attributes.Add("OnClick", "WriteHeadingToTextBox();")

        tsSuperBill.SelectedIndex = 0
        mpSuperBill.SelectedIndex = 0

        'Page.ClientScript.RegisterOnSubmitStatement(Me.GetType(), "beforeSubmit", "selectAllElements('" + lbHeading.ClientID + "');")


        'Dim cm As ClientScriptManager = Page.ClientScript
        'Dim cbReference As String = cm.GetCallbackEventReference(Me, "arg", "ReceiveServerData", "")
        'Dim callbackScript As String = "function CallServer(arg, context) {" + cbReference + "; }"
        'cm.RegisterClientScriptBlock(Me.GetType(), "CallServer", callbackScript, True)

       
        'If Page.IsPostBack Then
        '    If Request.Form(lbHeading.UniqueID) IsNot Nothing Then
        '        lData = Request.Form(lbHeading.UniqueID)
        '    End If
        'End If

        If Not Page.IsPostBack Then
            Session.Remove("ICD9Coll")
            Session.Remove("CPTColl")
        End If


        'rwmSuperBill.OffsetElementId = btnICDSearch.ClientID

        'lRadWindow = CType(rwmSuperBill.FindControl("rwICD9Search"), RadWindow)
        'lRadWindow.NavigateUrl = "SearchICD9.aspx"


        'rwmSuperBill.OffsetElementId = btnCPTSearch.ClientID
        'lRadWindow = CType(rwmSuperBill.FindControl("rwCPTSearch"), RadWindow)


    End Sub

    Protected Sub grdICD_DeleteCommand(ByVal source As Object, ByVal e As Telerik.WebControls.GridCommandEventArgs) Handles grdICD.DeleteCommand
        Dim lICD9Coll As ICD9Coll
        Dim lICD9DB As New ICD9DB()

        lICD9DB.Code = e.Item.Cells(3).Text
        lICD9DB.Description = e.Item.Cells(4).Text
        lICD9DB.SuperBillId = ""

        If Session("ICD9Coll") IsNot Nothing Then
            lICD9Coll = Session("ICD9Coll")
            lICD9Coll.Remove(lICD9DB)
            Session.Add("ICD9Coll", lICD9Coll)
        End If

    End Sub


    Protected Sub grdICD_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdICD.NeedDataSource

        Dim lICDColl As ICD9Coll = New ICD9Coll()

        If Session("ICD9Coll") IsNot Nothing Then
            lICDColl = Session("ICD9Coll")
        End If
        grdICD.DataSource = lICDColl

    End Sub

    Protected Sub grdCPT_DeleteCommand(ByVal source As Object, ByVal e As Telerik.WebControls.GridCommandEventArgs) Handles grdCPT.DeleteCommand
        Dim lCPTColl As CPTColl
        Dim lCPTDB As New CPTDB()
        Dim lFound As Boolean

        lCPTDB.Code = e.Item.Cells(5).Text
        lCPTDB.ShortDescription = e.Item.Cells(6).Text
        lCPTDB.SuperBillId = ""
        lCPTDB.Heading = e.Item.Cells(4).Text

        If Session("CPTColl") IsNot Nothing Then
            lCPTColl = Session("CPTColl")
            lCPTColl.Remove(lCPTDB)
            lFound = lCPTColl.CheckHeadingExistance(lCPTDB)
            If Not lFound Then
                lbHeading.Items.Remove(lCPTDB.Heading)
            End If

            Session.Add("CPTColl", lCPTColl)
        End If

    End Sub

    Protected Sub grdCPT_ItemDataBound(ByVal sender As Object, ByVal e As Telerik.WebControls.GridItemEventArgs) Handles grdCPT.ItemDataBound

        If e.Item.ItemType = GridItemType.GroupHeader Then
            e.Item.Cells(1).Text = e.Item.Cells(1).Text.Replace("Selected�Codes:", "")
        End If

    End Sub

    Protected Sub grdCPT_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdCPT.NeedDataSource
        Dim lCPTColl As CPTColl = New CPTColl()

        If Session("CPTColl") IsNot Nothing Then
            lCPTColl = Session("CPTColl")
        End If
        grdCPT.DataSource = lCPTColl
    End Sub

    Protected Sub btnICDAdd_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnICDAdd.Click
        Dim lICDColl As ICD9Coll
        Dim lICD9 As New ICD9DB()
        Dim lICDData As String()


    


        If txtICDData.Text = "" Then
            Return
        End If

        '' By Fareed to enforce Max 26 ICD Selection 12 Jan 2009 
        If grdICD.Items.Count > 29 Then
            Me.AjxMSuperBill.Alert("Number of ICDs cannot exceed 30")
            Return
        End If



        '' By Fareed to enforce Max 26 ICD Selection 12 Jan 2009 

        lICDData = txtICDData.Text.Split("|")

        lICDData = txtICDData.Text.Split("|")

        lICD9.Code = lICDData(0)
        lICD9.Description = lICDData(1)
        lICD9.SuperBillId = ""
        lICD9.IMOCode = lICDData(2)


        If Session("ICD9Coll") IsNot Nothing Then
            lICDColl = Session("ICD9Coll")
        Else
            lICDColl = New ICD9Coll
        End If

        ' If lICDColl.Count < 30 Then
        lICDColl.Add(lICD9)
        'Else
        'lblMessage1.Visible = True
        'lblMessage1.Text = "Can not add more than 30 CPTs"
        'End If




        Session.Add("ICD9Coll", lICDColl)
        txtICDData.Text = ""
        txtICD.Text = ""
        'txtICDDescription.Text = ""

        grdICD.Rebind()





    End Sub

    Protected Sub btnCPTAdd_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnCPTAdd.Click

        Dim lCPTColl As CPTColl
        Dim lCPT As New CPTDB()
        Dim lCPTData As String()


        If txtCPTData.Text = "" Then
            Me.AjxMSuperBill.Alert("Select CPT code from CPT search window")
            Return
        End If

        '' By Fareed to enforce Max 26 CPT Selection 12 Jan 2009 
        If grdCPT.Items.Count > 29 Then
            Me.AjxMSuperBill.Alert("Number of CPTs cannot exceed 30")
            Return
        End If
        '' By Fareed to enforce Max 26 ICD Selection 12 Jan 2009 
        If Utility.ChangeCase(txtCPTHeading.Text) <> "" AndAlso txtFees.Text <> "" Then

            lCPTData = txtCPTData.Text.Split("|")
            '  If lCPTData(3) <> "" Then

            lCPT.Code = lCPTData(3)
            lCPT.ShortDescription = lCPTData(1)
            lCPT.SuperBillId = ""
            lCPT.Heading = Utility.ChangeCase(txtCPTHeading.Text)
            lCPT.Fees = txtFees.Text
            lCPT.IMO = lCPTData(0)

            If Session("CPTColl") IsNot Nothing Then
                lCPTColl = Session("CPTColl")
            Else
                lCPTColl = New CPTColl
            End If


            'If lCPTColl.Count < 30 Then
            lCPTColl.Add(lCPT)
            'Else
            '    lblMessage2.Visible = True
            '    lblMessage2.Text = "Can not add more than 30 CPTs"
            'End If

            Session.Add("CPTColl", lCPTColl)

            txtCPTData.Text = ""
            txtCPT.Text = ""
            txtFees.Text = ""

            AddHeading(lCPT.Heading)

            grdCPT.Rebind()
            'Else
            '    Me.AjxMSuperBill.Alert("CPT code required")
            '    Return
            'End If
        Else
        Me.AjxMSuperBill.Alert("Heading and fees fields required")
        Return
        End If
       
    End Sub

    Private Sub AddHeading(ByVal pHeading As String)
        For Each lItem As ListItem In lbHeading.Items
            If lItem.Text.ToUpper = pHeading.ToUpper Then
                Return
            End If
        Next
        lbHeading.Items.Add(pHeading)
    End Sub


    Protected Sub btnICDSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnICDSearch.Click
        'AjxMSuperBill.ResponseScripts.Add("window.radopen('SearchICD9.aspx?dsc=" & Server.UrlEncode(txtICDDescription.Text) & "&icd=" & txtICD.Text & "','rwICD9Search');")
        AjxMSuperBill.ResponseScripts.Add("window.radopen('SearchICD9.aspx?icd=" & Server.UrlEncode(txtICD.Text) & "','rwICD9Search');")
        tsSuperBill.SelectedIndex = 1
        mpSuperBill.SelectedIndex = 1
    End Sub

    Protected Sub btnCPTSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnCPTSearch.Click

        AjxMSuperBill.ResponseScripts.Add("window.radopen('SearchCPT.aspx?cpt=" & Server.UrlEncode(txtCPT.Text) & "','rwCPTSearch');")
        tsSuperBill.SelectedIndex = 2
        mpSuperBill.SelectedIndex = 2
    End Sub



    Private Function SaveSuperBill() As Boolean

        Dim lUser As User
        lUser = CType(Session.Item("User"), User)


        Dim lSuperBillDB As New SuperBillDB()
        Dim lResult As Boolean

        With lSuperBillDB
            .SuperBillName = Utility.AdjustApostrophie(txtSuperBill.Text)
            .CPTSortBy = cmbCPTSortBy.Value
            .CPTSortOrder = cmbCPTSortOrder.Value
            .ICDSortBy = cmbICDSortBy.Value
            .ICDSortOrder = cmbICDSortOrder.Value
        End With



        lResult = SuperBillMethods.AddSuperBill(lSuperBillDB, grdCPT.Items, grdICD.Items, lbHeading, Request.Url.AbsoluteUri)

        Return lResult

    End Function

    Protected Sub btnICDSave_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnICDSave.Click, btnSuperBillSave.Click, btnCPTSave.Click
        Dim lResult As Boolean

        If grdCPT.Items.Count < 1 Or grdICD.Items.Count < 1 Then
            Me.AjxMSuperBill.Alert("Please enter at least one CPT and ICD code")
            Return
        End If


        lResult = SaveSuperBill()
        If lResult Then
            Me.AjxMSuperBill.Alert("SuperBill Added Successfully")
            Me.AjxMSuperBill.Redirect("SuperBillSetup.aspx")
            'lblMessage.Text = "SuperBill Added Successfully"
            'Response.Redirect("SuperBillSetup.aspx")
        Else
            Me.AjxMSuperBill.Alert("Error Adding SuperBill")
            'lblMessage.Text = "Error Adding SuperBill"
        End If
    End Sub

    Protected Sub btnICDCancel_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnICDCancel.Click, btnSuperBillCancel.Click, btnCPTCancel.Click
        Response.Redirect("SuperBillSetup.aspx")
    End Sub

    Protected Sub btnMoveUp_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnMoveUp.Click
        SuperBillMethods.MoveUp(lbHeading)
    End Sub

    Protected Sub btnMoveDown_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnMoveDown.Click
        SuperBillMethods.MoveDown(lbHeading)
    End Sub
End Class
