Imports System.Web.UI.HtmlControls
Imports System.Threading
Imports System.IO.Packaging

Partial Class DrSch_RxCureMaster
    Inherits System.Web.UI.MasterPage
    Shared WithEvents oDataPortable As DataPortabilityThread = New DataPortabilityThread()

    Public misRegLabs As String


    Protected Sub Page_Init(sender As Object, e As System.EventArgs) Handles Me.Init

        Dim lUser As User

        Try
            lUser = CType(Session("User"), User)

            misRegLabs = lUser.IsRegwithLabs

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim lUserRoles As New UserRoles(ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString())
        Dim lUser As User = CType(Session("User"), User)
        Dim lAskQuestion As String = ConfigurationManager.AppSettings("AskQuestion").ToString
        'mnuEpcs.Visible = lUser.IsClinicEpcs AndAlso lUser.IsEpcs
        muEPA.Visible = ConfigurationManager.AppSettings("ShowEPA").ToLower.Equals("true") AndAlso CType(Session.Item("User"), User).IsEpaEnabled
        If Not Page.IsPostBack Then
            'lUserRoles.LoadUserRights(mnuRxCure)
            lUserRoles.LoadBillingUser(mnuRxCure)

            If (mnuRxCure.FindItemByValue("mnuCreateRx").Visible.ToString.ToUpper = "TRUE" AndAlso lUser.ShowQuestion.ToUpper = "Y" AndAlso lAskQuestion.ToUpper = "TRUE") Then
                mnuRxCure.FindItemByValue("mnuSecQues").Visible = True
            End If


            If (ConfigurationManager.AppSettings("DrugFacts").ToUpper = "TRUE") Then
                mnuRxCure.FindItemByValue("mnuDrugFacts").Visible = True
            End If


            Dim lCond As String = String.Empty

            lCond = RxEntryMethods.LoadAuthorizationCombo("9", "13", "", "")

            Dim lRenewalCount As Int32 = RenewalMethods.GetPendingRenewalCount(lCond, "")
            If (lRenewalCount > 0) Then
                Me.imgQuickLink.Src = "../images/icons/quickview_blink.gif"
                Me.imgQuickLink.Alt = "You have " & lRenewalCount & " Pending Renewals "
            Else
                Me.imgQuickLink.Src = "../images/icons/quick-view1.gif"
                Me.imgQuickLink.Alt = "Quick View"
            End If

            If ConfigurationManager.AppSettings("Demo").ToUpper = "TRUE" Then
                imgDemo.Visible = True

            End If
            If ConfigurationManager.AppSettings("UnderConstruction").ToUpper = "TRUE" Then
                imgUnderConstruction.Visible = True

            End If
            If ConfigurationManager.AppSettings("IsRxHubLocalSourceRequest").ToUpper = "TRUE" Then
                imgRxHubLocalRequest.Visible = True

            End If
            If ConfigurationManager.AppSettings("SendEligibility").ToUpper = "FALSE" Then
                imgDontSendEligibility.Visible = True

            End If
            If lUser.IsReseted.ToString.ToUpper = "Y" Then
                Response.Redirect("ResetPassword.aspx", False)

            End If
        End If

        If lUser.HasLabModule = "Y"c And Not lUser.EmdeonUserName Is Nothing Then
            mnuLabs.Visible = True
        Else
            mnuLabs.Visible = False
        End If

        txtPagePath.Text = Me.Request.FilePath
        lblDate.Text = Date.Today.ToString("MMMM dd , yyyy")
        ' lblName.Text = " " + lUser.LastName + "," + lUser.FirstName + " " + lUser.SecondName
        lblName.Text = " " + lUser.FirstName + " " + lUser.SecondName + " " + lUser.LastName + "!"
        'set security
        If lUser.IsAdministrator = "N" Then
            SetPrevilages()
        End If
        isRxCureClinic.Value = lUser.IsRxCureClinic
        If lUser.IsRxCureClinic = "Y" Then
            mnuCQMReport.Visible = False
        End If
        'pageexpire()
        If ConfigurationManager.AppSettings("AllowEmdeonLabOrder").ToUpper = "FALSE" Then
            mnuLabDashboard.Visible = False
            mnuOrders.Visible = False
            mnuLabReports.Visible = False
            mnuPatientLink.Visible = False
            mnuPatientChart.Visible = False
        End If

        If lUser.IsEpcs And lUser.IsProvider = "Y" Then
            mnuEpcs.Visible = True
            mnuEPCSSignup.Visible = True
        Else
            mnuEPCSSignup.Visible = False
        End If


        If lUser.IsAdministrator.ToUpper.Equals("Y") AndAlso Not lUser.IsClinicEpcs Then
            mnuEpcs.Visible = False
        End If

    End Sub
    Public Sub PageExpire()
        Response.Buffer = True
        Response.ExpiresAbsolute = Now.Subtract(New TimeSpan(1, 0, 0, 0))
        Response.Expires = 0
        Response.CacheControl = "no-cache"

    End Sub

    Protected Sub ibtnLogOut_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ibtnLogOut.Click
        FormsAuthentication.SignOut()

        Session.Abandon()
        Response.Redirect("LoginPage.aspx")
    End Sub
    ''' <summary>
    ''' set previlages by reflection
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetPrevilages()

        Dim lformName As String
        Dim lReturnValue As Boolean

        Try
            'get current form name
            lformName = EHRRolesMethods.GetFormName(Request.Url.AbsolutePath)
            '  lformName = Request.Url.ToString().Substring(Request.Url.ToString().LastIndexOf("Panacea/Drsch/") + 14, Request.Url.ToString().LastIndexOf(".aspx") - Request.Url.ToString().LastIndexOf("Panacea/Drsch/") - 9)
            lReturnValue = EHRRolesMethods.SetPrevilages(lformName, Session("User"), Me)

            If lReturnValue = False Then
                If Request.UrlReferrer Is Nothing Then
                    Response.Redirect("../unauthorization.aspx", False)

                Else

                    If Request.UrlReferrer.ToString().Contains("Panacea/") Then
                        Response.Redirect("../unauthorization.aspx?URL=" + Request.UrlReferrer.ToString(), False)
                    Else
                        '  Response.Write("<script> alert('You are not authorize to view this page.'); location.href = 'Dashboard.aspx'; </script> ")
                        Response.Redirect("../unauthorization.aspx", False)
                    End If

                End If
            End If

        Catch ex As Exception
            Throw ex
        End Try
    End Sub



    Protected Sub btnPortability_Click(sender As Object, e As System.Web.UI.ImageClickEventArgs)
        Dim lthread As Thread
        Dim lUser As User = CType(Session("User"), User)
        Dim lCompleted As String
        Dim lds As DataSet
        Dim lPortableID As String
        Try
            lds = DataPortableMethods.GetPortableWrtUseRID(lUser.UserId, lUser.ConnectionString)
            If lds.Tables(0).Rows.Count > 0 Then
                lCompleted = lds.Tables(0).Rows(0)("IsCompleted")
                lPortableID = lds.Tables(0).Rows(0)("PortableID")
                If lCompleted = "N" Then
                    Response.Write("<script>alert('Downloading in process....please wait');</script>")
                    Return
                End If

                If Not lPortableID Is Nothing Then
                    DataPortableMethods.Update(lPortableID, lUser.ConnectionString)
                End If
            End If


            'If lDownload = "N" Then
            '    Response.Write("<script>alert('Already downloaded');</script>")
            '    Return
            'End If
            Response.Write("<script> window.open('../DataPortabilityPopup.aspx', 'newWindow', 'width=250,height=180,top=175,left=300,toolbar=0,location=0,directories=0,status=0,menuBar=0,scrollBars=1,resizable=1');</script>")

            If Not ContentPlaceHolder1.FindControl("pnlPortable") Is Nothing Then
                CType(ContentPlaceHolder1.FindControl("pnlPortable"), Panel).Visible = False

            End If

            Dim lEventLog As New EHREventLog
            lEventLog.ConnectionString = lUser.ConnectionString
            lEventLog.EventLog.EventDescription = "A user has stared data portability process with login id " & lUser.LoginId
            lEventLog.EventLog.EventTypeID = 174
            lEventLog.EventLog.ExtraID = ""
            lEventLog.EventLog.ExtraIDDescription = ""
            lEventLog.EventLog.ExtraID2 = ""
            lEventLog.EventLog.OCcurTime = DateTime.Now.ToString()
            lEventLog.EventLog.UserID = lUser.UserId
            lEventLog.EventLog.PatientID = 0
            lEventLog.HandleEvent()

            If DataPortableMethods.GetMaxID(lUser.ConnectionString).Tables(0).Rows.Count > 0 Then
                Session("PortableID") = DataPortableMethods.GetMaxID(lUser.ConnectionString).Tables(0).Rows(0)(0).ToString
            Else
                Session("PortableID") = 1
            End If


            oDataPortable.lConnectionstring = lUser.ConnectionString
            oDataPortable.luserId = lUser.UserId
            oDataPortable.mPortableID = Session("PortableID")
            oDataPortable.lcliniccode = lUser.ClinicId
            lthread = New Thread(AddressOf oDataPortable.AddProtability)
            lthread.Start()


        Catch ex As Exception
            Dim lLogID As String = String.Empty
            lLogID = ErrorLogMethods.LogError(ex, "Billing\RxCureMaster\btnPortability_Click")
            Response.Redirect("ErrorPage.aspx?LogID=" & lLogID, False)
        End Try

    End Sub
    Protected Shared Sub DataPortableEventHandler(ByVal pPortableID As String, pConnectionString As String) Handles oDataPortable.ThreadComplete
        Try
            DataPortableMethods.Update(pPortableID, pConnectionString)

        Catch ex As Exception

        End Try

    End Sub

End Class




