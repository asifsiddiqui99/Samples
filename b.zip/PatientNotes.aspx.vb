
Partial Class Billing_PatientNotes
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'Dim queryString As NameValueCollection
        Dim querystring As String = String.Empty

        Dim lPatientId As String = ""
        Dim lLogId As Int32 = 0

        If Not Page.IsPostBack Then

            ''''''''''' Clear Session for Add and Edit Allergy Pages'''''''''''''
            If (Not Session("CurrentXml") Is Nothing) Then
                Session("CurrentXml") = ""
            End If

            If (Not Session("EditCurrentXml") Is Nothing) Then
                Session("EditCurrentXml") = ""
            End If

            ''''''''''' Clear Session for Add and Edit Allergy Pages'''''''''''''


            ''''''''''' Clear Session for Patient Notes Pages'''''''''''''
            If (Not Session("CurrentNotesXml") Is Nothing) Then
                Session("CurrentNotesXml") = ""
            End If

            ''''''''''' Clear Session for Patient Notes Pages'''''''''''''

            Try
               
                If (Request.QueryString Is Nothing) Then
                    Exit Sub
                Else
                    'queryString = Encryption.DecryptQueryString(Request.QueryString.ToString())


                    lPatientId = Request.QueryString.Get(0).ToString()
                    txtPatientId.Text = lPatientId
                    LoadPatientNotes(txtPatientId.Text)


                End If
                

                'lPatientId = "312"
                'LoadPatientNotes(lPatientId)



            Catch ex As Exception
                lLogId = ErrorLogMethods.LogError(ex, "PatientNotes.aspx\Page_Load()")
                Response.Redirect("ErrorPage.aspx?LogId=" & lLogId, False)
            End Try


        End If

    End Sub
    Protected Sub LoadPatientNotes(ByVal pPatientID As String)

        Dim ldoc As XmlDocument = New XmlDocument()
       
        Dim lnode As XmlElement
        Dim lDs As DataSet = New DataSet
        Dim lUser As User
        Dim lObjPatientNotes As PatientNotes



        Dim lQuery As String = "AND PatientID = " & pPatientID

        Try
            lUser = CType(Session.Item("User"), User)
            lObjPatientNotes = New PatientNotes(lUser.ConnectionString)
            lDs = lObjPatientNotes.GetAllRecords(lQuery)

            ldoc.LoadXml("<PatientNotes></PatientNotes>")
            If (lDs.Tables(0).Rows.Count > 0) Then
                Dim i As Int32
                For i = 0 To lDs.Tables(0).Rows.Count - 1
                    lnode = ldoc.CreateElement("PatientNote")
                    With lnode
                        .SetAttribute("NoteId", lDs.Tables(0).Rows(i).Item("NoteId").ToString)
                        .SetAttribute("PatientId", lDs.Tables(0).Rows(i).Item("PatientId").ToString)
                        .SetAttribute("NoteDate", lDs.Tables(0).Rows(i).Item("NoteDate").ToString.Split(" ")(0))
                        .SetAttribute("Notes", lDs.Tables(0).Rows(i).Item("Notes").ToString)
                    End With
                    ldoc.DocumentElement.AppendChild(lnode.CloneNode(True))
                Next
            End If

            ''''''''' Previous Code''''''''''''''''''''''''
            If (ldoc.SelectSingleNode("/PatientNotes").HasChildNodes) Then
                Session("CurrentNotesXml") = ldoc.InnerXml.ToString
            End If
        Catch ex As Exception

            If (Not Session("CurrentNotesXml") Is Nothing) Then
                Session("CurrentNotesXml") = ""
            End If

            Dim myparent As Page = Me.Page
            Dim lLogID As String
            lLogID = ErrorLogMethods.LogError(ex, " :" & myparent.AppRelativeVirtualPath & "\UserControls\UserControls_PatientNotesUserControl.LoadPatientNotes()")
            Response.Redirect("ErrorPage.aspx?LogID=" & lLogID, False)



        End Try




    End Sub

   

   

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSave.Click
        If (Not Session("CurrentXml") Is Nothing) Then
            Session("CurrentXml") = ""
        End If

        If (Not Session("EditCurrentXml") Is Nothing) Then
            Session("EditCurrentXml") = ""
        End If


        ''''''''''' Clear Session for Patient Notes Pages'''''''''''''
        Dim lCurrentNotesXml As String = pNotesUc.GetXml()
        If (Not lCurrentNotesXml Is Nothing) Then

            Dim lUser As User

            lUser = CType(Session.Item("User"), User)
            Dim lPatientNotes As PatientNotes = New PatientNotes(lUser.ConnectionString)

            lCurrentNotesXml = lCurrentNotesXml.Replace("001", txtPatientId.Text)
            lPatientNotes.DeleteRecord(" And PatientId='" + txtPatientId.Text + "'")
            lPatientNotes.InsertRecord(lCurrentNotesXml)
            Session("CurrentNotesXml") = ""
            InjectScript.Text = "<script>CloseOnly()</Script>"

        End If
    End Sub

    Protected Sub btnClose_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnClose.Click
        ''''''''''' Clear Session for Add and Edit Allergy Pages'''''''''''''
        If (Not Session("CurrentXml") Is Nothing) Then
            Session("CurrentXml") = ""
        End If

        If (Not Session("EditCurrentXml") Is Nothing) Then
            Session("EditCurrentXml") = ""
        End If

        ''''''''''' Clear Session for Add and Edit Allergy Pages'''''''''''''


        ''''''''''' Clear Session for Patient Notes Pages'''''''''''''
        If (Not Session("CurrentNotesXml") Is Nothing) Then
            Session("CurrentNotesXml") = ""
        End If

        ''''''''''' Clear Session for Patient Notes Pages'''''''''''''
        InjectScript.Text = "<script>CloseOnly()</Script>"

    End Sub
End Class
