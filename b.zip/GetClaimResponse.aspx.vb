
Partial Class Billing_GetClaimResponse
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'Response.Write("ok")
        Page.Response.ContentType = "text/html"
        Dim reader As StreamReader = New StreamReader(Page.Request.InputStream)
        Dim lEdi835 As String = reader.ReadToEnd
        If (lEdi835 <> "") Then
            PostPayment(lEdi835)
        End If

    End Sub

    Protected Sub btnPostPayment_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnPostPayment.Click
        Dim lResults As Boolean = False
        Dim lResponsePaymentDetailColl As New ResponsePaymentDetailColl
        Dim lClaimResponseDB As New ClaimResponseDB
        Dim lResponsePaymentDetail As New ResponsePaymentDetail


        Try
            Dim lFileName As String = uplClaimResponse.PostedFile.FileName

            If lFileName.Equals("") Then
                Throw New Exception("Please Select a File")
            End If

            lResults = ClaimResponse835.ParseResponsePostPayment(lResponsePaymentDetailColl, lClaimResponseDB, lFileName)


            If lResults = True Then
                lblMessage.Text = "Payement posted successfully."
            Else
                lblMessage.Text = "An error has occured while processing the request."
            End If


        Catch ex As Exception
            lblMessage.Text = ex.Message
        End Try

    End Sub
    Protected Sub PostPayment(ByVal pEdi835 As String)
        Dim lResults As Boolean = False
        Dim lResponsePaymentDetailColl As New ResponsePaymentDetailColl
        Dim lClaimResponseDB As New ClaimResponseDB
        Dim lResponsePaymentDetail As New ResponsePaymentDetail


        Try
            'Dim lFileName As String = uplClaimResponse.PostedFile.FileName

            If pEdi835.Equals("") Then
                Throw New Exception("No content")
            End If

            'lResults = ClaimResponse835.ParseResponsePostPaymentRemote(lResponsePaymentDetailColl, lClaimResponseDB, pEdi835)
            lResults = ClaimResponse835.PostPaymentAndSaveMessageInfo(lResponsePaymentDetailColl, lClaimResponseDB, pEdi835)


            If lResults = True Then
                lblMessage.Text = "Payement posted successfully."
            Else
                lblMessage.Text = "An error has occured while processing the request."
            End If


        Catch ex As Exception
            lblMessage.Text = ex.Message
        End Try
    End Sub

End Class
