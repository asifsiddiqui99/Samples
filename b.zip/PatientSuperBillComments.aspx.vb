Imports Telerik.WebControls

Partial Class Billing_PatientSuperBillComments
    Inherits System.Web.UI.Page

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim lResult As String
        Dim lUser As User
        Dim lOldCommentsDs As New DataSet
        lUser = CType(Session.Item("User"), User)
        'If txComment.Text.Equals("") Then
        '    Exit Sub
        'End If
        Try
            If txtType.Text = "HCFA" Then
                Dim lHCFADBUpdated As HCFADBUpdated = New HCFADBUpdated
                With lHCFADBUpdated
                    .HCFANotes = txComment.Text & " " & lUser.FirstName & " " & lUser.LastName & "[" & lUser.LoginId & "]," & Date.Today.Date & ": "
                    .HCFAID = txtID.Text
                End With
                lResult = HCFAMethods.UpDateNotes(lHCFADBUpdated)
                Response.Write("<script>alert('Notes Successfully Added:');</script>")

            ElseIf txtType.Text = "PSB" Then
                Dim lPatientSuperBillDB As PatientSuperBillDB = New PatientSuperBillDB
                With lPatientSuperBillDB
                    If (txComment.Text.TrimEnd.TrimStart <> "") Then
                        lOldCommentsDs = PatientSuperBillMethods.LoadComment(Nothing, txtID.Text)
                        If (lOldCommentsDs.Tables.Count > 0 AndAlso lOldCommentsDs.Tables(0).Rows.Count > 0) Then
                            If (lOldCommentsDs.Tables(0).Rows(0).Item("Comments").ToString = txComment.Text) Then
                                .Comments = txComment.Text
                                .PatientSuperBillID = txtID.Text
                            Else
                                If (txComment.Text.Length < lOldCommentsDs.Tables(0).Rows(0).Item("Comments").ToString.Length) Then
                                    .Comments = txComment.Text
                                    .PatientSuperBillID = txtID.Text
                                Else
                                    '.Comments = txComment.Text & " :By " & lUser.FirstName & " " & lUser.LastName & "[" & lUser.LoginId & "] On " & Date.Today.Date & " "
                                    .Comments = txComment.Text
                                    .PatientSuperBillID = txtID.Text
                                End If
                            End If
                        Else
                            '.Comments = txComment.Text & " :By " & lUser.FirstName & " " & lUser.LastName & "[" & lUser.LoginId & "] On " & Date.Today.Date & " "
                            .Comments = txComment.Text
                            .PatientSuperBillID = txtID.Text
                        End If
                    Else
                        .Comments = ""
                        .PatientSuperBillID = txtID.Text
                    End If
                End With
                lResult = PatientSuperBillMethods.UpDateComment(lPatientSuperBillDB)
                Response.Write("<script>alert('Comments Successfully Added:');</script>")
            End If
        Catch ex As Exception

        End Try
    End Sub

    

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim lResult As Boolean

        If (Not Page.IsPostBack) Then
            Try
                Dim lDs As New DataSet()

                'Dim queryString As NameValueCollection

                If (Not Request.QueryString Is Nothing) Then
                    'queryString = Encryption.DecryptQueryString(Request.QueryString.ToString())
                    'txtID.Text = queryString("ID")
                    'txtType.Text = Request.QueryString("Type")
                    txtID.Text = Request.QueryString("ID")
                    txtType.Text = "PSB"
                End If


                Dim lHCFADBUpdated As HCFADBUpdated = New HCFADBUpdated
                If txtType.Text = "HCFA" Then
                    lDs = HCFAMethods.LoadNotes(lHCFADBUpdated, txtID.Text)
                    txComment.Text = lDs.Tables(0).Rows(0)("HCFANotes")

                    'lResult = HCFAMethods.InsertNotes(lHCFADBUpdated)
                End If



                Dim lPatientSuperBillDB As PatientSuperBillDB = New PatientSuperBillDB
                If txtType.Text = "PSB" Then
                    lDs = PatientSuperBillMethods.LoadComment(lPatientSuperBillDB, txtID.Text)

                    txComment.Text = lDs.Tables(0).Rows(0)("Comments")

                    'lResult = PatientSuperBillMethods.InsertComment(lPatientSuperBillDB)
                End If
            Catch ex As Exception

            End Try
        End If

    End Sub

   
    Protected Sub btnAddComments_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnAddComments.Click
        Dim lUser As User

        Try
            lUser = CType(Session("User"), User)
            txComment.Text = txComment.Text & vbCr & "" & lUser.FirstName & " " & lUser.LastName & " [" & lUser.FirstName & "], " & DateTime.Now & ": "
            txComment.Focus()
        Catch ex As Exception

        End Try

    End Sub
End Class
