
Imports Telerik.WebControls
Partial Class Billing_PaymentSearch
    Inherits System.Web.UI.Page

    ''' <summary>
    ''' changes by madiha: delete commented code said by FAraz Ahmed
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim queryString As NameValueCollection = Nothing
        Dim lPatientID As String
        Try

            If (Not Page.IsPostBack) Then
                If (Not Session("EditSelectedClaims") Is Nothing) Then
                    Session.Remove("EditSelectedClaims")
                End If
                Utility.SelectComboItem(cmbPayerType, "All", True)

                txtPayerName.Style("display") = "none"
                lblPayerName.Style("display") = "none"
                cmbPatient.Style("display") = "none"
                btnMirror.Style("display") = "none"
                'btnMirror.Visible = False
                cmbInsuranceCompany.Style("display") = "none"

                Utility.SelectComboItem(cmbPaymentStatus, "Pending", True)
                Utility.SelectComboItem(cmbPaymentMode, "All", True)

                If (Request.QueryString.Count > 0) Then
                    queryString = Encryption.DecryptQueryString(Request.QueryString.ToString())
                    If (queryString IsNot Nothing) Then
                        lPatientID = queryString("id").ToString
                        txtPatientID.Text = lPatientID
                        btnBackPS.Visible = True
                        Utility.SelectComboItem(cmbPayerType, "Patient", False)
                        'cmbPayerType.SelectedItem.Text = "Patient"
                        Dim lPatient As New PatientDBExtended
                        Dim lUser As User
                        lUser = CType(Session.Item("User"), User)
                        lPatient = PatientMethods.LoadPatientsById(lPatientID, lUser)
                        cmbPatient.Text = lPatient.LastName & "," & lPatient.FirstName
                        cmbPatient.Value = lPatient.PatientID
                    End If

                End If
                grdFacility.Rebind()


            End If

            If (cmbPayerType.SelectedItem.Text = "Insurance") Then
                cmbPatient.Style("display") = "none"
                btnMirror.Style("display") = "none"
                'btnMirror.Visible = False
                txtPayerName.Style("display") = "none"
                cmbInsuranceCompany.Style("display") = ""
                lblPayerName.Style("display") = ""
            ElseIf (cmbPayerType.SelectedItem.Text = "Patient") Then
                cmbInsuranceCompany.Style("display") = "none"
                txtPayerName.Style("display") = "none"
                cmbPatient.Style("display") = ""
                btnMirror.Style("display") = ""
                'btnMirror.Visible = True
                lblPayerName.Style("display") = ""
            Else
                cmbPatient.Style("display") = "none"
                btnMirror.Style("display") = "none"
                'btnMirror.Visible = False
                cmbInsuranceCompany.Style("display") = "none"
                txtPayerName.Style("display") = "none"
                lblPayerName.Style("display") = "none"

            End If


        Catch ex As Exception

        End Try
    End Sub
  
    Protected Sub grdFacility_ItemCommand(ByVal source As Object, ByVal e As Telerik.WebControls.GridCommandEventArgs) Handles grdFacility.ItemCommand
        If e.CommandName.Equals("Apply") Then            
            Response.Redirect("ApplyPayment.aspx" + Encryption.EncryptQueryString("PaymentID=" & e.Item.Cells(2).Text))
        End If
    End Sub

    Protected Sub grdFacility_ItemDataBound(ByVal sender As Object, ByVal e As Telerik.WebControls.GridItemEventArgs) Handles grdFacility.ItemDataBound
        Dim lbtnNotes As ImageButton
        Dim lbtnDetails As ImageButton

        Try
            If (e.Item.ItemType = Telerik.WebControls.GridItemType.Item Or e.Item.ItemType = Telerik.WebControls.GridItemType.AlternatingItem) Then

                Dim lDataItem As GridDataItem = CType(e.Item, GridDataItem)
                


                'lbtnNotes = CType(e.Item.FindControl("btnNotes"), ImageButton)
                'lbtnNotes.Attributes.Add("onclick", "javascript:return clickOnceQuestion(this," & e.Item.Cells(2).Text & ")")


                'Dim lComments As String = e.Item.Cells(12).Text
                'lComments = e.Item.Cells(12).Text

                lbtnNotes = CType(e.Item.FindControl("btnNotes"), ImageButton)
                lbtnNotes.Attributes.Add("onclick", "javascript:return clickOnceQuestion(this," & e.Item.Cells(2).Text & ");")


                'lbtnDetails = CType(e.Item.FindControl("btnDetails"), ImageButton)
                'lbtnDetails.Attributes.Add("onclick", "javascript:window.open('../Billing/PaymentRemitanceDetail.aspx" + Encryption.EncryptQueryString("RemID=" + e.Item.Cells(14).Text) + "','','width=700,height=400,toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,copyhistory=no,resizable = yes ')")

                If (e.Item.Cells(14).Text.ToString.Trim <> "&nbsp;" And e.Item.Cells(14).Text.ToString.Trim <> "") Then
                    lbtnNotes.ImageUrl = "../Images/comments_yellow.gif"
                Else
                    lbtnNotes.ImageUrl = "../Images/comments_blue.gif"
                End If

                If (e.Item.Cells(16).Text.ToString.Trim <> "&nbsp;" And e.Item.Cells(16).Text.ToString.Trim <> "0") Then
                    'lbtnDetails.ImageUrl = "../Images/comments_yellow.gif"
                    CType(CType(e.Item, GridDataItem)("View Detail").Controls(0), DataBoundLiteralControl).Visible = True
                Else
                    'lbtnDetails.Enabled = False
                    'lbtnDetails.ImageUrl = "../Images/comments_blue.gif"
                    CType(CType(e.Item, GridDataItem)("View Detail").Controls(0), DataBoundLiteralControl).Visible = False
                End If


                If (e.Item.Cells(13).Text = "Pending") Then
                    CType(lDataItem.Cells(11).Controls(0), ImageButton).Enabled = True
                Else
                    CType(lDataItem.Cells(11).Controls(0), ImageButton).Enabled = False
                End If


                If (e.Item.Cells(7).Text = e.Item.Cells(8).Text) Then
                    CType(lDataItem.Cells(11).Controls(0), ImageButton).Enabled = False
                    CType(lDataItem.Cells(11).Controls(0), ImageButton).ToolTip = "Full payment is already applied"
                    CType(lDataItem.Cells(11).Controls(0), ImageButton).CssClass = ""
                    CType(lDataItem.Cells(11).Controls(0), ImageButton).ImageUrl = "../Images/paymentapply-disable.gif"
                Else
                    CType(lDataItem.Cells(11).Controls(0), ImageButton).CssClass = "cursor"
                    CType(lDataItem.Cells(11).Controls(0), ImageButton).ToolTip = "Apply Payment"
                End If
                '**********************************
                Dim lStrAmount As String

                lStrAmount = e.Item.Cells(7).Text
                If (lStrAmount.Substring(0, 1) = "-") Then
                    lStrAmount = "(" & lStrAmount.Remove(0, 1) & ")"
                    e.Item.Cells(7).Text = lStrAmount
                End If
                lStrAmount = e.Item.Cells(8).Text
                If (lStrAmount.Substring(0, 1) = "-") Then
                    lStrAmount = "(" & lStrAmount.Remove(0, 1) & ")"
                    e.Item.Cells(8).Text = lStrAmount
                End If

                '**************************
                'mouseover by kanwaljeet
                If e.Item.Cells(10).Text = "1/1/1900" Then
                    e.Item.Cells(10).Text = ""
                End If

                ' If (lComments <> "&nbsp;") Then
                If (e.Item.Cells(12).Text.ToString.Trim <> "&nbsp;" And e.Item.Cells(14).Text.ToString.Trim <> "") Then
                    If (e.Item.Cells(14).Text.Length > 125) Then
                        e.Item.Cells(14).Text = e.Item.Cells(14).Text.Substring(0, 125) & "...."
                    End If

                    'lCommentsImg.Attributes.Add("onmouseover", "javascript:Tip('" & e.Item.Cells(28).Text.Substring(e.Item.Cells(28).Text.ToString.LastIndexOf(":") + 1) & "');")
                    'lCommentsImg.Attributes.Add("onmouseover", "javascript:Tip('123', DURATION,5000, OFFSETX, -50);")

                    If (e.Item.Cells(14).Text.Contains(vbCrLf)) Then
                        lbtnNotes.Attributes.Add("onmouseover", "javascript:Tip('<table background=\'../Images/comments.gif\' width=\'199\' height=\'132\'  border=\'0\' cellspacing=\'0\' cellpadding=\'16\' style=\'color:#666666; background-repeat:no-repeat; margin-right:35px;\' ><tr><td valign=\'top\' style=\'padding-top:43px; padding-right:25px;\' >" & e.Item.Cells(12).Text.Replace(vbCrLf, "") & "<\/td><\/tr><\/table>', DURATION,5000, OFFSETX, 0)")
                    Else
                        lbtnNotes.Attributes.Add("onmouseover", "javascript:Tip('<table background=\'../Images/comments.gif\' width=\'199\' height=\'132\'  border=\'0\' cellspacing=\'0\' cellpadding=\'16\' style=\'color:#666666; background-repeat:no-repeat; margin-right:35px;\' ><tr><td valign=\'top\' style=\'padding-top:43px; padding-right:25px;\' >" & e.Item.Cells(12).Text & "<\/td><\/tr><\/table>', DURATION,5000, OFFSETX, 0)")
                    End If
                End If


            End If
        Catch ex As Exception

        End Try
     
      
    End Sub
    Protected Sub grdFacility_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdFacility.NeedDataSource
        Dim lPaymentId As String = Utility.AdjustApostrophie(Me.txtPaymentId.Text)
        Dim lDescription As String = Utility.AdjustApostrophie(Me.txtDescription.Text)
        Dim lPayerType As String = cmbPayerType.Value
        Dim lPaymentFromDate As String = Me.dtPaymentFrom.SelectedDate.ToString
        Dim lPaymentToDate As String = Me.dtPaymentTo.SelectedDate.ToString
        Dim lPaymentMode As String = Me.cmbPaymentMode.Text
        Dim lPaymentStatus As String = Me.cmbPaymentStatus.Text
        Dim lPayerName As String = ""
       
        If lPayerType = "I" Then
            lPayerName = cmbInsuranceCompany.Text
        ElseIf lPayerType = "P" Then
            lPayerName = cmbPatient.Text
        End If

        Dim lUser As New User
        lUser = CType(Session("User"), User)

        pnlGrid.Visible = True
        grdFacility.DataSource = PaymentMethods.SearchPayment(lPaymentId, lDescription, lPayerType, lPaymentFromDate, lPaymentToDate, lPaymentMode, lPaymentStatus, lUser, Utility.AdjustApostrophie(lPayerName), dpCheckFromDate.SelectedDate.ToString, dpCheckToDate.SelectedDate.ToString, txtCheckNumber.Text)

    End Sub

    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSearch.Click
        Try
            'txtPatientID.Text = ""
            'btnBackPS.Visible = False
            grdFacility.Rebind()
        Catch ex As Exception

        End Try

    End Sub



    Protected Sub ImgAddFacility_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImgAddFacility.Click
        Response.Redirect("PostNewPayment.aspx")
    End Sub

    Protected Sub btnSave2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave2.Click


        Dim lUser As User
        Dim lPaymentID As String = String.Empty
        Dim lPaymentHdr As PaymentHdr


        Try
            lUser = CType(Session.Item("User"), User)

            lPaymentHdr = New PaymentHdr(lUser.ConnectionString)

            lPaymentID = Me.hdVisitID.Value.ToString

            If (Me.hdComment.Value.ToString.equals("")) Then
                'Exit Sub
            End If
            '& lUser.FirstName & " " & lUser.LastName & "[" & lUser.LoginId & "]," & Date.Today.Date & ": "
            lPaymentHdr.UpdateNotes(Me.hdComment.Value.ToString & " ", lPaymentID)
            grdFacility.Rebind()



        Catch ex As Exception

        End Try


    End Sub

    Protected Sub btnMirror_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnMirror.Click
        Dim newWindow As RadWindow
        Try
            newWindow = New RadWindow()
            If (cmbPatient.Text.ToString.Split(",").Length = 1) Then
                newWindow.NavigateUrl = "PatientSearch.aspx?srch=" & Utility.AdjustApostrophie(Me.cmbPatient.Text.ToString.Split(",")(0)) & "|" & "" & ""
            ElseIf (cmbPatient.Text.ToString.Split(",").Length > 1) Then
                newWindow.NavigateUrl = "PatientSearch.aspx?srch=" & Utility.AdjustApostrophie(Me.cmbPatient.Text.ToString.Split(",")(0)) & "|" & Me.cmbPatient.Text.ToString.Split(",")(1) & ""
            Else

            End If
            newWindow.ID = "rwPrimaryInsurer"
            newWindow.VisibleOnPageLoad = True
            newWindow.Top = 220
            newWindow.Left = 280
            newWindow.Width = Unit.Pixel(700)
            newWindow.Height = Unit.Pixel(385)
            newWindow.VisibleTitlebar = False
            newWindow.VisibleStatusbar = False
            newWindow.BorderStyle = BorderStyle.Solid
            newWindow.ReloadOnShow = True
            newWindow.BackColor = Drawing.Color.Transparent
            newWindow.ClientCallBackFunction = "PatientSearchCallBackFunction"
            newWindow.Enabled = True
            newWindow.Visible = True
            rwmSuperBill.Windows.Add(newWindow)
        Catch ex As Exception
            Dim lLogID As String = String.Empty
            lLogID = ErrorLogMethods.LogError(ex, " Billing_PatientLedgerPage.aspx\btnMirror_Click() ")
            Response.Redirect("~/ErrorPage.aspx?LogID=" & lLogID, False)
        End Try
    End Sub

    'Protected Sub cmbPayerType_SelectedIndexChanged(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxSelectedIndexChangedEventArgs) Handles cmbPayerType.SelectedIndexChanged
    '    Try
    '        If cmbPayerType.SelectedItem.Text = "Patient" Then
    '            btnMirror.Visible = True
    '        Else
    '            btnMirror.Visible = False

    '        End If
    '    Catch ex As Exception

    '    End Try
    'End Sub
    Protected Sub btnBackPS_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnBackPS.Click
        Dim lPatientID As String
        Try
            lPatientID = ElixirLibrary.Encryption.EncryptQueryString("id=" & txtPatientID.Text)
            Response.Redirect("selectpatient.aspx" & lPatientID)
        Catch ex As Exception

        End Try
    End Sub
End Class

