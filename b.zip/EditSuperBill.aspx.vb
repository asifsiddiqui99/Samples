Imports Telerik.WebControls

Partial Class Billing_EditSuperBill
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim lRadWindow As RadWindow



        tsSuperBill.SelectedIndex = 0
        mpSuperBill.SelectedIndex = 0


        '***** Get EmployeeId from Query String ********
        Dim lqueryString As NameValueCollection = Encryption.DecryptQueryString(Request.QueryString.ToString())

        If (Request.QueryString.Count = 0) Then
            Return
        End If
        txtSuperBillID.Text = lqueryString("sid")
        '***** Get EmployeeId from Query String ********

        If Not Page.IsPostBack Then
            SuperBillMethods.LoadSuperBillSession(txtSuperBillID.Text, lqueryString("sor"))
            LoadSuperBill()
            SuperBillMethods.LoadHeadingListBox(txtSuperBillID.Text, lbHeading)
        End If


        Me.btnICDCancel.OnClientClick = "javascript:window.history.go(-1);return false;"
        Me.btnSuperBillCancel.OnClientClick = "javascript:window.history.go(-1);return false;"
        Me.btnCPTCancel.OnClientClick = "javascript:window.history.go(-1);return false;"

        'rwmSuperBill.OffsetElementId = btnICDSearch.ClientID

        'lRadWindow = CType(rwmSuperBill.FindControl("rwICD9Search"), RadWindow)
        'lRadWindow.NavigateUrl = "SearchICD9.aspx"

        'rwmSuperBill.OffsetElementId = btnCPTSearch.ClientID
        'lRadWindow = CType(rwmSuperBill.FindControl("rwCPTSearch"), RadWindow)
    End Sub

    Private Sub LoadSuperBill()
        Dim lUser As User
        Dim lSuperBill As SuperBill
        Dim lResult As Boolean

        lUser = CType(Session.Item("User"), User)


        lSuperBill = New SuperBill(lUser.ConnectionString)

        lSuperBill.SuperBill.SuperBillId = txtSuperBillID.Text
        lResult = lSuperBill.GetRecordByID()


        If Not lResult Then
            Return
        End If

        With lSuperBill.SuperBill
            txtSuperBill.Text = .SuperBillName
            txtSuperBillID.Text = .SuperBillId

            Utility.SelectComboItem(cmbICDSortBy, .ICDSortBy, True)
            Utility.SelectComboItem(cmbICDSortOrder, .ICDSortOrder, True)

            Utility.SelectComboItem(cmbCPTSortBy, .CPTSortBy, True)
            Utility.SelectComboItem(cmbCPTSortOrder, .CPTSortOrder, True)
        End With




    End Sub

    Protected Sub grdICD_DeleteCommand(ByVal source As Object, ByVal e As Telerik.WebControls.GridCommandEventArgs) Handles grdICD.DeleteCommand
        Dim lICD9Coll As ICD9Coll
        Dim lICD9DB As New ICD9DB()

        lICD9DB.Code = e.Item.Cells(4).Text
        lICD9DB.Description = e.Item.Cells(5).Text
        lICD9DB.SuperBillId = ""

        If Session("ICD9Coll") IsNot Nothing Then
            lICD9Coll = Session("ICD9Coll")
            lICD9Coll.Remove(lICD9DB)
            Session.Add("ICD9Coll", lICD9Coll)
        End If



    End Sub

    Protected Sub grdICD_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdICD.NeedDataSource
        Dim lICDColl As ICD9Coll = New ICD9Coll()

        If Session("ICD9Coll") IsNot Nothing Then
            lICDColl = Session("ICD9Coll")
        End If
        grdICD.DataSource = lICDColl
    End Sub

    Protected Sub grdCPT_DeleteCommand(ByVal source As Object, ByVal e As Telerik.WebControls.GridCommandEventArgs) Handles grdCPT.DeleteCommand
        Dim lCPTColl As CPTColl
        Dim lCPTDB As New CPTDB()
        Dim lFound As Boolean

        lCPTDB.Code = e.Item.Cells(6).Text ' e.Item.Cells(5).Text
        lCPTDB.ShortDescription = e.Item.Cells(7).Text 'e.Item.Cells(6).Text
        lCPTDB.SuperBillId = ""
        lCPTDB.Heading = e.Item.Cells(4).Text

        If Session("CPTColl") IsNot Nothing Then
            lCPTColl = Session("CPTColl")
            lCPTColl.Remove(lCPTDB)

            lFound = lCPTColl.CheckHeadingExistance(lCPTDB)
            If Not lFound Then
                lbHeading.Items.Remove(lCPTDB.Heading)
            End If

            Session.Add("CPTColl", lCPTColl)

        End If
    End Sub

    Protected Sub grdCPT_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdCPT.NeedDataSource
        Dim lCPTColl As CPTColl = New CPTColl()

        If Session("CPTColl") IsNot Nothing Then
            lCPTColl = Session("CPTColl")
        End If
        grdCPT.DataSource = lCPTColl

        txtCPTCount.Text = lCPTColl.Count
    End Sub

    Protected Sub btnICDAdd_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnICDAdd.Click
        Dim lICDColl As ICD9Coll
        Dim lICD9 As New ICD9DB()
        Dim lICDData As String()


        If txtICDData.Text = "" Then
            Return
        End If
        lICDData = txtICDData.Text.Split("|")

        lICD9.Code = lICDData(0)
        lICD9.Description = lICDData(1)
        lICD9.SuperBillId = ""
        lICD9.IMOCode = lICDData(2)


        If Session("ICD9Coll") IsNot Nothing Then
            lICDColl = Session("ICD9Coll")
        Else
            lICDColl = New ICD9Coll
        End If

        If lICDColl.Count < 30 Then
            lICDColl.Add(lICD9)
        Else
            Page.RegisterStartupScript("testscript", "<script language='javascript'>alert('Number of ICDs cannot exceed 30');</script>")
            'Me.AjxMSuperBill.Alert("Number of ICDs cannot exceed 30")
            Return
        End If



        Session.Add("ICD9Coll", lICDColl)
        txtICDData.Text = ""
        txtICD.Text = ""



        grdICD.Rebind()
    End Sub

    Protected Sub btnCPTAdd_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnCPTAdd.Click
        Dim lCPTColl As CPTColl
        Dim lCPT As New CPTDB()
        Dim lCPTData As String()
        Dim lFound As Boolean = False


        If txtCPTData.Text = "" Then
            Return
        End If
        lCPTData = txtCPTData.Text.Split("|")

        lCPT.Code = lCPTData(3)
        lCPT.ShortDescription = lCPTData(1)
        lCPT.SuperBillId = ""
        lCPT.Heading = Utility.ChangeCase(txtCPTHeading.Text)
        lCPT.Fees = txtFees.Text
        lCPT.IMO = lCPTData(0)

        If Session("CPTColl") IsNot Nothing Then
            lCPTColl = Session("CPTColl")
        Else
            lCPTColl = New CPTColl
        End If


        If lCPTColl.Count < 30 Then
            For Each Item As CPTDB In lCPTColl
                If Item.Code = lCPT.Code Then
                    'Me.AjxMSuperBill.Alert("CPT already exists")
                    Page.RegisterStartupScript("testscript", "<script language='javascript'>alert('CPT already exists');</script>")
                    Return

                End If
            Next
            lCPTColl.Add(lCPT)
        Else
            'Me.AjxMSuperBill.Alert("Number of CPTs cannot exceed 30")
            Page.RegisterStartupScript("testscript", "<script language='javascript'>alert('Number of CPTs cannot exceed 30');</script>")
            Return
        End If

        SuperBillMethods.AddHeading(lCPT.Heading, lbHeading)
        Session.Add("CPTColl", lCPTColl)

        txtCPTData.Text = ""
        txtCPTHeading.Text = ""
        txtCPT.Text = ""
        txtFees.Text = ""


        grdCPT.Rebind()
    End Sub

    Private Sub OpenWindow(ByVal pNavigateUrl As String, ByVal pWindowId As String, ByVal pCallBackFunction As String)
        Dim newWindow As New RadWindow()

        newWindow.NavigateUrl = pNavigateUrl
        newWindow.ID = pWindowId
        newWindow.VisibleOnPageLoad = True
        newWindow.Top = 150
        newWindow.Left = 14
        newWindow.Width = Unit.Pixel(700)
        newWindow.Height = Unit.Pixel(400)
        newWindow.VisibleTitlebar = False
        newWindow.VisibleStatusbar = False
        newWindow.BorderStyle = BorderStyle.Solid
        newWindow.ReloadOnShow = True
        newWindow.BackColor = Drawing.Color.Transparent
        newWindow.ClientCallBackFunction = pCallBackFunction
        newWindow.Enabled = True
        newWindow.Visible = True
        'newWindow.Modal = True
        rwmSuperBill.Windows.Add(newWindow)
    End Sub

    Protected Sub btnICDSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnICDSearch.Click
        'AjxMSuperBill.ResponseScripts.Add("window.radopen('SearchICD9.aspx?icd=" & txtICD.Text & "','rwICD9Search');")
        OpenWindow("SearchICD9.aspx?icd=" & txtICD.Text & "&lid=1", "rwICD9Search", "ICDCallBackFunction")
        tsSuperBill.SelectedIndex = 1
        mpSuperBill.SelectedIndex = 1
    End Sub

    Protected Sub btnCPTSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnCPTSearch.Click
        'AjxMSuperBill.ResponseScripts.Add("window.radopen('SearchCPT.aspx?cpt=" & txtCPT.Text & "','rwCPTSearch');")
        OpenWindow("SearchCPT.aspx?cpt=" & txtCPT.Text, "rwCPTSearch", "CPTCallBackFunction")
        tsSuperBill.SelectedIndex = 2
        mpSuperBill.SelectedIndex = 2
    End Sub

    'Protected Sub btnICDSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnICDSearch.Click
    '    AjxMSuperBill.ResponseScripts.Add("window.radopen('SearchICD9.aspx?icd=" & txtICD.Text & "','rwICD9Search');")
    '    tsSuperBill.SelectedIndex = 1
    '    mpSuperBill.SelectedIndex = 1
    'End Sub

    'Protected Sub btnCPTSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnCPTSearch.Click
    '    AjxMSuperBill.ResponseScripts.Add("window.radopen('SearchCPT.aspx?cpt=" & txtCPT.Text & "','rwCPTSearch');")
    '    tsSuperBill.SelectedIndex = 2
    '    mpSuperBill.SelectedIndex = 2
    'End Sub

    Private Function SaveSuperBill() As Boolean

        Dim lUser As User
        lUser = CType(Session.Item("User"), User)


        Dim lSuperBillDB As New SuperBillDB()
        Dim lResult As Boolean

        With lSuperBillDB
            .SuperBillId = txtSuperBillID.Text
            .SuperBillName = Utility.AdjustApostrophie(txtSuperBill.Text)
            .CPTSortBy = cmbCPTSortBy.Value
            .CPTSortOrder = cmbCPTSortOrder.Value
            .ICDSortBy = cmbICDSortBy.Value
            .ICDSortOrder = cmbICDSortOrder.Value
        End With



        lResult = SuperBillMethods.UpdateSuperBill(lSuperBillDB, grdCPT.Items, grdICD.Items, lbHeading, Request.Url.AbsoluteUri)

        Return lResult

    End Function

    Protected Sub btnICDSave_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnICDSave.Click, btnSuperBillSave.Click, btnCPTSave.Click
        Dim lResult As Boolean

        If grdCPT.Items.Count < 1 Or grdICD.Items.Count < 1 Then
            Page.RegisterStartupScript("testscript", "<script language='javascript'>alert('Please enter atleast one CPT and ICD code');</script>")
            'Me.AjxMSuperBill.Alert("Please enter atleast one CPT and ICD code")
            Return
        End If


        lResult = SaveSuperBill()
        If lResult Then
            'lblMessage.Text = "SuperBill Updated Successfully"
            'Response.Redirect("SuperBillSetup.aspx")
            'Me.AjxMSuperBill.Alert("SuperBill Updated Successfully")
            'Me.AjxMSuperBill.Redirect("SuperBillSetup.aspx")
            'Me.AjxMSuperBill.Alert("SuperBill Updated Successfully")


            Response.Write("<script>alert('SuperBill Updated Successfully');</script>")
            PageExpire()

            Response.Write("<script>location.href = 'SuperBillSetup.aspx';</script>")




        Else
            'Me.AjxMSuperBill.Alert("Error Updating SuperBill")
            Response.Write("<script>alert('Error Updating SuperBill');</script>")
            'lblMessage.Text = "Error Updating SuperBill"
        End If
    End Sub

    'Protected Sub btnICDCancel_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnICDCancel.Click, btnSuperBillCancel.Click, btnCPTCancel.Click
    '    Response.Redirect("SuperBillSetup.aspx")
    'End Sub

    Protected Sub btnMoveUp_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnMoveUp.Click
        SuperBillMethods.MoveUp(lbHeading)
    End Sub

    Protected Sub btnMoveDown_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnMoveDown.Click
        SuperBillMethods.MoveDown(lbHeading)
    End Sub


    Public Sub PageExpire()
        Response.Buffer = True
        Response.ExpiresAbsolute = Now.Subtract(New TimeSpan(1, 0, 0, 0))
        Response.Expires = 0
        Response.CacheControl = "no-cache"
    End Sub

End Class
