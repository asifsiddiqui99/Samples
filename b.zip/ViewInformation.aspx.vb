
Partial Class Billing_ViewInformation
    Inherits System.Web.UI.Page
    Private Sub LoadPatient(ByVal pPatientId As String)
        Dim lUser As User
        Dim lResult As Boolean
        Dim lResultPrimaryInsurance As Boolean
        Dim lResultSecondaryInsurance As Boolean
        Dim lPatient As PatientExtended
        Dim lPatientInsurancePrimary As PatientInsurance
        Dim lPatientInsuranceSecondary As PatientInsurance
        Dim lLogId As Int32 = 0
        'Me.lblReturnedPrimaryInsurerInfo.Text = ""
        'Me.lblSecInsurerStatus.Text = ""

        Dim lPatientId As String = pPatientId

        Dim lStateResult As Boolean
        Dim lState As State
        Try
            'ResetPrimaryInsurance(False)
            'ResetSecondaryInsurance(False)
            'If Request.QueryString("EditID") Is Nothing Then
            'Exit Sub
            'End If
            'Dim lPatientId As String = Request.QueryString("EditID").ToString()

            lUser = CType(Session.Item("User"), User)
            lPatient = New PatientExtended(lUser.ConnectionString)
            lPatient.Patient.PatientID = lPatientId
            lResult = lPatient.GetRecordByID()
            ''lResult = lPatient.GetPatientWithDetailsByID()
            lState = New State(lUser.ConnectionString)
            If Not lResult Then
                lPatientId = ""
                Return
            End If

            lPatientInsurancePrimary = New PatientInsurance(lUser.ConnectionString)
            lPatientInsurancePrimary.PatientInsurance.PatientID = lPatientId
            lPatientInsurancePrimary.PatientInsurance.Type = "P"
            lResultPrimaryInsurance = lPatientInsurancePrimary.GetRecordByID()

            lPatientInsuranceSecondary = New PatientInsurance(lUser.ConnectionString)
            lPatientInsuranceSecondary.PatientInsurance.PatientID = lPatientId
            lPatientInsuranceSecondary.PatientInsurance.Type = "S"
            lResultSecondaryInsurance = lPatientInsuranceSecondary.GetRecordByID()

            With lPatient.Patient
                'Personal
                'Utility.SelectComboItem(cmbTitle, .Title, False)
                'Utility.SelectComboItem(Me.cmbMaritialStatus, .MartialStatus, False)
                lblFirstName.Text = .FirstName
                lblMiddleName.Text = .MiddleName
                lblLastName.Text = .LastName
                lblGender.Text = .Gender
                lblDOB.Text = .DOB
                lblAddressLine1.Text = .AddressLine1
                lblAddressLine2.Text = .AddressLine2
                lblCity.Text = .City
                ''lblstate.Text = .StateID
                'lState.State.StateID = .StateID


                If .ZipCode.ToString.Length > 5 Then
                    Me.lblZipCode.Text = .ZipCode.ToString.Substring(0, 5) + "-" + .ZipCode.ToString.Substring(5, 4)
                Else
                    Me.lblZipCode.Text = .ZipCode.ToString
                End If



                lblHousePhone.Text = .HomePhone


                'Responsible
                Me.lblResponsibleName.Text = .ResponsibleName
                Me.lblResponsibleCity.Text = .ResponsibleCity
                Me.lblResponsibleAddress.Text = .ResponsibleAddress
                Me.lblResponsibleHomePhone.Text = .ResponsibleHomePhone
                Me.lblResponsibleSSN.Text = .ResponsibleSSN
                Me.lblResponsibleWorkPhone.Text = .ResponsibleWorkPhone
                If .ResponsibleZip.ToString.Length > 5 Then
                    Me.lblResponsibleZip.Text = .ResponsibleZip.ToString.Substring(0, 5) + "-" + .ResponsibleZip.ToString.Substring(5, 4)
                Else
                    Me.lblResponsibleZip.Text = .ResponsibleZip.ToString
                End If

                'Me.lblResponsibleState.Text = .ResponsibleState
                Me.lblResponsibleRelationship.Text = .ResponsibleRelationship


            End With

            lState.State.StateID = lPatient.Patient.StateID
            lStateResult = lState.GetRecordByID()
            lblstate.Text = lState.State.Abbr
            lState.State.StateID = lPatient.Patient.ResponsibleState
            lStateResult = lState.GetRecordByID()
            Me.lblResponsibleState.Text = lState.State.Abbr

            ''Primary Insurance
            If (lResultPrimaryInsurance) Then
                With lPatientInsurancePrimary.PatientInsurance
                    If (.InsurerId = 0) Then
                        Me.lblInsuranceCompanyId.Text = .InsuranceCompanyID
                        Me.lblPayerId.Text = .PayerId

                        ''ask
                        ''  LoadInsuranceCombo(.InsuranceCompanyName, Me.lblInsuranceCompany.Text)
                        Me.lblInsuranceCompany.Text = .InsuranceCompanyName
                        'Me.cmbInsuranceCompany.Enabled = True



                    Else
                        Dim lTempResult As Boolean
                        Dim lTempPatient As New Patient(lUser.ConnectionString)
                        lTempPatient.Patient.PatientID = .InsurerId

                        Dim lTempPatientInsurance As New PatientInsurance(lUser.ConnectionString)
                        lTempPatientInsurance.PatientInsurance.PatientID = .InsurerId
                        lTempPatientInsurance.PatientInsurance.PatientInsID = .InsurerInsuranceId
                        lTempPatientInsurance.PatientInsurance.Type = .InsurerInsuranceType

                        lTempResult = lTempPatientInsurance.GetRecordByID()
                        lTempResult = lTempPatient.GetRecordByID()

                        Me.lblInsurerLastName.Text = lTempPatient.Patient.LastName
                        'LoadInsurerCombo(Me.RadComboBox1, Me.txtInsurerLastName.Text)
                        Me.lblInsurerFirstName.Text = lTempPatient.Patient.FirstName
                        Me.lblPrimaryInsurerId.Text = .InsurerId

                        Me.lblInsuranceCompanyId.Text = lTempPatientInsurance.PatientInsurance.InsuranceCompanyID
                        Me.lblPayerId.Text = lTempPatientInsurance.PatientInsurance.PayerId
                        'LoadInsuranceCombo(lTempPatientInsurance.PatientInsurance.InsuranceCompanyName, Me.cmbInsuranceCompany)
                        Me.lblInsuranceCompany.Text = lTempPatientInsurance.PatientInsurance.InsuranceCompanyName
                        'Me.cmbInsuranceCompany.Enabled = False
                        'Me.btnPrimaryInsurerSearch.Enabled = True
                        'Me.RadComboBox1.Enabled = True
                    End If
                    Me.lblRelationshipPrimaryInsurer.Text = .RelationshipToPrimaryInsurer
                    Me.lblSubscriberId.Text = .SubscriberID
                    Me.lblGroupNo.Text = .GroupNo
                    Me.lblPlanName.Text = .PlanName
                    Me.lblDeductable.Text = .Deductable
                    Me.lblVisitCopayment.Text = .VisitCopayment

                    Me.lblInsuredAuthorization.Text = .InsuredAuthorization

                    Me.lblSignature.Text = .SignatureOfFile
                    If (.SignatureDate <> "") Then
                        lblSignatureDate.Text = .SignatureDate
                    End If
                End With
            Else
                'ResetPrimaryInsurance(False)
            End If

            ''Secondary Insurance
            If (lResultSecondaryInsurance) Then
                With lPatientInsuranceSecondary.PatientInsurance
                    If (.InsurerId = 0) Then
                        Me.lblSecInsuranceCompanyID.Text = .InsuranceCompanyID
                        Me.lblSecPayerId.Text = .PayerId
                        ''LoadInsuranceCombo(.InsuranceCompanyName, Me.cmbSecInsuranceCompany)
                        Me.lblSecInsuranceCompany.Text = .InsuranceCompanyName
                        'Me.cmbSecInsuranceCompany.Enabled = True
                    Else
                        Dim lTempResult As Boolean
                        Dim lTempPatient As New Patient(lUser.ConnectionString)
                        lTempPatient.Patient.PatientID = .InsurerId

                        Dim lTempPatientInsurance As New PatientInsurance(lUser.ConnectionString)
                        lTempPatientInsurance.PatientInsurance.PatientID = .InsurerId
                        lTempPatientInsurance.PatientInsurance.PatientInsID = .InsurerInsuranceId
                        lTempPatientInsurance.PatientInsurance.Type = .InsurerInsuranceType

                        lTempResult = lTempPatientInsurance.GetRecordByID()
                        lTempResult = lTempPatient.GetRecordByID()

                        Me.lblSecInsurerLastName.Text = lTempPatient.Patient.LastName
                        ''LoadInsurerCombo(Me.RadComboBox3, Me.txtSecInsurerLastName.Text)
                        Me.lblSecInsurerFirstName.Text = lTempPatient.Patient.FirstName
                        Me.lblSecondaryInsurerId.Text = .InsurerId

                        Me.lblSecInsuranceCompanyID.Text = lTempPatientInsurance.PatientInsurance.InsuranceCompanyID
                        Me.lblSecPayerId.Text = lTempPatientInsurance.PatientInsurance.PayerId
                        '' LoadInsuranceCombo(lTempPatientInsurance.PatientInsurance.InsuranceCompanyName, Me.lblSecInsuranceCompany.Text)
                        Me.lblSecInsuranceCompany.Text = lTempPatientInsurance.PatientInsurance.InsuranceCompanyName
                        'Me.cmbSecInsuranceCompany.Enabled = False
                        'Me.ImageButton1.Enabled = True
                        'Me.RadComboBox3.Enabled = True
                    End If
                    Me.lblRelationshipSecondaryInsurer.Text = .RelationshipToPrimaryInsurer
                    Me.lblSecSubscriberId.Text = .SubscriberID
                    Me.lblSecGroupNo.Text = .GroupNo
                    Me.lblSecPlanName.Text = .PlanName
                    Me.lblSecDeductable.Text = .Deductable
                    Me.lblSecVisitCopayment.Text = .VisitCopayment
                    Me.lblSecInsuredAuthorization.Text = .InsuredAuthorization

                End With
            Else
                'ResetSecondaryInsurance(False)
            End If
        Catch ex As Exception
            lLogId = ErrorLogMethods.LogError(ex, "PatientPreview.aspx\LoadPatient(ByVal pPatientId As String)")
            Response.Redirect("ErrorPage.aspx?LogId=" & lLogId)
        End Try



    End Sub

    'Public Sub ResetPrimaryInsurance(ByVal flag As Boolean)

    '    Me.cmbInsuranceCompany.Enabled = True
    '    Me.cmbInsuranceCompany.Items.Clear()
    '    Me.cmbInsuranceCompany.Text = ""
    '    Me.cmbInsuranceCompany.Value = ""
    '    Me.txtInsuranceCompanyId.Text = 0
    '    Me.lblPayerId.Text = ""
    '    'If (Not Me.cmbInsuranceCompany.SelectedItem Is Nothing) Then
    '    '    Me.cmbInsuranceCompany.SelectedItem.Text = ""
    '    '    Me.cmbInsuranceCompany.Value = ""
    '    '    Me.cmbInsuranceCompany.SelectedItem.Value = ""
    '    'End If
    '    'Me.cmbInsuranceCompany.ClearSelection()
    '    'Me.cmbInsuranceCompany.Text = ""
    '    Me.cmbInsuranceCompany.Enabled = True
    '    Me.btnPrimaryInsurerSearch.Enabled = False

    '    Me.txtInsurerLastName.Text = ""
    '    Me.txtInsurerFirstName.Text = ""
    '    Me.txtPrimaryInsurerId.Text = 0
    '    Me.btnPrimaryInsurerSearch.Enabled = False

    '    Me.txtSubscriberId.Text = ""
    '    Me.txtPlanName.Text = ""
    '    Me.txtVisitCopayment.Text = ""
    '    Me.txtGroupNo.Text = ""

    '    'Me.cmbRelationshipPrimaryInsurer.ClearSelection()
    '    Utility.SelectComboItem(Me.cmbRelationshipPrimaryInsurer, "Self", False)
    '    Me.txtSubscriberId.Text = ""
    '    Me.txtGroupNo.Text = ""
    '    Me.txtPlanName.Text = ""
    '    Utility.SelectComboItem(Me.cmbInsuredAuthorization, "Yes", False)
    '    Me.txtDeductable.Text = ""
    '    Me.txtVisitCopayment.Text = ""
    '    Me.cmbSignature.ClearSelection()
    '    Me.RadComboBox1.ClearSelection()
    '    Me.RadComboBox1.Items.Clear()
    '    Me.RadComboBox1.Text = ""
    '    Me.RadComboBox1.Value = ""
    '    Me.RadComboBox1.Enabled = False
    '    Me.txtInsurerFirstName.Enabled = False
    '    Me.dtSignatureDate.SelectedDate = Nothing
    '    If (flag) Then
    '        Me.lblReturnedPrimaryInsurerInfo.Text = "No Primary/Self Insurance"
    '    Else
    '        Me.lblReturnedPrimaryInsurerInfo.Text = ""
    '    End If
    'End Sub
    'Public Sub ResetSecondaryInsurance(ByVal flag As Boolean)
    '    ''Me.cmbSecInsuranceCompany.DataSource = Nothing
    '    Me.cmbSecInsuranceCompany.Enabled = True
    '    Me.cmbSecInsuranceCompany.Items.Clear()
    '    Me.cmbSecInsuranceCompany.Text = ""
    '    Me.cmbSecInsuranceCompany.Value = ""
    '    Me.txtSecInsuranceCompanyID.Text = 0
    '    Me.lblSecPayerId.Text = ""
    '    'If (Not Me.cmbSecInsuranceCompany.SelectedItem Is Nothing) Then
    '    '    Me.cmbSecInsuranceCompany.SelectedItem.Text = ""
    '    '    Me.cmbSecInsuranceCompany.Value = ""
    '    '    Me.cmbSecInsuranceCompany.SelectedItem.Value = ""
    '    'End If
    '    'Me.cmbSecInsuranceCompany.ClearSelection()
    '    Me.ImageButton1.Enabled = False

    '    Me.txtSecInsurerLastName.Text = ""
    '    Me.txtSecInsurerFirstName.Text = ""
    '    Me.txtSecondaryInsurerId.Text = 0
    '    Me.ImageButton1.Enabled = False
    '    Me.txtSecDeductable.Text = ""

    '    Me.txtSecSubscriberId.Text = ""
    '    Me.txtSecPlanName.Text = ""
    '    Me.txtSecVisitCopayment.Text = ""
    '    Me.txtSecGroupNo.Text = ""



    '    'Me.cmbRelationshipSecondaryInsurer.ClearSelection()
    '    Utility.SelectComboItem(Me.cmbRelationshipSecondaryInsurer, "Self", False)
    '    Me.txtSecSubscriberId.Text = ""
    '    Me.txtSecGroupNo.Text = ""
    '    Me.txtSecPlanName.Text = ""
    '    Utility.SelectComboItem(Me.cmbSecInsuredAuthorization, "Yes", False)
    '    Me.txtSecDeductable.Text = ""
    '    Me.txtSecVisitCopayment.Text = ""
    '    Me.RadComboBox3.ClearSelection()
    '    Me.RadComboBox3.Items.Clear()
    '    Me.RadComboBox3.Text = ""
    '    Me.RadComboBox3.Value = ""
    '    Me.RadComboBox3.Enabled = False
    '    Me.txtSecInsurerFirstName.Enabled = False
    '    If (flag) Then
    '        Me.lblSecInsurerStatus.Text = "No Secondary/Self Insurance"
    '    Else
    '        Me.lblSecInsurerStatus.Text = ""
    '    End If

    'End Sub
    'Public Sub LoadInsuranceCombo(ByVal lCurrentInsurance As String, ByVal lCombo As Telerik.WebControls.RadComboBox)
    '    If lCurrentInsurance = "" Then
    '        Exit Sub
    '    End If
    '    Dim lDs As New DataSet
    '    Dim lUser As User
    '    Dim lLogId As Int32 = 0
    '    lUser = CType(Session.Item("User"), User)
    '    'Dim lobjPharmacyDb As New PharmacyDB
    '    'lobjPharmacyDb.ZipCode = e.Text
    '    Try
    '        lUser = CType(Session.Item("User"), User)
    '        lCombo.DataSource = Nothing
    '        'lDs = PharmacyMethods.GetPharmacy(lobjPharmacyDb, lUser, Request.Url.AbsoluteUri)
    '        lDs = InsuranceMethods.GetInsuranceForCombo(lCurrentInsurance, lUser)
    '        lCombo.DataSource = lDs
    '        lCombo.DataBind()
    '        'cmbInsuranceCompany.SelectedIndex = 0
    '    Catch ex As Exception
    '        lLogId = ErrorLogMethods.LogError(ex, "PatientPreview.aspx\LoadInsuranceCombo()")
    '        Response.Redirect("ErrorPage.aspx?LogId=" & lLogId)
    '    Finally
    '        lDs.Dispose()
    '    End Try

    'End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'Session("EditPatientID").ToString()
        Dim lPid As NameValueCollection = Encryption.DecryptQueryString(Request.QueryString.ToString())


        'pid = Request.QueryString("pid")
        'Dim lqueryString As NameValueCollection = Encryption.DecryptQueryString(Request.QueryString.ToString())

        LoadPatient(lPid("pid"))
    End Sub
End Class
