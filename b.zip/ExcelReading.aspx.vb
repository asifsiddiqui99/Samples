Imports System.Data
Imports System.Diagnostics
Imports System.Configuration.ConfigurationManager
Imports System.Security.Principal
Imports System.Data.OleDb
Imports System.Runtime.InteropServices
Imports Microsoft.Office.Interop.Excel
Imports System.Globalization
Imports System.Collections
Imports Microsoft.VisualBasic
Imports System.Xml
Imports ElixirLibrary
Imports InterFaxLibrary

Partial Class Billing_ExcelReading

    Inherits System.Web.UI.Page
    Dim con As New OleDb.OleDbConnection
    Dim xlworksheet As Worksheet
    Dim delDataTable As New System.Data.DataTable


    Protected Sub btnSubmit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSubmit.Click

       
        Dim strNewPath As String = String.Empty
        strNewPath = ViewState("ConnectionString")



        Try
            ViewState.Remove("lt1")

            FileUpload1.SaveAs(Server.MapPath(".\") + FileUpload1.FileName)

            Session("FileName") = Server.MapPath(".\") + FileUpload1.FileName

            ViewState("ConnectionString") = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Session("FileName") & ";Extended Properties=""Excel 12.0;HDR=Yes;IMEX=2"""

            con = New OleDb.OleDbConnection(ViewState("ConnectionString"))

            con.Open()

            Dim dt, dt1 As New System.Data.DataTable

            delDataTable.Columns.Add("CPT", System.Type.GetType("System.String"))

            dt1 = con.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, Nothing)

            dt = dt1

            Dim i As Integer

            For i = 0 To dt.Rows.Count - 1

                If (dt.Rows(i).Item("Table_Name").ToString.Contains("'")) Then
                    If (dt.Rows(i).Item("Table_Name").ToString.IndexOf("$") + 1 <> dt.Rows(i).Item("Table_Name").ToString.Length - 1) Then
                        delDataTable.Rows.Add(dt.Rows(i).Item("Table_Name").ToString)
                        dt.Rows(i).Delete()

                    End If
                Else
                    If (dt.Rows(i).Item("Table_Name").ToString.IndexOf("$") + 1 <> dt.Rows(i).Item("Table_Name").ToString.Length) Then
                        delDataTable.Rows.Add(dt.Rows(i).Item("Table_Name").ToString)
                        dt.Rows(i).Delete()
                    End If
                End If


            Next




            DataGrid1.DataSource = dt
            DataGrid1.DataBind()

            For i = 0 To DataGrid1.Items.Count - 1
                If (CType(DataGrid1.Items(i).Cells(1).FindControl("LinkButton2"), LinkButton).Text.Contains("$")) Then
                    CType(DataGrid1.Items(i).Cells(1).FindControl("LinkButton2"), LinkButton).Text = CType(DataGrid1.Items(i).Cells(0).FindControl("LinkButton1"), LinkButton).Text.Replace("$", "")
                End If
            Next

            ViewState("d") = delDataTable







            con.Close()
            Label1.Text = ""



        Catch ex As Exception
            Label1.Text = ex.Message
            con.Close()
        End Try
    End Sub

    Protected Sub DataGrid1_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles DataGrid1.ItemCommand
        Try
            'Dim con1 As New OleDbConnection(ViewState("ConnectionString"))

            Dim lFlag As Boolean = False
            con = New OleDb.OleDbConnection(ViewState("ConnectionString"))

            If (con.State = ConnectionState.Closed) Then
                con.Open()
            End If


            'Dim dt, dt2 As New System.Data.DataTable
            'dt2.Columns.Add("ColName", System.Type.GetType("System.String"))

            'Dim i As Integer = 0

            'con.Open()


            'dt = con.GetOleDbSchemaTable(OleDbSchemaGuid.Columns, _
            '                  New Object() {Nothing, Nothing, "Sheet2$", "TABLE"})

            ''dt = con1.GetOleDbSchemaTable(OleDbSchemaGuid.Columns, Nothing)

            Dim la As String = CType(e.Item.Cells(0).FindControl("LinkButton1"), LinkButton).Text

            Session("SheetName") = la

            'Dim da As New OleDbDataAdapter("Select * from [" + la + "]", con)

            ''Dim da As New OleDbDataAdapter("Select * from ['physicians fee schedule$'Print_Area]", con)



            'Dim ds As New DataSet()

            'da.Fill(ds)







            Dim dt, dt2 As New System.Data.DataTable
            dt2.Columns.Add("Column_Name", System.Type.GetType("System.String"))
            dt2.Columns.Add("Ordinal_Position", System.Type.GetType("System.String"))

            'dt = ds.Tables(0)

            'For Each row As DataRow In dt.Rows

            '    If Not ((row("COLUMN_NAME").ToString() = "Appendix") Or row("COLUMN_NAME").ToString().StartsWith("F")) Then
            '        dt2.Rows.Add(row("COLUMN_NAME").ToString())
            '        lFlag = True
            '    End If



            'Next
            'Dim i As Integer
            'Dim j As Integer
            'For i = 0 To dt.Columns.Count - 1
            '    If Not (dt.Columns(i).ColumnName.StartsWith("F") Or (dt.Columns(i).ColumnName.ToString = "Appendix")) Then
            '        dt2.Rows.Add(dt.Columns(i).ColumnName)
            '        lFlag = True
            '    End If
            'Next


            'If (lFlag = False) Then

            'delDataTable = ViewState("d")
            'Dim a As String


            Dim a As New Regex("^F.*[0-9]$")






            dt = con.GetOleDbSchemaTable(OleDbSchemaGuid.Columns, Nothing)
            Dim i As Integer

            For i = 0 To dt.Rows.Count - 1

                If a.IsMatch(dt.Rows(i).Item("Column_Name")) = False And dt.Rows(i).Item("Table_Name").ToString.StartsWith(la) Then
                    dt2.Rows.Add(dt.Rows(i).Item("Column_Name"), dt.Rows(i).Item("Ordinal_Position"))
                End If

            Next

            'la = la.Trim("'")
            'Dim a = dt.Select("TABLE_NAME like ""'physicians fee schedule$'""")

            'For x As Integer = 0 To a.length

            'Next


            'For i = 0 To dt.Rows.Count - 1
            '    If Not (dt.Rows(i).Item("Column_Name").ToString.StartsWith("F") Or (dt.Rows(i).Item("Column_Name").ToString = "Appendix")) Then

            '        For j = 0 To delDataTable.Rows.Count - 1

            '            If dt.Rows(i).Item("Table_Name").ToString() = delDataTable.Rows(j).Item(0) Then
            '                dt2.Rows.Add(dt.Rows(i).Item("Column_Name"))
            '            End If

            '        Next

            '    End If

            'Next

            'E'nd If


            DataGrid2.DataSource = dt2
            DataGrid2.DataBind()

            Button1.Visible = True

            con.Close()

        Catch ex As Exception
            Label1.Text = ex.Message + " Restart ASP.NET services"
            con.Close()
        End Try

    End Sub

    Public Sub GetCPT1(ByVal mylist As ArrayList, ByVal lrowcount As Integer)
        Dim lXmlDocument As New XmlDocument
        Dim lXmlElement As XmlElement
        Dim i As Integer = 0
        Dim j, lcol, lrow, k As Integer
        Dim lname, ldbfield As String
        Dim lflag As Boolean = False
        k = 0
        Dim unsaverecords As ArrayList = Nothing
        Dim mConnection As Connection = Nothing

        Dim lUser As User



        'lrowcount = 50000
        Try
            lUser = CType(Session("User"), User)
            mConnection = New Connection(lUser.ConnectionString)


            lXmlDocument.LoadXml("<FeeSchedules></FeeSchedules>")

            lrow = mylist.Item(j).ToString.Split(",")(1)


            For j = lrow + 1 To lrowcount

                lXmlElement = lXmlDocument.CreateElement("FeeSchedule")
                lflag = False

                For i = 0 To mylist.Count - 1

                    lname = mylist.Item(i).ToString.Split(",")(0)

                    lcol = mylist.Item(i).ToString.Split(",")(2)

                    ldbfield = mylist.Item(i).ToString.Split(",")(3)

                    lname = lname.Replace(" ", "")

                    With lXmlElement

                        If (CType(xlworksheet.Cells(j, lcol).value, String) = "") Or ((CType(xlworksheet.Cells(j, lcol).value, String) = " ")) Then
                            lflag = True
                            Exit For
                        Else
                            .SetAttribute(ldbfield, xlworksheet.Cells(j, lcol).value)
                        End If

                    End With

                Next

                If (lflag = False) Then
                    lXmlDocument.DocumentElement.AppendChild(lXmlElement.CloneNode(True))
                Else
                    k = k + 1
                End If



                If (j Mod 5000 = 0) Then

                    lUser = CType(Session("User"), User)

                    mConnection.ExecuteCommand("InsertFeeScheduleFromExcel", lXmlDocument.DocumentElement.OuterXml.ToString)
                    If (j = lrowcount) Then
                        Label1.Text = "Selected columns imported successfully" & ",total records in the file were " & lrowcount - lrow & " and records added were " & lrowcount - lrow - k
                        Exit Sub
                    End If

                    lXmlDocument = Nothing
                    lXmlDocument = New XmlDocument

                    lXmlDocument.LoadXml("<FeeSchedules></FeeSchedules>")

                End If

            Next

         


            
            mConnection.ExecuteScalarCommand("InsertFeeScheduleFromExcel", lXmlDocument.DocumentElement.OuterXml.ToString)

            Label1.Text = "Selected columns imported successfully" & ",total records in the file were " & lrowcount - lrow & " and records added were " & lrowcount - lrow - k



        Catch ex As Exception

            Label1.Text = "Error in field " & lname & " with row number" & j & " and column number " & lcol
        End Try

    End Sub

    Private Sub Traversing(ByVal mylist As ArrayList)


        Dim xlWorkBook As Workbook = Nothing
        Try
            Dim xlApp As Application

            Dim lrow As Integer = 0
            Dim lcol As Integer = 0
            Dim j As Integer
            Dim lname, ldatabasefield As String

            Dim mylist1 As New ArrayList()


            Dim lrowcount, lcolcount As Integer

            xlApp = New ApplicationClass


            xlWorkBook = xlApp.Workbooks.Open(Session("FileName"))

            Dim la As String = Session("SheetName")

            If (la.Contains("'")) Then
                la = la.Replace("'", "")
            End If
            If (la.Contains("$")) Then
                la = la.Replace("$", "")
            End If


            xlworksheet = xlWorkBook.Worksheets(la)


            lrowcount = xlworksheet.UsedRange.Rows.Count

            lcolcount = xlworksheet.UsedRange.Columns.Count






            For j = 0 To mylist.Count - 1

                lcol = mylist.Item(j).ToString.Split(",")(1)
                lname = mylist.Item(j).ToString.Split(",")(0)
                ldatabasefield = mylist.Item(j).ToString.Split(",")(2)

                For lrow = 1 To lrowcount

                    If (xlworksheet.Cells(lrow, lcol).value = lname) Then
                        'GetCPT(lrow, lcol, lrowcount, lname)
                        mylist1.Add(lname + "," + CType(lrow, String) + "," + CType(lcol, String) + "," + ldatabasefield)
                        Exit For
                    End If

                Next


            Next


            GetCPT1(mylist1, lrowcount)



            xlWorkBook.Close()
        Catch ex As Exception
            xlWorkBook.Close()
        End Try



    End Sub

    Protected Sub chkSelected_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim ck1 As System.Web.UI.WebControls.CheckBox = DirectCast(sender, System.Web.UI.WebControls.CheckBox)


        Dim dgi As DataGridItem = DirectCast(ck1.Parent.Parent, DataGridItem)

        Dim i As Integer = 0
        Dim j As Integer = 0

        For i = 0 To DataGrid2.Items.Count - 1
            If CType(DataGrid2.Items(i).FindControl("CheckBox1"), System.Web.UI.WebControls.CheckBox).Checked Then
                j = j + 1
            End If

            If (j > 3) Then
                CType(DataGrid2.Items(dgi.ItemIndex).FindControl("CheckBox1"), System.Web.UI.WebControls.CheckBox).Checked = False

                Label1.Text = "Only three check boxes of excel file can be selected at a time"

                CType(DataGrid2.Items(dgi.ItemIndex).FindControl("DropDownList1"), DropDownList).SelectedIndex = 0
                CType(DataGrid2.Items(dgi.ItemIndex).FindControl("DropDownList1"), DropDownList).Enabled = False
                CType(DataGrid2.Items(dgi.ItemIndex).FindControl("RequiredFieldValidator1"), RequiredFieldValidator).Enabled = False
                Exit Sub
            End If

        Next


        If (ck1.Checked = True) Then            
            CType(DataGrid2.Items(dgi.ItemIndex).FindControl("DropDownList1"), DropDownList).Enabled = True
            CType(DataGrid2.Items(dgi.ItemIndex).FindControl("RequiredFieldValidator1"), RequiredFieldValidator).Enabled = True
        Else
            CType(DataGrid2.Items(dgi.ItemIndex).FindControl("DropDownList1"), DropDownList).SelectedIndex = 0
            CType(DataGrid2.Items(dgi.ItemIndex).FindControl("DropDownList1"), DropDownList).Enabled = False
            CType(DataGrid2.Items(dgi.ItemIndex).FindControl("RequiredFieldValidator1"), RequiredFieldValidator).Enabled = False
            Label1.Text = ""
        End If


    End Sub

    Protected Sub DropDownList1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs)

        Dim i As Integer = 0
        Dim lflag As Boolean = False
        Dim ck1 As System.Web.UI.WebControls.DropDownList = DirectCast(sender, System.Web.UI.WebControls.DropDownList)

        Dim dgi As DataGridItem = DirectCast(ck1.Parent.Parent, DataGridItem)
        Dim a As String = ""
        a = CType(DataGrid2.Items(dgi.ItemIndex).FindControl("DropDownList1"), DropDownList).Text

        For i = 0 To DataGrid2.Items.Count - 1
            If (i <> dgi.ItemIndex) Then

                If (a = CType(DataGrid2.Items(i).FindControl("DropDownList1"), DropDownList).Text) Then
                    Label1.Text = "Only one datafield can be assign to one column of excel file"
                    CType(DataGrid2.Items(dgi.ItemIndex).FindControl("DropDownList1"), DropDownList).SelectedIndex = 0
                    lflag = True
                    Exit For
                End If

            End If

        Next

        If (lflag = False) Then
            Label1.Text = ""
        End If




    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim i As Integer
        Dim la As String = String.Empty


        Dim mylist As New ArrayList()



        Dim lt As New System.Data.DataTable

        For i = 0 To DataGrid2.Items.Count - 1

            If CType(DataGrid2.Items(i).FindControl("CheckBox1"), System.Web.UI.WebControls.CheckBox).Checked Then
                la = CType(DataGrid2.Items(i).FindControl("DropDownList1"), DropDownList).SelectedItem.Text

                mylist.Add(DataGrid2.Items(i).Cells(1).Text + "," + DataGrid2.Items(i).Cells(2).Text + "," + la)

            End If

        Next

        Traversing(mylist)

    End Sub

End Class
