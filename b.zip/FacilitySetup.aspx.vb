Imports Telerik.WebControls
Partial Class Billing_FacilitySetup
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim lUser As User
        Dim lIsAuthorize As Boolean
        Dim lUserRoles As UserRoles
        Page.Form.DefaultButton = btnSearch.UniqueID
        cmbFacility.Focus()
        If Not Page.IsPostBack Then
            lUser = CType(Session.Item("User"), User)
            lUserRoles = New UserRoles(lUser.ConnectionString)


            '********* Check User Validity ************
            lIsAuthorize = lUserRoles.CheckPageAuthorization(lUser.UserId, "EmployeeSetup.aspx")
            If Not lIsAuthorize Then
                Response.Redirect("unauthorization.aspx")
            End If

            '********* Load Authorized Tabs Only ***********


            'lUserRoles.LoadUserRights(tsRxEntry, lUser.UserId, "RxEntry.aspx")
            tsFacility.SelectedIndex = 0
            mpFacility.SelectedIndex = 0
            '*********************
            LoadData()
        End If
    End Sub


    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSearch.Click
        grdFacility.Rebind()
    End Sub
    Protected Sub ImgAddFacility_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImgAddFacility.Click
        Response.Redirect("AddNewFacility.aspx")
    End Sub

    Protected Sub grdFacility_DeleteCommand(ByVal source As Object, ByVal e As Telerik.WebControls.GridCommandEventArgs) Handles grdFacility.DeleteCommand

        Dim lFacility As New FacilityDB
        Dim lResult As Boolean
        Dim lCount As Integer


        With lFacility
            .FacilityID = CType(e.Item.Cells(2).Text, Integer)
        End With

        lCount = FacilityMethods.GetFacilityID(lFacility)

        If lCount > 0 Then
            'Response.Write("<script>alert('You can not delete this Facility.');return false;</script>")
            'Page.RegisterStartupScript("testscript", "<script language='javascript'>alert('You can not delete this Facility'); </script>")
            'Page.ClientScript.RegisterStartupScript([GetType], "MyScript", "<script>alert('hiiiii Shoyebaziz123 ')</script>")
            Page.ClientScript.RegisterStartupScript(Me.[GetType](), "alert", "showAlert();", True)

            'Me.RadAjaxManager1.Alert("Facility Added Successfully")
            'Me.RadAjaxManager1.Redirect("FacilitySetup.aspx")

            'Response.Write("<script>alert('You can not delete this Facility.');</script>")
            'Response.Write("<script>alert('Record Added successfully.');window.location.replace('FacilitySetup.aspx'); </script>")
            'Page.RegisterStartupScript("testscript", "<script language='javascript'>alert('You can not delete this Facility');return false </script>")
        Else
            lResult = FacilityMethods.DelteFacility(lFacility)
        End If





    End Sub

    Private Sub LoadData()
        'FacilityMethods.LoadFacilityNameCombo(cmbFacility, "")
    End Sub


    Protected Sub cmbFacility_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbFacility.ItemsRequested
        Dim lCond As String
        lCond = "And FacilityName Like '" & Utility.AdjustApostrophie(e.Text) & "%' "

        If (e.Text = "") Then
            Exit Sub
        End If

        FacilityMethods.LoadFacilityNameCombo(cmbFacility, lCond)
    End Sub

    Protected Sub grdFacility_ItemDataBound(ByVal sender As Object, ByVal e As Telerik.WebControls.GridItemEventArgs) Handles grdFacility.ItemDataBound
        If (e.Item.ItemType = GridItemType.Item Or e.Item.ItemType = GridItemType.AlternatingItem) Then
            Dim lDataItem As GridDataItem = CType(e.Item, GridDataItem)
            Dim lHyplnk As HyperLink = CType(lDataItem("Column2").Controls(0), HyperLink)
            Dim lID As String = lDataItem("FacilityID").Text
            Try
                


                If (e.Item.Cells(7).Text <> "" And (e.Item.Cells(7).Text.Length = 9)) Then


                    e.Item.Cells(7).Text = String.Format("{0:#####-####}", Double.Parse(e.Item.Cells(7).Text))
                End If

                If (e.Item.Cells(8).Text <> "" And e.Item.Cells(8).Text.Length > 7) Then

                    e.Item.Cells(8).Text = String.Format("{0:(###) ###-####}", Int64.Parse(e.Item.Cells(8).Text))

                End If










            Catch ex As Exception
                Dim myparent As Page = Me.Page
                Dim lLogID As String
                lLogID = ErrorLogMethods.LogError(ex, "FacilitySetup.aspx\Page_Load.CheckPageAuthorization")
                Response.Redirect("ErrorPage.aspx?LogID=" & lLogID, False)
            End Try

            lHyplnk.NavigateUrl = "EditFacility.aspx" + ElixirLibrary.Encryption.EncryptQueryString("FacilityID=" & lID)

        End If
    End Sub

    Protected Sub grdFacility_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdFacility.NeedDataSource
        pnlGrid.Visible = True
        If (cmbFacility.Text = "") Then
            grdFacility.DataSource = FacilityMethods.GetAllRecords(0)
            'grdFacility.DataBind()
        Else
            grdFacility.DataSource = FacilityMethods.GetAllRecords(cmbFacility.Value)
            ' grdFacility.DataBind()
        End If
    End Sub
End Class
