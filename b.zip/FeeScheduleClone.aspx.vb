
Partial Class Billing_FeeScheduleClone
    Inherits System.Web.UI.Page

    Dim mId As Integer = 0
    Dim mCPTlist
    Dim mDs As New DataSet


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim lString As String = ""
        If Me.grdInsurance.Rows.Count > 0 Then
            pnlInsurance.Visible = True
        Else
            pnlInsurance.Visible = False
        End If

        Try
            If Not IsPostBack Then
                Dim queryString As NameValueCollection
                queryString = Encryption.DecryptQueryString(Request.QueryString.ToString)
                lString = queryString("PID")
                mId = Convert.ToInt32(lString)

                'FillInsuranceTo()
                FillInsuranceFrom()
                Me.cmbInsuranceFrom.Enabled = False
                FilSelectedGrid()
                If grdSelectedInsurance.Rows.Count > 0 Then
                    pnlSelectedInsurance.Visible = True
                Else
                    pnlSelectedInsurance.Visible = False
                End If
            End If

        Catch ex As Exception

        End Try

        Me.btnCancel.OnClientClick = "javascript:window.history.go(-1);return false;"

    End Sub

    Sub FillInsuranceGrid()

        Dim lDS = New DataSet
        Dim lUser = New User
        'Dim lResultXmlData As String

        Try

            'lResultXmlData = IMOMethods.SearchCPT(txtCPTDesc.Text)
          
            lUser = CType(Session("User"), User)
            lDS = IMOMethods.SearchCPT(lUser, txtCPTDesc.Text)
            Try

                If (lDS IsNot Nothing) Then
                    ' Me.xmlSrcCPT.Data = lResultXmlData
                    Me.grdInsurance.DataSource = lDS
                    Me.grdInsurance.DataBind()
                Else
                    grdInsurance.DataSource = ""

                End If
                If grdInsurance.Rows.Count > 0 Then
                    Me.pnlInsurance.Visible = True
                Else
                    Me.pnlInsurance.Visible = False

                End If

            Catch ex As Exception
                grdInsurance.DataSource = ""

            End Try
        Catch ex As Exception

        End Try
    End Sub

    Sub FillInsuranceFrom()
        Dim lUser As User
        Dim lDS As DataSet
        Try
            lUser = CType(Session.Item("User"), User)
            lDS = FeeScheduleMethod.GetCompanyName(lUser, mId)

            cmbInsuranceFrom.DataSource = lDS.Tables(0).DefaultView
            cmbInsuranceFrom.DataTextField = "CompanyName"
            cmbInsuranceFrom.DataBind()

        Catch ex As Exception

        End Try
    End Sub

    Sub FilSelectedGrid()
        Dim lUser As User
        Dim lDS As DataSet
        Try
            lUser = CType(Session.Item("User"), User)
            lDS = FeeScheduleMethod.FillSelectedGrid(lUser, mId) 
            Session("DataSet") = lDS
            grdSelectedInsurance.DataSource = lDS.Tables(0).DefaultView
            grdSelectedInsurance.DataBind()
            If grdSelectedInsurance.Rows.Count > 0 Then
                pnlSelectedInsurance.Visible = True
            Else
                pnlSelectedInsurance.Visible = False
            End If
        Catch ex As Exception

        End Try
    End Sub
    Sub FillInsuranceTo()
        Dim lUser As User
        Dim lDS As DataSet
        Try
            lUser = CType(Session.Item("User"), User)
            lDS = FeeScheduleMethod.GetSelectedCmpnyNames(lUser, mId)

            cmbInsuranceTo.DataSource = lDS.Tables(0).DefaultView
            cmbInsuranceTo.DataTextField = "CompanyName"
            cmbInsuranceTo.DataValueField = "FavouriteInsuranceID"
            cmbInsuranceTo.DataBind()


        Catch ex As Exception

        End Try
    End Sub

    'Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click

    '    Dim lUser = CType(Session.Item("User"), User)
    '    Dim lBoolean As Boolean
    '    Try
    '        lBoolean = FeeScheduleMethod.SaveFeeSchedules(lUser, grdSelectedInsurance, cmbInsuranceTo.Value, cmbInsuranceTo.Text, 0, "SAVE")
    '        If (lBoolean = True) Then
    '            Page.RegisterStartupScript("testscript", "<script language='javascript'>alert('Your changes have been saved successfully');</script>")
    '        Else
    '            Page.RegisterStartupScript("testscript", "<script language='javascript'>alert('Error Occur While Saving');</script>")
    '        End If
    '    Catch ex As Exception

    '    End Try


    'End Sub

   

    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSearch.Click
        FillInsuranceGrid()

    End Sub

    Protected Sub grdSelectedInsurance_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles grdSelectedInsurance.PageIndexChanging
        grdSelectedInsurance.PageIndex = e.NewPageIndex
        GridRetain()
        grdSelectedInsurance.DataSource = Session("DataSet")
        grdSelectedInsurance.DataBind()
    End Sub


    Protected Sub grdSelectedInsurance_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles grdSelectedInsurance.RowCommand
        'If e.CommandName = "Delete" Then
        '    Dim oItem As GridViewRow = DirectCast(DirectCast(e.CommandSource, ImageButton).NamingContainer, GridViewRow)
        '    Dim RowIndex As Integer = oItem.RowIndex
        '    mDs = Session("DataSet")
        '    mDs.Tables(0).Rows(RowIndex).Delete()
        '    grdSelectedInsurance.DataSource = mDs
        '    grdSelectedInsurance.DataBind()
        '    'Session("DataSet") = grdSelectedInsurance.DataSource
        '    Session("DataSet") = mDs
        'End If
        If e.CommandName = "Delete" Then
            Dim oItem As GridViewRow = DirectCast(DirectCast(e.CommandSource, ImageButton).NamingContainer, GridViewRow)
            Dim RowIndex As Integer = oItem.RowIndex
            Dim lds As New DataSet
            Dim i As Integer = 0

            lds = Session("DataSet")


            For i = 0 To grdSelectedInsurance.Rows.Count - 1
                lds.Tables(0).Rows(i)("Fee") = IIf(CType(grdSelectedInsurance.Rows(i).Cells(2).FindControl("TextBox2"), TextBox).Text = "", 0, CType(grdSelectedInsurance.Rows(i).Cells(2).FindControl("TextBox2"), TextBox).Text)
            Next

            Dim rowdel As DataRow = lds.Tables(0).Rows(RowIndex)

            rowdel.Delete()

            lds.Tables(0).AcceptChanges()

            grdSelectedInsurance.DataSource = lds

            grdSelectedInsurance.DataBind()

            Session("DataSet") = lds
            If grdSelectedInsurance.Rows.Count > 0 Then
                pnlSelectedInsurance.Visible = True
            Else
                pnlSelectedInsurance.Visible = False
            End If
        End If

    End Sub

    Protected Sub grdSelectedInsurance_RowDeleting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewDeleteEventArgs) Handles grdSelectedInsurance.RowDeleting

    End Sub

    Protected Sub cmbInsuranceTo_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbInsuranceTo.ItemsRequested
        Dim lDS As DataSet
        Try
            lDS = FeeScheduleMethod.AutocompeteQueryForAddFeeSch(Session.Item("User"), e.Text)
            cmbInsuranceTo.DataSource = Nothing
            cmbInsuranceTo.DataSource = lDS.Tables(0).DefaultView
            cmbInsuranceTo.DataTextField = "CompanyName"
            cmbInsuranceTo.DataValueField = "FavouriteInsuranceID"
            cmbInsuranceTo.DataBind()
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub btnDeleted_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnDeleted.Click
        Dim chk As CheckBox
        Dim lds As DataSet
        lds = Session("DataSet")
        Dim lDataRow() As DataRow
        For Each row As GridViewRow In grdSelectedInsurance.Rows
            chk = CType(row.FindControl("chkFeeItem"), CheckBox)

            If chk.Checked = True Then

                lDataRow = lds.Tables(0).Select("CPTCode='" & row.Cells(1).Text.Replace("&nbsp;", "").Replace("amp;", "") & "' and Modifiers ='" & row.Cells(3).Text.Replace("&nbsp;", "").Replace("amp;", "") & "'")
                lDataRow(0).Delete()


            End If
        Next
        lds.Tables(0).AcceptChanges()
        grdSelectedInsurance.DataSource = lds
        grdSelectedInsurance.DataBind()

        Session("DataSet") = lds


    End Sub
   
    Protected Sub ibtnSave_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ibtnSave.Click
        Dim lUser As User = CType(Session.Item("User"), User)
        Dim lBoolean As Boolean
        Dim lGrid As New GridView
        GridRetain()
        lGrid.DataSource = Session("DataSet")
        lGrid.DataBind()
        Session("FeeScheduleID") = Nothing
        Dim lFeeSchedule As FeeSchedule = Nothing
        Try

            lFeeSchedule = New FeeSchedule(lUser.ConnectionString)

            If cmbInsuranceTo.Text.Equals("") Then
                Page.RegisterStartupScript("testscript", "<script language='javascript'>alert('Please select an inurance company');</script>")
                Return
            End If
            If cmbInsuranceTo.Text.Equals(cmbInsuranceFrom.Text) Then
                Page.RegisterStartupScript("testscript", "<script language='javascript'>alert('Please select a different insurance company');</script>")
                Return
            End If
            If lFeeSchedule.InsuranceCompanyExists(Me.cmbInsuranceTo.Value, Me.cmbInsuranceTo.Text.ToUpper) > 0 Then
                Session("FeeScheduleID") = lFeeSchedule.InsuranceCompanyExists(Me.cmbInsuranceTo.Value, Me.cmbInsuranceTo.Text.ToUpper)
            End If
           

            If Session("FeeScheduleID") IsNot Nothing Then
                Page.RegisterStartupScript("testscript", "<script language='javascript'>InsuranceCompanyConfirmation();</script>")
                Return

            Else
                If Not grdSelectedInsurance.Rows.Count > 0 Then
                    Page.RegisterStartupScript("testscript", "<script language='javascript'>alert('Please add fees');</script>")
                    Return
                End If
                lBoolean = FeeScheduleMethod.SaveFeeSchedules(lUser, lGrid, cmbInsuranceTo.Value, cmbInsuranceTo.Text, 0, "SAVE")
                Page.RegisterStartupScript("testscript", "<script language='javascript'>alert('Saved Successfully');window.location='FeeSchedule.aspx';</script>")
            End If


            If (lBoolean = True) Then
                'Page.RegisterStartupScript("testscript", "<script language='javascript'>alert('Your changes have been saved successfully');</script>")

                'Response.Redirect("FeeSchedule.aspx")

                Response.Write("<script>alert(' Your changes have been saved successfully');window.location='FeeSchedule.aspx';</script>")

            Else
                Page.RegisterStartupScript("testscript", "<script language='javascript'>alert('An error occured while saving');</script>")
            End If
        Catch ex As Exception

        End Try
    End Sub

    
    Protected Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnCancel.Click
        Response.Redirect("FeeSchedule.aspx")
    End Sub

    Protected Sub imgInc_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgInc.Click
        If txtPercent.Text.Equals("") Then
            Page.RegisterStartupScript("testscript", "<script language='javascript'>alert('Please insert applied amount');</script>")
            Return
        ElseIf Not grdSelectedInsurance.Rows.Count > 0 Then
            Page.RegisterStartupScript("testscript", "<script language='javascript'>alert('Not Applied');</script>")
        End If
        Dim lds As DataSet = Session("DataSet")
        Try
            If Me.cmbAply.SelectedItem.Text = "Increment" Then
                'For ind As Integer = 0 To grdSelectedInsurance.PageCount

                'Next
                For i As Integer = 0 To lds.Tables(0).Rows.Count - 1
                    Dim txtFees As Decimal = lds.Tables(0).Rows(i)("Fee")
                    Dim li As Decimal = txtFees + (txtFees * (txtPercent.Text / 100))

                    Dim lFormatedFees As String = li.ToString("####.##")
                    If lFormatedFees.Equals("") Then
                        lFormatedFees = "0.00"
                    End If
                    lds.Tables(0).Rows(i)("Fee") = lFormatedFees
                Next
                grdSelectedInsurance.DataSource = lds
                grdSelectedInsurance.DataBind()
                Session("DataSet") = lds
                'GridRetain()


                'For index As Integer = 0 To Me.grdSelectedInsurance.Rows.Count - 1
                '    Dim txtFees As TextBox = CType(Me.grdSelectedInsurance.Rows(index).FindControl("TextBox2"), TextBox)
                '    Dim li As Decimal = txtFees.Text + (txtFees.Text * (txtPercent.Text / 100))

                '    Dim lFormatedFees As String = li.ToString("####.##")
                '    If lFormatedFees.Equals("") Then
                '        lFormatedFees = "0.00"
                '    End If
                '    CType(Me.grdSelectedInsurance.Rows(index).FindControl("TextBox2"), TextBox).Text = lFormatedFees

                'Next
            Else

                For i As Integer = 0 To lds.Tables(0).Rows.Count - 1
                    Dim txtFees As Decimal = lds.Tables(0).Rows(i)("Fee")
                    Dim li As Decimal = txtFees - (txtFees * (txtPercent.Text / 100))

                    Dim lFormatedFees As String = li.ToString("####.##")
                    If lFormatedFees.Equals("") Then
                        lFormatedFees = "0.00"
                    End If
                    lds.Tables(0).Rows(i)("Fee") = lFormatedFees
                Next
                grdSelectedInsurance.DataSource = lds
                grdSelectedInsurance.DataBind()
                Session("DataSet") = lds

                'For index As Integer = 0 To Me.grdSelectedInsurance.Rows.Count - 1
                '    Dim txtFees As TextBox = CType(Me.grdSelectedInsurance.Rows(index).FindControl("TextBox2"), TextBox)
                '    Dim li As Decimal = txtFees.Text - (txtFees.Text * (txtPercent.Text / 100))

                '    Dim lFormatedFees As String = li.ToString("####.##")
                '    If lFormatedFees.Equals("") Then
                '        lFormatedFees = "0.00"
                '    End If
                '    CType(Me.grdSelectedInsurance.Rows(index).FindControl("TextBox2"), TextBox).Text = lFormatedFees

                'Next
            End If

            'grdSelectedInsurance.DataSource = lds
            'grdSelectedInsurance.DataBind()

            'Session("DataSet") = lds
        Catch ex As Exception

        End Try


    End Sub

   
    Protected Sub btnDown_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnDown.Click
        Dim cmbMod As Telerik.WebControls.RadComboBox

        Dim lDataTable As New DataTable()
        Dim cb As CheckBox
        GridRetain()

        Try

            lDataTable.Columns.Add("CPTCode")
            lDataTable.Columns.Add("Description")
            lDataTable.Columns.Add("Fee")
            lDataTable.Columns.Add("Modifiers")

            For Each row As GridViewRow In grdInsurance.Rows
                cb = CType(row.FindControl("chkItem"), CheckBox)
                cmbMod = CType(row.FindControl("cmbModifiers"), Telerik.WebControls.RadComboBox)
                If cb.Checked = True Then
                    Dim lDatarow As DataRow
                    lDatarow = lDataTable.NewRow()
                    lDatarow("CPTCode") = row.Cells(1).Text.Trim()
                    lDatarow("Description") = row.Cells(2).Text
                    lDatarow("Modifiers") = cmbMod.Text.Replace("&nbsp;", "").Replace("amp;", "").ToString()
                    lDatarow("Fee") = "0.00"
                    lDataTable.Rows.Add(lDatarow)
                End If
            Next
            If Session("DataSet") Is Nothing Then
                mDs.Tables.Add(lDataTable)
            Else
                mDs = Session("DataSet")
                Dim i As Integer

                For i = 0 To lDataTable.Rows.Count - 1
                    If mDs.Tables(0).Select("Modifiers ='" & lDataTable.Rows(i)("Modifiers").Replace("&nbsp;", "").Replace("amp;", "") & "' and CPTCode = '" & lDataTable.Rows(i)("CPTCode") & "'").Length > 0 Then
                        Page.RegisterStartupScript("testscript", "<script language='javascript'>alert('One of the selected record is already in the list');</script>")
                        Return

                    End If
                    mDs.Tables(0).Rows.Add(lDataTable.Rows(i)("CPTCode"), lDataTable.Rows(i)("Description"), lDataTable.Rows(i)("Fee"), lDataTable.Rows(i)("Modifiers").Replace("&nbsp;", "").Replace("amp;", "").ToString())
                Next
            End If


            Session("DataSet") = mDs
            grdSelectedInsurance.DataSource = mDs
            grdSelectedInsurance.DataBind()
            If grdSelectedInsurance.Rows.Count > 0 Then
                pnlSelectedInsurance.Visible = True
            Else
                pnlSelectedInsurance.Visible = False
            End If
        Catch ex As Exception

        End Try

    End Sub
    Protected Sub btnAddInsurance_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim lUser As User
        Dim lGrid As New GridView
        GridRetain()
        lGrid.DataSource = Session("DataSet")
        lGrid.DataBind()
        Try
            lUser = Session("User")
            If Not grdSelectedInsurance.Rows.Count > 0 Then
                Page.RegisterStartupScript("testscript", "<script language='javascript'>alert('Please add fees');</script>")
                Return
            End If
            If FeeScheduleMethod.SaveFeeSchedules(lUser, lGrid, cmbInsuranceTo.Value, cmbInsuranceTo.Text, Session("FeeScheduleID"), "Update") Then
                Page.RegisterStartupScript("testscript", "<script language='javascript'>alert('Saved Successfully');window.location='FeeSchedule.aspx';</script>")

            Else
                Page.RegisterStartupScript("testscript", "<script language='javascript'>alert('Save Failed');</script>")
            End If


        Catch ex As Exception

        End Try
    End Sub
    Public Sub GridRetain()
        Dim lDS As DataSet = Nothing
        Dim lDataTable As DataTable = Nothing
        lDS = New DataSet
        lDataTable = New DataTable
        Dim txtFee As TextBox
        lDS = Session("DataSet")
        lDataTable.Columns.Add("CPTCode")
        lDataTable.Columns.Add("Description")
        lDataTable.Columns.Add("Fee")
        lDataTable.Columns.Add("Modifiers")
        If Me.grdSelectedInsurance.Rows.Count > 0 Then
            For Each row As GridViewRow In Me.grdSelectedInsurance.Rows
                txtFee = CType(row.FindControl("TextBox2"), TextBox)
                Dim lDatarow() As DataRow
                Dim lDatarow1 As DataRow
                lDatarow1 = lDataTable.NewRow()
                lDatarow = lDS.Tables(0).Select("CPTCode='" & row.Cells(1).Text & "' and Modifiers ='" & row.Cells(3).Text.Replace("&nbsp;", "").Replace("amp;", "") & "'")
                lDatarow(0)("CPTCode") = row.Cells(1).Text.Replace("&nbsp;", "")
                lDatarow(0)("Description") = row.Cells(2).Text.Replace("&nbsp;", "")
                lDatarow(0)("Modifiers") = row.Cells(3).Text.Replace("&nbsp;", "").Replace("amp;", "")
                If txtFee.Text.Trim().Equals("") Then
                    lDatarow(0)("Fee") = "0.00"
                Else
                    lDatarow(0)("Fee") = txtFee.Text.Trim()
                End If


                lDS.Tables(0).AcceptChanges()
            Next




            Session("DataSet") = lDS
        End If
    End Sub
End Class
