
Partial Class Billing_AgingPrinterFriendly
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim lds As DataSet
        Dim myReportDocument
        Dim pGrid As New Telerik.WebControls.RadGrid
        Dim lUser As User

        lUser = CType(Session.Item("User"), User)

        Try
            If Session("Type") = "P" Then
                lds = Session("PatientDS")
                lds.Tables(0).TableName = "AgingPatient"
                myReportDocument = New CrystalDecisions.CrystalReports.Engine.ReportDocument()
                myReportDocument.Load(Server.MapPath("Reports\AgingPatientReport.rpt"))
                myReportDocument.SetDataSource(lds)
            End If
            If Session("Type") = "I" Then
                lds = Session("InsuranceDS")
                lds.Tables(0).TableName = "AgingInsurance"
                myReportDocument = New CrystalDecisions.CrystalReports.Engine.ReportDocument()
                myReportDocument.Load(Server.MapPath("Reports\AgingInsuranceReport.rpt"))
                myReportDocument.SetDataSource(lds)
            End If
           

            Dim lCrystalViewer As New CrystalDecisions.Web.CrystalReportViewer
            CrystalReportViewer1.DisplayGroupTree = False
            CrystalReportViewer1.HasCrystalLogo = False
            CrystalReportViewer1.HasViewList = True


            CrystalReportViewer1.Zoom(130)
            CrystalReportViewer1.BestFitPage = False
            CrystalReportViewer1.Width = New Unit("100%")
            CrystalReportViewer1.Height = New Unit("1500")
            CrystalReportViewer1.ReportSource = myReportDocument
            CrystalReportViewer1.DataBind()
            CrystalReportViewer1.PrintMode = CrystalDecisions.Web.PrintMode.ActiveX
        Catch ex As Exception

        End Try
    End Sub
End Class
