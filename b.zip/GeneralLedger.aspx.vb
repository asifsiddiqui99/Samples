Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports System.Data
Imports ElixirLibrary
Imports System.Data.SqlClient
Partial Class Billing_GeneralLedger
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim lDs As New DataSet
        Dim lUser As User = CType(HttpContext.Current.Session("User"), User)
        Dim lConnection As New Connection(lUser.ConnectionString)
        Dim lQuery As String = ""
        lQuery = "Select Date,Description,Debit,Credit,Balance from TempLedger "

        lDs = lConnection.ExecuteQuery(lQuery)

        CrystalReportViewer1.DisplayGroupTree = True
        CrystalReportViewer1.HasCrystalLogo = False
        CrystalReportViewer1.BestFitPage = True

        Dim myReportDocument As New ReportDocument()

        myReportDocument.Load(Server.MapPath("Reports/GeneralLedger.rpt"))
        myReportDocument.SetDataSource(lDs.Tables(0))

        CrystalReportViewer1.ReportSource = myReportDocument
        CrystalReportViewer1.DataBind()
    End Sub

End Class
