
Partial Class Billing_PreviewBlankSuperBill
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Request.QueryString("sid") Is Nothing Then
            Return
        End If
        txtSuperBillTemplateId.Text = Request.QueryString("sid").ToString()
        LoadSuperBillOrderInformation()

        If Not Page.IsPostBack Then
            LoadClinic()
            lblDateOfService.Text = Date.Today.Date
        End If

    End Sub

    Private Sub LoadClinic()
        Dim lUser As User
        Dim lClinic As ClinicDB
        Dim lState As StateDB
        Dim lPatientSuperBill As PatientSuperBill
        'Dim lFormatedSuperBillId As String

        lUser = CType(Session("User"), User)
        lClinic = ClinicMethods.GetClinic(lUser)
        lPatientSuperBill = New PatientSuperBill(lUser.ConnectionString)

        lblClinicName.Text = lClinic.ClinicName
        lblClinicAddress.Text = lClinic.AddressLine1
        lblClinicCity.Text = lClinic.City
        lblClinicZipCode.Text = lClinic.ZipCode
        lState = StateMethods.GetState(lClinic.StateId)
        lblClinicState.Text = lState.Abbr

        'lFormatedSuperBillId = lPatientSuperBill.GetUniqueId("")
        'lFormatedSuperBillId = "RxCure-SB-" & lFormatedSuperBillId.PadLeft(8, "0")
        'lblSuperBillID.Text = lFormatedSuperBillId
    End Sub

    Private Sub LoadSuperBillOrderInformation()
        Dim lUser As User
        Dim lSuperBill As SuperBill
        Dim lResult As Boolean

        lUser = CType(Session.Item("User"), User)


        lSuperBill = New SuperBill(lUser.ConnectionString)
        lSuperBill.SuperBill.SuperBillId = txtSuperBillTemplateId.Text
        lResult = lSuperBill.GetRecordByID()

        If Not lResult Then
            Return
        End If

        With lSuperBill.SuperBill
            'ICDSortBy + Order + CPTSortBy + Order 
            txtOrderBy.Text = lSuperBill.SuperBill.ICDSortBy & "|" & lSuperBill.SuperBill.ICDSortOrder & "|" & _
                                       lSuperBill.SuperBill.CPTSortBy & "|" & lSuperBill.SuperBill.CPTSortOrder
        End With
    End Sub

    
    Protected Sub grdCPT1_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdCPT1.NeedDataSource
        GenerateSuperBillMethods.LoadCPTGrid(grdCPT1, txtSuperBillTemplateId.Text, txtOrderBy.Text, 0)
    End Sub

    Protected Sub grdCPT2_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdCPT2.NeedDataSource
        GenerateSuperBillMethods.LoadCPTGrid(grdCPT2, txtSuperBillTemplateId.Text, txtOrderBy.Text, 1)
    End Sub

    Protected Sub grdCPT3_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdCPT3.NeedDataSource
        GenerateSuperBillMethods.LoadCPTGrid(grdCPT3, txtSuperBillTemplateId.Text, txtOrderBy.Text, 2)
    End Sub

    Protected Sub grdICD1_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdICD1.NeedDataSource
        GenerateSuperBillMethods.LoadICDGrid(grdICD1, txtSuperBillTemplateId.Text, txtOrderBy.Text, 0)
    End Sub

    Protected Sub grdICD2_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdICD2.NeedDataSource
        GenerateSuperBillMethods.LoadICDGrid(grdICD2, txtSuperBillTemplateId.Text, txtOrderBy.Text, 1)
    End Sub

    Protected Sub grdICD3_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdICD3.NeedDataSource
        GenerateSuperBillMethods.LoadICDGrid(grdICD3, txtSuperBillTemplateId.Text, txtOrderBy.Text, 2)
    End Sub

    
End Class
