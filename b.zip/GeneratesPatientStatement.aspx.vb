Imports Telerik.WebControls
Partial Class Billing_GeneratesPatientStatement
    Inherits System.Web.UI.Page

    Protected Sub btnsearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnsearch.Click
        Try
            'txtPatientID.Text = ""
            'btnBackPS.Visible = False
            grdClaim.Rebind()
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub grdClaim_ItemCommand(ByVal source As Object, ByVal e As Telerik.WebControls.GridCommandEventArgs) Handles grdClaim.ItemCommand
        ' Commented by Affan Toor | Date: 23-09-14 | Defect#: 2289 

        'If (e.CommandName = "ViewStatement") Then

        '    Dim lCurrent As String = e.Item.Cells(6).Text
        '    Dim l60 As String = e.Item.Cells(8).Text
        '    Dim l90 As String = e.Item.Cells(10).Text
        '    Dim lAbove As String = e.Item.Cells(12).Text
        '    Dim lTotalPR As String = e.Item.Cells(15).Text


        '    If (e.Item.Cells(6).Text.Contains("(")) Then                
        '        lCurrent = lCurrent.Replace("(", "")
        '        lCurrent = lCurrent.Replace(")", "")
        '        lCurrent = lCurrent * -1
        '    End If


        '    If (e.Item.Cells(8).Text.Contains("(")) Then
        '        l60 = e.Item.Cells(8).Text
        '        l60 = l60.Replace("(", "")
        '        l60 = l60.Replace(")", "")
        '        l60 = l60 * -1
        '    End If


        '    If (e.Item.Cells(10).Text.Contains("(")) Then                
        '        l90 = l90.Replace("(", "")
        '        l90 = l90.Replace(")", "")
        '        l90 = l90 * -1
        '    End If


        '    If (e.Item.Cells(12).Text.Contains("(")) Then                
        '        lAbove = lAbove.Replace("(", "")
        '        lAbove = lAbove.Replace(")", "")
        '        lAbove = lAbove * -1
        '    End If

        '    If (e.Item.Cells(15).Text.Contains("(")) Then                
        '        lTotalPR = lTotalPR.Replace("(", "")
        '        lTotalPR = lTotalPR.Replace(")", "")
        '        lTotalPR = lTotalPR * -1
        '    End If



        '    ScriptManager.RegisterStartupScript(Page, Page.GetType(), "report", "<script>window.open('" & Page.ResolveUrl("PatientStatementReport.aspx" & ElixirLibrary.Encryption.EncryptQueryString("PatientID=" + e.Item.Cells(3).Text + _
        '              "&Current=" + lCurrent + "&60=" + l60 _
        '            + "&90=" + l90 + "&Above=" + lAbove + _
        '            "&TotalPR=" + lTotalPR)) & " ' ,'','toolbar=no width=1100 height=800,left=150,top=150,scrollbars=1,menubar=1,resizable=1'); </script>", False)





        'End If
    End Sub

    Protected Sub grdClaim_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdClaim.NeedDataSource
        Dim lds As DataSet = Nothing
        Dim lcondition As String = String.Empty
        Dim lorderby As String = String.Empty
        Dim lDv As DataView
        Dim lFilter As String = ""

        Try

            'If (Page.IsPostBack = True) Then



            If cmbPatient.Text.Trim <> "" Then

                If cmbPatient.Text.Contains(",") Then
                    Dim lPatientName As String() = cmbPatient.Text.Split(","c)
                    txtPatientLastName.Text = lPatientName(0) & ",%" & lPatientName(1)
                Else
                    txtPatientLastName.Text = cmbPatient.Text
                End If

            Else
                txtPatientLastName.Text = ""
            End If

            If Not (txtPatientLastName.Text = "") Then
                lcondition = " And PatientName like '" & txtPatientLastName.Text & "%'"
            End If

            If Not (txtGuarantorLastName.Text = "") Then
                lcondition = lcondition & " And GuarantorName like '" & txtGuarantorLastName.Text & "%'"
            End If

            'If (txtPatientID.Text <> "") Then
            '    lcondition = lcondition & " and PatientId = '" & txtPatientID.Text & "' "
            'End If

            If (cmbOrderBy.SelectedItem.Text = "Patient") Then
                lorderby = " order by PatientName"
            ElseIf (cmbOrderBy.SelectedItem.Text = "Patient Responsibility") Then
                'lorderby = " order by (sum(RANGES.PrThirty)+sum(RANGES.PrSixty)+sum(RANGES.PrNinty)+sum(RANGES.PrAbove)) desc"
                lorderby = " order by TotalPR desc"
            ElseIf (cmbOrderBy.SelectedItem.Text = "Aging") Then
                'lorderby = " order by sum(RANGES.PrAbove) desc"
                lorderby = " order by PrAbove desc"
            End If


            lds = PatientMethodsExtended.GetPatientStatement(lcondition, lorderby)


            If (lds IsNot Nothing AndAlso lds.Tables(0).Rows.Count > 0) Then

                lDv = New DataView(lds.Tables(0))
                lFilter = "TotalPR>0"
                lDv.RowFilter = lFilter
                grdClaim.DataSource = lDv
            Else
                grdClaim.DataSource = lds
            End If



            'End If


        Catch ex As Exception

        End Try
    End Sub

    Protected Sub grdClaim_ItemDataBound(ByVal sender As Object, ByVal e As Telerik.WebControls.GridItemEventArgs) Handles grdClaim.ItemDataBound

        If (e.Item.ItemType = Telerik.WebControls.GridItemType.Item Or e.Item.ItemType = Telerik.WebControls.GridItemType.AlternatingItem) Then

            'e.Item.Cells(6).Text = Math.Round(Convert.ToDouble(e.Item.Cells(6).Text), 2)
            If (e.Item.Cells(6).Text < 0) Then
                e.Item.Cells(6).Text = e.Item.Cells(6).Text * -1
                e.Item.Cells(6).Text = "(" & e.Item.Cells(6).Text & ")"
            End If
            'e.Item.Cells(7).Text = Math.Round(Convert.ToDouble(e.Item.Cells(7).Text), 2)
            If (e.Item.Cells(7).Text < 0) Then
                e.Item.Cells(7).Text = e.Item.Cells(7).Text * -1
                e.Item.Cells(7).Text = "(" & e.Item.Cells(7).Text & ")"
            End If
            'e.Item.Cells(8).Text = Math.Round(Convert.ToDouble(e.Item.Cells(8).Text), 2)
            If (e.Item.Cells(8).Text < 0) Then
                e.Item.Cells(8).Text = e.Item.Cells(8).Text * -1
                e.Item.Cells(8).Text = "(" & e.Item.Cells(8).Text & ")"
            End If
            'e.Item.Cells(9).Text = Math.Round(Convert.ToDouble(e.Item.Cells(9).Text), 2)
            If (e.Item.Cells(9).Text < 0) Then
                e.Item.Cells(9).Text = e.Item.Cells(9).Text * -1
                e.Item.Cells(9).Text = "(" & e.Item.Cells(9).Text & ")"
            End If
            'e.Item.Cells(10).Text = Math.Round(Convert.ToDouble(e.Item.Cells(10).Text), 2)
            If (e.Item.Cells(10).Text < 0) Then
                e.Item.Cells(10).Text = e.Item.Cells(10).Text * -1
                e.Item.Cells(10).Text = "(" & e.Item.Cells(10).Text & ")"
            End If
            'e.Item.Cells(11).Text = Math.Round(Convert.ToDouble(e.Item.Cells(11).Text), 2)
            If (e.Item.Cells(11).Text < 0) Then
                e.Item.Cells(11).Text = e.Item.Cells(11).Text * -1
                e.Item.Cells(11).Text = "(" & e.Item.Cells(11).Text & ")"
            End If
            'e.Item.Cells(12).Text = Math.Round(Convert.ToDouble(e.Item.Cells(12).Text), 2)
            If (e.Item.Cells(12).Text < 0) Then
                e.Item.Cells(12).Text = e.Item.Cells(12).Text * -1
                e.Item.Cells(12).Text = "(" & e.Item.Cells(12).Text & ")"
            End If
            'e.Item.Cells(13).Text = Math.Round(Convert.ToDouble(e.Item.Cells(13).Text), 2)
            If (e.Item.Cells(13).Text < 0) Then
                e.Item.Cells(13).Text = e.Item.Cells(13).Text * -1
                e.Item.Cells(13).Text = "(" & e.Item.Cells(13).Text & ")"
            End If
            'e.Item.Cells(14).Text = Math.Round(Convert.ToDouble(e.Item.Cells(14).Text), 2)
            If (e.Item.Cells(14).Text < 0) Then
                e.Item.Cells(14).Text = e.Item.Cells(14).Text * -1
                e.Item.Cells(14).Text = "(" & e.Item.Cells(14).Text & ")"
            End If
            'e.Item.Cells(15).Text = Math.Round(Convert.ToDouble(e.Item.Cells(15).Text), 2)
            If (e.Item.Cells(15).Text < 0) Then
                e.Item.Cells(15).Text = e.Item.Cells(15).Text * -1
                e.Item.Cells(15).Text = "(" & e.Item.Cells(15).Text & ")"
            End If

            ' Start => Added by: Affan Toor | Date: 23-09-14 | Defect#: 2289 

            Dim lCurrent As String = e.Item.Cells(6).Text
            Dim l60 As String = e.Item.Cells(8).Text
            Dim l90 As String = e.Item.Cells(10).Text
            Dim lAbove As String = e.Item.Cells(12).Text
            Dim lTotalPR As String = e.Item.Cells(15).Text


            If (e.Item.Cells(6).Text.Contains("(")) Then
                lCurrent = lCurrent.Replace("(", "")
                lCurrent = lCurrent.Replace(")", "")
                lCurrent = lCurrent * -1
            End If


            If (e.Item.Cells(8).Text.Contains("(")) Then
                l60 = e.Item.Cells(8).Text
                l60 = l60.Replace("(", "")
                l60 = l60.Replace(")", "")
                l60 = l60 * -1
            End If


            If (e.Item.Cells(10).Text.Contains("(")) Then
                l90 = l90.Replace("(", "")
                l90 = l90.Replace(")", "")
                l90 = l90 * -1
            End If


            If (e.Item.Cells(12).Text.Contains("(")) Then
                lAbove = lAbove.Replace("(", "")
                lAbove = lAbove.Replace(")", "")
                lAbove = lAbove * -1
            End If

            If (e.Item.Cells(15).Text.Contains("(")) Then
                lTotalPR = lTotalPR.Replace("(", "")
                lTotalPR = lTotalPR.Replace(")", "")
                lTotalPR = lTotalPR * -1
            End If

            Dim imgView As Image = CType(e.Item.FindControl("imgView"), Image)

            imgView.Attributes.Add("Onclick", "window.open('" & Page.ResolveUrl("PatientStatementReport.aspx" & ElixirLibrary.Encryption.EncryptQueryString("PatientID=" + e.Item.Cells(3).Text + _
                      "&Current=" + lCurrent + "&60=" + l60 _
                    + "&90=" + l90 + "&Above=" + lAbove + _
                    "&TotalPR=" + lTotalPR)) & " ' ,'winprn','toolbar=no width=1100 height=800,left=150,top=150,scrollbars=1,menubar=1,resizable=1'); return false;")
            ' End => Added by: Affan Toor | Date: 23-09-14 | Defect#: 2289 

        End If



    End Sub

    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        Try


            Dim lUser As User = CType(Session("User"), User)
            Dim lUnselectcount As Integer = 0
            Dim lErrorcount As Integer = 0
            Dim lSuccessCount As Integer = 0

            Dim li As Integer = 0
            Dim lrecordcount As Integer = 0
            Dim lOutstandingbalance As Integer = 0
            Dim lPatientID As Integer
            Dim lGuarantorID As Integer
            Dim lPatientName As String
            Dim lTotalAmount As Double
            Dim lInsurancePending As Double
            Dim lTotalDue As Double
            Dim lCurrent As Double
            Dim l30 As Double
            Dim l60 As Double
            Dim l90 As Double
            Dim lresult As Boolean






            For li = 0 To grdClaim.Items.Count - 1
                Try
                    If (grdClaim.Items(li).Selected) Then

                        lPatientID = grdClaim.Items(li).Cells(3).Text
                        lGuarantorID = IIf(grdClaim.Items(li).Cells(18).Text = "", 0, grdClaim.Items(li).Cells(18).Text)
                        lPatientName = grdClaim.Items(li).Cells(4).Text
                        lTotalAmount = grdClaim.Items(li).Cells(14).Text
                        lInsurancePending = grdClaim.Items(li).Cells(14).Text - grdClaim.Items(li).Cells(15).Text
                        lTotalDue = grdClaim.Items(li).Cells(15).Text
                        lCurrent = grdClaim.Items(li).Cells(6).Text
                        l30 = grdClaim.Items(li).Cells(8).Text
                        l60 = grdClaim.Items(li).Cells(10).Text
                        l90 = grdClaim.Items(li).Cells(12).Text

                        If (lTotalDue > 0) Then
                            lrecordcount = lrecordcount + 1
                            lresult = PatientStatementsMethod.GenerateStatement(lPatientID, lGuarantorID, lPatientName, _
                                                    lTotalAmount, lInsurancePending, _
                                                     lTotalDue, lCurrent, l30, _
                                                    l60, l90, lUser, lrecordcount, grdClaim.SelectedItems.Count)

                            If (lresult) Then
                                lSuccessCount = lSuccessCount + 1
                            Else
                                lErrorcount = lErrorcount + 1
                            End If

                        Else
                            lOutstandingbalance = lOutstandingbalance + 1
                        End If

                    Else
                        lUnselectcount = lUnselectcount + 1
                    End If

                Catch ex As Exception
                    lErrorcount = lErrorcount + 1
                    Continue For

                End Try
            Next

            If (lUnselectcount = grdClaim.Items.Count) Then
                Response.Write("<script>alert('Atleast one record should be selected');</script>")
                Exit Sub
            End If

            If (lOutstandingbalance = grdClaim.SelectedItems.Count) Then
                Response.Write("<script>alert('There is no outstanding balance of selected patient(s)');</script>")
                Exit Sub
            End If


            If (lErrorcount > 0) Then
                Dim lMessageString As String = "Error generating " & lErrorcount & " out of " & grdClaim.SelectedItems.Count & " patient statements"
                Response.Write("<script>alert('" & lMessageString & "');</script>")

            ElseIf (lErrorcount = 0) Then
                Response.Write("<script>alert('Patient statement(s) generated successfully');</script>")
            End If


            grdClaim.Rebind()



        Catch ex As Exception

        End Try


    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim queryString As NameValueCollection = Nothing
        Dim lPatientID As String
        Try
            If IsPostBack = False Then
                If (Request.QueryString.Count > 0) Then
                    queryString = Encryption.DecryptQueryString(Request.QueryString.ToString())
                    If (queryString IsNot Nothing) Then
                        lPatientID = queryString("id").ToString
                        txtPatientID.Text = lPatientID
                        btnBackPS.Visible = True
                        Dim lPatient As New PatientDBExtended
                        Dim lUser As User
                        lUser = CType(Session.Item("User"), User)
                        lPatient = PatientMethods.LoadPatientsById(lPatientID, lUser)
                        cmbPatient.Text = lPatient.LastName & "," & lPatient.FirstName
                        grdClaim.Rebind()
                    End If
                End If
            End If
            Me.cmbPatient.Focus()
            Me.Form.DefaultButton = Me.btnsearch.UniqueID
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub btnMirror_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnMirror.Click

        Dim newWindow As RadWindow
        Try
            newWindow = New RadWindow()
            If (cmbPatient.Text.ToString.Split(",").Length = 1) Then
                newWindow.NavigateUrl = "PatientSearch.aspx?srch=" & Utility.AdjustApostrophie(Me.cmbPatient.Text.ToString.Split(",")(0)) & "|" & "" & ""
            ElseIf (cmbPatient.Text.ToString.Split(",").Length > 1) Then
                newWindow.NavigateUrl = "PatientSearch.aspx?srch=" & Utility.AdjustApostrophie(Me.cmbPatient.Text.ToString.Split(",")(0)) & "|" & Me.cmbPatient.Text.ToString.Split(",")(1) & ""
            Else

            End If
            newWindow.ID = "rwPrimaryInsurer"
            newWindow.VisibleOnPageLoad = True
            newWindow.Top = 220
            newWindow.Left = 280
            newWindow.Width = Unit.Pixel(697)
            newWindow.Height = Unit.Pixel(400)
            newWindow.VisibleTitlebar = False
            newWindow.VisibleStatusbar = False
            newWindow.BorderStyle = BorderStyle.Solid
            newWindow.ReloadOnShow = True
            newWindow.BackColor = Drawing.Color.Transparent
            newWindow.ClientCallBackFunction = "PatientSearchCallBackFunction"
            newWindow.Enabled = True
            newWindow.Visible = True
            rwmSuperBill.Windows.Add(newWindow)

        Catch ex As Exception
            Dim lLogID As String = String.Empty
            lLogID = ErrorLogMethods.LogError(ex, " Billing_GeneratesPatientStatement.aspx\btnMirror_Click() ")
            Response.Redirect("~/ErrorPage.aspx?LogID=" & lLogID, False)
        End Try


    End Sub

    Protected Sub btnBackPS_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnBackPS.Click
        Dim lPatientID As String
        Try
            lPatientID = ElixirLibrary.Encryption.EncryptQueryString("id=" & txtPatientID.Text)
            Response.Redirect("selectpatient.aspx" & lPatientID)
        Catch ex As Exception

        End Try
    End Sub
End Class
