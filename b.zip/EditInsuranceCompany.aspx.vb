Imports Telerik.WebControls
Partial Class Billing_EditInsuranceCompany
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If (Not Page.IsPostBack) Then

            Dim lIsAuthorize As Boolean
            Dim lUser As User
            Dim lUserRoles As UserRoles

            lUser = CType(Session.Item("User"), User)
            lUserRoles = New UserRoles(lUser.ConnectionString)

            '********* Check User Validity ************
            lIsAuthorize = lUserRoles.CheckPageAuthorization(lUser.UserId, "EmployeeSetup.aspx")
            If Not lIsAuthorize Then
                Response.Redirect("unauthorization.aspx")
            End If

            '********* Load Authorized Tabs Only ***********


            'lUserRoles.LoadUserRights(tsRxEntry, lUser.UserId, "RxEntry.aspx")
            tsEmployee.SelectedIndex = 0
            mpEmployee.SelectedIndex = 0
            '*********************

            StateMethods.Load_States(cmbState, lUser)
            cmbState.Items.Insert(0, New RadComboBoxItem("All"))

            LoadData()
            
        End If
    End Sub

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSave.Click
        Dim lUser As User
        lUser = CType(Session.Item("User"), User)


        Dim lInsurance As New InsuranceDB
        Dim lResult As Boolean



        With lInsurance

            .CompanyName = txtCompany.Text
            .PayerID = txtPayerID.Text
            .AddressLine1 = Utility.AdjustApostrophie(txtAddressLine1.Text)
            .AddressLine2 = Utility.AdjustApostrophie(txtAddressLine2.Text)
            .City = Utility.AdjustApostrophie(txtCity.Text)
            .ZipCode = mtbZipCode.Text
            .ContactName = Utility.AdjustApostrophie(txtContactName.Text)
            .WorkPhone = mtbWorkPhone.Text
            .Fax = mtbFax.Text
            .Email = txtEmail.Text
            .State = cmbState.Text
            .InsuranceType = cmbInsuranceType.Text
            .BillType = cmbBillType.Text
            .FavouriteInsuranceID = ViewState("FavReqID")

        End With

        lResult = InsuranceMethods.EditInsurance(lInsurance)

        If (lResult = True) Then
            Me.RadAjaxManager1.Alert("Insurance Updated Successfully")
            Me.RadAjaxManager1.Redirect("InsuranceSetup.aspx")
            'lblMessage.Text = "Insurance Updated Successfully"
        End If
    End Sub

    Protected Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnCancel.Click
        Response.Redirect("InsuranceSetup.aspx")
    End Sub

    Protected Sub cmbState_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbState.ItemsRequested
        InsuranceMethods.GetCompanyName(cmbState, "")
        cmbState.Items.Insert(0, New RadComboBoxItem("All"))
    End Sub

    Private Sub LoadData()
        Dim lFavReqID As Integer
        Dim lds As New DataSet
        'lFavReqID = Request.QueryString.Get("eid").ToString()

        Dim queryString As NameValueCollection = Encryption.DecryptQueryString(Request.QueryString.ToString())
        lFavReqID = queryString("eid")

        lds = InsuranceMethods.GetInsuranceRecords(" And FavouriteInsuranceID=" & lFavReqID)
        ViewState("FavReqID") = lFavReqID
        Dim lUser As User
        lUser = CType(Session.Item("User"), User)

        With lds.Tables(0).Rows(0)
            txtCompany.Text = .Item("CompanyName")
            txtPayerID.Text = .Item("PayerID")
            txtAddressLine1.Text = .Item("AddressLine1")
            txtAddressLine2.Text = .Item("AddressLine2")
            txtCity.Text = .Item("City")
            mtbZipCode.Text = .Item("ZipCode")
            txtContactName.Text = .Item("ContactName")
            mtbWorkPhone.Text = .Item("WorkPhone")
            mtbFax.Text = .Item("Fax")
            txtEmail.Text = .Item("Email")
            cmbState.SelectedIndex = cmbState.FindItemIndexByText(.Item("State"))
            cmbInsuranceType.SelectedIndex = cmbInsuranceType.FindItemIndexByText(.Item("InsuranceType"))
            cmbBillType.Text = .Item("BillType")

        End With


    End Sub

End Class
