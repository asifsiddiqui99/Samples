Imports Telerik.WebControls
Partial Class Billing_VisitSummarySearch
    Inherits System.Web.UI.Page

    Protected Sub btnsearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnsearch.Click
        grdSearch.Visible = True
        grdSearch.Rebind()

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim queryString As NameValueCollection = Nothing
        Dim lPatientID As String
        Try
            If (Page.IsPostBack = False) Then
                dpTransactionPeriodFrom.SelectedDate = Date.Now.AddMonths(-6)
                dpTransactionPeriodTo.SelectedDate = Date.Now
                If (Request.QueryString.Count > 0) Then
                    queryString = Encryption.DecryptQueryString(Request.QueryString.ToString())
                    If (queryString IsNot Nothing) Then
                        lPatientID = queryString("id").ToString
                        txtPatientID.Text = lPatientID
                        btnBackPS.Visible = True
                        Dim lPatient As New PatientDBExtended
                        Dim lUser As User
                        lUser = CType(Session.Item("User"), User)
                        lPatient = PatientMethods.LoadPatientsById(lPatientID, lUser)
                        cmbPatient.Text = lPatient.LastName & "," & lPatient.FirstName
                        cmbPatient.Value = lPatient.PatientID
                        txtHiddenPatientId.Text = lPatient.PatientID
                        'LoadGrid(txtHiddenPatientId.Text)
                    End If
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub grdSearch_ItemDataBound(ByVal sender As Object, ByVal e As Telerik.WebControls.GridItemEventArgs) Handles grdSearch.ItemDataBound
        Dim lDate As Date
        Dim lVisitID As String = ""
        Dim lDataItem As Telerik.WebControls.GridDataItem
        Dim lLink As HyperLink
        Dim lStrAmount As String
        Dim lBalance As Double

        Try
            If (e.Item.ItemType = Telerik.WebControls.GridItemType.Item Or e.Item.ItemType = Telerik.WebControls.GridItemType.AlternatingItem) Then
                lDataItem = CType(e.Item, Telerik.WebControls.GridDataItem)
                Dim lItem As GridDataItem = CType(e.Item, GridDataItem)
                lDate = e.Item.Cells(3).Text
                e.Item.Cells(3).Text = lDate.Date

                lLink = CType(lItem("VISITID").Controls(0), HyperLink)
                lLink.NavigateUrl = "VisitSummary.aspx" + ElixirLibrary.Encryption.EncryptQueryString("sid=" & e.Item.Cells(2).Text)

                lDate = e.Item.Cells(5).Text
                e.Item.Cells(5).Text = lDate.Date

                ' lBalance = CType(e.Item.Cells(9).Text, Double) - (CType(e.Item.Cells(10).Text, Double) + CType(e.Item.Cells(11).Text, Double)) + CType(e.Item.Cells(12).Text, Double)
                lBalance = e.Item.Cells(13).Text

                lStrAmount = e.Item.Cells(10).Text
                If (lStrAmount.Substring(0, 1) = "-") Then
                    lStrAmount = "(" & lStrAmount.Remove(0, 1) & ")"
                    e.Item.Cells(10).Text = lStrAmount
                End If
                lStrAmount = e.Item.Cells(11).Text
                If (lStrAmount.Substring(0, 1) = "-") Then
                    lStrAmount = "(" & lStrAmount.Remove(0, 1) & ")"
                    e.Item.Cells(11).Text = lStrAmount
                End If
                lStrAmount = e.Item.Cells(12).Text
                If (lStrAmount.Substring(0, 1) = "-") Then
                    lStrAmount = "(" & lStrAmount.Remove(0, 1) & ")"
                    e.Item.Cells(12).Text = lStrAmount
                End If

                If (lBalance.ToString.Substring(0, 1) = "-") Then
                    lStrAmount = "(" & lBalance.ToString("##0.00").Remove(0, 1) & ")"
                    e.Item.Cells(13).Text = lStrAmount
                Else
                    e.Item.Cells(13).Text = lBalance.ToString("##0.00")
                End If

                If e.Item.Cells(13).Text = "0.00" Or (lBalance.ToString.Substring(0, 1) = "-") Then
                    e.Item.Cells(15).Text = "Paid"
                Else
                    e.Item.Cells(15).Text = "Unpaid"
                End If

                lLink = CType(lItem("PatientNameLink1").Controls(0), HyperLink)
                lLink.NavigateUrl = "ApplyPayment.aspx" + ElixirLibrary.Encryption.EncryptQueryString("VisitID=" & e.Item.Cells(2).Text)
                lLink.ImageUrl = "../Images/adjustment.gif"
                lLink.ToolTip = "Apply Adjustment"

            End If
        Catch ex As Exception

        End Try


    End Sub

    Protected Sub btnMirror_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnMirror.Click
        Dim newWindow As RadWindow
        Try
            newWindow = New RadWindow()
            If (cmbPatient.Text.ToString.Split(",").Length = 1) Then
                newWindow.NavigateUrl = "PatientSearch.aspx?srch=" & Utility.AdjustApostrophie(Me.cmbPatient.Text.ToString.Split(",")(0)) & "|" & "" & ""
            ElseIf (cmbPatient.Text.ToString.Split(",").Length > 1) Then
                newWindow.NavigateUrl = "PatientSearch.aspx?srch=" & Utility.AdjustApostrophie(Me.cmbPatient.Text.ToString.Split(",")(0)) & "|" & Me.cmbPatient.Text.ToString.Split(",")(1) & ""
            Else

            End If
            newWindow.ID = "rwPrimaryInsurer"
            newWindow.VisibleOnPageLoad = True
            newWindow.Top = 220
            newWindow.Left = 280
            newWindow.Width = Unit.Pixel(697)
            newWindow.Height = Unit.Pixel(400)
            newWindow.VisibleTitlebar = False
            newWindow.VisibleStatusbar = False
            newWindow.BorderStyle = BorderStyle.Solid
            newWindow.ReloadOnShow = True
            newWindow.BackColor = Drawing.Color.Transparent
            newWindow.ClientCallBackFunction = "PatientSearchCallBackFunction"
            newWindow.Enabled = True
            newWindow.Visible = True
            rwmSuperBill.Windows.Add(newWindow)
        Catch ex As Exception
            Dim lLogID As String = String.Empty
            lLogID = ErrorLogMethods.LogError(ex, " Billing_PatientLedgerPage.aspx\btnMirror_Click() ")
            Response.Redirect("~/ErrorPage.aspx?LogID=" & lLogID, False)
        End Try
    End Sub

    Protected Sub btnGetReport_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnGetReport.Click
        Dim lFromDate As Date
        Dim lToDate As Date

        Try
            If (grdSearch.Items.Count > 0) Then
                lFromDate = dpTransactionPeriodFrom.SelectedDate
                lToDate = dpTransactionPeriodTo.SelectedDate.Value.Date

                Dim lEncryptedPart As String = ElixirLibrary.Encryption.EncryptQueryString("value=" & txtHiddenPatientId.Text & "|" & lFromDate & "|" & lToDate & "|" & Me.txtHiddenFavInsId.Text & "|" & Me.txtHiddenProviderId.Text & "|" & Me.txtHiddenVisitStatus.Text)
                Dim lScript As String = "window.open('VisitSummarySearchReport.aspx" & lEncryptedPart & "','winPrn','toolbar=0,scrollbars=1,location=0,statusbar=0,menubar=0,resizable=1,width=1000,height=800,left=200,top=80');"
                'Page.RegisterStartupScript("calllScript", lScript)
                Response.Write("<script>" & lScript & ";</script>")
            End If
        Catch ex As Exception
            Dim lLogID As String = String.Empty
            lLogID = ErrorLogMethods.LogError(ex, " Billing_VisitSummarySearch.aspx\btnGetReport_Click")
            Response.Redirect("~/ErrorPage.aspx?LogID=" & lLogID, False)
        End Try

    End Sub

    Protected Sub btnBackPS_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnBackPS.Click
        Dim lPatientID As String
        Try
            lPatientID = ElixirLibrary.Encryption.EncryptQueryString("id=" & txtPatientID.Text)
            Response.Redirect("selectpatient.aspx" & lPatientID)
        Catch ex As Exception

        End Try
    End Sub
    Public Sub LoadGrid(ByVal pPatientID As String)
        Dim lUser As User
        Dim lDS As New DataSet

        Dim lFavInsuranceID As String = ""
        Dim lProviderID As String = ""
        Dim lVisitStatus As String = ""
        Try


            lUser = CType(Session("User"), User)
            txtHiddenPatientId.Text = cmbPatient.Value
            Me.txtHiddenFavInsId.Text = Me.cmbPayer.Value
            Me.txtHiddenProviderId.Text = Me.cmbProvider.Value
            Me.txtHiddenVisitStatus.Text = Me.cmbVisitStatus.Value

            lFavInsuranceID = Me.txtHiddenFavInsId.Text
            lProviderID = Me.txtHiddenProviderId.Text
            lVisitStatus = Me.txtHiddenVisitStatus.Text


            lDS = PatientSuperBillMethods.LoadVisitSummarySearch(dpTransactionPeriodFrom.SelectedDate.Value, dpTransactionPeriodTo.SelectedDate.Value, pPatientID, lFavInsuranceID, lProviderID, lVisitStatus)
            grdSearch.DataSource = lDS
            'grdSearch.DataBind()
            If lDS.Tables(0).Rows.Count > 0 Then
                btnGetReport.ImageUrl = "../Imgbutton/btngetreport-off.gif"
                btnGetReport.Enabled = True
            Else
                btnGetReport.ImageUrl = "../Imgbutton/btnGetReport-disable.gif"
                btnGetReport.Enabled = False

            End If


        Catch ex As Exception

        End Try
    End Sub

    Protected Sub cmbPatient_SelectedIndexChanged(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxSelectedIndexChangedEventArgs) Handles cmbPatient.SelectedIndexChanged
        Try
            txtHiddenPatientId.Text = cmbPatient.Value
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub grdSearch_NeedDataSource(source As Object, e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdSearch.NeedDataSource
        'txtPatientID.Text = ""
        'btnBackPS.Visible = False
        If grdSearch.Visible Then
            If (cmbPatient.Text <> "") Then
                LoadGrid(txtHiddenPatientId.Text)
            Else
                LoadGrid("")
            End If
        End If

    End Sub
End Class
