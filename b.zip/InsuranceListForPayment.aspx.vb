
Imports Telerik.WebControls


Partial Class InsuranceListForPayment
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If (Not Page.IsPostBack) Then
            Dim lInsuranceName As String = String.Empty
            Dim lstate, lcity, lPhone As String
            Dim lCompanyName As String
            Dim whereClause As String = ""

            Dim lds As New DataSet

            If (Request.QueryString("InsuranceName") <> Nothing) Then
                lCompanyName = Request.QueryString("InsuranceName").ToString
            Else
                lCompanyName = txtPayerName.Text
            End If

            If lCompanyName = "" Then
                whereClause = whereClause
            Else
                whereClause = whereClause & " And CompanyName like '" & lCompanyName & "%'"
            End If

            If lstate = "" Then
                whereClause = whereClause
            Else
                whereClause = whereClause & " And State = '" & cmbState.Text & "%'"
            End If

            If lCity <> "" Then
                whereClause = whereClause & " And City like '" & Utility.AdjustApostrophie(txtCity.Text) & "%'"
            End If

            If lPhone <> "" Then
                whereClause = whereClause & " And WorkPhone like '" & txtPhone.Text & "%'"
            End If

            whereClause = whereClause & " And IsDelete='N'"

            lds = InsuranceMethods.GetInsuranceRecords(whereClause)
            RGInsuranceList.DataSource = lds
            Exit Sub
        End If


    End Sub

    ''changes made by talha...
    Protected Sub RGInsuranceList_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles RGInsuranceList.NeedDataSource

        Dim whereClause As String = ""

        Dim lds As New DataSet

        Dim lCompanyName As String = txtPayerName.Text
        Dim lState As String = cmbState.Text
        Dim lCity As String = txtCity.Text
        Dim lPhone As String = txtPhone.Text


        If lCompanyName = "" Then
            whereClause = whereClause
        Else
            whereClause = whereClause & " And CompanyName like '" & txtPayerName.Text & "%'"
        End If


        If lState = "" Then
            whereClause = whereClause
        Else
            whereClause = whereClause & " And State = '" & cmbState.Text & "'"
        End If


        If lCity <> "" Then
            whereClause = whereClause & " And City like '" & Utility.AdjustApostrophie(txtCity.Text) & "%'"
        End If

        If lPhone <> "" Then
            whereClause = whereClause & " And WorkPhone like '" & txtPhone.Text & "%'"
        End If

        whereClause = whereClause & " And IsDelete='N'"

        lds = InsuranceMethods.GetInsuranceRecords(whereClause)

        RGInsuranceList.DataSource = lds
    End Sub



    Protected Sub RGInsuranceList_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles RGInsuranceList.SelectedIndexChanged

        Dim lString As String

        'lString = CType(sender, RadGrid).SelectedItems.Item(0).Cells(3).Text & "|" & CType(sender, RadGrid).SelectedItems.Item(0).Cells(4).Text & _
        '"|" & CType(sender, RadGrid).SelectedItems.Item(0).Cells(6).Text & "|" & CType(sender, RadGrid).SelectedItems.Item(0).Cells(7).Text

        lString = CType(sender, RadGrid).SelectedItems.Item(0).Cells(2).Text & "|" & _
        CType(sender, RadGrid).SelectedItems.Item(0).Cells(7).Text

        InjectScript.Text = "<Script>CloseAndReload('" & lString & "');</Script>"


    End Sub

    Protected Sub btnClose_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnClose.Click
        lblClose.Text = "<script>CloseOnly()</Script>"
    End Sub
    ''changes made by talha...
    Protected Sub RGInsuranceList_ItemDataBound(ByVal sender As Object, ByVal e As Telerik.WebControls.GridItemEventArgs) Handles RGInsuranceList.ItemDataBound

    End Sub

    
    Protected Sub cmbState_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbState.ItemsRequested
        Dim lUser As User
        lUser = CType(Session.Item("User"), User)

        Dim lCond As String
        lCond = "And Abbr Like '" & Utility.AdjustApostrophie(e.Text) & "%' "

        If (e.Text = "") Then
            Exit Sub
        End If

        StateMethods.Load_States(cmbState, lUser, lCond)
    End Sub

   
    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSearch.Click
        RGInsuranceList.Rebind()
    End Sub
End Class