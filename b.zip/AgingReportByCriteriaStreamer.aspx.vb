
Partial Class Billing_AgingReportByCriteriaStreamer
    Inherits System.Web.UI.Page

    Protected Sub cmbPayer_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbPayer.ItemsRequested

        If (Session.Count = 0) Then
            Exit Sub
        End If

        If e.Text = "" Then
            Exit Sub
        End If
        Dim lDs As New DataSet
        Dim lUser As User

        Try
            lUser = CType(Session.Item("User"), User)
          
            lDs = InsuranceMethods.GetInsuranceForCombo(Utility.AdjustApostrophie(e.Text.Trim()), lUser)
         
            cmbPayer.DataSource = lDs
            cmbPayer.DataTextField = "CompanyName"
            cmbPayer.DataValueField = "FavouriteInsuranceID"
            cmbPayer.DataBind()

        Catch ex As Exception
            ErrorLogMethods.LogError(ex, "Billing_AgingReportByCriteria.aspx\cmbPayer_ItemsRequested()")

        Finally
            lDs.Dispose()
        End Try
    End Sub

  

  
    Protected Sub cmbPatientName_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbPatientName.ItemsRequested
        'If (Session.Count = 0) Then
        '    Exit Sub
        'End If

        'If e.Text = "" Then
        '    Exit Sub
        'End If
        'Dim lDs As New DataSet
        'Dim lUser As User
        'Try
        '    lUser = CType(Session.Item("User"), User)
        '    lDs = PatientMethods.LoadPatientsLastNameForPostPayment(Utility.AdjustApostrophie(e.Text.Trim()), lUser)
        '    cmbPatientName.DataSource = lDs
        '    cmbPatientName.DataBind()
        'Catch ex As Exception
        '    ErrorLogMethods.LogError(ex, "Billing_AgingReportByCriteria.aspx\RadComboBox1_ItemsRequested()")
        '    'Response.Redirect("Error.aspx")
        'Finally
        '    lDs.Dispose()
        'End 
        If (Session.Count = 0) Then
            Exit Sub
        End If

        If e.Text = "" Then
            Exit Sub
        End If
        Dim lDs As New DataSet
        Dim lUser As User
        Try
            lUser = CType(Session.Item("User"), User)
            lDs = PatientMethods.GetPatientsLastNameForPatientLedger(Utility.AdjustApostrophie(e.Text.Trim()), lUser)
            cmbPatientName.DataSource = lDs
            cmbPatientName.DataTextField = "Full"
            cmbPatientName.DataValueField = "PatientID"
            cmbPatientName.DataBind()
        Catch ex As Exception
            ErrorLogMethods.LogError(ex, "Billing_AgingReportByCriteria.aspx\RadComboBox1_ItemsRequested()")
            'Response.Redirect("Error.aspx")
        Finally
            lDs.Dispose()
        End Try
    End Sub

    Protected Sub cmbPatientNameDOS_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbPatientNameDOS.ItemsRequested
        'If (Session.Count = 0) Then
        '    Exit Sub
        'End If

        'If e.Text = "" Then
        '    Exit Sub
        'End If
        'Dim lDs As New DataSet
        'Dim lUser As User
        'Try
        '    lUser = CType(Session.Item("User"), User)
        '    lDs = PatientMethods.LoadPatientsLastNameForPostPayment(Utility.AdjustApostrophie(e.Text.Trim()), lUser)
        '    cmbPatientNameDOS.DataSource = lDs
        '    cmbPatientNameDOS.DataBind()
        'Catch ex As Exception
        '    ErrorLogMethods.LogError(ex, "Billing_AgingReportByCriteria.aspx\RadComboBox1_ItemsRequested()")
        '    'Response.Redirect("Error.aspx")
        'Finally
        '    lDs.Dispose()
        'End Try
        If (Session.Count = 0) Then
            Exit Sub
        End If

        If e.Text = "" Then
            Exit Sub
        End If
        Dim lDs As New DataSet
        Dim lUser As User
        Try
            lUser = CType(Session.Item("User"), User)
            lDs = PatientMethods.GetPatientsLastNameForPatientLedger(Utility.AdjustApostrophie(e.Text.Trim()), lUser)
            cmbPatientNameDOS.DataSource = lDs
            cmbPatientNameDOS.DataTextField = "Full"
            cmbPatientNameDOS.DataValueField = "PatientID"
            cmbPatientNameDOS.DataBind()
        Catch ex As Exception
            ErrorLogMethods.LogError(ex, "Billing_AgingReportByCriteria.aspx\RadComboBox1_ItemsRequested()")
            'Response.Redirect("Error.aspx")
        Finally
            lDs.Dispose()
        End Try
    End Sub

    Protected Sub cmbProvider_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbProvider.ItemsRequested
        If (Session.Count = 0) Then
            Exit Sub
        End If

        If e.Text = "" Then
            Exit Sub
        End If
        Dim lDs As New DataSet
        Dim lUser As User
        Try
            lUser = CType(Session.Item("User"), User)

            Dim lEmployee As New Employee(lUser.ConnectionString)
            lDs = lEmployee.GetActiveEmployees(" And SPI <> ''")
            Me.cmbProvider.DataSource = lDs
            cmbProvider.DataTextField = "EmployeeName"
            cmbProvider.DataValueField = "EmployeeID"
            Me.cmbProvider.DataBind()
        Catch ex As Exception
            ErrorLogMethods.LogError(ex, "Billing_AgingReportByCriteria.aspx\cmbProvider_ItemsRequested()")
            'Response.Redirect("Error.aspx")
        Finally
            lDs.Dispose()
        End Try
    End Sub
End Class
