
Partial Class Billing_MultiColumnTest
    Inherits System.Web.UI.Page

End Class
