
Partial Class Billing_SuperBillSetup
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        tsSuperBill.SelectedIndex = 0
        mpSuperBill.SelectedIndex = 0
    End Sub

    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSearch.Click
        pnlGrid.Visible = True
        grdSuperBill.Rebind()
    End Sub

    Protected Sub ImgAddEmployee_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImgAddSuperBill.Click
        Response.Redirect("AddSuperBill.aspx")
    End Sub

    Protected Sub grdSuperBill_DeleteCommand(ByVal source As Object, ByVal e As Telerik.WebControls.GridCommandEventArgs) Handles grdSuperBill.DeleteCommand
        Dim lSuperBillId As String
        Dim lUser As User
        Dim lMessage As String

        lUser = CType(Session.Item("User"), User)

        lSuperBillId = e.Item.Cells(2).Text
        lMessage = SuperBillMethods.DeleteSuperBill(lSuperBillId, lUser, Request.Url.AbsoluteUri)
        If lMessage <> "" Then
            grdSuperBill.ResponseScripts.Add("radalert('" & lMessage & "');")
        End If
    End Sub

    Protected Sub grdSuperBill_ItemDataBound(ByVal sender As Object, ByVal e As Telerik.WebControls.GridItemEventArgs) Handles grdSuperBill.ItemDataBound
        If (e.Item.ItemType = Telerik.WebControls.GridItemType.Item Or e.Item.ItemType = Telerik.WebControls.GridItemType.AlternatingItem) Then
            Dim lDataItem As Telerik.WebControls.GridDataItem = CType(e.Item, Telerik.WebControls.GridDataItem)
            Dim lHyplnk As HyperLink = CType(lDataItem("SuperBillName").Controls(0), HyperLink)
            Dim lSuperBillId As String = lDataItem("SuperBillId").Text
            Dim lICDSortBy As String = lDataItem("ICDSortBy").Text
            Dim lICDSortOrder As String = lDataItem("ICDSortOrder").Text
            Dim lCPTSortBy As String = lDataItem("CPTSortBy").Text
            Dim lCPTSortOrder As String = lDataItem("CPTSortOrder").Text
            lHyplnk.NavigateUrl = "EditSuperBill.aspx" & Encryption.EncryptQueryString("sid=" & lSuperBillId & "&sor=" & lICDSortBy & "" & lICDSortOrder & "" & lCPTSortBy & "" & lCPTSortOrder)
        End If
    End Sub

    Protected Sub grdSuperBill_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdSuperBill.NeedDataSource
        Dim lUser As User
        Dim lCond As String

        lUser = CType(Session.Item("User"), User)

        lCond = "And SuperBillName Like '" & Utility.AdjustApostrophie(txtSuperBillName.Text) & "%' And IsDeleted = 'N'"
        
        SuperBillMethods.Load_SuperBillGrid(grdSuperBill, lCond, lUser)
    End Sub
End Class
