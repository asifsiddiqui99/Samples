
Partial Class Billing_SearchICD9
    Inherits System.Web.UI.Page

    Protected Sub grdICD_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdICD.NeedDataSource
        'SuperBillMethods.LoadICDGridByDescription(grdICD, txtDescription.Text, txtCode.Text)

        Dim lResultXmlData As String = ""
        Dim lDS = New DataSet

        If (txtCode.Text = "") Then
            Exit Sub
        End If

        Try
            lDS = IMOMethods.SearchICD(txtCode.Text)

            'lResultXmlData = IMOMethods.SearchICD(txtCode.Text)
            If (lDS IsNot Nothing) Then
                grdICD.DataSource = lDS
                ' Me.xmlSrcICD.Data = lResultXmlData
                ' Me.grdICD.DataSource = xmlSrcICD
            Else
                grdICD.DataSource = ""

            End If
        Catch ex As Exception
            grdICD.DataSource = ""

        End Try

    End Sub

    Protected Sub grdICD_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdICD.SelectedIndexChanged
        Dim ICDColl As ICD9Coll
        Dim ICD9 As New ICD9DB()
        Dim lICDData As String = ""
        Dim lineId As String = ""

        ICD9.IMOCode = grdICD.SelectedItems.Item(0).Cells(5).Text
        ICD9.Description = grdICD.SelectedItems.Item(0).Cells(6).Text
        ICD9.Code = grdICD.SelectedItems.Item(0).Cells(4).Text
        ICD9.SuperBillId = ""


        If Request.QueryString("lid") Is Nothing Then
            If Session("ICD9Coll") IsNot Nothing Then
                ICDColl = Session("ICD9Coll")
                If ICDColl.IndexOf(ICD9) >= 0 Then
                    lblMessage.Text = "Code Already Exist"
                    Return
                End If
            End If
        Else
            lineId = Request.QueryString("lid")
            lICDData = lineId & "|"
        End If

        lICDData = lICDData & ICD9.Code & "|" & ICD9.Description & "|" & ICD9.IMOCode


        lblClose.Text = "<script>CloseOnReload('" & lICDData & "')</Script>"



    End Sub

    Protected Sub btnClose_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnClose.Click
        lblClose.Text = "<script>CloseOnly()</Script>"
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            If Not Request.QueryString("icd") Is Nothing Then
                txtCode.Text = Request.QueryString("icd").ToString()
            End If
            If Not Request.QueryString("dsc") Is Nothing Then
                'txtDescription.Text = Server.UrlDecode(Request.QueryString("dsc").ToString())
            End If
        End If
    End Sub

    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSearch.Click
        grdICD.Rebind()
    End Sub
End Class
