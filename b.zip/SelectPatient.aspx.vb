Imports Telerik.WebControls
Imports System.Drawing
Imports ElixirLibrary
Partial Class Billing_SelectPatient
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim queryString As NameValueCollection = Nothing
        Dim lPatientID As String
        Try
            If Not Page.IsPostBack Then
                If (Request.QueryString.Count > 0) Then
                    queryString = Encryption.DecryptQueryString(Request.QueryString.ToString())
                    If (queryString IsNot Nothing) Then
                        lPatientID = queryString("id").ToString
                        txtPatientID.Text = lPatientID
                        grdPatient.Rebind()
                        grdPatient.SelectedIndexes.Add(0)
                        cmbLastName.Text = grdPatient.SelectedItems.Item(0).Cells(5).Text.Split(",")(0)
                        cmbFirstName.Text = grdPatient.SelectedItems.Item(0).Cells(5).Text.Split(",")(1)
                    End If
                End If
                tsPatientSetup.SelectedIndex = 0
                tsPatientSetup.SelectedTab.Enabled = True
                Me.dtDOB.MaxDate = DateTime.Today
            End If
            cmbLastName.Focus()
            Me.Form.DefaultButton = Me.btnSearch.UniqueID
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub grdPatient_ItemCommand(ByVal source As Object, ByVal e As Telerik.WebControls.GridCommandEventArgs) Handles grdPatient.ItemCommand
        Try
            Dim lPatID As String = ""

            If (e.CommandName = "Select") Then
                lPatID = e.Item.Cells(2).Text
            End If
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub grdPatient_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdPatient.NeedDataSource
        grdPatient.AutoGenerateColumns = False
        LoadPatientGrid()
    End Sub
    Private Sub LoadPatientGrid()
        Dim lUser As User
        Dim lobjPatientDb As New PatientDB
        Dim lDs As New DataSet
        Try
            lobjPatientDb.LastName = Utility.AdjustApostrophie(Me.cmbLastName.Text)
            lobjPatientDb.FirstName = Utility.AdjustApostrophie(Me.cmbFirstName.Text)
            If (txtPatientID.Text <> "") Then
                lobjPatientDb.PatientID = txtPatientID.Text
            End If
            If Not Me.dtDOB.IsEmpty Then
                lobjPatientDb.DOB = Me.dtDOB.SelectedDate
            End If
            lUser = CType(Session.Item("User"), User)
            lDs = PatientMethods.SearchPatient(lobjPatientDb, lUser, Request.Url.AbsoluteUri.ToString)
            grdPatient.DataSource = lDs
            Me.pnlgrdPatient.Visible = True
        Catch ex As Exception
            ErrorLogMethods.LogError(ex, "PatientSetup.aspx\LoadPatientGrid()")
            'Me.RadAjaxPanel1.Alert("Error in searching Patient")
        Finally
            lDs.Dispose()
        End Try
    End Sub
    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)
        txtPatientID.Text = ""
        grdPatient.Rebind()
    End Sub
    Protected Sub btnVisitInformation_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnVisitInformation.Click
        Dim lPatientId As String
        Dim lURL As String = "VisitSearch.aspx"
        Dim lQueryString As String
        Try
            If (grdPatient.SelectedIndexes.Count > 0) Then
                lPatientId = grdPatient.SelectedItems.Item(0).Cells(2).Text
                lQueryString = ElixirLibrary.Encryption.EncryptQueryString("source=ps&id=" & lPatientId)
                Response.Redirect(lURL & lQueryString)
            Else
                Response.Write("<script>alert('Please select patient');</script>")
            End If

        Catch ex As Exception

        End Try
    End Sub
    Protected Sub btnVisitSummarySearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnVisitSummarySearch.Click
        Dim lPatientId As String
        Dim lURL As String = "VisitSummarySearch.aspx"
        Dim lQueryString As String
        Try
            If (grdPatient.SelectedIndexes.Count > 0) Then
                lPatientId = grdPatient.SelectedItems.Item(0).Cells(2).Text
                lQueryString = ElixirLibrary.Encryption.EncryptQueryString("source=ps&id=" & lPatientId)
                Response.Redirect(lURL & lQueryString)
            Else
                Response.Write("<script>alert('Please select patient');</script>")
            End If
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub btnClaimManagement_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnClaimManagement.Click
        Dim lPatientId As String
        Dim lURL As String = "ClaimSearch.aspx"
        Dim lQueryString As String
        Try
            If (grdPatient.SelectedIndexes.Count > 0) Then
                lPatientId = grdPatient.SelectedItems.Item(0).Cells(2).Text
                lQueryString = ElixirLibrary.Encryption.EncryptQueryString("source=ps&id=" & lPatientId)
                Response.Redirect(lURL & lQueryString)
            Else
                Response.Write("<script>alert('Please select patient');</script>")
            End If
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub btnBatchSubmission_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnBatchSubmission.Click
        Dim lPatientId As String
        Dim lURL As String = "ClaimBatchSearch.aspx"
        Dim lQueryString As String
        Try
            If (grdPatient.SelectedIndexes.Count > 0) Then
                lPatientId = grdPatient.SelectedItems.Item(0).Cells(2).Text
                lQueryString = ElixirLibrary.Encryption.EncryptQueryString("source=ps&id=" & lPatientId)
                Response.Redirect(lURL & lQueryString)
            Else
                Response.Write("<script>alert('Please select patient');</script>")
            End If
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub btnPatientLedger_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnPatientLedger.Click
        Dim lPatientId As String
        Dim lURL As String = "PatientLedgerPage.aspx"
        Dim lQueryString As String
        Try
            If (grdPatient.SelectedIndexes.Count > 0) Then
                lPatientId = grdPatient.SelectedItems.Item(0).Cells(2).Text
                lQueryString = ElixirLibrary.Encryption.EncryptQueryString("source=ps&id=" & lPatientId)
                Response.Redirect(lURL & lQueryString)
            Else
                Response.Write("<script>alert('Please select patient');</script>")
            End If
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub btnPatientStatementArchive_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnPatientStatementArchive.Click
        Dim lPatientId As String
        Dim lURL As String = "PatientStatementArchive.aspx"
        Dim lQueryString As String
        Try
            If (grdPatient.SelectedIndexes.Count > 0) Then
                lPatientId = grdPatient.SelectedItems.Item(0).Cells(2).Text
                lQueryString = ElixirLibrary.Encryption.EncryptQueryString("source=ps&id=" & lPatientId)
                Response.Redirect(lURL & lQueryString)
            Else
                Response.Write("<script>alert('Please select patient');</script>")
            End If
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub btnPatientStatementGenerate_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnPatientStatementGenerate.Click
        Dim lPatientId As String
        Dim lURL As String = "GeneratesPatientStatement.aspx"
        Dim lQueryString As String
        Try
            If (grdPatient.SelectedIndexes.Count > 0) Then
                lPatientId = grdPatient.SelectedItems.Item(0).Cells(2).Text
                lQueryString = ElixirLibrary.Encryption.EncryptQueryString("source=ps&id=" & lPatientId)
                Response.Redirect(lURL & lQueryString)
            Else
                Response.Write("<script>alert('Please select patient');</script>")
            End If
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub btnPostPayment_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnPostPayment.Click
        Dim lPatientId As String
        Dim lURL As String = "PaymentSearch.aspx"
        Dim lQueryString As String
        Try
            If (grdPatient.SelectedIndexes.Count > 0) Then
                lPatientId = grdPatient.SelectedItems.Item(0).Cells(2).Text
                lQueryString = ElixirLibrary.Encryption.EncryptQueryString("source=ps&id=" & lPatientId)
                Response.Redirect(lURL & lQueryString)
            Else
                Response.Write("<script>alert('Please select patient');</script>")
            End If
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub btnRemittance_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRemittance.Click
        Dim lPatientId As String
        Dim lURL As String = "RemittanceSearch.aspx"
        Dim lQueryString As String
        Try
            If (grdPatient.SelectedIndexes.Count > 0) Then
                lPatientId = grdPatient.SelectedItems.Item(0).Cells(2).Text
                lQueryString = ElixirLibrary.Encryption.EncryptQueryString("source=ps&id=" & lPatientId)
                Response.Redirect(lURL & lQueryString)
            Else
                Response.Write("<script>alert('Please select patient');</script>")
            End If
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub btnCreateSuperBill_Click(sender As Object, e As System.Web.UI.ImageClickEventArgs) Handles btnCreateSuperBill.Click
        Dim lPatientId As String
        Dim lURL As String = "SearchPatient.aspx"
        Dim lQueryString As String
        Try
            If (grdPatient.SelectedIndexes.Count > 0) Then
                lPatientId = grdPatient.SelectedItems.Item(0).Cells(2).Text
                lQueryString = ElixirLibrary.Encryption.EncryptQueryString("source=ps&id=" & lPatientId)
                Response.Redirect(lURL & lQueryString)
            Else
                Response.Write("<script>alert('Please select patient');</script>")
            End If

        Catch ex As Exception

        End Try
    End Sub
End Class
