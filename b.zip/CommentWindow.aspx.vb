
Partial Class Billing_CommentWindow
    Inherits System.Web.UI.Page
    Dim mPaymentDtlCollection As Hashtable 'PaymentDtlCollection
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim lPaymentID As Integer = 0
        Dim lHCFAID As Integer = 0

        Dim lPaymentHdr As PaymentHdr = Nothing
        Dim lClaim As Claim = Nothing

        Dim lPatientSuperBill As PatientSuperBill
        Dim lPsbID As String = ""
        Dim lCase As String = ""
        Dim lDS As New DataSet
        Dim lComments As New ArrayList

        Dim lUser As User
        Try
            lUser = CType(Session("User"), User)

            If Request.QueryString("PaymentId") IsNot Nothing Then 'IF THE USER IS COMING FROM PAYMENT SEARCH, GO HERE

                lPaymentID = Request.QueryString("PaymentID")
                lPaymentHdr = New PaymentHdr(CType(Session("User"), User).ConnectionString)


                lPaymentHdr.PaymentHdr.PaymentID = lPaymentID
                lPaymentHdr.GetRecordByID()


                txtComment.Value = lPaymentHdr.PaymentHdr.Notes

                'Else 'IF THE USER IS COMING FROM CLAIM SEARCH, GO HERE 
                '    lHCFAID = Request.QueryString("HCFAID")
                '    lClaim = New Claim(CType(Session("User"), User).ConnectionString)

                '    txtComment.Value = lClaim.GetClaimNotes(lHCFAID)

            End If

            If Request.QueryString("HCFAID") IsNot Nothing Then
                lHCFAID = Request.QueryString("HCFAID")
                lClaim = New Claim(CType(Session("User"), User).ConnectionString)

                txtComment.Value = lClaim.GetClaimNotes(lHCFAID)
            End If




            ''User is coming from Apply payment.....
            If Request.QueryString("VisitID") IsNot Nothing Then
                If (Session("PaymentDetailCollectionForHeader") IsNot Nothing) Then
                    mPaymentDtlCollection = Session("PaymentDetailCollectionForHeader")
                    Dim lpaymentdtl As PaymentDtlDB = Nothing

                    lpaymentdtl = mPaymentDtlCollection.Item(Request.QueryString.Get(0).ToString)
                    txtComment.Value = lpaymentdtl.Notes
                End If

            End If

            ''User is coming from patientsuperbill.....
            If Request.QueryString("PsbId") IsNot Nothing Then
                If (Request.QueryString("case") IsNot Nothing) Then
                    lPsbID = Request.QueryString("PsbId")
                    lCase = Request.QueryString("case")
                    If (lCase = "0") Then
                        lPatientSuperBill = New PatientSuperBill(lUser.ConnectionString)
                        lDS = lPatientSuperBill.LoadComments(Nothing, lPsbID)
                        If (lDS.Tables.Count > 0 AndAlso lDS.Tables(0).Rows.Count > 0) Then
                            txtComment.Value = lDS.Tables(0).Rows(0).Item("Comments").ToString
                        End If
                    End If
                    txtComment.Focus()
                End If
            End If

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub btnAddComments_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnAddComments.Click
        Dim lUser As User
        Try

            lUser = CType(Session("User"), User)
            txtComment.Value = txtComment.Value & vbCr & "" & lUser.FirstName & " " & lUser.LastName & " [" & lUser.FirstName & "], " & DateTime.Now & ": "
            txtComment.Focus()

        Catch ex As Exception

        End Try
    End Sub


End Class
