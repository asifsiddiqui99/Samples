Imports iTextSharp
Imports iTextSharp.text
Imports iTextSharp.text.pdf
Imports iTextSharp.text.xml
Imports System.IO


Partial Class Billing_ViewHcfaPdf
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim lHcfaId As Int32 = 0

        Dim queryString As NameValueCollection
        queryString = Encryption.DecryptQueryString(Request.QueryString.ToString())



        If (queryString("HCFAID") IsNot Nothing AndAlso queryString("HCFAID") <> "") Then
            lHcfaId = queryString("HCFAID")
        End If

        Dim lClaimPdfPath As String = FillForm(lHcfaId)
        If (lClaimPdfPath <> "") Then
            ViewPdf(lClaimPdfPath)
        Else
            Return
        End If

    End Sub
    Private Function FillForm(ByVal pHcfaID As String) As String
        Dim lUser As User
        Dim lClaimFileName As String = ""
        Dim lClaimFilePath As String = ""
        Dim lNewClaimPath As String = ""
        Dim lDirectoryInfo As DirectoryInfo
        Dim lPdfReader As PdfReader
        Dim lPdfStamper As PdfStamper
        Dim pdfFormFields As AcroFields
        Dim lConnection As Connection
        Dim lDs As New DataSet
        Dim lHcfaRowCount As Int32 = 0

        Dim queryString As NameValueCollection
        queryString = Encryption.DecryptQueryString(Request.QueryString.ToString())
        Dim lPdfTemplatePath As String
        If queryString("sor").ToString() = "Printed" Then
            lPdfTemplatePath = Server.MapPath("PdfTemplates\CMS1500TemplatePrinted.pdf")
        Else
            lPdfTemplatePath = Server.MapPath("PdfTemplates\CMS1500Template.pdf")
        End If

     

        Try
            lUser = CType(HttpContext.Current.Session.Item("User"), User)

            ''Getting HCFA
            lConnection = New Connection(lUser.ConnectionString)
            Dim lQuery As String = "Exec GetHcfaForReportNEW " & pHcfaID
            lDs = lConnection.ExecuteQuery(lQuery)

            If (lDs.Tables(0).Rows.Count < 6) Then
                Dim lrow As DataRow
                For lHcfaRowCount = lDs.Tables(0).Rows.Count To 5
                    lrow = lDs.Tables(0).NewRow()
                    lrow.ItemArray = lDs.Tables(0).Rows(0).ItemArray.Clone
                    lrow.Item("CPTCODE") = ""
                    lrow.Item("ModifierA") = DBNull.Value
                    lrow.Item("ModifierB") = DBNull.Value
                    lrow.Item("ModifierC") = DBNull.Value
                    lrow.Item("ModifierD") = DBNull.Value
                    lrow.Item("FacilitySecondaryIdentificationQualifier") = ""
                    lrow.Item("DateOfServiceFrom") = ""
                    lrow.Item("DateOfServiceTo") = ""
                    lrow.Item("PlaceOfService") = DBNull.Value
                    lrow.Item("DignosisPointer") = DBNull.Value
                    lrow.Item("Charges") = DBNull.Value
                    lrow.Item("Days") = DBNull.Value
                    lrow.Item("EPSDT") = ""
                    lrow.Item("NPI") = ""
                    lDs.Tables(0).Rows.Add(lrow)
                Next
            End If

            ''Getting HcfaDisplayId for file name
            If (lDs.Tables(0).Rows.Count > 0) Then
                lClaimFileName = Convert.ToDateTime(lDs.Tables(0).Rows(0).Item("HCFAPreparedDate")).Year & "-" & Convert.ToDateTime(lDs.Tables(0).Rows(0).Item("HCFAPreparedDate")).ToString("MM") & "-" & lDs.Tables(0).Rows(0).Item("HCFADisplayID").ToString.PadLeft(5, "0") & ".pdf"
            End If

            ''Check Save Directory if not exist than Create
            lClaimFilePath = CType(ConfigurationManager.AppSettings("ClaimRquestPath"), String)
            lDirectoryInfo = New DirectoryInfo(lClaimFilePath)
            If Not lDirectoryInfo.Exists Then
                lDirectoryInfo.Create()
            End If
            lClaimFilePath = CType(ConfigurationManager.AppSettings("ClaimRquestPath"), String) + lUser.ClinicId
            lDirectoryInfo = New DirectoryInfo(lClaimFilePath)
            If Not lDirectoryInfo.Exists Then
                lDirectoryInfo.Create()
            End If
            lClaimFilePath = CType(ConfigurationManager.AppSettings("ClaimRquestPath"), String) + lUser.ClinicId + "\ClaimsPDF\"
            lDirectoryInfo = New DirectoryInfo(lClaimFilePath)
            If Not lDirectoryInfo.Exists Then
                lDirectoryInfo.Create()
            End If
            ''Check Save Directory if not exist than Create

            'File Final save Path
            lNewClaimPath = lClaimFilePath & lClaimFileName


            '' HCFA template Pdf Loading And Creating New Filled HCFA work
            lPdfReader = New PdfReader(lPdfTemplatePath)
            lPdfStamper = New PdfStamper(lPdfReader, New FileStream(lNewClaimPath, FileMode.Create))

            pdfFormFields = lPdfStamper.AcroFields



            ' Set Form Text Fields     
            If (lDs.Tables(0).Rows.Count > 0) Then

                'Hdr
                Dim lAddress2 As String = lDs.Tables(0).Rows(0).Item("InsuranceAddressHdr").ToString
                If (lAddress2 <> "" AndAlso lAddress2.Contains(" ")) Then
                    Dim lZip As String = ""
                    lZip = lAddress2.Substring(lAddress2.LastIndexOf(" "))
                    If (lZip.Length > 6) Then
                        lZip = lZip.Insert(6, "-")
                    End If
                    lAddress2 = lAddress2.Replace(lAddress2.Substring(lAddress2.LastIndexOf(" ")), lZip)
                End If


                pdfFormFields.SetField("txtHdrInsuranceCompanyName", lDs.Tables(0).Rows(0).Item("InsuranceNameHdr").ToString)
                pdfFormFields.SetField("txtHdrInsuranceCompanyAddressLine1", lDs.Tables(0).Rows(0).Item("InsuranceAddressLine1").ToString)
                pdfFormFields.SetField("txtHdrInsuranceCompanyAddressLine2", lDs.Tables(0).Rows(0).Item("InsuranceAddressLine2").ToString)
                pdfFormFields.SetField("txtHdrInsuranceCompanyCityStateZip", lAddress2)

                'Block 1
                pdfFormFields.SetField("txt1aInsuresIdNo", lDs.Tables(0).Rows(0).Item("InsuredIDNumber").ToString)
                If (lDs.Tables(0).Rows(0).Item("Type1").ToString.ToUpper = "MEDICARE") Then
                    pdfFormFields.SetField("chk1Medicare", "Yes")
                End If
                If (lDs.Tables(0).Rows(0).Item("Type1").ToString.ToUpper = "MEDICAID") Then
                    pdfFormFields.SetField("chk1Medicaid", "Yes")
                End If
                If (lDs.Tables(0).Rows(0).Item("Type1").ToString.ToUpper = "TRICARE") Then
                    pdfFormFields.SetField("chk1TricareChampus", "Yes")
                End If
                If (lDs.Tables(0).Rows(0).Item("Type1").ToString.ToUpper = "CHAMPVA") Then
                    pdfFormFields.SetField("chk1CHAMPVA", "Yes")
                End If
                If (lDs.Tables(0).Rows(0).Item("Type1").ToString.ToUpper = "GROUP HEALTH PLAN") Then
                    pdfFormFields.SetField("chk1GroupHealthPlan", "Yes")
                End If
                If (lDs.Tables(0).Rows(0).Item("Type1").ToString.ToUpper = "FECA") Then
                    pdfFormFields.SetField("chk1FECA BLKLUNG", "Yes")
                End If
                If (lDs.Tables(0).Rows(0).Item("Type1").ToString.ToUpper = "OTHER") Then
                    pdfFormFields.SetField("chk1Other", "Yes")
                End If

                'Block 2
                pdfFormFields.SetField("txt2PatientName", lDs.Tables(0).Rows(0).Item("PatientName").ToString)

                'Block 3
                If (lDs.Tables(0).Rows(0).Item("PatientDOB") <> "01/01/1900") Then
                    pdfFormFields.SetField("txt3PatientBirthDate", lDs.Tables(0).Rows(0).Item("PatientDOB").ToString.Replace("/", "     "))
                Else
                    pdfFormFields.SetField("txt3PatientBirthDate", "")
                End If
                If (Left(lDs.Tables(0).Rows(0).Item("PatientGender"), 1).ToString.ToUpper = "M") Then
                    pdfFormFields.SetField("chk3SexM", "Yes")
                Else
                    pdfFormFields.SetField("chk3SexF", "Yes")
                End If

                'Block 4
                pdfFormFields.SetField("txt4InsuredName", lDs.Tables(0).Rows(0).Item("InsuredName").ToString)

                'Block 5
                pdfFormFields.SetField("txt5PatientAddressNoStreet", lDs.Tables(0).Rows(0).Item("PatientAddress").ToString)
                pdfFormFields.SetField("txt5PatientAddressCity", lDs.Tables(0).Rows(0).Item("PatientCity").ToString)
                pdfFormFields.SetField("txt5PatientAddressState", lDs.Tables(0).Rows(0).Item("PatientState").ToString)
                If (lDs.Tables(0).Rows(0).Item("PatientZipCode").ToString.Length > 5) Then
                    Dim lLongZipCode As String = lDs.Tables(0).Rows(0).Item("PatientZipCode").ToString
                    lLongZipCode = lLongZipCode.Insert(5, "-")
                    pdfFormFields.SetField("txt5PatientAddressZipCode", lLongZipCode)
                Else
                    pdfFormFields.SetField("txt5PatientAddressZipCode", lDs.Tables(0).Rows(0).Item("PatientZipCode").ToString)
                End If
                If (lDs.Tables(0).Rows(0).Item("PatientTelephone").ToString.Length > 4) Then
                    pdfFormFields.SetField("txt5PatientAddressPhone", lDs.Tables(0).Rows(0).Item("PatientTelephone").ToString.Insert(3, "    ").Insert(0, "   "))
                Else
                    pdfFormFields.SetField("txt5PatientAddressPhone", "")
                End If


                'Block 6
                If (lDs.Tables(0).Rows(0).Item("PatientRelationshipToInsured").ToString.ToUpper = "SELF") Then
                    pdfFormFields.SetField("chk6PatientRelationshipToInsuredSelf", "Yes")
                ElseIf (lDs.Tables(0).Rows(0).Item("PatientRelationshipToInsured").ToString.ToUpper = "SPOUSE") Then
                    pdfFormFields.SetField("chk6PatientRelationshipToInsuredSpouse", "Yes")
                ElseIf (lDs.Tables(0).Rows(0).Item("PatientRelationshipToInsured").ToString.ToUpper = "CHILD") Then
                    pdfFormFields.SetField("chk6PatientRelationshipToInsuredChild", "Yes")
                ElseIf (lDs.Tables(0).Rows(0).Item("PatientRelationshipToInsured").ToString.ToUpper = "OTHER") Then
                    pdfFormFields.SetField("chk6PatientRelationshipToInsuredOther", "Yes")
                End If

                'Block 7
                pdfFormFields.SetField("txt7InsuredAddressNoStreet", lDs.Tables(0).Rows(0).Item("InsuredAddress").ToString)
                pdfFormFields.SetField("txt7InsuredAddressCity", lDs.Tables(0).Rows(0).Item("InsuredCity").ToString)
                pdfFormFields.SetField("txt7InsuredAddressState", lDs.Tables(0).Rows(0).Item("InsuredState").ToString)
                If (lDs.Tables(0).Rows(0).Item("InsuredZipCode").ToString.Length > 5) Then
                    Dim lLongZipCode As String = lDs.Tables(0).Rows(0).Item("InsuredZipCode").ToString
                    lLongZipCode = lLongZipCode.Insert(5, "-")
                    pdfFormFields.SetField("txt7InsuredAddressZipCode", lLongZipCode)
                Else
                    pdfFormFields.SetField("txt7InsuredAddressZipCode", lDs.Tables(0).Rows(0).Item("InsuredZipCode").ToString)
                End If
                If (lDs.Tables(0).Rows(0).Item("InsuredTelephone").ToString.Length > 4) Then
                    pdfFormFields.SetField("txt7InsuredAddressPhone", lDs.Tables(0).Rows(0).Item("InsuredTelephone").ToString.Insert(3, "    ").Insert(0, "    "))
                Else
                    pdfFormFields.SetField("txt7InsuredAddressPhone", "")
                End If

                'Block 8
                If (lDs.Tables(0).Rows(0).Item("PatientMaritalStatus").ToString.ToUpper = "SINGLE") Then
                    pdfFormFields.SetField("chk8PatientStatusSingle", "Yes")
                ElseIf (lDs.Tables(0).Rows(0).Item("PatientMaritalStatus").ToString.ToUpper = "MARRIED") Then
                    pdfFormFields.SetField("chk8PatientStatusMarried", "Yes")
                ElseIf (lDs.Tables(0).Rows(0).Item("PatientMaritalStatus").ToString.ToUpper = "OTHER") Then
                    pdfFormFields.SetField("chk8PatientStatusOther", "Yes")
                End If

                If (lDs.Tables(0).Rows(0).Item("PatientEmploymentInfo").ToString <> "") Then
                    If (lDs.Tables(0).Rows(0).Item("PatientEmploymentInfo").ToString.ToUpper.Substring(0, 1) = "E") Then
                        pdfFormFields.SetField("chk8PatientStatusEmployed", "Yes")
                    ElseIf (lDs.Tables(0).Rows(0).Item("PatientEmploymentInfo").ToString.ToUpper.Substring(0, 1) = "F") Then
                        pdfFormFields.SetField("chk8PatientStatusFullTimeStudent", "Yes")
                    ElseIf (lDs.Tables(0).Rows(0).Item("PatientEmploymentInfo").ToString.ToUpper.Substring(0, 1) = "P") Then
                        pdfFormFields.SetField("chk8PatientStatusPartTimeStudent", "Yes")
                    End If
                End If

                'Block 9
                pdfFormFields.SetField("txt9OtherInsuredName", lDs.Tables(0).Rows(0).Item("OtherInsuredName").ToString)
                pdfFormFields.SetField("txt9aOtherInsuredPolicy/GroupNo", lDs.Tables(0).Rows(0).Item("OtherInsuredPolicy").ToString)
                If (lDs.Tables(0).Rows(0).Item("OtherInsuredDOB") <> "01/01/1900") Then
                    pdfFormFields.SetField("txt9bOtherInsuredDOB", lDs.Tables(0).Rows(0).Item("OtherInsuredDOB").ToString.Replace("/", "      "))
                Else
                    pdfFormFields.SetField("txt9bOtherInsuredDOB", "")
                End If
                pdfFormFields.SetField("txt9cEmployerName/SchoolName", lDs.Tables(0).Rows(0).Item("OtherInsuredEmployer").ToString)
                pdfFormFields.SetField("txt9dInsurancePlan/ProgrammeName", lDs.Tables(0).Rows(0).Item("SecondaryInsurancePlan").ToString)
                If (lDs.Tables(0).Rows(0).Item("OtherInsuredDOB") <> "01/01/1900" AndAlso Left(lDs.Tables(0).Rows(0).Item("OtherInsuredGender"), 1).ToString.ToUpper = "M") Then
                    pdfFormFields.SetField("chk9bOtherInsuredSexM", "Yes")
                ElseIf (lDs.Tables(0).Rows(0).Item("OtherInsuredDOB") <> "01/01/1900" AndAlso Left(lDs.Tables(0).Rows(0).Item("OtherInsuredGender"), 1).ToString.ToUpper = "F") Then
                    pdfFormFields.SetField("chk9bOtherInsuredSexF", "Yes")
                End If

                'Block 10
                pdfFormFields.SetField("txt10Place(State)", "")
                pdfFormFields.SetField("txt10dReservedForLocalUse", lDs.Tables(0).Rows(0).Item("ReservedBlock10D").ToString)
                If (lDs.Tables(0).Rows(0).Item("IsEmploymentRelated").ToString.ToUpper = "Y") Then
                    pdfFormFields.SetField("chk10aEmploymentYes", "Yes")
                ElseIf (lDs.Tables(0).Rows(0).Item("IsEmploymentRelated").ToString.ToUpper = "N") Then
                    pdfFormFields.SetField("chk10aEmploymentNo", "Yes")
                End If
                If (lDs.Tables(0).Rows(0).Item("IsAutoAccidentRelated").ToString.ToUpper = "Y") Then
                    pdfFormFields.SetField("chk10bAutoAccidentYes", "Yes")
                ElseIf (lDs.Tables(0).Rows(0).Item("IsAutoAccidentRelated").ToString.ToUpper = "N") Then
                    pdfFormFields.SetField("chk10bAutoAccidentNo", "Yes")
                End If
                If (lDs.Tables(0).Rows(0).Item("IsOtherAccidentRelated").ToString.ToUpper = "Y") Then
                    pdfFormFields.SetField("chk10cOtherAccidentYes", "Yes")
                ElseIf (lDs.Tables(0).Rows(0).Item("IsOtherAccidentRelated").ToString.ToUpper = "N") Then
                    pdfFormFields.SetField("chk10cOtherAccidentNo", "Yes")
                End If

                'Block 11
                pdfFormFields.SetField("txt11InsuredPolicyGroup/FecaNumber", lDs.Tables(0).Rows(0).Item("AnotherInsuredPolicy").ToString)
                If (lDs.Tables(0).Rows(0).Item("AnotherInsuredDOB") <> "01/01/1900") Then
                    pdfFormFields.SetField("txt11aInsuredDOB", lDs.Tables(0).Rows(0).Item("AnotherInsuredDOB").ToString.Replace("/", "     "))
                Else
                    pdfFormFields.SetField("txt11aInsuredDOB", "")
                End If
                pdfFormFields.SetField("txt11bEmployerName/SchoolName", lDs.Tables(0).Rows(0).Item("AnotherInsuredEmployerName").ToString)
                pdfFormFields.SetField("txt11cInsurancePlanName/ProgrammeName", lDs.Tables(0).Rows(0).Item("AnotherInsuredInsurancePlan").ToString)
                If (lDs.Tables(0).Rows(0).Item("AnotherInsuredDOB") <> "01/01/1900" AndAlso Left(lDs.Tables(0).Rows(0).Item("AnotherInsuredGender"), 1).ToString.ToUpper = "M") Then
                    pdfFormFields.SetField("chk11aInsuredPolicyGroupInsuredSexM", "Yes")
                ElseIf (lDs.Tables(0).Rows(0).Item("AnotherInsuredDOB") <> "01/01/1900" AndAlso Left(lDs.Tables(0).Rows(0).Item("AnotherInsuredGender"), 1).ToString.ToUpper = "F") Then
                    pdfFormFields.SetField("chk11aInsuredPolicyGroupInsuredSexF", "Yes")
                End If
                If (lDs.Tables(0).Rows(0).Item("IsAnotherPlan").ToString.ToUpper = "Y") Then
                    pdfFormFields.SetField("chk11dInsuredPolicyGroupAnotherHealthPlanYes", "Yes")
                ElseIf (lDs.Tables(0).Rows(0).Item("IsAnotherPlan").ToString.ToUpper = "N") Then
                    pdfFormFields.SetField("chk11dInsuredPolicyGroupAnotherHealthPlanNo", "Yes")
                End If

                'Block 12
                pdfFormFields.SetField("txt12Patient/AuthorizedPersonSignature", lDs.Tables(0).Rows(0).Item("ReleaseInfoSignature").ToString)
                pdfFormFields.SetField("txt12Patient/AuthorizedPersonSignatureDate", lDs.Tables(0).Rows(0).Item("ReleaseInfoDate").ToString)

                'Block 13
                pdfFormFields.SetField("txt13Insured/AuthorizedPersonSignature", lDs.Tables(0).Rows(0).Item("PaymentSignature").ToString)

                'Block 14
                If (lDs.Tables(0).Rows(0).Item("DateOfOccurance") <> "01/01/1900") Then
                    pdfFormFields.SetField("txt14DateOfCurrent", lDs.Tables(0).Rows(0).Item("DateOfOccurance").ToString.Replace("/", "      "))
                Else
                    pdfFormFields.SetField("txt14DateOfCurrent", "")
                End If

                'Block 15
                If (lDs.Tables(0).Rows(0).Item("PreviousOccuranceDate") <> "01/01/1900") Then
                    pdfFormFields.SetField("txt15PatientSameIllnessFirstDate", lDs.Tables(0).Rows(0).Item("PreviousOccuranceDate").ToString.Replace("/", "      "))
                Else
                    pdfFormFields.SetField("txt15PatientSameIllnessFirstDate", "")
                End If


                'Block 16
                If (lDs.Tables(0).Rows(0).Item("UnableToWorkFrom") <> "01/01/1900") Then
                    pdfFormFields.SetField("txt16DatePatientUnableToWorkFrom", lDs.Tables(0).Rows(0).Item("UnableToWorkFrom").ToString.Replace("/", "      "))
                Else
                    pdfFormFields.SetField("txt16DatePatientUnableToWorkFrom", "")
                End If
                If (lDs.Tables(0).Rows(0).Item("UnableToWorkTo") <> "01/01/1900") Then
                    pdfFormFields.SetField("txt16DatePatientUnableToWorkTo", lDs.Tables(0).Rows(0).Item("UnableToWorkTo").ToString.Replace("/", "     "))
                Else
                    pdfFormFields.SetField("txt16DatePatientUnableToWorkTo", "")
                End If

                'Block 17
                pdfFormFields.SetField("txt17ReferringProviderName", lDs.Tables(0).Rows(0).Item("RefferingProviderName").ToString)
                pdfFormFields.SetField("txt17aReferringProviderOtherSources", "")
                pdfFormFields.SetField("txt17bReferringProviderNPI", lDs.Tables(0).Rows(0).Item("RefferingProviderNPI").ToString)

                'Block 18
                If (lDs.Tables(0).Rows(0).Item("HospitalizationDateFrom") <> "01/01/1900") Then
                    pdfFormFields.SetField("txt18HospitalizationDatesFrom", lDs.Tables(0).Rows(0).Item("HospitalizationDateFrom").ToString.Replace("/", "     "))
                Else
                    pdfFormFields.SetField("txt18HospitalizationDatesFrom", "")
                End If
                If (lDs.Tables(0).Rows(0).Item("HospitalizationDateTo") <> "01/01/1900") Then
                    pdfFormFields.SetField("txt18HospitalizationDateTo", lDs.Tables(0).Rows(0).Item("HospitalizationDateTo").ToString.Replace("/", "     "))
                Else
                    pdfFormFields.SetField("txt18HospitalizationDateTo", "")
                End If

                'Block 19
                pdfFormFields.SetField("txt19ReservedForLocalUse", lDs.Tables(0).Rows(0).Item("ReservedBlock19").ToString)

                'Block 20

                If (lDs.Tables(0).Rows(0).Item("OutsideLabCharges").ToString = "0" Or lDs.Tables(0).Rows(0).Item("OutsideLabCharges").ToString = "0.0") Then
                    pdfFormFields.SetField("txt20ChargesIntegralPart", "")
                    pdfFormFields.SetField("txt20ChargesFractionalPart", "")

                    If (lDs.Tables(0).Rows(0).Item("IsOutsideLab").ToString = "Y") Then
                        pdfFormFields.SetField("chk20OutsideLabYes", "Yes")
                    ElseIf (lDs.Tables(0).Rows(0).Item("IsOutsideLab").ToString = "N") Then
                        pdfFormFields.SetField("chk20OutsideLabNo", "Yes")
                    End If
                Else
                    If (lDs.Tables(0).Rows(0).Item("OutsideLabCharges").ToString.Contains(".")) Then
                        pdfFormFields.SetField("txt20ChargesIntegralPart", lDs.Tables(0).Rows(0).Item("OutsideLabCharges").ToString.Split(".")(0))
                        pdfFormFields.SetField("txt20ChargesFractionalPart", lDs.Tables(0).Rows(0).Item("OutsideLabCharges").ToString.Split(".")(1))
                    Else
                        pdfFormFields.SetField("txt20ChargesIntegralPart", lDs.Tables(0).Rows(0).Item("OutsideLabCharges").ToString)
                        pdfFormFields.SetField("txt20ChargesFractionalPart", "00")
                    End If

                    If (lDs.Tables(0).Rows(0).Item("IsOutsideLab").ToString.ToUpper = "Y") Then
                        pdfFormFields.SetField("chk20OutsideLabYes", "Yes")
                    ElseIf (lDs.Tables(0).Rows(0).Item("IsOutsideLab").ToString.ToUpper = "N") Then
                        pdfFormFields.SetField("chk20OutsideLabNo", "Yes")
                    End If

                End If


                'Block 21

                'ICD1
                If (lDs.Tables(0).Rows(0).Item("ICD1").ToString.ToUpper.Contains("E")) Then
                    If (lDs.Tables(0).Rows(0).Item("ICD1").ToString.Length > 3) Then
                        Dim lICD1vidE As String = lDs.Tables(0).Rows(0).Item("ICD1").ToString.Replace(".", "")
                        'lICD1vidE = lICD1vidE.Insert(3, "   ")
                        pdfFormFields.SetField("txt21Diagnosis1", lICD1vidE.Insert(0, "   "))
                    Else
                        pdfFormFields.SetField("txt21Diagnosis1", lDs.Tables(0).Rows(0).Item("ICD1").ToString.Insert(0, "   ").Replace(".", ""))
                    End If
                Else
                    If (lDs.Tables(0).Rows(0).Item("ICD1").ToString.Length > 3) Then
                        Dim lICD1 As String = lDs.Tables(0).Rows(0).Item("ICD1").ToString.Replace(".", "")
                        lICD1 = lICD1.Insert(3, "  ")
                        pdfFormFields.SetField("txt21Diagnosis1", lICD1.Insert(0, "   "))
                    Else
                        pdfFormFields.SetField("txt21Diagnosis1", lDs.Tables(0).Rows(0).Item("ICD1").ToString.Insert(0, "   ").Replace(".", ""))
                    End If
                End If

                'ICD2
                If (lDs.Tables(0).Rows(0).Item("ICD2").ToString.ToUpper.Contains("E")) Then
                    If (lDs.Tables(0).Rows(0).Item("ICD2").ToString.Length > 3) Then
                        Dim lICD1vidE As String = lDs.Tables(0).Rows(0).Item("ICD2").ToString
                        'lICD1vidE = lICD1vidE.Insert(3, " ")
                        pdfFormFields.SetField("txt21Diagnosis2", lICD1vidE.Insert(0, "   "))
                    Else
                        pdfFormFields.SetField("txt21Diagnosis2", lDs.Tables(0).Rows(0).Item("ICD2").ToString.Insert(0, "   "))
                    End If
                Else
                    If (lDs.Tables(0).Rows(0).Item("ICD2").ToString.Length > 3) Then
                        Dim lICD1 As String = lDs.Tables(0).Rows(0).Item("ICD2").ToString
                        lICD1 = lICD1.Insert(3, "  ")
                        pdfFormFields.SetField("txt21Diagnosis2", lICD1.Insert(0, "   "))
                    Else
                        pdfFormFields.SetField("txt21Diagnosis2", lDs.Tables(0).Rows(0).Item("ICD2").ToString.Insert(0, "   "))
                    End If
                End If

                'ICD3
                If (lDs.Tables(0).Rows(0).Item("ICD3").ToString.ToUpper.Contains("E")) Then
                    If (lDs.Tables(0).Rows(0).Item("ICD3").ToString.Length > 3) Then
                        Dim lICD1vidE As String = lDs.Tables(0).Rows(0).Item("ICD3").ToString
                        'lICD1vidE = lICD1vidE.Insert(3, "   ")
                        pdfFormFields.SetField("txt21Diagnosis3", lICD1vidE.Insert(0, "   "))
                    Else
                        pdfFormFields.SetField("txt21Diagnosis3", lDs.Tables(0).Rows(0).Item("ICD3").ToString.Insert(0, "   "))
                    End If
                Else
                    If (lDs.Tables(0).Rows(0).Item("ICD3").ToString.Length > 3) Then
                        Dim lICD1 As String = lDs.Tables(0).Rows(0).Item("ICD3").ToString
                        lICD1 = lICD1.Insert(3, "  ")
                        pdfFormFields.SetField("txt21Diagnosis3", lICD1.Insert(0, "   "))
                    Else
                        pdfFormFields.SetField("txt21Diagnosis3", lDs.Tables(0).Rows(0).Item("ICD3").ToString.Insert(0, "   "))
                    End If
                End If

                'ICD4
                If (lDs.Tables(0).Rows(0).Item("ICD4").ToString.ToUpper.Contains("E")) Then
                    If (lDs.Tables(0).Rows(0).Item("ICD4").ToString.Length > 3) Then
                        Dim lICD1vidE As String = lDs.Tables(0).Rows(0).Item("ICD4").ToString
                        'lICD1vidE = lICD1vidE.Insert(3, "   ")
                        pdfFormFields.SetField("txt21Diagnosis4", lICD1vidE.Insert(0, "   "))
                    Else
                        pdfFormFields.SetField("txt21Diagnosis4", lDs.Tables(0).Rows(0).Item("ICD4").ToString.Insert(0, "   "))
                    End If
                Else
                    If (lDs.Tables(0).Rows(0).Item("ICD4").ToString.Length > 3) Then
                        Dim lICD1 As String = lDs.Tables(0).Rows(0).Item("ICD4").ToString
                        lICD1 = lICD1.Insert(3, "  ")
                        pdfFormFields.SetField("txt21Diagnosis4", lICD1.Insert(0, "   "))
                    Else
                        pdfFormFields.SetField("txt21Diagnosis4", lDs.Tables(0).Rows(0).Item("ICD4").ToString.Insert(0, "   "))
                    End If
                End If


                'Block 22
                pdfFormFields.SetField("txt22MedicalReSubmissionCode", lDs.Tables(0).Rows(0).Item("MedicaidCode").ToString)
                pdfFormFields.SetField("txt22OriginalRefNo", lDs.Tables(0).Rows(0).Item("OriginalRefrenceNumber").ToString)

                'Block 23
                pdfFormFields.SetField("txt23PriorAuthorizationCode", lDs.Tables(0).Rows(0).Item("PriorAuthorizationNumber").ToString)

                'Block 24
                If (lDs.Tables(0).Rows(0).Item("DateOfServiceFrom").ToString <> "") Then
                    pdfFormFields.SetField("txt24aDateOfServiceFrom1", Convert.ToDateTime(lDs.Tables(0).Rows(0).Item("DateOfServiceFrom")).ToString("MM:dd:yy").ToString.Replace(":", "     "))
                    pdfFormFields.SetField("txt24aDateOfServiceTo1", Convert.ToDateTime(lDs.Tables(0).Rows(0).Item("DateOfServiceTo")).ToString("MM:dd:yy").ToString.Replace(":", "      "))
                End If
                pdfFormFields.SetField("txt24bPlaceOfService1", lDs.Tables(0).Rows(0).Item("PlaceOfService").ToString)
                pdfFormFields.SetField("txt24cEMG1", "")
                pdfFormFields.SetField("txt24dProceduralServiceOrSuppliesCPT/HCPCS1", lDs.Tables(0).Rows(0).Item("CPTCode").ToString)
                pdfFormFields.SetField("txt24dProceduralServiceOrSuppliesModifier1a", lDs.Tables(0).Rows(0).Item("ModifierA").ToString)
                pdfFormFields.SetField("txt24dProceduralServiceOrSuppliesModifier1b", lDs.Tables(0).Rows(0).Item("ModifierB").ToString)
                pdfFormFields.SetField("txt24dProceduralServiceOrSuppliesModifier1c", lDs.Tables(0).Rows(0).Item("ModifierC").ToString)
                pdfFormFields.SetField("txt24dProceduralServiceOrSuppliesModifier1d", lDs.Tables(0).Rows(0).Item("ModifierD").ToString)
                pdfFormFields.SetField("txt24eDiagnosisPointer1", lDs.Tables(0).Rows(0).Item("DignosisPointer").ToString)
                If (lDs.Tables(0).Rows(0).Item("Charges").ToString.Contains(".")) Then
                    pdfFormFields.SetField("txt24fCharges1", lDs.Tables(0).Rows(0).Item("Charges").ToString.Replace(".", "    "))
                Else
                    pdfFormFields.SetField("txt24fCharges1", lDs.Tables(0).Rows(0).Item("Charges").ToString)
                End If
                pdfFormFields.SetField("txt24gDaysOrUnit1", lDs.Tables(0).Rows(0).Item("Days").ToString)
                pdfFormFields.SetField("txt24hEPSDTFamilyPlan1", lDs.Tables(0).Rows(0).Item("EPSDT").ToString)
                pdfFormFields.SetField("txt24jRenderingProviderID#1", lDs.Tables(0).Rows(0).Item("NPI").ToString)

                If (lDs.Tables(0).Rows(1).Item("DateOfServiceFrom").ToString <> "") Then
                    pdfFormFields.SetField("txt24aDateOfServiceFrom2", Convert.ToDateTime(lDs.Tables(0).Rows(1).Item("DateOfServiceFrom")).ToString("MM:dd:yy").ToString.Replace(":", "     "))
                    pdfFormFields.SetField("txt24aDateOfServiceTo2", Convert.ToDateTime(lDs.Tables(0).Rows(1).Item("DateOfServiceTo")).ToString("MM:dd:yy").ToString.Replace(":", "      "))
                End If
                pdfFormFields.SetField("txt24bPlaceOfService2", lDs.Tables(0).Rows(1).Item("PlaceOfService").ToString)
                pdfFormFields.SetField("txt24cEMG2", "")
                pdfFormFields.SetField("txt24dProceduralServiceOrSuppliesCPT/HCPCS2", lDs.Tables(0).Rows(1).Item("CPTCode").ToString)
                pdfFormFields.SetField("txt24dProceduralServiceOrSuppliesModifier2a", lDs.Tables(0).Rows(1).Item("ModifierA").ToString)
                pdfFormFields.SetField("txt24dProceduralServiceOrSuppliesModifier2b", lDs.Tables(0).Rows(1).Item("ModifierB").ToString)
                pdfFormFields.SetField("txt24dProceduralServiceOrSuppliesModifier2c", lDs.Tables(0).Rows(1).Item("ModifierC").ToString)
                pdfFormFields.SetField("txt24dProceduralServiceOrSuppliesModifier2d", lDs.Tables(0).Rows(1).Item("ModifierD").ToString)
                pdfFormFields.SetField("txt24eDiagnosisPointer2", lDs.Tables(0).Rows(1).Item("DignosisPointer").ToString)
                If (lDs.Tables(0).Rows(1).Item("Charges").ToString.Contains(".")) Then
                    pdfFormFields.SetField("txt24fCharges2", lDs.Tables(0).Rows(1).Item("Charges").ToString.Replace(".", "    "))
                Else
                    pdfFormFields.SetField("txt24fCharges2", lDs.Tables(0).Rows(1).Item("Charges").ToString)
                End If
                pdfFormFields.SetField("txt24gDaysOrUnit2", lDs.Tables(0).Rows(1).Item("Days").ToString)
                pdfFormFields.SetField("txt24hEPSDTFamilyPlan2", lDs.Tables(0).Rows(1).Item("EPSDT").ToString)
                pdfFormFields.SetField("txt24jRenderingProviderID#2", lDs.Tables(0).Rows(1).Item("NPI").ToString)

                If (lDs.Tables(0).Rows(2).Item("DateOfServiceFrom").ToString <> "") Then
                    pdfFormFields.SetField("txt24aDateOfServiceFrom3", Convert.ToDateTime(lDs.Tables(0).Rows(2).Item("DateOfServiceFrom")).ToString("MM:dd:yy").ToString.Replace(":", "     "))
                    pdfFormFields.SetField("txt24aDateOfServiceTo3", Convert.ToDateTime(lDs.Tables(0).Rows(2).Item("DateOfServiceTo")).ToString("MM:dd:yy").ToString.Replace(":", "      "))
                End If
                pdfFormFields.SetField("txt24bPlaceOfService3", lDs.Tables(0).Rows(2).Item("PlaceOfService").ToString)
                pdfFormFields.SetField("txt24cEMG3", "")
                pdfFormFields.SetField("txt24dProceduralServiceOrSuppliesCPT/HCPCS3", lDs.Tables(0).Rows(2).Item("CPTCode").ToString)
                pdfFormFields.SetField("txt24dProceduralServiceOrSuppliesModifier3a", lDs.Tables(0).Rows(2).Item("ModifierA").ToString)
                pdfFormFields.SetField("txt24dProceduralServiceOrSuppliesModifier3b", lDs.Tables(0).Rows(2).Item("ModifierB").ToString)
                pdfFormFields.SetField("txt24dProceduralServiceOrSuppliesModifier3c", lDs.Tables(0).Rows(2).Item("ModifierC").ToString)
                pdfFormFields.SetField("txt24dProceduralServiceOrSuppliesModifier3d", lDs.Tables(0).Rows(2).Item("ModifierD").ToString)
                pdfFormFields.SetField("txt24eDiagnosisPointer3", lDs.Tables(0).Rows(2).Item("DignosisPointer").ToString)
                If (lDs.Tables(0).Rows(2).Item("Charges").ToString.Contains(".")) Then
                    pdfFormFields.SetField("txt24fCharges3", lDs.Tables(0).Rows(2).Item("Charges").ToString.Replace(".", "    "))
                Else
                    pdfFormFields.SetField("txt24fCharges3", lDs.Tables(0).Rows(2).Item("Charges").ToString)
                End If
                pdfFormFields.SetField("txt24gDaysOrUnit3", lDs.Tables(0).Rows(2).Item("Days").ToString)
                pdfFormFields.SetField("txt24hEPSDTFamilyPlan3", lDs.Tables(0).Rows(2).Item("EPSDT").ToString)
                pdfFormFields.SetField("txt24jRenderingProviderID#3", lDs.Tables(0).Rows(2).Item("NPI").ToString)

                If (lDs.Tables(0).Rows(3).Item("DateOfServiceFrom").ToString <> "") Then
                    pdfFormFields.SetField("txt24aDateOfServiceFrom4", Convert.ToDateTime(lDs.Tables(0).Rows(3).Item("DateOfServiceFrom")).ToString("MM:dd:yy").ToString.Replace(":", "     "))
                    pdfFormFields.SetField("txt24aDateOfServiceTo4", Convert.ToDateTime(lDs.Tables(0).Rows(3).Item("DateOfServiceTo")).ToString("MM:dd:yy").ToString.Replace(":", "     "))
                End If
                pdfFormFields.SetField("txt24bPlaceOfService4", lDs.Tables(0).Rows(3).Item("PlaceOfService").ToString)
                pdfFormFields.SetField("txt24cEMG4", "")
                pdfFormFields.SetField("txt24dProceduralServiceOrSuppliesCPT/HCPCS4", lDs.Tables(0).Rows(3).Item("CPTCode").ToString)
                pdfFormFields.SetField("txt24dProceduralServiceOrSuppliesModifier4a", lDs.Tables(0).Rows(3).Item("ModifierA").ToString)
                pdfFormFields.SetField("txt24dProceduralServiceOrSuppliesModifier4b", lDs.Tables(0).Rows(3).Item("ModifierB").ToString)
                pdfFormFields.SetField("txt24dProceduralServiceOrSuppliesModifier4c", lDs.Tables(0).Rows(3).Item("ModifierC").ToString)
                pdfFormFields.SetField("txt24dProceduralServiceOrSuppliesModifier4d", lDs.Tables(0).Rows(3).Item("ModifierD").ToString)
                pdfFormFields.SetField("txt24eDiagnosisPointer4", lDs.Tables(0).Rows(3).Item("DignosisPointer").ToString)
                If (lDs.Tables(0).Rows(3).Item("Charges").ToString.Contains(".")) Then
                    pdfFormFields.SetField("txt24fCharges4", lDs.Tables(0).Rows(3).Item("Charges").ToString.Replace(".", "    "))
                Else
                    pdfFormFields.SetField("txt24fCharges4", lDs.Tables(0).Rows(3).Item("Charges").ToString)
                End If
                pdfFormFields.SetField("txt24gDaysOrUnit4", lDs.Tables(0).Rows(3).Item("Days").ToString)
                pdfFormFields.SetField("txt24hEPSDTFamilyPlan4", lDs.Tables(0).Rows(3).Item("EPSDT").ToString)
                pdfFormFields.SetField("txt24jRenderingProviderID#4", lDs.Tables(0).Rows(3).Item("NPI").ToString)

                If (lDs.Tables(0).Rows(4).Item("DateOfServiceFrom").ToString <> "") Then
                    pdfFormFields.SetField("txt24aDateOfServiceFrom5", Convert.ToDateTime(lDs.Tables(0).Rows(4).Item("DateOfServiceFrom")).ToString("MM:dd:yy").ToString.Replace(":", "     "))
                    pdfFormFields.SetField("txt24aDateOfServiceTo5", Convert.ToDateTime(lDs.Tables(0).Rows(4).Item("DateOfServiceTo")).ToString("MM:dd:yy").ToString.Replace(":", "     "))
                End If
                pdfFormFields.SetField("txt24bPlaceOfService5", lDs.Tables(0).Rows(4).Item("PlaceOfService").ToString)
                pdfFormFields.SetField("txt24cEMG5", "")
                pdfFormFields.SetField("txt24dProceduralServiceOrSuppliesCPT/HCPCS5", lDs.Tables(0).Rows(4).Item("CPTCode").ToString)
                pdfFormFields.SetField("txt24dProceduralServiceOrSuppliesModifier5a", lDs.Tables(0).Rows(4).Item("ModifierA").ToString)
                pdfFormFields.SetField("txt24dProceduralServiceOrSuppliesModifier5b", lDs.Tables(0).Rows(4).Item("ModifierB").ToString)
                pdfFormFields.SetField("txt24dProceduralServiceOrSuppliesModifier5c", lDs.Tables(0).Rows(4).Item("ModifierC").ToString)
                pdfFormFields.SetField("txt24dProceduralServiceOrSuppliesModifier5d", lDs.Tables(0).Rows(4).Item("ModifierD").ToString)
                pdfFormFields.SetField("txt24eDiagnosisPointer5", lDs.Tables(0).Rows(4).Item("DignosisPointer").ToString)
                If (lDs.Tables(0).Rows(4).Item("Charges").ToString.Contains(".")) Then
                    pdfFormFields.SetField("txt24fCharges5", lDs.Tables(0).Rows(4).Item("Charges").ToString.Replace(".", "    "))
                Else
                    pdfFormFields.SetField("txt24fCharges5", lDs.Tables(0).Rows(4).Item("Charges").ToString)
                End If
                pdfFormFields.SetField("txt24gDaysOrUnit5", lDs.Tables(0).Rows(4).Item("Days").ToString)
                pdfFormFields.SetField("txt24hEPSDTFamilyPlan5", lDs.Tables(0).Rows(4).Item("EPSDT").ToString)
                pdfFormFields.SetField("txt24jRenderingProviderID#5", lDs.Tables(0).Rows(4).Item("NPI").ToString)

                If (lDs.Tables(0).Rows(5).Item("DateOfServiceFrom").ToString <> "") Then
                    pdfFormFields.SetField("txt24aDateOfServiceFrom6", Convert.ToDateTime(lDs.Tables(0).Rows(5).Item("DateOfServiceFrom")).ToString("MM:dd:yy").ToString.Replace(":", "     "))
                    pdfFormFields.SetField("txt24aDateOfServiceTo6", Convert.ToDateTime(lDs.Tables(0).Rows(5).Item("DateOfServiceTo")).ToString("MM:dd:yy").ToString.Replace(":", "     "))
                End If
                pdfFormFields.SetField("txt24bPlaceOfService6", lDs.Tables(0).Rows(5).Item("PlaceOfService").ToString)
                pdfFormFields.SetField("txt24cEMG6", "")
                pdfFormFields.SetField("txt24dProceduralServiceOrSuppliesCPT/HCPCS6", lDs.Tables(0).Rows(5).Item("CPTCode").ToString)
                pdfFormFields.SetField("txt24dProceduralServiceOrSuppliesModifier6a", lDs.Tables(0).Rows(5).Item("ModifierA").ToString)
                pdfFormFields.SetField("txt24dProceduralServiceOrSuppliesModifier6b", lDs.Tables(0).Rows(5).Item("ModifierB").ToString)
                pdfFormFields.SetField("txt24dProceduralServiceOrSuppliesModifier6c", lDs.Tables(0).Rows(5).Item("ModifierC").ToString)
                pdfFormFields.SetField("txt24dProceduralServiceOrSuppliesModifier6d", lDs.Tables(0).Rows(5).Item("ModifierD").ToString)
                pdfFormFields.SetField("txt24eDiagnosisPointer6", lDs.Tables(0).Rows(5).Item("DignosisPointer").ToString)
                If (lDs.Tables(0).Rows(5).Item("Charges").ToString.Contains(".")) Then
                    pdfFormFields.SetField("txt24fCharges6", lDs.Tables(0).Rows(5).Item("Charges").ToString.Replace(".", "    "))
                Else
                    pdfFormFields.SetField("txt24fCharges6", lDs.Tables(0).Rows(5).Item("Charges").ToString)
                End If
                pdfFormFields.SetField("txt24gDaysOrUnit6", lDs.Tables(0).Rows(5).Item("Days").ToString)
                pdfFormFields.SetField("txt24hEPSDTFamilyPlan6", lDs.Tables(0).Rows(5).Item("EPSDT").ToString)
                pdfFormFields.SetField("txt24jRenderingProviderID#6", lDs.Tables(0).Rows(5).Item("NPI").ToString)

                'Block 25
                pdfFormFields.SetField("txt25FederalTaxID#", lDs.Tables(0).Rows(0).Item("FederalTaxID").ToString)
                If (lDs.Tables(0).Rows(0).Item("IsSSN").ToString.ToUpper = "Y") Then
                    pdfFormFields.SetField("chk25FederalTaxID#SSN", "Yes")
                ElseIf (lDs.Tables(0).Rows(0).Item("IsSSN").ToString.ToUpper = "N") Then
                    pdfFormFields.SetField("chk25FederalTaxID#EIN", "Yes")
                End If

                'Block 26
                pdfFormFields.SetField("txt26PatientAccountNo", lDs.Tables(0).Rows(0).Item("PatientAccountNumber").ToString)

                'Block 27
                If (lDs.Tables(0).Rows(0).Item("IsAcceptAssignment").ToString.ToUpper = "Y") Then
                    pdfFormFields.SetField("chk27AcceptAssigementYes", "Yes")
                ElseIf (lDs.Tables(0).Rows(0).Item("IsAcceptAssignment").ToString.ToUpper = "N") Then
                    pdfFormFields.SetField("chk27AcceptAssigementNo", "Yes")
                End If

                'Block 28
                If (lDs.Tables(0).Rows(0).Item("TotalCharge").ToString.Contains(".")) Then
                    pdfFormFields.SetField("txt28TotalChargesIntegralPart", lDs.Tables(0).Rows(0).Item("TotalCharge").ToString.Split(".")(0))
                    pdfFormFields.SetField("txt28TotalChargesFractionalPart", lDs.Tables(0).Rows(0).Item("TotalCharge").ToString.Split(".")(1))
                Else
                    pdfFormFields.SetField("txt28TotalChargesIntegralPart", lDs.Tables(0).Rows(0).Item("TotalCharge").ToString)
                    pdfFormFields.SetField("txt28TotalChargesFractionalPart", "00")
                End If

                'Block 29
                If (lDs.Tables(0).Rows(0).Item("AmountPaid").ToString.Contains(".")) Then
                    pdfFormFields.SetField("txt29AmountPaidIntegralPart", lDs.Tables(0).Rows(0).Item("AmountPaid").ToString.Split(".")(0))
                    pdfFormFields.SetField("txt29AmountPaidFractionalPart", lDs.Tables(0).Rows(0).Item("AmountPaid").ToString.Split(".")(1))
                Else
                    pdfFormFields.SetField("txt29AmountPaidIntegralPart", lDs.Tables(0).Rows(0).Item("AmountPaid").ToString)
                    pdfFormFields.SetField("txt29AmountPaidFractionalPart", "00")
                End If

                'Block 30
                If (lDs.Tables(0).Rows(0).Item("BalanceDue").ToString.Contains(".")) Then
                    pdfFormFields.SetField("txt30BalanceDueIntegralPart", lDs.Tables(0).Rows(0).Item("BalanceDue").ToString.Split(".")(0))
                    pdfFormFields.SetField("txt30BalanceDueFractionalPart", lDs.Tables(0).Rows(0).Item("BalanceDue").ToString.Split(".")(1))
                Else
                    pdfFormFields.SetField("txt30BalanceDueIntegralPart", lDs.Tables(0).Rows(0).Item("BalanceDue").ToString)
                    pdfFormFields.SetField("txt30BalanceDueFractionalPart", "00")
                End If

                'Block 31
                pdfFormFields.SetField("txt31Physician/SupplierSignature", lDs.Tables(0).Rows(0).Item("ProviderName").ToString)
                pdfFormFields.SetField("txt31Physician/SupplierSignatureDate", lDs.Tables(0).Rows(0).Item("HCFAPreparedDate").ToString)

                'Block 32
                pdfFormFields.SetField("txt32ServiceFacilityName", lDs.Tables(0).Rows(0).Item("FacilityName").ToString)
                pdfFormFields.SetField("txt32ServiceFacilityAddress", lDs.Tables(0).Rows(0).Item("FacilityAddress").ToString)
                Dim lFacilityCityStateZip As String = ""
                Dim lFacilityZipCode As String = lDs.Tables(0).Rows(0).Item("FacilityZipCode").ToString
                If (lFacilityZipCode.Length > 5) Then
                    lFacilityZipCode = lFacilityZipCode.Insert(5, "-")
                End If
                lFacilityCityStateZip = lDs.Tables(0).Rows(0).Item("FacilityCity").ToString & " " & lDs.Tables(0).Rows(0).Item("FacilityState").ToString & " " & lFacilityZipCode
                pdfFormFields.SetField("txt32ServiceFacilityCityStateZip", lFacilityCityStateZip)
                pdfFormFields.SetField("txt32ServiceFacilityNPI", lDs.Tables(0).Rows(0).Item("FacilityProvider").ToString)
                Dim ltxt32SerFacOthrSource As String = lDs.Tables(0).Rows(0).Item("FacilitySecondaryIdentificationQualifier").ToString & " " & lDs.Tables(0).Rows(0).Item("FacilityCode").ToString
                pdfFormFields.SetField("txt32ServiceFacilityOtherSources", ltxt32SerFacOthrSource)

                'Block 33
                If (lDs.Tables(0).Rows(0).Item("ClinicPhoneNumber").ToString.Length > 4) Then
                    'pdfFormFields.SetField("txt33BillingProviderPhone#", lDs.Tables(0).Rows(0).Item("ClinicPhoneNumber").ToString.Insert(3, " "))
                    pdfFormFields.SetField("txt33BillingProviderPhone#", lDs.Tables(0).Rows(0).Item("ClinicPhoneNumber").ToString.Insert(3, "    ").Insert(0, "  "))
                Else
                    pdfFormFields.SetField("txt33BillingProviderPhone#", "")
                End If
                pdfFormFields.SetField("txt33BillingProviderName", lDs.Tables(0).Rows(0).Item("ClinicName").ToString)
                pdfFormFields.SetField("txt33BillingProviderAddress", lDs.Tables(0).Rows(0).Item("ClinicAddress").ToString)
                Dim ltxt33BillingProviderCityStateZip As String = ""
                Dim lClinicZipCode As String = lDs.Tables(0).Rows(0).Item("ClinicZip").ToString
                If (lClinicZipCode.Length > 5) Then
                    lClinicZipCode = lClinicZipCode.Insert(5, "-")
                End If
                ltxt33BillingProviderCityStateZip = lDs.Tables(0).Rows(0).Item("ClinicCity").ToString & " " & lDs.Tables(0).Rows(0).Item("ClinicState").ToString & " " & lClinicZipCode
                pdfFormFields.SetField("txt33BillingProviderCityStateZip", ltxt33BillingProviderCityStateZip)
                pdfFormFields.SetField("txt33BillingProviderNPI", lDs.Tables(0).Rows(0).Item("ClinicPinNumber").ToString)
                Dim ltxt33BillingProviderOtherSources As String = lDs.Tables(0).Rows(0).Item("ClinicSecondaryIdentificationQualifier").ToString & " " & lDs.Tables(0).Rows(0).Item("ClinicGroupNumber").ToString
                pdfFormFields.SetField("txt33BillingProviderOtherSources", ltxt33BillingProviderOtherSources)
            End If

            ' Set True to make new saved file un-editable
            lPdfStamper.FormFlattening = True




            Return lNewClaimPath
        Catch ex As Exception
            Return ""
        Finally
            If (lPdfStamper IsNot Nothing) Then
                lPdfStamper.Close()
            End If

        End Try


    End Function
    Public Sub ViewPdf(ByVal pPdfPath As String)
        Dim lClient As System.Net.WebClient = New System.Net.WebClient()
        Dim lBuffer As Byte() = lClient.DownloadData(pPdfPath)

        If (lBuffer IsNot Nothing) Then
            Response.ClearHeaders()
            Response.ClearContent()
            Response.ContentType = "application/pdf"
            Response.AddHeader("Content-Disposition", "inline")
            Response.AddHeader("content-length", lBuffer.Length.ToString())
            Response.BinaryWrite(lBuffer)
            Response.End()
        End If


    End Sub

End Class

