Imports Telerik.WebControls
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Partial Class Billing_AgingReportByCriteria
    Inherits System.Web.UI.Page
    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        'Try
        '    If (Page.IsPostBack) Then
        '        LoadReport()
        '    End If
        'Catch ex As Exception

        'End Try
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Try
            If Not Page.IsPostBack Then
                Me.dtDosFrom.DbSelectedDate = Today.Date.AddMonths(-6)
                Me.dtDOSTo.DbSelectedDate = Today.Date


                Me.dtDosFrom.MaxDate = Date.Now
                Me.dtDOSTo.MaxDate = Date.Now

                ShowPanel()
            Else
                ShowPanel()
                LoadReport()
            End If
        Catch ex As Exception
        End Try
    End Sub
    Private Sub ShowPanel()
        If (Me.rdbCriteria.SelectedValue = 1) Then
            Me.pnlPayer.Style("display") = "block"
            Me.pnlPatient.Style("display") = "none"
            Me.pnlAccount.Style("display") = "none"
            Me.pnlDOS.Style("display") = "none"
        ElseIf (Me.rdbCriteria.SelectedValue = 2) Then
            Me.pnlPayer.Style("display") = "none"
            Me.pnlPatient.Style("display") = "block"
            Me.pnlAccount.Style("display") = "none"
            Me.pnlDOS.Style("display") = "none"
        ElseIf (Me.rdbCriteria.SelectedValue = 3) Then
            Me.pnlPayer.Style("display") = "none"
            Me.pnlPatient.Style("display") = "none"
            Me.pnlAccount.Style("display") = "block"
            Me.pnlDOS.Style("display") = "none"
        ElseIf (Me.rdbCriteria.SelectedValue = 4) Then
            Me.pnlPayer.Style("display") = "none"
            Me.pnlPatient.Style("display") = "none"
            Me.pnlAccount.Style("display") = "none"
            Me.pnlDOS.Style("display") = "block"
        End If
    End Sub
    'Protected Sub rdbCriteria_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdbCriteria.SelectedIndexChanged
    '    Try
    '        If Me.rdbCriteria.SelectedIndex = 0 Then
    '            Me.pnlPayer.Visible = True
    '            pnlReportViewer.Enabled = True

    '            pnlGrid.Enabled = False
    '            Me.pnlPatient.Visible = False
    '            Me.pnlAccount.Visible = False
    '            Me.pnlDOS.Visible = False

    '        ElseIf Me.rdbCriteria.SelectedIndex = 1 Then

    '            Me.pnlPatient.Visible = True
    '            pnlReportViewer.Enabled = True

    '            pnlGrid.Enabled = False
    '            Me.pnlPayer.Visible = False
    '            Me.pnlAccount.Visible = False
    '            Me.pnlDOS.Visible = False

    '        ElseIf Me.rdbCriteria.SelectedIndex = 2 Then

    '            Me.pnlAccount.Visible = True
    '            pnlReportViewer.Enabled = True

    '            pnlGrid.Enabled = False
    '            Me.pnlPatient.Visible = False
    '            Me.pnlPayer.Visible = False
    '            Me.pnlDOS.Visible = False

    '        ElseIf Me.rdbCriteria.SelectedIndex = 3 Then
    '            Me.pnlDOS.Visible = True
    '            pnlReportViewer.Enabled = True

    '            pnlGrid.Enabled = False
    '            Me.pnlAccount.Visible = False
    '            Me.pnlPatient.Visible = False
    '            Me.pnlPayer.Visible = False

    '        End If
    '    Catch ex As Exception

    '    End Try
    'End Sub
    Protected Sub cmbPayer_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbPayer.ItemsRequested

        Dim lUser As User


        If (Session.Count = 0) Then
            Exit Sub
        End If


        Try

            If e.Text = "" Then
                Exit Sub
            End If

            lUser = CType(Session.Item("User"), User)

            Dim lInsurance As Insurance = New Insurance(lUser.ConnectionString)

            cmbPayer.DataSource = lInsurance.GetAllRecords("AND IsDelete= 'N' And CompanyName like '" & Utility.AdjustApostrophie(e.Text) & "%'Order By CompanyName asc").Tables(0)
            cmbPayer.DataTextField = "CompanyName"
            cmbPayer.DataBind()
            cmbPayer.Items.Insert(0, New RadComboBoxItem(""))


        Catch ex As Exception
            Dim lLogID As String
            lLogID = ErrorLogMethods.LogError(ex, " : UserControls\UserControls_PatientSearch.cmbLastName_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs)  ")
            Response.Redirect("ErrorPage.aspx?LogID=" & lLogID)

        End Try
    End Sub
    Protected Sub btnSearchPayer_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSearchPayer.Click
        Try
            RemoveReportDoc()
            LoadReport()
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub btnSearchDOS_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSearchDOS.Click
        Try
            RemoveReportDoc()
            LoadReport()
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub btnSearchAccount_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSearchAccount.Click
        Try
            RemoveReportDoc()
            LoadReport()
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub btnSearchPatient_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSearchPatient.Click
        Try
            RemoveReportDoc()
            LoadReport()
        Catch ex As Exception

        End Try
    End Sub
    'Public Sub LoadAgingByDOSReport()
    '    Dim myReportDocument As New ReportDocument()
    '    Dim lSpParameter(2) As SpParameter
    '    Dim lDs As DataSet
    '    Dim lClinicDS As DataSet
    '    Dim lUser As User = CType(HttpContext.Current.Session("User"), User)
    '    Dim lConnection As New Connection(lUser.ConnectionString)
    '    Dim lClinic As New Clinic(lUser.ConnectionString)
    '    Dim lParameterFields As New ParameterFields()
    '    Dim lParameterField As New ParameterField()
    '    Dim lParameterValue As New ParameterDiscreteValue()
    '    Dim lQueryForReport As String = ""

    '    Try
    '        lDs = New DataSet
    '        lClinicDS = New DataSet

    '        lQueryForReport = "select top 1 ClaimID='CL 2010-10-00001',FillingDate='1/1/2010',ReFillingDate='2/2/2010',Notes='Notes goes here,Notes goes here-1',DOS='1/1/2010',PatientName='Patient1(a)',Charges='100',Days0to30=10,Days31to60=20,Days61to90=30,Days91plus=40,DaysTotal=91,Extra1='',Extra2='',Extra3='',Extra4='' from PatientLedger " _
    '        & "union all select top 1 ClaimID='CL 2010-10-00002',FillingDate='2/2/2010',ReFillingDate='3/3/2010',Notes='Notes goes here,Notes goes here-2',DOS='1/1/2010',PatientName='Patient1(a)',Charges='100',Days0to30=10,Days31to60=20,Days61to90=30,Days91plus=40,DaysTotal=91,Extra1='',Extra2='',Extra3='',Extra4='' from PatientLedger " _
    '        & "union all select top 1 ClaimID='CL 2010-10-00003',FillingDate='3/3/2010',ReFillingDate='4/4/2010',Notes='Notes goes here,Notes goes here-3',DOS='1/1/2010',PatientName='Patient1(b)',Charges='100',Days0to30=10,Days31to60=20,Days61to90=30,Days91plus=40,DaysTotal=91,Extra1='0010',Extra2='',Extra3='',Extra4='' from PatientLedger " _
    '        & "union all select top 1 ClaimID='CL 2010-10-00004',FillingDate='4/4/2010',ReFillingDate='5/5/2010',Notes='Notes goes here,Notes goes here-4',DOS='2/2/2010',PatientName='Patient2(a)',Charges='100',Days0to30=-10,Days31to60=20,Days61to90=30,Days91plus=40,DaysTotal=90,Extra1='0010',Extra2='',Extra3='',Extra4='' from PatientLedger"

    '        lDs = lConnection.ExecuteQuery(lQueryForReport)

    '        lClinicDS = lClinic.GetClinicInfoForReports(lUser.ClinicId)

    '        lDs.Tables(0).TableName = "AgingReportByDOS"

    '        If lDs.Tables(0).Rows.Count > 0 Then

    '            myReportDocument.Load(Server.MapPath("Reports/AgingReportByDOS.rpt"))

    '            myReportDocument.SetDataSource(lDs.Tables("AgingReportByDOS"))

    '            myReportDocument.SetParameterValue("ClinicName", lClinicDS.Tables(0).Rows(0)("ClinicName"))
    '            myReportDocument.SetParameterValue("ClinicAddress", lClinicDS.Tables(0).Rows(0)("ClinicAddressLine1") + " " + lClinicDS.Tables(0).Rows(0)("ClinicCity") + " " + lClinicDS.Tables(0).Rows(0)("ClinicState") + " " + lClinicDS.Tables(0).Rows(0)("ClinicZipCode"))
    '            crvAgingByCriteria.ParameterFieldInfo = lParameterFields

    '            Me.pnlReportViewer.Visible = True
    '            Me.crvAgingByCriteria.ReportSource = myReportDocument
    '            Session.Add("ReportDocument", myReportDocument)

    '            Me.crvAgingByCriteria.Zoom(135)
    '            Me.crvAgingByCriteria.BestFitPage = False
    '            Me.crvAgingByCriteria.DisplayGroupTree = False
    '            Me.crvAgingByCriteria.HasViewList = False
    '            Me.crvAgingByCriteria.HasDrillUpButton = False
    '            Me.crvAgingByCriteria.HasZoomFactorList = False
    '            Me.crvAgingByCriteria.HasExportButton = False
    '            Me.crvAgingByCriteria.HasSearchButton = False
    '            Me.crvAgingByCriteria.HasPageNavigationButtons = False
    '            Me.crvAgingByCriteria.HasToggleGroupTreeButton = False
    '            Me.crvAgingByCriteria.HasCrystalLogo = False
    '            Me.crvAgingByCriteria.HasDrillUpButton = False
    '            Me.crvAgingByCriteria.HasGotoPageButton = False
    '            Me.crvAgingByCriteria.Width = New Unit("100%")
    '            Me.crvAgingByCriteria.Height = New Unit("1500")
    '            Me.crvAgingByCriteria.EnableDrillDown = False
    '            Me.crvAgingByCriteria.DataBind()

    '            Me.crvAgingByCriteria.PrintMode = CrystalDecisions.Web.PrintMode.ActiveX
    '        End If



    '    Catch ex As Exception
    '        Response.Write("<script>alert('Error Generating Report, Contact your System administrator');</script>")
    '        Return
    '    End Try
    'End Sub
    'Public Sub LoadAgingByAccountReport()
    '    Dim myReportDocument As New ReportDocument()
    '    Dim lSpParameter(2) As SpParameter
    '    Dim lDs As DataSet
    '    Dim lClinicDS As DataSet
    '    Dim lUser As User = CType(HttpContext.Current.Session("User"), User)
    '    Dim lConnection As New Connection(lUser.ConnectionString)
    '    Dim lClinic As New Clinic(lUser.ConnectionString)
    '    Dim lParameterFields As New ParameterFields()
    '    Dim lParameterField As New ParameterField()
    '    Dim lParameterValue As New ParameterDiscreteValue()

    '    Try
    '        lDs = New DataSet
    '        lClinicDS = New DataSet


    '        '    lDs = AgingReportMethods.GetReportByPayerDOS(cmbPayer.Text)
    '        'ElseIf (rdbDatePayer.SelectedValue = "F") Then
    '        '    lDs = AgingReportMethods.GetReportByPayerFillingDate(cmbPayer.Text)


    '        lClinicDS = lClinic.GetClinicInfoForReports(lUser.ClinicId)

    '        lDs.Tables(0).TableName = "AgingReportByAccount"
    '        If lDs.Tables(0).Rows.Count > 0 Then

    '            myReportDocument.Load(Server.MapPath("Reports/AgingReportByAccount.rpt"))
    '            myReportDocument.SetDataSource(lDs)
    '            myReportDocument.SetParameterValue("PClinicName", lClinicDS.Tables(0).Rows(0)("ClinicName"))
    '            myReportDocument.SetParameterValue("PClinicAddress", lClinicDS.Tables(0).Rows(0)("ClinicAddressLine1") + " " + lClinicDS.Tables(0).Rows(0)("ClinicCity") + " " + lClinicDS.Tables(0).Rows(0)("ClinicState") + " " + lClinicDS.Tables(0).Rows(0)("ClinicZipCode"))
    '            crvAgingByCriteria.ParameterFieldInfo = lParameterFields

    '            Me.pnlReportViewer.Visible = True
    '            Me.crvAgingByCriteria.ReportSource = myReportDocument


    '            Session.Add("ReportDocument", myReportDocument)

    '            Me.crvAgingByCriteria.Zoom(125)
    '            Me.crvAgingByCriteria.BestFitPage = False
    '            Me.crvAgingByCriteria.DisplayGroupTree = False
    '            Me.crvAgingByCriteria.HasViewList = False
    '            Me.crvAgingByCriteria.HasDrillUpButton = False
    '            Me.crvAgingByCriteria.HasZoomFactorList = False
    '            Me.crvAgingByCriteria.HasExportButton = False
    '            Me.crvAgingByCriteria.HasSearchButton = False
    '            Me.crvAgingByCriteria.HasPageNavigationButtons = False
    '            Me.crvAgingByCriteria.HasToggleGroupTreeButton = False
    '            Me.crvAgingByCriteria.HasCrystalLogo = False
    '            Me.crvAgingByCriteria.HasDrillUpButton = False
    '            Me.crvAgingByCriteria.HasGotoPageButton = False
    '            Me.crvAgingByCriteria.Width = New Unit("100%")
    '            Me.crvAgingByCriteria.Height = New Unit("1500")

    '            Me.crvAgingByCriteria.DataBind()

    '            Me.crvAgingByCriteria.PrintMode = CrystalDecisions.Web.PrintMode.ActiveX
    '        End If



    '    Catch ex As Exception
    '        Response.Write("<script>alert('Error Generating Report, Contact your System administrator');</script>")
    '        Return
    '    End Try
    'End Sub
    'Private Sub LoadAgingByPayerReport()
    '    Dim myReportDocument As New ReportDocument()
    '    Dim lSpParameter(2) As SpParameter
    '    Dim lDs As DataSet
    '    Dim lClinicDS As DataSet
    '    Dim lUser As User = CType(HttpContext.Current.Session("User"), User)
    '    Dim lConnection As New Connection(lUser.ConnectionString)
    '    Dim lClinic As New Clinic(lUser.ConnectionString)
    '    Dim lParameterFields As New ParameterFields()
    '    Dim lParameterField As New ParameterField()
    '    Dim lParameterValue As New ParameterDiscreteValue()

    '    Try
    '        lDs = New DataSet
    '        lClinicDS = New DataSet

    '        If (rdbDatePayer.SelectedValue = "D") Then
    '            lDs = AgingReportMethods.GetReportByPayerDOS(cmbPayer.Text)
    '        ElseIf (rdbDatePayer.SelectedValue = "F") Then
    '            lDs = AgingReportMethods.GetReportByPayerFillingDate(cmbPayer.Text)
    '        End If

    '        lClinicDS = lClinic.GetClinicInfoForReports(lUser.ClinicId)

    '        lDs.Tables(0).TableName = "AgingReportByPayer"
    '        If lDs.Tables(0).Rows.Count > 0 Then

    '            myReportDocument.Load(Server.MapPath("Reports/AgingReportByPayer.rpt"))
    '            myReportDocument.SetDataSource(lDs)
    '            myReportDocument.SetParameterValue("PClinicName", lClinicDS.Tables(0).Rows(0)("ClinicName"))
    '            myReportDocument.SetParameterValue("PClinicAddress", lClinicDS.Tables(0).Rows(0)("ClinicAddressLine1") + " " + lClinicDS.Tables(0).Rows(0)("ClinicCity") + " " + lClinicDS.Tables(0).Rows(0)("ClinicState") + " " + lClinicDS.Tables(0).Rows(0)("ClinicZipCode"))
    '            crvAgingByCriteria.ParameterFieldInfo = lParameterFields

    '            Me.pnlReportViewer.Visible = True
    '            Me.crvAgingByCriteria.ReportSource = myReportDocument


    '            Session.Add("ReportDocument", myReportDocument)

    '            Me.crvAgingByCriteria.Zoom(125)
    '            Me.crvAgingByCriteria.BestFitPage = False
    '            Me.crvAgingByCriteria.DisplayGroupTree = False
    '            Me.crvAgingByCriteria.HasViewList = False
    '            Me.crvAgingByCriteria.HasDrillUpButton = False
    '            Me.crvAgingByCriteria.HasZoomFactorList = False
    '            Me.crvAgingByCriteria.HasExportButton = False
    '            Me.crvAgingByCriteria.HasSearchButton = False
    '            Me.crvAgingByCriteria.HasPageNavigationButtons = False
    '            Me.crvAgingByCriteria.HasToggleGroupTreeButton = False
    '            Me.crvAgingByCriteria.HasCrystalLogo = False
    '            Me.crvAgingByCriteria.HasDrillUpButton = False
    '            Me.crvAgingByCriteria.HasGotoPageButton = False
    '            Me.crvAgingByCriteria.Width = New Unit("100%")
    '            Me.crvAgingByCriteria.Height = New Unit("1500")

    '            Me.crvAgingByCriteria.DataBind()

    '            Me.crvAgingByCriteria.PrintMode = CrystalDecisions.Web.PrintMode.ActiveX
    '        End If



    '    Catch ex As Exception
    '        Response.Write("<script>alert('Error Generating Report, Contact your System administrator');</script>")
    '        Return
    '    End Try
    'End Sub
    Public Sub LoadReport()
        Try
            If (Me.rdbCriteria.SelectedValue = 1) Then
                BindReport("payer")
            ElseIf (Me.rdbCriteria.SelectedValue = 2) Then
                BindReport("patient")
            ElseIf (Me.rdbCriteria.SelectedValue = 3) Then
                BindReport("account")
            ElseIf (Me.rdbCriteria.SelectedValue = 4) Then
                BindReport("dos")
            End If

            'If Me.pnlPayer.Visible = True Then
            '    BindReport("payer")
            'ElseIf (Me.pnlDOS.Visible = True) Then
            '    BindReport("dos")
            'ElseIf (Me.pnlAccount.Visible = True) Then
            '    BindReport("account")
            'ElseIf (Me.pnlPatient.Visible = True) Then
            '    BindReport("patient")
            'End If
        Catch ex As Exception

        End Try
    End Sub
    Public Sub BindReport(ByVal pCriteria As String)
        Dim myReportDocument As ReportDocument
        
        Dim lDs As DataSet
        Dim lClinicDS As DataSet
        Dim lUser As User
        Dim lConnection As Connection
        Dim lClinic As Clinic
        Dim lAgingRp As AgingReportMethods
        Dim lDosMainCond As String = ""
        Dim lDosClPyCond As String = ""

        Try
            If Session("ReportDocument") Is Nothing Then
                myReportDocument = New ReportDocument()
            Else
                myReportDocument = CType(Session("ReportDocument"), ReportDocument)
            End If

            lUser = CType(HttpContext.Current.Session("User"), User)
            lConnection = New Connection(lUser.ConnectionString)
            lClinic = New Clinic(lUser.ConnectionString)
            lDs = New DataSet
            lClinicDS = New DataSet
            lClinicDS = lClinic.GetClinicInfoForReports(lUser.ClinicId)
            lAgingRp = New AgingReportMethods(lConnection)
            If (pCriteria = "payer") Then
                If (rdbDatePayer.SelectedValue = "D") Then
                    lDs = lAgingRp.GetReportByPayerDOS(cmbPayer.Text)
                ElseIf (rdbDatePayer.SelectedValue = "F") Then
                    lDs = lAgingRp.GetReportByPayerFillingDate(cmbPayer.Text)
                End If
            ElseIf (pCriteria = "patient") Then
                If (Me.rdbDatePatient.SelectedValue = "D") Then
                    lDs = lAgingRp.GetReportByPatientDOS(cmbPatientName.Text)
                ElseIf (rdbDatePatient.SelectedValue = "S") Then
                    lDs = lAgingRp.GetReportByPatientStatementDate(cmbPatientName.Text)
                End If

            ElseIf (pCriteria = "account") Then
                lDs = lAgingRp.GetReportByAccount(rdbDateAccounts.SelectedValue)
            ElseIf (pCriteria = "dos") Then
                CreateDosCondition(lDosMainCond, lDosClPyCond)
                lDs = lAgingRp.GetReportByDOS(lDosMainCond, lDosClPyCond)
            End If
            If (pCriteria = "payer") Then
                lDs.Tables(0).TableName = "AgingReportByPayer"
                myReportDocument.Load(Server.MapPath("Reports/AgingReportByPayer.rpt"))
            ElseIf (pCriteria = "patient") Then
                lDs.Tables(0).TableName = "AgingReportByPatient"
                myReportDocument.Load(Server.MapPath("Reports/AgingReportByPatient.rpt"))
            ElseIf (pCriteria = "account") Then
                lDs.Tables(0).TableName = "AgingReportByAccount"
                myReportDocument.Load(Server.MapPath("Reports/AgingReportByAccount.rpt"))
            ElseIf (pCriteria = "dos") Then
                lDs.Tables(0).TableName = "AgingReportByDOS"
                myReportDocument.Load(Server.MapPath("Reports/AgingReportByDOS.rpt"))
            End If
            If lDs.Tables(0).Rows.Count > 0 Then
                lblMessage.Style("display") = "none"
                myReportDocument.SetDataSource(lDs)
                myReportDocument.SetParameterValue("PClinicName", lClinicDS.Tables(0).Rows(0)("ClinicName"))

                myReportDocument.SetParameterValue("PClinicAddress", lClinicDS.Tables(0).Rows(0)("ClinicAddressLine1") + " " + lClinicDS.Tables(0).Rows(0)("ClinicCity") + " " + lClinicDS.Tables(0).Rows(0)("ClinicState") + " " + lClinicDS.Tables(0).Rows(0)("ClinicZipCode"))
                'If lClinicDS.Tables(0).Rows(0)("ClinicZipCode").ToString.Length > 5 Then
                '    myReportDocument.SetParameterValue("PClinicAddress", lClinicDS.Tables(0).Rows(0)("ClinicAddressLine1") + " " + lClinicDS.Tables(0).Rows(0)("ClinicCity") + " " + lClinicDS.Tables(0).Rows(0)("ClinicState") + " " + lClinicDS.Tables(0).Rows(0)("ClinicZipCode").ToString.Substring(0, 5) + "-" + lClinicDS.Tables(0).Rows(0)("ClinicZipCode").ToString.Substring(5, 4))
                'End If

                'Me.pnlReportViewer.Visible = True
                Me.pnlReportViewer.Style("display") = "block"
                Me.crvAgingByCriteria.ReportSource = myReportDocument
                Session.Add("ReportDocument", myReportDocument)
                Me.crvAgingByCriteria.Zoom(100)
                Me.crvAgingByCriteria.BestFitPage = False
                Me.crvAgingByCriteria.DisplayGroupTree = False
                Me.crvAgingByCriteria.HasViewList = False
                Me.crvAgingByCriteria.HasDrillUpButton = False
                Me.crvAgingByCriteria.HasZoomFactorList = False
                Me.crvAgingByCriteria.HasExportButton = False
                Me.crvAgingByCriteria.HasSearchButton = False
                Me.crvAgingByCriteria.HasPageNavigationButtons = True
                Me.crvAgingByCriteria.HasToggleGroupTreeButton = False
                Me.crvAgingByCriteria.HasCrystalLogo = False
                Me.crvAgingByCriteria.HasDrillUpButton = False
                Me.crvAgingByCriteria.HasGotoPageButton = False
                Me.crvAgingByCriteria.EnableDrillDown = False
                Me.crvAgingByCriteria.Width = New Unit("100%")
                Me.crvAgingByCriteria.Height = New Unit("100%")
                Me.crvAgingByCriteria.DataBind()
                'Me.crvAgingByCriteria.PrintMode = CrystalDecisions.Web.PrintMode.ActiveX
            Else
                lblMessage.Style("display") = "block"
                lblMessage.Text = "No records found"

            End If
        Catch ex As Exception
            Response.Write("<script>alert('Error Generating Report, Contact your System administrator');</script>")
            Return
        End Try
    End Sub
    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload
        Try
            RemoveReportDoc()
            Me.crvAgingByCriteria.Dispose()
            Me.crvAgingByCriteria = Nothing
        Catch ex As Exception

        End Try

    End Sub
    Public Sub CreateDosCondition(ByRef pMainCond As String, ByRef pClPyCond As String)
        Dim lClaimQuery As String = ""
        Dim lPaymentQuery As String = ""
        Try
            pMainCond = ""
            pClPyCond = ""
            If (Me.txtClaimId.Text.Trim <> "") Then
                lClaimQuery = "VisitID in (select PatientSuperBillID from hcfaUpdated H where ''CL-'' + Cast(Year(H.HCFAPreparedDate) as Varchar) + ''-''+ case Len(Cast(Month(H.HCFAPreparedDate) as Varchar)) when 1 then ''0''+ Cast(Month(H.HCFAPreparedDate) as Varchar) when 2 then Cast(Month(H.HCFAPreparedDate) as Varchar) End + ''-''+ Right(REPLICATE(''0'', 5) + Cast(H.HCFADisplayID As Varchar),5) = ''" & Utility.AdjustApostrophie(Me.txtClaimId.Text.Trim) & "'')"
            Else
                lClaimQuery = ""
            End If

            If (Me.txtPaymentId.Text.Trim <> "") Then
                lPaymentQuery = "VisitID in (select distinct D.VisitID from PaymentHdr H,PaymentDtl D where H.PaymentID=D.PaymentID AND ''PT-'' + Cast(Year(H.EntryDate) as Varchar) + ''-''+ case Len(Cast(Month(H.EntryDate) as Varchar)) when 1 then ''0''+ Cast(Month(H.EntryDate) as Varchar) when 2 then Cast(Month(H.EntryDate) as Varchar) End + ''-''+ Right(REPLICATE(''0'', 5) + Cast(H.DisplayID As Varchar),5)=''" & Utility.AdjustApostrophie(Me.txtPaymentId.Text.Trim) & "'')"
            Else
                lPaymentQuery = ""
            End If

            If (lClaimQuery.Trim <> "" AndAlso lPaymentQuery.Trim <> "") Then
                pClPyCond = " AND (" & lClaimQuery & " OR " & lPaymentQuery & ")"
            ElseIf (lClaimQuery <> "" AndAlso lPaymentQuery.Trim = "") Then
                pClPyCond = " AND " & lClaimQuery
            ElseIf (lPaymentQuery.Trim <> "" AndAlso lClaimQuery = "") Then
                pClPyCond = " AND " & lPaymentQuery
            Else
                pClPyCond = ""
            End If


            If Me.dtDosFrom.DbSelectedDate IsNot Nothing AndAlso Me.dtDOSTo.DbSelectedDate IsNot Nothing AndAlso dtDosFrom.DbSelectedDate.ToString <> "" AndAlso dtDOSTo.DbSelectedDate.ToString <> "" Then
                pMainCond = " AND DateOfService between ''" & dtDosFrom.DbSelectedDate & "'' AND ''" & dtDOSTo.DbSelectedDate & "'' "
            End If



            If (Me.cmbPatientNameDOS.Text.Trim <> "") Then
                If (cmbPatientNameDOS.Text.Contains(",")) Then
                    pMainCond = pMainCond & " AND (PatientName like ''" & Utility.AdjustApostrophie(Me.cmbPatientNameDOS.Text.Trim) & "%'' " & "  OR PatientName like ''" & Utility.AdjustApostrophie(Me.cmbPatientNameDOS.Text.Trim.Replace(" ", "")) & "%'')  "
                Else
                    pMainCond = pMainCond & " AND PatientName like ''" & Utility.AdjustApostrophie(Me.cmbPatientNameDOS.Text.Trim) & "%'' "
                End If
            End If

            If (Me.cmbAgingPeriod.Text.ToUpper <> "ALL") Then
                If (cmbAgingPeriod.Value = "30") Then
                    pMainCond = pMainCond & " AND Thirty <> 0 "
                ElseIf (cmbAgingPeriod.Value = "60") Then
                    pMainCond = pMainCond & " AND Sixty <> 0 "
                ElseIf (cmbAgingPeriod.Value = "90") Then
                    pMainCond = pMainCond & " AND Ninty <> 0 "
                ElseIf (cmbAgingPeriod.Value = "120") Then
                    pMainCond = pMainCond & " AND Above <> 0 "
                End If
            End If
            pMainCond = pMainCond.Trim
            pClPyCond = pClPyCond.Trim

            pMainCond = pMainCond & " " & pClPyCond
            pMainCond = pMainCond.Trim

        Catch ex As Exception

        End Try
    End Sub
    Public Sub RemoveReportDoc()
        Dim myReportDocument As ReportDocument
        Try
            If Session("ReportDocument") IsNot Nothing Then
                myReportDocument = CType(Session("ReportDocument"), ReportDocument)
                myReportDocument.Close()
                myReportDocument.Dispose()
                Session.Remove("ReportDocument")
            End If
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub btnMirror_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnMirror.Click
        Dim newWindow As RadWindow
        Try
            newWindow = New RadWindow()
            If (cmbPatientName.Text.ToString.Split(",").Length = 1) Then
                newWindow.NavigateUrl = "PatientSearch.aspx?srch=" & Utility.AdjustApostrophie(Me.cmbPatientName.Text.ToString.Split(",")(0)) & "|" & "" & ""
            ElseIf (cmbPatientName.Text.ToString.Split(",").Length > 1) Then
                newWindow.NavigateUrl = "PatientSearch.aspx?srch=" & Utility.AdjustApostrophie(Me.cmbPatientName.Text.ToString.Split(",")(0)) & "|" & Me.cmbPatientName.Text.ToString.Split(",")(1) & ""
            Else

            End If
            newWindow.ID = "rwPrimaryInsurer"
            newWindow.VisibleOnPageLoad = True
            newWindow.Top = 220
            newWindow.Left = 280
            newWindow.Width = Unit.Pixel(700)
            newWindow.Height = Unit.Pixel(385)
            newWindow.VisibleTitlebar = False
            newWindow.VisibleStatusbar = False
            newWindow.BorderStyle = BorderStyle.Solid
            newWindow.ReloadOnShow = True
            newWindow.BackColor = Drawing.Color.Transparent
            newWindow.ClientCallBackFunction = "PatientSearchCallBackFunction"
            newWindow.Enabled = True
            newWindow.Visible = True
            rwmSuperBill.Windows.Add(newWindow)
        Catch ex As Exception
            Dim lLogID As String = String.Empty
            lLogID = ErrorLogMethods.LogError(ex, " Billing_PatientLedgerPage.aspx\btnMirror_Click() ")
            Response.Redirect("~/ErrorPage.aspx?LogID=" & lLogID, False)
        End Try
    End Sub

    Protected Sub btnMirror1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnMirror1.Click
        Dim newWindow As RadWindow
        Try
            newWindow = New RadWindow()
            If (cmbPatientNameDOS.Text.ToString.Split(",").Length = 1) Then
                newWindow.NavigateUrl = "PatientSearch.aspx?srch=" & Utility.AdjustApostrophie(Me.cmbPatientNameDOS.Text.ToString.Split(",")(0)) & "|" & "" & ""
            ElseIf (cmbPatientNameDOS.Text.ToString.Split(",").Length > 1) Then
                newWindow.NavigateUrl = "PatientSearch.aspx?srch=" & Utility.AdjustApostrophie(Me.cmbPatientNameDOS.Text.ToString.Split(",")(0)) & "|" & Me.cmbPatientNameDOS.Text.ToString.Split(",")(1) & ""
            Else

            End If
            newWindow.ID = "rwPrimaryInsurer"
            newWindow.VisibleOnPageLoad = True
            newWindow.Top = 220
            newWindow.Left = 280
            newWindow.Width = Unit.Pixel(700)
            newWindow.Height = Unit.Pixel(385)
            newWindow.VisibleTitlebar = False
            newWindow.VisibleStatusbar = False
            newWindow.BorderStyle = BorderStyle.Solid
            newWindow.ReloadOnShow = True
            newWindow.BackColor = Drawing.Color.Transparent
            newWindow.ClientCallBackFunction = "PatientSearchCallBackFunction1"
            newWindow.Enabled = True
            newWindow.Visible = True
            rwmSuperBill.Windows.Add(newWindow)
        Catch ex As Exception
            Dim lLogID As String = String.Empty
            lLogID = ErrorLogMethods.LogError(ex, " Billing_PatientLedgerPage.aspx\btnMirror1_Click() ")
            Response.Redirect("~/ErrorPage.aspx?LogID=" & lLogID, False)
        End Try
    End Sub
End Class
