Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports System.Security.Cryptography
Imports System.Data
Imports ElixirLibrary
Imports System.Data.SqlClient

Partial Class Billing_VisitDetail
    Inherits System.Web.UI.Page
    Protected Sub imgView_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgView.Click
        'Dim lQueryString = "DtTo=" & dtTo.SelectedDate.Date & "&DtFrom=" & dtFrom.SelectedDate.Date & "&PatID=" & txtPatientID.Text
        Dim lQueryString As String = ""
        Dim lParamString = dtTo.SelectedDate.GetValueOrDefault.Date & "|" & dtFrom.SelectedDate.GetValueOrDefault.Date & "|" & txtPatientID.Text & "|" & Utility.AdjustApostrophie(Me.txtPatientName.Text)
        'Dim lParamString = dtTo.SelectedDate.Date & dtFrom.SelectedDate.Date & txtPatientID.Text & Me.txtPatientName.Text

        If ((Not Request.QueryString("ReportParam") Is Nothing) And txtPatientID.Text = "") Then
            If (Request.QueryString("ReportParam") <> "" And txtPatientID.Text = "") Then
                'lReportParam = Decrypt(Request.QueryString("ReportParam"), "!#$a54?3")


                'lQueryString = "VisitDetail.aspx?ReportParam=" & Request.QueryString("ReportParam").Replace(" ", "+")
                lQueryString = "VisitDetail.aspx" + ElixirLibrary.Encryption.EncryptQueryString("ReportParam=")
            Else
                'lQueryString = "VisitDetail.aspx?ReportParam=" & Utility.Encrypt(lParamString, "!#$a54?3")
                lQueryString = "VisitDetail.aspx" + ElixirLibrary.Encryption.EncryptQueryString("ReportParam=" & lParamString)

            End If
        Else
            'lQueryString = "VisitDetail.aspx?ReportParam=" & Utility.Encrypt(lParamString, "!#$a54?3")
            lQueryString = "VisitDetail.aspx" + ElixirLibrary.Encryption.EncryptQueryString("ReportParam=" & lParamString)

        End If

        Response.Redirect(lQueryString)
        
        

    End Sub

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init

        If Page.Request.Form.Get(btnSearch.ClientID.Replace("_", "$") + ".x") Is Nothing And Page.Request.Form.Get(imgView.ClientID.Replace("_", "$") + ".x") Is Nothing Then
            If (Not (Request.QueryString("ReportParam") Is Nothing)) Then
                LoadReport()
            End If
        End If
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

       

        crvVisitDetail.Width = New Unit("100%")



        If (Not Page.IsPostBack) Then
            If dtFrom.SelectedDate.GetValueOrDefault.Year.ToString = "1900" Then
                dtFrom.SelectedDate = Date.Now
            End If
            If dtTo.SelectedDate.GetValueOrDefault.Year.ToString = "1900" Then
                dtTo.SelectedDate = Date.Now
            End If
            If txtPatientID.Text = "" AndAlso (Request.QueryString("ReportParam") IsNot Nothing) Then
                Dim lDecryptedString As String = Encryption.DecryptQueryString(Request.QueryString.ToString)("ReportParam")
                If (lDecryptedString.ToUpper <> "ERROR" And lDecryptedString <> "") Then
                    txtPatientID.Text = lDecryptedString.Split("|")(2)
                    txtPatientName.Text = lDecryptedString.Split("|")(3)
                Else
                    Response.Redirect("VisitDetail.aspx")
                End If

            End If


        End If

    End Sub

    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload
        Dim myReportDocument As ReportDocument

        If Session("ReportDocument") IsNot Nothing Then
            myReportDocument = CType(Session("ReportDocument"), ReportDocument)
            myReportDocument.Close()
            myReportDocument.Dispose()
            Session.Remove("ReportDocument")
        End If

        'If (crvVisitDetail.ViewInfo.IsMainReportView = True) Then
        '    Button1.Visible = False
        'End If

        


    End Sub

    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSearch.Click
       

        Me.AjxMVisitDetail.ResponseScripts.Add("window.radopen('PatientSearch.aspx?srch=" & Me.txtPatientName.Text & "|" & "" & "|" & Me.txtPatientID.Text & "','rwPreviewSearch');")
    End Sub

    Protected Sub Button3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button3.Click
        
    End Sub

    Public Sub LoadReport()

       

        Dim lPatientId As String = ""
        Dim lDtFrom As String = ""
        Dim lDtTo As String = ""

        Dim queryString As NameValueCollection

        queryString = Encryption.DecryptQueryString(Request.QueryString.ToString())


        Dim lDecryptedString As String = queryString("ReportParam")

        If (lDecryptedString.ToUpper <> "ERROR" And lDecryptedString <> "") Then
            lPatientId = lDecryptedString.Split("|")(2)
            lDtFrom = lDecryptedString.Split("|")(1)
            lDtTo = lDecryptedString.Split("|")(0)
        Else
            Response.Redirect("VisitDetail.aspx")
        End If


        dtTo.SelectedDate = lDtTo
        dtFrom.SelectedDate = lDtFrom

        Dim lSuperBill As SuperBill
        Dim lDs As New DataSet
        Dim lUser As User = Session("User")
        Dim lParameterFields As New ParameterFields()
        Dim lParameterField As New ParameterField()
        Dim lParameterValue As New ParameterDiscreteValue()
        Dim lClinic As New Clinic(lUser.ConnectionString)
        Dim clinicTbl As DataTable
        Dim lDs2 As New DataSet()


        Try

            'txtPatientID.Text = "135"
            'If txtPatientID.Text = "" Then
            'Return
            'End If


            lSuperBill = New SuperBill(lUser.ConnectionString)


            'lDs = SuperBillMethods.GetVisitDetail(txtPatientID.Text, "04/09/2008"dtFrom.SelectedDate.Date, dtTo.SelectedDate.Date)
            lDs = SuperBillMethods.GetVisitDetail(lPatientId, lDtFrom, lDtTo)


            lDs2 = lClinic.GetClinicInfoForReports(lUser.ClinicId)
            lDs2.Tables(0).TableName = "ClinicInfo"
            clinicTbl = New DataTable("ClinicInfo")
            clinicTbl = lDs2.Tables(0).Copy()
            lDs.Tables.Add(clinicTbl)

            lDs.Tables(0).TableName = "VisitDetail"
            lDs.Tables(1).TableName = "VisitPaymentDetail"
            lDs.Tables(2).TableName = "ClinicInfo"

        Catch ex As Exception
            Response.Write("<script>alert('Error Generating Report, Contact your System administrator');</script>")
            Return
        End Try

        crvVisitDetail.DisplayGroupTree = False
        crvVisitDetail.HasCrystalLogo = False
        crvVisitDetail.HasToggleGroupTreeButton = False
        crvVisitDetail.HasZoomFactorList = False

        crvVisitDetail.Zoom(100)
        crvVisitDetail.BestFitPage = False
        crvVisitDetail.Width = New Unit("100%")
        crvVisitDetail.Height = New Unit("1500")
        crvVisitDetail.HasSearchButton = False
        crvVisitDetail.HasViewList = False

        '//--Initializing CrystalReport        
        Dim myReportDocument As New ReportDocument()

        myReportDocument.Load(Server.MapPath("Reports\VisitDetail.rpt"))
        myReportDocument.SetDataSource(lDs)

        myReportDocument.Subreports(0).SetDataSource(lDs.Tables(1))
        'If (crvVisitDetail.OnDrillDownSubreport() Is True) Then
        '    Button1.Visible = True
        'End If
        lParameterValue.Value = lDtFrom
        'lParameterValue.Value = CType("04/09/2008", Date)
        lParameterField.Name = "DOSFrom"
        lParameterField.CurrentValues.Add(lParameterValue)
        lParameterFields.Add(lParameterField)

        lParameterField = New ParameterField()
        lParameterValue = New ParameterDiscreteValue()

        lParameterValue.Value = lDtTo
        'lParameterValue.Value = CType("04/09/2008", Date)
        lParameterField.Name = "DOSTo"
        lParameterField.CurrentValues.Add(lParameterValue)
        lParameterFields.Add(lParameterField)

        '---------------
        lParameterField = New ParameterField()
        lParameterValue = New ParameterDiscreteValue()

        lParameterValue.Value = lDs2.Tables(0).Rows(0)("ClinicName")
        'lParameterValue.Value = CType("04/09/2008", Date)
        lParameterField.Name = "PClinicName"
        lParameterField.CurrentValues.Add(lParameterValue)
        lParameterFields.Add(lParameterField)

        lParameterField = New ParameterField()
        lParameterValue = New ParameterDiscreteValue()
        '{ClinicInfo.ClinicAddressLine1}+','+{ClinicInfo.ClinicCity}+','+{ClinicInfo.ClinicState}+','+{ClinicInfo.ClinicZipCode}
        lParameterValue.Value = lDs2.Tables(0).Rows(0)("ClinicAddressLine1") + " " + lDs2.Tables(0).Rows(0)("ClinicCity") + " " + lDs2.Tables(0).Rows(0)("ClinicState")
        If lDs2.Tables(0).Rows(0)("ClinicZipCode").ToString.Length > 5 Then
            lParameterValue.Value = lParameterValue.Value + " " + lDs2.Tables(0).Rows(0)("ClinicZipCode").ToString.Substring(0, 5) + "-" + lDs2.Tables(0).Rows(0)("ClinicZipCode").ToString.Substring(5, 4)

        End If
        'lParameterValue.Value = CType("04/09/2008", Date)
        lParameterField.Name = "PClinicAddress"
        lParameterField.CurrentValues.Add(lParameterValue)
        lParameterFields.Add(lParameterField)

        '-------------
        crvVisitDetail.ParameterFieldInfo = lParameterFields


        Session.Add("ReportDocument", myReportDocument)

        '//--Binding report with CrystalReportViewer        
        crvVisitDetail.ReportSource = myReportDocument
        crvVisitDetail.DataBind()

        crvVisitDetail.PrintMode = CrystalDecisions.Web.PrintMode.ActiveX


    End Sub

    'Protected Sub btnMainRpt_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnMainRpt.Click
    '    If (crvVisitDetail.ViewInfo.IsSubreportView = True) Then
    '        Button1.Visible = True
    '    End If
    'End Sub

    Protected Sub crvVisitDetail_DrillDownSubreport(ByVal source As Object, ByVal e As CrystalDecisions.Web.DrillSubreportEventArgs) Handles crvVisitDetail.DrillDownSubreport
        btnClose.Width = New Unit("50")
    End Sub

End Class
