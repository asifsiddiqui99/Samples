Imports OASystems
Partial Class Billing_AgingRptByInsurance
    Inherits System.Web.UI.UserControl
    Private mRowConnt As Integer
    Public Property RowConnt() As Integer
        Get
            Return mRowConnt
        End Get
        Set(ByVal value As Integer)
            mRowConnt = value
        End Set
    End Property
    Private mButton As ImageButton
    Public WriteOnly Property BtnPrint() As ImageButton

        Set(ByVal value As ImageButton)
            mButton = value
        End Set
    End Property
    Protected Sub btnsearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnsearch.Click

        FillGrid()
      
    End Sub

    Protected Sub grdSearchInsurance_SortCommand(ByVal source As Object, ByVal e As Telerik.WebControls.GridSortCommandEventArgs) Handles grdSearchInsurance.SortCommand
        FillGrid()
    End Sub

    Public Sub FillGrid()
        Dim lQuery As String = String.Empty
        Dim lConnection As New Connection(CType(Session("User"), User).ConnectionString)
        Dim lDataSet As DataSet = Nothing
        Dim lDateCriteria As Date
        Dim lOrderBy As String = String.Empty

        Try

            If ddlRange.SelectedValue.Equals("All") Then
                lDateCriteria = Date.Today
            Else
                lDateCriteria = Date.Today.AddDays(ddlRange.SelectedValue)
            End If


            'lOrderBy &= " Order By Y." & ddlSort.SelectedValue & " " & ddlOrder.SelectedItem.Text


            lQuery = "select InsuranceCompany, Sum(TotalClaims) as TotalClaims, Sum(Balance) as TotalBalance from " _
                    & "(" _
                    & "select " _
                    & "PatientSuperBillID, " _
                    & "DateOfService," _
                    & "PAtientID," _
                    & "InsuranceCompanyID," _
                    & "InsuranceCompany," _
                    & "InsurerInsuranceID," _
                    & "IsNull(dbo.GetTotalVisitLevelPrvPayment(X.PatientSuperBillID) + dbo.GetTotalCPTLevelPrvPayment(X.PAtientSuperBillID),0) as PreviousPayment, " _
                    & "IsNull(dbo.GetTotalCharges(X.PatientSuperBillID),0) as TotalCharges, " _
                    & "Balance = (IsNull(dbo.GetTotalCharges(X.PatientSuperBillID),0) + IsNull(dbo.GetTotalAdjustment(X.PatientSuperBillID),0) -  (IsNull(dbo.GetTotalVisitLevelPrvPayment(X.PatientSuperBillID) + dbo.GetTotalCPTLevelPrvPayment(X.PAtientSuperBillID),0))) , " _
                    & "Count(HCFAID) as TotalClaims " _
                    & "from " _
                    & "( " _
                    & "select PSB.PatientSuperBillID, DateOfService, PSB.PatientID, InsuranceCompanyID, InsuranceCompany, InsurerInsuranceID, HCFAID, MainICFavouriteInsuranceID, A.AdjustmentDescription  " _
                    & "from PatientSuperBill PSB " _
                    & "inner join PatientInsurance [PI] on PSB.PatientID = [PI].PatientID " _
                    & "left outer join HCFAUpdated HU on Case When InsuranceCompanyID = 0 then [PI].InsurerInsuranceID else InsuranceCompanyID END = HU.MainICFavouriteInsuranceID " _
                    & "left outer join Adjustment A on PSB.PAtientSuperBillID = A.VisitID " _
                    & "where Isnull(HCFAID, 0 ) <> 0  and PSB.PrimaryInsuranceCompanyID = InsuranceCompanyID   and (IsNull(A.AdjustmentDescription, '') = '' or A.AdjustmentDescription not like '%PR%') " _
                    & ") as X " _
                    & " where DateOfService <= '" & lDateCriteria.ToString("yyyy-MM-dd") & "'" _
                    & "Group by X.PatientSuperBillID, DateOfSErvice, PatientID, InsuranceCOmpanyID, InsuranceCompany, InsurerInsuranceID " _
                    & ") as Y " _
                    & "Where(Y.Balance <> 0) " _
                    & "Group By Y.InsuranceCompany "




            lDataSet = lConnection.ExecuteQuery(lQuery)

          
          
            grdSearchInsurance.DataSource = lDataSet
            grdSearchInsurance.DataBind()
            If grdSearchInsurance.Items.Count > 0 Then
                mButton.Enabled = True
                Session("InsuranceDS") = lDataSet
            Else
                mButton.Enabled = False
             
            End If
            RowConnt = grdSearchInsurance.Items.Count
           
        Catch ex As Exception

        End Try
    End Sub
    Public Sub GridRetain()
        Dim lDatatable As New DataTable
        Dim lds As New DataSet

        lDatatable.Columns.Add("InsuranceCompany")
        lDatatable.Columns.Add("TotalClaims")
        lDatatable.Columns.Add("TotalBalance")
        For index As Integer = 0 To grdSearchInsurance.Items.Count - 1
            Dim ldr As DataRow
            ldr = lDatatable.NewRow()
            ldr.Item("InsuranceCompany") = grdSearchInsurance.Items(index).Cells(2).Text
            ldr.Item("TotalClaims") = grdSearchInsurance.Items(index).Cells(3).Text
            ldr.Item("TotalBalance") = grdSearchInsurance.Items(index).Cells(4).Text
            lDatatable.Rows.Add(ldr)
        Next
        lds.Tables.Add(lDatatable)
        Session("InsuranceDS") = lds
    End Sub
End Class
