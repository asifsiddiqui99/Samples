Imports OASystems
Partial Class AddPatientAllergy
    Inherits System.Web.UI.UserControl

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim lUser As User

        If (Not Page.IsPostBack) Then

            lUser = CType(Session.Item("User"), User)

            'Me.tsAddAllergy.SelectedIndex = 0
            'Me.tsAddAllergy.SelectedTab.Enabled = True
            'Me.mpAddAllergy.SelectedIndex = 0

            'Session("CurrentXml") = ""
            Session("AllergySearch") = "%"
            Session("DrugSearch") = ""

        End If

    End Sub
    '**************** Medication Search Logic To Add Patient Allergy Drug *****************'
    Protected Sub ibtnSimpleSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ibtnSimpleSearch.Click
        If (Session("DrugSearch") Is Nothing) Then
            Session("DrugSearch") = ""
        End If
        Session("DrugSearch") = Utility.AdjustApostrophie(Me.txtDrugName.Text.Trim)

        Me.grdDrugList.Rebind()
    End Sub
    Protected Sub grdDrugList_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdDrugList.NeedDataSource
        Dim lobjMediSpan As New MSDrugMethods
        Dim lDs As DataSet

        If (Session("DrugSearch") Is Nothing Or Session("DrugSearch").ToString = "") Then
            Exit Sub
        End If

        Try
            Me.lblSelectedDrugId.Text = ""
            Me.lblSelectedDrugName.Text = ""
            lDs = lobjMediSpan.GetDrugNames(Session("DrugSearch").ToString, "Simple")
            Me.grdDrugList.DataSource = lDs
            Me.pnlgridDruglist.Visible = True
        Catch ex As Exception

        End Try

    End Sub
    Protected Sub grdDrugList_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdDrugList.SelectedIndexChanged
        Me.lblSelectedDrugId.Text = Me.grdDrugList.SelectedItems(0).Cells(3).Text
        Me.lblSelectedDrugName.Text = Me.grdDrugList.SelectedItems(0).Cells(4).Text
    End Sub
    '**************** End Medication Search Logic To Add Patient Allergy Drug *****************'


    '**************** Allergy Search Logic To Add Patient Allergy *****************'

    Protected Sub ibtnAllergySearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ibtnAllergySearch.Click
        If (Session("AllergySearch") Is Nothing) Then
            Session("AllergySearch") = ""
        End If

        If (Utility.AdjustApostrophie(Me.txtAllergyName.Text.Trim) = "") Then
            Session("AllergySearch") = "%"
        Else
            Session("AllergySearch") = Utility.AdjustApostrophie(Me.txtAllergyName.Text.Trim)
        End If
        'Session("AllergySearch") = Utility.AdjustApostrophie(Me.txtAllergyName.Text.Trim)
        Me.grdAllergy.Rebind()
    End Sub
    Protected Sub grdAllergy_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdAllergy.NeedDataSource
        Session("AllergySearch") = "%"
        'Dim lobjMediSpan As New MSDrugMethods
        Dim lDs As DataSet
        If (Session("AllergySearch") Is Nothing Or Session("AllergySearch").ToString = "") Then
            Exit Sub
        End If

        Try
            Dim lUser As User
            lUser = CType(Session.Item("User"), User)
            'lDs = lobjMediSpan.AllergySearch(Utility.AdjustApostrophie(Session("AllergySearch").ToString))
            lDs = AllergyMethods.SearchAllergies(lUser, Request.Url.AbsoluteUri, Session("AllergySearch").ToString)
            Me.grdAllergy.DataSource = lDs
            Me.pnlgrdAllergy.Visible = True
        Catch ex As Exception

        End Try
    End Sub
  

    '**************** End Add Allergy Making Xml Logic *****************'


    '**************** Binding Cuurent Allergy Grid Logic Just to Display*****************'
    Protected Sub grdCurrentAllergies_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdCurrentAllergies.NeedDataSource

        Dim rdr As StringReader
        Dim lDs As New DataSet

        If (Session("CurrentXml") Is Nothing) Then
            Exit Sub
        End If

        If (Not Session("CurrentXml") Is Nothing) Then
            If (Session("CurrentXml").ToString = "") Then
                Exit Sub
            End If
        End If

        Dim ltemp As String = Session("CurrentXml")

        If ltemp = "" Then
            Exit Sub
        End If

        If (ltemp <> "<PatientAllergies></PatientAllergies>") Then
            rdr = New StringReader(ltemp)
            lDs.ReadXml(rdr)
            Me.grdCurrentAllergies.DataSource = lDs
        Else
            ''rdr = New StringReader(ltemp)
            ''lDs.ReadXml(rdr)
            Dim tempDs As New DataSet
            Dim DT As New DataTable
            tempDs.Tables.Add(DT)
            Me.grdCurrentAllergies.DataSource = tempDs
            'Me.grdCurrentAllergies.DataSource = lDs
        End If
        'rdr = New StringReader(ltemp)
        'lDs.ReadXml(rdr)
        'Me.grdCurrentAllergies.DataSource = lDs
        
        
    End Sub
    Protected Sub grdCurrentAllergies_DeleteCommand(ByVal source As Object, ByVal e As Telerik.WebControls.GridCommandEventArgs) Handles grdCurrentAllergies.DeleteCommand

        Dim lDrugId As String
        Dim lAllergyId As String


        lDrugId = e.Item.Cells(4).Text
        lAllergyId = e.Item.Cells(5).Text

        Dim doc As XmlDocument = New XmlDocument()
        If (Session("CurrentXml") Is Nothing) Then
            Session("CurrentXml") = ""
        End If
        Dim TempXml As String = Session("CurrentXml").ToString
        If TempXml <> "" Then
            doc.LoadXml(TempXml)
            Dim nodelist As XmlNodeList
            'Dim node As XmlNode
            nodelist = doc.SelectNodes("PatientAllergies/PatientAllergy")
            For Each node As XmlNode In nodelist
                If (node.Attributes.GetNamedItem("DrugId").Value = lDrugId And node.Attributes.GetNamedItem("AllergyID").Value = lAllergyId) Then
                    doc.DocumentElement.RemoveChild(node)
                End If
            Next
            Session("CurrentXml") = doc.InnerXml.ToString
        End If
    End Sub
    Public Function GetXml() As String
        If (Session("CurrentXml") Is Nothing) Then
            Return ""
        Else
            Return Session("CurrentXml").ToString
        End If

    End Function

    Protected Sub btnAddAllergy_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnAddAllergy.Click

        '********************* Validation Code *******************'
        Me.lblDrugSearch.Visible = False
        Me.lblAllergySearch.Visible = False

        Dim lCheckBox As CheckBox
        Dim AllergyFlag As Boolean = True
        Dim DrugFlag As Boolean = True

        If (Me.lblSelectedDrugId.Text <> "") Then
            DrugFlag = False
        End If

        For Each lGridItem As Telerik.WebControls.GridDataItem In grdAllergy.Items
            lCheckBox = CType(lGridItem.Cells(2).FindControl("chkSelectAllergy"), CheckBox)
            If (Not lCheckBox Is Nothing) AndAlso lCheckBox.Checked Then
                AllergyFlag = False
            End If
        Next

        If (DrugFlag And Not AllergyFlag) Then
            Me.lblDrugSearch.Visible = True
            Me.lblDrugSearch.Text = "Must select Drug"
            Exit Sub
        End If


        If (AllergyFlag And Not DrugFlag) Then
            Me.lblAllergySearch.Visible = True
            Me.lblAllergySearch.Text = "Must select atleast one Allergy"
            Exit Sub
        End If

        If (DrugFlag And AllergyFlag) Then
            Me.lblDrugSearch.Visible = True
            Me.lblDrugSearch.Text = "Must select Drug"
            Me.lblAllergySearch.Visible = True
            Me.lblAllergySearch.Text = "Must select atleast one Allergy"
            Exit Sub
        End If

        '********************* Validation Code *******************'

        If (Session("CurrentXml") Is Nothing) Then
            Session("CurrentXml") = ""
        End If



        Dim lXmlDocument As New XmlDocument
        Dim lXmlNode As XmlElement
        Dim CurrentXml As String = Session("CurrentXml").ToString
        If CurrentXml = "" Then
            lXmlDocument.LoadXml("<PatientAllergies></PatientAllergies>")
        Else
            lXmlDocument.LoadXml(CurrentXml)
        End If

        For Each lGridItem As Telerik.WebControls.GridDataItem In grdAllergy.Items
            lCheckBox = CType(lGridItem.Cells(2).FindControl("chkSelectAllergy"), CheckBox)
            If (Not lCheckBox Is Nothing) AndAlso lCheckBox.Checked Then
                lXmlNode = lXmlDocument.CreateElement("PatientAllergy")
                With lXmlNode
                    .SetAttribute("PatientID", "001")
                    .SetAttribute("DrugId", Me.lblSelectedDrugId.Text)
                    .SetAttribute("DrugName", Me.lblSelectedDrugName.Text)
                    .SetAttribute("AllergyID", lGridItem.Cells(3).Text)
                    .SetAttribute("AllergyName", lGridItem.Cells(4).Text)
                End With
                lXmlDocument.DocumentElement.AppendChild(lXmlNode.CloneNode(True))
            End If
        Next

        Session("CurrentXml") = lXmlDocument.InnerXml.ToString()

        grdCurrentAllergies.Rebind()
        grdAllergy.Rebind()
        Me.grdDrugList.Rebind()

        'Me.tsAddAllergy.SelectedIndex = 1
        'Me.tsAddAllergy.SelectedTab.Enabled = True
        'Me.mpAddAllergy.SelectedIndex = 1

    End Sub
End Class
