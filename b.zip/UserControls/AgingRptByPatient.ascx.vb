Imports OASystems
Partial Class Billing_AgingRptByPatient
    Inherits System.Web.UI.UserControl

    Private mRowConnt As Integer
    Public Property RowConnt() As Integer
        Get
            Return mRowConnt
        End Get
        Set(ByVal value As Integer)
            mRowConnt = value
        End Set
    End Property

    Private mButton As ImageButton
    Public WriteOnly Property BtnPrint() As ImageButton

        Set(ByVal value As ImageButton)
            mButton = value
        End Set
    End Property

    Protected Sub btnsearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnsearch.Click

        FillGrid()
     
    End Sub

    Protected Sub grdSearchPatient_SortCommand(ByVal source As Object, ByVal e As Telerik.WebControls.GridSortCommandEventArgs) Handles grdSearchPatient.SortCommand
        FillGrid()
    End Sub

    Public Sub FillGrid()
        Dim lQuery As String = String.Empty
        Dim lConnection As New Connection(CType(Session("User"), User).ConnectionString)
        Dim lDataSet As DataSet = Nothing
        Dim lDateCriteria As Date
        Dim lOrderBy As String = String.Empty

        Try

            If ddlRange.SelectedValue.Equals("All") Then
                lDateCriteria = Date.Today
            Else
                lDateCriteria = Date.Today.AddDays(ddlRange.SelectedValue)
            End If


            'lOrderBy &= " Order By X." & ddlSort.SelectedValue & " " & ddlOrder.SelectedItem.Text


            lQuery = "Select PatientName, " & _
            "Count(VisitID) as TotalVisits," & _
            "SUM(TotalCharges+TotalAdjustment -(PreviousVisitLevelPayment+PreviousCPTLevelPAyment)) as TotalBalance " & _
            "from" & _
            "(" & _
            "	Select " & _
            "	dbo.GetTotalCharges(PSB.PatientSuperBillID) as TotalCharges, " & _
            "	IsNull(dbo.GetTotalAdjustment(PSB.PatientSuperBillID),0) as TotalAdjustment, " & _
            "	dbo.GetTotalVisitLevelPrvPayment(PSB.PatientSuperBillID) as PreviousVisitLevelPayment, " & _
            "	dbo.GetTotalCPTLevelPrvPayment(PSB.PatientSuperBillID) as PreviousCPTLevelPayment, " & _
            "	DateOfService,  " & _
            "	PatientName,  " & _
            "	PatientSuperBillID as VisitID" & _
            "	from PatientSuperBill PSB" & _
            "	where PatientSuperBillID in (select VisitID from Paymentdtl) and DateofService <= ' " & lDateCriteria.ToString("yyyy-MM-dd") & "  ' " & _
            ") as X " & _
            "Group by PatientName " & _
            "Having  SUM(TotalCharges+TotalAdjustment -(PreviousVisitLevelPayment+PreviousCPTLevelPAyment)) <> 0  "


            lDataSet = lConnection.ExecuteQuery(lQuery)


            grdSearchPatient.DataSource = lDataSet
            grdSearchPatient.DataBind()
            RowConnt = grdSearchPatient.Items.Count
            Session("PatientDS") = lDataSet
            If RowConnt > 0 Then
                mButton.Enabled = True
                Session("PatientDS") = lDataSet
            Else
                mButton.Enabled = False
            End If

        Catch ex As Exception

        End Try
    End Sub
    Public Sub GridRetain()
        Dim lDatatable As New DataTable
        Dim lds As New DataSet

        lDatatable.Columns.Add("PatientName")
        lDatatable.Columns.Add("TotalVisits")
        lDatatable.Columns.Add("TotalBalance")
        For index As Integer = 0 To grdSearchPatient.Items.Count - 1
            Dim ldr As DataRow
            ldr = lDatatable.NewRow()
            ldr.Item("PatientName") = grdSearchPatient.Items(index).Cells(2).Text
            ldr.Item("TotalVisits") = grdSearchPatient.Items(index).Cells(3).Text
            ldr.Item("TotalBalance") = grdSearchPatient.Items(index).Cells(4).Text
            lDatatable.Rows.Add(ldr)
        Next
        lds.Tables.Add(lDatatable)
        Session("PatientDS") = lds
    End Sub
End Class
