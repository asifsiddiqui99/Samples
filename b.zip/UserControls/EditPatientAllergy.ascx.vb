Imports OASystems
Partial Class EditPatientAllergy
    Inherits System.Web.UI.UserControl
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If (Not Page.IsPostBack) Then

            'Me.tsAddAllergy.SelectedIndex = 1
            'Me.tsAddAllergy.SelectedTab.Enabled = True
            'Me.mpAddAllergy.SelectedIndex = 1
            If (Session("EditCurrentXml") Is Nothing) Then
                Session("EditCurrentXml") = ""
            End If
            ' Session("EditCurrentXml") = ""
            Session("EditAllergySearch") = "%"
            Session("EditDrugSearch") = ""
        End If
    End Sub
    '**************** Medication Search Logic To Add Patient Allergy Drug *****************'
    Protected Sub ibtnSimpleSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ibtnSimpleSearch.Click
        If (Session("EditDrugSearch") Is Nothing) Then
            Session("EditDrugSearch") = ""
        End If
        Session("EditDrugSearch") = Utility.AdjustApostrophie(Me.txtDrugName.Text.Trim)
        Me.grdDrugList.Rebind()
    End Sub
    Protected Sub grdDrugList_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdDrugList.NeedDataSource
        Dim lobjMediSpan As New MSDrugMethods
        Dim lDs As DataSet

        If (Session("EditDrugSearch") Is Nothing Or Session("EditDrugSearch").ToString = "") Then
            Exit Sub
        End If

        Try
            Me.lblSelectedDrugId.Text = ""
            Me.lblSelectedDrugName.Text = ""
            lDs = lobjMediSpan.GetDrugNames(Session("EditDrugSearch").ToString, "Simple")
            Me.grdDrugList.DataSource = lDs
            Me.pnlGrdDrugList.Visible = True
        Catch ex As Exception

        End Try

    End Sub
    Protected Sub grdDrugList_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdDrugList.SelectedIndexChanged
        Me.lblSelectedDrugId.Text = Me.grdDrugList.SelectedItems(0).Cells(3).Text
        Me.lblSelectedDrugName.Text = Me.grdDrugList.SelectedItems(0).Cells(4).Text
    End Sub
    '**************** End Medication Search Logic To Add Patient Allergy Drug *****************'


    '**************** Allergy Search Logic To Add Patient Allergy *****************'

    Protected Sub ibtnAllergySearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ibtnAllergySearch.Click
        If (Session("EditAllergySearch") Is Nothing) Then
            Session("EditAllergySearch") = ""
        End If
        If (Utility.AdjustApostrophie(Me.txtAllergyName.Text.Trim) = "") Then
            Session("EditAllergySearch") = "%"
        Else
            Session("EditAllergySearch") = Utility.AdjustApostrophie(Me.txtAllergyName.Text.Trim)
        End If
        Me.grdAllergy.Rebind()
    End Sub
    Protected Sub grdAllergy_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdAllergy.NeedDataSource
        Dim lDs As DataSet

        If (Session("EditAllergySearch") Is Nothing Or Session("EditAllergySearch").ToString = "") Then
            Exit Sub
        End If

        Try
            Dim lUser As User
            lUser = CType(Session.Item("User"), User)
            lDs = AllergyMethods.SearchAllergies(lUser, Request.Url.AbsoluteUri, Session("EditAllergySearch").ToString)
            Me.grdAllergy.DataSource = lDs
            Me.pnlGdAllergy.Visible = True
        Catch ex As Exception

        End Try
    End Sub
    '**************** End Allergy Search Logic To Add Patient Allergy *****************'

    '**************** Add Allergy Making Xml Logic *****************'

    'Protected Sub btnAddAllergy_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAddAllergy.Click

    '    vcfs()

    'End Sub

    '**************** Binding Cuurent Allergy Grid Logic Just to Display*****************'
    Protected Sub grdCurrentAllergies_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdCurrentAllergies.NeedDataSource
        Dim lPatientId As String = ""
        Dim rdr As StringReader
        Dim ldoc As XmlDocument = New XmlDocument()
        Dim TempXml As String
        Dim nodelist As XmlNodeList
        Dim lnode As XmlElement
        Dim lDs As DataSet = New DataSet
        Dim lUser As User
        Dim lRow As DataRow

        If (Not Session("EditPatientID") Is Nothing) Then
            lPatientId = Session("EditPatientID").ToString()
        Else
            Exit Sub
        End If

        Dim lQuery As String = "AND PatientID = " & lPatientId
        lUser = CType(Session.Item("User"), User)
        Dim lObjPatientAllergy As New PatientAllergy(lUser.ConnectionString)
        'If (Session("EditCurrentXml") Is Nothing) Then
        If (Session("EditCurrentXml").ToString = "") Then
            lDs = lObjPatientAllergy.GetAllRecords(lQuery)
        End If
        'End If
        ''Test Code''''''''''''''''''
        If (Not Session("EditCurrentXml") Is Nothing) Then
            If (Session("EditCurrentXml").ToString <> "") Then
                ldoc.LoadXml(Session("EditCurrentXml").ToString)
                'If (lDs.Tables(0).Rows.Count > 0) Then
                '    Dim i As Int32
                '    For i = 0 To lDs.Tables(0).Rows.Count - 1
                '        lnode = ldoc.CreateElement("PatientAllergy")
                '        With lnode
                '            .SetAttribute("PatientID", lPatientId)
                '            .SetAttribute("DrugId", lDs.Tables(0).Rows(i).Item(4).ToString)
                '            .SetAttribute("DrugName", lDs.Tables(0).Rows(i).Item(5).ToString)
                '            .SetAttribute("AllergyID", lDs.Tables(0).Rows(i).Item(2).ToString)
                '            .SetAttribute("AllergyName", lDs.Tables(0).Rows(i).Item(3).ToString)
                '        End With
                '        ldoc.DocumentElement.AppendChild(lnode.CloneNode(True))
                '    Next
                'End If
            Else
                ldoc.LoadXml("<PatientAllergies></PatientAllergies>")
                If (lDs.Tables(0).Rows.Count > 0) Then
                    Dim i As Int32
                    For i = 0 To lDs.Tables(0).Rows.Count - 1
                        lnode = ldoc.CreateElement("PatientAllergy")
                        With lnode
                            .SetAttribute("PatientID", lPatientId)
                            .SetAttribute("DrugId", lDs.Tables(0).Rows(i).Item(4).ToString)
                            .SetAttribute("DrugName", lDs.Tables(0).Rows(i).Item(5).ToString)
                            .SetAttribute("AllergyID", lDs.Tables(0).Rows(i).Item(2).ToString)
                            .SetAttribute("AllergyName", lDs.Tables(0).Rows(i).Item(3).ToString)
                        End With
                        ldoc.DocumentElement.AppendChild(lnode.CloneNode(True))
                    Next
                End If
            End If
        End If
        '' End Test Code'''''''''''
        ''''''''' Previous Code''''''''''''''''''''''''
        'If (Not Session("EditCurrentXml") Is Nothing) Then
        '    If (Session("EditCurrentXml").ToString <> "") Then
        '        TempXml = Session("EditCurrentXml").ToString
        '        ldoc.LoadXml(TempXml)
        '        nodelist = ldoc.SelectNodes("PatientAllergies/PatientAllergy")
        '        For Each lnode As XmlNode In nodelist
        '            lRow = lDs.Tables(0).NewRow
        '            lRow(0) = "1"
        '            lRow(1) = lnode.Attributes.GetNamedItem("PatientID").Value
        '            lRow(2) = lnode.Attributes.GetNamedItem("AllergyID").Value
        '            lRow(3) = lnode.Attributes.GetNamedItem("AllergyName").Value
        '            lRow(4) = lnode.Attributes.GetNamedItem("DrugId").Value
        '            lRow(5) = lnode.Attributes.GetNamedItem("DrugName").Value
        '            lDs.Tables(0).Rows.Add(lRow)
        '        Next
        '    End If
        'End If
        ''''''''' Previous Code''''''''''''''''''''''''
        If (ldoc.SelectSingleNode("/PatientAllergies").HasChildNodes) Then
            Session("EditCurrentXml") = ldoc.InnerXml.ToString
            rdr = New StringReader(Session("EditCurrentXml").ToString)
            lDs.ReadXml(rdr)
            Me.grdCurrentAllergies.DataSource = lDs
        Else
            'Session("EditCurrentXml") = ""
            'lDs = lObjPatientAllergy.GetAllRecords(lQuery)
            Dim tempDs As New DataSet
            Dim DT As New DataTable
            tempDs.Tables.Add(DT)
            Me.grdCurrentAllergies.DataSource = tempDs
        End If


        'rdr = New StringReader(Session("EditCurrentXml").ToString)
        'lDs.ReadXml(rdr)
        'Me.grdCurrentAllergies.DataSource = lDs
    End Sub
    Protected Sub grdCurrentAllergies_DeleteCommand(ByVal source As Object, ByVal e As Telerik.WebControls.GridCommandEventArgs) Handles grdCurrentAllergies.DeleteCommand
        Dim lCheck As Boolean = False

        Dim lPatientId As String = ""
        If (Not Session("EditPatientID") Is Nothing) Then
            lPatientId = Session("EditPatientID").ToString()
        Else
            Exit Sub
        End If

        Dim lDrugId As String
        Dim lAllergyId As String
        Dim lUser As User
        lUser = CType(Session.Item("User"), User)

        lDrugId = e.Item.Cells(4).Text
        lAllergyId = e.Item.Cells(5).Text

        Dim lQuery As String = "AND PatientID = " & lPatientId & " AND AllergyID = " & lAllergyId & " And DrugId = " & lDrugId

        Dim doc As XmlDocument = New XmlDocument()
        Dim TempXml As String = Session("EditCurrentXml").ToString
        If TempXml <> "" Then
            doc.LoadXml(TempXml)
            Dim nodelist As XmlNodeList
            'Dim node As XmlNode
            nodelist = doc.SelectNodes("PatientAllergies/PatientAllergy")
            For Each node As XmlNode In nodelist
                If (node.Attributes.GetNamedItem("DrugId").Value = lDrugId And node.Attributes.GetNamedItem("AllergyID").Value = lAllergyId) Then
                    doc.DocumentElement.RemoveChild(node)
                    lCheck = True
                End If
            Next
            Session("EditCurrentXml") = doc.InnerXml.ToString
        End If
        'If (lCheck = False) Then
        '    Dim lObjPatientAllergy As New PatientAllergy(lUser.ConnectionString)
        '    lObjPatientAllergy.DeleteRecord(lQuery)
        'End If
    End Sub
    Public Function GetXml() As String
        Return Session("EditCurrentXml").ToString
    End Function

    Protected Sub btnAddAllergy_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnAddAllergy.Click

        '********************* Validation Code *******************'
        Me.lblDrugSearch.Visible = False
        Me.lblAllergySearch.Visible = False

        Dim lCheckBox As CheckBox
        Dim AllergyFlag As Boolean = True
        Dim DrugFlag As Boolean = True

        If (Me.lblSelectedDrugId.Text <> "") Then
            DrugFlag = False
        End If

        For Each lGridItem As Telerik.WebControls.GridDataItem In grdAllergy.Items
            lCheckBox = CType(lGridItem.Cells(2).FindControl("chkSelectAllergy"), CheckBox)
            If (Not lCheckBox Is Nothing) AndAlso lCheckBox.Checked Then
                AllergyFlag = False
            End If
        Next

        If (DrugFlag And Not AllergyFlag) Then
            Me.lblDrugSearch.Visible = True
            Me.lblDrugSearch.Text = "Must select Drug"
            Exit Sub
        End If


        If (AllergyFlag And Not DrugFlag) Then
            Me.lblAllergySearch.Visible = True
            Me.lblAllergySearch.Text = "Must select atleast one Allergy"
            Exit Sub
        End If

        If (DrugFlag And AllergyFlag) Then
            Me.lblDrugSearch.Visible = True
            Me.lblDrugSearch.Text = "Must select Drug"
            Me.lblAllergySearch.Visible = True
            Me.lblAllergySearch.Text = "Must select atleast one Allergy"
            Exit Sub
        End If

        '********************* Validation Code *******************'

        If (Session("EditCurrentXml") Is Nothing) Then
            Session("EditCurrentXml") = ""
        End If

        'Dim lCheckBox As CheckBox
        Dim lPatientId As String = ""
        If (Not Session("EditPatientID") Is Nothing) Then
            lPatientId = Session("EditPatientID").ToString()
        Else
            Exit Sub
        End If
        ''Dim lPatientId As String = Request.QueryString("EditID").ToString()

        Dim lXmlDocument As New XmlDocument
        Dim lXmlNode As XmlElement
        Dim CurrentXml As String = Session("EditCurrentXml").ToString
        If CurrentXml = "" Then
            lXmlDocument.LoadXml("<PatientAllergies></PatientAllergies>")
        Else
            lXmlDocument.LoadXml(CurrentXml)
        End If

        For Each lGridItem As Telerik.WebControls.GridDataItem In grdAllergy.Items
            lCheckBox = CType(lGridItem.Cells(2).FindControl("chkSelectAllergy"), CheckBox)
            If (Not lCheckBox Is Nothing) AndAlso lCheckBox.Checked Then
                lXmlNode = lXmlDocument.CreateElement("PatientAllergy")
                With lXmlNode
                    .SetAttribute("PatientID", lPatientId)
                    .SetAttribute("DrugId", Me.lblSelectedDrugId.Text)
                    .SetAttribute("DrugName", Me.lblSelectedDrugName.Text)
                    .SetAttribute("AllergyID", lGridItem.Cells(3).Text)
                    .SetAttribute("AllergyName", lGridItem.Cells(4).Text)
                End With
                lXmlDocument.DocumentElement.AppendChild(lXmlNode.CloneNode(True))
            End If
        Next

        Session("EditCurrentXml") = lXmlDocument.InnerXml.ToString()

        grdCurrentAllergies.Rebind()
        grdAllergy.Rebind()
        Me.grdDrugList.Rebind()

        'Me.tsAddAllergy.SelectedIndex = 1
        'Me.tsAddAllergy.SelectedTab.Enabled = True
        'Me.mpAddAllergy.SelectedIndex = 1


    End Sub
End Class
