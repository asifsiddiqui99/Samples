
Partial Class Billing_ViewPatientStatementArchiveDtl
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If (Page.IsPostBack = False) Then
            Dim lPdfPath As String = ""
            Dim lUser As User
            Dim lPdfTemplatePath As String


            Dim queryString As NameValueCollection
            queryString = Encryption.DecryptQueryString(Request.QueryString.ToString())

            lUser = CType(HttpContext.Current.Session.Item("User"), User)
            lPdfTemplatePath = ConfigurationManager.AppSettings("ClaimRquestPath") & lUser.ClinicId & "\Statements"

            If (queryString IsNot Nothing AndAlso queryString("ID") IsNot Nothing) Then
                'lPdfPath = lPdfTemplatePath & "\" & queryString("ID").ToString() & ".pdf" 'To be uncomment lateron
                lPdfPath = lPdfTemplatePath & "\Sample.pdf"
                ViewPdf(lPdfPath)
            End If
        End If
    End Sub
    Public Sub ViewPdf(ByVal pPdfPath As String)
        Dim lClient As System.Net.WebClient = New System.Net.WebClient()
        Dim lBuffer As Byte() = lClient.DownloadData(pPdfPath)


        If (lBuffer IsNot Nothing) Then
            Response.ContentType = "application/pdf"
            Response.AddHeader("content-length", lBuffer.Length.ToString())
            Response.BinaryWrite(lBuffer)
        End If
    End Sub
End Class
