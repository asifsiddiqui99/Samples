Imports Telerik.WebControls
Partial Class Billing_EditReferringProvider
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


        Dim queryString As NameValueCollection
        Try
            If (Request.QueryString Is Nothing) Then
                Exit Sub
            Else
                queryString = Encryption.DecryptQueryString(Request.QueryString.ToString())
                ViewState("lProviderID") = queryString("eid")

                FacilityMethods.LoadFacilityNameCombo(cmbFacility, "")
                cmbFacility.Items.Insert(0, New RadComboBoxItem(""))
            End If


        Catch ex As Exception
            ErrorLogMethods.LogError(ex, "EditFacility.aspx\Encryption.DecryptQueryString(Request.QueryString.ToString())")
            Return
        End Try







        Try
            If (Not Page.IsPostBack) Then


                Dim lIsAuthorize As Boolean
                Dim lUser As User
                Dim lUserRoles As UserRoles
                Dim lState, lfacility As String
                Dim lSpecialityDs As DataSet

                lSpecialityDs = ReferringMethods.GetSpeciality(ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString)
                Me.txtSpeciality.DataSource = lSpecialityDs
                Me.txtSpeciality.DataTextField = "SpecializationId"
                Me.txtSpeciality.DataValueField = "Code"
                Me.txtSpeciality.DataBind()

                lUser = CType(Session.Item("User"), User)
                lUserRoles = New UserRoles(lUser.ConnectionString)

                '********* Check User Validity ************
                lIsAuthorize = lUserRoles.CheckPageAuthorization(lUser.UserId, "EmployeeSetup.aspx")
                If Not lIsAuthorize Then
                    Response.Redirect("unauthorization.aspx")
                End If

                '********* Load Authorized Tabs Only ***********


                'lUserRoles.LoadUserRights(tsRxEntry, lUser.UserId, "RxEntry.aspx")
                tsEmployee.SelectedIndex = 0
                mpEmployee.SelectedIndex = 0
                '*********************

                Dim lds As New DataSet
            
                lds = ReferringMethods.GetAllRecords(" And ProviderID=" & ViewState("lProviderID"))

                With lds.Tables(0).Rows(0)
                    txtLastName.Text = .Item("LastName")
                    txtFirstName.Text = .Item("FirstName")
                    txtMiddleName.Text = .Item("MiddleName")
                    cmbState.SelectedIndex = cmbState.FindItemIndexByText(.Item("State"))
                    txtAddressLine1.Text = .Item("AddressLine1")
                    txtAddressLine2.Text = .Item("AddressLine2")
                    txtCity.Text = .Item("City")
                    lState = .Item("State")

                    If (lState <> "") Then
                        StateMethods.Load_States(cmbState, lUser)
                        cmbState.SelectedIndex = cmbState.FindItemIndexByText(.Item("State"))
                    End If

                    mtbZipCode.Text = .Item("ZipCode")
                    mtbWorkPhone.Text = .Item("WorkPhone")
                    mtbFax.Text = .Item("Fax")
                    txtEmail.Text = .Item("Email")
                    txtNPI.Text = .Item("NPI")
                    mtbWorkPhoneExtension.Text = .Item("Ext")
                    lfacility = .Item("FacilityID")

                    If (lfacility <> 0) Then                        
                        cmbFacility.SelectedIndex = cmbFacility.FindItemIndexByValue(.Item("FacilityID"))
                    End If

                    txtSpeciality.Text = .Item("Speciality")
                    txtDegree.Text = .Item("Degree")

                End With
            End If
        Catch ex As Exception

        End Try

        Me.btnCancel.OnClientClick = "javascript:window.history.go(-1);return false;"
    End Sub

    Protected Sub cmbState_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbState.ItemsRequested
        Dim lUser As User

        lUser = CType(Session.Item("User"), User)

        Dim lCond As String
        lCond = "And Abbr Like '" & Utility.AdjustApostrophie(e.Text) & "%' "

        If (e.Text = "") Then
            Exit Sub
        End If


        StateMethods.Load_States(cmbState, lUser, lCond)

    End Sub

    'Protected Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnCancel.Click
    '    Response.Redirect("ReferringProviderSetup.aspx")
    'End Sub

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSave.Click
        If (ReferringMethods.CheckExistEdit(txtNPI.Text, ViewState("lProviderID"))) Then
            Me.RadAjaxManager1.Alert("Different Referring Provider With Same NPI Already Exists")
        Else
            Dim lUser As User
            lUser = CType(Session.Item("User"), User)

            Dim lReferringProvider As New ReferringProviderDB
            Dim lResult As Boolean

            With lReferringProvider

                .LastName = Utility.AdjustApostrophie(txtLastName.Text)
                .FirstName = Utility.AdjustApostrophie(txtFirstName.Text)
                .MiddleName = Utility.AdjustApostrophie(txtMiddleName.Text)
                .State = cmbState.Text
                .AddressLine1 = Utility.AdjustApostrophie(txtAddressLine1.Text)
                .AddressLine2 = Utility.AdjustApostrophie(txtAddressLine2.Text)
                .City = Utility.AdjustApostrophie(txtCity.Text)
                .ZipCode = mtbZipCode.Text
                .WorkPhone = mtbWorkPhone.Text
                .Ext = mtbWorkPhoneExtension.Text
                .Fax = mtbFax.Text
                .Email = txtEmail.Text
                .NPI = Utility.AdjustApostrophie(txtNPI.Text)
                .Speciality = Utility.AdjustApostrophie(txtSpeciality.Text)
                .Degree = Utility.AdjustApostrophie(txtDegree.Text)

                If (cmbFacility.Text <> "") Then
                    .Facility = cmbFacility.Value
                Else
                    .Facility = 0
                End If

                .ProviderID = ViewState("lProviderID")

            End With

            lResult = ReferringMethods.EditReferringProvider(lReferringProvider)

            If (lResult = True) Then
                'Me.RadAjaxManager1.Alert("Referring Provider Updated Successfully")
                'Me.RadAjaxManager1.Redirect("ReferringProviderSetup.aspx")


                ''lblMessage.Text = "Referring Provider Updated Successfully"

                Response.Write("<script>alert('Referring Provider Updated Successfully');</script>")
                PageExpire()

                Response.Write("<script>location.href = 'ReferringProviderSetup.aspx';</script>")



            End If

            ''if user hasnt selected a state.......
            If (cmbState.Text = "") Then
                cmbState.Items.Clear()
            End If

            If (cmbFacility.Text = "") Then
                cmbFacility.Items.Clear()
            End If
        End If

    End Sub

    'Protected Sub cmbFacility_ItemsRequested(ByVal o As Object, ByVal e As Telerik.WebControls.RadComboBoxItemsRequestedEventArgs) Handles cmbFacility.ItemsRequested
    '    Dim lCond As String
    '    lCond = "And FacilityName Like '" & Utility.AdjustApostrophie(e.Text) & "%' "

    '    If (e.Text = "") Then
    '        Exit Sub
    '    End If

    '    FacilityMethods.LoadFacilityNameCombo(cmbFacility, lCond)
    'End Sub

    Public Sub PageExpire()
        Response.Buffer = True
        Response.ExpiresAbsolute = Now.Subtract(New TimeSpan(1, 0, 0, 0))
        Response.Expires = 0
        Response.CacheControl = "no-cache"
    End Sub
End Class
