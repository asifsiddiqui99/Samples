
Partial Class Billing_EditBillingProviderDialog
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim lUser As User

        lUser = CType(Session.Item("User"), User)

        Dim lHCFADBUpdated As HCFADBUpdated



        If IsPostBack = False Then
            Try
                If (Session("HCFADBUpdated") Is Nothing) Then
                    Exit Sub
                Else

                    lHCFADBUpdated = CType(Session("HCFADBUpdated"), HCFADBUpdated)

                    With lHCFADBUpdated.BillingPvd

                        txtBProviderId.Text = .BillingProviderId
                        txtFirstName.Text = .FirstName
                        txtMiddleName.Text = .MiddleName
                        txtLastName.Text = .LastName
                        txtAddressOne.Text = .AddressLine1
                        txtAddressTwo.Text = .AddressLine2
                        txtCity.Text = .City
                        Utility.SelectComboItem(cbState, .State, False)
                        txtZipCode.Text = .ZipCode
                        txtPhoneOne.Text = .Phone1
                        txtPhoneTwo.Text = .Phone2
                        txtFax.Text = .Fax
                        txtEmail.Text = .Email
                        txtNPI.Text = .NPI
                        txtTaxID.Text = .TaxID
                        mtbSSN.Text = .SSN
                    End With
                End If


            Catch ex As Exception

                Return
            End Try

            '********* Load Authorized Tabs Only ***********
            StateMethods.Load_States(cbState, lUser)


        End If
    End Sub




 
    Protected Sub btnUpdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnUpdate.Click

        Dim lHCFADBUpdated As HCFADBUpdated
        lHCFADBUpdated = CType(Session("HCFADBUpdated"), HCFADBUpdated)
      

        Try



            With lHCFADBUpdated.BillingPvd
                .AddressLine1 = Me.txtAddressOne.Text
                .AddressLine2 = Me.txtAddressTwo.Text
                .City = Me.txtCity.Text
                .Email = Me.txtEmail.Text
                .Fax = Me.txtFax.Text
                .FirstName = Me.txtFirstName.Text
                .LastName = Me.txtLastName.Text
                .MiddleName = Me.txtMiddleName.Text
                .NPI = Me.txtNPI.Text
                .Phone1 = Me.txtPhoneOne.Text
                .Phone2 = Me.txtPhoneTwo.Text
                .SSN = Me.mtbSSN.Text
                .State = Me.cbState.SelectedItem.Text
                .TaxID = Me.txtTaxID.Text
                .ZipCode = Me.txtZipCode.Text

            End With

            'lHCFADBUpdated.BillingPvd = lBProvider
            'lHCFADBUpdated.BillingPvd.BillingProviderId = txtBProviderId.Text.ToString
            Session("HCFADBUpdated") = lHCFADBUpdated
            Response.Write("<script language=javascript>parent.questionwindow2.hide();</script>")

        Catch ex As Exception

        End Try
    End Sub

   
End Class
