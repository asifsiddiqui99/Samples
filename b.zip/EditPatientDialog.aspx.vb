Imports Telerik.WebControls
Partial Class Billing_EditPatientDialog
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim lHCFADBUpdated As HCFADBUpdated

        Dim mPatientType As String = ""





        If Page.IsPostBack = False Then
            If (Not Request.QueryString("Ptype").ToString() Is Nothing AndAlso Request.QueryString("Ptype").ToString() <> "") Then
                mPatientType = Request.QueryString("Ptype").ToString().Split("_")(2)
                Me.txtPatType.Text = mPatientType
            End If

            Try
                If (Session("HCFADBUpdated") Is Nothing) Then
                    Exit Sub
                Else

                    lHCFADBUpdated = CType(Session("HCFADBUpdated"), HCFADBUpdated)
                    If Me.txtPatType.Text = "btnEditPat" Then
                        Me.txtPatientId.Text = lHCFADBUpdated.Patient.PatientID
                    ElseIf Me.txtPatType.Text = "btnEditiPat" Then
                        Me.txtiPatientId.Text = lHCFADBUpdated.InsurerPatient.PatientID
                    ElseIf Me.txtPatType.Text = "btnEditOtheriPat" Then
                        Me.txtOtheriPatientId.Text = lHCFADBUpdated.OtherInsurerPatient.PatientID
                    End If

                End If

                LoadPatient()
            Catch ex As Exception
            End Try
        End If





    End Sub



    ' ************************* End Update Patient Related Code ********'
    Private Sub LoadPatient()
        Dim lHCFADBUpdated As HCFADBUpdated
        lHCFADBUpdated = CType(Session("HCFADBUpdated"), HCFADBUpdated)
        Dim lUser As User
        lUser = CType(Session.Item("User"), User)
        Try

            If Me.txtPatientId.Text <> "0" AndAlso Me.txtPatientId.Text <> "" Then
                With lHCFADBUpdated.Patient
                    Me.txtPatientId.Text = .PatientID
                    Me.txtLastName.Text = .LastName
                    Me.txtFirstName.Text = .FirstName
                    Me.txtMiddleName.Text = .MiddleName
                    Me.txtAddressLine1.Text = .AddressLine1
                    Me.txtAddressLine2.Text = .AddressLine2
                End With
            End If

            If Me.txtiPatientId.Text <> "0" AndAlso Me.txtiPatientId.Text <> "" Then
                With lHCFADBUpdated.InsurerPatient
                    Me.txtPatientId.Text = .PatientID
                    Me.txtLastName.Text = .LastName
                    Me.txtFirstName.Text = .FirstName
                    Me.txtMiddleName.Text = .MiddleName
                    Me.txtAddressLine1.Text = .AddressLine1
                    Me.txtAddressLine2.Text = .AddressLine2
                End With
            End If
            If Me.txtOtheriPatientId.Text <> "0" AndAlso Me.txtOtheriPatientId.Text <> "" Then
                With lHCFADBUpdated.OtherInsurerPatient
                    Me.txtPatientId.Text = .PatientID
                    Me.txtLastName.Text = .LastName
                    Me.txtFirstName.Text = .FirstName
                    Me.txtMiddleName.Text = .MiddleName
                    Me.txtAddressLine1.Text = .AddressLine1
                    Me.txtAddressLine2.Text = .AddressLine2
                End With
            End If




        Catch ex As Exception

            Return
        End Try




    End Sub



    Protected Sub btnPersonalSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnPersonalSave.Click
        Dim lUser As User
        Dim lHCFADBUpdated As HCFADBUpdated
        lHCFADBUpdated = CType(Session("HCFADBUpdated"), HCFADBUpdated)
        '  Dim lPatient = New PatientDBExtended


        lUser = CType(Session.Item("User"), User)

        Try




            If Me.txtPatType.Text = "btnEditPat" Then

                With lHCFADBUpdated.Patient
                    .AddressLine1 = Me.txtAddressLine1.Text
                    .AddressLine2 = Me.txtAddressLine2.Text
                    .FirstName = Me.txtFirstName.Text
                    .LastName = Me.txtLastName.Text
                    .MiddleName = Me.txtMiddleName.Text
                End With
                'lHCFADBUpdated.Patient = lPatient
                'lHCFADBUpdated.Patient.PatientID = txtPatientId.Text.ToString

            ElseIf Me.txtPatType.Text = "btnEditiPat" Then

                With lHCFADBUpdated.InsurerPatient
                    .AddressLine1 = Me.txtAddressLine1.Text
                    .AddressLine2 = Me.txtAddressLine2.Text
                    .FirstName = Me.txtFirstName.Text
                    .LastName = Me.txtLastName.Text
                    .MiddleName = Me.txtMiddleName.Text
                End With

                'lHCFADBUpdated.InsurerPatient = lPatient
                'lHCFADBUpdated.InsurerPatient.PatientID = txtiPatientId.Text.ToString
            ElseIf Me.txtPatType.Text = "btnEditOtheriPat" Then

                With lHCFADBUpdated.OtherInsurerPatient
                    .AddressLine1 = Me.txtAddressLine1.Text
                    .AddressLine2 = Me.txtAddressLine2.Text
                    .FirstName = Me.txtFirstName.Text
                    .LastName = Me.txtLastName.Text
                    .MiddleName = Me.txtMiddleName.Text
                End With

                'lHCFADBUpdated.OtherInsurerPatient = lPatient
                'lHCFADBUpdated.OtherInsurerPatient.PatientID = txtOtheriPatientId.Text.ToString
            End If


            Session("HCFADBUpdated") = lHCFADBUpdated
            Response.Write("<script language=javascript>parent.questionwindow3.hide();</script>")




        Catch ex As Exception

        End Try

    End Sub
End Class