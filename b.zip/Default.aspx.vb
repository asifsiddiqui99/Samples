
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports System.Data
Imports ElixirLibrary
Imports System.Data.SqlClient

Partial Class Billing_Default
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'CrystalReportViewer1.ReportSource = Server.MapPath("HCFA.rpt")


        Dim lDs As New DataSet
        Dim lConnection As New Connection()
        Dim lQuery As String = ""
        lQuery = "Select EmployeeID, ClinicId, SPI, DEA "
        lQuery += "From UserMaster "


        '--Opening Sql Connection        

        lDs = lConnection.ExecuteReportQuery(lQuery, "UserMaster")

        '//--(Optional) I have used it to disable the properties        
        CrystalReportViewer1.DisplayGroupTree = False
        CrystalReportViewer1.HasCrystalLogo = False
        '//--Initializing CrystalReport        
        Dim myReportDocument As New ReportDocument()

        myReportDocument.Load(Server.MapPath("HCFA.rpt"))
        myReportDocument.SetDataSource(lDs)
        '//--Binding report with CrystalReportViewer        
        CrystalReportViewer1.ReportSource = myReportDocument
        CrystalReportViewer1.DataBind()



    End Sub
End Class
