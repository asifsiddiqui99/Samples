Imports Microsoft.VisualBasic
Imports System.xml
Imports System.IO
Imports Rebex.Net
Partial Class Billing_PostRemittance
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Page.IsPostBack = False Then
            grdSearch.DataSource = Nothing
        End If
    End Sub

    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSearch.Click
        Try

            grdSearch.Rebind()


        Catch ex As Exception
            lblErrorMsg.Text = ex.Message
            lblErrorMsg.Visible = True
        End Try
    End Sub

    Protected Sub grdSearch_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdSearch.NeedDataSource
        Dim lTbl = New DataTable
        Try
            If Page.IsPostBack = True Then
                GetPostRemittance()
            Else
                grdSearch.DataSource = lTbl
            End If

        Catch ex As Exception
            lblErrorMsg.Text = ex.Message
            lblErrorMsg.Visible = True
        End Try

    End Sub

    Protected Sub grdSearch_ItemCommand(ByVal source As Object, ByVal e As Telerik.WebControls.GridCommandEventArgs) Handles grdSearch.ItemCommand
        Dim lStrPath As String
        Dim lStrReader As StreamReader
        Dim lStrEdi835 As String
        Try
            If (e.CommandName = "Send") Then
                lStrPath = e.Item.Cells(2).Text
                lStrReader = New StreamReader(lStrPath)
                lStrEdi835 = lStrReader.ReadToEnd
                lStrReader.Close()
                If (lStrEdi835 <> "") Then
                    PostPayment(lStrPath, lStrEdi835)
                End If
            End If
        Catch ex As Exception

        End Try

    End Sub

    Protected Sub PostPayment(ByVal pStrFileNameAndPath As String, ByVal pEdi835 As String)
        Dim lBoolResult As Boolean
        Dim lRemitanceMethods As RemittanceMethods
        Dim lStrRTN As String = ""
        Try

            lRemitanceMethods = New RemittanceMethods()
            lStrRTN = lRemitanceMethods.GetRTN(pEdi835)
            If (lStrRTN <> "") Then

                If (lRemitanceMethods.CheckIfExist(lStrRTN)) Then
                    Response.Write("<script>alert('Payement already posted.');</script>")
                    lRemitanceMethods.MoveFiles(pStrFileNameAndPath, pStrFileNameAndPath.Replace("ClaimResponse835", "ClaimResponse835Archive"))
                Else
                    lBoolResult = lRemitanceMethods.PostRemittance(pStrFileNameAndPath, pEdi835)
                    If lBoolResult = True Then
                        Response.Write("<script>alert('Payement posted successfully.');</script>")
                    Else
                        Response.Write("<script>alert('An error has occured while processing the request.');</script>")
                    End If
                End If
            End If
            grdSearch.Rebind()

        Catch ex As Exception
            Response.Write("<script>alert('An error has occured while processing the request.');</script>")
        End Try

    End Sub


    Private Sub GetPostRemittance()
        Dim lPath As String = ""

        Dim lUser As User
        lUser = CType(Session.Item("User"), User)



        If (lPath = "") Then
            lPath = System.Configuration.ConfigurationManager.AppSettings("ClaimRquestPath").ToString() & lUser.ClinicId.ToString & "\" & "ClaimResponse835\"

        End If


        Dim dtbl As DataTable
        Dim dcol As DataColumn
        Dim drow As DataRow
        Dim dset As New DataSet

        'create the datatable... 
        dtbl = New DataTable("Files")

        'create the columns in the datatable... 
        dcol = New DataColumn("FilePath", GetType(String))
        dtbl.Columns.Add(dcol)
        dcol = New DataColumn("FileName", GetType(String))
        dtbl.Columns.Add(dcol)
        dcol = New DataColumn("CreationDate", GetType(String))
        dtbl.Columns.Add(dcol)


        Dim dir_info As New DirectoryInfo(lPath)
        Try


            If dir_info.Exists Then
                Dim fs_infos() As FileInfo = dir_info.GetFiles()

                If dpCreationDate.DbSelectedDate IsNot Nothing AndAlso dpCreationDate.DbSelectedDate.ToString <> "" AndAlso txtFileName.Text <> "" Then
                    For Each fs_info As FileInfo In fs_infos
                        If fs_info.CreationTime.Date = dpCreationDate.DbSelectedDate AndAlso fs_info.Name.ToUpper Like txtFileName.Text.ToUpper & "*" Then
                            drow = dtbl.NewRow
                            drow.Item("FilePath") = fs_info.FullName
                            drow.Item("FileName") = fs_info.Name
                            drow.Item("CreationDate") = fs_info.CreationTime.Date.ToString("MM/dd/yyyy")
                            dtbl.Rows.Add(drow)
                        End If

                    Next fs_info

                    fs_infos = Nothing


                ElseIf dpCreationDate.DbSelectedDate IsNot Nothing AndAlso dpCreationDate.DbSelectedDate.ToString <> "" AndAlso txtFileName.Text = "" Then
                    For Each fs_info As FileInfo In fs_infos
                        If fs_info.CreationTime.Date = dpCreationDate.DbSelectedDate Then
                            drow = dtbl.NewRow
                            drow.Item("FilePath") = fs_info.FullName
                            drow.Item("FileName") = fs_info.Name
                            drow.Item("CreationDate") = fs_info.CreationTime.Date.ToString("MM/dd/yyyy")
                            dtbl.Rows.Add(drow)
                        End If

                    Next fs_info

                    fs_infos = Nothing

                ElseIf txtFileName.Text <> "" AndAlso dpCreationDate.DbSelectedDate Is Nothing Then
                    For Each fs_info As FileInfo In fs_infos
                        If fs_info.Name.ToUpper Like txtFileName.Text.ToUpper & "*" Then
                            drow = dtbl.NewRow
                            drow.Item("FilePath") = fs_info.FullName
                            drow.Item("FileName") = fs_info.Name
                            drow.Item("CreationDate") = fs_info.CreationTime.Date.ToString("MM/dd/yyyy")
                            dtbl.Rows.Add(drow)
                        End If

                    Next fs_info

                    fs_infos = Nothing
                Else


                    For Each fs_info As FileInfo In fs_infos
                        drow = dtbl.NewRow
                        drow.Item("FilePath") = fs_info.FullName
                        drow.Item("FileName") = fs_info.Name
                        drow.Item("CreationDate") = fs_info.CreationTime.Date.ToString("MM/dd/yyyy")
                        dtbl.Rows.Add(drow)
                    Next fs_info

                    fs_infos = Nothing
                End If


            End If




        Catch ex As Exception

        End Try







        dset.Tables.Add(dtbl)
        grdSearch.DataSource = dset

    End Sub


#Region "Get New Remittance Files From Gateway Work"

    Protected Sub ibtnGetRemittanceFiles_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ibtnGetRemittanceFiles.Click
        Dim lFtpClaimResponseGetResult As Boolean = False

        lFtpClaimResponseGetResult = GetFilesFromGatewayFtp()

        If (lFtpClaimResponseGetResult) Then
            Response.Write("<script>alert('New claim response files saved sucessfully.')</script>")
        Else
            Response.Write("<script>alert('Error saving new claim response files.')</script>")
        End If
    End Sub

    Public Function GetFilesFromGatewayFtp() As Boolean
        Dim lGatewayFtpLink As String = ""
        Dim lGatewayFtpUserID As String = ""
        Dim lGatewayFtpPassword As String = ""
        Dim lGatewayFtpClaimResponsePath As String = ""
        Dim lClient As Rebex.Net.Sftp
        Dim lFileDownloadPath As String = ""
        Dim lClinic As Clinic
        Dim lUser As User
        Dim lFtpFileList As SftpItemCollection
        Dim lFtpFileDeletePath As String = ""
        Dim lRemittanceHdrEntryResult As Boolean = False

        Try

            lUser = CType(HttpContext.Current.Session("User"), User)
            lFileDownloadPath = GetLocalClaimResponseSavePath()

            lClinic = New Clinic(lUser.ConnectionString)
            lClinic.Clinic.ClinicId = lUser.ClinicId
            lClinic.GetRecordByID()

            lGatewayFtpUserID = lClinic.Clinic.GatewayFtpUserID
            lGatewayFtpPassword = lClinic.Clinic.GatewayFtpPassword


            lGatewayFtpClaimResponsePath = CType(ConfigurationManager.AppSettings("GatewayFtpClaimResponsePath"), String)
            lGatewayFtpLink = CType(ConfigurationManager.AppSettings("GatewayFtpLink"), String)


            lClient = New Rebex.Net.Sftp
            lClient.Connect(lGatewayFtpLink)
            lClient.Login(lGatewayFtpUserID, lGatewayFtpPassword)
            lClient.GetFiles(lGatewayFtpClaimResponsePath & "*", lFileDownloadPath, SftpBatchTransferOptions.Recursive, SftpActionOnExistingFiles.OverwriteAll)

            lClient.ChangeDirectory(lGatewayFtpClaimResponsePath)


            lFtpFileList = lClient.GetList()


            For Each lListItem As SftpItem In lFtpFileList
                lFtpFileDeletePath = lGatewayFtpClaimResponsePath & lListItem.Name '"/remits/" & lTest
                lRemittanceHdrEntryResult = RemittanceHdrDtlEntry(lFileDownloadPath & "\" & lListItem.Name)
                If (lRemittanceHdrEntryResult) Then
                    lClient.DeleteFile(lFtpFileDeletePath)
                    lRemittanceHdrEntryResult = False
                End If

            Next

            Return True
        Catch ex As Exception
            Return False
        Finally
            If (lClient.State = SftpState.Connected) Then
                lClient.Disconnect()
                lClient.Dispose()
            End If
        End Try
    End Function

    Public Function GetLocalClaimResponseSavePath() As String
        Dim lPath As String = ""
        Dim lUser As User
        Dim lDirectoryInfo As DirectoryInfo


        Try
            lUser = CType(HttpContext.Current.Session.Item("User"), User)

            lPath = CType(ConfigurationManager.AppSettings("ClaimResponsePath"), String)
            lDirectoryInfo = New DirectoryInfo(lPath)
            If Not lDirectoryInfo.Exists Then
                lDirectoryInfo.Create()
            End If
            lPath = CType(ConfigurationManager.AppSettings("ClaimResponsePath"), String) + lUser.ClinicId
            lDirectoryInfo = New DirectoryInfo(lPath)
            If Not lDirectoryInfo.Exists Then
                lDirectoryInfo.Create()
            End If
            lPath = CType(ConfigurationManager.AppSettings("ClaimResponsePath"), String) + lUser.ClinicId + "\ClaimResponse835"
            lDirectoryInfo = New DirectoryInfo(lPath)
            If Not lDirectoryInfo.Exists Then
                lDirectoryInfo.Create()
            End If

            Return lPath
        Catch ex As Exception
            Return ""
        End Try

    End Function

#End Region

#Region "Remittance Header Detail Entry code"
    Public Function RemittanceHdrDtlEntry(ByVal pFilePath As String) As Boolean
        Dim lStrPath As String
        Dim lStrReader As StreamReader
        Dim lStrEdi835 As String
        Dim lRemittanceHdrPostingResult As Boolean = False
        Try

            lStrPath = pFilePath
            lStrReader = New StreamReader(lStrPath)
            lStrEdi835 = lStrReader.ReadToEnd
            lStrReader.Close()
            If (lStrEdi835 <> "") Then
                PostRemittanceHdr(lStrPath, lStrEdi835)
            Else
                Return False
            End If

        Catch ex As Exception
            Return False
        End Try
    End Function

    Protected Sub PostRemittanceHdr(ByVal pStrFileNameAndPath As String, ByVal pEdi835 As String)
        Dim lBoolResult As Boolean
        Dim lRemitanceMethods As RemittanceMethods
        Dim lStrRTN As String = ""
        Try

            lRemitanceMethods = New RemittanceMethods()
            lStrRTN = lRemitanceMethods.GetRTN(pEdi835)
            If (lStrRTN <> "") Then

                If (lRemitanceMethods.CheckIfExist(lStrRTN)) Then
                    lRemitanceMethods.MoveFiles(pStrFileNameAndPath, pStrFileNameAndPath.Replace("ClaimResponse835", "ClaimResponse835Archive"))
                Else
                    lBoolResult = lRemitanceMethods.PostRemittanceHeaderOnly(pStrFileNameAndPath, pEdi835)
                    
                End If
            Else
                Throw New Exception
            End If

        Catch ex As Exception
            Throw ex
        End Try

    End Sub

#End Region



    
End Class
