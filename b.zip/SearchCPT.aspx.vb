
Partial Class Billing_SearchCPT
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then
            If Request.QueryString("cpt") IsNot Nothing Then
                txtCode.Text = Request.QueryString("cpt").ToString()
            End If

            If Not Request.QueryString("dsc") Is Nothing Then
                'txtDescription.Text = Server.UrlDecode(Request.QueryString("dsc").ToString())
            End If

            If Not Request.QueryString("TextBoxName") Is Nothing Then
                txtHdn.Text = Request.QueryString("TextBoxName").ToString()
            End If

            If Not Request.QueryString("Description") Is Nothing Then
                txtHdn.Text += "|" & Request.QueryString("Description").ToString()
            End If

            If Not Request.QueryString("Charges") Is Nothing Then
                txtHdn.Text += "|" & Request.QueryString("Charges").ToString()
            End If

            If Not Request.QueryString("lID") Is Nothing Then
                txtHdn.Text += "|" & Request.QueryString("lID").ToString()
            End If


        End If

    End Sub

    Protected Sub grdCPT_NeedDataSource(ByVal source As Object, ByVal e As Telerik.WebControls.GridNeedDataSourceEventArgs) Handles grdCPT.NeedDataSource
        'SuperBillMethods.LoadCPTGridByDescription(grdCPT, txtDescription.Text, txtCode.Text)
        Dim lDS = New DataSet
        Dim lUser = New User
        'Dim lResultXmlData As String = ""

        If (txtCode.Text = "") Then
            Exit Sub
        End If

        Try
            lUser = CType(Session("User"), User)
            lDS = IMOMethods.SearchCPT(lUser, txtCode.Text)

            'lResultXmlData = IMOMethods.SearchCPT(txtCode.Text)
            If (lDS IsNot Nothing) Then
                grdCPT.DataSource = lDS
                ' Me.xmlSrcCPT.Data = lResultXmlData
                ' Me.grdCPT.DataSource = xmlSrcCPT
            Else
                grdCPT.DataSource = ""
                'lblErrorMsg.Text = "Failed To Load"
                'lblErrorMsg.Visible = True
            End If
        Catch ex As Exception
            grdCPT.DataSource = ""
            'lblErrorMsg.Text = "Failed To Load"
            'lblErrorMsg.Visible = True
        End Try

    End Sub

    Protected Sub grdCPT_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdCPT.SelectedIndexChanged
        Dim CPTColl As CPTColl
        Dim CPT As New CPTDB()
        Dim lCPTData As String = ""
        Dim lineId As String = ""

        CPT.Code = grdCPT.SelectedItems.Item(0).Cells(4).Text
        CPT.ShortDescription = grdCPT.SelectedItems.Item(0).Cells(6).Text
        CPT.SuperBillId = ""
        CPT.IMO = grdCPT.SelectedItems.Item(0).Cells(5).Text

        If Request.QueryString("lid") Is Nothing Then
            If Session("CPTColl") IsNot Nothing Then
                CPTColl = Session("CPTColl")
                If CPTColl.IndexOf(CPT) >= 0 Then
                    lblMessage.Text = "Code Already Exist"
                    Return
                End If
            End If
        Else
            lineId = Request.QueryString("lid")
            lCPTData = lineId & "|"
        End If
        lCPTData = lCPTData & CPT.Code & "|" & CPT.ShortDescription & "|" & txtHdn.Text & "|" & CPT.IMO


        lblClose.Text = "<script>CloseOnReload('" & lCPTData & "')</Script>"
    End Sub

    Protected Sub btnClose_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnClose.Click
        lblClose.Text = "<script>CloseOnReload('')</Script>"
    End Sub


    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSearch.Click
        grdCPT.Rebind()
    End Sub
End Class
