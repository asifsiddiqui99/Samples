
Partial Class Billing_Default2
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'Dim lUser As User

        'lUser = CType(Session.Item("User"), User)
        'Dim lEmployee As New Employee(lUser.ConnectionString)
        'Dim lDs As DataSet

        'Try
        '    lDs = lEmployee.GetActiveEmployees("")
        '    '            DataList1.DataSource = lDs
        '    '            DataList1.DataBind()
        'Catch ex As Exception

        'End Try

        Dim lXml As String = "<Message xmlns=""http://www.surescripts.com/messaging"" version=""1.0"">  <Header>  <To>mailto:9999955.ncpdp@surescripts.com</To>   <From>mailto:6255358965001.spi@surescripts.com</From>   <MessageID>0</MessageID>   <RelatesToMessageID>51564f24aadsdc3c94086486fcbfd6166</RelatesToMessageID>   <SentTime>2007-03-30T11:03:27.0Z</SentTime>   <TestMessage />   </Header> <Body> <Error>  <Code>601</Code>   </Error>  </Body>  </Message>"

        Response.Write(lXml)
    End Sub
End Class
