﻿using System.ComponentModel.DataAnnotations;

namespace ErPrescriptionWriterV2.Models
{
    public class Prescription
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Medication Name is required.")]
        public string DrugName { get; set; }

        [Required(ErrorMessage = "Sig is required.")]
        public string Sig { get; set; }

        [Required(ErrorMessage = "Quantity is required.")]
        public string Qty { get; set; }
        public string Route { get; set; }
        public string Strength { get; set; }
        public string Unit { get; set; }
        public string Form { get; set; }
        public bool IsDispense { get; set; }

        [Required(ErrorMessage = "Patient is required")]
        public int PatientId { get; set; }
        public Patient Patient { get; set; }


    }
}