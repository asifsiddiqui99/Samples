﻿using System;
using System.ComponentModel.DataAnnotations;


namespace ErPrescriptionWriterV2.Models
{
    public class Patient
    {
        public int ID { get; set; }

        [Required(ErrorMessage = "Last Name is required.")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "First Name is required.")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "DOB is required.")]
        public DateTime DOB { get; set; }

        [Required(ErrorMessage = "Address is required.")]
        public string Address { get; set; }

        [Required(ErrorMessage = "Gender is required.")]
        public char Gender { get; set; }
        public string PhoneNumber { get; set; }
        public DateTime DateAdded { get; set; }




    }
}