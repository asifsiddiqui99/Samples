﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(ErPrescriptionWriterV2.Startup))]
namespace ErPrescriptionWriterV2
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
