﻿$(document).ready(function () {

    var viewModel = {
        medications: []
    };
    var sigContainer = $("#sigContainer");
    var grid = $("#drugTable")
    var favoriteContainer = $("#browseFavoritesContainer");
    var medicationContainer = $("#searchMedicationContainer");


    sigContainer.hide();
    grid.hide();
    favoriteContainer.hide();


    var favoriteTable = $("#favoriteTable").DataTable({
        data: [],
        columns: [
            {
                data: "synonym",
                render: function (data, type, drug) {
                    return "<h6>" + data + "</h6>";
                }

            },
            {
                data: "name"

            }
            
        ],
        rowCallback: function (row, data) { },
        filter: false,
        info: false,
        ordering: false,
        processing: true,
        retrieve: true,
        paging: false

    });

    var drugTable = $("#drugTable").DataTable({
        data: [],
        columns: [
            {
                data: "synonym",
                render: function (data, type, drug) {
                    return "<h6>" + data + "</h6>";
                }

            },
            {
                data: "name"

            }
        ],
        rowCallback: function (row, data) { },
        filter: false,
        info: false,
        ordering: false,
        processing: true,
        retrieve: true,
        paging: false

    });



    $("#search").on("click", function (e) {
        grid.show();
        grid.attr('style', 'width:100%');
        sigContainer.show();

        var drugName = $("#medication").val();

        $.ajax({
            url: "https://rxnav.nlm.nih.gov/REST/drugs.json?name=" + drugName,
            type: "get",
        }).done(function (result) {
            drugTable.clear().draw();
            drugTable.rows.add(result.drugGroup.conceptGroup[1].conceptProperties).draw();
            console.log('loded');
        }).fail(function (jqXHR, textStatus, errorThrown) {
            // needs to implement if it fails
        });
    });

    $("#freeText").on("click", function () {
        if ($(this).prop("checked")) {
            grid.hide();
            $("#search").hide();
            sigContainer.show();
        }
        else {
            $("#search").show();
            sigContainer.hide();

        }
    });


    $('#drugTable tbody').on('click', 'tr', function () {
        if ($(this).hasClass('selected')) {
            $(this).removeClass('selected');
        }
        else {
            drugTable.$('tr.selected').removeClass('selected');
            $(this).addClass('selected');
        }
    });

    $("#medications").on("click", ".js-delete", function () {

        var span = $(this).parents("td").siblings().children(".medication-barblue");
        console.log(span.text());

        $(this).parents("li").remove();
       
        

    }); 



    $("#addToList").on("click", function (e) {

        
        /*var template = $("#medication-template").html();

        template = template.replace("{{MedicationPlaceHolder}}", drugTable.rows(".selected").data()[0].synonym);
        template = template.replace("{{SigPlaceHolder}}", $("#sig").val());
        template = template.replace("{{QtyPlaceHolder}}", $("#qty").val());

        $("#medications").append(template);


        viewModel.medications.push({ drugName: drugTable.rows(".selected").data()[0].synonym, sig: 'Once a day', qty: '10' }); */

        var item = { drugName: drugTable.rows(".selected").data()[0].synonym, sig: $("#sig").val(), qty: $("#qty").val() };
        addToList(item);
       


    });



    function addToList(listItem) {
        var template = $("#medication-template").html();

        template = template.replace("{{MedicationPlaceHolder}}", listItem.drugName);
        template = template.replace("{{SigPlaceHolder}}", listItem.sig);
        template = template.replace("{{QtyPlaceHolder}}", listItem.qty);

        $("#medications").append(template);


        viewModel.medications.push({ drugName: listItem.drugName, sig: listItem.sig, qty: listItem.qty });
    }

        /*
        * 
        * Browse Favorites
        *
        */

    $("#browseFavorite").on("click", function (e) {

        
        if (favoriteTable.rows().data().length == 0)
        {
            $.ajax({
                url: "https://rxnav.nlm.nih.gov/REST/drugs.json?name=zantac",
                type: "get",
            }).done(function (result) {
                favoriteTable.clear().draw();
                favoriteTable.rows.add(result.drugGroup.conceptGroup[1].conceptProperties).draw();
            }).fail(function (jqXHR, textStatus, errorThrown) {
                // needs to implement if it fails
            });
        }

        
        favoriteTable.column(1).visible(false);
        
        medicationContainer.hide();
        favoriteContainer.show();
        $("#favoriteTable").attr('style', 'width:100%');

    });

    
    $("#favoriteCancel").on("click", function (e) {

        $("#searchMedicationContainer").show();
        $("#browseFavoritesContainer").hide();


    });

    $("#favoriteOk").on("click", function (e) {

        $("#searchMedicationContainer").show();
        $("#browseFavoritesContainer").hide();

        //Ajax Call to get all drugs within the selected favorite
        /*$.ajax({
            url: "/api/GetFavoriteDrugs/" + favoriteTable.rows(".selected").data()[0].id,
            type: "get",
        }).done(function (result) {
            $.each(result, function (drug) {
                var item = { drugName: drug.name, sig: drug.sig, qty: drug.qty };
                addToList(item);
            });
        }).fail(function (jqXHR, textStatus, errorThrown) {
            // needs to implement if it fails
        }); */


        /* Need to delete below two lines when Ajax lines will be uncommented */
        var item = { drugName: favoriteTable.rows(".selected").data()[0].synonym, sig: 'Thrice a day', qty: '35' };
        addToList(item);


    });

    $('#favoriteTable tbody').on('click', 'tr', function () {
        $(this).toggleClass('selected');
    });



    


});