Imports System.Xml
Imports System.Data.SqlClient
Imports System.Configuration
Imports ElixirLibrary
Namespace SureScripts
    Public Class NewPrescription
#Region "Instance Variables"
        Private mHeader As HeaderType = New HeaderType
        Private mNewRx As NewRxType = New NewRxType
        Private mLocaldb As LocalDBType = New LocalDBType
        Private mConnectionString As String = ""
#End Region


#Region "Properties"
        Public Property Header() As HeaderType
            Get
                Return mHeader
            End Get
            Set(ByVal Value As HeaderType)
                mHeader = Value
            End Set
        End Property
        Public Property NewRx() As NewRxType
            Get
                Return mNewRx
            End Get
            Set(ByVal Value As NewRxType)
                mNewRx = Value
            End Set
        End Property
        Public Property LocalDB() As LocalDBType
            Get
                Return mLocaldb
            End Get
            Set(ByVal Value As LocalDBType)
                mLocaldb = Value
            End Set
        End Property

        Public Property ConnectionString() As String
            Get
                Return mConnectionString
            End Get
            Set(ByVal Value As String)
                mConnectionString = Value
            End Set
        End Property
#End Region


#Region "Methods"


        Private Sub GetNode(ByVal tree As XmlNode, ByVal RecMessage As SureScriptsLibrary.SureScripts.ReceivedMessage)
            Dim lName As String = tree.Name

            Try
                Select Case lName.ToUpper
                    Case "TO"
                        RecMessage.HeaderType.To.MailAddress = tree.InnerText
                    Case "FROM"
                        RecMessage.HeaderType.From.MailAddress = tree.InnerText
                    Case "MESSAGEID"
                        RecMessage.HeaderType.MesssageID = tree.InnerText
                    Case "RELATESTOMESSAGEID"
                        RecMessage.HeaderType.RelatesToMessageID = tree.InnerText
                    Case "SENTTIME"
                        RecMessage.HeaderType.SentTime.UtcDate = tree.InnerText
                    Case "CODE"
                        RecMessage.ErrorType.Code = tree.InnerText
                        RecMessage.StatusType.Code = tree.InnerText
                    Case "DESCRIPTIONCODE"
                        RecMessage.ErrorType.DescriptionCode = tree.InnerText
                    Case "DESCRIPTION"
                        RecMessage.ErrorType.Description = tree.InnerText
                    Case "ERROR"
                        RecMessage.MessageType = "ERROR"
                    Case "STATUS"
                        RecMessage.MessageType = "STATUS"
                End Select

            Catch ex As Exception
                Throw New Exception(ex.Message + " : SurescriptsLibrary\NewPrescription.GetNode(ByVal tree As XmlNode, ByVal RecMessage As SureScriptsLibrary.SureScripts.ReceivedMessage) ")
            End Try

        End Sub

        Public Sub ParseTree(ByVal tree As XmlNode, ByVal RecMessage As SureScriptsLibrary.SureScripts.ReceivedMessage)
            Try
                If Not (tree Is Nothing) Then
                    GetNode(tree, RecMessage)
                End If
                If tree.HasChildNodes Then
                    tree = tree.FirstChild
                    While Not (tree Is Nothing)
                        ParseTree(tree, RecMessage)
                        tree = tree.NextSibling
                    End While
                End If

            Catch ex As Exception
                Throw New Exception(ex.Message + " : SurescriptsLibrary\NewPrescription.ParseTree(ByVal tree As XmlNode, ByVal RecMessage As SureScriptsLibrary.SureScripts.ReceivedMessage) ")
            End Try
        End Sub


        Public Sub UpdateMessageHdrXML(ByVal lXMLContents As String)

            Dim lConnection As New Connection()
            Dim lQuery As String = String.Empty
            Dim lXmlDocument As New XmlDocument()            
            Dim lMessageId As String = String.Empty
            Dim lXmlNamespaceManager As XmlNamespaceManager = Nothing



            lXMLContents = lXMLContents.Substring(lXMLContents.IndexOf("<Header>"))
            lXMLContents = "<Message>" + lXMLContents

            lXmlDocument.LoadXml(lXMLContents)
            lMessageId = lXmlDocument.SelectSingleNode("//Header/MessageID").InnerText




            'lXMLData = lXMLData.Substring(lXMLData.IndexOf("<Header>"))
            'lXMLData = "<Message>" + lXMLData

            'lXmlDocument.LoadXml(lXMLContents)
            'lXmlNamespaceManager = New XmlNamespaceManager(lXmlDocument.NameTable)
            'lXmlNamespaceManager.AddNamespace("NewPrescription", "http://www.surescripts.com/messaging")


            'lMessageId = lXmlDocument.SelectSingleNode("//NewPrescription:Header/NewPrescription:MessageID", lXmlNamespaceManager).InnerText


            lQuery = "Update MessageHdr Set XMLContents ='" & lXMLContents.Replace("'", "''") & "' " _
                   & "Where MessageId ='" & lMessageId & "' "


            Try
                lConnection.ExecuteCommand(lQuery)
            Catch ex As Exception
                Throw New Exception(ex.Message + "SureScriptsLibrary\NewPrescription.UpdateMessageHdrXML(ByVal lXMLContents As String) ")
            End Try

        End Sub

        Public Function SaveStatus(ByVal constr As String, ByVal RecMessage As ReceivedMessage) As Boolean

            Dim lConnection As New Connection()

            Dim lQuery As String
            Dim lDs As New DataSet
            Dim lMessageCode As Integer
            Dim lStatus As Boolean = True
            Dim lMessageType As Integer
            Dim lMessageStatus As String
            Dim lRetries As String
            Dim lCode As String
            Dim lHdrStatus As String
            Dim lPoNo As String
            Dim lSPI As String

            Try

                lConnection.BeginTrans()

                lQuery = "Select *, Cast(Right(PrescriberOrderNo,9) AS BigInt) AS PONo From MessageHdr " _
                       & "Where MessageId ='" & RecMessage.HeaderType.RelatesToMessageID & "' "


                If lConnection.IsTransactionAlive Then
                    lDs = lConnection.ExecuteTransactionQuery(lQuery)
                Else
                    lDs = lConnection.ExecuteQuery(lQuery)
                End If

                If lDs.Tables(0).Rows.Count > 0 Then
                    lMessageCode = CType(lDs.Tables(0).Rows(0)("MessageCode"), Integer)
                    lHdrStatus = lDs.Tables(0).Rows(0)("LastStatus")
                    lPoNo = lDs.Tables(0).Rows(0)("PoNo")
                    lSPI = lDs.Tables(0).Rows(0)("UserId")
                End If

                If RecMessage.MessageType = "ERROR" Then
                    lMessageType = 1
                    lCode = RecMessage.ErrorType.Code
                Else
                    lMessageType = 3
                    lCode = RecMessage.StatusType.Code
                End If

                If (lCode = "601" Or lCode = "900") And (lHdrStatus <> "Success" And lHdrStatus <> "Failure") Then
                    lMessageStatus = "Failure"

                    lQuery = "Update MessageDtl Set Status = 'Failure' " _
                           & "Where Direction = 'O' " _
                           & "And DetailMessageType = 4 " _
                           & "And MessageCode = " & lMessageCode & " "


                    If lConnection.IsTransactionAlive Then
                        lConnection.ExecuteTransactionCommand(lQuery)
                    Else
                        lConnection.ExecuteCommand(lQuery)
                    End If


                    lQuery = "Update MessageHdr " _
                           & "Set LastStatus ='" & lMessageStatus & "' " _
                           & "Where MessageCode = " & lMessageCode & " "


                    If lConnection.IsTransactionAlive Then
                        lConnection.ExecuteTransactionCommand(lQuery)
                    Else
                        lConnection.ExecuteCommand(lQuery)
                    End If




                ElseIf (lCode = "600" Or lCode = "602" Or lCode = "NR") And (lHdrStatus <> "Success" And lHdrStatus <> "Failure") Then
                    lMessageStatus = "Failure"

                    lQuery = "Select Count(*) Retries " _
                           & "From MessageDtl " _
                           & "Where MessageCode = " & lMessageCode & " " _
                           & "And Direction = 'O' " _
                           & "And DetailMessageType = 4 " _
                           & "And Status = 'Pending' "


                    If lConnection.IsTransactionAlive Then
                        lDs = lConnection.ExecuteTransactionQuery(lQuery)
                    Else
                        lDs = lConnection.ExecuteQuery(lQuery)
                    End If

                    If lDs.Tables(0).Rows.Count > 0 Then
                        lRetries = CType(lDs.Tables(0).Rows(0)("Retries"), Integer)
                    End If

                    If lRetries >= 4 Then

                        lQuery = "Update MessageDtl Set Status = 'Failure' " _
                               & "Where Direction = 'O' " _
                               & "And DetailMessageType = 4 " _
                               & "And MessageCode = " & lMessageCode & " "

                        If lConnection.IsTransactionAlive Then
                            lConnection.ExecuteTransactionCommand(lQuery)
                        Else
                            lConnection.ExecuteCommand(lQuery)
                        End If



                        lQuery = "Update MessageHdr " _
                               & "Set LastStatus ='" & lMessageStatus & "' " _
                               & "Where MessageCode = " & lMessageCode & " "

                        If lConnection.IsTransactionAlive Then
                            lConnection.ExecuteTransactionCommand(lQuery)
                        Else
                            lConnection.ExecuteCommand(lQuery)
                        End If


                        'If Not lStatus Then
                        '    Throw New Exception
                        'End If
                    Else
                        lQuery = "Update MessageDtl Set Status = 'Pending' " _
                               & "Where Direction = 'O' " _
                               & "And DetailMessageType = 4 " _
                               & "And MessageCode = " & lMessageCode & " "

                        If lConnection.IsTransactionAlive Then
                            lConnection.ExecuteTransactionCommand(lQuery)
                        Else
                            lConnection.ExecuteCommand(lQuery)
                        End If



                        lQuery = "Update MessageHdr " _
                               & "Set LastStatus ='Pending' " _
                               & "Where MessageCode = " & lMessageCode & " "

                        If lConnection.IsTransactionAlive Then
                            lConnection.ExecuteTransactionCommand(lQuery)
                        Else
                            lConnection.ExecuteCommand(lQuery)
                        End If


                        lMessageStatus = "Pending"
                    End If

                ElseIf lCode = "000" And (lHdrStatus <> "Success" And lHdrStatus <> "Failure") Then
                    lMessageStatus = "Success"

                    lQuery = "Update MessageDtl Set Status = 'InProgress' " _
                           & "Where Direction = 'O' " _
                           & "And LineId = (Select Max(LineId)  " _
                           & "              From MessageDtl " _
                           & "              Where MessageCode = " & lMessageCode & "  " _
                           & "              And Direction = 'O' " _
                           & "              And DetailMessageType = 4) "


                    If lConnection.IsTransactionAlive Then
                        lConnection.ExecuteTransactionCommand(lQuery)
                    Else
                        lConnection.ExecuteCommand(lQuery)
                    End If




                    lQuery = "Update MessageDtl Set Status = 'Failure' " _
                           & "Where Direction = 'O' " _
                           & "And LineId <> (Select Max(LineId)  " _
                           & "                    From MessageDtl " _
                           & "                    Where MessageCode = " & lMessageCode & "  " _
                           & "	                  And Direction = 'O' " _
                           & "	                  And DetailMessageType = 4) " _
                           & "And MessageCode = " & lMessageCode & "  "

                    If lConnection.IsTransactionAlive Then
                        lConnection.ExecuteTransactionCommand(lQuery)
                    Else
                        lConnection.ExecuteCommand(lQuery)
                    End If



                    lQuery = "Update MessageHdr " _
                               & "Set LastStatus ='InProgress' " _
                               & "Where MessageCode = " & lMessageCode & " "

                    If lConnection.IsTransactionAlive Then
                        lConnection.ExecuteTransactionCommand(lQuery)
                    Else
                        lConnection.ExecuteCommand(lQuery)
                    End If



                    'It Should Become "Failure" or "Success" On receiving Message from Ultimate Receiver
                    'Should Be handle by Message Receiving Form.

                ElseIf lCode = "010" And (lHdrStatus <> "Success" And lHdrStatus <> "Failure") Then

                    lMessageStatus = "Success"

                    lQuery = "Update MessageDtl Set Status = 'Success' " _
                           & "Where Direction = 'O' " _
                           & "And LineId = (Select Max(LineId)  " _
                           & "              From MessageDtl " _
                           & "              Where MessageCode = " & lMessageCode & "  " _
                           & "              And Direction = 'O' " _
                           & "              And DetailMessageType = 4) "

                    If lConnection.IsTransactionAlive Then
                        lConnection.ExecuteTransactionCommand(lQuery)
                    Else
                        lConnection.ExecuteCommand(lQuery)
                    End If




                    lQuery = "Update MessageDtl Set Status = 'Failure' " _
                           & "Where Direction = 'O' " _
                           & "And LineId <> (Select Max(LineId)  " _
                           & "                    From MessageDtl " _
                           & "                    Where MessageCode = " & lMessageCode & "  " _
                           & "	                  And Direction = 'O' " _
                           & "	                  And DetailMessageType = 4) " _
                           & "And MessageCode = " & lMessageCode & "  "

                    If lConnection.IsTransactionAlive Then
                        lConnection.ExecuteTransactionCommand(lQuery)
                    Else
                        lConnection.ExecuteCommand(lQuery)
                    End If




                    lQuery = "Update MessageHdr " _
                           & "Set LastStatus ='" & lMessageStatus & "' " _
                           & "Where MessageCode = " & lMessageCode & " "

                    If lConnection.IsTransactionAlive Then
                        lConnection.ExecuteTransactionCommand(lQuery)
                    Else
                        lConnection.ExecuteCommand(lQuery)
                    End If


                Else
                    Throw New Exception(" SurescriptsLibrary\NewPrescription.SaveStatus(ByVal constr As String, ByVal RecMessage As ReceivedMessage) ")
                End If





                lQuery = "INSERT INTO MessageDtl(MessageCode, MessageTime, " _
                       & "Status, Code, DescriptionCode, " _
                       & "[Description],Direction,ReceivedMessageId,DetailMessageType) " _
                       & "VALUES(" _
                       & " " & lMessageCode & ", " _
                       & "'" & Left(RecMessage.HeaderType.SentTime.UtcDate, 19) & "', " _
                       & "'" & lMessageStatus & "'," _
                       & "'" & lCode & "'," _
                       & "'" & RecMessage.ErrorType.DescriptionCode & "'," _
                       & "'" & RecMessage.ErrorType.Description.Replace("'", "''") & " '," _
                       & "'I'," _
                       & "'" & RecMessage.HeaderType.MesssageID & "'," _
                       & " " & lMessageType & ")"


                If lConnection.IsTransactionAlive Then
                    lConnection.ExecuteTransactionCommand(lQuery)
                Else
                    lConnection.ExecuteCommand(lQuery)
                End If

                '*****************Commented for WebService Version ******************

                'lStatus = UpdateRenewalRequestStatus(lPoNo, lSPI, lMessageStatus, constr)
                'If Not lStatus Then
                '    Throw New Exception("SurescriptsLibrary\NewPrescription.UpdateRenewalRequestStatus(ByVal lRxId As String, ByVal lSPI As String, ByVal lStatus As String, ByVal lConnectionString As String) ")
                'End If

                '*****************End Commented for WebService Version ******************


                'If ErrorCode = 601 or 900 Status = failure And All others are also Failure
                'If ErrorCode = 600 or 602 Status = failure And All others will be Pending if Out is Less then 4
                'If Code = 000 Then Status = "Success" And Last One  will be "InProgress" And All Others Will be Failure
                'If Code = 010 Then Status = "Success" And Last One will be "Success And All Others Will be Failure"



                lConnection.CommitTrans()

                SaveStatus = lStatus

            Catch ex As Exception
                lConnection.RollBackTrans()

                Throw New Exception(ex.Message + " : SurescriptsLibrary\NewPrescription.SaveStatus(ByVal constr As String, ByVal RecMessage As ReceivedMessage)  ")

                SaveStatus = False


            End Try

        End Function

        Public Function WriteXMLForNewPrescription(ByVal path As String, ByVal filename As String, ByVal constr As String, ByVal lMessageId As String, ByVal lRxId As String) As Boolean
            Dim xmlw As XmlTextWriter
            Dim lResult As Boolean
            Try

                '' ''lResult = AddMessage(filename, lMessageId, lRxId, constr)
                '' ''If lResult = False Then
                '' ''    Throw New Exception
                '' ''End If
                xmlw = New XmlTextWriter(path & "\\" & filename, Nothing)
                xmlw.Formatting = Formatting.Indented
                'xmlw.WriteStartDocument()
                xmlw.WriteStartElement("Message")
                xmlw.WriteAttributeString("xmlns", "http://www.surescripts.com/messaging")
                xmlw.WriteAttributeString("version", "1.0")

                '' Header complex type element
                xmlw.WriteStartElement("Header")

                xmlw.WriteStartElement("To")
                xmlw.WriteString("mailto:" & Me.Header.To.MailAddress & "@surescripts.com")
                'xmlw.WriteString(Me.Header.To.MailAddress)
                xmlw.WriteEndElement()

                xmlw.WriteStartElement("From")
                xmlw.WriteString("mailto:" & Me.Header.From.MailAddress & "@surescripts.com")
                'xmlw.WriteString(Me.Header.From.MailAddress)
                xmlw.WriteEndElement()

                xmlw.WriteStartElement("MessageID")
                xmlw.WriteString(Me.Header.MesssageID)
                xmlw.WriteEndElement()

                xmlw.WriteStartElement("SentTime")
                xmlw.WriteString(Me.Header.SentTime.UtcDate)
                xmlw.WriteEndElement()

                'xmlw.WriteStartElement("TestMessage")
                'xmlw.WriteString("")
                'xmlw.WriteEndElement()


                xmlw.WriteEndElement()
                ''' End Header Complex type




                ''' Body complex type
                xmlw.WriteStartElement("Body")
                ''' NewRx complex type
                xmlw.WriteStartElement("NewRx")
                If Me.NewRx.RxReferenceNumber.Trim <> "" Then
                    ''' RxReferenceNumber Simple type
                    xmlw.WriteStartElement("RxReferenceNumber")
                    xmlw.WriteString(Me.NewRx.RxReferenceNumber.Trim)
                    xmlw.WriteEndElement()
                    ''' End RxReferenceNumber Simple type
                End If

                If Me.NewRx.PrescriberOrderNumber.Trim <> "" Then
                    ''' PrescriberOrderNumber Simple type
                    xmlw.WriteStartElement("PrescriberOrderNumber")
                    xmlw.WriteString(Me.NewRx.PrescriberOrderNumber.Trim)
                    xmlw.WriteEndElement()
                End If


                ' Pharmacy complex type
                xmlw.WriteStartElement("Pharmacy")
                ''' Identification complex type
                xmlw.WriteStartElement("Identification")
                ''' NCPDPID simple type
                xmlw.WriteStartElement("NCPDPID")
                xmlw.WriteString(Me.NewRx.Pharmacy.Identification.NCPDPID.Trim)
                xmlw.WriteEndElement()
                ''' End NCPDPID simple type
                If Me.NewRx.Pharmacy.Identification.FileID.Trim <> "" Then
                    ''' FileID simple type
                    xmlw.WriteStartElement("FileID")
                    xmlw.WriteString(Me.NewRx.Pharmacy.Identification.FileID.Trim)
                    xmlw.WriteEndElement()
                    ''' End FileID simple type
                End If
                If Me.NewRx.Pharmacy.Identification.StateLicenseNumber.Trim <> "" Then
                    ''' StateLicenseNumber simple type
                    xmlw.WriteStartElement("StateLicenseNumber")
                    xmlw.WriteString(Me.NewRx.Pharmacy.Identification.StateLicenseNumber.Trim)
                    xmlw.WriteEndElement()
                    ''' End StateLicenseNumber simple type
                End If
                If Me.NewRx.Pharmacy.Identification.MedicareNumber.Trim <> "" Then
                    ''' MedicareNumber simple type
                    xmlw.WriteStartElement("MedicareNumber")
                    xmlw.WriteString(Me.NewRx.Pharmacy.Identification.MedicareNumber.Trim)
                    xmlw.WriteEndElement()
                    ''' End MedicareNumber simple type
                End If
                If Me.NewRx.Pharmacy.Identification.MediCaidNumber.Trim <> "" Then
                    ''' MediaciadNumber simple type
                    xmlw.WriteStartElement("MedicaidNumber")
                    xmlw.WriteString(Me.NewRx.Pharmacy.Identification.MediCaidNumber.Trim)
                    xmlw.WriteEndElement()
                    ''' End MedicaidNumber simple type
                End If
                If Me.NewRx.Pharmacy.Identification.PPONumber.Trim <> "" Then
                    ''' PPONumber simple type
                    xmlw.WriteStartElement("PPONumber")
                    xmlw.WriteString(Me.NewRx.Pharmacy.Identification.PPONumber.Trim)
                    xmlw.WriteEndElement()
                    ''' End PPONumber simple type
                End If
                If Me.NewRx.Pharmacy.Identification.PayerId.Trim <> "" Then
                    ''' PayerID simple type
                    xmlw.WriteStartElement("PayerID")
                    xmlw.WriteString(Me.NewRx.Pharmacy.Identification.PayerId.Trim)
                    xmlw.WriteEndElement()
                    ''' End PayerID simple type
                End If
                If Me.NewRx.Pharmacy.Identification.BINLocationNumber.Trim <> "" Then
                    ''' BINLocationNumber simple type
                    xmlw.WriteStartElement("BINLocationNumber")
                    xmlw.WriteString(Me.NewRx.Pharmacy.Identification.BINLocationNumber.Trim)
                    xmlw.WriteEndElement()
                    ''' End BinLocationNumber simple type
                End If
                If Me.NewRx.Pharmacy.Identification.DEANumber.Trim <> "" Then
                    ''' DEANumber simple type
                    xmlw.WriteStartElement("DEANumber")
                    xmlw.WriteString(Me.NewRx.Pharmacy.Identification.DEANumber.Trim)
                    xmlw.WriteEndElement()
                    ''' End DEANumber simple type
                End If
                If Me.NewRx.Pharmacy.Identification.HIN.Trim <> "" Then
                    ''' Hin simple type
                    xmlw.WriteStartElement("HIN")
                    xmlw.WriteString(Me.NewRx.Pharmacy.Identification.HIN.Trim)
                    xmlw.WriteEndElement()
                    ''' End HIN simple type
                End If
                If Me.NewRx.Pharmacy.Identification.SecondaryCoverage.Trim <> "" Then
                    ''' SecondaryCoverage simple type
                    xmlw.WriteStartElement("SecondaryCoverage")
                    xmlw.WriteString(Me.NewRx.Pharmacy.Identification.SecondaryCoverage.Trim)
                    xmlw.WriteEndElement()
                    ''' End SecondaryCoverage simple type
                End If
                If Me.NewRx.Pharmacy.Identification.NAICode.Trim <> "" Then
                    ''' NAICode simple type
                    xmlw.WriteStartElement("NAICode")
                    xmlw.WriteString(Me.NewRx.Pharmacy.Identification.NAICode.Trim)
                    xmlw.WriteEndElement()
                    ''' End NAICode simple type
                End If
                If Me.NewRx.Pharmacy.Identification.PromotionNumber.Trim <> "" Then
                    ''' NAICode simple type
                    xmlw.WriteStartElement("NAICode")
                    xmlw.WriteString(Me.NewRx.Pharmacy.Identification.NAICode.Trim)
                    xmlw.WriteEndElement()
                    ''' End NAICode simple type
                End If
                xmlw.WriteEndElement()
                ''' End Identification complex type
                If Me.NewRx.Pharmacy.StoreName.Trim <> "" Then
                    ''' StoreName simple type
                    xmlw.WriteStartElement("StoreName")
                    xmlw.WriteString(Left(Me.NewRx.Pharmacy.StoreName.Trim, 35))
                    xmlw.WriteEndElement()
                    ''' End StoreName simple type
                End If


                If Me.NewRx.Pharmacy.Address.AddressLine1.Trim <> "" Or Me.NewRx.Pharmacy.Address.AddressLine2.Trim <> "" Or Me.NewRx.Pharmacy.Address.City.Trim <> "" Or Me.NewRx.Pharmacy.Address.State.Trim <> "" Or Me.NewRx.Pharmacy.Address.ZipCode.Trim <> "" Then
                    ''' Address complex type
                    xmlw.WriteStartElement("Address")
                    ''' AddressLine1 simple type
                    If Me.NewRx.Pharmacy.Address.AddressLine1 <> "" Then
                        xmlw.WriteStartElement("AddressLine1")
                        xmlw.WriteString(Left(Me.NewRx.Pharmacy.Address.AddressLine1.Trim, 35))
                        xmlw.WriteEndElement()
                        ''' End AddressLine1 simple type
                    End If
                    If Me.NewRx.Pharmacy.Address.AddressLine2 <> "" Then
                        ''' AddressLine2 simple type
                        xmlw.WriteStartElement("AddressLine2")
                        xmlw.WriteString(Left(Me.NewRx.Pharmacy.Address.AddressLine2.Trim, 35))
                        xmlw.WriteEndElement()
                        ''' End AddressLine2 simple type
                    End If
                    If Me.NewRx.Pharmacy.Address.City <> "" Then
                        ''' City simple type
                        xmlw.WriteStartElement("City")
                        xmlw.WriteString(Left(Me.NewRx.Pharmacy.Address.City.Trim, 35))
                        xmlw.WriteEndElement()
                        ''' End City simple type
                    End If
                    If Me.NewRx.Pharmacy.Address.State <> "" Then
                        ''' State simple type
                        xmlw.WriteStartElement("State")
                        xmlw.WriteString(Me.NewRx.Pharmacy.Address.State.Trim)
                        xmlw.WriteEndElement()
                        ''' End State simple type
                    End If
                    If Me.NewRx.Pharmacy.Address.ZipCode.Trim <> "" Then
                        ''' ZipCode simple type
                        xmlw.WriteStartElement("ZipCode")
                        xmlw.WriteString(Me.NewRx.Pharmacy.Address.ZipCode.Replace("-", ""))
                        xmlw.WriteEndElement()
                        ''' End ZipCode simple type
                    End If
                    xmlw.WriteEndElement()
                    ''' End Address complex type
                End If
                If Me.NewRx.Pharmacy.Email.Trim <> "" Then
                    ''' Email simple type
                    xmlw.WriteStartElement("Email")
                    xmlw.WriteString(Left(Me.NewRx.Pharmacy.Email.Trim, 80))
                    xmlw.WriteEndElement()
                    ''' End Email simple type
                End If
                Dim a As Integer = 0
                If Not Me.NewRx.Pharmacy.PhoneNumbers.Phone Is Nothing Then
                    ''' PhoneNumbers complex type
                    xmlw.WriteStartElement("PhoneNumbers")
                    For a = 0 To Me.NewRx.Pharmacy.PhoneNumbers.Phone.Length - 1
                        If Me.NewRx.Pharmacy.PhoneNumbers.Phone(a).Number.Trim <> "" Then
                            ''' Phone complex type
                            xmlw.WriteStartElement("Phone")
                            ''' Number simple type
                            xmlw.WriteStartElement("Number")
                            xmlw.WriteString(Left(Me.NewRx.Pharmacy.PhoneNumbers.Phone(a).Number.Trim, 25))
                            xmlw.WriteEndElement()
                            ''' End Number simple type
                            ''' Qualifier simple type
                            xmlw.WriteStartElement("Qualifier")
                            xmlw.WriteString(Me.NewRx.Pharmacy.PhoneNumbers.Phone(a).Qualifier)
                            xmlw.WriteEndElement()
                            ''' End Qualifier simple type
                            xmlw.WriteEndElement()
                            ''' End Phone complex type
                        End If
                    Next
                    xmlw.WriteEndElement()
                    ''' End PhoneNumbers complex type
                End If
                xmlw.WriteEndElement()
                ''' End Pharmacy complex type
                ''' Prescriber complex type
                xmlw.WriteStartElement("Prescriber")
                ''' Identification complex type
                xmlw.WriteStartElement("Identification")
                ''' SPI simple type
                xmlw.WriteStartElement("SPI")
                xmlw.WriteString(Me.NewRx.Prescriber.Identification.SPI)
                xmlw.WriteEndElement()
                ''' End SPI simple type
                If Me.NewRx.Prescriber.Identification.SocialSecurity.Trim <> "" Then
                    ''' SocialSecurity simple type
                    xmlw.WriteStartElement("SocialSecurity")
                    xmlw.WriteString(Left(Me.NewRx.Prescriber.Identification.SocialSecurity.Trim, 35))
                    xmlw.WriteEndElement()
                    ''' End SocialSecurity simple type
                End If

                If Me.NewRx.Prescriber.Identification.DEANumber.Trim <> "" Then
                    ''' DEANumber simple type
                    xmlw.WriteStartElement("DEANumber")
                    xmlw.WriteString(Left(Me.NewRx.Prescriber.Identification.DEANumber.Trim, 35))
                    xmlw.WriteEndElement()
                    ''' End DEANumber simple type
                End If

                If Me.NewRx.Prescriber.Identification.MedicaidNumber.Trim <> "" Then
                    ''' MedicaidNumber simple type
                    xmlw.WriteStartElement("MedicaidNumber")
                    xmlw.WriteString(Left(Me.NewRx.Prescriber.Identification.MedicaidNumber.Trim, 35))
                    xmlw.WriteEndElement()
                    ''' End MedicaidNumber simple type
                End If

                If Me.NewRx.Prescriber.Identification.MedicareNumber.Trim <> "" Then
                    ''' MedicareNumber simple type
                    xmlw.WriteStartElement("MedicareNumber")
                    xmlw.WriteString(Left(Me.NewRx.Prescriber.Identification.MedicareNumber.Trim, 35))
                    xmlw.WriteEndElement()
                    ''' End MedicareNumber simple type
                End If
                If Me.NewRx.Prescriber.Identification.UPIN.Trim <> "" Then
                    ''' UPIN simple type
                    xmlw.WriteStartElement("UPIN")
                    xmlw.WriteString(Left(Me.NewRx.Prescriber.Identification.UPIN.Trim, 35))
                    xmlw.WriteEndElement()
                    ''' End UPIN simple type
                End If

                If Me.NewRx.Prescriber.Identification.NPI.Trim <> "" Then
                    ''' UPIN simple type
                    xmlw.WriteStartElement("NPI")
                    xmlw.WriteString(Left(Me.NewRx.Prescriber.Identification.NPI.Trim, 35))
                    xmlw.WriteEndElement()
                    ''' End UPIN simple type
                End If


                '''''''''''
                xmlw.WriteEndElement()
                ''' End Identification complex type
                If Me.NewRx.Prescriber.ClinicName.Trim <> "" Then
                    ''' ClinicName simple type
                    xmlw.WriteStartElement("ClinicName")
                    xmlw.WriteString(Left(Me.NewRx.Prescriber.ClinicName.Trim, 35))
                    xmlw.WriteEndElement()
                    ''' End ClinicName simple type
                End If
                If Me.NewRx.Prescriber.Name.LastName.Trim <> "" Or Me.NewRx.Prescriber.Name.FirstName.Trim <> "" Or Me.NewRx.Prescriber.Name.MiddleName.Trim <> "" Then
                    ''' Name complex type
                    xmlw.WriteStartElement("Name")
                    If Me.NewRx.Prescriber.Name.LastName.Trim <> "" Then
                        ''' LastName simple type
                        xmlw.WriteStartElement("LastName")
                        xmlw.WriteString(Left(Me.NewRx.Prescriber.Name.LastName.Trim, 35))
                        xmlw.WriteEndElement()
                        ''' End LastName simple type
                    End If
                    If Me.NewRx.Prescriber.Name.FirstName.Trim <> "" Then
                        ''' FirstName simple type
                        xmlw.WriteStartElement("FirstName")
                        xmlw.WriteString(Left(Me.NewRx.Prescriber.Name.FirstName.Trim, 35))
                        xmlw.WriteEndElement()
                        ''' End FirstName simple type
                    End If
                    If Me.NewRx.Prescriber.Name.MiddleName.Trim <> "" Then
                        ''' MiddleName simple type
                        xmlw.WriteStartElement("MiddleName")
                        xmlw.WriteString(Left(Me.NewRx.Prescriber.Name.MiddleName.Trim, 35))
                        xmlw.WriteEndElement()
                        ''' End MidleName simple type
                    End If
                    xmlw.WriteEndElement()
                    ''' End Name complex type
                End If





                If Me.NewRx.Prescriber.PrescriberAgent.FirstName.Trim <> "" Or Me.NewRx.Prescriber.PrescriberAgent.LastName.Trim <> "" Or Me.NewRx.Prescriber.PrescriberAgent.MiddleName.Trim <> "" Then
                    ''' PrescriberAgent complex type
                    xmlw.WriteStartElement("PrescriberAgent")
                    If Me.NewRx.Prescriber.PrescriberAgent.LastName.Trim <> "" Then
                        ''' LastName simple type
                        xmlw.WriteStartElement("LastName")
                        xmlw.WriteString(Left(Me.NewRx.Prescriber.PrescriberAgent.LastName.Trim, 35))
                        xmlw.WriteEndElement()
                        ''' End LastName simple type
                    End If
                    If Me.NewRx.Prescriber.PrescriberAgent.FirstName.Trim <> "" Then
                        ''' FirstName simple type
                        xmlw.WriteStartElement("FirstName")
                        xmlw.WriteString(Left(Me.NewRx.Prescriber.PrescriberAgent.FirstName.Trim, 35))
                        xmlw.WriteEndElement()
                        ''' End FirstName simple type
                    End If
                    If Me.NewRx.Prescriber.PrescriberAgent.MiddleName.Trim <> "" Then
                        ''' MiddleName simple type
                        xmlw.WriteStartElement("MiddleName")
                        xmlw.WriteString(Left(Me.NewRx.Prescriber.PrescriberAgent.MiddleName.Trim, 35))
                        xmlw.WriteEndElement()
                        ''' End MidleName simple type
                    End If
                    xmlw.WriteEndElement()
                    ''' End PrescriberAgent complex type
                End If






                If Me.NewRx.Prescriber.Address.AddressLine1.Trim <> "" Or Me.NewRx.Prescriber.Address.AddressLine2.Trim <> "" Or Me.NewRx.Prescriber.Address.City.Trim <> "" Or Me.NewRx.Prescriber.Address.State.Trim <> "" Or Me.NewRx.Prescriber.Address.ZipCode.Trim <> "" Then
                    ''' Address complex type
                    xmlw.WriteStartElement("Address")
                    If Me.NewRx.Prescriber.Address.AddressLine1.Trim <> "" Then
                        ''' AddressLine1 simple type
                        xmlw.WriteStartElement("AddressLine1")
                        xmlw.WriteString(Left(Me.NewRx.Prescriber.Address.AddressLine1.Trim, 35))
                        xmlw.WriteEndElement()
                        ''' End AddressLine1 simple type
                    End If
                    If Me.NewRx.Prescriber.Address.AddressLine2.Trim <> "" Then
                        ''' AddressLine2 simple type
                        xmlw.WriteStartElement("AddressLine2")
                        xmlw.WriteString(Left(Me.NewRx.Prescriber.Address.AddressLine2.Trim, 35))
                        xmlw.WriteEndElement()
                        ''' End AddressLine2 simple type
                    End If
                    If Me.NewRx.Prescriber.Address.City.Trim <> "" Then
                        ''' City simple type
                        xmlw.WriteStartElement("City")
                        xmlw.WriteString(Left(Me.NewRx.Prescriber.Address.City.Trim, 35))
                        xmlw.WriteEndElement()
                        ''' End City simple type
                    End If
                    If Me.NewRx.Prescriber.Address.State.Trim <> "" Then
                        ''' State simple type
                        xmlw.WriteStartElement("State")
                        xmlw.WriteString(Me.NewRx.Prescriber.Address.State.Trim)
                        xmlw.WriteEndElement()
                        ''' End State simple type
                    End If
                    If Me.NewRx.Prescriber.Address.ZipCode.Trim <> "" Then
                        ''' ZipCode simple type
                        xmlw.WriteStartElement("ZipCode")
                        xmlw.WriteString(Me.NewRx.Prescriber.Address.ZipCode.Replace("-", ""))
                        xmlw.WriteEndElement()
                        ''' End ZipCode simple type
                    End If
                    xmlw.WriteEndElement()
                    ''' End Address complex type
                End If
                If Me.NewRx.Prescriber.Email.Trim <> "" Then
                    ''' Email simple type
                    xmlw.WriteStartElement("Email")
                    xmlw.WriteString(Left(Me.NewRx.Prescriber.Email.Trim, 80))
                    xmlw.WriteEndElement()
                    ''' End Email simple type
                End If
                If Not Me.NewRx.Prescriber.PhoneNumbers.Phone Is Nothing Then
                    ''' PhoneNumbers complex type
                    xmlw.WriteStartElement("PhoneNumbers")
                    For a = 0 To Me.NewRx.Prescriber.PhoneNumbers.Phone.Length - 1
                        If Me.NewRx.Prescriber.PhoneNumbers.Phone(a).Number.Trim <> "" Then
                            ''' Phone complex type
                            xmlw.WriteStartElement("Phone")
                            ''' Number simple type
                            xmlw.WriteStartElement("Number")
                            xmlw.WriteString(Left(Me.NewRx.Prescriber.PhoneNumbers.Phone(a).Number.Trim, 25))
                            xmlw.WriteEndElement()
                            ''' End Number simple type
                            ''' Qualifier simple type
                            xmlw.WriteStartElement("Qualifier")
                            xmlw.WriteString(Me.NewRx.Prescriber.PhoneNumbers.Phone(a).Qualifier)
                            xmlw.WriteEndElement()
                            ''' End Qualifier simple type
                            xmlw.WriteEndElement()
                            ''' End Phone complex type
                        End If
                    Next
                    xmlw.WriteEndElement()
                    ''' End PhoneNumbers complex type
                End If
                xmlw.WriteEndElement()
                ''' End Prescriber complex type
                ''' Patient Complex type
                xmlw.WriteStartElement("Patient")
                If (Me.NewRx.Patient.Identification.SocialSecurity.Trim <> "" _
                    Or Me.NewRx.Patient.Identification.FileID.Trim <> "" _
                    Or Me.NewRx.Patient.Identification.MedicaidNumber.Trim <> "" _
                    Or Me.NewRx.Patient.Identification.MedicalcareNumber.Trim <> "" _
                    Or Me.NewRx.Patient.Identification.PPONumber.Trim <> "") Then
                    ''' Identification complex type
                    xmlw.WriteStartElement("Identification")
                    If Me.NewRx.Patient.Identification.FileID.Trim <> "" Then
                        ''' FileID simple type
                        xmlw.WriteStartElement("FileId")
                        xmlw.WriteString(Left(Me.NewRx.Patient.Identification.FileID.Trim, 35))
                        xmlw.WriteEndElement()
                        ''' End FileID simple type
                    End If
                    If Me.NewRx.Patient.Identification.MedicalcareNumber.Trim <> "" Then
                        ''' MedicareNumber simple type
                        xmlw.WriteStartElement("MedicareNumber")
                        xmlw.WriteString(Left(Me.NewRx.Patient.Identification.MedicalcareNumber.Trim, 35))
                        xmlw.WriteEndElement()
                        ''' End MedicareNumber simple type
                    End If
                    If Me.NewRx.Patient.Identification.MedicaidNumber.Trim <> "" Then
                        ''' MedicaidNumber simple type
                        xmlw.WriteStartElement("MedicaidNumber")
                        xmlw.WriteString(Left(Me.NewRx.Patient.Identification.MedicaidNumber.Trim, 35))
                        xmlw.WriteEndElement()
                        ''' End MedicaidNumber simple type
                    End If
                    If Me.NewRx.Patient.Identification.PPONumber.Trim <> "" Then
                        ''' PPONumber simple type
                        xmlw.WriteStartElement("PPONumber")
                        xmlw.WriteString(Left(Me.NewRx.Patient.Identification.PPONumber.Trim, 35))
                        xmlw.WriteEndElement()
                        ''' End PPONumber simple type
                    End If


                    If Me.NewRx.Patient.Identification.SocialSecurity.Trim <> "" Then
                        ''' SocialSecurity simple type
                        xmlw.WriteStartElement("SocialSecurity")
                        xmlw.WriteString(Left(Me.NewRx.Patient.Identification.SocialSecurity.Trim, 35))
                        xmlw.WriteEndElement()
                        ''' End SocialSecurity simple type
                    End If


                    xmlw.WriteEndElement()

                    ''' End Identification complex type
                End If

                If Me.NewRx.Patient.Name.LastName.Trim <> "" Or Me.NewRx.Patient.Name.FirstName.Trim <> "" Or Me.NewRx.Patient.Name.MiddleName.Trim <> "" Then
                    ''' Name complex type
                    xmlw.WriteStartElement("Name")
                    If Me.NewRx.Patient.Name.LastName.Trim <> "" Then
                        ''' LastName simple type
                        xmlw.WriteStartElement("LastName")
                        xmlw.WriteString(Left(Me.NewRx.Patient.Name.LastName.Trim, 35))
                        xmlw.WriteEndElement()
                        ''' End LastName simple type
                    End If
                    If Me.NewRx.Patient.Name.FirstName.Trim <> "" Then
                        ''' FirstName simple type
                        xmlw.WriteStartElement("FirstName")
                        xmlw.WriteString(Left(Me.NewRx.Patient.Name.FirstName.Trim, 35))
                        xmlw.WriteEndElement()
                        ''' End FirstName simple type
                    End If
                    If Me.NewRx.Patient.Name.MiddleName.Trim <> "" Then
                        ''' MiddleName simple type
                        xmlw.WriteStartElement("MiddleName")
                        xmlw.WriteString(Left(Me.NewRx.Patient.Name.MiddleName.Trim, 35))
                        xmlw.WriteEndElement()
                        ''' End MidleName simple type
                    End If
                    xmlw.WriteEndElement()
                    ''' End Name complex type
                End If

                ''' Gender simple type
                xmlw.WriteStartElement("Gender")
                xmlw.WriteString(IIf(Me.NewRx.Patient.Gender = 1, "M", "F"))
                xmlw.WriteEndElement()
                ''' End Gender simple type

                If Me.NewRx.Patient.DateOfBirth.Date.Trim <> "" Then
                    ''' DateOfBirth simple type
                    xmlw.WriteStartElement("DateOfBirth")
                    xmlw.WriteString(Me.NewRx.Patient.DateOfBirth.Date.Trim)
                    xmlw.WriteEndElement()
                    ''' End DateOfBirth simple type
                End If
                ''' Address complex type

                If Me.NewRx.Patient.Address.AddressLine1.Trim <> "" Or Me.NewRx.Patient.Address.AddressLine2.Trim <> "" Or Me.NewRx.Patient.Address.City.Trim <> "" Or Me.NewRx.Patient.Address.State.Trim <> "" Or Me.NewRx.Patient.Address.ZipCode.Trim <> "" Then
                    xmlw.WriteStartElement("Address")
                    If Me.NewRx.Patient.Address.AddressLine1.Trim <> "" Then
                        ''' AddressLine1 simple type
                        xmlw.WriteStartElement("AddressLine1")
                        xmlw.WriteString(Left(Me.NewRx.Patient.Address.AddressLine1.Trim, 35))
                        xmlw.WriteEndElement()
                        ''' End AddressLine1 simple type
                    End If
                    If Me.NewRx.Patient.Address.AddressLine2.Trim <> "" Then
                        ''' AddressLine2 simple type
                        xmlw.WriteStartElement("AddressLine2")
                        xmlw.WriteString(Left(Me.NewRx.Patient.Address.AddressLine2.Trim, 35))
                        xmlw.WriteEndElement()
                        ''' End AddressLine2 simple type
                    End If
                    If Me.NewRx.Patient.Address.City.Trim <> "" Then
                        ''' City simple type
                        xmlw.WriteStartElement("City")
                        xmlw.WriteString(Left(Me.NewRx.Patient.Address.City.Trim, 35))
                        xmlw.WriteEndElement()
                        ''' End City simple type
                    End If
                    If Me.NewRx.Patient.Address.State.Trim <> "" Then
                        ''' State simple type
                        xmlw.WriteStartElement("State")
                        xmlw.WriteString(Me.NewRx.Patient.Address.State.Trim)
                        xmlw.WriteEndElement()
                        ''' End State simple type
                    End If
                    If Me.NewRx.Patient.Address.ZipCode.Trim <> "" Then
                        ''' ZipCode simple type
                        xmlw.WriteStartElement("ZipCode")
                        xmlw.WriteString(Me.NewRx.Patient.Address.ZipCode.Replace("-", ""))
                        xmlw.WriteEndElement()
                        ''' End ZipCode simple type
                    End If
                    xmlw.WriteEndElement()
                    ''' End Address complex type
                End If
                If Me.NewRx.Patient.Email.Trim <> "" Then
                    ''' Email simple type
                    xmlw.WriteStartElement("Email")
                    xmlw.WriteString(Left(Me.NewRx.Patient.Email.Trim, 80))
                    xmlw.WriteEndElement()
                    ''' End Email simple type
                End If
                If Not Me.NewRx.Patient.PhoneNumbers.Phone Is Nothing Then
                    ''' PhoneNumbers complex type
                    xmlw.WriteStartElement("PhoneNumbers")
                    For a = 0 To Me.NewRx.Patient.PhoneNumbers.Phone.Length - 1
                        ''' Phone complex type

                        If Me.NewRx.Patient.PhoneNumbers.Phone(a).Number.Trim <> "" Then
                            xmlw.WriteStartElement("Phone")
                            ''' Number simple type
                            xmlw.WriteStartElement("Number")
                            xmlw.WriteString(Left(Me.NewRx.Patient.PhoneNumbers.Phone(a).Number.Trim, 25))
                            xmlw.WriteEndElement()
                            ''' End Number simple type
                            ''' Qualifier simple type
                            xmlw.WriteStartElement("Qualifier")
                            xmlw.WriteString(Me.NewRx.Patient.PhoneNumbers.Phone(a).Qualifier)
                            xmlw.WriteEndElement()
                            ''' End Qualifier simple type
                            xmlw.WriteEndElement()
                            ''' End Phone complex type
                        End If
                    Next
                    xmlw.WriteEndElement()
                    ''' End PhoneNumbers complex type
                End If
                xmlw.WriteEndElement()
                ''' End Patient complex type
                ''' MediacationPrescribed complex type
                xmlw.WriteStartElement("MedicationPrescribed")
                If Me.NewRx.MedicationPrescribed.DrugDescription.Trim <> "" Then
                    ''' DrugDescription simple type
                    xmlw.WriteStartElement("DrugDescription")
                    xmlw.WriteString(Me.NewRx.MedicationPrescribed.DrugDescription.Trim)
                    xmlw.WriteEndElement()
                    ''' End DrugDescription simple type
                End If


                If Me.NewRx.MedicationPrescribed.Quantity.Value <> "" Then
                    ''' Quantity complex type
                    xmlw.WriteStartElement("Quantity")
                    ''' Qualifier simple type
                    xmlw.WriteStartElement("Qualifier")
                    xmlw.WriteString(Me.NewRx.MedicationPrescribed.Quantity.Qualifier)
                    xmlw.WriteEndElement()
                    ''' End Qualifier simple type
                    ''' Value simple type
                    xmlw.WriteStartElement("Value")
                    xmlw.WriteString(Left(Me.NewRx.MedicationPrescribed.Quantity.Value, 15))
                    xmlw.WriteEndElement()
                    ''' End Vlaue simple type
                    xmlw.WriteEndElement()
                    ''' End Quantity complex type
                End If

                If Me.NewRx.MedicationPrescribed.DaysSupply.Trim <> "" Then
                    ''' DaysSupply simple type
                    xmlw.WriteStartElement("DaysSupply")
                    xmlw.WriteString(Left(Me.NewRx.MedicationPrescribed.DaysSupply.Trim, 3))
                    xmlw.WriteEndElement()
                    ''' End DaysSupply simple type
                End If
                If Me.NewRx.MedicationPrescribed.Directions.Trim <> "" Then
                    ''' Directions simple type
                    xmlw.WriteStartElement("Directions")
                    xmlw.WriteString(Left(Me.NewRx.MedicationPrescribed.Directions.Trim, 140))
                    xmlw.WriteEndElement()
                    ''' End Directions simple type
                End If
                If Me.NewRx.MedicationPrescribed.Note.Trim <> "" Then
                    ''' Note simple type
                    xmlw.WriteStartElement("Note")
                    xmlw.WriteString(Left(Me.NewRx.MedicationPrescribed.Note.Trim, 210))
                    xmlw.WriteEndElement()
                    ''' End Note simple type
                End If
                If Me.NewRx.MedicationPrescribed.Refills.Qualifier.Trim <> "" Then
                    ''' Refills complex type
                    xmlw.WriteStartElement("Refills")
                    ''' Qualifier simple type
                    xmlw.WriteStartElement("Qualifier")
                    xmlw.WriteString(Me.NewRx.MedicationPrescribed.Refills.Qualifier.Trim)
                    xmlw.WriteEndElement()
                    ''' End Qualifier simple type
                    ''' Quantity simple type
                    If Me.NewRx.MedicationPrescribed.Refills.Qualifier.Trim() <> "PRN" Then
                        xmlw.WriteStartElement("Quantity")
                        xmlw.WriteString(Left(Me.NewRx.MedicationPrescribed.Refills.Quantity.Trim, 3))
                        xmlw.WriteEndElement()
                        ''' End Quantity simple type
                    End If

                    xmlw.WriteEndElement()
                    ''' End Refills complex type
                End If
                If Me.NewRx.MedicationPrescribed.Substitutions.Trim <> "" Then
                    ''' Substitutions simple type
                    xmlw.WriteStartElement("Substitutions")
                    xmlw.WriteString(Me.NewRx.MedicationPrescribed.Substitutions.Trim)
                    xmlw.WriteEndElement()
                    ''' End Substitutions simple type
                End If
                If Me.NewRx.MedicationPrescribed.WrittenDate.Date.Trim <> "" Then
                    ''' WrittenDate simple type
                    xmlw.WriteStartElement("WrittenDate")
                    xmlw.WriteString(Me.NewRx.MedicationPrescribed.WrittenDate.Date.Trim)
                    xmlw.WriteEndElement()
                    ''' End WrittenDate simple type
                End If
                xmlw.WriteEndElement()
                ''' End MedicationPrescribed complex type
                xmlw.WriteEndElement()
                ''' End NewRx complex type
                xmlw.WriteEndElement()
                ''' End Body complex type
                xmlw.WriteEndElement()
                ''' End Message complex type
                xmlw.WriteEndDocument()

                Return True

            Catch ex As Exception
                Dim a As String
                a = ex.Message
                Return False
            Finally
                If Not xmlw Is Nothing Then
                    xmlw.Flush()
                    xmlw.Close()
                End If
            End Try

        End Function



        Public Function AddMessage(ByVal filename As String, ByVal lMsgId As String, ByVal lRxId As String, ByVal lClinicConnectionString As String) As Boolean

            Dim flg As Boolean = False
            Dim lConnection As New Connection()



            Dim lQuery As String

            Dim id As Integer = 0
            Dim lPharmacyCode As String = ""
            Dim lIsFailure As Boolean
            Dim lResult As Boolean
            Dim lCode As Long
            Dim lIsExist As Boolean


            Try

                If lMsgId <> "" Then
                    lIsExist = True
                    Me.Header.MesssageID = lMsgId
                Else

                    lIsExist = False
                End If


                lConnection.BeginTrans_ReadCommitted()

                lCode = GetNewCode(lConnection, lMsgId, lRxId)
                'lCode = GetMessageID(lConnection, lMsgId, lRxId)
                If lCode = 0 Then
                    Throw New Exception(" Error in GetMessageID : SurescriptsLibrary\NewPrescription.AddMessage(ByVal filename As String, ByVal lMsgId As String, ByVal lRxId As String, ByVal lClinicConnectionString As String) ")
                End If

                If Me.Header.MesssageID <> "" Then
                    lMsgId = Me.Header.MesssageID
                End If


                'Me.Header.MesssageID = lMsgId
                Me.NewRx.PrescriberOrderNumber = "RxCure-PO-" & lRxId.PadLeft(9, "0")



                If lIsExist Then
                    lResult = AddMessageDtl(lConnection, "O", lCode)
                    If Not lResult Then
                        Throw New Exception(" Error in AddMessageDtl : SurescriptsLibrary\NewPrescription.AddMessage(ByVal filename As String, ByVal lMsgId As String, ByVal lRxId As String, ByVal lClinicConnectionString As String) ")
                    End If
                Else

                    lResult = AddMessageHdr(lConnection, "O", lCode, filename)
                    If Not lResult Then
                        Throw New Exception(" Error in AddMessageHdr  : SurescriptsLibrary\NewPrescription.AddMessage(ByVal filename As String, ByVal lMsgId As String, ByVal lRxId As String, ByVal lClinicConnectionString As String) ")
                    End If
                    lResult = AddMessageDtl(lConnection, "O", lCode)

                    If Not lResult Then
                        Throw New Exception(" Error in AddMessageDtl  : SurescriptsLibrary\NewPrescription.AddMessage(ByVal filename As String, ByVal lMsgId As String, ByVal lRxId As String, ByVal lClinicConnectionString As String) ")
                    End If
                    'lResult = UpdatePatCurrent(lClinicConnectionString, lMsgId, lRxId)
                    'If Not lResult Then
                    '    Throw New Exception(" Error in UpdatePatCurrent : SurescriptsLibrary\NewPrescription.AddMessage(ByVal filename As String, ByVal lMsgId As String, ByVal lRxId As String, ByVal lClinicConnectionString As String) ")
                    'End If

                End If

                lConnection.CommitTrans()
                flg = True
            Catch ex As Exception
                lConnection.RollBackTrans()
                Throw New Exception(" SurescriptsLibrary\NewPrescription.AddMessage(ByVal filename As String, ByVal lMsgId As String, ByVal lRxId As String, ByVal lClinicConnectionString As String) ")

                flg = False
            End Try
            Return flg
        End Function

        Private Function UpdatePatCurrent(ByVal lClinicConnectionString As String, ByVal lMessageId As String, ByVal lRxId As String) As Boolean

            Dim lConnection As New Connection(lClinicConnectionString)
            'Dim lConnection As New SqlConnection(lClinicConnectionString)
            'Dim lCommand As New SqlCommand
            Dim lQuery As String

            Try
                lQuery = "Update RxList " _
                       & "Set MessageId ='" & lMessageId & "', " _
                       & "SendCount = SendCount + 1 " _
                       & "Where RxId =" & Val(Right(lRxId, 9)) & " "


                If lConnection.IsTransactionAlive Then
                    lConnection.ExecuteTransactionCommand(lQuery)
                Else
                    lConnection.ExecuteCommand(lQuery)
                End If

                UpdatePatCurrent = True
            Catch ex As Exception
                TraceLogging.ErrorLogMethods.LogError(ex, "SurescriptsLibrary\NewPrescription.UpdatePatCurrent(ByVal lClinicConnectionString As String, ByVal lMessageId As String, ByVal lRxId As String) ")
                UpdatePatCurrent = False
            End Try

        End Function

        Private Function UpdateRenewalRequestStatus(ByVal lRxId As String, ByVal lSPI As String, ByVal lStatus As String, ByVal lConnectionString As String) As Boolean
            'Dim lConnectionMaster As ConnectionMaster = New ConnectionMaster
            Dim lConnectionMaster As New ConnectionMaster
            Dim lConnection As Connection
            'Dim lCommand As New SqlCommand
            Dim lQuery As String
            Dim lResult As Boolean

            Try
                lResult = lConnectionMaster.Get_ConnectionInformation_By_SPI(lSPI)
                If lResult = False Or lConnectionMaster.ConnectionString = "" Then
                    Throw New Exception
                End If

                'lConnectionMaster.Get_ConnectionInformation_By_SPI(lSPI)
                'If lConnectionMaster.ConnectionString = "" Then
                '    Throw New Exception
                'End If
                lConnection = New Connection(lConnectionMaster.ConnectionString)
                'lConnection = New Connection(lConnectionString)

                lQuery = "Update RenewalRequest " _
                        & "Set NewPrescriptionStatus = '" & lStatus & "' " _
                        & "Where RenewalRequestID = (Select Distinct RenewalRequestID " _
                        & "                         From RxList " _
                        & "                         Where RxId = " & lRxId & " " _
                        & "                         And RenewalRequestID <> 0) "



                If lConnection.IsTransactionAlive Then
                    lConnection.ExecuteTransactionCommand(lQuery)
                Else
                    lConnection.ExecuteCommand(lQuery)
                End If

                UpdateRenewalRequestStatus = True
            Catch ex As Exception
                TraceLogging.ErrorLogMethods.LogError(ex, "SurescriptsLibrary\NewPrescription.UpdateRenewalRequestStatus(ByVal lRxId As String, ByVal lSPI As String, ByVal lStatus As String, ByVal lConnectionString As String) ")
                UpdateRenewalRequestStatus = False
            End Try

        End Function

        Public Shared Function UpdateMessageID(ByVal lOldMsgId As String, ByVal lNewMsgId As String, ByVal lSPI As String) As Boolean

            Dim lConnectionMaster As New ConnectionMaster
            Dim lConnection As Connection
            Dim lCommand As New SqlCommand
            Dim lQuery As String

            Try

                lConnectionMaster.Get_ConnectionInformation_By_SPI(lSPI)
                If lConnectionMaster.ConnectionString = "" Then
                    Throw New Exception
                End If
                lConnection = New Connection(lConnectionMaster.ConnectionString)


                lQuery = "Update RxList " _
                        & "Set MessageId ='" & lNewMsgId & "' " _
                        & "Where MessageId ='" & lOldMsgId & "' "


                lConnection.ExecuteCommand(lQuery)
                UpdateMessageID = True
            Catch ex As Exception
                TraceLogging.ErrorLogMethods.LogError(ex, "SurescriptsLibrary\NewPrescription.UpdateMessageID(ByVal lOldMsgId As String, ByVal lNewMsgId As String, ByVal lSPI As String) ")
                UpdateMessageID = False
            End Try

        End Function

        Public Function AddMessageHdr(ByRef lConnection As Connection, _
                                      ByVal lDirection As String, _
                                      ByVal lCode As Long, _
                                      ByVal lFileName As String) As Boolean

            Dim lStatus As Boolean
            Dim lQuery As String

            Try
                lQuery = "Insert Into MessageHdr (" _
                   & "MessageCode, MessageId, MessageTypeId, LastStatus," _
                   & "XMLPath, ClinicId, UserId, " _
                   & "PrescriberOrderNo, RxReferenceNo, " _
                   & "RelatesToMessageId, Direction, XMLContents, PharmacyCode) " _
                   & "VALUES(" _
                   & lCode & ", " _
                   & "'" & Me.Header.MesssageID & "', " _
                   & "4," _
                   & "'Pending'," _
                   & "'" & lFileName & "'," _
                   & "'" & Me.LocalDB.ClinicCode & "'," _
                   & "'" & Me.NewRx.Prescriber.Identification.SPI & "'," _
                   & "'" & Me.NewRx.PrescriberOrderNumber & "'," _
                   & "'" & Me.NewRx.RxReferenceNumber & "'," _
                   & "''," _
                   & "'" & lDirection & "', " _
                   & "'', " _
                   & "'" & Me.NewRx.Pharmacy.Identification.NCPDPID & "')"

                If lConnection.IsTransactionAlive Then
                    lConnection.ExecuteTransactionCommand(lQuery)
                Else
                    lConnection.ExecuteCommand(lQuery)
                End If

            Catch ex As Exception
                Throw New Exception(ex.Message & " SurescriptsLibrary\NewPrescription.AddMessageHdr(ByRef lConnection As Connection,ByVal lDirection As String,ByVal lCode As Long,ByVal lFileName As String ) ")
            End Try


            AddMessageHdr = True

        End Function


        Public Function AddMessageDtl(ByRef lConnection As Connection, _
                                      ByVal lDirection As String, _
                                      ByVal lCode As Long) As Boolean

            Dim lStatus As Boolean
            Dim lQuery As String

            Try
                lQuery = "INSERT INTO MessageDtl(MessageCode, MessageTime, " _
                   & "Status, Code, DescriptionCode, " _
                   & "[Description],Direction,ReceivedMessageId, DetailMessageType) " _
                   & "VALUES(" _
                   & " " & lCode & ", " _
                   & "'" & Left(Me.Header.SentTime.UtcDate, 19) & "', " _
                   & "'Pending'," _
                   & "''," _
                   & "''," _
                   & "''," _
                   & "'O'," _
                   & "'',4)"

                If lConnection.IsTransactionAlive Then
                    lConnection.ExecuteTransactionCommand(lQuery)
                Else
                    lConnection.ExecuteCommand(lQuery)
                End If

            Catch ex As Exception
                Throw New Exception(ex.Message & " SurescriptsLibrary\NewPrescription.AddMessageDtl(ByRef lConnection As Connection,ByVal lDirection As String,ByVal lCode As Long) ")
            End Try


            AddMessageDtl = True

        End Function


        Private Function CheckDuplicateMessage(ByRef lConnection As Connection, _
                                               ByVal lMessageId As String, _
                                               ByVal lPharmacyCode As String, _
                                               ByVal lDirection As String, _
                                               ByRef lIsFailure As Boolean, _
                                               ByRef lCode As Long) As Boolean

            Dim lDs As DataSet
            Dim lStatus As Boolean
            Dim lQuery As String
            Dim lCond As String


            Try
                If lDirection = "O" Then
                    lCond = "And Direction = 'O'"
                Else
                    lCond = "And Direction = 'I'"
                End If

                lQuery = "Select * From MessageHdr " _
                       & "Where MessageId ='" & lMessageId & "' " _
                       & "And PharmacyCode ='" & Me.NewRx.Pharmacy.Identification.NCPDPID & "' " _
                       & lCond


                If lConnection.IsTransactionAlive Then
                    lDs = lConnection.ExecuteTransactionQuery(lQuery)
                Else
                    lDs = lConnection.ExecuteQuery(lQuery)
                End If

                'lDs = DBClass.ExecuteQuery(lQuery, lTransaction)
                If lDs.Tables(0).Rows.Count > 0 Then
                    If CType(lDs.Tables(0).Rows(0)("LastStatus"), String) = "Success" Then
                        lCode = CType(lDs.Tables(0).Rows(0)("MessageCode"), Long)
                        CheckDuplicateMessage = True
                        lIsFailure = False
                    ElseIf CType(lDs.Tables(0).Rows(0)("LastStatus"), String) = "Failure" Then
                        lCode = CType(lDs.Tables(0).Rows(0)("MessageCode"), Long)
                        CheckDuplicateMessage = False
                        lIsFailure = True
                    End If
                Else
                    CheckDuplicateMessage = False
                    lIsFailure = False
                End If

            Catch ex As Exception
                Throw New Exception(" SurescriptsLibrary\NewPrescription.CheckDuplicateMessage(ByRef lConnection As Connection,ByVal lMessageId As String,ByVal lPharmacyCode As String,ByVal lDirection As String,ByRef lIsFailure As Boolean,ByRef lCode As Long) ")
            End Try


        End Function


        Public Function GetNewCode(ByRef lConnection As Connection, ByRef lMsgId As String, ByVal lRxId As String) As String

            Dim lDs As DataSet
            Dim lMessageCode As String = ""
            Dim lMessageNo As Integer = 0
            Dim lStatus As Boolean
            Dim lQuery As String


            Try
                lRxId = "RxCure-PO-" & lRxId.PadLeft(9, "0")

                If lMsgId <> "" Then

                    lQuery = "Select * From MessageHdr Where MessageId ='" & lMsgId & "' " _
                           & "And PrescriberOrderNo ='" & lRxId & "' " _
                           & "And Direction = 'O' "

                    If lConnection.IsTransactionAlive Then
                        lDs = lConnection.ExecuteTransactionQuery(lQuery)
                    Else
                        lDs = lConnection.ExecuteQuery(lQuery)
                    End If

                    If lDs.Tables.Count > 0 Then
                        If lDs.Tables(0).Rows.Count > 0 Then
                            lMessageCode = lDs.Tables(0).Rows(0).Item("MessageCode")
                        End If
                    End If

                Else

                    lQuery = "Select IsNull(Max(MessageCode),0) + 1  AS MessageCode From MessageHdr "

                    If lConnection.IsTransactionAlive Then
                        lDs = lConnection.ExecuteTransactionQuery(lQuery)
                    Else
                        lDs = lConnection.ExecuteQuery(lQuery)
                    End If


                    If lDs.Tables.Count > 0 Then
                        lMessageCode = CType(lDs.Tables(0).Rows(0)("MessageCode"), String)
                    End If
                End If

                GetNewCode = lMessageCode

            Catch ex As Exception
                Throw New Exception(" SurescriptsLibrary\NewPrescription.GetMessageID(ByRef lConnection As Connection, ByRef lMsgId As String, ByVal lRxId As String) ")
            End Try

        End Function


        Public Function GetMessageID(ByRef lConnection As Connection, ByRef lMsgId As String, ByVal lRxId As String) As String

            Dim lDs As DataSet
            Dim lMessageCode As String = ""
            Dim lMessageNo As Integer = 0
            Dim lStatus As Boolean
            Dim lQuery As String


            Try
                lRxId = "RxCure-PO-" & lRxId.PadLeft(9, "0")

                If lMsgId <> "" Then

                    lQuery = "Select * From MessageHdr Where MessageId ='" & lMsgId & "' " _
                           & "And PrescriberOrderNo ='" & lRxId & "' " _
                           & "And Direction = 'O' "

                    If lConnection.IsTransactionAlive Then
                        lDs = lConnection.ExecuteTransactionQuery(lQuery)
                    Else
                        lDs = lConnection.ExecuteQuery(lQuery)
                    End If

                    If lDs.Tables.Count > 0 Then
                        If lDs.Tables(0).Rows.Count > 0 Then
                            lMessageCode = lDs.Tables(0).Rows(0).Item("MessageCode")
                        End If
                    End If

                Else

                    lQuery = "Select MessageIdNumeric+1 As MsgId, Prefix from NumSeries "

                    If lConnection.IsTransactionAlive Then
                        lDs = lConnection.ExecuteTransactionQuery(lQuery)
                    Else
                        lDs = lConnection.ExecuteQuery(lQuery)
                    End If


                    If lDs.Tables.Count > 0 Then
                        lMsgId = CType(lDs.Tables(0).Rows(0)("Prefix"), String) & "-" _
                               & CType(lDs.Tables(0).Rows(0)("MsgId"), String).PadLeft(10, "0")

                        lMessageNo = lDs.Tables(0).Rows(0)("MsgId")
                    End If

                    lQuery = "Update NumSeries Set CurrentMessageId ='" & lMsgId & "', " _
                           & "MessageIdNumeric = " & lMessageNo & " "

                    If lConnection.IsTransactionAlive Then
                        lConnection.ExecuteTransactionCommand(lQuery)
                    Else
                        lConnection.ExecuteCommand(lQuery)
                    End If


                    lQuery = "Select IsNull(Max(MessageCode),0) + 1  AS MessageCode From MessageHdr "
                    If lConnection.IsTransactionAlive Then
                        lDs = lConnection.ExecuteTransactionQuery(lQuery)
                    Else
                        lDs = lConnection.ExecuteQuery(lQuery)
                    End If


                    If lDs.Tables.Count > 0 Then
                        lMessageCode = CType(lDs.Tables(0).Rows(0)("MessageCode"), String)
                    End If

                End If

                GetMessageID = lMessageCode

            Catch ex As Exception
                Throw New Exception(" SurescriptsLibrary\NewPrescription.GetMessageID(ByRef lConnection As Connection, ByRef lMsgId As String, ByVal lRxId As String) ")
            End Try

        End Function


        Public Function FormatMessageID(ByVal messageid As String) As String
            Dim str As String
            str = "rxcure-" & messageid.ToString.PadLeft(9, "0")
            Return str
        End Function
#End Region

    End Class
    Public Class LocalDBType
        Private mDoctorCode As String = ""
        Private mPatientCode As String = ""
        Private mClinicCode As String = ""
        Private mDrugCode As String = "'"

        Public Property DoctorCode() As String
            Get
                Return mDoctorCode
            End Get
            Set(ByVal Value As String)
                mDoctorCode = Value
            End Set
        End Property
        Public Property PatientCode() As String
            Get
                Return mPatientCode
            End Get
            Set(ByVal Value As String)
                mPatientCode = Value
            End Set
        End Property
        Public Property ClinicCode() As String
            Get
                Return mClinicCode
            End Get
            Set(ByVal Value As String)
                mClinicCode = Value
            End Set
        End Property
        Public Property DrugCode() As String
            Get
                Return mDrugCode
            End Get
            Set(ByVal Value As String)
                mDrugCode = Value
            End Set
        End Property

        
    End Class
End Namespace

