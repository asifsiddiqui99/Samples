Namespace SureScripts

    Public Class SCRIPTDataType

    End Class

    Public Class DateType
        Private mDate As String '= Date.Now

        Public Property [Date]() As String
            Get
                If Not mDate Is Nothing Then
                    Return CType(mDate, Date).ToString("yyyyMMdd")
                Else
                    Return ""
                End If
            End Get
            Set(ByVal Value As String)
                mDate = Value
            End Set
        End Property
    End Class

    Public Class UtcDateType
        Private mUtcDate As String = Date.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fZ")

        Public Property UtcDate() As String
            Get
                Return mUtcDate
            End Get
            Set(ByVal Value As String)
                mUtcDate = Value 'CType(Value, Date).ToString("yyyy-MM-ddThh:mm:ss.fZ")
            End Set
        End Property

        'Public Property UtcDate() As String
        '    Get
        '        Return CType(mUtcDate, Date).ToUniversalTime.ToString("yyyy-MM-ddThh:mm:ss.fZ")
        '    End Get
        '    Set(ByVal Value As String)
        '        mUtcDate = CType(Value, Date).ToUniversalTime.ToString("yyyy-MM-ddThh:mm:ss.fZ")
        '    End Set
        'End Property
    End Class
End Namespace
