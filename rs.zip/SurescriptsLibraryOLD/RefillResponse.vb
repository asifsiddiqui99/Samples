Imports System.Xml
Imports System.Data.SqlClient
Imports System.Configuration
Imports ElixirLibrary
Imports System.web
Imports Microsoft.VisualBasic
Namespace SureScripts
    Public Class RefillResponse
#Region "Instance Variables"
        Private mHeader As New HeaderType
        Private mRefillResponse As New RefillResponseType
        Private mConnectionString As String
        Private mLocaldb As LocalDBType = New LocalDBType
#End Region


#Region "Properties"
        Public Property Header() As HeaderType
            Get
                Return mHeader
            End Get
            Set(ByVal Value As HeaderType)
                mHeader = Value
            End Set
        End Property
        Public Property RefillResponse() As RefillResponseType
            Get
                Return mRefillResponse
            End Get
            Set(ByVal Value As RefillResponseType)
                mRefillResponse = Value
            End Set
        End Property
        Public Property ConnectionString() As String
            Get
                Return mConnectionString
            End Get
            Set(ByVal Value As String)
                mConnectionString = Value
            End Set
        End Property
        Public Property LocalDB() As LocalDBType
            Get
                Return mLocaldb
            End Get
            Set(ByVal Value As LocalDBType)
                mLocaldb = Value
            End Set
        End Property
#End Region


#Region "Methods"
        Public Function WriteXMLForRefillResponse(ByVal path As String, ByVal filename As String, ByVal lConnectionString As String)
            Dim xmlw As XmlTextWriter
            Dim lResult As Boolean
            Try

                ', lMessageId, lRxId, constr
                lResult = AddMessage(filename, "", "", lConnectionString)
                If lResult = False Then
                    Throw New Exception
                End If
                xmlw = New XmlTextWriter(path + filename, Nothing)
                xmlw.Formatting = Formatting.Indented
                'xmlw.WriteStartDocument()
                xmlw.WriteStartElement("Message")
                xmlw.WriteAttributeString("version", "1.0")
                xmlw.WriteAttributeString("xmlns", "http://www.surescripts.com/messaging")


                '' Header complex type element
                xmlw.WriteStartElement("Header")

                xmlw.WriteStartElement("To")
                xmlw.WriteString(Me.Header.To.MailAddress)
                xmlw.WriteEndElement()

                xmlw.WriteStartElement("From")
                xmlw.WriteString(Me.Header.From.MailAddress)
                xmlw.WriteEndElement()

                xmlw.WriteStartElement("MessageID")
                xmlw.WriteString(Me.Header.MesssageID)
                xmlw.WriteEndElement()

                xmlw.WriteStartElement("RelatesToMessageID")
                xmlw.WriteString(Me.Header.RelatesToMessageID)
                xmlw.WriteEndElement()

                xmlw.WriteStartElement("SentTime")
                xmlw.WriteString(Me.Header.SentTime.UtcDate)
                xmlw.WriteEndElement()

                'xmlw.WriteStartElement("TestMessage")
                'xmlw.WriteString("")
                'xmlw.WriteEndElement()


                xmlw.WriteEndElement()
                '' End Header Complex type




                '' Body complex type
                xmlw.WriteStartElement("Body")
                '' RefillResponse complex type
                xmlw.WriteStartElement("RefillResponse")

                If Me.RefillResponse.RxReferenceNumber.Trim <> "" Then
                    '' RxReferenceNumber Simple type
                    xmlw.WriteStartElement("RxReferenceNumber")
                    xmlw.WriteString(Me.RefillResponse.RxReferenceNumber.Trim)
                    xmlw.WriteEndElement()
                    '' End RxReferenceNumber Simple type
                End If

                If Me.RefillResponse.PrescribedOrderNumber.Trim <> "" Then
                    '' PrescribedOrderNumber Simple type
                    xmlw.WriteStartElement("PrescribedOrderNumber")
                    xmlw.WriteString(Me.RefillResponse.PrescribedOrderNumber.Trim)
                    xmlw.WriteEndElement()
                    '' End PrescribedOrderNumber Simple type
                End If

                '' Response complex type
                xmlw.WriteStartElement("Response")
                '' Approved complex type
                If Me.RefillResponse.Response.ApprovedWithChanges.Note.Trim <> "" Then
                    xmlw.WriteStartElement("ApprovedWithChanges")

                    If Me.RefillResponse.Response.ApprovedWithChanges.Note = "~AKP751T~4033~" Then
                        Me.RefillResponse.Response.ApprovedWithChanges.Note = ""
                    End If
                    '' Refills complex type
                    ''xmlw.WriteStartElement("Refills")
                    '' Qualifier simple type
                    ''xmlw.WriteStartElement("Qualifier")
                    ''xmlw.WriteString(Me.RefillResponse.Response.ApprovedWithChanges.Refills.Qualifier)
                    ''xmlw.WriteEndElement()
                    ' End Qualifier type
                    ' Quantity simple type
                    'xmlw.WriteStartElement("Quantity")
                    'xmlw.WriteString(Me.RefillResponse.Response.ApprovedWithChanges.Refills.Quantity)
                    'xmlw.WriteEndElement()
                    ' End Quantity type
                    If Me.RefillResponse.Response.ApprovedWithChanges.Note.Trim <> "" Then
                        xmlw.WriteStartElement("Note")
                        xmlw.WriteString(Me.RefillResponse.Response.ApprovedWithChanges.Note.Trim)
                        xmlw.WriteEndElement()
                    End If
                    ' End Note Type
                    'xmlw.WriteEndElement()
                    ' End Refills complex type
                    xmlw.WriteEndElement()
                    ' End Approved complex type
                ElseIf Me.RefillResponse.Response.DeniedNewPrescriptionToFollow.Note.Trim <> "" Then
                    ' Start DeniedNewPrescriptionToFollow complex type
                    xmlw.WriteStartElement("DeniedNewPrescriptionToFollow")
                    ' Start Note type
                    'xmlw.WriteStartElement("Note")
                    'xmlw.WriteString(Me.RefillResponse.Response.DeniedNewPrescriptionToFollow.Note)
                    'xmlw.WriteEndElement()
                    '' End Note type
                    xmlw.WriteEndElement()
                    '' End DeniedNewPrescriptionToFollow complex type
                ElseIf Me.RefillResponse.Response.Denied.DenielReason.Trim <> "" Then
                    xmlw.WriteStartElement("Denied")
                    '' Start Denied  type
                    ''xmlw.WriteStartElement("DenialReasonCode")
                    ''xmlw.WriteString(Me.RefillResponse.Response.Denied.DenailReasonCode)
                    ''xmlw.WriteEndElement()
                    '' End Denied complex type

                    '' Start DenialReason type
                    xmlw.WriteStartElement("DenialReason")
                    xmlw.WriteString(Me.RefillResponse.Response.Denied.DenielReason.Trim)
                    xmlw.WriteEndElement()
                    '' End DenialReason type
                    xmlw.WriteEndElement()

                Else
                    '' Start Approved complex type
                    xmlw.WriteStartElement("Approved")
                    '' Start Note type

                    If Me.RefillResponse.Response.Approved.Note = "~AKP751T~4033~" Then
                        Me.RefillResponse.Response.Approved.Note = ""
                    End If

                    If Me.RefillResponse.Response.Approved.Note.Trim <> "" Then
                        xmlw.WriteStartElement("Note")
                        xmlw.WriteString(Me.RefillResponse.Response.Approved.Note.Trim)
                        xmlw.WriteEndElement()
                        '' End Note type
                    End If
                    xmlw.WriteEndElement()
                    '' End Approved complex type
                End If
                'If Me.RefillResponse.Response.Approved.Refills.Quantity <> "" And Me.RefillResponse.Response.Approved.Refills.Quantity <> "0" Then

                '    xmlw.WriteStartElement("Approved")
                '    ' Refills complex type
                '    xmlw.WriteStartElement("Refills")
                '    ' Qualifier simple type
                '    xmlw.WriteStartElement("Qualifier")
                '    xmlw.WriteString(Me.RefillResponse.Response.Approved.Refills.Qualifier)
                '    xmlw.WriteEndElement()
                '    ''' End Qualifier type
                '    ''' Quantity simple type
                '    xmlw.WriteStartElement("Quantity")
                '    xmlw.WriteString(Me.RefillResponse.Response.Approved.Refills.Quantity)
                '    xmlw.WriteEndElement()
                '    ''' End Quantity type
                '    xmlw.WriteStartElement("Note")
                '    xmlw.WriteString(Me.RefillResponse.Response.Approved.Note)
                '    xmlw.WriteEndElement()
                '    ''' End Note Type
                '    xmlw.WriteEndElement()
                '    ''' End Refills complex type
                '    xmlw.WriteEndElement()
                '    ''' End Approved complex type
                'Else
                '    xmlw.WriteStartElement("DenialReasonCode")
                '    xmlw.WriteString(Me.RefillResponse.Response.Denied.DenailReasonCode)
                '    xmlw.WriteEndElement()

                '    xmlw.WriteStartElement("DenialReason")
                '    xmlw.WriteString(Me.RefillResponse.Response.Denied.DenielReason)
                '    xmlw.WriteEndElement()
                'End If
                xmlw.WriteEndElement()
                '' End Response complex type
                '' Pharmacy complex type
                xmlw.WriteStartElement("Pharmacy")
                '' Identification complex type
                xmlw.WriteStartElement("Identification")
                '' NCPDPID simple type
                xmlw.WriteStartElement("NCPDPID")
                xmlw.WriteString(Me.RefillResponse.Pharmacy.Identification.NCPDPID.Trim)
                xmlw.WriteEndElement()
                '' End NCPDPID simple type
                ''''''''''''''''''''''
                If Me.RefillResponse.Pharmacy.Identification.FileID.Trim <> "" Then
                    xmlw.WriteStartElement("FileID")
                    xmlw.WriteString(Me.RefillResponse.Pharmacy.Identification.FileID.Trim)
                    xmlw.WriteEndElement()
                End If
                If Me.RefillResponse.Pharmacy.Identification.StateLicenseNumber.Trim <> "" Then
                    xmlw.WriteStartElement("StateLicenseNumber")
                    xmlw.WriteString(Me.RefillResponse.Pharmacy.Identification.StateLicenseNumber.Trim)
                    xmlw.WriteEndElement()
                End If

                If Me.RefillResponse.Pharmacy.Identification.MedicareNumber.Trim <> "" Then
                    xmlw.WriteStartElement("MedicareNumber")
                    xmlw.WriteString(Me.RefillResponse.Pharmacy.Identification.MedicareNumber.Trim)
                    xmlw.WriteEndElement()
                End If

                If Me.RefillResponse.Pharmacy.Identification.MediCaidNumber.Trim <> "" Then
                    xmlw.WriteStartElement("MedicaidNumber")
                    xmlw.WriteString(Me.RefillResponse.Pharmacy.Identification.MediCaidNumber.Trim)
                    xmlw.WriteEndElement()
                End If

                If Me.RefillResponse.Pharmacy.Identification.PPONumber.Trim <> "" Then
                    xmlw.WriteStartElement("PPONumber")
                    xmlw.WriteString(Me.RefillResponse.Pharmacy.Identification.PPONumber.Trim)
                    xmlw.WriteEndElement()
                End If

                If Me.RefillResponse.Pharmacy.Identification.PayerId.Trim <> "" Then
                    xmlw.WriteStartElement("PayerID")
                    xmlw.WriteString(Me.RefillResponse.Pharmacy.Identification.PayerId.Trim)
                    xmlw.WriteEndElement()
                End If

                If Me.RefillResponse.Pharmacy.Identification.BINLocationNumber.Trim <> "" Then
                    xmlw.WriteStartElement("BINLocationNumber")
                    xmlw.WriteString(Me.RefillResponse.Pharmacy.Identification.BINLocationNumber.Trim)
                    xmlw.WriteEndElement()
                End If

                If Me.RefillResponse.Pharmacy.Identification.DEANumber.Trim <> "" Then
                    xmlw.WriteStartElement("DEANumber")
                    xmlw.WriteString(Me.RefillResponse.Pharmacy.Identification.DEANumber.Trim)
                    xmlw.WriteEndElement()
                End If

                If Me.RefillResponse.Pharmacy.Identification.HIN.Trim <> "" Then
                    xmlw.WriteStartElement("HIN")
                    xmlw.WriteString(Me.RefillResponse.Pharmacy.Identification.HIN.Trim)
                    xmlw.WriteEndElement()
                End If

                If Me.RefillResponse.Pharmacy.Identification.SecondaryCoverage.Trim <> "" Then
                    xmlw.WriteStartElement("SecondaryCoverage")
                    xmlw.WriteString(Me.RefillResponse.Pharmacy.Identification.SecondaryCoverage.Trim)
                    xmlw.WriteEndElement()
                End If

                If Me.RefillResponse.Pharmacy.Identification.NAICode.Trim <> "" Then
                    xmlw.WriteStartElement("NAICCode")
                    xmlw.WriteString(Me.RefillResponse.Pharmacy.Identification.NAICode.Trim)
                    xmlw.WriteEndElement()
                End If

                If Me.RefillResponse.Pharmacy.Identification.PromotionNumber.Trim <> "" Then
                    xmlw.WriteStartElement("PromotionNumber")
                    xmlw.WriteString(Me.RefillResponse.Pharmacy.Identification.PromotionNumber.Trim)
                    xmlw.WriteEndElement()
                End If

                If Me.RefillResponse.Pharmacy.Identification.SocialSecurity.Trim <> "" Then
                    xmlw.WriteStartElement("SocialSecurity")
                    xmlw.WriteString(Me.RefillResponse.Pharmacy.Identification.SocialSecurity.Trim)
                    xmlw.WriteEndElement()
                End If

                If Me.RefillResponse.Pharmacy.Identification.NPI.Trim <> "" Then
                    xmlw.WriteStartElement("NPI")
                    xmlw.WriteString(Me.RefillResponse.Pharmacy.Identification.NPI.Trim)
                    xmlw.WriteEndElement()
                End If
                If Me.RefillResponse.Pharmacy.Identification.PriorAuthorization.Trim <> "" Then
                    xmlw.WriteStartElement("PriorAuthorization")
                    xmlw.WriteString(Me.RefillResponse.Pharmacy.Identification.PriorAuthorization.Trim)
                    xmlw.WriteEndElement()
                End If

                ''''''''''''''
                xmlw.WriteEndElement()
                '''' End Identification complex type
                If Me.RefillResponse.Pharmacy.StoreName.Trim <> "" Then
                    '  ''' StoreName simple type
                    xmlw.WriteStartElement("StoreName")
                    xmlw.WriteString(Me.RefillResponse.Pharmacy.StoreName.Trim)
                    xmlw.WriteEndElement()
                    '   ''' End StoreName simple type
                End If

                If Me.RefillResponse.Pharmacy.Pharmacist.LastName.Trim <> "" Or Me.RefillResponse.Pharmacy.Pharmacist.FirstName.Trim <> "" Or Me.RefillResponse.Pharmacy.Pharmacist.MiddleName.Trim <> "" Or Me.RefillResponse.Pharmacy.Pharmacist.Suffix.Trim <> "" Or Me.RefillResponse.Pharmacy.Pharmacist.Prefix.Trim <> "" Then
                    ' ''' Pharmacist complex type
                    xmlw.WriteStartElement("Pharmacist")
                    If Me.RefillResponse.Pharmacy.Pharmacist.LastName.Trim <> "" Then
                        '    ''' LastName simple type
                        xmlw.WriteStartElement("LastName")
                        xmlw.WriteString(Me.RefillResponse.Pharmacy.Pharmacist.LastName.Trim)
                        xmlw.WriteEndElement()
                        '   ''' End LastName simple type
                    End If
                    If Me.RefillResponse.Pharmacy.Pharmacist.FirstName.Trim <> "" Then
                        '  ''' FirstName simple type
                        xmlw.WriteStartElement("FirstName")
                        xmlw.WriteString(Me.RefillResponse.Pharmacy.Pharmacist.FirstName.Trim)
                        xmlw.WriteEndElement()
                        ' ''' End FirstName simple type
                    End If

                    If Me.RefillResponse.Pharmacy.Pharmacist.MiddleName.Trim <> "" Then
                        xmlw.WriteStartElement("MiddleName")
                        xmlw.WriteString(Me.RefillResponse.Pharmacy.Pharmacist.MiddleName.Trim)
                        xmlw.WriteEndElement()
                    End If

                    If Me.RefillResponse.Pharmacy.Pharmacist.Suffix.Trim <> "" Then
                        xmlw.WriteStartElement("Suffix")
                        xmlw.WriteString(Me.RefillResponse.Pharmacy.Pharmacist.Suffix.Trim)
                        xmlw.WriteEndElement()
                    End If

                    If Me.RefillResponse.Pharmacy.Pharmacist.Prefix.Trim <> "" Then
                        xmlw.WriteStartElement("Prefix")
                        xmlw.WriteString(Me.RefillResponse.Pharmacy.Pharmacist.Prefix.Trim)
                        xmlw.WriteEndElement()
                    End If


                    xmlw.WriteEndElement()
                    '''' End Pharmacist complex type
                End If

                If Me.RefillResponse.Pharmacy.PharmacistAgent.LastName.Trim <> "" Or Me.RefillResponse.Pharmacy.PharmacistAgent.FirstName.Trim <> "" Or Me.RefillResponse.Pharmacy.PharmacistAgent.MiddleName.Trim <> "" Or Me.RefillResponse.Pharmacy.PharmacistAgent.Suffix.Trim <> "" Or Me.RefillResponse.Pharmacy.PharmacistAgent.Prefix.Trim <> "" Then
                    '''' PharmacistAgent complex type
                    xmlw.WriteStartElement("PharmacistAgent")

                    If Me.RefillResponse.Pharmacy.PharmacistAgent.LastName.Trim <> "" Then
                        '   ''' LastName simple type
                        xmlw.WriteStartElement("LastName")
                        xmlw.WriteString(Me.RefillResponse.Pharmacy.PharmacistAgent.LastName.Trim)
                        xmlw.WriteEndElement()
                        '  ''' End LastName simple type
                    End If
                    If Me.RefillResponse.Pharmacy.PharmacistAgent.FirstName.Trim <> "" Then
                        ' ''' FirstName simple type
                        xmlw.WriteStartElement("FirstName")
                        xmlw.WriteString(Me.RefillResponse.Pharmacy.PharmacistAgent.FirstName.Trim)
                        xmlw.WriteEndElement()
                        '''' End FirstName simple type
                    End If

                    If Me.RefillResponse.Pharmacy.PharmacistAgent.MiddleName.Trim <> "" Then
                        xmlw.WriteStartElement("MiddleName")
                        xmlw.WriteString(Me.RefillResponse.Pharmacy.PharmacistAgent.MiddleName.Trim)
                        xmlw.WriteEndElement()
                    End If

                    If Me.RefillResponse.Pharmacy.PharmacistAgent.Suffix.Trim <> "" Then
                        xmlw.WriteStartElement("Suffix")
                        xmlw.WriteString(Me.RefillResponse.Pharmacy.PharmacistAgent.Suffix.Trim)
                        xmlw.WriteEndElement()
                    End If

                    If Me.RefillResponse.Pharmacy.PharmacistAgent.Prefix.Trim <> "" Then
                        xmlw.WriteStartElement("Prefix")
                        xmlw.WriteString(Me.RefillResponse.Pharmacy.PharmacistAgent.Prefix.Trim)
                        xmlw.WriteEndElement()
                    End If

                    xmlw.WriteEndElement()
                    '''' End PharmacistAgent complex type
                End If

                If Me.RefillResponse.Pharmacy.Address.AddressLine1.Trim <> "" Or Me.RefillResponse.Pharmacy.Address.AddressLine2.Trim <> "" Or Me.RefillResponse.Pharmacy.Address.City.Trim <> "" Or Me.RefillResponse.Pharmacy.Address.State.Trim <> "" Or Me.RefillResponse.Pharmacy.Address.ZipCode.Trim <> "" Then
                    '''' Address complex type
                    xmlw.WriteStartElement("Address")

                    If Me.RefillResponse.Pharmacy.Address.AddressLine1.Trim <> "" Then
                        '   ''' AddressLine1 simple type
                        xmlw.WriteStartElement("AddressLine1")
                        xmlw.WriteString(Me.RefillResponse.Pharmacy.Address.AddressLine1.Trim)
                        xmlw.WriteEndElement()
                        '  ''' End AddressLine1 simple type
                    End If
                    '''' AddressLine2 simple type
                    If Me.RefillResponse.Pharmacy.Address.AddressLine2.Trim <> "" Then
                        xmlw.WriteStartElement("AddressLine2")
                        xmlw.WriteString(Me.RefillResponse.Pharmacy.Address.AddressLine2.Trim)
                        xmlw.WriteEndElement()
                    End If
                    '''' End AddressLine2 simple type
                    If Me.RefillResponse.Pharmacy.Address.City.Trim <> "" Then
                        '  ''' City simple type
                        xmlw.WriteStartElement("City")
                        xmlw.WriteString(Me.RefillResponse.Pharmacy.Address.City.Trim)
                        xmlw.WriteEndElement()
                        ' ''' End City simple type
                    End If

                    If Me.RefillResponse.Pharmacy.Address.State.Trim <> "" Then
                        '''' State simple type
                        xmlw.WriteStartElement("State")
                        xmlw.WriteString(Me.RefillResponse.Pharmacy.Address.State.Trim)
                        xmlw.WriteEndElement()
                    End If
                    '''' End State simple type
                    If Me.RefillResponse.Pharmacy.Address.ZipCode.Trim <> "" Then
                        '   ''' ZipCode simple type
                        xmlw.WriteStartElement("ZipCode")
                        xmlw.WriteString(Me.RefillResponse.Pharmacy.Address.ZipCode.Replace("-", ""))
                        xmlw.WriteEndElement()
                        '  ''' End ZipCode simple type
                    End If
                    xmlw.WriteEndElement()
                    '''' End Address complex type
                End If

                If Me.RefillResponse.Pharmacy.Email.Trim <> "" Then
                    '''' Email simple type
                    xmlw.WriteStartElement("Email")
                    xmlw.WriteString(Me.RefillResponse.Pharmacy.Email.Trim)
                    xmlw.WriteEndElement()
                    '''' End Email simple type
                End If
                If Not Me.RefillResponse.Pharmacy.PhoneNumbers.Phone Is Nothing Then
                    '''' PhoneNumbers complex type
                    xmlw.WriteStartElement("PhoneNumbers")
                    Dim a As Integer = 0
                    For a = 0 To Me.RefillResponse.Pharmacy.PhoneNumbers.Phone.Length - 1
                        '''' Phone complex type
                        xmlw.WriteStartElement("Phone")
                        '''' Number simple type
                        xmlw.WriteStartElement("Number")
                        xmlw.WriteString(Me.RefillResponse.Pharmacy.PhoneNumbers.Phone(a).Number.Trim)
                        xmlw.WriteEndElement()
                        '''' End Number simple type
                        '''' Qualifier simple type
                        xmlw.WriteStartElement("Qualifier")
                        xmlw.WriteString(Me.RefillResponse.Pharmacy.PhoneNumbers.Phone(a).Qualifier)
                        xmlw.WriteEndElement()
                        '''' End Qualifier simple type
                        xmlw.WriteEndElement()
                        '''' End Phone complex type
                    Next
                    xmlw.WriteEndElement()
                    '''' End PhoneNumbers complex type
                End If
                xmlw.WriteEndElement()
                '''' End Pharmacy complex type
                '''' Prescriber complex type
                xmlw.WriteStartElement("Prescriber")
                '''' Identification complex type
                xmlw.WriteStartElement("Identification")
                '''' SPI simple type
                xmlw.WriteStartElement("SPI")
                xmlw.WriteString(Me.RefillResponse.Prescriber.Identification.SPI)
                xmlw.WriteEndElement()
                '''' End SPI simple type


                ''''''''

                If Me.RefillResponse.Prescriber.Identification.FileID.Trim <> "" Then
                    xmlw.WriteStartElement("FileID")
                    xmlw.WriteString(Me.RefillResponse.Prescriber.Identification.FileID.Trim)
                    xmlw.WriteEndElement()
                End If
                If Me.RefillResponse.Prescriber.Identification.StateLicenseNumber.Trim <> "" Then
                    xmlw.WriteStartElement("StateLicenseNumber")
                    xmlw.WriteString(Me.RefillResponse.Prescriber.Identification.StateLicenseNumber.Trim)
                    xmlw.WriteEndElement()
                End If

                If Me.RefillResponse.Prescriber.Identification.MedicareNumber.Trim <> "" Then
                    xmlw.WriteStartElement("MedicareNumber")
                    xmlw.WriteString(Me.RefillResponse.Prescriber.Identification.MedicareNumber.Trim)
                    xmlw.WriteEndElement()
                End If
                If Me.RefillResponse.Prescriber.Identification.MedicaidNumber.Trim <> "" Then
                    xmlw.WriteStartElement("MedicaidNumber")
                    xmlw.WriteString(Me.RefillResponse.Prescriber.Identification.MedicaidNumber.Trim)
                    xmlw.WriteEndElement()
                End If
                If Me.RefillResponse.Prescriber.Identification.DentisiLicenseNumber.Trim <> "" Then
                    xmlw.WriteStartElement("DentistLicenseNumber")
                    xmlw.WriteString(Me.RefillResponse.Prescriber.Identification.DentisiLicenseNumber.Trim)
                    xmlw.WriteEndElement()
                End If
                If Me.RefillResponse.Prescriber.Identification.UPIN.Trim <> "" Then
                    xmlw.WriteStartElement("UPIN")
                    xmlw.WriteString(Me.RefillResponse.Prescriber.Identification.UPIN.Trim)
                    xmlw.WriteEndElement()
                End If
                If Me.RefillResponse.Prescriber.Identification.PPONumber.Trim <> "" Then
                    xmlw.WriteStartElement("PPONumber")
                    xmlw.WriteString(Me.RefillResponse.Prescriber.Identification.PPONumber.Trim)
                    xmlw.WriteEndElement()
                End If
                If Me.RefillResponse.Prescriber.Identification.DEANumber.Trim <> "" Then
                    xmlw.WriteStartElement("DEANumber")
                    xmlw.WriteString(Me.RefillResponse.Prescriber.Identification.DEANumber.Trim)
                    xmlw.WriteEndElement()
                End If
                '''' SocialSecurity simple type
                If Me.RefillResponse.Prescriber.Identification.SocialSecurity.Trim <> "" Then
                    xmlw.WriteStartElement("SocialSecurity")
                    xmlw.WriteString(Me.RefillResponse.Prescriber.Identification.SocialSecurity.Trim)
                    xmlw.WriteEndElement()
                End If
                '''' End SocialSecurity simple type
                If Me.RefillResponse.Prescriber.Identification.NPI.Trim <> "" Then
                    xmlw.WriteStartElement("NPI")
                    xmlw.WriteString(Me.RefillResponse.Prescriber.Identification.NPI.Trim)
                    xmlw.WriteEndElement()
                End If
                If Me.RefillResponse.Prescriber.Identification.PriorAuthorization.Trim <> "" Then
                    xmlw.WriteStartElement("PriorAuthorization")
                    xmlw.WriteString(Me.RefillResponse.Prescriber.Identification.PriorAuthorization.Trim)
                    xmlw.WriteEndElement()
                End If

                ''''''''


                xmlw.WriteEndElement()
                '''' End Identification complex type
                If Me.RefillResponse.Prescriber.ClinicName.Trim <> "" Then
                    xmlw.WriteStartElement("ClinicName")
                    xmlw.WriteString(Me.RefillResponse.Prescriber.ClinicName.Trim)
                    xmlw.WriteEndElement()
                End If
                If Me.RefillResponse.Prescriber.Name.LastName.Trim <> "" Or Me.RefillResponse.Prescriber.Name.FirstName.Trim <> "" Or Me.RefillResponse.Prescriber.Name.MiddleName.Trim <> "" Or Me.RefillResponse.Prescriber.Name.Suffix.Trim <> "" Or Me.RefillResponse.Prescriber.Name.Prefix.Trim <> "" Then
                    '''' Name complex type
                    xmlw.WriteStartElement("Name")
                    If Me.RefillResponse.Prescriber.Name.LastName.Trim <> "" Then
                        '''' LastName simple type
                        xmlw.WriteStartElement("LastName")
                        xmlw.WriteString(Me.RefillResponse.Prescriber.Name.LastName.Trim)
                        xmlw.WriteEndElement()
                        '''' End LastName simple type
                    End If
                    If Me.RefillResponse.Prescriber.Name.FirstName.Trim <> "" Then
                        '''' FirstName simple type
                        xmlw.WriteStartElement("FirstName")
                        xmlw.WriteString(Me.RefillResponse.Prescriber.Name.FirstName.Trim)
                        xmlw.WriteEndElement()
                        '''' End FirstName simple type
                    End If
                    '''' MiddleName simple type
                    If Me.RefillResponse.Prescriber.Name.MiddleName.Trim <> "" Then
                        xmlw.WriteStartElement("MiddleName")
                        xmlw.WriteString(Me.RefillResponse.Prescriber.Name.MiddleName.Trim)
                        xmlw.WriteEndElement()
                    End If
                    '''' End MidleName simple type

                    If Me.RefillResponse.Prescriber.Name.Suffix.Trim <> "" Then
                        xmlw.WriteStartElement("Suffix")
                        xmlw.WriteString(Me.RefillResponse.Prescriber.Name.Suffix.Trim)
                        xmlw.WriteEndElement()
                    End If
                    If Me.RefillResponse.Prescriber.Name.Prefix.Trim <> "" Then
                        xmlw.WriteStartElement("Prefix")
                        xmlw.WriteString(Me.RefillResponse.Prescriber.Name.Prefix.Trim)
                        xmlw.WriteEndElement()
                    End If
                    xmlw.WriteEndElement()
                    '''' End Name complex type
                End If
                '''' Specialty complex type
                If Me.RefillResponse.Prescriber.Specialty.SpecialtyCode.Trim <> "" Then
                    xmlw.WriteStartElement("Specialty")
                    '   ''' Qualifier simple type
                    xmlw.WriteStartElement("Qualifier")
                    xmlw.WriteString(Me.RefillResponse.Prescriber.Specialty.Qualifier.Trim)
                    xmlw.WriteEndElement()
                    '  ''' End Qualifier simple type
                    ' ''' SpecialtyCode simple type
                    xmlw.WriteStartElement("SpecialtyCode")
                    xmlw.WriteString(Me.RefillResponse.Prescriber.Specialty.SpecialtyCode.Trim)
                    xmlw.WriteEndElement()
                    '''' End SpecialtyCode simple type
                    xmlw.WriteEndElement()
                    '''' End Specialty complex type
                End If
                If Me.RefillResponse.Prescriber.PrescriberAgent.FirstName.Trim <> "" Or Me.RefillResponse.Prescriber.PrescriberAgent.LastName.Trim <> "" Or Me.RefillResponse.Prescriber.PrescriberAgent.MiddleName.Trim <> "" Then
                    '''' PrescriberAgent complex type
                    xmlw.WriteStartElement("PrescriberAgent")
                    If Me.RefillResponse.Prescriber.PrescriberAgent.LastName.Trim <> "" Then
                        '   ''' LastName simple type
                        xmlw.WriteStartElement("LastName")
                        xmlw.WriteString(Me.RefillResponse.Prescriber.PrescriberAgent.LastName.Trim)
                        xmlw.WriteEndElement()
                        '  ''' End LastName simple type
                    End If
                    If Me.RefillResponse.Prescriber.PrescriberAgent.FirstName.Trim <> "" Then
                        ' ''' FirstName simple type
                        xmlw.WriteStartElement("FirstName")
                        xmlw.WriteString(Me.RefillResponse.Prescriber.PrescriberAgent.FirstName.Trim)
                        xmlw.WriteEndElement()
                        '''' End FirstName simple type
                    End If

                    If Me.RefillResponse.Prescriber.PrescriberAgent.MiddleName.Trim <> "" Then
                        xmlw.WriteStartElement("MiddleName")
                        xmlw.WriteString(Me.RefillResponse.Prescriber.PrescriberAgent.MiddleName.Trim)
                        xmlw.WriteEndElement()
                    End If
                    '''' End MidleName simple type

                    If Me.RefillResponse.Prescriber.PrescriberAgent.Suffix.Trim <> "" Then
                        xmlw.WriteStartElement("Suffix")
                        xmlw.WriteString(Me.RefillResponse.Prescriber.PrescriberAgent.Suffix.Trim)
                        xmlw.WriteEndElement()
                    End If
                    If Me.RefillResponse.Prescriber.PrescriberAgent.Prefix.Trim <> "" Then
                        xmlw.WriteStartElement("Prefix")
                        xmlw.WriteString(Me.RefillResponse.Prescriber.PrescriberAgent.Prefix.Trim)
                        xmlw.WriteEndElement()
                    End If
                    xmlw.WriteEndElement()
                    '''' End PrescriberAgent complex type
                End If
                If Me.RefillResponse.Prescriber.Address.AddressLine1.Trim <> "" Or Me.RefillResponse.Prescriber.Address.AddressLine2.Trim <> "" Or Me.RefillResponse.Prescriber.Address.City.Trim <> "" Or Me.RefillResponse.Prescriber.Address.State.Trim <> "" Or Me.RefillResponse.Prescriber.Address.ZipCode.Trim <> "" Then
                    '''' Address complex type
                    xmlw.WriteStartElement("Address")
                    If Me.RefillResponse.Prescriber.Address.AddressLine1.Trim <> "" Then
                        ' ''' AddressLine1 simple type
                        xmlw.WriteStartElement("AddressLine1")
                        xmlw.WriteString(Me.RefillResponse.Prescriber.Address.AddressLine1.Trim)
                        xmlw.WriteEndElement()
                        ' ''' End AddressLine1 simple type
                    End If

                    If Me.RefillResponse.Prescriber.Address.AddressLine2.Trim <> "" Then
                        xmlw.WriteStartElement("AddressLine2")
                        xmlw.WriteString(Me.RefillResponse.Prescriber.Address.AddressLine2.Trim)
                        xmlw.WriteEndElement()
                    End If
                    If Me.RefillResponse.Prescriber.Address.City.Trim <> "" Then
                        ' ''' City simple type
                        xmlw.WriteStartElement("City")
                        xmlw.WriteString(Me.RefillResponse.Prescriber.Address.City.Trim)
                        xmlw.WriteEndElement()
                        ' ''' End City simple type
                    End If
                    If Me.RefillResponse.Prescriber.Address.State.Trim <> "" Then
                        '  ''' State simple type
                        xmlw.WriteStartElement("State")
                        xmlw.WriteString(Me.RefillResponse.Prescriber.Address.State.Trim)
                        xmlw.WriteEndElement()
                        ' ''' End State simple type
                    End If
                    If Me.RefillResponse.Prescriber.Address.ZipCode.Trim <> "" Then
                        ' ''' ZipCode simple type
                        xmlw.WriteStartElement("ZipCode")
                        xmlw.WriteString(Me.RefillResponse.Prescriber.Address.ZipCode.Replace("-", ""))
                        xmlw.WriteEndElement()
                        '  ''' End ZipCode simple type
                    End If
                    xmlw.WriteEndElement()
                    '   ''' End Address complex type
                End If
                If Me.RefillResponse.Prescriber.Email.Trim <> "" Then
                    '' ''' Email simple type
                    xmlw.WriteStartElement("Email")
                    xmlw.WriteString(Me.RefillResponse.Prescriber.Email.Trim)
                    xmlw.WriteEndElement()
                    ' ''' End Email simple type
                End If
                If Not Me.RefillResponse.Prescriber.PhoneNumbers.Phone Is Nothing Then

                    '''' PhoneNumbers complex type
                    xmlw.WriteStartElement("PhoneNumbers")
                    Dim a As Integer = 0
                    For a = 0 To Me.RefillResponse.Prescriber.PhoneNumbers.Phone.Length - 1
                        ' ''' Phone complex type
                        xmlw.WriteStartElement("Phone")
                        ' ''' Number simple type
                        xmlw.WriteStartElement("Number")
                        xmlw.WriteString(Me.RefillResponse.Prescriber.PhoneNumbers.Phone(a).Number.Trim)
                        xmlw.WriteEndElement()
                        '  ''' End Number simple type
                        '   ''' Qualifier simple type
                        xmlw.WriteStartElement("Qualifier")
                        xmlw.WriteString(Me.RefillResponse.Prescriber.PhoneNumbers.Phone(a).Qualifier)
                        xmlw.WriteEndElement()
                        '  ''' End Qualifier simple type
                        xmlw.WriteEndElement()
                        '     ''' End Phone complex type
                    Next
                    xmlw.WriteEndElement()
                    ' ''' End PhoneNumbers complex type
                End If
                xmlw.WriteEndElement()
                '''' End Prescriber complex type
                '''' Patient Complex type
                xmlw.WriteStartElement("Patient")

                If Me.RefillResponse.PAtient.Identification.SocialSecurity.Trim <> "" Or _
                   Me.RefillResponse.PAtient.Identification.FileID.Trim <> "" Or _
                   Me.RefillResponse.PAtient.Identification.MedicalcareNumber.Trim <> "" Or _
                   Me.RefillResponse.PAtient.Identification.MedicaidNumber.Trim <> "" Or _
                   Me.RefillResponse.PAtient.Identification.PPONumber.Trim <> "" Then

                    '''' Identification complex type
                    xmlw.WriteStartElement("Identification")

                    If Me.RefillResponse.PAtient.Identification.FileID.Trim <> "" Then
                        xmlw.WriteStartElement("FileID")
                        xmlw.WriteString(Me.RefillResponse.PAtient.Identification.FileID.Trim)
                        xmlw.WriteEndElement()
                    End If

                    If Me.RefillResponse.PAtient.Identification.MedicalcareNumber.Trim <> "" Then
                        xmlw.WriteStartElement("MedicareNumber")
                        xmlw.WriteString(Me.RefillResponse.PAtient.Identification.MedicalcareNumber.Trim)
                        xmlw.WriteEndElement()
                    End If

                    If Me.RefillResponse.PAtient.Identification.MedicaidNumber.Trim <> "" Then
                        xmlw.WriteStartElement("MedicaidNumber")
                        xmlw.WriteString(Me.RefillResponse.PAtient.Identification.MedicaidNumber.Trim)
                        xmlw.WriteEndElement()
                    End If

                    If Me.RefillResponse.PAtient.Identification.PPONumber.Trim <> "" Then
                        xmlw.WriteStartElement("PPONumber")
                        xmlw.WriteString(Me.RefillResponse.PAtient.Identification.PPONumber.Trim)
                        xmlw.WriteEndElement()
                    End If
                    If Me.RefillResponse.PAtient.Identification.SocialSecurity.Trim <> "" Then
                        '''' SocialSecurity simple type
                        xmlw.WriteStartElement("SocialSecurity")
                        xmlw.WriteString(Me.RefillResponse.PAtient.Identification.SocialSecurity.Trim)
                        xmlw.WriteEndElement()
                        '''' End SocialSecurity simple type
                    End If

                    xmlw.WriteEndElement()
                    '''' End Identification complex type
                End If
                If Me.RefillResponse.PAtient.Name.LastName.Trim <> "" Or Me.RefillResponse.PAtient.Name.FirstName.Trim <> "" Or Me.RefillResponse.PAtient.Name.MiddleName.Trim <> "" Or Me.RefillResponse.PAtient.Name.Suffix.Trim <> "" Or Me.RefillResponse.PAtient.Name.Prefix.Trim <> "" Then
                    '''' Name complex type
                    xmlw.WriteStartElement("Name")
                    If Me.RefillResponse.PAtient.Name.LastName.Trim <> "" Then
                        '''' LastName simple type
                        xmlw.WriteStartElement("LastName")
                        xmlw.WriteString(Me.RefillResponse.PAtient.Name.LastName.Trim)
                        xmlw.WriteEndElement()
                        '''' End LastName simple type
                    End If
                    If Me.RefillResponse.PAtient.Name.FirstName.Trim <> "" Then
                        '''' FirstName simple type
                        xmlw.WriteStartElement("FirstName")
                        xmlw.WriteString(Me.RefillResponse.PAtient.Name.FirstName.Trim)
                        xmlw.WriteEndElement()
                        '''' End FirstName simple type
                    End If
                    If Me.RefillResponse.PAtient.Name.MiddleName.Trim <> "" Then
                        ''' MiddleName simple type
                        xmlw.WriteStartElement("MiddleName")
                        xmlw.WriteString(Me.RefillResponse.PAtient.Name.MiddleName.Trim)
                        xmlw.WriteEndElement()
                        '''' End MidleName simple type
                    End If

                    If Me.RefillResponse.PAtient.Name.Suffix.Trim <> "" Then
                        '''' Suffix simple type
                        xmlw.WriteStartElement("Suffix")
                        xmlw.WriteString(Me.RefillResponse.PAtient.Name.Suffix.Trim)
                        xmlw.WriteEndElement()
                        '''' End Suffix simple type
                    End If
                    If Me.RefillResponse.PAtient.Name.Prefix.Trim <> "" Then
                        '''' Prefix simple type
                        xmlw.WriteStartElement("Prefix")
                        xmlw.WriteString(Me.RefillResponse.PAtient.Name.Prefix.Trim)
                        xmlw.WriteEndElement()
                        '''' End Prefix simple type
                    End If

                    xmlw.WriteEndElement()
                    '''' End Name complex type
                End If
                '''' Gender simple type
                xmlw.WriteStartElement("Gender")
                xmlw.WriteString(IIf(Me.RefillResponse.PAtient.Gender = 1, "M", "F"))
                xmlw.WriteEndElement()
                '''' End Gender simple type
                If Me.RefillResponse.PAtient.DateOfBirth.Date.Trim <> "" Then
                    '''' DateOfBirth simple type
                    xmlw.WriteStartElement("DateOfBirth")
                    xmlw.WriteString(Me.RefillResponse.PAtient.DateOfBirth.Date.Trim)
                    xmlw.WriteEndElement()
                    '''' End DateOfBirth simple type
                End If
                If Me.RefillResponse.PAtient.Address.AddressLine1.Trim <> "" Or Me.RefillResponse.PAtient.Address.AddressLine2.Trim <> "" Or Me.RefillResponse.PAtient.Address.City.Trim <> "" Or Me.RefillResponse.PAtient.Address.State.Trim <> "" Or Me.RefillResponse.PAtient.Address.ZipCode.Trim <> "" Then
                    '''' Address complex type
                    xmlw.WriteStartElement("Address")
                    If Me.RefillResponse.PAtient.Address.AddressLine1.Trim <> "" Then
                        '''' AddressLine1 simple type
                        xmlw.WriteStartElement("AddressLine1")
                        xmlw.WriteString(Me.RefillResponse.PAtient.Address.AddressLine1.Trim)
                        xmlw.WriteEndElement()
                        '''' End AddressLine1 simple type
                    End If
                    If Me.RefillResponse.PAtient.Address.AddressLine2.Trim <> "" Then
                        xmlw.WriteStartElement("AddressLine2")
                        xmlw.WriteString(Me.RefillResponse.PAtient.Address.AddressLine2.Trim)
                        xmlw.WriteEndElement()
                    End If
                    If Me.RefillResponse.PAtient.Address.City.Trim <> "" Then
                        '''' City simple type
                        xmlw.WriteStartElement("City")
                        xmlw.WriteString(Me.RefillResponse.PAtient.Address.City.Trim)
                        xmlw.WriteEndElement()
                        '''' End City simple type
                    End If
                    If Me.RefillResponse.PAtient.Address.State.Trim <> "" Then
                        '''' State simple type
                        xmlw.WriteStartElement("State")
                        xmlw.WriteString(Me.RefillResponse.PAtient.Address.State.Trim)
                        xmlw.WriteEndElement()
                        '''' End State simple type
                    End If
                    If Me.RefillResponse.PAtient.Address.ZipCode.Trim <> "" Then
                        '''' ZipCode simple type
                        xmlw.WriteStartElement("ZipCode")
                        xmlw.WriteString(Me.RefillResponse.PAtient.Address.ZipCode.Replace("-", ""))
                        xmlw.WriteEndElement()
                        '''' End ZipCode simple type
                    End If
                    xmlw.WriteEndElement()
                    '''' End Address complex type
                End If
                If Me.RefillResponse.PAtient.Email.Trim <> "" Then
                    '''' Email simple type
                    xmlw.WriteStartElement("Email")
                    xmlw.WriteString(Me.RefillResponse.PAtient.Email.Trim)
                    xmlw.WriteEndElement()
                    '''' End Email simple type
                End If
                If Not Me.RefillResponse.PAtient.PhoneNumbers.Phone Is Nothing Then
                    '''' PhoneNumbers complex type
                    xmlw.WriteStartElement("PhoneNumbers")
                    Dim a As Integer = 0
                    For a = 0 To Me.RefillResponse.PAtient.PhoneNumbers.Phone.Length - 1
                        '''' Phone complex type
                        xmlw.WriteStartElement("Phone")
                        '''' Number simple type
                        xmlw.WriteStartElement("Number")
                        xmlw.WriteString(Me.RefillResponse.PAtient.PhoneNumbers.Phone(a).Number.Trim)
                        xmlw.WriteEndElement()
                        '''' End Number simple type
                        '''' Qualifier simple type
                        xmlw.WriteStartElement("Qualifier")
                        xmlw.WriteString(Me.RefillResponse.PAtient.PhoneNumbers.Phone(a).Qualifier)
                        xmlw.WriteEndElement()
                        '''' End Qualifier simple type
                        xmlw.WriteEndElement()
                        '''' End Phone complex type
                    Next
                    xmlw.WriteEndElement()
                    '''' End PhoneNumbers complex type
                End If
                xmlw.WriteEndElement()
                ' ''' End Patient complex type
                '  ''' MediacationPrescribed complex type
                xmlw.WriteStartElement("MedicationPrescribed")
                ' ''' DrugDescription simple type
                xmlw.WriteStartElement("DrugDescription")
                xmlw.WriteString(Me.RefillResponse.MedicationPrescribed.DrugDescription.Trim)
                xmlw.WriteEndElement()
                '''' End DrugDescription simple type

                If Me.RefillResponse.MedicationPrescribed.DrugCoded.ProductCode.Trim <> "" Or Me.RefillResponse.MedicationPrescribed.DrugCoded.ProductCodeQualifier.Trim <> "" Or Me.RefillResponse.MedicationPrescribed.DrugCoded.DosageForm.Trim <> "" Or Me.RefillResponse.MedicationPrescribed.DrugCoded.Strength.Trim <> "" Or Me.RefillResponse.MedicationPrescribed.DrugCoded.StrengthUnits.Trim <> "" Or Me.RefillResponse.MedicationPrescribed.DrugCoded.DrugDBCode.Trim <> "" Or Me.RefillResponse.MedicationPrescribed.DrugCoded.DrugDBCodeQualifier.Trim <> "" Then
                    ' ''' DrugCoded complex type
                    xmlw.WriteStartElement("DrugCoded")
                    If Me.RefillResponse.MedicationPrescribed.DrugCoded.ProductCode.Trim <> "" Then
                        ' ''' ProductCode simple type
                        xmlw.WriteStartElement("ProductCode")
                        xmlw.WriteString(Me.RefillResponse.MedicationPrescribed.DrugCoded.ProductCode.Trim)
                        xmlw.WriteEndElement()
                        '  ''' End ProductCode simple type
                    End If
                    If Me.RefillResponse.MedicationPrescribed.DrugCoded.ProductCodeQualifier.Trim <> "" Then
                        ' ''' ProductCodeQualifier simple type
                        xmlw.WriteStartElement("ProductCodeQualifier")
                        xmlw.WriteString(Me.RefillResponse.MedicationPrescribed.DrugCoded.ProductCodeQualifier.Trim)
                        xmlw.WriteEndElement()
                        ' ''' End ProductCodeQualifier simple type
                    End If
                    If Me.RefillResponse.MedicationPrescribed.DrugCoded.DosageForm.Trim <> "" Then
                        '''' DosageForm simple type
                        xmlw.WriteStartElement("DosageForm")
                        xmlw.WriteString(Me.RefillResponse.MedicationPrescribed.DrugCoded.DosageForm.Trim)
                        xmlw.WriteEndElement()
                        '  ''' End DosageForm simple type
                    End If
                    If Me.RefillResponse.MedicationPrescribed.DrugCoded.Strength.Trim <> "" Then
                        '''' Strength simple type
                        xmlw.WriteStartElement("Strength")
                        xmlw.WriteString(Me.RefillResponse.MedicationPrescribed.DrugCoded.Strength.Trim)
                        xmlw.WriteEndElement()
                        ' ''' End Strength simple type
                    End If
                    If Me.RefillResponse.MedicationPrescribed.DrugCoded.StrengthUnits.Trim <> "" Then
                        '''' StrengthUnits simple type
                        xmlw.WriteStartElement("StrengthUnits")
                        xmlw.WriteString(Me.RefillResponse.MedicationPrescribed.DrugCoded.StrengthUnits.Trim)
                        xmlw.WriteEndElement()
                        '''' End StrengthUnits simple type
                    End If
                    If Me.RefillResponse.MedicationPrescribed.DrugCoded.DrugDBCode.Trim <> "" Then
                        '''' DrugDBCode simple type
                        xmlw.WriteStartElement("DrugDBCode")
                        xmlw.WriteString(Me.RefillResponse.MedicationPrescribed.DrugCoded.DrugDBCode.Trim)
                        xmlw.WriteEndElement()
                        '''' End DrugDBCode simple type
                    End If
                    If Me.RefillResponse.MedicationPrescribed.DrugCoded.DrugDBCodeQualifier.Trim <> "" Then
                        ' ''' DrugDBCodeQualifier simple type
                        xmlw.WriteStartElement("DrugDBCodeQualifier")
                        xmlw.WriteString(Me.RefillResponse.MedicationPrescribed.DrugCoded.DrugDBCodeQualifier.Trim)
                        xmlw.WriteEndElement()
                        ' ''' End DrugDBCodeQualifier simple type
                    End If
                    xmlw.WriteEndElement()
                    '''' End DrugCoded complex type
                End If

                '''' Quantity complex type
                xmlw.WriteStartElement("Quantity")
                If Me.RefillResponse.MedicationPrescribed.Quantity.Qualifier.Trim <> "" Then
                    ' ''' Qualifier simple type
                    xmlw.WriteStartElement("Qualifier")
                    xmlw.WriteString(Me.RefillResponse.MedicationPrescribed.Quantity.Qualifier.Trim)
                    xmlw.WriteEndElement()
                    ' ''' End Qualifier simple type
                End If
                If Me.RefillResponse.MedicationPrescribed.Quantity.Value.Trim <> "" Then
                    '''' Value simple type
                    xmlw.WriteStartElement("Value")
                    xmlw.WriteString(Me.RefillResponse.MedicationPrescribed.Quantity.Value.Trim)
                    xmlw.WriteEndElement()
                    '''' End Value simple type
                End If
                xmlw.WriteEndElement()
                '''' End Quantity complex type
                If Me.RefillResponse.MedicationPrescribed.DaysSupply.Trim <> "" Then
                    '''' DaysSupply simple type
                    xmlw.WriteStartElement("DaysSupply")
                    xmlw.WriteString(Me.RefillResponse.MedicationPrescribed.DaysSupply.Trim)
                    xmlw.WriteEndElement()
                    '''' End DaysSupply simple type
                End If
                If Me.RefillResponse.MedicationPrescribed.Directions.Trim <> "" Then
                    ' ''' Directions simple type
                    xmlw.WriteStartElement("Directions")
                    xmlw.WriteString(Me.RefillResponse.MedicationPrescribed.Directions.Trim)
                    xmlw.WriteEndElement()
                    ' ''' End Directions simple type
                End If
                If Me.RefillResponse.MedicationPrescribed.Note.Trim <> "" Then
                    ' ''' Note simple type
                    xmlw.WriteStartElement("Note")
                    xmlw.WriteString(Me.RefillResponse.MedicationPrescribed.Note.Trim)
                    xmlw.WriteEndElement()
                    ' ''' End Note simple type
                End If

                If Me.RefillResponse.MedicationPrescribed.Refills.Qualifier.Trim <> "" Then
                    '''' Refills complex type
                    xmlw.WriteStartElement("Refills")
                    If Me.RefillResponse.MedicationPrescribed.Refills.Qualifier.Trim <> "" Then
                        ' ''' Qualifier simple type
                        xmlw.WriteStartElement("Qualifier")
                        xmlw.WriteString(Me.RefillResponse.MedicationPrescribed.Refills.Qualifier.Trim)
                        xmlw.WriteEndElement()
                        ' ''' End Qualifier simple type
                    End If
                    '''' Quantity simple type
                    If Me.RefillResponse.MedicationPrescribed.Refills.Qualifier.Trim() <> "PRN" Then
                        If Me.RefillResponse.MedicationPrescribed.Refills.Quantity.Trim <> "" Then
                            xmlw.WriteStartElement("Quantity")
                            xmlw.WriteString(Left(Me.RefillResponse.MedicationPrescribed.Refills.Quantity.Trim, 3))
                            xmlw.WriteEndElement()
                            '''' End Quantity simple type
                        End If
                    End If
                    xmlw.WriteEndElement()
                    ' ''' End Refills complex type
                End If
                If Me.RefillResponse.MedicationPrescribed.Substitutions.Trim <> "" Then
                    ' ''' Substitutions simple type
                    xmlw.WriteStartElement("Substitutions")
                    xmlw.WriteString(Me.RefillResponse.MedicationPrescribed.Substitutions.Trim)
                    xmlw.WriteEndElement()
                    '''' End Substitutions simple type
                End If

                If Me.RefillResponse.MedicationPrescribed.WrittenDate.Date.Trim <> "" Then
                    '''' WrittenDate simple type
                    xmlw.WriteStartElement("WrittenDate")
                    xmlw.WriteString(Me.RefillResponse.MedicationPrescribed.WrittenDate.Date.Trim)
                    xmlw.WriteEndElement()
                    ' ''' End WrittenDate simple type
                End If
                If Me.RefillResponse.MedicationPrescribed.LastFillDate.Date.Trim <> "" Then
                    '''' LastFillDate simple type
                    xmlw.WriteStartElement("LastFillDate")
                    xmlw.WriteString(Me.RefillResponse.MedicationPrescribed.LastFillDate.Date.Trim)
                    xmlw.WriteEndElement()
                    '''' End LastFillDate simple type
                End If
                ''''''''''''''''
                If Me.RefillResponse.MedicationPrescribed.Diagnosis.Qualifier.Trim <> "" Then
                    'Diagnosis Complex Type Start Here
                    xmlw.WriteStartElement("Diagnosis")

                    If Me.RefillResponse.MedicationPrescribed.Diagnosis.Qualifier.Trim <> "" Then
                        xmlw.WriteStartElement("Qualifier")
                        xmlw.WriteString(Me.RefillResponse.MedicationPrescribed.Diagnosis.Qualifier.Trim)
                        xmlw.WriteEndElement()
                    End If

                    If Me.RefillResponse.MedicationPrescribed.Diagnosis.Primary.Value.Trim <> "" Then
                        'Primary Complex Type
                        xmlw.WriteStartElement("Primary")

                        xmlw.WriteStartElement("Qualifier")
                        xmlw.WriteString(Me.RefillResponse.MedicationPrescribed.Diagnosis.Primary.Qualifier.Trim)
                        xmlw.WriteEndElement()

                        xmlw.WriteStartElement("Value")
                        xmlw.WriteString(Me.RefillResponse.MedicationPrescribed.Diagnosis.Primary.Value.Trim)
                        xmlw.WriteEndElement()

                        xmlw.WriteEndElement()
                        'Primary Complex Type End Here
                    End If

                    If Me.RefillResponse.MedicationPrescribed.Diagnosis.Secondary.Value.Trim <> "" Then
                        'Secondary Complex Type Start Here
                        xmlw.WriteStartElement("Secondary")

                        xmlw.WriteStartElement("Qualifier")
                        xmlw.WriteString(Me.RefillResponse.MedicationPrescribed.Diagnosis.Secondary.Qualifier.Trim)
                        xmlw.WriteEndElement()

                        xmlw.WriteStartElement("Value")
                        xmlw.WriteString(Me.RefillResponse.MedicationPrescribed.Diagnosis.Secondary.Value.Trim)
                        xmlw.WriteEndElement()

                        xmlw.WriteEndElement()
                        'Secondary Complex Type End Here 
                    End If

                    xmlw.WriteEndElement()
                    'Diagnosis Complex Type End Here
                End If
                If Me.RefillResponse.MedicationPrescribed.PriorAuthorization.Value.Trim <> "" Then
                    xmlw.WriteStartElement("PriorAuthorization")

                    xmlw.WriteStartElement("Qualifier")
                    xmlw.WriteString(Me.RefillResponse.MedicationPrescribed.PriorAuthorization.Qualifier.Trim)
                    xmlw.WriteEndElement()

                    xmlw.WriteStartElement("Value")
                    xmlw.WriteString(Me.RefillResponse.MedicationPrescribed.PriorAuthorization.Value.Trim)
                    xmlw.WriteEndElement()

                    xmlw.WriteEndElement()
                End If
                ''''''''''''''''
                xmlw.WriteEndElement()
                '''' End MedicationPrescribed complex type
                xmlw.WriteEndElement()
                '''' End RefillResponse complex type
                xmlw.WriteEndElement()
                '''' End Body complex type
                xmlw.WriteEndElement()
                '''' End Message complex type
                xmlw.WriteEndDocument()

                lResult = True
            Catch ex As Exception
                'Dim a As String
                'a = ex.Message
                lResult = False
            Finally
                xmlw.Flush()
                xmlw.Close()
            End Try
            Return lResult
        End Function


        Private Sub GetNode(ByVal tree As XmlNode, ByVal RecMessage As SureScriptsLibrary.SureScripts.ReceivedMessage)
            Dim lName As String = tree.Name

            Try
                Select Case lName.ToUpper
                    Case "TO"
                        RecMessage.HeaderType.To.MailAddress = tree.InnerText
                    Case "FROM"
                        RecMessage.HeaderType.From.MailAddress = tree.InnerText
                    Case "MESSAGEID"
                        RecMessage.HeaderType.MesssageID = tree.InnerText
                    Case "RELATESTOMESSAGEID"
                        RecMessage.HeaderType.RelatesToMessageID = tree.InnerText
                    Case "SENTTIME"
                        RecMessage.HeaderType.SentTime.UtcDate = tree.InnerText
                    Case "CODE"
                        RecMessage.ErrorType.Code = tree.InnerText
                        RecMessage.StatusType.Code = tree.InnerText
                    Case "DESCRIPTIONCODE"
                        RecMessage.ErrorType.DescriptionCode = tree.InnerText
                    Case "DESCRIPTION"
                        RecMessage.ErrorType.Description = tree.InnerText
                    Case "ERROR"
                        RecMessage.MessageType = "ERROR"
                    Case "STATUS"
                        RecMessage.MessageType = "STATUS"
                End Select

            Catch ex As Exception
                Throw New Exception(ex.Message + " : SurescriptsLibrary\RefillResponse.GetNode(ByVal tree As XmlNode, ByVal RecMessage As SureScriptsLibrary.SureScripts.ReceivedMessage) ")
            End Try

        End Sub

        Public Sub ParseTree(ByVal tree As XmlNode, ByVal RecMessage As SureScriptsLibrary.SureScripts.ReceivedMessage)

            Try
                If Not (tree Is Nothing) Then
                    GetNode(tree, RecMessage)
                End If
                If tree.HasChildNodes Then
                    tree = tree.FirstChild
                    While Not (tree Is Nothing)
                        ParseTree(tree, RecMessage)
                        tree = tree.NextSibling
                    End While
                End If

            Catch ex As Exception
                Throw New Exception(ex.Message + " : SurescriptsLibrary\RefillResponse.ParseTree(ByVal tree As XmlNode, ByVal RecMessage As SureScriptsLibrary.SureScripts.ReceivedMessage) ")
            End Try

        End Sub

        Public Function SaveStatus(ByVal constr As String, ByVal RecMessage As ReceivedMessage) As Boolean
            Dim lConnection As New Connection()
            'Dim lConnectionString As String
            'lConnectionString = ConfigurationSettings.AppSettings("connectionString")
            'If lConnectionString = "" Then
            '    lConnectionString = Me.ConnectionString
            'End If
            'Dim con As New SqlConnection(lConnectionString)

            'Dim lTransaction As SqlTransaction
            Dim lQuery As String
            Dim lDs As New DataSet
            Dim lMessageCode As Integer
            Dim lStatus As Boolean
            Dim lMessageType As Integer
            Dim lMessageStatus As String
            Dim lRetries As String
            Dim lCode As String
            Dim lHdrStatus As String

            Try
                'con.Open()
                'lTransaction = con.BeginTransaction
                lConnection.BeginTrans()

                lQuery = "Select * From MessageHdr " _
                       & "Where MessageId ='" & RecMessage.HeaderType.RelatesToMessageID & "' "

                If lConnection.IsTransactionAlive Then
                    lDs = lConnection.ExecuteTransactionQuery(lQuery)
                Else
                    lDs = lConnection.ExecuteQuery(lQuery)
                End If

                If lDs.Tables(0).Rows.Count > 0 Then
                    lMessageCode = CType(lDs.Tables(0).Rows(0)("MessageCode"), Integer)
                    lHdrStatus = lDs.Tables(0).Rows(0)("LastStatus")
                End If

                If RecMessage.MessageType = "ERROR" Then
                    lMessageType = 1
                    lCode = RecMessage.ErrorType.Code
                Else
                    lMessageType = 3
                    lCode = RecMessage.StatusType.Code
                End If

                If (lCode = "601" Or lCode = "900") And (lHdrStatus <> "Success" And lHdrStatus <> "Failure") Then
                    lMessageStatus = "Failure"

                    lQuery = "Update MessageDtl Set Status = 'Failure' " _
                           & "Where Direction = 'O' " _
                           & "And DetailMessageType = 7 " _
                           & "And MessageCode = " & lMessageCode & " "

                    If lConnection.IsTransactionAlive Then
                        lConnection.ExecuteTransactionCommand(lQuery)
                    Else
                        lConnection.ExecuteCommand(lQuery)
                    End If

                    'If Not lStatus Then
                    '    Throw New Exception
                    'End If

                    lQuery = "Update MessageHdr " _
                           & "Set LastStatus ='" & lMessageStatus & "' " _
                           & "Where MessageCode = " & lMessageCode & " "

                    If lConnection.IsTransactionAlive Then
                        lConnection.ExecuteTransactionCommand(lQuery)
                    Else
                        lConnection.ExecuteCommand(lQuery)
                    End If

                    'If Not lStatus Then
                    '    Throw New Exception
                    'End If



                ElseIf (lCode = "600" Or lCode = "602" Or lCode = "NR") And (lHdrStatus <> "Success" And lHdrStatus <> "Failure") Then
                    lMessageStatus = "Failure"

                    lQuery = "Select Count(*) Retries " _
                           & "From MessageDtl " _
                           & "Where MessageCode = " & lMessageCode & " " _
                           & "And Direction = 'O' " _
                           & "And DetailMessageType = 7 " _
                           & "And Status = 'Pending' "

                    If lConnection.IsTransactionAlive Then
                        lDs = lConnection.ExecuteTransactionQuery(lQuery)
                    Else
                        lDs = lConnection.ExecuteQuery(lQuery)
                    End If

                    If lDs.Tables(0).Rows.Count > 0 Then
                        lRetries = CType(lDs.Tables(0).Rows(0)("Retries"), Integer)
                    End If

                    If lRetries >= 4 Then

                        lQuery = "Update MessageDtl Set Status = 'Failure' " _
                               & "Where Direction = 'O' " _
                               & "And DetailMessageType = 7 " _
                               & "And MessageCode = " & lMessageCode & " "

                        If lConnection.IsTransactionAlive Then
                            lConnection.ExecuteTransactionCommand(lQuery)
                        Else
                            lConnection.ExecuteCommand(lQuery)
                        End If

                        'If Not lStatus Then
                        '    Throw New Exception
                        'End If

                        lQuery = "Update MessageHdr " _
                               & "Set LastStatus ='" & lMessageStatus & "' " _
                               & "Where MessageCode = " & lMessageCode & " "

                        If lConnection.IsTransactionAlive Then
                            lConnection.ExecuteTransactionCommand(lQuery)
                        Else
                            lConnection.ExecuteCommand(lQuery)
                        End If

                        'If Not lStatus Then
                        '    Throw New Exception
                        'End If
                    Else
                        lQuery = "Update MessageDtl Set Status = 'Pending' " _
                               & "Where Direction = 'O' " _
                               & "And DetailMessageType = 7 " _
                               & "And MessageCode = " & lMessageCode & " "

                        If lConnection.IsTransactionAlive Then
                            lConnection.ExecuteTransactionCommand(lQuery)
                        Else
                            lConnection.ExecuteCommand(lQuery)
                        End If

                        'If Not lStatus Then
                        '    Throw New Exception
                        'End If

                        lQuery = "Update MessageHdr " _
                               & "Set LastStatus ='Pending' " _
                               & "Where MessageCode = " & lMessageCode & " "

                        If lConnection.IsTransactionAlive Then
                            lConnection.ExecuteTransactionCommand(lQuery)
                        Else
                            lConnection.ExecuteCommand(lQuery)
                        End If

                        'If Not lStatus Then
                        '    Throw New Exception
                        'End If
                        lMessageStatus = "Pending"
                    End If

                ElseIf lCode = "000" And (lHdrStatus <> "Success" And lHdrStatus <> "Failure") Then
                    lMessageStatus = "Success"

                    lQuery = "Update MessageDtl Set Status = 'InProgress' " _
                           & "Where Direction = 'O' " _
                           & "And LineId = (Select Max(LineId)  " _
                           & "              From MessageDtl " _
                           & "              Where MessageCode = " & lMessageCode & "  " _
                           & "              And Direction = 'O' " _
                           & "              And DetailMessageType = 7) "

                    If lConnection.IsTransactionAlive Then
                        lConnection.ExecuteTransactionCommand(lQuery)
                    Else
                        lConnection.ExecuteCommand(lQuery)
                    End If

                    'If Not lStatus Then
                    '    Throw New Exception
                    'End If


                    lQuery = "Update MessageDtl Set Status = 'Failure' " _
                           & "Where Direction = 'O' " _
                           & "And LineId <> (Select Max(LineId)  " _
                           & "                    From MessageDtl " _
                           & "                    Where MessageCode = " & lMessageCode & "  " _
                           & "	                  And Direction = 'O' " _
                           & "	                  And DetailMessageType = 7) " _
                           & "And MessageCode = " & lMessageCode & "  "

                    If lConnection.IsTransactionAlive Then
                        lConnection.ExecuteTransactionCommand(lQuery)
                    Else
                        lConnection.ExecuteCommand(lQuery)
                    End If

                    'If Not lStatus Then
                    '    Throw New Exception
                    'End If

                    lQuery = "Update MessageHdr " _
                               & "Set LastStatus ='InProgress' " _
                               & "Where MessageCode = " & lMessageCode & " "

                    If lConnection.IsTransactionAlive Then
                        lConnection.ExecuteTransactionCommand(lQuery)
                    Else
                        lConnection.ExecuteCommand(lQuery)
                    End If

                    'If Not lStatus Then
                    '    Throw New Exception
                    'End If

                    'It Should Become "Failure" or "Success" On receiving Message from Ultimate Receiver
                    'Should Be handle by Message Receiving Form.

                ElseIf lCode = "010" And (lHdrStatus <> "Success" And lHdrStatus <> "Failure") Then

                    lMessageStatus = "Success"

                    lQuery = "Update MessageDtl Set Status = 'Success' " _
                           & "Where Direction = 'O' " _
                           & "And LineId = (Select Max(LineId)  " _
                           & "              From MessageDtl " _
                           & "              Where MessageCode = " & lMessageCode & "  " _
                           & "              And Direction = 'O' " _
                           & "              And DetailMessageType = 7) "

                    If lConnection.IsTransactionAlive Then
                        lConnection.ExecuteTransactionCommand(lQuery)
                    Else
                        lConnection.ExecuteCommand(lQuery)
                    End If

                    'If Not lStatus Then
                    '    Throw New Exception
                    'End If


                    lQuery = "Update MessageDtl Set Status = 'Failure' " _
                           & "Where Direction = 'O' " _
                           & "And LineId <> (Select Max(LineId)  " _
                           & "                    From MessageDtl " _
                           & "                    Where MessageCode = " & lMessageCode & "  " _
                           & "	                  And Direction = 'O' " _
                           & "	                  And DetailMessageType = 7) " _
                           & "And MessageCode = " & lMessageCode & "  "

                    If lConnection.IsTransactionAlive Then
                        lConnection.ExecuteTransactionCommand(lQuery)
                    Else
                        lConnection.ExecuteCommand(lQuery)
                    End If

                    'If Not lStatus Then
                    '    Throw New Exception
                    'End If


                    lQuery = "Update MessageHdr " _
                           & "Set LastStatus ='" & lMessageStatus & "' " _
                           & "Where MessageCode = " & lMessageCode & " "

                    If lConnection.IsTransactionAlive Then
                        lConnection.ExecuteTransactionCommand(lQuery)
                    Else
                        lConnection.ExecuteCommand(lQuery)
                    End If
                    'If Not lStatus Then
                    '    Throw New Exception
                    'End If
                Else
                    Throw New Exception(" SurescriptsLibrary\RefillResponse.SaveStatus(ByVal constr As String, ByVal RecMessage As ReceivedMessage) ")
                End If


                lQuery = "INSERT INTO MessageDtl(MessageCode, MessageTime, " _
                       & "Status, Code, DescriptionCode, " _
                       & "[Description],Direction,ReceivedMessageId,DetailMessageType) " _
                       & "VALUES(" _
                       & " " & lMessageCode & ", " _
                       & "'" & Left(RecMessage.HeaderType.SentTime.UtcDate, 19) & "', " _
                       & "'" & lMessageStatus & "'," _
                       & "'" & lCode & "'," _
                       & "'" & RecMessage.ErrorType.DescriptionCode & "'," _
                       & "'" & RecMessage.ErrorType.Description.Replace("'", "''") & " '," _
                       & "'I'," _
                       & "'" & RecMessage.HeaderType.MesssageID & "'," _
                       & " " & lMessageType & ")"

                If lConnection.IsTransactionAlive Then
                    lConnection.ExecuteTransactionCommand(lQuery)
                Else
                    lConnection.ExecuteCommand(lQuery)
                End If
                'If Not lStatus Then
                '    Throw New Exception
                'End If


                'If ErrorCode = 601 or 900 Status = failure And All others are also Failure
                'If ErrorCode = 600 or 602 Status = failure And All others will be Pending if Out is Less then 4
                'If Code = 000 Then Status = "Success" And Last One  will be "InProgress" And All Others Will be Failure
                'If Code = 010 Then Status = "Success" And Last One will be "Success And All Others Will be Failure"

                lConnection.CommitTrans()
                SaveStatus = True

            Catch ex As Exception

                lConnection.RollBackTrans()

                Throw New Exception(ex.Message + " : SurescriptsLibrary\RefillResponse.SaveStatus(ByVal constr As String, ByVal RecMessage As ReceivedMessage)  ")

                SaveStatus = False
            End Try

        End Function


        Public Function GetNewCode(ByRef lConnection As Connection, ByRef lMsgId As String, ByVal lRxId As String) As String

            Dim lDs As DataSet
            Dim lMessageCode As String = ""
            Dim lMessageNo As Integer = 0
            Dim lStatus As Boolean
            Dim lQuery As String


            Try
                lRxId = "RxCure-PO-" & lRxId.PadLeft(9, "0")

                If lMsgId <> "" Then

                    lQuery = "Select * From MessageHdr Where MessageId ='" & lMsgId & "' " _
                           & "And PrescriberOrderNo ='" & lRxId & "' " _
                           & "And Direction = 'O' "

                    If lConnection.IsTransactionAlive Then
                        lDs = lConnection.ExecuteTransactionQuery(lQuery)
                    Else
                        lDs = lConnection.ExecuteQuery(lQuery)
                    End If

                    If lDs.Tables.Count > 0 Then
                        If lDs.Tables(0).Rows.Count > 0 Then
                            lMessageCode = lDs.Tables(0).Rows(0).Item("MessageCode")
                        End If
                    End If

                Else

                    lQuery = "Select IsNull(Max(MessageCode),0) + 1  AS MessageCode From MessageHdr "

                    If lConnection.IsTransactionAlive Then
                        lDs = lConnection.ExecuteTransactionQuery(lQuery)
                    Else
                        lDs = lConnection.ExecuteQuery(lQuery)
                    End If


                    If lDs.Tables.Count > 0 Then
                        lMessageCode = CType(lDs.Tables(0).Rows(0)("MessageCode"), String)
                    End If
                End If

                GetNewCode = lMessageCode

            Catch ex As Exception
                Throw New Exception(" SurescriptsLibrary\NewPrescription.GetMessageID(ByRef lConnection As Connection, ByRef lMsgId As String, ByVal lRxId As String) ")
            End Try

        End Function

        Public Function AddMessage(ByVal filename As String, ByVal lMsgId As String, ByVal lRxId As String, ByVal lClinicConnectionString As String) As Boolean

            Dim flg As Boolean = False

            Dim lConnection As New Connection()
            'Dim lConnectionString As String
            'lConnectionString = ConfigurationSettings.AppSettings("connectionString")
            'If lConnectionString = "" Then
            '    lConnectionString = Me.ConnectionString
            'End If
            'Dim con As New SqlConnection(lConnectionString)
            Dim lQuery As String
            'Dim lTransaction As SqlTransaction
            Dim id As Integer = 0
            Dim lPharmacyCode As String = ""
            Dim lIsFailure As Boolean
            Dim lResult As Boolean
            Dim lCode As Long
            Dim lIsExist As Boolean


            Try


                If lMsgId <> "" Then
                    lIsExist = True
                    Me.Header.MesssageID = lMsgId
                Else
                    lIsExist = False
                End If


                lConnection.BeginTrans()
                'con.Open()
                'lTransaction = con.BeginTransaction
                'lCode = GetMessageID(lConnection, lMsgId, lRxId)
                lCode = GetNewCode(lConnection, lMsgId, lRxId)
                'lCode = GetMessageID(lConnection, lMsgId, lRxId)

                If lCode = 0 Then
                    Throw New Exception("Error Getting MessageId : SureScriptsLibrary\RefillResponse\AddMessage.AddMessage(ByVal filename As String, ByVal lMsgId As String, ByVal lRxId As String, ByVal lClinicConnectionString As String))")
                End If

                If Me.Header.MesssageID <> "" Then
                    lMsgId = Me.Header.MesssageID
                End If

                'Me.Header.MesssageID = lMsgId
                'Me.RefillResponse.PrescribedOrderNumber = "RxCure-PO-" & lRxId.PadLeft(9, "0")

                If lIsExist Then
                    lResult = AddMessageDtl(lConnection, "O", lCode)
                    If Not lResult Then
                        Throw New Exception("Error Adding AddMessageDtl : SureScriptsLibrary\RefillResponse\AddMessage.AddMessage(ByVal filename As String, ByVal lMsgId As String, ByVal lRxId As String, ByVal lClinicConnectionString As String))")
                    End If
                Else

                    lResult = AddMessageHdr(lConnection, "O", lCode, filename)
                    If Not lResult Then
                        Throw New Exception("Error Adding AddMessageHdr : SureScriptsLibrary\RefillResponse\AddMessage.AddMessage(ByVal filename As String, ByVal lMsgId As String, ByVal lRxId As String, ByVal lClinicConnectionString As String))")
                    End If
                    lResult = AddMessageDtl(lConnection, "O", lCode)

                    If Not lResult Then
                        Throw New Exception
                    End If
                    lResult = UpdateRefillRequestSS(lClinicConnectionString, lMsgId, lRxId)
                    If Not lResult Then
                        Throw New Exception("Error Updating UpdateRefillRequestSS : SureScriptsLibrary\RefillResponse\AddMessage.AddMessage(ByVal filename As String, ByVal lMsgId As String, ByVal lRxId As String, ByVal lClinicConnectionString As String))")
                    End If
                End If

                lConnection.CommitTrans()
                flg = True
            Catch ex As Exception
                lConnection.RollBackTrans()
                Throw New Exception(ex.Message + " : SurescriptsLibrary\RefillResponse.AddMessage(ByVal filename As String, ByVal lMsgId As String, ByVal lRxId As String, ByVal lClinicConnectionString As String) ")
                flg = False
            End Try
            Return flg
        End Function

        Private Function UpdateRefillRequestSS(ByVal lClinicConnectionString As String, ByVal lMessageId As String, ByVal lRxId As String) As Boolean
            '============= To be checked lateron and uncomment ==========================

            ''Dim lConnection As New Connection(lClinicConnectionString)
            ' ''Dim lCommand As New SqlCommand
            ''Dim lQuery As String
            ''Dim lRefills As String
            ''Dim lRefillQualifier As String


            ''Dim lUser As Object

            ''lRefillQualifier = Me.RefillResponse.MedicationPrescribed.Refills.Qualifier
            ''lRefillQualifier = IIf(lRefillQualifier = "", "R", lRefillQualifier)

            ''If Me.RefillResponse.Response.ApprovedWithChanges.Refills.Quantity <> "" And Me.RefillResponse.Response.ApprovedWithChanges.Refills.Quantity <> "0" Then
            ''    lRefills = Me.RefillResponse.Response.ApprovedWithChanges.Refills.Quantity
            ''ElseIf Me.RefillResponse.Response.Denied.DenailReasonCode <> "" Then
            ''    lRefills = "0"
            ''Else
            ''    lRefills = Me.RefillResponse.MedicationPrescribed.Refills.Quantity
            ''End If

            ''Try

            ''    lUser = HttpContext.Current.Session("User")

            ''    lQuery = "Update RenewalRequest " _
            ''           & "Set IsSent ='Y' " _
            ''           & "Where MessageId ='" & Me.Header.RelatesToMessageID & "' " _
            ''           & "And NCPDPID ='" & Me.RefillResponse.Pharmacy.Identification.NCPDPID & "' "

            ''    If lConnection.IsTransactionAlive Then
            ''        lConnection.ExecuteTransactionCommand(lQuery)
            ''    Else
            ''        lConnection.ExecuteCommand(lQuery)
            ''    End If

            ''    lQuery = "Update RenewalResponse " _
            ''           & "Set IsApproved ='Y', IsSent = 'Y', SentByUserID='" & lUser.UserId & "', ApprovedByUserId='" & lUser.UserId & "' " _
            ''           & "Where RenewalResponseId = " _
            ''           & "  (Select Max(RenewalResponseId) From RenewalResponse RR, RenewalRequest Req  " _
            ''           & "   Where RR.RenewalRequestId = Req.RenewalRequestId " _
            ''           & "   And Req.MessageId ='" & Me.Header.RelatesToMessageID & "' " _
            ''           & "   And Req.NCPDPID ='" & Me.RefillResponse.Pharmacy.Identification.NCPDPID & "') "

            ''    If lConnection.IsTransactionAlive Then
            ''        lConnection.ExecuteTransactionCommand(lQuery)
            ''    Else
            ''        lConnection.ExecuteCommand(lQuery)
            ''    End If




            ''    lQuery = "Update RenewalResponse " _
            ''           & "Set IsSent = 'Y' " _
            ''           & "Where RenewalRequestId = ( " _
            ''           & "        Select RenewalRequestId From RenewalRequest " _
            ''           & "        Where MessageId ='" & Me.Header.RelatesToMessageID & "' " _
            ''           & "        And NCPDPID ='" & Me.RefillResponse.Pharmacy.Identification.NCPDPID & "') " _
            ''           & "And IsApproved = 'Y' "

            ''    If lConnection.IsTransactionAlive Then
            ''        lConnection.ExecuteTransactionCommand(lQuery)
            ''    Else
            ''        lConnection.ExecuteCommand(lQuery)
            ''    End If

            ''    UpdateRefillRequestSS = True
            ''Catch ex As Exception
            ''    UpdateRefillRequestSS = False
            ''    TraceLogging.ErrorLogMethods.LogError(ex, "SurescriptsLibrary\RefillResponse.UpdateRefillRequestSS(ByVal lClinicConnectionString As String, ByVal lMessageId As String, ByVal lRxId As String) ")
            ''End Try

        End Function

        Public Function AddMessageHdr(ByRef lConnection As Connection, _
                                      ByVal lDirection As String, _
                                      ByVal lCode As Long, _
                                      ByVal lFileName As String) As Boolean

            Dim lStatus As Boolean
            Dim lQuery As String

            Try
                lQuery = "Insert Into MessageHdr (" _
                   & "MessageCode, MessageId, MessageTypeId, LastStatus," _
                   & "XMLPath, ClinicId, UserId, " _
                   & "PrescriberOrderNo, RxReferenceNo, " _
                   & "RelatesToMessageId, Direction, XMLContents, PharmacyCode) " _
                   & "VALUES(" _
                   & lCode & ", " _
                   & "'" & Me.Header.MesssageID & "', " _
                   & "7," _
                   & "'Pending'," _
                   & "'" & lFileName & "'," _
                   & "'" & Me.LocalDB.ClinicCode & "'," _
                   & "'" & Me.RefillResponse.Prescriber.Identification.SPI & "'," _
                   & "'" & Me.RefillResponse.PrescribedOrderNumber & "'," _
                   & "'" & Me.RefillResponse.RxReferenceNumber & "'," _
                   & "'" & Me.Header.RelatesToMessageID & "'," _
                   & "'" & lDirection & "', " _
                   & "'', " _
                   & "'" & Me.RefillResponse.Pharmacy.Identification.NCPDPID & "')"


                If lConnection.IsTransactionAlive Then
                    lConnection.ExecuteTransactionCommand(lQuery)
                Else
                    lConnection.ExecuteCommand(lQuery)
                End If


            Catch ex As Exception
                Throw New Exception(ex.Message + " : SurescriptsLibrary\RefillResponse.AddMessageHdr(ByRef lConnection As Connection, ByVal lDirection As String, ByVal lCode As Long, ByVal lFileName As String) ")
            End Try

            AddMessageHdr = True

        End Function

        Public Function AddMessageDtl(ByRef lConnection As Connection, _
                                      ByVal lDirection As String, _
                                      ByVal lCode As Long) As Boolean

            Dim lStatus As Boolean
            Dim lQuery As String

            Try
                lQuery = "INSERT INTO MessageDtl(MessageCode, MessageTime, " _
                   & "Status, Code, DescriptionCode, " _
                   & "[Description],Direction,ReceivedMessageId, DetailMessageType) " _
                   & "VALUES(" _
                   & " " & lCode & ", " _
                   & "'" & Left(Me.Header.SentTime.UtcDate, 19) & "', " _
                   & "'Pending'," _
                   & "''," _
                   & "''," _
                   & "''," _
                   & "'O'," _
                   & "'',7)"

                If lConnection.IsTransactionAlive Then
                    lConnection.ExecuteTransactionCommand(lQuery)
                Else
                    lConnection.ExecuteCommand(lQuery)
                End If


            Catch ex As Exception
                Throw New Exception(ex.Message + " : SurescriptsLibrary\RefillResponse.AddMessageDtl(ByRef lConnection As Connection,ByVal lDirection As String, ByVal lCode As Long) ")
            End Try


            AddMessageDtl = True

        End Function


        Public Function GetMessageID(ByRef lConnection As Connection, ByRef lMsgId As String, ByVal lRxId As String) As String

            Dim lDs As DataSet
            Dim lMessageCode As String = ""
            Dim lMessageNo As Integer = 0
            Dim lStatus As Boolean
            Dim lQuery As String

            'lRxId = "RxCure-PO-" & lRxId.PadLeft(9, "0")

            Try
                If lMsgId <> "" Then

                    lQuery = "Select * From MessageHdr Where MessageId ='" & lMsgId & "' " _
                           & "And PrescriberOrderNo ='" & lRxId & "' " _
                           & "And Direction = 'O' "

                    If lConnection.IsTransactionAlive Then
                        lDs = lConnection.ExecuteTransactionQuery(lQuery)
                    Else
                        lDs = lConnection.ExecuteQuery(lQuery)
                    End If

                    If lDs.Tables.Count > 0 Then
                        If lDs.Tables(0).Rows.Count > 0 Then
                            lMessageCode = lDs.Tables(0).Rows(0).Item("MessageCode")
                        End If
                    End If

                Else

                    lQuery = "Select MessageIdNumeric+1 As MsgId, Prefix from NumSeries "
                    If lConnection.IsTransactionAlive Then
                        lDs = lConnection.ExecuteTransactionQuery(lQuery)
                    Else
                        lDs = lConnection.ExecuteQuery(lQuery)
                    End If
                    If lDs.Tables.Count > 0 Then
                        lMsgId = CType(lDs.Tables(0).Rows(0)("Prefix"), String) & "-" _
                               & CType(lDs.Tables(0).Rows(0)("MsgId"), String).PadLeft(10, "0")

                        lMessageNo = lDs.Tables(0).Rows(0)("MsgId")
                    End If

                    lQuery = "Update NumSeries Set CurrentMessageId ='" & lMsgId & "', " _
                           & "MessageIdNumeric = " & lMessageNo & " "
                    If lConnection.IsTransactionAlive Then
                        lConnection.ExecuteTransactionCommand(lQuery)
                    Else
                        lConnection.ExecuteCommand(lQuery)
                    End If


                    lQuery = "Select IsNull(Max(MessageCode),0) + 1  AS MessageCode From MessageHdr "
                    If lConnection.IsTransactionAlive Then
                        lDs = lConnection.ExecuteTransactionQuery(lQuery)
                    Else
                        lDs = lConnection.ExecuteQuery(lQuery)
                    End If
                    If lDs.Tables.Count > 0 Then
                        lMessageCode = CType(lDs.Tables(0).Rows(0)("MessageCode"), String)
                    End If

                End If

            Catch ex As Exception
                Throw New Exception(ex.Message + " : SurescriptsLibrary\RefillResponse.GetMessageID(ByRef lConnection As Connection, ByRef lMsgId As String, ByVal lRxId As String) ")
            End Try


            GetMessageID = lMessageCode
        End Function

#End Region
    End Class
End Namespace

