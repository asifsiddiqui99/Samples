Imports System.Configuration
Imports System.Data.SqlClient
Imports System.xml
Imports System.IO
Imports System.Text
Imports ElixirLibrary

Namespace SureScripts

    Public Class SubElementType

    End Class

    Public Class NewRxType
        Private mRxReferenceNumber As String = ""
        Private mPrescriberOrderNumber As String = ""
        Private mPharmacy As PharmacyType = New PharmacyType
        Private mPrescriber As PrescriberType = New PrescriberType
        Private mSupervisor As SupervisorType = New SupervisorType
        Private mPatient As PatientType = New PatientType
        Private mMedicationPrescribed As NewRXMedicationType = New NewRXMedicationType

        Public Property RxReferenceNumber() As String
            Get
                Return mRxReferenceNumber
            End Get
            Set(ByVal Value As String)
                mRxReferenceNumber = Value
            End Set
        End Property

        Public Property PrescriberOrderNumber() As String
            Get
                Return mPrescriberOrderNumber
            End Get
            Set(ByVal Value As String)
                mPrescriberOrderNumber = Value
            End Set
        End Property

        Public Property Pharmacy() As PharmacyType
            Get
                Return mPharmacy
            End Get
            Set(ByVal Value As PharmacyType)
                mPharmacy = Value
            End Set
        End Property

        Public Property Prescriber() As PrescriberType
            Get
                Return mPrescriber
            End Get
            Set(ByVal Value As PrescriberType)
                mPrescriber = Value
            End Set
        End Property

        Public Property Supervisor() As SupervisorType
            Get
                Return mSupervisor
            End Get
            Set(ByVal Value As SupervisorType)
                mSupervisor = Value
            End Set
        End Property

        Public Property Patient() As PatientType
            Get
                Return mPatient
            End Get
            Set(ByVal Value As PatientType)
                mPatient = Value
            End Set
        End Property

        Public Property MedicationPrescribed() As NewRXMedicationType
            Get
                Return mMedicationPrescribed
            End Get
            Set(ByVal Value As NewRXMedicationType)
                mMedicationPrescribed = Value
            End Set
        End Property

    End Class

    Public Class HeaderType
        Private mTo As MailAddressType = New MailAddressType("")
        Private mFrom As MailAddressType = New MailAddressType("") '6901147812001.spi
        Private mMessageID As String = ""
        Private mRelatesToMessageID As String = ""
        Private mSentTime As UtcDateType = New UtcDateType

        Public Property [To]() As MailAddressType
            Get
                Return mTo
            End Get
            Set(ByVal Value As MailAddressType)
                mTo = Value
            End Set
        End Property

        Public Property From() As MailAddressType
            Get
                Return mFrom
            End Get
            Set(ByVal Value As MailAddressType)
                mFrom = Value
            End Set
        End Property

        Public Property MesssageID() As String
            Get
                Return mMessageID
            End Get
            Set(ByVal Value As String)
                mMessageID = Value
            End Set
        End Property

        Public Property RelatesToMessageID() As String
            Get
                Return mRelatesToMessageID
            End Get
            Set(ByVal Value As String)
                mRelatesToMessageID = Value
            End Set
        End Property

        Public Property SentTime() As UtcDateType
            Get
                Return mSentTime
            End Get
            Set(ByVal Value As UtcDateType)
                mSentTime = Value
            End Set
        End Property

    End Class

    Public Class MailAddressType
        Private mMailAddress As String = ""
        Public Property MailAddress() As String
            Get
                Return mMailAddress
            End Get
            Set(ByVal Value As String)
                'mMailAddress = "mailto:" & Value & "@surescripts.com"
                mMailAddress = Value
            End Set
        End Property
        Public Sub New(ByVal address As String)
            Me.MailAddress = address
        End Sub
    End Class

    Public Class RefillRequestType
#Region "Instance Variables"

        Private mRxReferenceNumber As String = ""
        Private mPrescriberOrderNumber As String = ""
        Private mPharmacy As MandatoryPharmacyType = New MandatoryPharmacyType
        Private mPrescriber As PrescriberType = New PrescriberType
        Private mSupervisor As SupervisorType = New SupervisorType
        Private mPatient As PatientType = New PatientType
        Private mMedicationPrescribed As MedicationType = New MedicationType

        Private mHeader As HeaderType = New HeaderType
        'Private mNewRx As NewRxType = New NewRxType
        'Private mLocaldb As LocalDBType = New LocalDBType
        Private mConnectionString As String = ""
#End Region

        Public Property RxReferencenumber() As String
            Get
                Return mRxReferenceNumber
            End Get
            Set(ByVal Value As String)
                mRxReferenceNumber = Value
            End Set
        End Property

        Public Property PrescriberOrderNumber() As String
            Get
                Return mPrescriberOrderNumber
            End Get
            Set(ByVal Value As String)
                mPrescriberOrderNumber = Value
            End Set
        End Property

        Public Property Pharmacy() As MandatoryPharmacyType
            Get
                Return mPharmacy
            End Get
            Set(ByVal Value As MandatoryPharmacyType)
                mPharmacy = Value
            End Set
        End Property
        Public Property Prescriber() As PrescriberType
            Get
                Return mPrescriber
            End Get
            Set(ByVal Value As PrescriberType)
                mPrescriber = Value
            End Set
        End Property
        Public Property Supervisor() As SupervisorType
            Get
                Return mSupervisor
            End Get
            Set(ByVal Value As SupervisorType)
                mSupervisor = Value
            End Set
        End Property
        Public Property Patient() As PatientType
            Get
                Return mPatient
            End Get
            Set(ByVal Value As PatientType)
                mPatient = Value
            End Set
        End Property
        Public Property MedicationPrescribed() As MedicationType
            Get
                Return mMedicationPrescribed
            End Get
            Set(ByVal Value As MedicationType)
                mMedicationPrescribed = Value
            End Set
        End Property
        Public Property Header() As HeaderType
            Get
                Return mHeader
            End Get
            Set(ByVal Value As HeaderType)
                mHeader = Value
            End Set
        End Property
        Public Property ConnectionString() As String
            Get
                Return mConnectionString
            End Get
            Set(ByVal Value As String)
                mConnectionString = Value
            End Set
        End Property

        

        Private Sub GetNode(ByVal tree As XmlNode)
            Dim lDate As String
            Dim lName As String = tree.Name.ToUpper
            Dim lParent As String = tree.ParentNode.Name.ToUpper
            Dim lGrandParent As String
            Dim lGrandGrandParent As String
            Static lPharmacyPhoneCounter As Integer
            Static lPatientPhoneCounter As Integer
            Static lPrescriberPhoneCounter As Integer


            Try
                If Not tree.ParentNode.ParentNode Is Nothing Then
                    lGrandParent = tree.ParentNode.ParentNode.Name.ToUpper

                    If Not tree.ParentNode.ParentNode.ParentNode Is Nothing Then
                        lGrandGrandParent = tree.ParentNode.ParentNode.ParentNode.Name.ToUpper
                    Else
                        lGrandGrandParent = "MESSAGE"
                    End If
                Else
                    lGrandParent = "MESSAGE"
                    lGrandGrandParent = "MESSAGE"
                End If



                If lGrandParent = "MESSAGE" And lParent = "HEADER" Then
                    Select Case lName
                        Case "TO"
                            Me.Header.To.MailAddress = tree.InnerText
                        Case "FROM"
                            Me.Header.From.MailAddress = tree.InnerText
                        Case "MESSAGEID"
                            Me.Header.MesssageID = tree.InnerText
                        Case "SENTTIME"
                            Me.Header.SentTime.UtcDate = tree.InnerText
                    End Select
                ElseIf lGrandParent = "BODY" And lParent = "REFILLREQUEST" Then
                    Select Case lName
                        Case "RXREFERENCENUMBER"
                            Me.RxReferencenumber = tree.InnerText
                        Case "PRESCRIBERORDERNUMBER"
                            Me.PrescriberOrderNumber = tree.InnerText
                    End Select
                ElseIf lGrandParent = "PHARMACY" And lParent = "IDENTIFICATION" Then
                    Select Case lName
                        Case "NCPDPID"
                            Me.Pharmacy.Identification.NCPDPID = tree.InnerText
                        Case "FILEID"
                            Me.Pharmacy.Identification.FileID = tree.InnerText
                        Case "STATELICENSENUMBER"
                            Me.Pharmacy.Identification.StateLicenseNumber = tree.InnerText
                        Case "MEDICARENUMBER"
                            Me.Pharmacy.Identification.MedicareNumber = tree.InnerText
                        Case "MEDICAIDNUMBER"
                            Me.Pharmacy.Identification.MediCaidNumber = tree.InnerText
                        Case "PPONUMBER"
                            Me.Pharmacy.Identification.PPONumber = tree.InnerText
                        Case "PAYERID"
                            Me.Pharmacy.Identification.PayerId = tree.InnerText
                        Case "BINLOCATIONNUMBER"
                            Me.Pharmacy.Identification.BINLocationNumber = tree.InnerText
                        Case "DEANUMBER"
                            Me.Pharmacy.Identification.DEANumber = tree.InnerText
                        Case "HIN"
                            Me.Pharmacy.Identification.HIN = tree.InnerText
                        Case "SECONDARYCOVERAGE"
                            Me.Pharmacy.Identification.SecondaryCoverage = tree.InnerText
                        Case "NAICCODE"
                            Me.Pharmacy.Identification.NAICode = tree.InnerText
                        Case "PROMOTIONNUMBER"
                            Me.Pharmacy.Identification.PromotionNumber = tree.InnerText
                        Case "SOCIALSECURITY"
                            Me.Pharmacy.Identification.SocialSecurity = tree.InnerText
                        Case "NPI"
                            Me.Pharmacy.Identification.NPI = tree.InnerText
                        Case "PRIORAUTHORIZATION"
                            Me.Pharmacy.Identification.PriorAuthorization = tree.InnerText

                    End Select
                ElseIf lGrandParent = "REFILLREQUEST" And lParent = "PHARMACY" Then
                    Select Case lName
                        Case "STORENAME"
                            Me.Pharmacy.StoreName = tree.InnerText
                        Case "EMAIL"
                            Me.Pharmacy.Email = tree.InnerText
                    End Select
                ElseIf lGrandParent = "PHARMACY" And lParent = "PHARMACIST" Then
                    Select Case lName
                        Case "LASTNAME"
                            Me.Pharmacy.Pharmacist.LastName = tree.InnerText
                        Case "FIRSTNAME"
                            Me.Pharmacy.Pharmacist.FirstName = tree.InnerText
                        Case "MIDDLENAME"
                            Me.Pharmacy.Pharmacist.MiddleName = tree.InnerText
                        Case "SUFFIX"
                            Me.Pharmacy.Pharmacist.Suffix = tree.InnerText
                        Case "PREFIX"
                            Me.Pharmacy.Pharmacist.Prefix = tree.InnerText

                    End Select
                ElseIf lGrandParent = "PHARMACY" And lParent = "PHARMACISTAGENT" Then
                    Select Case lName
                        Case "LASTNAME"
                            Me.Pharmacy.PharmacistAgent.LastName = tree.InnerText
                        Case "FIRSTNAME"
                            Me.Pharmacy.PharmacistAgent.FirstName = tree.InnerText
                        Case "MIDDLENAME"
                            Me.Pharmacy.PharmacistAgent.MiddleName = tree.InnerText
                        Case "SUFFIX"
                            Me.Pharmacy.PharmacistAgent.Suffix = tree.InnerText
                        Case "PREFIX"
                            Me.Pharmacy.PharmacistAgent.Prefix = tree.InnerText
                    End Select

                ElseIf lGrandParent = "PHARMACY" And lParent = "ADDRESS" Then
                    Select Case lName
                        Case "ADDRESSLINE1"
                            Me.Pharmacy.Address.AddressLine1 = tree.InnerText
                        Case "ADDRESSLINE2"
                            Me.Pharmacy.Address.AddressLine2 = tree.InnerText
                        Case "CITY"
                            Me.Pharmacy.Address.City = tree.InnerText
                        Case "STATE"
                            Me.Pharmacy.Address.State = tree.InnerText
                        Case "ZIPCODE"
                            Me.Pharmacy.Address.ZipCode = tree.InnerText
                    End Select
                ElseIf lGrandGrandParent = "PHARMACY" And lGrandParent = "PHONENUMBERS" And lParent = "PHONE" Then
                    Select Case lName
                        Case "NUMBER"
                            Dim tempPhone As New SureScriptsLibrary.SureScripts.PhoneType
                            If lPharmacyPhoneCounter = 0 Then
                                tempPhone.Number = tree.InnerText
                                Me.Pharmacy.PhoneNumbers.Phone = New SureScriptsLibrary.SureScripts.PhoneType(0) {tempPhone}
                            ElseIf lPharmacyPhoneCounter = 1 Then
                                tempPhone.Number = tree.InnerText
                                Me.Pharmacy.PhoneNumbers.Phone = New SureScriptsLibrary.SureScripts.PhoneType(1) {Me.Pharmacy.PhoneNumbers.Phone(0), tempPhone}
                            Else
                                tempPhone.Number = tree.InnerText
                                Me.Pharmacy.PhoneNumbers.Phone = New SureScriptsLibrary.SureScripts.PhoneType(2) {Me.Pharmacy.PhoneNumbers.Phone(0), Me.Pharmacy.PhoneNumbers.Phone(1), tempPhone}
                            End If

                        Case "QUALIFIER"
                            If lPharmacyPhoneCounter = 0 Then
                                Me.Pharmacy.PhoneNumbers.Phone(0).Qualifier = tree.InnerText
                                lPharmacyPhoneCounter = lPharmacyPhoneCounter + 1
                            ElseIf lPharmacyPhoneCounter = 1 Then
                                Me.Pharmacy.PhoneNumbers.Phone(1).Qualifier = tree.InnerText
                                lPharmacyPhoneCounter = lPharmacyPhoneCounter + 1
                            Else
                                Me.Pharmacy.PhoneNumbers.Phone(2).Qualifier = tree.InnerText
                                lPharmacyPhoneCounter = lPharmacyPhoneCounter + 1
                            End If
                    End Select
                    ''''''''' **** PRESCRIBER STARTS HERE ****''''''''''''''''''
                ElseIf lGrandGrandParent = "REFILLREQUEST" And lGrandParent = "PRESCRIBER" And lParent = "IDENTIFICATION" Then
                    Select Case lName
                        Case "SPI"
                            Me.Prescriber.Identification.SPI = tree.InnerText
                        Case "SOCIALSECURITY"
                            Me.Prescriber.Identification.SocialSecurity = tree.InnerText
                        Case "FILEID"
                            Me.Prescriber.Identification.FileID = tree.InnerText
                        Case "STATELICENSENUMBER"
                            Me.Prescriber.Identification.StateLicenseNumber = tree.InnerText
                        Case "MEDICARENUMBER"
                            Me.Prescriber.Identification.MedicareNumber = tree.InnerText
                        Case "MEDICAIDNUMBER"
                            Me.Prescriber.Identification.MedicaidNumber = tree.InnerText
                        Case "DENTISTLICENSENUMBER"
                            Me.Prescriber.Identification.DentisiLicenseNumber = tree.InnerText
                        Case "UPIN"
                            Me.Prescriber.Identification.UPIN = tree.InnerText
                        Case "PPONUMBER"
                            Me.Prescriber.Identification.PPONumber = tree.InnerText
                        Case "DEANUMBER"
                            Me.Prescriber.Identification.DEANumber = tree.InnerText
                        Case "NPI"
                            Me.Prescriber.Identification.NPI = tree.InnerText
                        Case "PRIORAUTHORIZATION"
                            Me.Prescriber.Identification.PriorAuthorization = tree.InnerText
                    End Select

                ElseIf lGrandGrandParent = "REFILLREQUEST" And lGrandParent = "PRESCRIBER" And lParent = "NAME" Then
                    Select Case lName
                        Case "LASTNAME"
                            Me.Prescriber.Name.LastName = tree.InnerText
                        Case "FIRSTNAME"
                            Me.Prescriber.Name.FirstName = tree.InnerText
                        Case "MIDDLENAME"
                            Me.Prescriber.Name.MiddleName = tree.InnerText
                        Case "SUFFIX"
                            Me.Prescriber.Name.Suffix = tree.InnerText
                        Case "PREFIX"
                            Me.Prescriber.Name.Prefix = tree.InnerText
                    End Select
                ElseIf lGrandGrandParent = "REFILLREQUEST" And lGrandParent = "PRESCRIBER" And lParent = "SPECIALTY" Then
                    Select Case lName
                        Case "QUALIFIER"
                            Me.Prescriber.Specialty.Qualifier = tree.InnerText
                        Case "SPECIALTYCODE"
                            Me.Prescriber.Specialty.SpecialtyCode = tree.InnerText
                    End Select
                ElseIf lGrandGrandParent = "REFILLREQUEST" And lGrandParent = "PRESCRIBER" And lParent = "PRESCRIBERAGENT" Then
                    Select Case lName
                        Case "LASTNAME"
                            Me.Prescriber.PrescriberAgent.LastName = tree.InnerText
                        Case "FIRSTNAME"
                            Me.Prescriber.PrescriberAgent.FirstName = tree.InnerText
                        Case "MIDDLENAME"
                            Me.Prescriber.PrescriberAgent.MiddleName = tree.InnerText
                        Case "SUFFIX"
                            Me.Prescriber.PrescriberAgent.Suffix = tree.InnerText
                        Case "PREFIX"
                            Me.Prescriber.PrescriberAgent.Prefix = tree.InnerText
                    End Select
                ElseIf lGrandGrandParent = "REFILLREQUEST" And lGrandParent = "PRESCRIBER" And lParent = "ADDRESS" Then
                    Select Case lName
                        Case "ADDRESSLINE1"
                            Me.Prescriber.Address.AddressLine1 = tree.InnerText
                        Case "ADDRESSLINE2"
                            Me.Prescriber.Address.AddressLine2 = tree.InnerText
                        Case "CITY"
                            Me.Prescriber.Address.City = tree.InnerText
                        Case "STATE"
                            Me.Prescriber.Address.State = tree.InnerText
                        Case "ZIPCODE"
                            Me.Prescriber.Address.ZipCode = tree.InnerText
                    End Select
                ElseIf lGrandParent = "REFILLREQUEST" And lParent = "PRESCRIBER" Then
                    Select Case lName
                        Case "EMAIL"
                            Me.Prescriber.Email = tree.InnerText
                        Case "CLINICNAME"
                            Me.Prescriber.ClinicName = tree.InnerText
                    End Select
                ElseIf lGrandGrandParent = "PRESCRIBER" And lGrandParent = "PHONENUMBERS" And lParent = "PHONE" Then
                    Select Case lName
                        Case "NUMBER"
                            Dim tempPhone As New SureScriptsLibrary.SureScripts.PhoneType
                            If lPrescriberPhoneCounter = 0 Then
                                tempPhone.Number = tree.InnerText
                                Me.Prescriber.PhoneNumbers.Phone = New SureScriptsLibrary.SureScripts.PhoneType(0) {tempPhone}
                            ElseIf lPrescriberPhoneCounter = 1 Then
                                tempPhone.Number = tree.InnerText
                                Me.Prescriber.PhoneNumbers.Phone = New SureScriptsLibrary.SureScripts.PhoneType(1) {Me.Prescriber.PhoneNumbers.Phone(0), tempPhone}
                            Else
                                tempPhone.Number = tree.InnerText
                                Me.Prescriber.PhoneNumbers.Phone = New SureScriptsLibrary.SureScripts.PhoneType(2) {Me.Prescriber.PhoneNumbers.Phone(0), Me.Prescriber.PhoneNumbers.Phone(1), tempPhone}
                            End If
                        Case "QUALIFIER"
                            If lPrescriberPhoneCounter = 0 Then
                                Me.Prescriber.PhoneNumbers.Phone(0).Qualifier = tree.InnerText
                                lPrescriberPhoneCounter = lPrescriberPhoneCounter + 1
                            ElseIf lPrescriberPhoneCounter = 1 Then
                                Me.Prescriber.PhoneNumbers.Phone(1).Qualifier = tree.InnerText
                                lPrescriberPhoneCounter = lPrescriberPhoneCounter + 1
                            Else
                                Me.Prescriber.PhoneNumbers.Phone(2).Qualifier = tree.InnerText
                                lPrescriberPhoneCounter = lPrescriberPhoneCounter + 1
                            End If
                    End Select
                    ''''''''' **** PATIENT STARTS HERE ****''''''''''''''''''
                ElseIf lGrandGrandParent = "REFILLREQUEST" And lGrandParent = "PATIENT" And lParent = "IDENTIFICATION" Then
                    Select Case lName
                        Case "SOCIALSECURITY"
                            Me.Patient.Identification.SocialSecurity = tree.InnerText
                            'Case "MEDICARENUMBER"
                            '    Me.Patient.Identification.MedicaidNumber = tree.InnerText
                        Case "FILEID"
                            Me.Patient.Identification.FileID = tree.InnerText
                        Case "MEDICARENUMBER"
                            Me.Patient.Identification.MedicalcareNumber = tree.InnerText
                        Case "MEDICAIDNUMBER"
                            Me.Patient.Identification.MedicaidNumber = tree.InnerText
                        Case "PPONUMBER"
                            Me.Patient.Identification.PPONumber = tree.InnerText
                        Case "SOCIALSECURITY"
                            Me.Patient.Identification.SocialSecurity = tree.InnerText
                    End Select
                ElseIf lGrandGrandParent = "REFILLREQUEST" And lGrandParent = "PATIENT" And lParent = "NAME" Then
                    Select Case lName
                        Case "LASTNAME"
                            Me.Patient.Name.LastName = tree.InnerText
                        Case "FIRSTNAME"
                            Me.Patient.Name.FirstName = tree.InnerText
                        Case "MIDDLENAME"
                            Me.Patient.Name.MiddleName = tree.InnerText
                        Case "SUFFIX"
                            Me.Patient.Name.Suffix = tree.InnerText
                        Case "PREFIX"
                            Me.Patient.Name.Prefix = tree.InnerText
                    End Select
                ElseIf lGrandParent = "REFILLREQUEST" And lParent = "PATIENT" Then
                    Select Case lName
                        Case "GENDER"
                            If tree.InnerText = "M" Then
                                Me.Patient.Gender = GenderType.M
                            ElseIf tree.InnerText = "F" Then
                                Me.Patient.Gender = GenderType.F
                            Else
                                Me.Patient.Gender = GenderType.U
                            End If
                        Case "EMAIL"
                            Me.Patient.Email = tree.InnerText
                        Case "DATEOFBIRTH"
                            lDate = Mid(tree.InnerText, 5, 2) + "-"
                            lDate = lDate + Right(tree.InnerText, 2) + "-"
                            lDate = lDate + Left(tree.InnerText, 4)
                            Me.Patient.DateOfBirth.Date = lDate

                    End Select
                ElseIf lGrandGrandParent = "REFILLREQUEST" And lGrandParent = "PATIENT" And lParent = "ADDRESS" Then
                    Select Case lName
                        Case "ADDRESSLINE1"
                            Me.Patient.Address.AddressLine1 = tree.InnerText
                        Case "ADDRESSLINE2"
                            Me.Patient.Address.AddressLine2 = tree.InnerText
                        Case "CITY"
                            Me.Patient.Address.City = tree.InnerText
                        Case "STATE"
                            Me.Patient.Address.State = tree.InnerText
                        Case "ZIPCODE"
                            Me.Patient.Address.ZipCode = tree.InnerText
                    End Select
                ElseIf lGrandGrandParent = "PATIENT" And lGrandParent = "PHONENUMBERS" And lParent = "PHONE" Then
                    Select Case lName
                        Case "NUMBER"
                            Dim tempPhone As New SureScriptsLibrary.SureScripts.PhoneType
                            If lPatientPhoneCounter = 0 Then
                                tempPhone.Number = tree.InnerText
                                Me.Patient.PhoneNumbers.Phone = New SureScriptsLibrary.SureScripts.PhoneType(0) {tempPhone}
                            ElseIf lPatientPhoneCounter = 1 Then
                                tempPhone.Number = tree.InnerText
                                Me.Patient.PhoneNumbers.Phone = New SureScriptsLibrary.SureScripts.PhoneType(1) {Me.Patient.PhoneNumbers.Phone(0), tempPhone}
                            Else
                                tempPhone.Number = tree.InnerText
                                Me.Patient.PhoneNumbers.Phone = New SureScriptsLibrary.SureScripts.PhoneType(2) {Me.Patient.PhoneNumbers.Phone(0), Me.Patient.PhoneNumbers.Phone(1), tempPhone}
                            End If
                        Case "QUALIFIER"
                            If lPatientPhoneCounter = 0 Then
                                Me.Patient.PhoneNumbers.Phone(0).Qualifier = tree.InnerText
                                lPatientPhoneCounter = lPatientPhoneCounter + 1
                            ElseIf lPatientPhoneCounter = 1 Then
                                Me.Patient.PhoneNumbers.Phone(1).Qualifier = tree.InnerText
                                lPatientPhoneCounter = lPatientPhoneCounter + 1
                            Else
                                Me.Patient.PhoneNumbers.Phone(2).Qualifier = tree.InnerText
                                lPatientPhoneCounter = lPatientPhoneCounter + 1
                            End If
                    End Select
                    ''''****MEDICATION PRESCRIBED ****'''''
                ElseIf lGrandGrandParent = "REFILLREQUEST" And lGrandParent = "MEDICATIONPRESCRIBED" And lParent = "DRUGCODED" Then
                    Select Case lName
                        Case "PRODUCTCODE"
                            Me.MedicationPrescribed.DrugCoded.ProductCode = tree.InnerText
                        Case "PRODUCTCODEQUALIFIER"
                            Me.MedicationPrescribed.DrugCoded.ProductCodeQualifier = tree.InnerText
                        Case "DOSAGEFORM"
                            Me.MedicationPrescribed.DrugCoded.DosageForm = tree.InnerText
                        Case "STRENGTH"
                            Me.MedicationPrescribed.DrugCoded.Strength = tree.InnerText
                        Case "STRENGTHUNITS"
                            Me.MedicationPrescribed.DrugCoded.StrengthUnits = tree.InnerText
                        Case "DRUGDBCODE"
                            Me.MedicationPrescribed.DrugCoded.DrugDBCode = tree.InnerText
                        Case "DRUGDBCODEQUALIFIER"
                            Me.MedicationPrescribed.DrugCoded.DrugDBCodeQualifier = tree.InnerText

                    End Select
                ElseIf lGrandGrandParent = "REFILLREQUEST" And lGrandParent = "MEDICATIONPRESCRIBED" And lParent = "QUANTITY" Then
                    Select Case lName
                        Case "QUALIFIER"
                            Me.MedicationPrescribed.Quantity.Qualifier = tree.InnerText
                        Case "VALUE"
                            Me.MedicationPrescribed.Quantity.Value = tree.InnerText
                    End Select
                ElseIf lGrandParent = "REFILLREQUEST" And lParent = "MEDICATIONPRESCRIBED" Then
                    Select Case lName
                        Case "DRUGDESCRIPTION"
                            Me.MedicationPrescribed.DrugDescription = tree.InnerText
                        Case "DAYSSUPPLY"
                            Me.MedicationPrescribed.DaysSupply = tree.InnerText
                        Case "DIRECTIONS"
                            Me.MedicationPrescribed.Directions = tree.InnerText
                        Case "SUBSTITUTIONS"
                            Me.MedicationPrescribed.Substitutions = tree.InnerText
                        Case "WRITTENDATE"
                            '''''

                            lDate = Mid(tree.InnerText, 5, 2) + "-"
                            lDate = lDate + Right(tree.InnerText, 2) + "-"
                            lDate = lDate + Left(tree.InnerText, 4)
                            Me.MedicationPrescribed.WrittenDate.Date = lDate
                            '''''
                            'Me.MedicationPrescribed.WrittenDate.Date = tree.InnerText
                        Case "LASTFILLDATE"

                            lDate = Mid(tree.InnerText, 5, 2) + "-"
                            lDate = lDate + Right(tree.InnerText, 2) + "-"
                            lDate = lDate + Left(tree.InnerText, 4)
                            Me.MedicationPrescribed.LastFillDate.Date = lDate
                            'Me.MedicationPrescribed.LastFillDate.Date = tree.InnerText
                        Case "NOTE"
                            Me.MedicationPrescribed.Note = tree.InnerText
                    End Select
                ElseIf lGrandGrandParent = "REFILLREQUEST" And lGrandParent = "MEDICATIONPRESCRIBED" And lParent = "REFILLS" Then
                    Select Case lName
                        Case "QUALIFIER"
                            Me.MedicationPrescribed.Refills.Qualifier = tree.InnerText
                        Case "QUANTITY"
                            Me.MedicationPrescribed.Refills.Quantity = tree.InnerText
                    End Select

                ElseIf lGrandParent = "MEDICATIONPRESCRIBED" And lParent = "DIAGNOSIS" Then
                    Select Case lName
                        Case "QUALIFIER"
                            Me.MedicationPrescribed.Diagnosis.Qualifier = tree.InnerText
                    End Select
                ElseIf lGrandGrandParent = "MEDICATIONPRESCRIBED" And lGrandParent = "DIAGNOSIS" And lParent = "PRIMARY" Then
                    Select Case lName
                        Case "QUALIFIER"
                            Me.MedicationPrescribed.Diagnosis.Primary.Qualifier = tree.InnerText
                        Case "VALUE"
                            Me.MedicationPrescribed.Diagnosis.Primary.Value = tree.InnerText
                    End Select
                ElseIf lGrandGrandParent = "MEDICATIONPRESCRIBED" And lGrandParent = "DIAGNOSIS" And lParent = "SECONDARY" Then
                    Select Case lName
                        Case "QUALIFIER"
                            Me.MedicationPrescribed.Diagnosis.Secondary.Qualifier = tree.InnerText
                        Case "VALUE"
                            Me.MedicationPrescribed.Diagnosis.Secondary.Value = tree.InnerText
                    End Select
                ElseIf lGrandGrandParent = "REFILLREQUEST" And lGrandParent = "MEDICATIONPRESCRIBED" And lParent = "PRIORAUTHORIZATION" Then
                    Select Case lName
                        Case "QUALIFIER"
                            Me.MedicationPrescribed.PriorAuthorization.Qualifier = tree.InnerText
                        Case "VALUE"
                            Me.MedicationPrescribed.PriorAuthorization.Value = tree.InnerText
                    End Select
                End If


            Catch ex As Exception
                Throw New Exception(ex.Message + " : SurescriptsLibrary\RefillRequestType.GetNode(ByVal tree As XmlNode) ")
            End Try

        End Sub

        Public Sub ParseTree(ByVal tree As XmlNode)
            Try

                If Not (tree Is Nothing) Then
                    GetNode(tree)
                End If
                If tree.HasChildNodes Then
                    tree = tree.FirstChild
                    While Not (tree Is Nothing)
                        ParseTree(tree)
                        tree = tree.NextSibling
                    End While
                End If

            Catch ex As Exception
                Throw New Exception(ex.Message + " : SurescriptsLibrary\RefillRequestType.ParseTree(ByVal tree As XmlNode) ")
            End Try
        End Sub


        Public Function ReadXML(ByVal xmldata As String) As RefillRequestType
            Dim xmld As New XmlDocument

            Try

                xmld.LoadXml(xmldata)
                ParseTree(xmld.DocumentElement)

            Catch ex As Exception
                Throw New Exception(ex.Message + " : SurescriptsLibrary\RefillRequestType.ReadXML(ByVal xmldata As String)  ")
            End Try

        End Function

        Public Function AddMessage(ByVal filename As String, ByVal lMsgId As String, ByVal lRxId As String, ByVal constr As String, ByVal lXMLContents As String) As String

            Dim flg As Boolean = False
            Dim lConnection As New Connection()
            'Dim lConnectionString As String
            'lConnectionString = ConfigurationSettings.AppSettings("connectionString")
            'If lConnectionString = "" Then
            '    lConnectionString = Me.ConnectionString
            'End If
            'Dim con As New SqlConnection(lConnectionString)

            Dim lQuery As String
            'Dim lTransaction As SqlTransaction

            Dim lResult As Boolean
            Dim lCode As String


            Dim lConnectionMaster As New SureScriptsLibrary.SureScripts.ConnectionMaster

            Try
                flg = lConnectionMaster.Get_ConnectionInformation_By_SPI(Me.Prescriber.Identification.SPI)
                If Not flg Then
                    Throw New Exception("Unable to get ConnectionInformation By SPI : SurescriptsLibrary\RefillRequestType.AddMessage(ByVal filename As String, ByVal lMsgId As String, ByVal lRxId As String, ByVal constr As String, ByVal lXMLContents As String) ")
                End If



                'con.Open()

                'lTransaction = con.BeginTransaction

                lConnection.BeginTrans()

                lResult = CheckDuplicateMessage(lConnection, Me.Header.MesssageID, Me.Pharmacy.Identification.NCPDPID)
                If lResult Then
                    Throw New Exception
                End If

                lCode = GetMessageCode(lConnection)
                If lCode = "" Then
                    Throw New Exception
                End If

                lResult = AddMessageHdr(lConnection, "I", lCode, filename, lConnectionMaster.ClinicID, lXMLContents)
                If Not lResult Then
                    Throw New Exception
                End If

                lResult = AddMessageDtl(lConnection, "I", lCode)

                If Not lResult Then
                    Throw New Exception
                End If

                If Me.PrescriberOrderNumber <> "" Then

                    'lResult = UpdatePatCurrent(lConnectionMaster.ConnectionString, lMsgId, lRxId)
                    'If Not lResult Then
                    '    Throw New Exception
                    'End If
                End If

                lConnection.CommitTrans()
                'lTransaction.Commit()
                AddMessage = lCode
            Catch ex As Exception
                lConnection.RollBackTrans()
                TraceLogging.ErrorLogMethods.LogError(ex, "SurescriptsLibrary\RefillRequestType.AddMessage(ByVal filename As String, ByVal lMsgId As String, ByVal lRxId As String, ByVal constr As String, ByVal lXMLContents As String) ")
                'lTransaction.Rollback()
                flg = False
                AddMessage = ""
            End Try
        End Function

        Public Function AddRefillRequest(ByVal lClinicConnectionString As String, ByVal lDrCode As String) As Boolean


            Dim lConnection As New Connection(lClinicConnectionString)
            'Dim lCommand As New SqlCommand
            Dim lQuery As String
            Dim lFillStatus As String
            Dim lPharmacyPhone As String = ""
            Dim lPharmacyPhoneQualifier As String = ""
            Dim lPatientPhone As String = ""
            Dim lPatientPhoneQualifier As String = ""


            If Not Me.Pharmacy.PhoneNumbers.Phone Is Nothing Then
                If Me.Pharmacy.PhoneNumbers.Phone.Length > 0 Then
                    lPharmacyPhone = Me.Pharmacy.PhoneNumbers.Phone(0).Number
                    lPharmacyPhoneQualifier = Me.Pharmacy.PhoneNumbers.Phone(0).Qualifier
                End If
            End If


            If Not Me.Patient.PhoneNumbers.Phone Is Nothing Then
                If Me.Patient.PhoneNumbers.Phone.Length > 0 Then
                    lPatientPhone = Me.Patient.PhoneNumbers.Phone(0).Number
                    lPatientPhoneQualifier = Me.Patient.PhoneNumbers.Phone(0).Qualifier
                End If
            End If

            If Me.MedicationPrescribed.Refills.Quantity = "" Then
                Me.MedicationPrescribed.Refills.Quantity = "0"
            End If
            If Me.MedicationPrescribed.Refills.Qualifier.Trim = "" Then
                Me.MedicationPrescribed.Refills.Qualifier = "R"
            End If
            


            Try

                lQuery = "Insert Into RenewalRequest " _
                       & "(RequestDate, MessageID, NCPDPID, PharmacyName, " _
                       & "PharmacyPhoneNo, PharmacyPhoneQualifier, DrugNDC, " _
                       & "Drug, Quantity, Sig, LastFillDate, WrittenDate, " _
                       & "DaysSupply, Substitution, Refills, RefillQualifier, " _
                       & "PharmacistMessage, PatientID, PatientName, PatientPhoneNo, " _
                       & "PatientPhoneQualifier, DoctorUserId, DoctorName, DoctorSPI, " _
                       & "DEA, IsSent, RelatesToMessageID, PharmacyReferenceNumber, " _
                       & "PrescriberOrderNumber, PharmacyProvider,PatientGender,PatientDOB,IsPrinted) " _
                       & "VALUES ( " _
                       & "'" & DateTime.Now.Date.ToString("MMM dd yyyy") & "'," _
                       & "'" & Me.Header.MesssageID & "'," _
                       & "'" & Me.Pharmacy.Identification.NCPDPID & "'," _
                       & "'" & Me.Pharmacy.StoreName.Replace("'", "''") & "'," _
                       & "'" & lPharmacyPhone & "'," _
                       & "'" & lPharmacyPhoneQualifier & "'," _
                       & "'" & Me.MedicationPrescribed.DrugCoded.ProductCode & "'," _
                       & "'" & Me.MedicationPrescribed.DrugDescription.Replace("'", "''") & "'," _
                       & " " & IIf(Me.MedicationPrescribed.Quantity.Value = "", "-1", Me.MedicationPrescribed.Quantity.Value) & "," _
                       & "'" & Me.MedicationPrescribed.Directions.Replace("'", "''") & "'," _
                       & "'" & Me.MedicationPrescribed.LastFillDate.Date & "'," _
                       & "'" & Me.MedicationPrescribed.WrittenDate.Date & "'," _
                       & " " & IIf(Me.MedicationPrescribed.DaysSupply = "", "-1", Me.MedicationPrescribed.DaysSupply) & "," _
                       & "'" & Me.MedicationPrescribed.Substitutions & "'," _
                       & " " & IIf(Me.MedicationPrescribed.Refills.Quantity.Trim = "", "0", Me.MedicationPrescribed.Refills.Quantity) & "," _
                       & "'" & IIf(Me.MedicationPrescribed.Refills.Qualifier.Trim = "", "R", Me.MedicationPrescribed.Refills.Qualifier) & "'," _
                       & "'" & Me.MedicationPrescribed.Note.Replace("'", "''") & "'," _
                       & "'" & Me.Patient.Identification.SocialSecurity & "'," _
                       & "'" & Me.Patient.Name.LastName.Replace("'", "''") & ", " & Me.Patient.Name.FirstName.Replace("'", "''") & "'," _
                       & "'" & lPatientPhone & "'," _
                       & "'" & lPatientPhoneQualifier & "'," _
                       & " " & lDrCode & "," _
                       & "'" & Me.Prescriber.Name.LastName.Replace("'", "''") & ", " & Me.Prescriber.Name.FirstName.Replace("'", "''") & "'," _
                       & "'" & Me.Prescriber.Identification.SPI & "'," _
                       & "''," _
                       & "'N'," _
                       & "''," _
                       & "'" & Me.RxReferencenumber & "'," _
                       & "'" & Me.PrescriberOrderNumber & "'," _
                       & "'S','" & IIf(Me.Patient.Gender = GenderType.M, "M", "F") & "'," _
                       & "'" & IIf(Me.Patient.DateOfBirth.Date <> "", Me.Patient.DateOfBirth.Date, "1/1/1900") & "',0)"

                lConnection.ExecuteCommand(lQuery)
                'lConnection.Open()
                'lCommand.CommandText = lQuery
                'lCommand.Connection = lConnection
                'lCommand.ExecuteNonQuery()

                'lConnection.Close()
                AddRefillRequest = True
            Catch ex As Exception
                Throw New Exception(ex.Message + " : SurescriptsLibrary\RefillRequestType.AddRefillRequest(ByVal lClinicConnectionString As String, ByVal lDrCode As String) ")
                AddRefillRequest = False
            End Try

        End Function

        Public Function AddMessageHdr(ByVal lConnection As Connection, _
                                      ByVal lDirection As String, _
                                      ByVal lCode As String, _
                                      ByVal lFileName As String, ByVal lClinicID As String, ByVal lXMLContents As String) As Boolean

            Dim lStatus As Boolean
            Dim lQuery As String


            Try

                lQuery = "Insert Into MessageHdr (" _
                       & "MessageCode, MessageId, MessageTypeId, LastStatus," _
                       & "XMLPath, ClinicId, UserId, " _
                       & "PrescriberOrderNo, RxReferenceNo, " _
                       & "RelatesToMessageId, Direction, XMLContents, PharmacyCode) " _
                       & "VALUES(" _
                       & lCode & ", " _
                       & "'" & Me.Header.MesssageID & "', " _
                       & "6," _
                       & "'Success'," _
                       & "'" & lFileName & "'," _
                       & "'" & lClinicID & "'," _
                       & "'" & Me.Prescriber.Identification.SPI & "'," _
                       & "'" & Me.PrescriberOrderNumber & "'," _
                       & "'" & Me.RxReferencenumber & "'," _
                       & "''," _
                       & "'" & lDirection & "', " _
                       & "'" & lXMLContents.Replace("'", "''") & "', " _
                       & "'" & Me.Pharmacy.Identification.NCPDPID & "')"
                'lXMLContents

                'lStatus = DBClass.ExecuteUpdate(lQuery, lTransaction)
                lConnection.ExecuteTransactionCommand(lQuery)

                AddMessageHdr = True
            Catch ex As Exception
                Throw New Exception(ex.Message + " : SurescriptsLibrary\RefillRequestType.AddMessageHdr(ByVal lConnection As Connection,ByVal lDirection As String,ByVal lCode As String, ByVal lFileName As String, ByVal lClinicID As String, ByVal lXMLContents As String)  ")
                AddMessageHdr = False
            End Try


        End Function

        Public Function AddMessageDtl(ByVal lConnection As Connection, _
                                      ByVal lDirection As String, _
                                      ByVal lCode As String) As Boolean


            Dim lQuery As String

            Try

                lQuery = "INSERT INTO MessageDtl(MessageCode, MessageTime, " _
                       & "Status, Code, DescriptionCode, " _
                       & "[Description],Direction,ReceivedMessageId, DetailMessageType) " _
                       & "VALUES(" _
                       & " " & lCode & ", " _
                       & "'" & CDate(Me.Header.SentTime.UtcDate) & "', " _
                       & "'Success'," _
                       & "''," _
                       & "''," _
                       & "'" & Me.Header.MesssageID & "'," _
                       & "'" & lDirection & "'," _
                       & "'',6)"

                lConnection.ExecuteTransactionCommand(lQuery)
                AddMessageDtl = True
            Catch ex As Exception
                Throw New Exception(ex.Message + " : SurescriptsLibrary\RefillRequestType.AddMessageDtl(ByVal lConnection As Connection,ByVal lDirection As String,ByVal lCode As String) ")
                AddMessageDtl = False
            End Try



        End Function

        
        Private Function CheckDuplicateMessage(ByVal lConnection As Connection, _
                                               ByVal lMessageId As String, _
                                               ByVal lPharmacyCode As String) As Boolean

            'Function Returns True If Message is Duplicate 

            Dim lDs As DataSet
            Dim lStatus As Boolean
            Dim lQuery As String
            Dim lCond As String

            Try

            
                lQuery = "Select * From MessageHdr " _
                       & "Where MessageId ='" & lMessageId & "' " _
                       & "And PharmacyCode ='" & lPharmacyCode & "' " _
                       & lCond


                lDs = lConnection.ExecuteTransactionQuery(lQuery)
                If lDs.Tables(0).Rows.Count > 0 Then
                    CheckDuplicateMessage = True
                Else
                    CheckDuplicateMessage = False
                End If

            Catch ex As Exception
                Throw New Exception(ex.Message + " : SurescriptsLibrary\RefillRequestType.CheckDuplicateMessage(ByVal lConnection As Connection,ByVal lMessageId As String,  ByVal lPharmacyCode As String) ")
            End Try

        End Function

        Public Function GetMessageCode(ByVal lConnection As Connection) As String

            Dim lDs As DataSet
            Dim lMessageCode As String = ""
            Dim lMessageNo As Integer = 0
            Dim lStatus As Boolean
            Dim lQuery As String

            Try

                lQuery = "Select IsNull(Max(MessageCode),0) + 1  AS MessageCode From MessageHdr "
                lDs = lConnection.ExecuteTransactionQuery(lQuery)
                'lDs = DBClass.ExecuteQuery(lQuery, lTransaction)
                If lDs.Tables.Count > 0 Then
                    lMessageCode = CType(lDs.Tables(0).Rows(0)("MessageCode"), String)
                End If
                GetMessageCode = lMessageCode

            Catch ex As Exception
                Throw New Exception(ex.Message + " : SurescriptsLibrary\RefillRequestType.GetMessageCode(ByVal lConnection As Connection) ")
            End Try

        End Function

        Public Function SaveStatus(ByVal RecMessage As ReceivedMessage, ByVal lMessageCode As String) As Boolean

            'Dim lConnectionString As String
            'lConnectionString = ConfigurationSettings.AppSettings("connectionString")
            'If lConnectionString = "" Then
            '    lConnectionString = Me.ConnectionString
            'End If
            'Dim con As New SqlConnection(lConnectionString)
            Dim lConnection As New Connection()

            'Dim lTransaction As SqlTransaction
            Dim lQuery As String
            Dim lDs As New DataSet
            Dim lStatus As Boolean
            Dim lMessageType As Integer
            Dim lCode As String
            Dim lDescriptionCode As String
            Dim lDescription As String

            Try
                'con.Open()
                'lTransaction = con.BeginTransaction

                lConnection.BeginTrans()


                If RecMessage.MessageType = "ERROR" Then
                    lMessageType = 1
                    lCode = RecMessage.ErrorType.Code
                    lDescriptionCode = RecMessage.ErrorType.DescriptionCode
                    lDescription = RecMessage.ErrorType.Description
                Else
                    lMessageType = 3
                    lCode = RecMessage.StatusType.Code
                    lDescriptionCode = ""
                    lDescription = RecMessage.StatusType.Description
                End If


                lQuery = "INSERT INTO MessageDtl(MessageCode, MessageTime, " _
                       & "Status, Code, DescriptionCode, " _
                       & "[Description],Direction,ReceivedMessageId,DetailMessageType) " _
                       & "VALUES(" _
                       & " " & lMessageCode & ", " _
                       & "'" & Left(RecMessage.HeaderType.SentTime.UtcDate, 19) & "', " _
                       & "'Success'," _
                       & "'" & lCode & "'," _
                       & "'" & lDescriptionCode & "'," _
                       & "'" & lDescription.Replace("'", "''") & " '," _
                       & "'O'," _
                       & "'0'," _
                       & " " & lMessageType & ")"

                lConnection.ExecuteTransactionCommand(lQuery)

                lConnection.CommitTrans()
                SaveStatus = lStatus

            Catch ex As Exception

                lConnection.RollBackTrans()
                TraceLogging.ErrorLogMethods.LogError(ex, " : SurescriptsLibrary\RefillRequestType.SaveStatus(ByVal RecMessage As ReceivedMessage, ByVal lMessageCode As String) ")

                SaveStatus = False
           
            End Try

        End Function


        Private Function Get_MasterDatabaseName() As String
            Dim lConnection As New Connection()

            Try
                Return lConnection.GetDatabaseName()
            Catch ex As Exception
                Throw New Exception(ex.Message + " : SurescriptsLibrary\RefillRequestType.Get_MasterDatabaseName() ")
            End Try

        End Function

        Public Function GetRequestsForDoctor(ByVal lConnectionString As String, ByVal lDrCode As String, ByVal lClinicCode As String) As DataSet
            Dim lQuery As String
            Dim lDs As New DataSet
            Dim lDatabase = ""
            Dim lConnection As New Connection(lConnectionString)
            If lConnectionString = "" Then
                Throw New Exception
            End If

            Try

                Dim lObjConnectionMaster As New ConnectionMaster
                lObjConnectionMaster.Get_ConnectionInformation_By_DrCode(lDrCode, lClinicCode)

                lDatabase = Get_MasterDatabaseName()

                lQuery = "Select *, WriteDate = Case When Year(RR.WrittenDate) = 1900 Then Null Else RR.WrittenDate End  " _
                        & "From Elixir_APS_RenewalRequestSS RR " _
                        & "Where RR.DoctorId = '" & lObjConnectionMaster.SPI & "'  " _
                        & "And IsNull(RR.IsSent,0) = 0  "


                
                lDs = lConnection.ExecuteQuery(lQuery)
                'Dim lDa As New SqlClient.SqlDataAdapter(lQuery, lConnectionString)
                'lDa.Fill(lDs)
                GetRequestsForDoctor = lDs
            Catch ex As Exception
                Throw New Exception(ex.Message + " : SurescriptsLibrary\RefillRequestType.GetRequestsForDoctor(ByVal lConnectionString As String, ByVal lDrCode As String, ByVal lClinicCode As String) ")
                GetRequestsForDoctor = Nothing
            End Try



        End Function

        Public Function LoadRequest(ByVal lMessageId As String, ByVal lPharmacyId As String) As Boolean
            Dim lStatus As Boolean
            Dim lPath As String = System.Configuration.ConfigurationSettings.AppSettings("SureScriptsRequestsXmlPath").ToString()
            Dim lXMLData As String
            If lMessageId = "" Then
                Exit Function
            End If
            Dim lObjMessageHdr As New MessageHeader

            Try
                lStatus = lObjMessageHdr.GetMessageHeaderInfoByMessageId(lMessageId, lPharmacyId)
                If Not lStatus Then
                    Throw New Exception
                End If
                'Test
                'Dim lFile As New FileInfo(lPath & lObjMessageHdr.XMLPath.ToString())
                'If Not lFile.Exists Then
                '    Dim lWriter As New StreamWriter(lPath & lObjMessageHdr.XMLPath.ToString())
                '    lWriter.Write(lObjMessageHdr.XMLContents)
                '    lWriter.Flush()
                '    lWriter.Close()
                'End If
                'lFile = Nothing

                'Test


                Dim lReader As New StreamReader(lPath & lObjMessageHdr.XMLPath.ToString())
                lXMLData = lReader.ReadToEnd()
                lReader.Close()
                ReadXML(lXMLData)
                LoadRequest = True
            Catch ex As Exception
                Throw New Exception(ex.Message + " : SurescriptsLibrary\RefillRequestType.LoadRequest(ByVal lMessageId As String, ByVal lPharmacyId As String) ")
                LoadRequest = False
            End Try


        End Function

        Public Function GetRequest(ByVal lMessageId As String, ByVal lPharmacyId As String) As String
            Dim lStatus As Boolean
            Dim lPath As String = System.Configuration.ConfigurationSettings.AppSettings("SureScriptsRequestsXmlPath").ToString()
            Dim lXMLData As String
            If lMessageId = "" Then
                Return ""
            End If
            Dim lObjMessageHdr As New MessageHeader
            lStatus = lObjMessageHdr.GetMessageHeaderInfoByMessageId(lMessageId, lPharmacyId)
            If Not lStatus Then
                Throw New Exception
            End If
            
            Try
                Dim lReader As New StreamReader(lPath & lObjMessageHdr.XMLPath.ToString())
                lXMLData = lReader.ReadToEnd()
                lReader.Close()
                ReadXML(lXMLData)

                Return lXMLData
            Catch ex As Exception
                TraceLogging.ErrorLogMethods.LogError(ex, " : SurescriptsLibrary\RefillRequestType.GetRequest(ByVal lMessageId As String, ByVal lPharmacyId As String) ")
                Return ""
            End Try


        End Function


    End Class

   





    Public Class RefillResponseType
        Private mRxReferenceNumber As String = ""
        Private mPrescriberOrderNumber As String = ""
        Private mResponse As ResponseType = New ResponseType
        Private mPharmacy As PharmacyType = New PharmacyType
        Private mPrescriber As PrescriberType = New PrescriberType
        Private mSupervisor As SupervisorType = New SupervisorType
        Private mPatient As PatientType = New PatientType
        Private mMedicationPrescribed As ResponseMedicationType = New ResponseMedicationType

        Public Property RxReferenceNumber() As String
            Get
                Return mRxReferenceNumber
            End Get
            Set(ByVal Value As String)
                mRxReferenceNumber = Value
            End Set
        End Property
        Public Property PrescribedOrderNumber() As String
            Get
                Return mPrescriberOrderNumber
            End Get
            Set(ByVal Value As String)
                mPrescriberOrderNumber = Value
            End Set
        End Property
        Public Property Response() As ResponseType
            Get
                Return mResponse
            End Get
            Set(ByVal Value As ResponseType)
                mResponse = Value
            End Set
        End Property
        Public Property Pharmacy() As PharmacyType
            Get
                Return mPharmacy
            End Get
            Set(ByVal Value As PharmacyType)
                mPharmacy = Value
            End Set
        End Property
        Public Property Prescriber() As PrescriberType
            Get
                Return mPrescriber
            End Get
            Set(ByVal Value As PrescriberType)
                mPrescriber = Value
            End Set
        End Property
        Public Property Supervisor() As SupervisorType
            Get
                Return mSupervisor
            End Get
            Set(ByVal Value As SupervisorType)
                mSupervisor = Value
            End Set
        End Property
        Public Property PAtient() As PatientType
            Get
                Return mPatient
            End Get
            Set(ByVal Value As PatientType)
                mPatient = Value
            End Set
        End Property
        Public Property MedicationPrescribed() As ResponseMedicationType
            Get
                Return mMedicationPrescribed
            End Get
            Set(ByVal Value As ResponseMedicationType)
                mMedicationPrescribed = Value
            End Set
        End Property
    End Class

    Public Class ResponseType
        Private mApproved As ApprovedType = New ApprovedType
        Private mDenied As DeniedType = New DeniedType
        Private mDeniedNewPrescriptionToFollow As DeniedNewPrescriptionToFollowType = New DeniedNewPrescriptionToFollowType
        Private mApprovedWithChanges As ApprovedWithChangesType = New ApprovedWithChangesType
        Public Property Approved() As ApprovedType
            Get
                Return mApproved
            End Get
            Set(ByVal Value As ApprovedType)
                mApproved = Value
            End Set
        End Property
        Public Property Denied() As DeniedType
            Get
                Return mDenied
            End Get
            Set(ByVal Value As DeniedType)
                mDenied = Value
            End Set
        End Property
        Public Property DeniedNewPrescriptionToFollow() As DeniedNewPrescriptionToFollowType
            Get
                Return mDeniedNewPrescriptionToFollow
            End Get
            Set(ByVal Value As DeniedNewPrescriptionToFollowType)
                mDeniedNewPrescriptionToFollow = Value
            End Set
        End Property
        Public Property ApprovedWithChanges() As ApprovedWithChangesType
            Get
                Return mApprovedWithChanges
            End Get
            Set(ByVal Value As ApprovedWithChangesType)
                mApprovedWithChanges = Value
            End Set
        End Property
    End Class

    Public Class ApprovedType
        'Private mRefills As RefillsType = New RefillsType
        Private mNote As String = ""

        'Public Property Refills() As RefillsType
        '    Get
        '        Return mRefills
        '    End Get
        '    Set(ByVal Value As RefillsType)
        '        mRefills = Value
        '    End Set
        'End Property
        Public Property Note() As String
            Get
                Return mNote
            End Get
            Set(ByVal Value As String)
                mNote = Value
            End Set
        End Property
    End Class

    Public Class DeniedType
        Private mDenialReasonCode As String = ""
        Private mDenialReason As String = ""

        Public Property DenailReasonCode() As String
            Get
                Return mDenialReasonCode
            End Get
            Set(ByVal Value As String)
                mDenialReasonCode = Value
            End Set
        End Property
        Public Property DenielReason() As String
            Get
                Return mDenialReason
            End Get
            Set(ByVal Value As String)
                mDenialReason = Value
            End Set
        End Property

    End Class

    Public Class ApprovedWithChangesType
        Private mNote As String = ""
        Private mRefills As New RefillsType

        Public Property Refills() As RefillsType
            Get
                Return mRefills
            End Get
            Set(ByVal Value As RefillsType)
                mRefills = Value
            End Set
        End Property

        Public Property Note() As String
            Get
                Return mNote
            End Get
            Set(ByVal Value As String)
                mNote = Value
            End Set
        End Property


        'Private mApprovedWithChanges As String = ""
        'Public Property ApprovedWithChanges() As String
        '    Get
        '        Return mApprovedWithChanges
        '    End Get
        '    Set(ByVal Value As String)
        '        mApprovedWithChanges = Value
        '    End Set
        'End Property
    End Class

    Public Class DeniedNewPrescriptionToFollowType
        Private mNote As String = ""

        Public Property Note() As String
            Get
                Return mNote
            End Get
            Set(ByVal Value As String)
                mNote = Value
            End Set
        End Property
    End Class

    Public Class RequestType
        Private mGenericSubstitution As String = ""
        Private mTherapeuticInterchangeSubstitution As String = ""
        Private mPriorAuthorizationRequired As String = ""

        Public Property GenericSubstitution() As String
            Get
                Return mGenericSubstitution
            End Get
            Set(ByVal Value As String)
                mGenericSubstitution = Value
            End Set
        End Property
        Public Property TherapeuticInterchangeSubstitution() As String
            Get
                Return mTherapeuticInterchangeSubstitution
            End Get
            Set(ByVal Value As String)
                mTherapeuticInterchangeSubstitution = Value
            End Set
        End Property
        Public Property PriorAuthorizationRequired() As String
            Get
                Return mPriorAuthorizationRequired
            End Get
            Set(ByVal Value As String)
                mPriorAuthorizationRequired = Value
            End Set
        End Property


    End Class

    Public Class RxChangeResponseType
        Private mRxReferenceNumber As String = ""
        Private mPrescriberOrderNumber As String = ""
        Private mResponse As ResponseType = New ResponseType
        Private mPharmacy As PharmacyType = New PharmacyType
        Private mPrescriber As PrescriberType = New PrescriberType
        Private mSupervisor As SupervisorType = New SupervisorType
        Private mPatient As PatientType = New PatientType
        Private mMedicationPrescribed As ResponseMedicationType = New ResponseMedicationType

        Public Property RxReferenceNumber() As String
            Get
                Return mRxReferenceNumber
            End Get
            Set(ByVal Value As String)
                mRxReferenceNumber = Value
            End Set
        End Property
        Public Property PrescriberOrderNumber() As String
            Get
                Return mPrescriberOrderNumber
            End Get
            Set(ByVal Value As String)
                mPrescriberOrderNumber = Value
            End Set
        End Property
        Public Property Response() As ResponseType
            Get
                Return (mResponse)
            End Get
            Set(ByVal Value As ResponseType)
                mResponse = Value
            End Set
        End Property
        Public Property Pharmacy() As PharmacyType
            Get
                Return mPharmacy
            End Get
            Set(ByVal Value As PharmacyType)
                mPharmacy = Value
            End Set
        End Property
        Public Property Prescriber() As PrescriberType
            Get
                Return mPrescriber
            End Get
            Set(ByVal Value As PrescriberType)
                mPrescriber = Value
            End Set
        End Property
        Public Property Supervisor() As SupervisorType
            Get
                Return mSupervisor
            End Get
            Set(ByVal Value As SupervisorType)
                mSupervisor = Value
            End Set
        End Property
        Public Property Patient() As PatientType
            Get
                Return mPatient
            End Get
            Set(ByVal Value As PatientType)
                mPatient = Value
            End Set
        End Property
        Public Property MedicationPrescribed() As ResponseMedicationType
            Get
                Return mMedicationPrescribed
            End Get
            Set(ByVal Value As ResponseMedicationType)
                mMedicationPrescribed = Value
            End Set
        End Property




    End Class

    Public Class RxFill
        Private mRxReferenceNumber As String = ""
        Private mPrescriberOrderNumber As String = ""
        Private mFillStatus As FillStatusType = New FillStatusType
        Private mPharmacy As MandatoryPharmacyType = New MandatoryPharmacyType
        Private mPrescriber As PrescriberType = New PrescriberType
        Private mSupervisor As SupervisorType = New SupervisorType
        Private mPatient As PatientType = New PatientType
        Private mMedicationPrescribed As MedicationType = New MedicationType
        Private mHeader As HeaderType = New HeaderType
        Private mConnectionString As String

        Public Property RxReferenceNumber() As String
            Get
                Return mRxReferenceNumber
            End Get
            Set(ByVal Value As String)
                mRxReferenceNumber = Value
            End Set
        End Property
        Public Property PrescriberOrderNumber() As String
            Get
                Return mPrescriberOrderNumber
            End Get
            Set(ByVal Value As String)
                mPrescriberOrderNumber = Value
            End Set
        End Property
        Public Property FillStatusType() As FillStatusType
            Get
                Return (mFillStatus)
            End Get
            Set(ByVal Value As FillStatusType)
                mFillStatus = Value
            End Set
        End Property
        Public Property Pharmacy() As MandatoryPharmacyType
            Get
                Return mPharmacy
            End Get
            Set(ByVal Value As MandatoryPharmacyType)
                mPharmacy = Value
            End Set
        End Property
        Public Property Prescriber() As PrescriberType
            Get
                Return mPrescriber
            End Get
            Set(ByVal Value As PrescriberType)
                mPrescriber = Value
            End Set
        End Property
        Public Property Supervisor() As SupervisorType
            Get
                Return mSupervisor
            End Get
            Set(ByVal Value As SupervisorType)
                mSupervisor = Value
            End Set
        End Property
        Public Property Patient() As PatientType
            Get
                Return mPatient
            End Get
            Set(ByVal Value As PatientType)
                mPatient = Value
            End Set
        End Property
        Public Property MedicationPrescribed() As MedicationType
            Get
                Return mMedicationPrescribed
            End Get
            Set(ByVal Value As MedicationType)
                mMedicationPrescribed = Value
            End Set
        End Property
        Public Property Header() As HeaderType
            Get
                Return mHeader
            End Get
            Set(ByVal Value As HeaderType)
                mHeader = Value
            End Set
        End Property
        Public Property ConnectionString() As String
            Get
                Return mConnectionString
            End Get
            Set(ByVal Value As String)
                mConnectionString = Value
            End Set
        End Property

        Private Sub GetNode(ByVal tree As XmlNode)
            Dim lName As String = tree.Name.ToUpper
            Dim lParent As String = tree.ParentNode.Name.ToUpper
            Dim lGrandParent As String
            Dim lGrandGrandParent As String
            If Not tree.ParentNode.ParentNode Is Nothing Then
                lGrandParent = tree.ParentNode.ParentNode.Name.ToUpper

                If Not tree.ParentNode.ParentNode.ParentNode Is Nothing Then
                    lGrandGrandParent = tree.ParentNode.ParentNode.ParentNode.Name.ToUpper
                Else
                    lGrandGrandParent = "MESSAGE"
                End If
            Else
                lGrandParent = "MESSAGE"
                lGrandGrandParent = "MESSAGE"
            End If



            If lGrandParent = "MESSAGE" And lParent = "HEADER" Then
                Select Case lName
                    Case "TO"
                        Me.Header.To.MailAddress = tree.InnerText
                    Case "FROM"
                        Me.Header.From.MailAddress = tree.InnerText
                    Case "MESSAGEID"
                        Me.Header.MesssageID = tree.InnerText
                    Case "SENTTIME"
                        Me.Header.SentTime.UtcDate = tree.InnerText
                End Select
            ElseIf lGrandParent = "BODY" And lParent = "RXFILL" Then
                Select Case lName
                    Case "RXREFERENCENUMBER"
                        Me.RxReferenceNumber = tree.InnerText
                    Case "PRESCRIBERORDERNUMBER"
                        Me.PrescriberOrderNumber = tree.InnerText
                End Select
            ElseIf lGrandParent = "RXFILL" And lParent = "FILLSTATUS" Then
                Select Case lName
                    Case "FILLED"
                        Me.FillStatusType.Filled.Note = "FILLED"
                    Case "NOTFILLED"
                        Me.FillStatusType.NotFilled.Note = "NOTFILLED"
                    Case "PARTIALFILL"
                        Me.FillStatusType.PartialFill.Note = "PARTIALFILL"
                End Select
            ElseIf lGrandGrandParent = "RXFILL" And lGrandParent = "FILLSTATUS" And lParent = "FILLED" Then
                Select Case lName
                    Case "NOTE"
                        Me.FillStatusType.Filled.Note = tree.InnerText
                End Select

            ElseIf lGrandGrandParent = "RXFILL" And lGrandParent = "FILLSTATUS" And lParent = "NOTFILLED" Then
                Select Case lName
                    Case "NOTE"
                        Me.FillStatusType.NotFilled.Note = tree.InnerText
                    Case "FILLREASONCODE"
                        Me.FillStatusType.NotFilled.FillReasonCode = tree.InnerText
                End Select
            ElseIf lGrandGrandParent = "RXFILL" And lGrandParent = "FILLSTATUS" And lParent = "PARTIALFILL" Then
                Select Case lName
                    Case "NOTE"
                        Me.FillStatusType.NotFilled.Note = tree.InnerText
                    Case "FILLREASONCODE"
                        Me.FillStatusType.NotFilled.FillReasonCode = tree.InnerText
                End Select
            ElseIf lGrandParent = "PHARMACY" And lParent = "IDENTIFICATION" Then
                Select Case lName
                    Case "NCPDPID"
                        Me.Pharmacy.Identification.NCPDPID = tree.InnerText
                End Select
            ElseIf lGrandParent = "RXFILL" And lParent = "PHARMACY" Then
                Select Case lName
                    Case "STORENAME"
                        Me.Pharmacy.StoreName = tree.InnerText
                End Select
            ElseIf lGrandParent = "PHARMACY" And lParent = "PHARMACIST" Then
                Select Case lName
                    Case "LASTNAME"
                        Me.Pharmacy.Pharmacist.LastName = tree.InnerText
                    Case "FIRSTNAME"
                        Me.Pharmacy.Pharmacist.FirstName = tree.InnerText
                End Select
            ElseIf lGrandParent = "PHARMACY" And lParent = "PHARMACISTAGENT" Then
                Select Case lName
                    Case "LASTNAME"
                        Me.Pharmacy.PharmacistAgent.LastName = tree.InnerText
                    Case "FIRSTNAME"
                        Me.Pharmacy.PharmacistAgent.FirstName = tree.InnerText
                End Select

            ElseIf lGrandParent = "PHARMACY" And lParent = "ADDRESS" Then
                Select Case lName
                    Case "ADDRESSLINE1"
                        Me.Pharmacy.Address.AddressLine1 = tree.InnerText
                    Case "ADDRESSLINE2"
                        Me.Pharmacy.Address.AddressLine2 = tree.InnerText
                    Case "CITY"
                        Me.Pharmacy.Address.City = tree.InnerText
                    Case "STATE"
                        Me.Pharmacy.Address.State = tree.InnerText
                    Case "ZIPCODE"
                        Me.Pharmacy.Address.ZipCode = tree.InnerText
                End Select
            ElseIf lGrandParent = "RXFILL" And lParent = "PHARMACY" Then
                Select Case lName
                    Case "EMAIL"
                        Me.Pharmacy.Email = tree.InnerText
                End Select
            ElseIf lGrandGrandParent = "PHARMACY" And lGrandParent = "PHONENUMBERS" And lParent = "PHONE" Then
                Select Case lName
                    Case "NUMBER"
                        Dim tempPhone As New SureScriptsLibrary.SureScripts.PhoneType
                        tempPhone.Number = tree.InnerText
                        Me.Pharmacy.PhoneNumbers.Phone = New SureScriptsLibrary.SureScripts.PhoneType(0) {tempPhone}
                    Case "QUALIFIER"
                        Me.Pharmacy.PhoneNumbers.Phone(0).Qualifier = tree.InnerText
                End Select
                ''''''''' **** PRESCRIBER STARTS HERE ****''''''''''''''''''
            ElseIf lGrandGrandParent = "RXFILL" And lGrandParent = "PRESCRIBER" And lParent = "IDENTIFICATION" Then
                Select Case lName
                    Case "SPI"
                        Me.Prescriber.Identification.SPI = tree.InnerText
                    Case "SOCIALSECURITY"
                        Me.Prescriber.Identification.SocialSecurity = tree.InnerText
                End Select

            ElseIf lGrandGrandParent = "RXFILL" And lGrandParent = "PRESCRIBER" And lParent = "NAME" Then
                Select Case lName
                    Case "LASTNAME"
                        Me.Prescriber.Name.LastName = tree.InnerText
                    Case "FIRSTNAME"
                        Me.Prescriber.Name.FirstName = tree.InnerText
                    Case "MIDDLENAME"
                        Me.Prescriber.Name.MiddleName = tree.InnerText
                End Select
            ElseIf lGrandGrandParent = "RXFILL" And lGrandParent = "PRESCRIBER" And lParent = "SPECIALITY" Then
                Select Case lName
                    Case "QUALIFIER"
                        Me.Prescriber.Specialty.Qualifier = tree.InnerText
                    Case "SPECIALITYCODE"
                        Me.Prescriber.Specialty.SpecialtyCode = tree.InnerText
                End Select
            ElseIf lGrandGrandParent = "RXFILL" And lGrandParent = "PRESCRIBER" And lParent = "PRESCRIBERAGENT" Then
                Select Case lName
                    Case "LASTNAME"
                        Me.Prescriber.Name.LastName = tree.InnerText
                    Case "FIRSTNAME"
                        Me.Prescriber.Name.FirstName = tree.InnerText
                    Case "MIDDLENAME"
                        Me.Prescriber.Name.MiddleName = tree.InnerText
                End Select
            ElseIf lGrandGrandParent = "RXFILL" And lGrandParent = "PRESCRIBER" And lParent = "ADDRESS" Then
                Select Case lName
                    Case "ADDRESSLINE1"
                        Me.Prescriber.Address.AddressLine1 = tree.InnerText
                    Case "ADDRESSLINE2"
                        Me.Prescriber.Address.AddressLine2 = tree.InnerText
                    Case "CITY"
                        Me.Prescriber.Address.City = tree.InnerText
                    Case "STATE"
                        Me.Prescriber.Address.State = tree.InnerText
                    Case "ZIPCODE"
                        Me.Prescriber.Address.ZipCode = tree.InnerText
                End Select
            ElseIf lGrandParent = "RXFILL" And lParent = "PRESCRIBER" Then
                Select Case lName
                    Case "EMAIL"
                        Me.Prescriber.Email = tree.InnerText
                End Select
            ElseIf lGrandGrandParent = "PRESCRIBER" And lGrandParent = "PHONENUMBERS" And lParent = "PHONE" Then
                Select Case lName
                    Case "NUMBER"
                        Dim tempPhone As New SureScriptsLibrary.SureScripts.PhoneType
                        tempPhone.Number = tree.InnerText
                        Me.Prescriber.PhoneNumbers.Phone = New SureScriptsLibrary.SureScripts.PhoneType(0) {tempPhone}
                    Case "QUALIFIER"
                        Me.Prescriber.PhoneNumbers.Phone(0).Qualifier = tree.InnerText
                End Select
                ''''''''' **** PATIENT STARTS HERE ****''''''''''''''''''
            ElseIf lGrandGrandParent = "RXFILL" And lGrandParent = "PATIENT" And lParent = "IDENTIFICATION" Then
                Select Case lName
                    Case "SOCIALSECURITY"
                        Me.Patient.Identification.SocialSecurity = tree.InnerText
                    Case "MEDICARENUMBER"
                        Me.Patient.Identification.MedicaidNumber = tree.InnerText
                    Case "FILEID"
                        Me.Patient.Identification.FileID = tree.InnerText
                End Select
            ElseIf lGrandGrandParent = "RXFILL" And lGrandParent = "PATIENT" And lParent = "NAME" Then
                Select Case lName
                    Case "LASTNAME"
                        Me.Patient.Name.LastName = tree.InnerText
                    Case "FIRSTNAME"
                        Me.Patient.Name.FirstName = tree.InnerText
                    Case "MIDDLENAME"
                        Me.Patient.Name.MiddleName = tree.InnerText
                End Select
            ElseIf lGrandParent = "RXFILL" And lParent = "PATIENT" Then
                Select Case lName
                    Case "GENDER"
                        If tree.InnerText = "M" Then
                            Me.Patient.Gender = GenderType.M
                        ElseIf tree.InnerText = "F" Then
                            Me.Patient.Gender = GenderType.F
                        Else
                            Me.Patient.Gender = GenderType.U
                        End If
                    Case "DATEOFBIRTH"
                        Me.Patient.DateOfBirth.Date = tree.InnerText
                    Case "EMAIL"
                        Me.Patient.Email = tree.InnerText
                End Select
            ElseIf lGrandGrandParent = "RXFILL" And lGrandParent = "PATIENT" And lParent = "ADDRESS" Then
                Select Case lName
                    Case "ADDRESSLINE1"
                        Me.Patient.Address.AddressLine1 = tree.InnerText
                    Case "ADDRESSLINE2"
                        Me.Patient.Address.AddressLine2 = tree.InnerText
                    Case "CITY"
                        Me.Patient.Address.City = tree.InnerText
                    Case "STATE"
                        Me.Patient.Address.State = tree.InnerText
                    Case "ZIPCODE"
                        Me.Patient.Address.ZipCode = tree.InnerText
                End Select
            ElseIf lGrandGrandParent = "PATIENT" And lGrandParent = "PHONENUMBERS" And lParent = "PHONE" Then
                Select Case lName
                    Case "NUMBER"
                        Dim tempPhone As New SureScriptsLibrary.SureScripts.PhoneType
                        tempPhone.Number = tree.InnerText
                        Me.Patient.PhoneNumbers.Phone = New SureScriptsLibrary.SureScripts.PhoneType(0) {tempPhone}
                    Case "QUALIFIER"
                        Me.Patient.PhoneNumbers.Phone(0).Qualifier = tree.InnerText
                End Select
                ''''****MEDICATION PRESCRIBED ****'''''
            ElseIf lGrandGrandParent = "RXFILL" And lGrandParent = "MEDICATIONPRESCRIBED" And lParent = "DRUGCODED" Then
                Select Case lName
                    Case "PRODUCTCODE"
                        Me.MedicationPrescribed.DrugCoded.ProductCode = tree.InnerText
                    Case "PRODUCTCODEQUALIFIER"
                        Me.MedicationPrescribed.DrugCoded.ProductCodeQualifier = tree.InnerText
                    Case "DOSAGEFORM"
                        Me.MedicationPrescribed.DrugCoded.DosageForm = tree.InnerText
                    Case "STRENGTH"
                        Me.MedicationPrescribed.DrugCoded.Strength = tree.InnerText
                    Case "STRENGTHUNITS"
                        Me.MedicationPrescribed.DrugCoded.StrengthUnits = tree.InnerText
                    Case "DRUGDBCODE"
                        Me.MedicationPrescribed.DrugCoded.DrugDBCode = tree.InnerText
                    Case "DRUGDBCODEQUALIFIER"
                        Me.MedicationPrescribed.DrugCoded.DrugDBCodeQualifier = tree.InnerText

                End Select
            ElseIf lGrandGrandParent = "RXFILL" And lGrandParent = "MEDICATIONPRESCRIBED" And lParent = "QUANTITY" Then
                Select Case lName
                    Case "QUALIFIER"
                        Me.MedicationPrescribed.Quantity.Qualifier = tree.InnerText
                    Case "VALUE"
                        Me.MedicationPrescribed.Quantity.Value = tree.InnerText
                End Select
            ElseIf lGrandParent = "RXFILL" And lParent = "MEDICATIONPRESCRIBED" Then
                Select Case lName
                    Case "DRUGDESCRIPTION"
                        Me.MedicationPrescribed.DrugDescription = tree.InnerText
                    Case "DAYSSUPPLY"
                        Me.MedicationPrescribed.DaysSupply = tree.InnerText
                    Case "DIRECTIONS"
                        Me.MedicationPrescribed.Directions = tree.InnerText
                    Case "SUBSTITUTIONS"
                        Me.MedicationPrescribed.Substitutions = tree.InnerText
                    Case "WRITTENDATE"
                        Me.MedicationPrescribed.WrittenDate.Date = tree.InnerText
                    Case "LASTFILLDATE"
                        Me.MedicationPrescribed.LastFillDate.Date = tree.InnerText
                End Select
            ElseIf lGrandGrandParent = "RXFILL" And lGrandParent = "MEDICATIONPRESCRIBED" And lParent = "REFILLS" Then
                Select Case lName
                    Case "QUALIFIER"
                        Me.MedicationPrescribed.Refills.Qualifier = tree.InnerText
                    Case "QUANTITY"
                        Me.MedicationPrescribed.Refills.Quantity = tree.InnerText
                End Select

            End If
        End Sub

        Public Sub ParseTree(ByVal tree As XmlNode)
            If Not (tree Is Nothing) Then
                GetNode(tree)
            End If
            If tree.HasChildNodes Then
                tree = tree.FirstChild
                While Not (tree Is Nothing)
                    ParseTree(tree)
                    tree = tree.NextSibling
                End While
            End If
        End Sub


        Public Function ReadXML(ByVal xmldata As String)
            Dim xmld As New XmlDocument
            xmld.LoadXml(xmldata)
            ParseTree(xmld.DocumentElement)
        End Function

        Public Function AddMessage(ByVal filename As String, ByVal lMsgId As String, ByVal lRxId As String, ByVal constr As String) As String

            Dim flg As Boolean = False
            'Dim lConnectionString As String
            'lConnectionString = ConfigurationSettings.AppSettings("connectionString")
            'If lConnectionString = "" Then
            '    lConnectionString = Me.ConnectionString
            'End If
            'Dim con As New SqlConnection(lConnectionString)

            Dim lConnection As New Connection()

            Dim lQuery As String
            'Dim lTransaction As SqlTransaction

            Dim lResult As Boolean
            Dim lCode As String


            Dim lConnectionMaster As New SureScriptsLibrary.SureScripts.ConnectionMaster
            flg = lConnectionMaster.Get_ConnectionInformation_By_SPI(Me.Prescriber.Identification.SPI)
            If Not flg Then
                Throw New Exception
            End If

            Try
                lConnection.BeginTrans()
                'con.Open()

                'lTransaction = con.BeginTransaction

                lResult = CheckDuplicateMessage(lConnection, Me.Header.MesssageID, Me.Pharmacy.Identification.NCPDPID)
                If lResult Then
                    Throw New Exception
                End If

                lCode = GetMessageCode(lConnection)
                If lCode = "" Then
                    Throw New Exception
                End If

                lResult = AddMessageHdr(lConnection, "I", lCode, filename, lConnectionMaster.ClinicID)
                If Not lResult Then
                    Throw New Exception
                End If

                lResult = AddMessageDtl(lConnection, "I", lCode)

                If Not lResult Then
                    Throw New Exception
                End If

                If Me.PrescriberOrderNumber <> "" Then

                    lResult = UpdatePatCurrent(lConnectionMaster.ConnectionString, lMsgId, lRxId)
                    If Not lResult Then
                        Throw New Exception
                    End If
                End If

                lConnection.CommitTrans()
                'lTransaction.Commit()
                AddMessage = lCode
            Catch ex As Exception
                lConnection.RollBackTrans()
                'lTransaction.Rollback()
                flg = False
                AddMessage = ""
            Finally
                'If con.State <> ConnectionState.Closed Then
                '    con.Close()
                'End If
            End Try
        End Function

        Private Function UpdatePatCurrent(ByVal lClinicConnectionString As String, ByVal lMessageId As String, ByVal lRxId As String) As Boolean

            Dim lConnection As New Connection(lClinicConnectionString)
            'Dim lConnection As New SqlConnection(lClinicConnectionString)
            'Dim lCommand As New SqlCommand
            Dim lQuery As String
            Dim lFillStatus As String

            Try
                If Me.FillStatusType.Filled.Note <> "" Then
                    lFillStatus = "Filled"
                ElseIf Me.FillStatusType.NotFilled.Note <> "" Then
                    lFillStatus = "NotFilled"
                ElseIf Me.FillStatusType.PartialFill.Note <> "" Then
                    lFillStatus = "PartialFill"
                End If

                lQuery = "Update Aps_Pat_Current " _
                       & "Set RxFillStatus ='" & lFillStatus & "' " _
                       & "Where Rx_Id =" & Val(Right(Me.PrescriberOrderNumber, 9)) & " "


                lConnection.ExecuteCommand(lQuery)
                'lConnection.Open()
                'lCommand.CommandText = lQuery
                'lCommand.Connection = lConnection
                'lCommand.ExecuteNonQuery()
                'lConnection.Close()
                UpdatePatCurrent = True
            Catch ex As Exception
                UpdatePatCurrent = False
            End Try

        End Function



        Public Function AddMessageHdr(ByRef lConnection As Connection, _
                                      ByVal lDirection As String, _
                                      ByVal lCode As String, _
                                      ByVal lFileName As String, ByVal lClinicID As String) As Boolean

            Dim lStatus As Boolean
            Dim lQuery As String



            lQuery = "Insert Into MessageHdr (" _
                   & "MessageCode, MessageId, MessageTypeId, LastStatus," _
                   & "XMLPath, ClinicId, UserId, " _
                   & "PrescriberOrderNo, RxReferenceNo, " _
                   & "RelatesToMessageId, Direction, XMLContents, PharmacyCode) " _
                   & "VALUES(" _
                   & lCode & ", " _
                   & "'" & Me.Header.MesssageID & "', " _
                   & "5," _
                   & "'Success'," _
                   & "'" & lFileName & "'," _
                   & "'" & lClinicID & "'," _
                   & "'" & Me.Prescriber.Identification.SPI & "'," _
                   & "'" & Me.PrescriberOrderNumber & "'," _
                   & "'" & Me.RxReferenceNumber & "'," _
                   & "''," _
                   & "'" & lDirection & "', " _
                   & "'', " _
                   & "'" & Me.Pharmacy.Identification.NCPDPID & "')"


            lConnection.ExecuteTransactionCommand(lQuery)
            AddMessageHdr = True

        End Function

        
        Public Function AddMessageDtl(ByRef lConnection As Connection, _
                                      ByVal lDirection As String, _
                                      ByVal lCode As String) As Boolean

            Dim lStatus As Boolean
            Dim lQuery As String

            lQuery = "INSERT INTO MessageDtl(MessageCode, MessageTime, " _
                   & "Status, Code, DescriptionCode, " _
                   & "[Description],Direction,ReceivedMessageId, DetailMessageType) " _
                   & "VALUES(" _
                   & " " & lCode & ", " _
                   & "'" & CDate(Me.Header.SentTime.UtcDate) & "', " _
                   & "'Success'," _
                   & "''," _
                   & "''," _
                   & "'" & Me.Header.MesssageID & "'," _
                   & "'" & lDirection & "'," _
                   & "'',5)"

            lConnection.ExecuteTransactionCommand(lQuery)

            AddMessageDtl = True

        End Function

        
        Private Function CheckDuplicateMessage(ByRef lConnection As Connection, _
                                               ByVal lMessageId As String, _
                                               ByVal lPharmacyCode As String) As Boolean

            'Function Returns True If Message is Duplicate 

            Dim lDs As DataSet
            Dim lStatus As Boolean
            Dim lQuery As String
            Dim lCond As String


            lQuery = "Select * From MessageHdr " _
                   & "Where MessageId ='" & lMessageId & "' " _
                   & "And PharmacyCode ='" & lPharmacyCode & "' " _
                   & lCond

            lDs = lConnection.ExecuteTransactionQuery(lQuery)

            If lDs.Tables(0).Rows.Count > 0 Then
                CheckDuplicateMessage = True
            Else
                CheckDuplicateMessage = False
            End If

        End Function

        Public Function GetMessageCode(ByVal lConnection As Connection) As String

            Dim lDs As DataSet
            Dim lMessageCode As String = ""
            Dim lMessageNo As Integer = 0
            Dim lStatus As Boolean
            Dim lQuery As String


            lQuery = "Select IsNull(Max(MessageCode),0) + 1  AS MessageCode From MessageHdr "
            lDs = lConnection.ExecuteTransactionQuery(lQuery)

            If lDs.Tables.Count > 0 Then
                lMessageCode = CType(lDs.Tables(0).Rows(0)("MessageCode"), String)
            End If
            GetMessageCode = lMessageCode

        End Function

        Public Function SaveStatus(ByVal RecMessage As ReceivedMessage, ByVal lMessageCode As String) As Boolean

            'Dim lConnectionString As String
            'lConnectionString = ConfigurationSettings.AppSettings("connectionString")
            'If lConnectionString = "" Then
            '    lConnectionString = Me.ConnectionString
            'End If
            'Dim con As New SqlConnection(lConnectionString)

            Dim lConnection As New Connection()

            'Dim lTransaction As SqlTransaction
            Dim lQuery As String
            Dim lDs As New DataSet
            Dim lStatus As Boolean
            Dim lMessageType As Integer
            Dim lCode As String
            Dim lDescriptionCode As String
            Dim lDescription As String

            Try
                'con.Open()
                'lTransaction = con.BeginTransaction

                lConnection.BeginTrans()
                If RecMessage.MessageType = "ERROR" Then
                    lMessageType = 1
                    lCode = RecMessage.ErrorType.Code
                    lDescriptionCode = RecMessage.ErrorType.DescriptionCode
                    lDescription = RecMessage.ErrorType.Description
                Else
                    lMessageType = 3
                    lCode = RecMessage.StatusType.Code
                    lDescriptionCode = ""
                    lDescription = RecMessage.StatusType.Description
                End If


                lQuery = "INSERT INTO MessageDtl(MessageCode, MessageTime, " _
                       & "Status, Code, DescriptionCode, " _
                       & "[Description],Direction,ReceivedMessageId,DetailMessageType) " _
                       & "VALUES(" _
                       & " " & lMessageCode & ", " _
                       & "'" & Left(RecMessage.HeaderType.SentTime.UtcDate, 19) & "', " _
                       & "'Success'," _
                       & "'" & lCode & "'," _
                       & "'" & lDescriptionCode & "'," _
                       & "'" & lDescription.Replace("'", "''") & " '," _
                       & "'O'," _
                       & "'0'," _
                       & " " & lMessageType & ")"


                lConnection.ExecuteTransactionCommand(lQuery)
                
                lConnection.CommitTrans()

                SaveStatus = True

            Catch ex As Exception
                lConnection.RollBackTrans()
                SaveStatus = False
            End Try

        End Function
    End Class

    Public Class FillStatusType
        Private mFilled As FillNoteType = New FillNoteType
        Private mNotFilled As DeniedFillType = New DeniedFillType
        Private mPartialFill As FillNoteType = New FillNoteType

        Public Property Filled() As FillNoteType
            Get
                Return mFilled
            End Get
            Set(ByVal Value As FillNoteType)
                mFilled = Value
            End Set
        End Property
        Public Property NotFilled() As DeniedFillType
            Get
                Return mNotFilled
            End Get
            Set(ByVal Value As DeniedFillType)
                mNotFilled = Value
            End Set
        End Property
        Public Property PartialFill() As FillNoteType
            Get
                Return mPartialFill
            End Get
            Set(ByVal Value As FillNoteType)
                mPartialFill = Value
            End Set
        End Property
    End Class

    Public Class FillNoteType
        Private mNote As String = ""

        Public Property Note() As String
            Get
                Return mNote
            End Get
            Set(ByVal Value As String)
                mNote = Value
            End Set
        End Property
    End Class

    Public Class DeniedFillType
        Private mNote As String = ""
        Private mFillReasonCode As String = ""

        Public Property Note() As String
            Get
                Return mNote
            End Get
            Set(ByVal Value As String)
                mNote = Value
            End Set
        End Property
        Public Property FillReasonCode() As String
            Get
                Return mFillReasonCode
            End Get
            Set(ByVal Value As String)
                mFillReasonCode = Value
            End Set
        End Property

    End Class

    Public Class FillReasonCodeType
        Private mFillReasonCode As String = ""
        Private mNote As String = ""

        Public Property FillReasonCode() As String
            Get
                Return mFillReasonCode
            End Get
            Set(ByVal Value As String)
                mFillReasonCode = Value
            End Set
        End Property
        Public Property Note() As String
            Get
                Return mNote
            End Get
            Set(ByVal Value As String)
                mNote = Value
            End Set
        End Property

    End Class

    Public Class StatusType
        Private mHeader As HeaderType = New HeaderType
        Private mCode As String = ""
        Private mDescription As String = ""

        Public Property Header() As HeaderType
            Get
                Return mHeader
            End Get
            Set(ByVal Value As HeaderType)
                mHeader = Value
            End Set
        End Property
        Public Property Code() As String
            Get
                Return mCode
            End Get
            Set(ByVal Value As String)
                mCode = Value
            End Set
        End Property
        Public Property Description() As String
            Get
                Return mDescription
            End Get
            Set(ByVal Value As String)
                mDescription = Value
            End Set
        End Property

        Public Function WriteXml(ByVal filename As String) As String

            Dim xmlw As XmlTextWriter

            Dim lResult As Boolean
            Dim xmlstring As String = ""
            Try

                xmlw = New XmlTextWriter(filename, Nothing)
                xmlw.Formatting = Formatting.Indented
                xmlw.WriteStartElement("Message")
                xmlw.WriteAttributeString("xmlns", "http://www.surescripts.com/messaging")
                xmlw.WriteAttributeString("version", "1.0")

                '' Header complex type element
                xmlw.WriteStartElement("Header")

                xmlw.WriteStartElement("To")
                xmlw.WriteString(Me.Header.To.MailAddress)
                xmlw.WriteEndElement()

                xmlw.WriteStartElement("From")
                xmlw.WriteString(Me.Header.From.MailAddress)
                xmlw.WriteEndElement()

                xmlw.WriteStartElement("MessageID")
                xmlw.WriteString(Me.Header.MesssageID)
                xmlw.WriteEndElement()

                xmlw.WriteStartElement("SentTime")
                xmlw.WriteString(Me.Header.SentTime.UtcDate)
                xmlw.WriteEndElement()

                xmlw.WriteStartElement("TestMessage")
                xmlw.WriteString("")
                xmlw.WriteEndElement()
                xmlw.WriteEndElement()
                ''' End Header Complex type




                ''' Body complex type
                xmlw.WriteStartElement("Body")
                ''' Status complex type
                xmlw.WriteStartElement("Status")

                ''' Code Simple type
                xmlw.WriteStartElement("Code")
                xmlw.WriteString(Me.Code)
                xmlw.WriteEndElement()
                ''' End Code Simple type

                ''' Description Simple type
                xmlw.WriteStartElement("Description")
                xmlw.WriteString(Me.Description)
                xmlw.WriteEndElement()
                ''' End Description Simple type
                ''' End Status complex type
                xmlw.WriteEndElement()
                ''' End Body complex type
                xmlw.WriteEndElement()
                ''' End Message complex type
                xmlw.WriteEndDocument()

            Catch ex As Exception
                Dim a As String
                a = ex.Message
            Finally
                If Not xmlw Is Nothing Then
                    xmlw.Flush()
                    xmlw.Close()
                    Dim Stread As StreamReader = New StreamReader(filename)
                    xmlstring = Stread.ReadToEnd()
                    Stread.Close()

                End If
            End Try
            Return xmlstring
        End Function
    End Class

    Public Class ErrorType
        Private mCode As String = ""
        Private mDescriptionCode As String = ""
        Private mDescription As String = ""

        Public Property Code() As String
            Get
                Return mCode
            End Get
            Set(ByVal Value As String)
                mCode = Value
            End Set
        End Property
        Public Property DescriptionCode() As String
            Get
                Return mDescriptionCode
            End Get
            Set(ByVal Value As String)
                mDescriptionCode = Value
            End Set
        End Property
        Public Property Description() As String
            Get
                Return mDescription
            End Get
            Set(ByVal Value As String)
                mDescription = Value
            End Set
        End Property

    End Class

    Public Class VerifyType
        Private mCode As String = ""

        Public Property Code() As String
            Get
                Return mCode
            End Get
            Set(ByVal Value As String)
                mCode = Value
            End Set
        End Property
    End Class

    Public Class PharmacyType
        Private mIdentification As PharmacyIDType = New PharmacyIDType
        Private mStoreName As String = ""
        Private mPharmacist As NameType = New NameType
        Private mPharmacistAgent As NameType = New NameType
        Private mAddress As AddressType = New AddressType
        Private mEmail As String = ""
        Private mPhoneNumbers As PhoneNumbersType = New PhoneNumbersType

        Public Property Identification() As PharmacyIDType
            Get
                Return mIdentification
            End Get
            Set(ByVal Value As PharmacyIDType)
                mIdentification = Value
            End Set
        End Property
        Public Property StoreName() As String
            Get
                Return mStoreName
            End Get
            Set(ByVal Value As String)
                mStoreName = Value
            End Set
        End Property
        Public Property Pharmacist() As NameType
            Get
                Return mPharmacist
            End Get
            Set(ByVal Value As NameType)
                mPharmacist = Value
            End Set
        End Property
        Public Property PharmacistAgent() As NameType
            Get
                Return mPharmacistAgent
            End Get
            Set(ByVal Value As NameType)
                mPharmacistAgent = Value
            End Set
        End Property
        Public Property Address() As AddressType
            Get
                Return mAddress
            End Get
            Set(ByVal Value As AddressType)
                mAddress = Value
            End Set
        End Property
        Public Property Email() As String
            Get
                Return mEmail
            End Get
            Set(ByVal Value As String)
                mEmail = Value
            End Set
        End Property
        Public Property PhoneNumbers() As PhoneNumbersType
            Get
                Return mPhoneNumbers
            End Get
            Set(ByVal Value As PhoneNumbersType)
                mPhoneNumbers = Value
            End Set
        End Property
    End Class

    Public Class MandatoryPharmacyType
        Private mIdentification As PharmacyIDType = New PharmacyIDType
        Private mStoreName As String = ""
        Private mPharmacist As NameType = New NameType
        Private mPharmacistAgent As MandatoryNameType = New MandatoryNameType
        Private mAddress As MandatoryAddressType = New MandatoryAddressType
        Private mEmail As String = ""
        Private mPhoneNumbers As PhoneNumbersType = New PhoneNumbersType

        Public Property Identification() As PharmacyIDType
            Get
                Return mIdentification
            End Get
            Set(ByVal Value As PharmacyIDType)
                mIdentification = Value
            End Set
        End Property
        Public Property StoreName() As String
            Get
                Return mStoreName
            End Get
            Set(ByVal Value As String)
                mStoreName = Value
            End Set
        End Property
        Public Property Pharmacist() As NameType
            Get
                Return mPharmacist
            End Get
            Set(ByVal Value As NameType)
                mPharmacist = Value
            End Set
        End Property
        Public Property PharmacistAgent() As MandatoryNameType
            Get
                Return mPharmacistAgent
            End Get
            Set(ByVal Value As MandatoryNameType)
                mPharmacistAgent = Value
            End Set
        End Property
        Public Property Address() As MandatoryAddressType
            Get
                Return mAddress
            End Get
            Set(ByVal Value As MandatoryAddressType)
                mAddress = Value
            End Set
        End Property
        Public Property Email() As String
            Get
                Return mEmail
            End Get
            Set(ByVal Value As String)
                mEmail = Value
            End Set
        End Property
        Public Property PhoneNumbers() As PhoneNumbersType
            Get
                Return mPhoneNumbers
            End Get
            Set(ByVal Value As PhoneNumbersType)
                mPhoneNumbers = Value
            End Set
        End Property
    End Class

    Public Class PharmacyIDType
        Private mNCPDPID As String = "" '9999955
        Private mFileID As String = ""
        Private mStateLicenseNumber As String = ""
        Private mMedicareNumber As String = ""
        Private mMedicaidNumber As String = ""
        Private mPPONumber As String = ""
        Private mPayerID As String = ""
        Private mBINLocationNumber As String = ""
        Private mDEANumber As String = ""
        Private mHIN As String = ""
        Private mSecondaryCoverage As String = ""
        Private mNAICCode As String = ""
        Private mPromotionNumber As String = ""
        Private mSocialSecurity As String = ""
        Private mNPI As String = ""
        Private mPriorAuthorization As String = ""

        Public Property NCPDPID() As String
            Get
                Return mNCPDPID
            End Get
            Set(ByVal Value As String)
                mNCPDPID = Value
            End Set
        End Property
        Public Property FileID() As String
            Get
                Return mFileID
            End Get
            Set(ByVal Value As String)
                mFileID = Value
            End Set
        End Property
        Public Property StateLicenseNumber() As String
            Get
                Return mStateLicenseNumber
            End Get
            Set(ByVal Value As String)
                mStateLicenseNumber = Value
            End Set
        End Property
        Public Property MedicareNumber() As String
            Get
                Return mMedicareNumber
            End Get
            Set(ByVal Value As String)
                mMedicareNumber = Value
            End Set
        End Property
        Public Property MediCaidNumber() As String
            Get
                Return mMedicaidNumber
            End Get
            Set(ByVal Value As String)
                mMedicaidNumber = Value
            End Set
        End Property
        Public Property PPONumber() As String
            Get
                Return mPPONumber
            End Get
            Set(ByVal Value As String)
                mPPONumber = Value
            End Set
        End Property
        Public Property PayerId() As String
            Get
                Return mPayerID
            End Get
            Set(ByVal Value As String)
                mPayerID = Value
            End Set
        End Property
        Public Property BINLocationNumber() As String
            Get
                Return mBINLocationNumber
            End Get
            Set(ByVal Value As String)
                mBINLocationNumber = Value
            End Set
        End Property
        Public Property DEANumber() As String
            Get
                Return mDEANumber
            End Get
            Set(ByVal Value As String)
                mDEANumber = Value
            End Set
        End Property
        Public Property HIN() As String
            Get
                Return mHIN
            End Get
            Set(ByVal Value As String)
                mHIN = Value
            End Set
        End Property
        Public Property SecondaryCoverage() As String
            Get
                Return mSecondaryCoverage
            End Get
            Set(ByVal Value As String)
                mSecondaryCoverage = Value
            End Set
        End Property
        Public Property NAICode() As String
            Get
                Return mNAICCode
            End Get
            Set(ByVal Value As String)
                mNAICCode = Value
            End Set
        End Property
        Public Property PromotionNumber() As String
            Get
                Return mPromotionNumber
            End Get
            Set(ByVal Value As String)
                mPromotionNumber = Value
            End Set
        End Property
        Public Property SocialSecurity() As String
            Get
                Return mSocialSecurity
            End Get
            Set(ByVal Value As String)
                mSocialSecurity = Value
            End Set
        End Property
        Public Property NPI() As String
            Get
                Return mNPI
            End Get
            Set(ByVal Value As String)
                mNPI = Value
            End Set
        End Property
        Public Property PriorAuthorization() As String
            Get
                Return mPriorAuthorization
            End Get
            Set(ByVal Value As String)
                mPriorAuthorization = Value
            End Set
        End Property
    End Class

    Public Class PrescriberType
        Private mIdentification As PrescriberIDType = New PrescriberIDType
        Private mClinicName As String = ""
        Private mName As MandatoryNameType = New MandatoryNameType
        Private mSpecialty As SpecialtyType = New SpecialtyType
        Private mPrescriberAgent As MandatoryNameType = New MandatoryNameType
        Private mAddress As AddressType = New AddressType
        Private mEmail As String = ""
        Private mPhoneNumbers As PhoneNumbersType = New PhoneNumbersType

        Public Property Identification() As PrescriberIDType
            Get
                Return mIdentification
            End Get
            Set(ByVal Value As PrescriberIDType)
                mIdentification = Value
            End Set
        End Property
        Public Property ClinicName() As String
            Get
                Return mClinicName
            End Get
            Set(ByVal Value As String)
                mClinicName = Value
            End Set
        End Property
        Public Property Name() As MandatoryNameType
            Get
                Return mName
            End Get
            Set(ByVal Value As MandatoryNameType)
                mName = Value
            End Set
        End Property
        Public Property Specialty() As SpecialtyType
            Get
                Return mSpecialty
            End Get
            Set(ByVal Value As SpecialtyType)
                mSpecialty = Value
            End Set
        End Property
        Public Property PrescriberAgent() As MandatoryNameType
            Get
                Return mPrescriberAgent
            End Get
            Set(ByVal Value As MandatoryNameType)
                mPrescriberAgent = Value
            End Set
        End Property
        Public Property Address() As AddressType
            Get
                Return mAddress
            End Get
            Set(ByVal Value As AddressType)
                mAddress = Value
            End Set
        End Property
        Public Property Email() As String
            Get
                Return mEmail
            End Get
            Set(ByVal Value As String)
                mEmail = Value
            End Set
        End Property
        Public Property PhoneNumbers() As PhoneNumbersType
            Get
                Return mPhoneNumbers
            End Get
            Set(ByVal Value As PhoneNumbersType)
                mPhoneNumbers = Value
            End Set
        End Property
    End Class

    Public Class SupervisorType
        Private mIdentification As SuperviserIDType = New SuperviserIDType
        Private mClinicName As String = ""
        Private mName As MandatoryNameType = New MandatoryNameType
        Private mSpecialty As SpecialtyType = New SpecialtyType
        Private mPrescriberAgent As MandatoryNameType = New MandatoryNameType
        Private mAddress As AddressType = New AddressType
        Private mEmail As String = ""
        Private mPhoneNumbers As PhoneNumbersType = New PhoneNumbersType

        Public Property Identification() As SuperviserIDType
            Get
                Return mIdentification
            End Get
            Set(ByVal Value As SuperviserIDType)
                mIdentification = Value
            End Set
        End Property
        Public Property ClinicName() As String
            Get
                Return mClinicName
            End Get
            Set(ByVal Value As String)
                mClinicName = Value
            End Set
        End Property
        Public Property Name() As MandatoryNameType
            Get
                Return mName
            End Get
            Set(ByVal Value As MandatoryNameType)
                mName = Value
            End Set
        End Property
        Public Property Specialty() As SpecialtyType
            Get
                Return mSpecialty
            End Get
            Set(ByVal Value As SpecialtyType)
                mSpecialty = Value
            End Set
        End Property
        Public Property PrescriberAgent() As MandatoryNameType
            Get
                Return mPrescriberAgent
            End Get
            Set(ByVal Value As MandatoryNameType)
                mPrescriberAgent = Value
            End Set
        End Property
        Public Property Address() As AddressType
            Get
                Return mAddress
            End Get
            Set(ByVal Value As AddressType)
                mAddress = Value
            End Set
        End Property
        Public Property Email() As String
            Get
                Return mEmail
            End Get
            Set(ByVal Value As String)
                mEmail = Value
            End Set
        End Property
        Public Property PhoneNumbers() As PhoneNumbersType
            Get
                Return mPhoneNumbers
            End Get
            Set(ByVal Value As PhoneNumbersType)
                mPhoneNumbers = Value
            End Set
        End Property
    End Class

    Public Class MandatoryPrescriberType
        Private mIdentification As PrescriberIDType = New PrescriberIDType
        Private mClinicName As String = "'"
        Private mName As MandatoryNameType = New MandatoryNameType
        Private mSpecialty As SpecialtyType = New SpecialtyType
        Private mPrescriberAgent As MandatoryNameType = New MandatoryNameType
        Private mAddress As MandatoryAddressType = New MandatoryAddressType
        Private mEmail As String = ""
        Private mPhoneNumbers As PhoneNumbersType = New PhoneNumbersType

        Public Property Identification() As PrescriberIDType
            Get
                Return mIdentification
            End Get
            Set(ByVal Value As PrescriberIDType)
                mIdentification = Value
            End Set
        End Property
        Public Property ClinicName() As String
            Get
                Return mClinicName
            End Get
            Set(ByVal Value As String)
                mClinicName = Value
            End Set
        End Property
        Public Property Name() As MandatoryNameType
            Get
                Return mName
            End Get
            Set(ByVal Value As MandatoryNameType)
                mName = Value
            End Set
        End Property
        Public Property Specialty() As SpecialtyType
            Get
                Return mSpecialty
            End Get
            Set(ByVal Value As SpecialtyType)
                mSpecialty = Value
            End Set
        End Property
        Public Property PrescriberAgent() As MandatoryNameType
            Get
                Return mPrescriberAgent
            End Get
            Set(ByVal Value As MandatoryNameType)
                mPrescriberAgent = Value
            End Set
        End Property
        Public Property Address() As MandatoryAddressType
            Get
                Return mAddress
            End Get
            Set(ByVal Value As MandatoryAddressType)
                mAddress = Value
            End Set
        End Property
        Public Property Email() As String
            Get
                Return mEmail
            End Get
            Set(ByVal Value As String)
                mEmail = Value
            End Set
        End Property
        Public Property PhoneNumbers() As PhoneNumbersType
            Get
                Return mPhoneNumbers
            End Get
            Set(ByVal Value As PhoneNumbersType)
                mPhoneNumbers = Value
            End Set
        End Property
    End Class

    Public Class PrescriberIDType
        Private mSPI As String = "" '6901147812001
        Private mFileID As String = ""
        Private mStateLicenseNumber As String = ""
        Private mMedicareNumber As String = ""
        Private mMedicaidNumber As String = ""
        Private mDentistLicenseNumber As String = ""
        Private mUPIN As String = ""
        Private mPPONumber As String = ""
        Private mDEANumber As String = ""
        Private mSocialSecurity As String = ""
        Private mNPI As String = ""
        Private mPriorAuthorization As String = ""

        Public Property SPI() As String
            Get
                Return mSPI
            End Get
            Set(ByVal Value As String)
                mSPI = Value
            End Set
        End Property
        Public Property FileID() As String
            Get
                Return mFileID
            End Get
            Set(ByVal Value As String)
                mFileID = Value
            End Set
        End Property
        Public Property StateLicenseNumber() As String
            Get
                Return mStateLicenseNumber
            End Get
            Set(ByVal Value As String)
                mStateLicenseNumber = Value
            End Set
        End Property
        Public Property MedicareNumber() As String
            Get
                Return mMedicareNumber
            End Get
            Set(ByVal Value As String)
                mMedicareNumber = Value
            End Set
        End Property
        Public Property MedicaidNumber() As String
            Get
                Return mMedicaidNumber
            End Get
            Set(ByVal Value As String)
                mMedicaidNumber = Value
            End Set
        End Property
        Public Property DentisiLicenseNumber() As String
            Get
                Return mDentistLicenseNumber
            End Get
            Set(ByVal Value As String)
                mDentistLicenseNumber = Value
            End Set
        End Property
        Public Property UPIN() As String
            Get
                Return mUPIN
            End Get
            Set(ByVal Value As String)
                mUPIN = Value
            End Set
        End Property
        Public Property PPONumber() As String
            Get
                Return mPPONumber
            End Get
            Set(ByVal Value As String)
                mPPONumber = Value
            End Set
        End Property
        Public Property DEANumber() As String
            Get
                Return mDEANumber
            End Get
            Set(ByVal Value As String)
                mDEANumber = Value
            End Set
        End Property
        Public Property SocialSecurity() As String
            Get
                Return Common.ChangeSSNFormat(mSocialSecurity)
            End Get
            Set(ByVal Value As String)
                mSocialSecurity = Common.ChangeSSNFormat(Value)
            End Set
        End Property
        Public Property NPI() As String
            Get
                Return mNPI
            End Get
            Set(ByVal Value As String)
                mNPI = Value
            End Set
        End Property
        Public Property PriorAuthorization() As String
            Get
                Return mPriorAuthorization
            End Get
            Set(ByVal Value As String)
                mPriorAuthorization = Value
            End Set
        End Property

    End Class

    Public Class SuperviserIDType
        Private mSPI As String = ""
        Private mFileID As String = ""
        Private mStateLicenseNumber As String = ""
        Private mMedicareNumber As String = ""
        Private mMedicaidNumber As String = ""
        Private mDentistLicenseNumber As String = ""
        Private mUPIN As String = ""
        Private mPPONumber As String = ""
        Private mDEANumber As String = ""
        Private mSocialSecurity As String = ""
        Private mNPI As String = ""
        Private mPriorAuthorization As String = ""
        Private mSpecialty As SpecialtyType = New SpecialtyType

        Public Property SPI() As String
            Get
                Return mSPI
            End Get
            Set(ByVal Value As String)
                mSPI = Value
            End Set
        End Property
        Public Property FileID() As String
            Get
                Return mFileID
            End Get
            Set(ByVal Value As String)
                mFileID = Value
            End Set
        End Property
        Public Property StateLicenseNumber() As String
            Get
                Return mStateLicenseNumber
            End Get
            Set(ByVal Value As String)
                mStateLicenseNumber = Value
            End Set
        End Property
        Public Property MedicareNumber() As String
            Get
                Return mMedicareNumber
            End Get
            Set(ByVal Value As String)
                mMedicareNumber = Value
            End Set
        End Property
        Public Property MedicaidNumber() As String
            Get
                Return mMedicaidNumber
            End Get
            Set(ByVal Value As String)
                mMedicaidNumber = Value
            End Set
        End Property
        Public Property DentisiLicenseNumber() As String
            Get
                Return mDentistLicenseNumber
            End Get
            Set(ByVal Value As String)
                mDentistLicenseNumber = Value
            End Set
        End Property
        Public Property UPIN() As String
            Get
                Return mUPIN
            End Get
            Set(ByVal Value As String)
                mUPIN = Value
            End Set
        End Property
        Public Property PPONumber() As String
            Get
                Return mPPONumber
            End Get
            Set(ByVal Value As String)
                mPPONumber = Value
            End Set
        End Property
        Public Property DEANumber() As String
            Get
                Return mDEANumber
            End Get
            Set(ByVal Value As String)
                mDEANumber = Value
            End Set
        End Property
        Public Property SocialSecurity() As String
            Get
                Return mSocialSecurity
            End Get
            Set(ByVal Value As String)
                mSocialSecurity = Value
            End Set
        End Property
        Public Property NPI() As String
            Get
                Return mNPI
            End Get
            Set(ByVal Value As String)
                mNPI = Value
            End Set
        End Property
        Public Property PriorAuthorization() As String
            Get
                Return mPriorAuthorization
            End Get
            Set(ByVal Value As String)
                mPriorAuthorization = Value
            End Set
        End Property
        Public Property Specialty() As SpecialtyType
            Get
                Return mSpecialty
            End Get
            Set(ByVal Value As SpecialtyType)
                mSpecialty = Value
            End Set
        End Property
    End Class

    Public Class SpecialtyType
        Private mQualifier As String = ""
        Private mSpecialtyCode As String = ""
        Public Property Qualifier() As String
            Get
                Return mQualifier
            End Get
            Set(ByVal Value As String)
                mQualifier = Value
            End Set
        End Property
        Public Property SpecialtyCode() As String
            Get
                Return mSpecialtyCode
            End Get
            Set(ByVal Value As String)
                mSpecialtyCode = Value
            End Set
        End Property
    End Class

    Public Class PatientType
        Private mIdentification As PatientIDType = New PatientIDType
        Private mName As MandatoryNameType = New MandatoryNameType
        Private mGender As GenderType = GenderType.M
        Private mDateOfBirth As DateType = New DateType
        Private mAddress As AddressType = New AddressType
        Private mEmail As String = ""
        Private mPhoneNumbers As PhoneNumbersType = New PhoneNumbersType

        Public Property Identification() As PatientIDType
            Get
                Return mIdentification
            End Get
            Set(ByVal Value As PatientIDType)
                mIdentification = Value
            End Set
        End Property
        Public Property Name() As MandatoryNameType
            Get
                Return mName
            End Get
            Set(ByVal Value As MandatoryNameType)
                mName = Value
            End Set
        End Property
        Public Property Gender() As GenderType
            Get
                Return mGender
            End Get
            Set(ByVal Value As GenderType)
                mGender = Value
            End Set
        End Property
        Public Property DateOfBirth() As DateType
            Get
                Return mDateOfBirth
            End Get
            Set(ByVal Value As DateType)
                mDateOfBirth = Value
            End Set
        End Property
        Public Property Address() As AddressType
            Get
                Return mAddress
            End Get
            Set(ByVal Value As AddressType)
                mAddress = Value
            End Set
        End Property
        Public Property Email() As String
            Get
                Return mEmail
            End Get
            Set(ByVal Value As String)
                mEmail = Value
            End Set
        End Property
        Public Property PhoneNumbers() As PhoneNumbersType
            Get
                Return mPhoneNumbers
            End Get
            Set(ByVal Value As PhoneNumbersType)
                mPhoneNumbers = Value
            End Set
        End Property
    End Class

    Public Class PatientIDType
        Private mFileID As String = ""
        Private mMedicareNumber As String = ""
        Private mMedicaidNumber As String = ""
        Private mPPONumber As String = ""
        Private mSocialSecurity As String = ""

        Public Property FileID() As String
            Get
                Return mFileID
            End Get
            Set(ByVal Value As String)
                mFileID = Value
            End Set
        End Property
        Public Property MedicalcareNumber() As String
            Get
                Return mMedicareNumber
            End Get
            Set(ByVal Value As String)
                mMedicareNumber = Value
            End Set
        End Property
        Public Property MedicaidNumber() As String
            Get
                Return mMedicaidNumber
            End Get
            Set(ByVal Value As String)
                mMedicaidNumber = Value
            End Set
        End Property
        Public Property PPONumber() As String
            Get
                Return mPPONumber
            End Get
            Set(ByVal Value As String)
                mPPONumber = Value
            End Set
        End Property
        Public Property SocialSecurity() As String
            Get
                Return Common.ChangeSSNFormat(mSocialSecurity)
            End Get
            Set(ByVal Value As String)
                mSocialSecurity = Common.ChangeSSNFormat(Value)
            End Set
        End Property
    End Class

    Public Enum GenderType
        M = 1
        F = 2
        U = 3
    End Enum

    Public Class MedicationType

        Private mDrugDescription As String = ""
        Private mDrugCoded As DrugCodedType = New DrugCodedType
        Private mQuantity As QuantityType = New QuantityType
        Private mDaysSupply As String = ""
        Private mDirections As String = ""
        Private mNote As String = ""
        Private mRefills As RefillsType = New RefillsType
        Private mSubstitutions As String = ""
        Private mWrittenDate As DateType = New DateType
        Private mLastFillDate As DateType = New DateType
        Private mDiagnosis As Diagnosis = New Diagnosis
        Private mPriorAuthorization As PriorAuthorizationType = New PriorAuthorizationType

        Public Property DrugDescription() As String
            Get
                Return mDrugDescription
            End Get
            Set(ByVal Value As String)
                mDrugDescription = Value
            End Set
        End Property
        Public Property DrugCoded() As DrugCodedType
            Get
                Return mDrugCoded
            End Get
            Set(ByVal Value As DrugCodedType)
                mDrugCoded = Value
            End Set
        End Property
        Public Property Quantity() As QuantityType
            Get
                Return mQuantity
            End Get
            Set(ByVal Value As QuantityType)
                mQuantity = Value
            End Set
        End Property
        Public Property DaysSupply() As String
            Get
                Return mDaysSupply
            End Get
            Set(ByVal Value As String)
                mDaysSupply = Value
            End Set
        End Property
        Public Property Directions() As String
            Get
                Return mDirections
            End Get
            Set(ByVal Value As String)
                mDirections = Value
            End Set
        End Property
        Public Property Note() As String
            Get
                Return mNote
            End Get
            Set(ByVal Value As String)
                mNote = Value
            End Set
        End Property
        Public Property Refills() As RefillsType
            Get
                Return mRefills
            End Get
            Set(ByVal Value As RefillsType)
                mRefills = Value
            End Set
        End Property
        Public Property Substitutions() As String
            Get
                Return mSubstitutions
            End Get
            Set(ByVal Value As String)
                mSubstitutions = Value
            End Set
        End Property
        Public Property WrittenDate() As DateType
            Get
                Return mWrittenDate
            End Get
            Set(ByVal Value As DateType)
                mWrittenDate = Value
            End Set
        End Property
        Public Property LastFillDate() As DateType
            Get
                Return mLastFillDate
            End Get
            Set(ByVal Value As DateType)
                mLastFillDate = Value
            End Set
        End Property
        Public Property Diagnosis() As Diagnosis
            Get
                Return mDiagnosis
            End Get
            Set(ByVal Value As Diagnosis)
                mDiagnosis = Value
            End Set
        End Property
        Public Property PriorAuthorization() As PriorAuthorizationType
            Get
                Return mPriorAuthorization
            End Get
            Set(ByVal Value As PriorAuthorizationType)
                mPriorAuthorization = Value
            End Set
        End Property
    End Class

    Public Class NewRXMedicationType

        'Differs from MedicationType 
        '1. Substitutions value set is limited 
        '2. WrittenDate is required


        Private mDrugDescription As String = ""
        Private mDrugCoded As DrugCodedType = New DrugCodedType
        Private mQuantity As QuantityType = New QuantityType
        Private mDaysSupply As String = ""
        Private mDirections As String = ""
        Private mNote As String = ""
        Private mRefills As RefillsType = New RefillsType
        Private mSubstitutions As String = ""
        Private mWrittenDate As DateType = New DateType
        Private mLastFillDate As DateType = New DateType
        Private mDiagnosis As Diagnosis = New Diagnosis
        Private mPriorAuthorization As PriorAuthorizationType = New PriorAuthorizationType

        Public Property DrugDescription() As String
            Get
                Return mDrugDescription
            End Get
            Set(ByVal Value As String)
                mDrugDescription = Value
            End Set
        End Property
        Public Property DrugCoded() As DrugCodedType
            Get
                Return mDrugCoded
            End Get
            Set(ByVal Value As DrugCodedType)
                mDrugCoded = Value
            End Set
        End Property
        Public Property Quantity() As QuantityType
            Get
                Return mQuantity
            End Get
            Set(ByVal Value As QuantityType)
                mQuantity = Value
            End Set
        End Property
        Public Property DaysSupply() As String
            Get
                Return mDaysSupply
            End Get
            Set(ByVal Value As String)
                mDaysSupply = Value
            End Set
        End Property
        Public Property Directions() As String
            Get
                Return mDirections
            End Get
            Set(ByVal Value As String)
                mDirections = Value
            End Set
        End Property
        Public Property Note() As String
            Get
                Return mNote
            End Get
            Set(ByVal Value As String)
                mNote = Value
            End Set
        End Property
        Public Property Refills() As RefillsType
            Get
                Return mRefills
            End Get
            Set(ByVal Value As RefillsType)
                mRefills = Value
            End Set
        End Property
        Public Property Substitutions() As String
            Get
                Return mSubstitutions
            End Get
            Set(ByVal Value As String)
                mSubstitutions = Value
            End Set
        End Property
        Public Property WrittenDate() As DateType
            Get
                Return mWrittenDate
            End Get
            Set(ByVal Value As DateType)
                mWrittenDate = Value
            End Set
        End Property
        Public Property LastFillDate() As DateType
            Get
                Return mLastFillDate
            End Get
            Set(ByVal Value As DateType)
                mLastFillDate = Value
            End Set
        End Property
        Public Property Diagnosis() As Diagnosis
            Get
                Return mDiagnosis
            End Get
            Set(ByVal Value As Diagnosis)
                mDiagnosis = Value
            End Set
        End Property
        Public Property PriorAuthorization() As PriorAuthorizationType
            Get
                Return mPriorAuthorization
            End Get
            Set(ByVal Value As PriorAuthorizationType)
                mPriorAuthorization = Value
            End Set
        End Property
    End Class

    Public Class ResponseMedicationType

        'Differs from MedicationType 
        '1. Substitutions value set is limited


        Private mDrugDescription As String = ""
        Private mDrugCoded As DrugCodedType = New DrugCodedType
        Private mQuantity As QuantityType = New QuantityType
        Private mDaysSupply As String = ""
        Private mDirections As String = ""
        Private mNote As String = ""
        Private mRefills As RefillsType = New RefillsType
        Private mSubstitutions As String = ""
        Private mWrittenDate As DateType = New DateType
        Private mLastFillDate As DateType = New DateType
        Private mDiagnosis As Diagnosis = New Diagnosis
        Private mPriorAuthorization As PriorAuthorizationType = New PriorAuthorizationType

        Public Property DrugDescription() As String
            Get
                Return mDrugDescription
            End Get
            Set(ByVal Value As String)
                mDrugDescription = Value
            End Set
        End Property
        Public Property DrugCoded() As DrugCodedType
            Get
                Return mDrugCoded
            End Get
            Set(ByVal Value As DrugCodedType)
                mDrugCoded = Value
            End Set
        End Property
        Public Property Quantity() As QuantityType
            Get
                Return mQuantity
            End Get
            Set(ByVal Value As QuantityType)
                mQuantity = Value
            End Set
        End Property
        Public Property DaysSupply() As String
            Get
                Return mDaysSupply
            End Get
            Set(ByVal Value As String)
                mDaysSupply = Value
            End Set
        End Property
        Public Property Directions() As String
            Get
                Return mDirections
            End Get
            Set(ByVal Value As String)
                mDirections = Value
            End Set
        End Property
        Public Property Note() As String
            Get
                Return mNote
            End Get
            Set(ByVal Value As String)
                mNote = Value
            End Set
        End Property
        Public Property Refills() As RefillsType
            Get
                Return mRefills
            End Get
            Set(ByVal Value As RefillsType)
                mRefills = Value
            End Set
        End Property
        Public Property Substitutions() As String
            Get
                Return mSubstitutions
            End Get
            Set(ByVal Value As String)
                mSubstitutions = Value
            End Set
        End Property
        Public Property WrittenDate() As DateType
            Get
                Return mWrittenDate
            End Get
            Set(ByVal Value As DateType)
                mWrittenDate = Value
            End Set
        End Property
        Public Property LastFillDate() As DateType
            Get
                Return mLastFillDate
            End Get
            Set(ByVal Value As DateType)
                mLastFillDate = Value
            End Set
        End Property
        Public Property Diagnosis() As Diagnosis
            Get
                Return mDiagnosis
            End Get
            Set(ByVal Value As Diagnosis)
                mDiagnosis = Value
            End Set
        End Property
        Public Property PriorAuthorization() As PriorAuthorizationType
            Get
                Return mPriorAuthorization
            End Get
            Set(ByVal Value As PriorAuthorizationType)
                mPriorAuthorization = Value
            End Set
        End Property
    End Class

    Public Class Diagnosis
        Private mQualifier As String = ""
        Private mPrimary As DiagnosisType = New DiagnosisType
        Private mSecondary As DiagnosisType = New DiagnosisType

        Public Property Qualifier() As String
            Get
                Return mQualifier
            End Get
            Set(ByVal Value As String)
                mQualifier = Value
            End Set
        End Property
        Public Property Primary() As DiagnosisType
            Get
                Return mPrimary
            End Get
            Set(ByVal Value As DiagnosisType)
                mPrimary = Value
            End Set
        End Property
        Public Property Secondary() As DiagnosisType
            Get
                Return mSecondary
            End Get
            Set(ByVal Value As DiagnosisType)
                mSecondary = Value
            End Set
        End Property
    End Class

    Public Class DrugCodedType
        Private mProductCode As String = ""
        Private mProductCodeQualifier As String = ""
        Private mDosageForm As String = ""
        Private mStrength As String = ""
        Private mStrengthUnits As String = ""
        Private mDrugDBCode As String = ""
        Private mDrugDBCodeQualifier As String = ""

        Public Property ProductCode() As String
            Get
                Return mProductCode
            End Get
            Set(ByVal Value As String)
                mProductCode = Value
            End Set
        End Property
        Public Property ProductCodeQualifier() As String
            Get
                Return mProductCodeQualifier
            End Get
            Set(ByVal Value As String)
                mProductCodeQualifier = Value
            End Set
        End Property
        Public Property DosageForm() As String
            Get
                Return mDosageForm
            End Get
            Set(ByVal Value As String)
                mDosageForm = Value
            End Set
        End Property
        Public Property Strength() As String
            Get
                Return mStrength
            End Get
            Set(ByVal Value As String)
                mStrength = Value
            End Set
        End Property
        Public Property StrengthUnits() As String
            Get
                Return mStrengthUnits
            End Get
            Set(ByVal Value As String)
                mStrengthUnits = Value
            End Set
        End Property
        Public Property DrugDBCode() As String
            Get
                Return mDrugDBCode
            End Get
            Set(ByVal Value As String)
                mDrugDBCode = Value
            End Set
        End Property
        Public Property DrugDBCodeQualifier() As String
            Get
                Return mDrugDBCodeQualifier
            End Get
            Set(ByVal Value As String)
                mDrugDBCodeQualifier = Value
            End Set
        End Property
    End Class

    Public Class QuantityType
        Private mQualifier As String = ""
        Private mValue As String = ""
        Public Property Qualifier() As String
            Get
                Return mQualifier
            End Get
            Set(ByVal Value As String)
                mQualifier = Value
            End Set
        End Property
        Public Property Value() As String
            Get
                Return mValue
            End Get
            Set(ByVal Value As String)
                mValue = Value
            End Set
        End Property
    End Class

    Public Class RefillsType
        Private mQualifier As String = ""
        Private mQuantity As String = ""
        Public Property Qualifier() As String
            Get
                Return mQualifier
            End Get
            Set(ByVal Value As String)
                mQualifier = Value
            End Set
        End Property
        Public Property Quantity() As String
            Get
                Return mQuantity
            End Get
            Set(ByVal Value As String)
                mQuantity = Value
            End Set
        End Property
    End Class

    Public Class DiagnosisType
        Private mQualifier As String = ""
        Private mValue As String = ""
        Public Property Qualifier() As String
            Get
                Return mQualifier
            End Get
            Set(ByVal Value As String)
                mQualifier = Value
            End Set
        End Property
        Public Property Value() As String
            Get
                Return mValue
            End Get
            Set(ByVal Value As String)
                mValue = Value
            End Set
        End Property
    End Class

    Public Class PriorAuthorizationType
        Private mQualifier As String = ""
        Private mValue As String = ""
        Public Property Qualifier() As String
            Get
                Return mQualifier
            End Get
            Set(ByVal Value As String)
                mQualifier = Value
            End Set
        End Property
        Public Property Value() As String
            Get
                Return mValue
            End Get
            Set(ByVal Value As String)
                mValue = Value
            End Set
        End Property

    End Class

    Public Class NameType
        Private mLastName As String = ""
        Private mFirstName As String = ""
        Private mMiddleName As String = ""
        Private mSuffix As String = ""
        Private mPrefix As String = ""

        Public Property LastName() As String
            Get
                Return mLastName
            End Get
            Set(ByVal Value As String)
                mLastName = Value
            End Set
        End Property
        Public Property FirstName() As String
            Get
                Return mFirstName
            End Get
            Set(ByVal Value As String)
                mFirstName = Value
            End Set
        End Property
        Public Property MiddleName() As String
            Get
                Return mMiddleName
            End Get
            Set(ByVal Value As String)
                mMiddleName = Value
            End Set
        End Property
        Public Property Suffix() As String
            Get
                Return mSuffix
            End Get
            Set(ByVal Value As String)
                mSuffix = Value
            End Set
        End Property
        Public Property Prefix() As String
            Get
                Return mPrefix
            End Get
            Set(ByVal Value As String)
                mPrefix = Value
            End Set
        End Property
    End Class

    Public Class MandatoryNameType
        Private mLastName As String = ""
        Private mFirstName As String = ""
        Private mMiddleName As String = ""
        Private mSuffix As String = ""
        Private mPrefix As String = ""

        Public Property LastName() As String
            Get
                Return mLastName
            End Get
            Set(ByVal Value As String)
                mLastName = Value
            End Set
        End Property
        Public Property FirstName() As String
            Get
                Return mFirstName
            End Get
            Set(ByVal Value As String)
                mFirstName = Value
            End Set
        End Property
        Public Property MiddleName() As String
            Get
                Return mMiddleName
            End Get
            Set(ByVal Value As String)
                mMiddleName = Value
            End Set
        End Property
        Public Property Suffix() As String
            Get
                Return mSuffix
            End Get
            Set(ByVal Value As String)
                mSuffix = Value
            End Set
        End Property
        Public Property Prefix() As String
            Get
                Return mPrefix
            End Get
            Set(ByVal Value As String)
                mPrefix = Value
            End Set
        End Property
    End Class

    Public Class AddressType
        Private mAddressLine1 As String = ""
        Private mAddressLine2 As String = ""
        Private mCity As String = ""
        Private mState As String = ""
        Private mZipCode As String = ""

        Public Property AddressLine1() As String
            Get
                Return mAddressLine1
            End Get
            Set(ByVal Value As String)
                mAddressLine1 = Value
            End Set
        End Property
        Public Property AddressLine2() As String
            Get
                Return mAddressLine2
            End Get
            Set(ByVal Value As String)
                mAddressLine2 = Value
            End Set
        End Property
        Public Property City() As String
            Get
                Return mCity
            End Get
            Set(ByVal Value As String)
                mCity = Value
            End Set
        End Property
        Public Property State() As String
            Get
                Return mState
            End Get
            Set(ByVal Value As String)
                mState = Value
            End Set
        End Property
        Public Property ZipCode() As String
            Get
                Return mZipCode
            End Get
            Set(ByVal Value As String)
                mZipCode = Value
            End Set
        End Property
    End Class

    Public Class MandatoryAddressType
        Private mAddressLine1 As String = ""
        Private mAddressLine2 As String = ""
        Private mCity As String = ""
        Private mState As String = ""
        Private mZipCode As String = ""

        Public Property AddressLine1() As String
            Get
                Return mAddressLine1
            End Get
            Set(ByVal Value As String)
                mAddressLine1 = Value
            End Set
        End Property
        Public Property AddressLine2() As String
            Get
                Return mAddressLine2
            End Get
            Set(ByVal Value As String)
                mAddressLine2 = Value
            End Set
        End Property
        Public Property City() As String
            Get
                Return mCity
            End Get
            Set(ByVal Value As String)
                mCity = Value
            End Set
        End Property
        Public Property State() As String
            Get
                Return mState
            End Get
            Set(ByVal Value As String)
                mState = Value
            End Set
        End Property
        Public Property ZipCode() As String
            Get
                Return mZipCode
            End Get
            Set(ByVal Value As String)
                mZipCode = Value
            End Set
        End Property
    End Class

    Public Class PhoneNumbersType
        Private mPhone() As PhoneType
        Public Property Phone() As PhoneType()
            Get
                Return mPhone
            End Get
            Set(ByVal Value As PhoneType())
                mPhone = Value
            End Set
        End Property
    End Class

    Public Class PhoneType
        Private mNumber As String = ""
        Private mQualifier As String = "TE"

        Public Property Number() As String
            Get
                Return Common.ChangePhoneFormat(mNumber)
            End Get
            Set(ByVal Value As String)
                mNumber = Common.ChangePhoneFormat(Value)
            End Set
        End Property
        Public Property Qualifier() As String
            Get
                Return mQualifier
            End Get
            Set(ByVal Value As String)
                mQualifier = Value
            End Set
        End Property
    End Class

    Public Class ReceivedMessage
        Private mHeaderType As New HeaderType
        Private mStatusType As New StatusType
        Private mErrorType As New ErrorType
        Private mMessageType As String = ""

        Public Property HeaderType() As HeaderType
            Get
                Return mHeaderType
            End Get
            Set(ByVal Value As HeaderType)
                mHeaderType = Value
            End Set
        End Property

        Public Property StatusType() As StatusType
            Get
                Return mStatusType
            End Get
            Set(ByVal Value As StatusType)
                mStatusType = Value
            End Set
        End Property

        Public Property ErrorType() As ErrorType
            Get
                Return mErrorType
            End Get
            Set(ByVal Value As ErrorType)
                mErrorType = Value
            End Set
        End Property

        Public Property MessageType() As String
            Get
                Return mMessageType
            End Get
            Set(ByVal Value As String)
                mMessageType = Value
            End Set
        End Property

        Public Function WriteXMLForStatusORError(ByVal lFileName As String)
            ', ByVal filename As String


            Dim XmlDoc As New XmlDocument
            Dim XmlNode As XmlElement
            Dim str As String

            'Try
            '    XmlDoc.LoadXml("<Message></Message>")
            '    XmlDoc.DocumentElement.SetAttribute("xmlns",  


            '    XmlNode = XmlDoc.CreateElement("Header")
            '    XmlNodeTo = XmlDoc.CreateElement("To")
            '    XmlNode.AppendChild(  

            '    XmlNode.SetAttribute("Name", name)
            '    XmlNode.SetAttribute("FName", fname)
            '    XmlNode.SetAttribute("DOB", dob)
            '    XmlNode.SetAttribute("Gender", gender)
            '    XmlNode.SetAttribute("MStatus", mstatus)
            '    XmlNode.SetAttribute("NIC", nic)
            '    XmlNode.SetAttribute("Designation", designation)
            '    XmlNode.SetAttribute("Department", department)
            '    XmlNode.SetAttribute("Phone", phone)
            '    XmlNode.SetAttribute("Mobile", mobile)
            '    XmlNode.SetAttribute("Status", Status)

            '    XmlDoc.DocumentElement.AppendChild(XmlNode.CloneNode(True))


            '    Con.RunSPReturnBool(XmlDoc.OuterXml.ToString, "usp_InsertEmployee")
            'Catch ex As Exception
            '    'MsgBox(ex.Message)
            'Finally
            '    '==============
            Dim xmlw As XmlTextWriter
            Dim lResult As Boolean
            Try
                'path & "\\" & 
                xmlw = New XmlTextWriter(lFileName, Nothing)
                xmlw.Formatting = Formatting.Indented
                xmlw.WriteStartElement("Message")
                xmlw.WriteAttributeString("xmlns", "http://www.surescripts.com/messaging")
                xmlw.WriteAttributeString("version", "1.0")

                '' Header complex type element
                xmlw.WriteStartElement("Header")

                xmlw.WriteStartElement("To")
                xmlw.WriteString(Me.HeaderType.To.MailAddress)
                xmlw.WriteEndElement()

                xmlw.WriteStartElement("From")
                xmlw.WriteString(Me.HeaderType.From.MailAddress)
                xmlw.WriteEndElement()

                xmlw.WriteStartElement("MessageID")
                xmlw.WriteString(Me.HeaderType.MesssageID)
                xmlw.WriteEndElement()

                xmlw.WriteStartElement("RelatesToMessageID")
                xmlw.WriteString(Me.HeaderType.RelatesToMessageID)
                xmlw.WriteEndElement()

                xmlw.WriteStartElement("SentTime")
                xmlw.WriteString(Me.HeaderType.SentTime.UtcDate)
                xmlw.WriteEndElement()

                xmlw.WriteStartElement("TestMessage")
                xmlw.WriteString("")
                xmlw.WriteEndElement()
                xmlw.WriteEndElement()
                ''' End Header Complex type




                ''' Body complex type
                xmlw.WriteStartElement("Body")

                If Me.MessageType.ToUpper = "ERROR" Then
                    ''' Status complex type
                    xmlw.WriteStartElement("Error")

                    xmlw.WriteStartElement("Code")
                    xmlw.WriteString(Me.ErrorType.Code)
                    xmlw.WriteEndElement()

                    If Me.ErrorType.DescriptionCode <> "" Then
                        xmlw.WriteStartElement("DescriptionCode")
                        xmlw.WriteString(Me.ErrorType.DescriptionCode)
                        xmlw.WriteEndElement()
                    End If

                    'xmlw.WriteStartElement("Description")
                    'xmlw.WriteString(Me.ErrorType.Description)
                    'xmlw.WriteEndElement()
                Else
                    ''' Status complex type
                    xmlw.WriteStartElement("Status")

                    xmlw.WriteStartElement("Code")
                    xmlw.WriteString(Me.StatusType.Code)
                    xmlw.WriteEndElement()

                    'xmlw.WriteStartElement("Description")
                    'xmlw.WriteString(Me.StatusType.Description)
                    'xmlw.WriteEndElement()
                End If


                ''' End Element Of Status Tag
                xmlw.WriteEndElement()

                ''' End Body complex type
                xmlw.WriteEndElement()
                ''' End Message complex type
                xmlw.WriteEndDocument()

            Catch ex As Exception
                Dim a As String
                a = ex.Message
            Finally
                If Not xmlw Is Nothing Then
                    xmlw.Flush()
                    xmlw.Close()
                End If
            End Try

        End Function
    End Class

End Namespace

