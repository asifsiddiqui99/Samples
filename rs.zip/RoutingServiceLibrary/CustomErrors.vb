﻿Imports Microsoft.VisualBasic
Imports System.Data
Imports System.Configuration

Public Class CustomErrorsDB
#Region "Attributes"

    Private mCustomErrorId As String
    Private mCode As String
    Private mMessage As String

#End Region
#Region "Properties"
    Public Property CustomErrorId() As String
        Get
            Return mCustomErrorId
        End Get
        Set(ByVal value As String)
            mCustomErrorId = value
        End Set
    End Property

    Public Property Code() As String
        Get
            Return mCode
        End Get
        Set(ByVal value As String)
            mCode = value
        End Set
    End Property

    Public Property Message() As String
        Get
            Return mMessage
        End Get
        Set(ByVal value As String)
            mMessage = value
        End Set
    End Property

#End Region
End Class
Public Class CustomErrors

#Region "Fields"
    Private mConnection As ElixirLibrary.Connection
    Private mConnectionString As String
    Private mCustomErrors As New CustomErrorsDB
#End Region

#Region "Property"
    Public ReadOnly Property Connection() As ElixirLibrary.Connection
        Get
            Return mConnection
        End Get
    End Property

    Public ReadOnly Property ConnectionString() As String
        Get
            Return mConnectionString
        End Get
    End Property

    Public Property CustomErrors() As CustomErrorsDB
        Get
            Return mCustomErrors
        End Get
        Set(ByVal value As CustomErrorsDB)
            mCustomErrors = value
        End Set
    End Property
#End Region

#Region "Constructor"
    ''' <summary>
    ''' Uses Default Connection String 
    ''' </summary>
    ''' <remarks>
    ''' 
    ''' Created because Dose Table is in RxCureMaster Database
    ''' </remarks>
    Sub New()
        mConnectionString = ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString()
        mConnection = New ElixirLibrary.Connection(mConnectionString)
    End Sub

    ''' <summary>
    ''' Assign given connection to the current Object
    ''' </summary>
    ''' <param name="pConnection">
    ''' Contains refrence to the connection object
    ''' </param>
    ''' <remarks>
    ''' Use when  using Transaction
    ''' Must Specify Connection other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnection As ElixirLibrary.Connection)
        If pConnection Is Nothing Then
            Throw New ArgumentException("Connection can not be empty")
        End If

        mConnection = pConnection
    End Sub

#End Region

    Public Function GetCustomErrorMessage(ByVal pCode As String, ByVal pDescriptionCode As String) As String
        Dim lQuery As String
        Dim lDs As DataSet

        Try
            lQuery = "Select RC.Code, DescriptionCode, Type, " _
                & "Case When CustomErrorCode Is Null Then " _
                & "	RC.[Description] " _
                & "Else " _
                & "	CE.Message " _
                & "End AS Message, CE.CustomErrorId " _
                & "From ReferenceCodes RC, CustomErrors CE " _
                & "Where RC.CustomErrorCode = CE.Code  " _
                & "And RC.Code = '" & pCode & "' "


            If pDescriptionCode <> "" Then
                lQuery = lQuery + " And DescriptionCode = " + pDescriptionCode + " "
            End If

            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If


            With lDs.Tables(0)
                If .Rows.Count > 0 Then
                    Me.CustomErrors.CustomErrorId = .Rows(0)("CustomErrorId")
                    Me.CustomErrors.Code = .Rows(0)("Code")
                    Me.CustomErrors.Message = .Rows(0)("Message")

                    Return True
                End If
            End With

        Catch ex As Exception
            Throw New Exception(ex.Message + " : DAL\CustomErrors.GetCustomErrorMessage(ByVal pCode As String, ByVal pDescriptionCode As String) ")
        End Try


        Return False
    End Function
End Class