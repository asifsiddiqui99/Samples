﻿
<DataContract()>
Public Class SearchPharmacyResult
    <DataMember(Order:=1)>
    Public Property NCPDPID As String

    <DataMember(Order:=2)>
    Public Property StoreName As String

    <DataMember(Order:=3)>
    Public Property AddressLine1 As String

    <DataMember(Order:=4)>
    Public Property AddressLine2 As String

    <DataMember(Order:=5)>
    Public Property City As String

    <DataMember(Order:=6)>
    Public Property State As String

    <DataMember(Order:=7)>
    Public Property Zip As String

    <DataMember(Order:=8)>
    Public Property PrimaryPhone As String

    <DataMember(Order:=9)>
    Public Property Fax As String

    <DataMember(Order:=10)>
    Public Property Email As String

    <DataMember(Order:=11)>
    Public Property ActiveStartTime As DateTime

    <DataMember(Order:=12)>
    Public Property ActiveEndTime As DateTime

    <DataMember(Order:=13)>
    Public Property IsMailOrderPharmacy As String

End Class
