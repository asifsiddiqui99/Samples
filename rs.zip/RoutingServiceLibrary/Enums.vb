﻿Imports Microsoft.VisualBasic

<DataContract()> _
Public Enum Gender
    <EnumMember()> Male
    <EnumMember()> Female
End Enum




<DataContract()> _
Public Enum QuantityQualifiers
    <EnumMember()> C48473
    <EnumMember()> C62412
    <EnumMember()> C78783
    <EnumMember()> C48474
    <EnumMember()> C48475
    <EnumMember()> C53495
    <EnumMember()> C54564
    <EnumMember()> C53498
    <EnumMember()> C48476
    <EnumMember()> C48477
    <EnumMember()> C48478
    <EnumMember()> C48479
    <EnumMember()> C62413
    <EnumMember()> C64696
    <EnumMember()> C48480
    <EnumMember()> C54702
    <EnumMember()> C48481
    <EnumMember()> C62414
    <EnumMember()> C69093
    <EnumMember()> C48484
    <EnumMember()> C48489
    <EnumMember()> C48490
    <EnumMember()> C62417
    <EnumMember()> C96265
    <EnumMember()> C64933
    <EnumMember()> C53499
    <EnumMember()> C48494
    <EnumMember()> C48580
    <EnumMember()> C48155
    <EnumMember()> C69124
    <EnumMember()> C48499
    <EnumMember()> C48501
    <EnumMember()> C62275
    <EnumMember()> C62418
    <EnumMember()> C62276
    <EnumMember()> C67283
    <EnumMember()> C28252
    <EnumMember()> C48504
    <EnumMember()> C48505
    <EnumMember()> C48506
    <EnumMember()> C48491
    <EnumMember()> C28253
    <EnumMember()> C28254
    <EnumMember()> C28251
    <EnumMember()> C71204
    <EnumMember()> C100052
    <EnumMember()> C69086
    <EnumMember()> C48519
    <EnumMember()> C48520
    <EnumMember()> C48521
    <EnumMember()> C65032
    <EnumMember()> C82484
    <EnumMember()> C48524
    <EnumMember()> C48529
    <EnumMember()> C48530
    <EnumMember()> C48531
    <EnumMember()> C65060
    <EnumMember()> C48534
    <EnumMember()> C62609
    <EnumMember()> C71324
    <EnumMember()> C48536
    <EnumMember()> C53502
    <EnumMember()> C48537
    <EnumMember()> C53503
    <EnumMember()> C48538
    <EnumMember()> C48539
    <EnumMember()> C53504
    <EnumMember()> C48540
    <EnumMember()> C48541
    <EnumMember()> C48542
    <EnumMember()> C62421
    <EnumMember()> C48543
    <EnumMember()> C48544
    <EnumMember()> C54704
    <EnumMember()> C48548
    <EnumMember()> C48549
    <EnumMember()> C38046
    <EnumMember()> C48551
    <EnumMember()> C48552


End Enum

<DataContract()> _
Public Enum RefillQualifiers
    <EnumMember()> R
    <EnumMember()> PRN
End Enum

<DataContract()> _
Public Enum Substitution
    <EnumMember()> SubstituationAllowed = 0
    <EnumMember()> DispenseAsWritten = 1
End Enum


<DataContract()> _
Public Enum States
    <EnumMember()> AL
    <EnumMember()> AK
    <EnumMember()> AZ
    <EnumMember()> AR
    <EnumMember()> [AS] 'Territory
    <EnumMember()> CA
    <EnumMember()> CO
    <EnumMember()> CT
    <EnumMember()> DE
    <EnumMember()> DC
    <EnumMember()> FL
    <EnumMember()> FM 'Territory
    <EnumMember()> GA
    <EnumMember()> GU 'Territory
    <EnumMember()> HI
    <EnumMember()> ID
    <EnumMember()> IL
    <EnumMember()> [IN]
    <EnumMember()> IA
    <EnumMember()> KS
    <EnumMember()> KY
    <EnumMember()> LA
    <EnumMember()> [ME]
    <EnumMember()> MD
    <EnumMember()> MA
    <EnumMember()> MH 'Territory
    <EnumMember()> MI
    <EnumMember()> MN
    <EnumMember()> MS
    <EnumMember()> MO
    <EnumMember()> MP ' Territory
    <EnumMember()> MT
    <EnumMember()> NE
    <EnumMember()> NV
    <EnumMember()> NH
    <EnumMember()> NJ
    <EnumMember()> NM
    <EnumMember()> NY
    <EnumMember()> NC
    <EnumMember()> ND
    <EnumMember()> OH
    <EnumMember()> OK
    <EnumMember()> [OR]
    <EnumMember()> PA
    <EnumMember()> PR 'Territory 
    <EnumMember()> PW 'Territory
    <EnumMember()> RI
    <EnumMember()> SC
    <EnumMember()> SD
    <EnumMember()> TN
    <EnumMember()> TX
    <EnumMember()> UT
    <EnumMember()> VI 'Territory
    <EnumMember()> VT
    <EnumMember()> VA
    <EnumMember()> WA
    <EnumMember()> WV
    <EnumMember()> WI
    <EnumMember()> WY













End Enum