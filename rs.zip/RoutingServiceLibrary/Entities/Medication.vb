﻿Imports Microsoft.VisualBasic
<DataContract()>
Public Class Medication

    Private m_IsFromFHVCDatabase As String
    <DataMember()>
    Public Property IsFromFHVCDatabase() As String
        Get
            Return m_IsFromFHVCDatabase
        End Get
        Set(ByVal value As String)
            m_IsFromFHVCDatabase = value
        End Set
    End Property

    Private m_DaysSupply As String
    <DataMember()>
    Public Property DaysSupply() As String
        Get
            Return m_DaysSupply
        End Get
        Set(ByVal value As String)
            m_DaysSupply = value
        End Set
    End Property
    Private m_Directions As String
    <DataMember()>
    Public Property Directions() As String
        Get
            Return m_Directions
        End Get
        Set(ByVal value As String)
            m_Directions = value
        End Set
    End Property

    Private m_DrugDescription As String
    <DataMember()>
    Public Property DrugDescription() As String
        Get
            Return m_DrugDescription
        End Get
        Set(ByVal value As String)
            m_DrugDescription = value
        End Set
    End Property

    Private m_QuantityQualifier As String
    <DataMember()>
    Public Property QuantityQualifier() As String
        Get
            Return m_QuantityQualifier
        End Get
        Set(ByVal value As String)
            m_QuantityQualifier = value
        End Set
    End Property

    Private m_QuantityValue As String
    <DataMember()>
    Public Property QuantityValue() As String
        Get
            Return m_QuantityValue
        End Get
        Set(ByVal value As String)
            m_QuantityValue = value
        End Set
    End Property

    Private m_Note As String
    <DataMember()>
    Public Property Note() As String
        Get
            Return m_Note
        End Get
        Set(ByVal value As String)
            m_Note = value
        End Set
    End Property

    Private m_RefillsQuantifier As String
    <DataMember()>
    Public Property RefillsQuantifier() As String
        Get
            Return m_RefillsQuantifier
        End Get
        Set(ByVal value As String)
            m_RefillsQuantifier = value
        End Set
    End Property

    Private m_RefillsQuantityValue As String
    <DataMember()>
    Public Property RefillsQuantityValue() As String
        Get
            Return m_RefillsQuantityValue
        End Get
        Set(ByVal value As String)
            m_RefillsQuantityValue = value
        End Set
    End Property

    Private m_Substitutions As String
    <DataMember()>
    Public Property Substitutions() As String
        Get
            Return m_Substitutions
        End Get
        Set(ByVal value As String)
            m_Substitutions = value
        End Set
    End Property

    Private m_IsDevice As String
    <DataMember()>
    Public Property IsDevice() As String
        Get
            Return m_IsDevice
        End Get
        Set(ByVal value As String)
            m_IsDevice = value
        End Set
    End Property

    Private m_DrugNDC As String
    <DataMember()>
    Public Property DrugNDC() As String
        Get
            Return m_DrugNDC
        End Get
        Set(ByVal value As String)
            m_DrugNDC = value
        End Set
    End Property

    Private m_RxNorm As String
    <DataMember()>
    Public Property RxNorm() As String
        Get
            Return m_RxNorm
        End Get
        Set(ByVal value As String)
            m_RxNorm = value
        End Set
    End Property

    Private m_RxID As String
    <DataMember()>
    Public Property RxID() As String
        Get
            Return m_RxID
        End Get
        Set(ByVal value As String)
            m_RxID = value
        End Set
    End Property

End Class
