﻿Imports Microsoft.VisualBasic
<DataContract()>
Public Class Patient

    <DataMember()>
    Public Property PatientID() As String
        Get
            Return m_PatientID
        End Get
        Set(value As String)
            m_PatientID = value
        End Set
    End Property
    Private m_PatientID As String
    <DataMember()>
    Public Property LastName() As String
        Get
            Return m_LastName
        End Get
        Set(value As String)
            m_LastName = value
        End Set
    End Property
    Private m_LastName As String
    <DataMember()>
    Public Property FirstName() As String
        Get
            Return m_FirstName
        End Get
        Set(value As String)
            m_FirstName = value
        End Set
    End Property
    Private m_FirstName As String
    <DataMember()>
    Public Property City() As String
        Get
            Return m_City
        End Get
        Set(value As String)
            m_City = value
        End Set
    End Property
    Private m_City As String
    <DataMember()>
    Public Property State() As String
        Get
            Return m_State
        End Get
        Set(value As String)
            m_State = value
        End Set
    End Property
    Private m_State As String
    <DataMember()>
    Public Property Zip() As String
        Get
            Return m_Zip
        End Get
        Set(value As String)
            m_Zip = value
        End Set
    End Property
    Private m_Zip As String
    <DataMember()>
    Public Property Phone() As String
        Get
            Return m_Phone
        End Get
        Set(value As String)
            m_Phone = value
        End Set
    End Property
    Private m_Phone As String

    Private m_SSN As String
    <DataMember()>
    Public Property SSN() As String
        Get
            Return m_SSN
        End Get
        Set(ByVal value As String)
            m_SSN = value
        End Set
    End Property

    Private m_Gender As String
    <DataMember()>
    Public Property Gender() As String
        Get
            Return m_Gender
        End Get
        Set(ByVal value As String)
            m_Gender = value
        End Set
    End Property

    Private m_DOB As String
    <DataMember()>
    Public Property DOB() As String
        Get
            Return m_DOB
        End Get
        Set(ByVal value As String)
            m_DOB = value
        End Set
    End Property

    Private m_AddressLine1 As String
    <DataMember()>
    Public Property AddressLine1() As String
        Get
            Return m_AddressLine1
        End Get
        Set(ByVal value As String)
            m_AddressLine1 = value
        End Set
    End Property


    Private m_AddressLine2 As String
    <DataMember()>
    Public Property AddressLine2() As String
        Get
            Return m_AddressLine2
        End Get
        Set(ByVal value As String)
            m_AddressLine2 = value
        End Set
    End Property



    Private m_LoggedInUserID As String
    <DataMember()>
    Public Property LoggedInUserID() As String
        Get
            Return m_LoggedInUserID
        End Get
        Set(ByVal value As String)
            m_LoggedInUserID = value
        End Set
    End Property

    Private m_PreferredPharmacyNCPDPID As String
    <DataMember()>
    Public Property PreferredPharmacyNCPDPID() As String
        Get
            Return m_PreferredPharmacyNCPDPID
        End Get
        Set(ByVal value As String)
            m_PreferredPharmacyNCPDPID = value
        End Set
    End Property


End Class
