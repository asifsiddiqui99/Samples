﻿Imports Microsoft.VisualBasic
<DataContract()>
Public Class Clinic


    <DataMember()>
    Public Property ClinicCode() As String
        Get
            Return m_ClinicCode
        End Get
        Set(value As String)
            m_ClinicCode = value
        End Set
    End Property
    Private m_ClinicCode As String

    <DataMember()>
    Public Property Name() As String
        Get
            Return m_Name
        End Get
        Set(value As String)
            m_Name = value
        End Set
    End Property
    Private m_Name As String

    <DataMember()>
    Public Property City() As String
        Get
            Return m_City
        End Get
        Set(value As String)
            m_City = value
        End Set
    End Property
    Private m_City As String

    <DataMember()>
    Public Property State() As String
        Get
            Return m_State
        End Get
        Set(value As String)
            m_State = value
        End Set
    End Property
    Private m_State As String

    <DataMember()>
    Public Property Zip() As String
        Get
            Return m_Zip
        End Get
        Set(value As String)
            m_Zip = value
        End Set
    End Property
    Private m_Zip As String

    <DataMember()>
    Public Property Phone() As String
        Get
            Return m_Phone
        End Get
        Set(value As String)
            m_Phone = value
        End Set
    End Property
    Private m_Phone As String
End Class
