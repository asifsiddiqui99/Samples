﻿Imports Microsoft.VisualBasic
<DataContract()>
Public Class Allergy


    Private m_AllergyType As String
    <DataMember()>
    Public Property AllergyType() As String
        Get
            Return m_AllergyType
        End Get
        Set(ByVal value As String)
            m_AllergyType = value
        End Set
    End Property


    Private m_RxNomID As String
    <DataMember()>
    Public Property RxNomID() As String
        Get
            Return m_RxNomID
        End Get
        Set(ByVal value As String)
            m_RxNomID = value
        End Set
    End Property

    Private m_Description As String
    <DataMember()>
    Public Property Description() As String
        Get
            Return m_Description
        End Get
        Set(ByVal value As String)
            m_Description = value
        End Set
    End Property

    Private m_ReactionType As String
    <DataMember()>
    Public Property ReactionType() As String
        Get
            Return m_ReactionType
        End Get
        Set(ByVal value As String)
            m_ReactionType = value
        End Set
    End Property

    Private m_Reaction As String
    <DataMember()>
    Public Property Reaction() As String
        Get
            Return m_Reaction
        End Get
        Set(ByVal value As String)
            m_Reaction = value
        End Set
    End Property

    Private m_Severity As String
    <DataMember()>
    Public Property Severity() As String
        Get
            Return m_Severity
        End Get
        Set(ByVal value As String)
            m_Severity = value
        End Set
    End Property

    Private m_OnSetDate As String
    <DataMember()>
    Public Property OnSetDate() As String
        Get
            Return m_OnSetDate
        End Get
        Set(ByVal value As String)
            m_OnSetDate = value
        End Set
    End Property

    Private m_Notes As String
    <DataMember()>
    Public Property Notes() As String
        Get
            Return m_Notes
        End Get
        Set(ByVal value As String)
            m_Notes = value
        End Set
    End Property



End Class
