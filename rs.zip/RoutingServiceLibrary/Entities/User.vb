﻿Imports Microsoft.VisualBasic
<DataContract()>
Public Class User

    <DataMember()>
    Public Property LoginID() As String
        Get
            Return m_LoginID
        End Get
        Set(value As String)
            m_LoginID = value
        End Set
    End Property
    Private m_LoginID As String
    <DataMember()>
    Public Property LastName() As String
        Get
            Return m_LastName
        End Get
        Set(value As String)
            m_LastName = value
        End Set
    End Property
    Private m_LastName As String
    <DataMember()>
    Public Property FirstName() As String
        Get
            Return m_FirstName
        End Get
        Set(value As String)
            m_FirstName = value
        End Set
    End Property
    Private m_FirstName As String
    <DataMember()>
    Public Property City() As String
        Get
            Return m_City
        End Get
        Set(value As String)
            m_City = value
        End Set
    End Property
    Private m_City As String
    <DataMember()>
    Public Property State() As String
        Get
            Return m_State
        End Get
        Set(value As String)
            m_State = value
        End Set
    End Property
    Private m_State As String
    <DataMember()>
    Public Property Zip() As String
        Get
            Return m_Zip
        End Get
        Set(value As String)
            m_Zip = value
        End Set
    End Property
    Private m_Zip As String
    <DataMember()>
    Public Property Phone() As String
        Get
            Return m_Phone
        End Get
        Set(value As String)
            m_Phone = value
        End Set
    End Property
    Private m_Phone As String

    Private m_PrescriberSPI As String
    <DataMember()>
    Public Property PrescriberSPI() As String
        Get
            Return m_PrescriberSPI
        End Get
        Set(ByVal value As String)
            m_PrescriberSPI = value
        End Set
    End Property
End Class
