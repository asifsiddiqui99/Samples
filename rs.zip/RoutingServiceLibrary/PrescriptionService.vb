﻿' NOTE: You can use the "Rename" command on the context menu to change the class name "Service" in code, svc and config file together.

Imports ElixirLibrary
Imports SurescriptsLibrary
Imports SurescriptsLibrary.SureScripts
Imports System.IO
Imports System.Data
Imports System.Net
Imports System.Xml
Imports TraceLogging
Imports System.Configuration
Imports System.Text.RegularExpressions
Imports System.Xml.Schema
Imports System.Xml.Serialization
Imports RxHub
Imports System.ServiceModel.Channels


<ServiceBehavior(InstanceContextMode:=InstanceContextMode.Single)>
Public Class PrescriptionService
    Implements IPrescriptionService


    Public Sub New()
    End Sub

    Public Function GetData(ByVal value As Integer) As String Implements IPrescriptionService.GetData
        Return String.Format("You entered: {0}", value)
    End Function

    Function PostPanaceaAdmin(ByVal panaceaAdminRequest As PanaceaAdminRequest) As ResponseData Implements IPrescriptionService.PostPanaceaAdmin
        Dim resDataToSend As ResponseData = New ResponseData
        Try

            If CheckClientIP() Then

                If Not IsNothing(panaceaAdminRequest) Then

                    Dim clinicConnectionString = ClinicDBMethods.GetClinicConnectionString(panaceaAdminRequest.ClinicInfo.ClinicCode)

                    If Not String.IsNullOrEmpty(clinicConnectionString) Then
                        Dim lUserID As String = ClinicDBMethods.UpdateUser(panaceaAdminRequest.UserInfo, clinicConnectionString, resDataToSend.Message)
                        If Not String.IsNullOrEmpty(lUserID) AndAlso ClinicDBMethods.UpdateClinic(panaceaAdminRequest.ClinicInfo, clinicConnectionString) Then
                            Dim token As String = Encryption.Encrypt(panaceaAdminRequest.ClinicInfo.ClinicCode + "|" + lUserID & "|" & Guid.NewGuid().ToString())
                            Dim lClinicTokenID As Integer = ClinicDBMethods.InsertToken(panaceaAdminRequest.ClinicInfo, lUserID, clinicConnectionString, token, String.Empty, String.Empty, String.Empty)
                            If lClinicTokenID > 0 Then
                                resDataToSend.Status = "Succesfull"
                                resDataToSend.Message = "The request was succesful and return url was succesfully generated"
                                resDataToSend.UrlWithToken = ConfigurationManager.AppSettings("PanaceaURL") + "?" & Base64Encode("_func=panaceaadmin&_token=" & token & "&_tokenid=" & lClinicTokenID)
                            Else
                                resDataToSend.Status = "TokenGenerationError"
                                resDataToSend.Message = "The Doctor / User and Clinic  provided were found/created but token was not generated"
                            End If
                        Else
                            resDataToSend.Status = "UserOrClinicError"
                        End If



                    End If

                End If

            End If

        Catch ex As Exception

        End Try
        Return resDataToSend
    End Function



    Private Function CheckClientIP() As Boolean
        Try
            If Not String.IsNullOrEmpty(ConfigurationManager.AppSettings("ClientDomains")) Then
                Dim ipAddresses As String() = ConfigurationManager.AppSettings("ClientDomains").Split(","c)

                If ipAddresses.Length > 0 Then
                    Dim context As OperationContext = OperationContext.Current
                    Dim prop As MessageProperties = context.IncomingMessageProperties
                    Dim endpoint As RemoteEndpointMessageProperty = TryCast(prop(RemoteEndpointMessageProperty.Name), RemoteEndpointMessageProperty)
                    Dim ip As String = endpoint.Address
                    If Not String.IsNullOrEmpty(ip) Then
                        Return ConfigurationManager.AppSettings("ClientDomains").ToLower.Contains(ip)
                    End If
                End If
            End If

        Catch ex As Exception

        End Try
        Return True

    End Function
    Public Function Base64Encode(plainText As String) As String
        Return plainText 'HttpUtility.UrlEncode(System.Text.Encoding.UTF8.GetBytes(plainText))
    End Function

    Public Function PostCurrentMedicationRequest(currentMedicationRequest As CurrentMedicationRequest) As ResponseData Implements IPrescriptionService.PostCurrentMedicationRequest
        Dim resDataToSend As ResponseData = New ResponseData
        Try
            If CheckClientIP() Then

                If Not IsNothing(currentMedicationRequest) Then

                    Dim clinicConnectionString = ClinicDBMethods.GetClinicConnectionString(currentMedicationRequest.ClinicInfo.ClinicCode)

                    If Not String.IsNullOrEmpty(clinicConnectionString) Then
                        Dim lUserID As String = ClinicDBMethods.UpdateUser(currentMedicationRequest.UserInfo, clinicConnectionString, resDataToSend.Message)
                        If Not String.IsNullOrEmpty(lUserID) AndAlso ClinicDBMethods.UpdateClinic(currentMedicationRequest.ClinicInfo, clinicConnectionString) Then

                            Dim patientID As String = ClinicDBMethods.InsertUpdatePatient(currentMedicationRequest.PatientInfo, clinicConnectionString, resDataToSend.Message)


                            If Not String.IsNullOrEmpty(patientID) Then

                                Dim token As String = Encryption.Encrypt(currentMedicationRequest.ClinicInfo.ClinicCode & "|" & lUserID & "|" & patientID & "|" & Guid.NewGuid().ToString())
                                Dim lClinicTokenID As Integer = ClinicDBMethods.InsertToken(currentMedicationRequest.ClinicInfo, lUserID, clinicConnectionString, token, patientID, String.Empty, String.Empty)

                                If lClinicTokenID > 0 Then
                                    resDataToSend.Status = "Succesfull"
                                    resDataToSend.Message = "The request was succesful and return url was succesfully generated"
                                    resDataToSend.UrlWithToken = ConfigurationManager.AppSettings("PanaceaURL") + "?" & Base64Encode("_func=currentmedication&_token=" & token & "&_tokenid=" & lClinicTokenID)
                                Else
                                    resDataToSend.Status = "TokenGenerationError"
                                    resDataToSend.Message = "The Doctor / User and Clinic  provided were found/created but token was not generated"
                                End If

                            Else
                                resDataToSend.Status = "PatientInsertionError"
                                ''''''resDataToSend.Message = "The Patient was not being inserted in the Database"
                            End If


                        Else
                            resDataToSend.Status = "UserOrClinicError"
                        End If



                    End If

                End If

            End If
        Catch ex As Exception

        End Try
        Return resDataToSend
    End Function


    Function PostEpaRequest(ByVal epaRequest As EPARequest) As ResponseData Implements IPrescriptionService.PostEpaRequest
        Dim resDataToSend As ResponseData = New ResponseData
        Try

            If CheckClientIP() Then

                If Not IsNothing(epaRequest) Then

                    Dim clinicConnectionString = ClinicDBMethods.GetClinicConnectionString(epaRequest.ClinicInfo.ClinicCode)

                    If Not String.IsNullOrEmpty(clinicConnectionString) Then
                        Dim lUserID As String = ClinicDBMethods.UpdateUser(epaRequest.UserInfo, clinicConnectionString, resDataToSend.Message)
                        If Not String.IsNullOrEmpty(lUserID) AndAlso ClinicDBMethods.UpdateClinic(epaRequest.ClinicInfo, clinicConnectionString) Then
                            Dim token As String = Encryption.Encrypt(epaRequest.ClinicInfo.ClinicCode + "|" + lUserID & "|" & Guid.NewGuid().ToString())
                            Dim lClinicTokenID As Integer = ClinicDBMethods.InsertToken(epaRequest.ClinicInfo, lUserID, clinicConnectionString, token, String.Empty, String.Empty, String.Empty)
                            If lClinicTokenID > 0 Then
                                resDataToSend.Status = "Succesfull"
                                resDataToSend.Message = "The request was succesful and return url was succesfully generated"
                                resDataToSend.UrlWithToken = ConfigurationManager.AppSettings("PanaceaURL") + "?" & Base64Encode("_func=epa&_token=" & token & "&_tokenid=" & lClinicTokenID)
                            Else
                                resDataToSend.Status = "TokenGenerationError"
                                resDataToSend.Message = "The Doctor / User and Clinic  provided were found/created but token was not generated"
                            End If
                        Else
                            resDataToSend.Status = "UserOrClinicError"
                        End If



                    End If

                End If

            End If

        Catch ex As Exception

        End Try
        Return resDataToSend
    End Function

    Function PostEpcsRequest(ByVal epcsRequest As EPCSRequest) As ResponseData Implements IPrescriptionService.PostEpcsRequest
        Dim resDataToSend As ResponseData = New ResponseData
        Try

            If CheckClientIP() Then

                If Not IsNothing(epcsRequest) Then

                    Dim clinicConnectionString = ClinicDBMethods.GetClinicConnectionString(epcsRequest.ClinicInfo.ClinicCode)

                    If Not String.IsNullOrEmpty(clinicConnectionString) Then
                        Dim lUserID As String = ClinicDBMethods.UpdateUser(epcsRequest.UserInfo, clinicConnectionString, resDataToSend.Message)
                        If Not String.IsNullOrEmpty(lUserID) AndAlso ClinicDBMethods.UpdateClinic(epcsRequest.ClinicInfo, clinicConnectionString) Then
                            Dim token As String = Encryption.Encrypt(epcsRequest.ClinicInfo.ClinicCode + "|" + lUserID & "|" & Guid.NewGuid().ToString())
                            Dim lClinicTokenID As Integer = ClinicDBMethods.InsertToken(epcsRequest.ClinicInfo, lUserID, clinicConnectionString, token, String.Empty, String.Empty, String.Empty)
                            If lClinicTokenID > 0 Then
                                resDataToSend.Status = "Succesfull"
                                resDataToSend.Message = "The request was succesful and return url was succesfully generated"
                                resDataToSend.UrlWithToken = ConfigurationManager.AppSettings("PanaceaURL") + "?" & Base64Encode("_func=epcs&_token=" & token & "&_tokenid=" & lClinicTokenID)
                            Else
                                resDataToSend.Status = "TokenGenerationError"
                                resDataToSend.Message = "The Doctor / User and Clinic  provided were found/created but token was not generated"
                            End If
                        Else
                            resDataToSend.Status = "UserOrClinicError"
                        End If



                    End If

                End If

            End If

        Catch ex As Exception

        End Try
        Return resDataToSend
    End Function

    Function PostViewCurrentRequest(ByVal viewCurrentRequest As ViewCurrentRequest) As ResponseData Implements IPrescriptionService.PostViewCurrentRequest
        Dim resDataToSend As ResponseData = New ResponseData
        Try

            If CheckClientIP() Then

                If Not IsNothing(viewCurrentRequest) Then

                    Dim clinicConnectionString = ClinicDBMethods.GetClinicConnectionString(viewCurrentRequest.ClinicInfo.ClinicCode)

                    If Not String.IsNullOrEmpty(clinicConnectionString) Then
                        Dim lUserID As String = ClinicDBMethods.UpdateUser(viewCurrentRequest.UserInfo, clinicConnectionString, resDataToSend.Message)
                        If Not String.IsNullOrEmpty(lUserID) AndAlso ClinicDBMethods.UpdateClinic(viewCurrentRequest.ClinicInfo, clinicConnectionString) Then
                            Dim token As String = Encryption.Encrypt(viewCurrentRequest.ClinicInfo.ClinicCode + "|" + lUserID & "|" & Guid.NewGuid().ToString())
                            Dim lClinicTokenID As Integer = ClinicDBMethods.InsertToken(viewCurrentRequest.ClinicInfo, lUserID, clinicConnectionString, token, String.Empty, String.Empty, String.Empty)
                            If lClinicTokenID > 0 Then
                                resDataToSend.Status = "Succesfull"
                                resDataToSend.Message = "The request was succesful and return url was succesfully generated"
                                resDataToSend.UrlWithToken = ConfigurationManager.AppSettings("PanaceaURL") + "?" & Base64Encode("_func=viewcurrent&_token=" & token & "&_tokenid=" & lClinicTokenID)
                            Else
                                resDataToSend.Status = "TokenGenerationError"
                                resDataToSend.Message = "The Doctor / User and Clinic  provided were found/created but token was not generated"
                            End If
                        Else
                            resDataToSend.Status = "UserOrClinicError"
                        End If



                    End If

                End If

            End If

        Catch ex As Exception

        End Try
        Return resDataToSend
    End Function

    Function PostWritePrescriptionRequest(ByVal writePrescriptionRequest As WritePrescriptionRequest) As ResponseData Implements IPrescriptionService.PostWritePrescriptionRequest
        Dim resDataToSend As ResponseData = New ResponseData
        Try
            If CheckClientIP() Then

                If Not IsNothing(writePrescriptionRequest) Then

                    Dim clinicConnectionString = ClinicDBMethods.GetClinicConnectionString(writePrescriptionRequest.ClinicInfo.ClinicCode)

                    If Not String.IsNullOrEmpty(clinicConnectionString) Then
                        Dim lUserID As String = ClinicDBMethods.UpdateUser(writePrescriptionRequest.UserInfo, clinicConnectionString, resDataToSend.Message)
                        If Not String.IsNullOrEmpty(lUserID) AndAlso ClinicDBMethods.UpdateClinic(writePrescriptionRequest.ClinicInfo, clinicConnectionString) Then

                            Dim patientID As String = ClinicDBMethods.InsertUpdatePatient(writePrescriptionRequest.PatientInfo, clinicConnectionString, resDataToSend.Message)


                            If Not String.IsNullOrEmpty(patientID) Then

                                Dim token As String = Encryption.Encrypt(writePrescriptionRequest.ClinicInfo.ClinicCode & "|" & lUserID & "|" & patientID & "|" & Guid.NewGuid().ToString())

                                Dim lClinicTokenID As Integer = ClinicDBMethods.InsertToken(writePrescriptionRequest.ClinicInfo, lUserID, clinicConnectionString, token, patientID, String.Empty, String.Empty)

                                If lClinicTokenID > 0 Then
                                    resDataToSend.Status = "Succesfull"
                                    resDataToSend.Message = "The request was succesful and return url was succesfully generated"
                                    resDataToSend.UrlWithToken = ConfigurationManager.AppSettings("PanaceaURL") + "?" & Base64Encode("_func=writeprescription&_token=" & token & "&_tokenid=" & lClinicTokenID)
                                Else
                                    resDataToSend.Status = "TokenGenerationError"
                                    resDataToSend.Message = "The Doctor / User and Clinic  provided were found/created but token was not generated"
                                End If

                            Else
                                resDataToSend.Status = "PatientInsertionError"
                            End If


                        Else
                            resDataToSend.Status = "UserOrClinicError"
                        End If



                    End If

                End If

            End If
        Catch ex As Exception

        End Try
        Return resDataToSend
    End Function

    Function PostReWritePrescriptionRequest(ByVal reWritePrescriptionRequest As ReWritePrescriptionRequest) As ResponseData Implements IPrescriptionService.PostReWritePrescriptionRequest
        Dim resDataToSend As ResponseData = New ResponseData
        Try
            If CheckClientIP() Then

                If Not IsNothing(reWritePrescriptionRequest) Then

                    Dim clinicConnectionString = ClinicDBMethods.GetClinicConnectionString(reWritePrescriptionRequest.ClinicInfo.ClinicCode)

                    If Not String.IsNullOrEmpty(clinicConnectionString) Then
                        Dim lUserID As String = ClinicDBMethods.UpdateUser(reWritePrescriptionRequest.UserInfo, clinicConnectionString, resDataToSend.Message)
                        If Not String.IsNullOrEmpty(lUserID) AndAlso ClinicDBMethods.UpdateClinic(reWritePrescriptionRequest.ClinicInfo, clinicConnectionString) Then

                            Dim patientID As String = ClinicDBMethods.InsertUpdatePatient(reWritePrescriptionRequest.PatientInfo, clinicConnectionString, resDataToSend.Message)


                            If Not String.IsNullOrEmpty(patientID) Then

                                Dim lRxFromExternalID As Integer = ClinicDBMethods.InsertExternalRx(patientID, reWritePrescriptionRequest.MedicationInfo, lUserID, reWritePrescriptionRequest.UserInfo.PrescriberSPI, clinicConnectionString, resDataToSend.Message)

                                If lRxFromExternalID > 0 Then

                                    Dim token As String = Encryption.Encrypt(reWritePrescriptionRequest.ClinicInfo.ClinicCode & "|" & lUserID & "|" & patientID & "|" & lRxFromExternalID & "|" & reWritePrescriptionRequest.MedicationInfo.RxNorm & "|" & Guid.NewGuid().ToString())
                                    Dim lClinicTokenID As Integer = ClinicDBMethods.InsertToken(reWritePrescriptionRequest.ClinicInfo, lUserID, clinicConnectionString, token, patientID, reWritePrescriptionRequest.MedicationInfo.RxNorm, lRxFromExternalID)
                                    If lClinicTokenID > 0 Then

                                        ClinicDBMethods.InsertAllAllergies(patientID, lUserID, clinicConnectionString, reWritePrescriptionRequest.AllergyList, resDataToSend.Message)

                                        resDataToSend.Status = "Succesfull"
                                        Dim mainMessage As String = "The Medication Request was succesful and return url was succesfully generated"

                                        If (Not IsNothing(reWritePrescriptionRequest.AllergyList)) Then
                                            resDataToSend.Message = mainMessage & ". About Allergies; " & resDataToSend.Message
                                        Else
                                            resDataToSend.Message = mainMessage
                                        End If

                                        resDataToSend.UrlWithToken = ConfigurationManager.AppSettings("PanaceaURL") + "?" & Base64Encode("_func=rewriteprescription&_token=" & token & "&_tokenid=" & lClinicTokenID)




                                    Else
                                        resDataToSend.Status = "TokenGenerationError"
                                        resDataToSend.Message = "The Doctor / User and Clinic  provided were found/created but token was not generated"
                                    End If
                                Else
                                    resDataToSend.Status = "Medication Insertion Error"
                                End If

                            Else
                                resDataToSend.Status = "PatientInsertionError"
                                '''resDataToSend.Message = "The Patient was not being inserted in the Database"
                            End If


                        Else
                            resDataToSend.Status = "UserOrClinicError"
                        End If



                    End If

                End If

            End If
        Catch ex As Exception

        End Try
        Return resDataToSend
    End Function

    Function GetStateNames(ByVal pClinicCode As String) As DataTable Implements IPrescriptionService.GetStateNames
        Try

            Return ClinicDBMethods.GetStateNames(ClinicDBMethods.GetClinicConnectionString(pClinicCode))
        Catch ex As Exception

        End Try
        Return New DataTable
    End Function

    Function GetReactionTypes() As List(Of String) Implements IPrescriptionService.GetReactionTypes

        Dim reactions As New List(Of String)()
        Try

            reactions.Add("Unknown")
            reactions.Add("Intolerant Of Side Effects")
            reactions.Add("Side Effect")
            reactions.Add("True Allergy")
        Catch ex As Exception

        End Try
        Return reactions

    End Function
    Function GetIsFromFHVCOptions() As List(Of String) Implements IPrescriptionService.GetIsFromFHVCOptions
        Dim values = New List(Of String)()
        Try
            values.Add("Y")
            values.Add("N")
        Catch ex As Exception

        End Try
        Return values
    End Function

    Function GetIsDeviceOptions() As List(Of String) Implements IPrescriptionService.GetIsDeviceOptions
        Dim values = New List(Of String)
        Try
            values.Add("Y")
            values.Add("N")

        Catch ex As Exception

        End Try
        Return values
    End Function

    Function GetRefilQualifierOptions() As List(Of String) Implements IPrescriptionService.GetRefilQualifierOptions
        Dim values = New List(Of String)
        Try
            values.Add("R")
            values.Add("PRN")
        Catch ex As Exception

        End Try
        Return values
    End Function


    Function GetSubstitutionsOptions() As List(Of String) Implements IPrescriptionService.GetSubstitutionsOptions
        Dim values = New List(Of String)
        Try
            values.Add("Y")
            values.Add("N")
        Catch ex As Exception

        End Try
        Return values
    End Function



    
End Class
