﻿' NOTE: You can use the "Rename" command on the context menu to change the interface name "IService" in both code and config file together.
<ServiceContract()>
Public Interface IPrescriptionService

    <OperationContract()>
    Function GetData(ByVal value As Integer) As String

    <OperationContract()>
    Function PostPanaceaAdmin(ByVal panaceaAdminRequest As PanaceaAdminRequest) As ResponseData


    <OperationContract()>
    Function PostCurrentMedicationRequest(ByVal currentMedicationRequest As CurrentMedicationRequest) As ResponseData


    <OperationContract()>
    Function PostEpaRequest(ByVal epaRequest As EPARequest) As ResponseData

    <OperationContract()>
    Function PostEpcsRequest(ByVal epcsRequest As EPCSRequest) As ResponseData

    <OperationContract()>
    Function PostViewCurrentRequest(ByVal viewCurrentRequest As ViewCurrentRequest) As ResponseData


    <OperationContract()>
    Function PostWritePrescriptionRequest(ByVal writePrescriptionRequest As WritePrescriptionRequest) As ResponseData


    <OperationContract()>
    Function PostReWritePrescriptionRequest(ByVal reWritePrescriptionRequest As ReWritePrescriptionRequest) As ResponseData

    <OperationContract()>
    Function GetStateNames(ByVal pClinicCode As String) As DataTable

    <OperationContract()>
    Function GetReactionTypes() As List(Of String)

    <OperationContract()>
    Function GetIsFromFHVCOptions() As List(Of String)
    <OperationContract()>
    Function GetIsDeviceOptions() As List(Of String)


    <OperationContract()>
    Function GetRefilQualifierOptions() As List(Of String)


    <OperationContract()>
    Function GetSubstitutionsOptions() As List(Of String)

End Interface



