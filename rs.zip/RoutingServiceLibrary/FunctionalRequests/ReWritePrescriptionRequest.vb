﻿Imports Microsoft.VisualBasic
<DataContract()>
Public Class ReWritePrescriptionRequest
    Private mClinicInfo As Clinic

    <DataMember()>
    Public Property ClinicInfo() As Clinic
        Get
            Return mClinicInfo
        End Get
        Set(ByVal value As Clinic)
            mClinicInfo = value
        End Set
    End Property


    Private mUserInfo As User

    <DataMember()>
    Public Property UserInfo() As User
        Get
            Return mUserInfo
        End Get
        Set(ByVal value As User)
            mUserInfo = value
        End Set
    End Property

    Private m_MedicationInfo As Medication

    <DataMember()>
    Public Property MedicationInfo() As Medication
        Get
            Return m_MedicationInfo
        End Get
        Set(ByVal value As Medication)
            m_MedicationInfo = value
        End Set
    End Property
    Private m_PatientInfo As Patient
    <DataMember()>
    Public Property PatientInfo() As Patient
        Get
            Return m_PatientInfo
        End Get
        Set(ByVal value As Patient)
            m_PatientInfo = value
        End Set
    End Property

    Private m_AllergyList As List(Of Allergy)
    <DataMember()>
    Public Property AllergyList() As List(Of Allergy)
        Get
            Return m_AllergyList
        End Get
        Set(ByVal value As List(Of Allergy))
            m_AllergyList = value
        End Set
    End Property

End Class
