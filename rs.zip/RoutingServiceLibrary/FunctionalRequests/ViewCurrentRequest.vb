﻿Imports Microsoft.VisualBasic
<DataContract()>
Public Class ViewCurrentRequest
    Private mClinicInfo As Clinic

    <DataMember()>
    Public Property ClinicInfo() As Clinic
        Get
            Return mClinicInfo
        End Get
        Set(ByVal value As Clinic)
            mClinicInfo = value
        End Set
    End Property


    Private mUserInfo As User

    <DataMember()>
    Public Property UserInfo() As User
        Get
            Return mUserInfo
        End Get
        Set(ByVal value As User)
            mUserInfo = value
        End Set
    End Property
End Class
