﻿Imports Microsoft.VisualBasic
<DataContract()>
Public Class WritePrescriptionRequest
    Private m_UserInfo As User
    <DataMember()>
    Public Property UserInfo() As User
        Get
            Return m_UserInfo
        End Get
        Set(ByVal value As User)
            m_UserInfo = value
        End Set
    End Property

    Private m_ClinicInfo As Clinic
    <DataMember()>
    Public Property ClinicInfo() As Clinic
        Get
            Return m_ClinicInfo
        End Get
        Set(ByVal value As Clinic)
            m_ClinicInfo = value
        End Set
    End Property


    Private m_PatientInfo As Patient
    <DataMember()>
    Public Property PatientInfo() As Patient
        Get
            Return m_PatientInfo
        End Get
        Set(ByVal value As Patient)
            m_PatientInfo = value
        End Set
    End Property
End Class
