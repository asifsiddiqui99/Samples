﻿Imports Microsoft.VisualBasic
<DataContract()>
Public Class ResponseData
    <DataMember()>
    Public Property Status() As String
        Get
            Return m_Status
        End Get
        Set(value As String)
            m_Status = value
        End Set
    End Property
    Private m_Status As String
    <DataMember()>
    Public Property Message() As String
        Get
            Return m_Message
        End Get
        Set(value As String)
            m_Message = value
        End Set
    End Property
    Private m_Message As String
    <DataMember()>
    Public Property UrlWithToken() As String
        Get
            Return m_UrlWithToken
        End Get
        Set(value As String)
            m_UrlWithToken = value
        End Set
    End Property
    Private m_UrlWithToken As String
End Class

