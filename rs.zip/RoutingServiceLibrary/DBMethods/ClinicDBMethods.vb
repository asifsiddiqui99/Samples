﻿Imports System.Collections.Generic
Imports System.Linq
Imports System.Web
Imports System.Data
Imports System.Configuration
Imports System.Data.Sql
Imports System.Data.SqlClient
Imports System.Data.SqlTypes
Imports System.Text

Public Class ClinicDBMethods

    Private Shared Function GetDataTableFromQuery(connectionString As String, query As String) As DataTable
        Dim dt As New DataTable()
        Dim connection As New SqlConnection(connectionString)
        connection.Open()
        Dim cmd As New SqlCommand(query, connection)
        Dim adapter As New SqlDataAdapter(cmd)
        adapter.Fill(dt)
        connection.Close()
        Return dt
    End Function
    Private Shared Function RunNonQuery(connectionString As String, query As String) As Boolean
        Dim connection As New SqlConnection(connectionString)
        connection.Open()
        Dim cmd As New SqlCommand(query, connection)
        Dim rowsEffected As Integer = cmd.ExecuteNonQuery()
        connection.Close()
        Return rowsEffected > 0
    End Function

    Public Shared Function InsertAllAllergies(pPatientID As String, pUserID As String, connectionString As String, ByVal allergyList As List(Of Allergy), ByRef pMessage As String) As Boolean

        Try
            Dim errorString As StringBuilder
            Dim counter As Integer = 1
            For Each alergy As Allergy In allergyList
                errorString = New StringBuilder
                Dim isError As Boolean = False
                errorString.Append(IIf(Not String.IsNullOrEmpty(pMessage), ", Allergy # " & counter & ": ", "Allergy # " & counter & ": "))
                If String.IsNullOrEmpty(alergy.Description) Then
                    isError = True
                    errorString.Append("Missing Description")
                End If

                If String.IsNullOrEmpty(alergy.RxNomID) Then
                    isError = True
                    errorString.Append(IIf(errorString.ToString().Contains("Missing"), ", RxnormID", "Missing RxNormID"))
                End If

                If String.IsNullOrEmpty(alergy.OnSetDate) Then
                    isError = True
                    errorString.Append(IIf(errorString.ToString().Contains("Missing"), ", OnSetDate", "Missing OnSetDate"))
                End If



                If Not isError Then

                    If InsertAllergy(pPatientID, alergy, pUserID, connectionString) Then
                        errorString.Append("Succesfuly imported")
                    Else
                        errorString.Append("Error Importing Allergy")
                    End If

                End If

                counter = counter + 1
                pMessage = pMessage & errorString.ToString()
            Next

        Catch ex As Exception

        End Try

        Return True

    End Function



    Public Shared Function GetClinicConnectionString(pClinicCode As String) As String

        Try
            Dim sbQuery As New StringBuilder()
            sbQuery.Append(" select ConnectionString from ConnectionMaster where ClinicCode = '" & pClinicCode & "' ")

            Dim dt As DataTable = GetDataTableFromQuery(ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString, sbQuery.ToString())

            If dt.Rows.Count > 0 Then
                Return dt.Rows(0)("ConnectionString").ToString()
            End If

        Catch ex As Exception
        End Try

        Return String.Empty
    End Function

    Public Shared Function UpdateUser(dUser As User, connectionString As String, ByRef pMessage As String) As String

        Try


            Dim isError As Boolean = False
            Dim errorString As New StringBuilder

            If String.IsNullOrEmpty(dUser.LoginID) Then
                isError = True
                errorString.Append(IIf(Not String.IsNullOrEmpty(errorString.ToString()), ", LoginID", "LoginID"))
            End If

            If String.IsNullOrEmpty(dUser.PrescriberSPI) Then
                isError = True
                errorString.Append(IIf(Not String.IsNullOrEmpty(errorString.ToString()), "and Prescriber SPI", "Prescriber SPI"))
            End If

            If isError Then

                pMessage = "User information has missing field(s): " & errorString.ToString()
                Return String.Empty

            End If


            Dim sbQuery As New StringBuilder()
            sbQuery.Append(" update employee set LoginID ='" & dUser.LoginID & "' ")

            If Not String.IsNullOrEmpty(dUser.LastName) Then
                sbQuery.Append(" , LastName ='" & Convert.ToString(dUser.LastName) & "' ")
            End If
            If Not String.IsNullOrEmpty(dUser.FirstName) Then
                sbQuery.Append(" , FirstName ='" & Convert.ToString(dUser.FirstName) & "' ")
            End If
            If Not String.IsNullOrEmpty(dUser.Phone) Then
                sbQuery.Append(", WorkPhone='" & Convert.ToString(dUser.Phone) & "' ")
            End If

            If Not String.IsNullOrEmpty(dUser.City) Then
                sbQuery.Append(" , City ='" & Convert.ToString(dUser.City) & "' ")
            End If
            If Not String.IsNullOrEmpty(dUser.State) Then
                sbQuery.Append(" , StateID=(select top 1 StateID from state where name ='" & Convert.ToString(dUser.State) & "') ")
            End If
            If Not String.IsNullOrEmpty(dUser.Zip) Then
                sbQuery.Append(" , ZipCode='" & Convert.ToString(dUser.Zip) & "' ")
            End If


            sbQuery.Append(" where LoginID = '" & dUser.LoginID & "'")


            If RunNonQuery(connectionString, sbQuery.ToString()) Then

                Dim dtEmployee = GetDataTableFromQuery(connectionString, "select EmployeeID from Employee where loginid = '" & dUser.LoginID & "'")

                If dtEmployee.Rows.Count > 0 Then
                    Return dtEmployee.Rows(0)("EmployeeID").ToString()
                End If

            End If

        Catch ex As Exception
            pMessage = IIf(String.IsNullOrEmpty(pMessage), ex.Message, " , " & ex.Message)
        End Try

        Return String.Empty
    End Function


    Public Shared Function InsertToken(ByVal clinic As Clinic, ByVal pUserID As String, connectionString As String, token As String, ByVal pPatientID As String, ByVal pRxNormID As String, ByVal pRxFromExternalID As String) As Integer

        Try

            Dim sbQuery As New StringBuilder()
            sbQuery.Append(" INSERT INTO ClinicToken(Token,ClinicCode,UserID,PatientID,RxNorm,RxID,RxFromExternalID) ")
            sbQuery.Append(" values('" & token & "','" & Convert.ToString(clinic.ClinicCode) & "'," & pUserID & "," & IIf(String.IsNullOrEmpty(pPatientID), "NULL", pPatientID) & ",'" & pRxNormID & "',NULL," & IIf(String.IsNullOrEmpty(pRxFromExternalID), "NULL", pRxFromExternalID) & ")")

            If RunNonQuery(connectionString, sbQuery.ToString()) Then

                Dim dt As DataTable = GetDataTableFromQuery(connectionString, " select top 1 clinictokenid from ClinicToken order by 1 desc ")

                If dt.Rows.Count > 0 Then

                    Return Convert.ToInt32(dt.Rows(0)("clinictokenid"))

                End If

            End If



        Catch ex As Exception
        End Try

        Return 0
    End Function



    Public Shared Function UpdateClinic(clinic As Clinic, connectionString As String) As Boolean

        Try
            Dim sbQuery As New StringBuilder()
            sbQuery.Append(" update ClinicInfo set clinicid = '" & Convert.ToString(clinic.ClinicCode) & "' ")

            If Not String.IsNullOrEmpty(clinic.Name) Then
                sbQuery.Append(" , ClinicName ='" & Convert.ToString(clinic.Name) & "' ")
            End If
            If Not String.IsNullOrEmpty(clinic.Phone) Then
                sbQuery.Append(", Phone1='" & Convert.ToString(clinic.Phone) & "' ")
            End If

            If Not String.IsNullOrEmpty(clinic.City) Then
                sbQuery.Append(" , City ='" & Convert.ToString(clinic.City) & "' ")
            End If
            If Not String.IsNullOrEmpty(clinic.State) Then
                sbQuery.Append(" , StateID=(select top 1 StateID from state where name ='" & Convert.ToString(clinic.State) & "') ")
            End If
            If Not String.IsNullOrEmpty(clinic.Zip) Then
                sbQuery.Append(" , ZipCode='" & Convert.ToString(clinic.Zip) & "' ")
            End If

            sbQuery.Append(" where clinicid = '" & Convert.ToString(clinic.ClinicCode) & "'")


            Return RunNonQuery(connectionString, sbQuery.ToString())

        Catch ex As Exception
        End Try

        Return False
    End Function




    Public Shared Function GetPatientIDToInsert(ByVal pConnectionString As String) As Integer
        Try
            Dim dtPatient = GetDataTableFromQuery(pConnectionString, " select top 1 patientid from patient order by patientid desc ")

            If dtPatient.Rows.Count > 0 Then

                Return Convert.ToInt32(dtPatient.Rows(0)("PatientID")) + 1

            End If

        Catch ex As Exception

        End Try
        Return 1
    End Function

    Public Shared Function InsertExternalRx(pPatientID As String, medication As Medication, pUserID As String, pSPI As String, connectionString As String, ByRef pMessage As String) As Integer

        Dim dtPatient As DataTable = New DataTable

        Try


            Dim isError As Boolean = False
            Dim errorString As New StringBuilder

            If String.IsNullOrEmpty(medication.DaysSupply) Then
                isError = True
                errorString.Append(IIf(Not String.IsNullOrEmpty(errorString.ToString()), ", DaysSupply", "DaysSupply"))
            End If
            If String.IsNullOrEmpty(medication.Directions) Then
                isError = True
                errorString.Append(IIf(Not String.IsNullOrEmpty(errorString.ToString()), ", Directions", "Directions"))
            End If
            If String.IsNullOrEmpty(medication.DrugDescription) Then
                isError = True
                errorString.Append(IIf(Not String.IsNullOrEmpty(errorString.ToString()), ", DrugDescription", "DrugDescription"))
            End If

            If String.IsNullOrEmpty(medication.QuantityQualifier) Then
                isError = True
                errorString.Append(IIf(Not String.IsNullOrEmpty(errorString.ToString()), ", QuantityQualifier", "QuantityQualifier"))
            End If

            If String.IsNullOrEmpty(medication.QuantityValue) Then
                isError = True
                errorString.Append(IIf(Not String.IsNullOrEmpty(errorString.ToString()), ", QuantityValue", "QuantityValue"))
            End If

            If String.IsNullOrEmpty(medication.Substitutions) Then
                isError = True
                errorString.Append(IIf(String.IsNullOrEmpty(errorString.ToString()), ", Substitutions", "Substitutions"))
            End If

            If String.IsNullOrEmpty(medication.RxNorm) Then
                isError = True
                errorString.Append(IIf(Not String.IsNullOrEmpty(errorString.ToString()), ", RxNorm", "RxNorm"))
            End If

            If Not String.IsNullOrEmpty(medication.IsFromFHVCDatabase) Then
                If medication.IsFromFHVCDatabase.ToLower.Equals("n") AndAlso String.IsNullOrEmpty(medication.RxID) Then
                    isError = True
                    errorString.Append(IIf(Not String.IsNullOrEmpty(errorString.ToString()), ", RxID (Required when IsFromFHVCDatabase=N)", "RxID (Required when IsFromFHVCDatabase=N)"))
                End If
            End If


            If isError Then

                pMessage = "Medication could not be inserted because of the missing fieds: " & errorString.ToString()
                Return 0

            End If

            Dim sbQuery As New StringBuilder()

            sbQuery.Append(" INSERT INTO RxFromExternal(IsFromFHVCDatabase,DaysSupply,Directions,DrugDescription,QuantityQualifier,QuantityValue,Note,RefillsQuantifier ")
            sbQuery.Append(" ,RefillsQuantityValue,Substitutions,IsDevice,DrugNDC,RxNorm,RxID,PatientID,UserID,DoctorUserID) ")
            sbQuery.Append(" VALUES('" & medication.IsFromFHVCDatabase & "','" & medication.DaysSupply & "','" & medication.Directions & "', ")
            sbQuery.Append(" '" & medication.DrugDescription & "','" & medication.QuantityQualifier & "','" & medication.QuantityValue & "','" & medication.Note & "','" & medication.RefillsQuantifier & "','" & medication.RefillsQuantityValue & "' ")
            sbQuery.Append(" ,'" & medication.Substitutions & "','" & medication.IsDevice & "','" & medication.DrugNDC & "','" & medication.RxNorm & "','" & medication.RxID & "'," & pPatientID & "," & pUserID & ",(select top 1 employeeid from Employee where SPI = '" & pSPI & "')) ")

            If RunNonQuery(connectionString, sbQuery.ToString()) Then

                Dim dt As DataTable = GetDataTableFromQuery(connectionString, " select top 1 RxFromExternalID from RxFromExternal order by RxFromExternalID desc ")

                If dt.Rows.Count > 0 Then

                    Return Convert.ToInt32(dt.Rows(0)("RxFromExternalID"))

                End If

            End If
        Catch ex As Exception
            pMessage = ex.Message
        End Try

        Return 0
    End Function



    Public Shared Function InsertAllergy(pPatientID As String, allergy As Allergy, pUserID As String, connectionString As String) As Boolean

        Dim dtPatient As DataTable = New DataTable

        Try

            Dim sbQuery As New StringBuilder()

            sbQuery.Append(" INSERT INTO AllergyList(PatientID,AllergyType,SnomedRxNomID,Description,ReactionType ")
            sbQuery.Append(" ,Reaction,Severity,OnSetDate,Notes,Status,isDeleted,UserID,TimeStamp,isNK) ")
            sbQuery.Append(" VALUES(" & pPatientID & ",'" & allergy.AllergyType & "', ")
            sbQuery.Append(" '" & allergy.RxNomID & "','" & allergy.Description & "','" & allergy.ReactionType & "','" & allergy.Reaction & "','" & allergy.Severity & "','" & allergy.OnSetDate & "' ")
            sbQuery.Append(" ,'" & allergy.Notes & "','Active','N'," & pUserID & ",getdate(),'N') ")

            Return RunNonQuery(connectionString, sbQuery.ToString())
        Catch ex As Exception
        End Try

        Return False
    End Function

    Public Shared Function InsertUpdatePatient(patient As Patient, connectionString As String, ByRef pMessage As String) As String

        Dim dtPatient As DataTable = New DataTable

        Try
            Dim isError As Boolean = False
            Dim errorString As New StringBuilder

            If String.IsNullOrEmpty(patient.FirstName) Then
                isError = True
                errorString.Append(IIf(Not String.IsNullOrEmpty(errorString.ToString()), ", FirstName", "Firstname"))
            End If

            If String.IsNullOrEmpty(patient.LastName) Then
                isError = True
                errorString.Append(IIf(Not String.IsNullOrEmpty(errorString.ToString()), ", LastName", "LastName"))
            End If

            If String.IsNullOrEmpty(patient.DOB) Then
                isError = True
                errorString.Append(IIf(Not String.IsNullOrEmpty(errorString.ToString()), ", DOB", "DOB"))
            End If

            If String.IsNullOrEmpty(patient.Gender) Then
                isError = True
                errorString.Append(IIf(Not String.IsNullOrEmpty(errorString.ToString()), ", Gender", "Gender"))
            End If

            If String.IsNullOrEmpty(patient.AddressLine1) Then
                isError = True
                errorString.Append(IIf(String.IsNullOrEmpty(errorString.ToString()), ", AddressLine1", "AddressLine1"))
            End If

            If String.IsNullOrEmpty(patient.State) Then
                isError = True
                errorString.Append(IIf(Not String.IsNullOrEmpty(errorString.ToString()), ", State", "State"))
            End If

            If String.IsNullOrEmpty(patient.Zip) Then
                isError = True
                errorString.Append(IIf(Not String.IsNullOrEmpty(errorString.ToString()), ", Zip", "Zip"))
            End If

            

            If isError Then

                pMessage = "Patient could not be inserted because of the missing fieds: " & errorString.ToString()
                Return String.Empty

            End If

            Dim sbQuery As New StringBuilder()
            dtPatient = GetDataTableFromQuery(connectionString, " select * from patient where FirstName =  '" & patient.FirstName & "' and LastName = '" & patient.LastName & "'and cast(DOB as datetime)=cast('" & patient.DOB & "' as datetime) and IsDeleted='N'")

            If dtPatient.Rows.Count > 0 Then
                sbQuery.Append(" update Patient set title='" & IIf(patient.Gender.ToLower.Equals("male"), "Mr", "Ms") & "', HousePhone = '" & patient.Phone & "', SSN = '" & patient.SSN & "', Gender = '" & patient.Gender & "', DOB = '" & patient.DOB & "' ")
                sbQuery.Append(" ,MiddleName = '', WorkPhone = '', WorkPhoneExtension = '',Fax = '',Email = '',Occupation = '',InsuranceID = '',InsuranceName = '',PharmacyName = '',PictureFilePath = '' ")
                sbQuery.Append(" ,PharmacyProvider = '',EmergencyContactCity='',EmergencyContactZip='',EmergencyContactState='' ")
                sbQuery.Append(" ,NCPDPID2 = '',PharmacyName2 = '',PharmacyProvider2 = '',Race = '',AccessMedHistory = '',Ethinicity = '',Language = 'English' ")
                sbQuery.Append(" ,ResponsibleName = '',ResponsibleRelationship='',ResponsibleHomePhone='',ResponsibleWorkPhone='' ")
                sbQuery.Append(" ,ResponsibleAddress='',ResponsibleSSN='',ResponsibleCity='',ResponsibleState='',ResponsibleZip='' ")
                sbQuery.Append(" ,IsTransfered='N',TransferedBy='',CommunicationMethod='Not Specified',TransferedDate='1900-01-01 00:00:00.000',ReferredTo=0 ")
                sbQuery.Append(" , AddressLine1 = '" & patient.AddressLine1 & "' , AddressLine2 = '" & patient.AddressLine2 & "', City = '" & patient.City & "' ")
                sbQuery.Append(" , StateID = (select top 1 StateID from State where Name = '" & patient.State & "'),ZipCode = '" & patient.Zip & "',  NcpdpID = '" & patient.PreferredPharmacyNCPDPID & "' ")
                sbQuery.Append(" where FirstName = '" & patient.FirstName & "' and LastName = '" & patient.LastName & "' ")
                sbQuery.Append("  and cast(DOB as datetime)=cast('" & patient.DOB & "' as datetime) and IsDeleted='N' ")
            Else
                sbQuery.Append(" insert into Patient(Patientid,Title,FirstName,LastName,HousePhone, ")
                sbQuery.Append(" ResponsibleName,ResponsibleRelationship,ResponsibleHomePhone,ResponsibleWorkPhone,ResponsibleAddress ")
                sbQuery.Append(" ,ResponsibleSSN,ResponsibleCity,ResponsibleState,ResponsibleZip,IsTransfered,TransferedBy, ")
                sbQuery.Append(" TransferedDate,ReferredTo,SSN,Gender,DOB,AddressLine1,AddressLine2,City, ")
                sbQuery.Append(" StateID,ZipCode,NcpdpID,MiddleName,WorkPhone, WorkPhoneExtension,Fax,Email,Occupation,InsuranceID,InsuranceName,PharmacyName,PictureFilePath,PharmacyProvider,EmergencyContactCity,EmergencyContactZip,EmergencyContactState,NCPDPID2,PharmacyName2,PharmacyProvider2,Race,AccessMedHistory,Ethinicity,Language,CommunicationMethod) ")
                sbQuery.Append(" values(" & GetPatientIDToInsert(connectionString) & ",'" & IIf(patient.Gender.ToLower.Equals("male"), "Mr", "Ms") & "','" & patient.FirstName & "','" & patient.LastName & "','" & patient.Phone & "','','','','','','','','','','N','','1900-01-01 00:00:00.000',0,'" & patient.SSN & "' ")
                sbQuery.Append(" ,'" & patient.Gender & "','" & patient.DOB & "','" & patient.AddressLine1 & "','" & patient.AddressLine2 & "','" & patient.City & "', ")
                sbQuery.Append(" (select top 1 stateid from State where Name = '" & patient.State & "') ")
                sbQuery.Append(" ,'" & patient.Zip & "','" & patient.PreferredPharmacyNCPDPID & "','','','','','','','','','','','','','','','','','','','','','English','Not Specified') ")

            End If
            If RunNonQuery(connectionString, sbQuery.ToString()) Then
                dtPatient = GetDataTableFromQuery(connectionString, " select top 1 patientid from patient where FirstName =  '" & patient.FirstName & "' and LastName = '" & patient.LastName & "'and cast(DOB as datetime)=cast('" & patient.DOB & "' as datetime) and IsDeleted='N'")
                If dtPatient.Rows.Count > 0 Then
                    Return dtPatient.Rows(0)("PatientID").ToString()
                End If

            End If
        Catch ex As Exception

            pMessage = IIf(String.IsNullOrEmpty(pMessage), ex.Message, " , " & ex.Message)

        End Try

        Return String.Empty
    End Function


    Public Shared Function GetStateNames(pConnectionString As String) As DataTable

        Try
            Return GetDataTableFromQuery(pConnectionString, "SELECT Name from State")

        Catch ex As Exception
        End Try

        Return New DataTable
    End Function

End Class
