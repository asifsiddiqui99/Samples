﻿Imports Microsoft.VisualBasic
Imports ElixirLibrary
Imports System.Data
Imports System.Security.Cryptography
Imports System.Text

Public Class AuthenticationMethods

    Public Shared Function ValudateUser(ByVal pUserID As String, ByVal pUserPassword As String) As String
        Dim lQuery As String
        Dim lDs As New DataSet()
        Dim lConnection As Connection
        Dim lStatus As String
        Dim lHashedPassword As String
        Try
            lHashedPassword = GetHashedText(pUserPassword)

            lConnection = New Connection()
            lQuery = "select * from ServiceClients where UserID = '" + pUserID + "' And cast(Password as varbinary) = cast('" + lHashedPassword + "' as varbinary) "
            If lConnection.IsTransactionAlive() Then
                lDs = lConnection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = lConnection.ExecuteQuery(lQuery)
            End If
            If lDs.Tables(0).Rows.Count > 0 Then
                lStatus = "True"
            Else
                lStatus = "False " & lHashedPassword
            End If
            Return lStatus
        Catch ex As Exception
            Return ex.Message
            Throw New Exception(ex.Message + " : GetUserNew(ByVal pUserID As String, ByVal pUserPassword As String) As Boolean ")
        End Try
    End Function

    Private Shared Function GetHashedText(ByVal str As String) As String
        Dim ObjUEncode As New UnicodeEncoding()
        Dim HashValue As Byte()
        Dim strBytes As Byte() = ObjUEncode.GetBytes(str)

        Dim strHex As String = ""
        Dim objSHAHash As New SHA256Managed
        HashValue = objSHAHash.ComputeHash(strBytes)
        For Each b As Byte In HashValue
            strHex &= String.Format("{0:x2}", b)
        Next
        Return strHex
    End Function

    Private Shared Function CompareHash(ByVal pStr1 As String, ByVal pStr2 As String) As Boolean
        If GetHashedText(pStr1) = GetHashedText(pStr2) Then
            Return True
        Else
            Return False
        End If
    End Function
End Class


Public Class UserNamePassValidator
    Inherits System.IdentityModel.Selectors.UserNamePasswordValidator
    Public Overrides Sub Validate(ByVal userName As String, ByVal password As String)
        Dim lIsAuthenticated As String

        If userName Is Nothing OrElse password Is Nothing Then
            Throw New ArgumentNullException()
        End If

        lIsAuthenticated = AuthenticationMethods.ValudateUser(userName, password)
        If Not lIsAuthenticated = "True" Then
            Throw New FaultException("Incorrect Username or Password " & lIsAuthenticated)
        End If


    End Sub
End Class
