Imports Microsoft.VisualBasic
Imports Medispan
Imports System.Data.SqlClient
Imports System.Configuration

Public Class MSDrugMethods
    Public Function GetDrugNames(ByVal strSearch As String, ByVal SearchType As String) As DataSet
        Dim MyDataSet As DataSet = New DataSet
        Dim DrugTable As DataTable = New DataTable
        Dim Column1 As DataColumn
        Dim Column2 As DataColumn
        Dim Row As DataRow
        Try
            Dim nav As Dib.Navigation = New Dib.Navigation
            Dim objFilter As Dib.DrugFilter = New Dib.DrugFilter
            objFilter.SetNameType(Dib.DIBDrugNameTypeFilter.DN_TF_ALL)
            objFilter.SetIncludeDevices(True)
            Dim drgColl As Dib.DrugNames
            If SearchType.Equals("Simple") Then
                drgColl = nav.DrugNameSearch(strSearch, Dib.DIBSearchMethod.DIB_SM_SIMPLE, Dib.DIBPhoneticSearch.DIB_PS_NOPHONETIC, objFilter)
            Else
                If SearchType.Equals("Exhaustive") Then
                    drgColl = nav.DrugNameSearch(strSearch, Dib.DIBSearchMethod.DIB_SM_EXHAUSTIVE, Dib.DIBPhoneticSearch.DIB_PS_NOPHONETIC, objFilter)
                Else
                    drgColl = nav.DrugNameSearch(strSearch, Dib.DIBSearchMethod.DIB_SM_EXHAUSTIVE, Dib.DIBPhoneticSearch.DIB_PS_ONLY, objFilter)
                End If
            End If
            DrugTable = MyDataSet.Tables.Add("Drugs")
            Column1 = New DataColumn("drug_id", System.Type.GetType("System.Int64"))
            DrugTable.Columns.Add(Column1)
            Column2 = New DataColumn("drug_name", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(Column2)
            For Each drgcol As Dib.DrugName In drgColl
                Row = MyDataSet.Tables("Drugs").NewRow
                Row(0) = drgcol.Id
                Row(1) = drgcol.Description
                MyDataSet.Tables("Drugs").Rows.Add(Row)
            Next
        Catch ex As Exception
            Throw New Exception(ex.Message & ":MeddispanLibrary\MSDrugMethods.GetDrugNames(ByVal strSearch=" & strSearch & " As String, ByVal SearchType=" & SearchType & "  As String)")
        End Try
        Return MyDataSet
    End Function

    Public Function GetRxDrugNames(ByVal strSearch As String, ByVal SearchType As String) As DataSet
        Dim MyDataSet As DataSet = New DataSet
        Dim DrugTable As DataTable = New DataTable
        Dim Column1 As DataColumn
        Dim Column2 As DataColumn
        Dim Column3 As DataColumn
        Dim Column4 As DataColumn
        Dim Column5 As DataColumn
        Dim Column6 As DataColumn
        Dim Column7 As DataColumn
        Dim Column8 As DataColumn
        Dim Column9 As DataColumn
        Dim Column10 As DataColumn
        Dim Column11 As DataColumn
        Dim Column12 As DataColumn
        Dim Column13 As DataColumn
        Dim Column14 As DataColumn
        Dim Column15 As DataColumn
        Dim Row As DataRow
        Dim NumRows As Integer
        Dim ind As Integer = 0
        Dim temp As String = ""

        Try
            Dim nav As Dib.Navigation = New Dib.Navigation
            Dim objFilter As Dib.DrugFilter = New Dib.DrugFilter
            objFilter.SetIncludeDevices(True)
            objFilter.SetNameType(Dib.DIBDrugNameTypeFilter.DN_TF_ALL)
            Dim drgColl As Dib.DispensableDrugs
            Dim eqDrugs As Dib.DispensableDrugs
            Dim packDrugs As Dib.PackagedDrugs
            Dim objDIBCode As Dib.DIBCode
            Dim objDispensableDrug As Dib.DispensableDrug
            Dim objGPIClassification As Dib.GPIClassification
            If SearchType.Equals("Simple") Then
                drgColl = nav.DispensableDrugSearch(strSearch, Dib.DIBSearchMethod.DIB_SM_SIMPLE, Dib.DIBPhoneticSearch.DIB_PS_NOPHONETIC, objFilter)
            Else
                If SearchType.Equals("Exhaustive") Then
                    drgColl = nav.DispensableDrugSearch(strSearch, Dib.DIBSearchMethod.DIB_SM_EXHAUSTIVE, Dib.DIBPhoneticSearch.DIB_PS_NOPHONETIC, objFilter)
                Else
                    drgColl = nav.DispensableDrugSearch(strSearch, Dib.DIBSearchMethod.DIB_SM_EXHAUSTIVE, Dib.DIBPhoneticSearch.DIB_PS_ONLY, objFilter)
                End If
            End If
            DrugTable = MyDataSet.Tables.Add("Drugs")
            Column1 = New DataColumn("DrugID", System.Type.GetType("System.Int64"))
            DrugTable.Columns.Add(Column1)
            Column2 = New DataColumn("DrugName", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(Column2)
            Column3 = New DataColumn("DrugRoute", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(Column3)
            Column4 = New DataColumn("DrugDosage", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(Column4)
            Column5 = New DataColumn("DrugForm", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(Column5)
            Column6 = New DataColumn("DrugName2", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(Column6)
            Column7 = New DataColumn("NDC", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(Column7)
            Column8 = New DataColumn("DIN", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(Column8)
            Column9 = New DataColumn("GenericName", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(Column9)
            Column10 = New DataColumn("Class", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(Column10)
            Column11 = New DataColumn("GPrice", System.Type.GetType("System.Double"))
            DrugTable.Columns.Add(Column11)
            Column12 = New DataColumn("WPrice", System.Type.GetType("System.Double"))
            DrugTable.Columns.Add(Column12)
            Column13 = New DataColumn("Group", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(Column13)
            Column14 = New DataColumn("Status", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(Column14)
            Column15 = New DataColumn("SingleNDC", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(Column15)
            NumRows = drgColl.Count

            For Each drgcol As Dib.DispensableDrug In drgColl
                Row = MyDataSet.Tables("Drugs").NewRow
                Row(0) = drgcol.Id
                Row(1) = drgcol.Name
                Row(2) = drgcol.Route
                Row(3) = drgcol.Strength & " " & drgcol.StrengthUnit
                Row(4) = drgcol.DoseForm
                temp = drgcol.Name.Replace("""", "^")
                temp = temp.Replace("'", "~")
                Row(5) = temp
                temp = drgColl.Item(ind).Id.ToString
                temp = temp.PadLeft(9, "0"c)
                Row(7) = temp
                Row(8) = ""
                objDIBCode = New Dib.DIBCode(20, drgcol.NameTypeCode)
                If objDIBCode.Description.Equals("Generic Name") Then
                    Row(8) = Row(1)
                Else
                    eqDrugs = drgcol.GetEquivalentItems(Dib.DIBDrugNameTypeFilter.DN_TF_BRANDGENERICANDGENERIC)

                    For Each eqDrug As Dib.DispensableDrug In eqDrugs
                        objDIBCode = New Dib.DIBCode(20, eqDrug.NameTypeCode)
                        Row(8) = objDIBCode.Description
                        If objDIBCode.Description.Equals("Generic Name") Then
                            Row(8) = eqDrug.Name
                        End If
                    Next
                End If
                If Not Row(8).Equals("") Then
                    objDispensableDrug = New Dib.DispensableDrug(drgcol.Id)
                    Try
                        objGPIClassification = objDispensableDrug.GetGPIClassification
                        Row(9) = objGPIClassification.Description
                        Try
                            objGPIClassification = objGPIClassification.GetParent
                            Row(12) = objGPIClassification.Description
                        Catch e2 As Exception
                            Row(12) = Row(9)
                            Row(9) = Row(8)
                        End Try
                    Catch e1 As Exception
                        Row(9) = ""
                    End Try
                Else
                    objDispensableDrug = New Dib.DispensableDrug(drgcol.Id)
                    Try
                        objGPIClassification = objDispensableDrug.GetGPIClassification
                        Row(8) = objGPIClassification.Description
                        Try
                            objGPIClassification = objGPIClassification.GetParent
                            Row(9) = objGPIClassification.Description
                            Try
                                objGPIClassification = objGPIClassification.GetParent
                                Row(12) = objGPIClassification.Description
                            Catch e3 As Exception
                                Row(12) = Row(9)
                                Row(9) = Row(8)
                            End Try
                        Catch e4 As Exception
                            Row(9) = ""
                            Row(12) = ""
                        End Try
                    Catch e5 As Exception
                        Row(8) = ""
                        Row(9) = ""
                        Row(12) = ""
                    End Try
                End If
                temp = Row(8).ToString.Replace("""", "^")
                temp = temp.Replace("'", "~")
                Row(8) = temp
                temp = Row(9).ToString.Replace("""", "^")
                temp = temp.Replace("'", "~")
                Row(9) = temp
                temp = Row(9).ToString.Replace("""", "^")
                temp = temp.Replace("'", "~")
                Row(9) = temp
                temp = Row(12).ToString.Replace("""", "^")
                temp = temp.Replace("'", "~")
                Row(12) = temp
                If objDispensableDrug.HasPackagedDrugs Then
                    packDrugs = drgcol.GetPackagedDrugs
                    'Row(13) = packDrugs.Item(0).NDC  'Status Column

                    Dim str As String = ""
                    For x As Integer = 0 To packDrugs.Count - 1
                        str = str + "," + packDrugs.Item(x).Id
                    Next
                    Row(6) = str


                    Row(14) = packDrugs.Item(0).NDC 'Single NDC
                    Dim DP As Dib.DrugPrice
                    Try
                        DP = packDrugs.Item(1).GetPriceCurrent("02")
                        Row(11) = DP.Price
                    Catch
                        Row(11) = 0
                    End Try
                    Try
                        DP = packDrugs.Item(1).GetPriceCurrent("08")
                        Row(10) = DP.Price
                    Catch
                        Row(10) = 0
                    End Try
                End If
                MyDataSet.Tables("Drugs").Rows.Add(Row)
            Next
        Catch ex As Exception
            Throw New Exception(ex.Message & ":MedispanLibrary\MSDrugMethods.GetRxDrugNames(ByVal strSearch=" & strSearch & " As String, ByVal SearchType=" & SearchType & " As String)")
        End Try
        Return MyDataSet
    End Function

    Public Function GetRxDrugNamesPDA(ByVal strSearch As String, ByVal SearchType As String) As DataSet
        Dim MyDataSet As DataSet = New DataSet
        Dim DrugTable As DataTable = New DataTable
        Dim Column1 As DataColumn
        Dim Column2 As DataColumn
        Dim Column3 As DataColumn
        Dim Column4 As DataColumn
        Dim Column5 As DataColumn
        Dim Column6 As DataColumn
        Dim Column7 As DataColumn
        Dim Column8 As DataColumn
        Dim Column9 As DataColumn
        Dim Column10 As DataColumn
        Dim Column11 As DataColumn
        Dim Column12 As DataColumn
        Dim Column13 As DataColumn
        Dim Column14 As DataColumn
        Dim Row As DataRow
        Dim temp As String = ""

        Try
            Dim nav As Dib.Navigation = New Dib.Navigation
            Dim objFilter As Dib.DrugFilter = New Dib.DrugFilter
            objFilter.SetIncludeDevices(True)
            objFilter.SetNameType(Dib.DIBDrugNameTypeFilter.DN_TF_ALL)
            Dim drgColl As Dib.DispensableDrugs
            Dim eqDrugs As Dib.DispensableDrugs
            Dim packDrugs As Dib.PackagedDrugs
            Dim objDIBCode As Dib.DIBCode
            Dim objDispensableDrug As Dib.DispensableDrug
            Dim objGPIClassification As Dib.GPIClassification
            If SearchType.Equals("Simple") Then
                drgColl = nav.DispensableDrugSearch(strSearch, Dib.DIBSearchMethod.DIB_SM_SIMPLE, Dib.DIBPhoneticSearch.DIB_PS_NOPHONETIC, objFilter)
            Else
                If SearchType.Equals("Exhaustive") Then
                    drgColl = nav.DispensableDrugSearch(strSearch, Dib.DIBSearchMethod.DIB_SM_EXHAUSTIVE, Dib.DIBPhoneticSearch.DIB_PS_NOPHONETIC, objFilter)
                Else
                    drgColl = nav.DispensableDrugSearch(strSearch, Dib.DIBSearchMethod.DIB_SM_EXHAUSTIVE, Dib.DIBPhoneticSearch.DIB_PS_ONLY, objFilter)
                End If
            End If
            DrugTable = MyDataSet.Tables.Add("Drugs")

            Column1 = New DataColumn("DrugID", System.Type.GetType("System.Int64"))
            DrugTable.Columns.Add(Column1)
            Column2 = New DataColumn("DrugName", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(Column2)
            Column3 = New DataColumn("DrugRoute", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(Column3)
            Column4 = New DataColumn("DrugDosage", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(Column4)
            Column5 = New DataColumn("DrugForm", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(Column5)
            Column6 = New DataColumn("DrugName2", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(Column6)
            Column7 = New DataColumn("NDC", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(Column7)
            Column8 = New DataColumn("DIN", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(Column8)
            Column9 = New DataColumn("GenericName", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(Column9)
            Column10 = New DataColumn("Class", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(Column10)
            Column11 = New DataColumn("GPrice", System.Type.GetType("System.Double"))
            DrugTable.Columns.Add(Column11)
            Column12 = New DataColumn("WPrice", System.Type.GetType("System.Double"))
            DrugTable.Columns.Add(Column12)
            Column13 = New DataColumn("Group", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(Column13)
            Column14 = New DataColumn("Status", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(Column14)

            For Each drgcol As Dib.DispensableDrug In drgColl
                Row = MyDataSet.Tables("Drugs").NewRow
                Row(0) = drgcol.Id
                Row(1) = drgcol.Name
                Row(2) = drgcol.Route
                Row(3) = drgcol.Strength & " " & drgcol.StrengthUnit
                Row(4) = drgcol.DoseForm
                temp = drgcol.Name.Replace("""", "^")
                temp = temp.Replace("'", "~")
                Row(5) = temp
                temp = drgcol.Id.ToString
                temp = temp.PadLeft(9, "0"c)
                Row(7) = temp
                Row(8) = ""
                objDIBCode = New Dib.DIBCode(20, drgcol.NameTypeCode)
                If objDIBCode.Description.Equals("Generic Name") Then
                    Row(8) = Row(1)
                Else
                    eqDrugs = drgcol.GetEquivalentItems(Dib.DIBDrugNameTypeFilter.DN_TF_BRANDGENERICANDGENERIC)

                    For Each eqDrug As Dib.DispensableDrug In eqDrugs
                        objDIBCode = New Dib.DIBCode(20, eqDrug.NameTypeCode)
                        Row(8) = objDIBCode.Description
                        If objDIBCode.Description.Equals("Generic Name") Then
                            Row(8) = eqDrug.Name
                        End If
                    Next
                End If
                If Not Row(8).Equals("") Then
                    objDispensableDrug = New Dib.DispensableDrug(drgcol.Id)
                    Try
                        objGPIClassification = objDispensableDrug.GetGPIClassification
                        Row(9) = objGPIClassification.Description
                        Try
                            objGPIClassification = objGPIClassification.GetParent
                            Row(12) = objGPIClassification.Description
                        Catch e2 As Exception
                            Row(12) = Row(9)
                            Row(9) = Row(8)
                        End Try
                    Catch e1 As Exception
                        Row(9) = ""
                    End Try
                Else
                    objDispensableDrug = New Dib.DispensableDrug(drgcol.Id)
                    Try
                        objGPIClassification = objDispensableDrug.GetGPIClassification
                        Row(8) = objGPIClassification.Description
                        Try
                            objGPIClassification = objGPIClassification.GetParent
                            Row(9) = objGPIClassification.Description
                            Try
                                objGPIClassification = objGPIClassification.GetParent
                                Row(12) = objGPIClassification.Description
                            Catch e3 As Exception
                                Row(12) = Row(9)
                                Row(9) = Row(8)
                            End Try
                        Catch e4 As Exception
                            Row(9) = ""
                            Row(12) = ""
                        End Try
                    Catch e5 As Exception
                        Row(8) = ""
                        Row(9) = ""
                        Row(12) = ""
                    End Try
                End If
                temp = Row(8).ToString.Replace("""", "^")
                temp = temp.Replace("'", "~")
                Row(8) = temp
                temp = Row(9).ToString.Replace("""", "^")
                temp = temp.Replace("'", "~")
                Row(9) = temp
                temp = Row(9).ToString.Replace("""", "^")
                temp = temp.Replace("'", "~")
                Row(9) = temp
                temp = Row(12).ToString.Replace("""", "^")
                temp = temp.Replace("'", "~")
                Row(12) = temp
                If objDispensableDrug.HasPackagedDrugs Then
                    packDrugs = drgcol.GetPackagedDrugs
                    Row(6) = packDrugs.Item(1).NDC
                    Dim DP As Dib.DrugPrice
                    Try
                        DP = packDrugs.Item(1).GetPriceCurrent("02")
                        Row(11) = DP.Price
                    Catch
                        Row(11) = 0
                    End Try
                    Try
                        DP = packDrugs.Item(1).GetPriceCurrent("08")
                        Row(10) = DP.Price
                    Catch
                        Row(10) = 0
                    End Try
                End If
                MyDataSet.Tables("Drugs").Rows.Add(Row)
            Next
        Catch ex As Exception
            Throw New Exception(ex.Message & ":MedispanLibrary\MSDrugMethods.GetRxDrugNamesPDA(ByVal strSearch=" & strSearch & " As String, ByVal SearchType=" & SearchType & " As String)")
        End Try
        Return MyDataSet
    End Function

    Public Function GetRxDrugNamesByNDC(ByVal ndc As String, ByVal dsdrug As DataSet) As DataSet
        Dim nav As Dib.Navigation = New Dib.Navigation
        Dim objDIBCode As Dib.DIBCode
        Dim objDispensableDrug As Dib.DispensableDrug
        Dim eqDrugs As Dib.DispensableDrugs
        Dim objPd As Dib.PackagedDrug
        Dim MyDataSet As DataSet = New DataSet
        Dim DrugTable As DataTable = New DataTable
        Dim Column1 As DataColumn
        Dim Column2 As DataColumn
        Dim Column3 As DataColumn
        Dim Column4 As DataColumn
        Dim Column5 As DataColumn
        Dim Column6 As DataColumn
        Dim Column7 As DataColumn
        Dim Column8 As DataColumn
        Dim Column9 As DataColumn
        Dim Column10 As DataColumn
        Dim Column11 As DataColumn
        Dim Column12 As DataColumn
        Dim Column13 As DataColumn
        Dim Column14 As DataColumn
        Dim Column15 As DataColumn

        '********* Duplicate Fields ************
        Dim Column16 As DataColumn
        Dim Column17 As DataColumn
        Dim Column18 As DataColumn
        Dim Column19 As DataColumn
        Dim Column20 As DataColumn
        Dim Column21 As DataColumn
        Dim Column22 As DataColumn
        '********* End Duplicate Fields ********

        Dim Column23 As DataColumn
        Dim lTempDataset As New DataSet


        Dim Row As DataRow
        Dim temp As String = ""

        Try


            lTempDataset = dsdrug.Copy()
            objPd = New Dib.PackagedDrug(ndc)

            objDispensableDrug = New Dib.DispensableDrug(objPd.DispensableDrugId)
            Dim objGPIClassification As Dib.GPIClassification
            If dsdrug.Tables.Count = 0 Then

                DrugTable = MyDataSet.Tables.Add("Drugs")

                Column1 = New DataColumn("DrugID", System.Type.GetType("System.Int64"))
                DrugTable.Columns.Add(Column1)
                Column2 = New DataColumn("DrugName", System.Type.GetType("System.String"))
                DrugTable.Columns.Add(Column2)
                Column3 = New DataColumn("DrugRoute", System.Type.GetType("System.String"))
                DrugTable.Columns.Add(Column3)
                Column4 = New DataColumn("DrugDosage", System.Type.GetType("System.String"))
                DrugTable.Columns.Add(Column4)
                Column5 = New DataColumn("DrugForm", System.Type.GetType("System.String"))
                DrugTable.Columns.Add(Column5)
                Column6 = New DataColumn("DrugName2", System.Type.GetType("System.String"))
                DrugTable.Columns.Add(Column6)
                Column7 = New DataColumn("NDC", System.Type.GetType("System.String"))
                DrugTable.Columns.Add(Column7)
                Column8 = New DataColumn("DIN", System.Type.GetType("System.String"))
                DrugTable.Columns.Add(Column8)
                Column9 = New DataColumn("GenericName", System.Type.GetType("System.String"))
                DrugTable.Columns.Add(Column9)
                Column10 = New DataColumn("Class", System.Type.GetType("System.String"))
                DrugTable.Columns.Add(Column10)
                Column11 = New DataColumn("GPrice", System.Type.GetType("System.Double"))
                DrugTable.Columns.Add(Column11)
                Column12 = New DataColumn("WPrice", System.Type.GetType("System.Double"))
                DrugTable.Columns.Add(Column12)
                Column13 = New DataColumn("Group", System.Type.GetType("System.String"))
                DrugTable.Columns.Add(Column13)
                Column14 = New DataColumn("Status", System.Type.GetType("System.String"))
                DrugTable.Columns.Add(Column14)
                Column15 = New DataColumn("SingleNDC", System.Type.GetType("System.String"))
                DrugTable.Columns.Add(Column15)

                '********* Duplicate Fields ************
                Column16 = New DataColumn("ID", System.Type.GetType("System.Int64"))
                DrugTable.Columns.Add(Column16)

                Column17 = New DataColumn("Name", System.Type.GetType("System.String"))
                DrugTable.Columns.Add(Column17)

                Column18 = New DataColumn("Route", System.Type.GetType("System.String"))
                DrugTable.Columns.Add(Column18)

                Column19 = New DataColumn("Strength", System.Type.GetType("System.String"))
                DrugTable.Columns.Add(Column19)

                Column20 = New DataColumn("StrengthUnit", System.Type.GetType("System.String"))
                DrugTable.Columns.Add(Column20)

                Column21 = New DataColumn("DoseForm", System.Type.GetType("System.String"))
                DrugTable.Columns.Add(Column21)
                Column22 = New DataColumn("StatusCode", System.Type.GetType("System.Int32"))
                DrugTable.Columns.Add(Column22)
                '********* End Duplicate Fields ********

                Column23 = New DataColumn("CopayRules", System.Type.GetType("System.String"))
                DrugTable.Columns.Add(Column23)

                dsdrug = MyDataSet
            End If
            Row = dsdrug.Tables("Drugs").NewRow

            '********* Duplicate Fields ************
            Row(15) = objDispensableDrug.Id
            Row(16) = objDispensableDrug.Name
            Row(17) = objDispensableDrug.Route
            Row(18) = objDispensableDrug.Strength
            Row(19) = objDispensableDrug.StrengthUnit
            Row(20) = objDispensableDrug.DoseForm
            '********* End Duplicate Fields ********

            Row(0) = objDispensableDrug.Id
            Row(1) = objDispensableDrug.Name
            Row(2) = objDispensableDrug.Route
            Row(3) = objDispensableDrug.Strength & " " & objDispensableDrug.StrengthUnit
            Row(4) = objDispensableDrug.DoseForm
            temp = objDispensableDrug.Name.Replace("""", "^")
            temp = temp.Replace("'", "~")
            Row(5) = temp
            temp = objDispensableDrug.Id.ToString
            temp = temp.PadLeft(9, "0"c)
            Row(7) = temp
            Row(8) = ""
            objDIBCode = New Dib.DIBCode(20, objDispensableDrug.NameTypeCode)
            If objDIBCode.Description.Equals("Generic Name") Then
                Row(8) = Row(1)
            Else
                eqDrugs = objDispensableDrug.GetEquivalentItems(Dib.DIBDrugNameTypeFilter.DN_TF_BRANDGENERICANDGENERIC)
                For Each eqDrug As Dib.DispensableDrug In eqDrugs
                    objDIBCode = New Dib.DIBCode(20, eqDrug.NameTypeCode)
                    Row(8) = objDIBCode.Description
                    If objDIBCode.Description.Equals("Generic Name") Then
                        Row(8) = eqDrug.Name
                    End If
                Next
            End If
            If Not Row(8).Equals("") Then
                objDispensableDrug = New Dib.DispensableDrug(objDispensableDrug.Id)
                Try
                    objGPIClassification = objDispensableDrug.GetGPIClassification
                    Row(9) = objGPIClassification.Description
                    Try
                        objGPIClassification = objGPIClassification.GetParent
                        Row(12) = objGPIClassification.Description
                    Catch e2 As Exception
                        Row(12) = Row(9)
                        Row(9) = Row(8)
                    End Try
                Catch e1 As Exception
                    Row(9) = ""
                End Try
            Else
                objDispensableDrug = New Dib.DispensableDrug(objDispensableDrug.Id)
                Try
                    objGPIClassification = objDispensableDrug.GetGPIClassification
                    Row(8) = objGPIClassification.Description
                    Try
                        objGPIClassification = objGPIClassification.GetParent
                        Row(9) = objGPIClassification.Description
                        Try
                            objGPIClassification = objGPIClassification.GetParent
                            Row(12) = objGPIClassification.Description
                        Catch e3 As Exception
                            Row(12) = Row(9)
                            Row(9) = Row(8)
                        End Try
                    Catch e4 As Exception
                        Row(9) = ""
                        Row(12) = ""
                    End Try
                Catch e5 As Exception
                    Row(8) = ""
                    Row(9) = ""
                    Row(12) = ""
                End Try
            End If
            temp = Row(8).ToString.Replace("""", "^")
            temp = temp.Replace("'", "~")
            Row(8) = temp
            temp = Row(9).ToString.Replace("""", "^")
            temp = temp.Replace("'", "~")
            Row(9) = temp
            temp = Row(9).ToString.Replace("""", "^")
            temp = temp.Replace("'", "~")
            Row(9) = temp
            temp = Row(12).ToString.Replace("""", "^")
            temp = temp.Replace("'", "~")
            Row(12) = temp
            Row(6) = "," + objPd.NDC
            Row(14) = objPd.NDC 'Single NDC

            Dim DP As Dib.DrugPrice
            Try
                DP = objPd.GetPriceCurrent("02")
                Row(11) = DP.Price
            Catch
                Row(11) = 0
            End Try
            Try
                DP = objPd.GetPriceCurrent("08")
                Row(10) = DP.Price
            Catch
                Row(10) = 0
            End Try
            dsdrug.Tables("Drugs").Rows.Add(Row)
            '''''''''''''''''''''''''''''''''''''''''''''Change LOG'''''''''''''''''''''''''''''''''''''''''''''''''''
            ''Description: Returned an empty dataset instead of throwing an exception 
            ''Could have returned the one passed but it might have led to the dataset being in an inconsistent state
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        Catch ex As Exception
            'Throw New Exception(ex.Message & ":MedispanLibrary\MSDrugMethods.GetRxDrugNamesByNDC(ByVal ndc As String, ByVal dsdrug As DataSet)")
            Return lTempDataset
        End Try
        Return dsdrug

    End Function

    Public Function GetRxDrugNamesByDDID(ByVal ddId As Integer, ByVal dsdrug As DataSet) As DataSet
        Dim nav As Dib.Navigation = New Dib.Navigation
        Dim objDIBCode As Dib.DIBCode
        Dim objDispensableDrug As Dib.DispensableDrug
        Dim eqDrugs As Dib.DispensableDrugs
        Dim objPd As Dib.PackagedDrugs
        Dim MyDataSet As DataSet = New DataSet
        Dim DrugTable As DataTable = New DataTable
        Dim Column1 As DataColumn
        Dim Column2 As DataColumn
        Dim Column3 As DataColumn
        Dim Column4 As DataColumn
        Dim Column5 As DataColumn
        Dim Column6 As DataColumn
        Dim Column7 As DataColumn
        Dim Column8 As DataColumn
        Dim Column9 As DataColumn
        Dim Column10 As DataColumn
        Dim Column11 As DataColumn
        Dim Column12 As DataColumn
        Dim Column13 As DataColumn
        Dim Column14 As DataColumn
        Dim Column15 As DataColumn

        '********* Duplicate Fields ************
        Dim Column16 As DataColumn
        Dim Column17 As DataColumn
        Dim Column18 As DataColumn
        Dim Column19 As DataColumn
        Dim Column20 As DataColumn
        Dim Column21 As DataColumn
        '********* End Duplicate Fields ********
        Dim Row As DataRow
        Dim temp As String = ""

        Try
            objDispensableDrug = New Dib.DispensableDrug(ddId)
            Dim objGPIClassification As Dib.GPIClassification
            objPd = objDispensableDrug.GetPackagedDrugs
            If dsdrug.Tables.Count = 0 Then
               
                DrugTable = MyDataSet.Tables.Add("Drugs")

                Column1 = New DataColumn("DrugID", System.Type.GetType("System.Int64"))
                DrugTable.Columns.Add(Column1)
                Column2 = New DataColumn("DrugName", System.Type.GetType("System.String"))
                DrugTable.Columns.Add(Column2)
                Column3 = New DataColumn("DrugRoute", System.Type.GetType("System.String"))
                DrugTable.Columns.Add(Column3)
                Column4 = New DataColumn("DrugDosage", System.Type.GetType("System.String"))
                DrugTable.Columns.Add(Column4)
                Column5 = New DataColumn("DrugForm", System.Type.GetType("System.String"))
                DrugTable.Columns.Add(Column5)
                Column6 = New DataColumn("DrugName2", System.Type.GetType("System.String"))
                DrugTable.Columns.Add(Column6)
                Column7 = New DataColumn("NDC", System.Type.GetType("System.String"))
                DrugTable.Columns.Add(Column7)
                Column8 = New DataColumn("DIN", System.Type.GetType("System.String"))
                DrugTable.Columns.Add(Column8)
                Column9 = New DataColumn("GenericName", System.Type.GetType("System.String"))
                DrugTable.Columns.Add(Column9)
                Column10 = New DataColumn("Class", System.Type.GetType("System.String"))
                DrugTable.Columns.Add(Column10)
                Column11 = New DataColumn("GPrice", System.Type.GetType("System.Double"))
                DrugTable.Columns.Add(Column11)
                Column12 = New DataColumn("WPrice", System.Type.GetType("System.Double"))
                DrugTable.Columns.Add(Column12)
                Column13 = New DataColumn("Group", System.Type.GetType("System.String"))
                DrugTable.Columns.Add(Column13)
                Column14 = New DataColumn("Status", System.Type.GetType("System.String"))
                DrugTable.Columns.Add(Column14)
                Column15 = New DataColumn("SingleNDC", System.Type.GetType("System.String"))
                DrugTable.Columns.Add(Column15)

                '********* Duplicate Fields ************
                Column16 = New DataColumn("ID", System.Type.GetType("System.Int64"))
                DrugTable.Columns.Add(Column16)

                Column17 = New DataColumn("Name", System.Type.GetType("System.String"))
                DrugTable.Columns.Add(Column17)

                Column18 = New DataColumn("Route", System.Type.GetType("System.String"))
                DrugTable.Columns.Add(Column18)

                Column19 = New DataColumn("Strength", System.Type.GetType("System.String"))
                DrugTable.Columns.Add(Column19)

                Column20 = New DataColumn("StrengthUnit", System.Type.GetType("System.String"))
                DrugTable.Columns.Add(Column20)

                Column21 = New DataColumn("DoseForm", System.Type.GetType("System.String"))
                DrugTable.Columns.Add(Column21)
                '********* End Duplicate Fields ********

                dsdrug = MyDataSet
            End If
          
            Row = dsdrug.Tables("Drugs").NewRow

            '********* Duplicate Fields ************
            Row(15) = objDispensableDrug.Id
            Row(16) = objDispensableDrug.Name
            Row(17) = objDispensableDrug.Route
            Row(18) = objDispensableDrug.Strength
            Row(19) = objDispensableDrug.StrengthUnit
            Row(20) = objDispensableDrug.DoseForm
            '********* End Duplicate Fields ********

            Row(0) = objDispensableDrug.Id
            Row(1) = objDispensableDrug.Name
            Row(2) = objDispensableDrug.Route
            Row(3) = objDispensableDrug.Strength & " " & objDispensableDrug.StrengthUnit
            Row(4) = objDispensableDrug.DoseForm
            temp = objDispensableDrug.Name.Replace("""", "^")
            temp = temp.Replace("'", "~")
            Row(5) = temp
            temp = objDispensableDrug.Id.ToString
            temp = temp.PadLeft(9, "0"c)
            Row(7) = temp
            Row(8) = ""
            objDIBCode = New Dib.DIBCode(20, objDispensableDrug.NameTypeCode)
            If objDIBCode.Description.Equals("Generic Name") Then
                Row(8) = Row(1)
            Else
                eqDrugs = objDispensableDrug.GetEquivalentItems(Dib.DIBDrugNameTypeFilter.DN_TF_BRANDGENERICANDGENERIC)
                For Each eqDrug As Dib.DispensableDrug In eqDrugs
                    objDIBCode = New Dib.DIBCode(20, eqDrug.NameTypeCode)
                    Row(8) = objDIBCode.Description
                    If objDIBCode.Description.Equals("Generic Name") Then
                        Row(8) = eqDrug.Name
                    End If
                Next
            End If
            If Not Row(8).Equals("") Then
                objDispensableDrug = New Dib.DispensableDrug(objDispensableDrug.Id)
                Try
                    objGPIClassification = objDispensableDrug.GetGPIClassification
                    Row(9) = objGPIClassification.Description
                    Try
                        objGPIClassification = objGPIClassification.GetParent
                        Row(12) = objGPIClassification.Description
                    Catch e2 As Exception
                        Row(12) = Row(9)
                        Row(9) = Row(8)
                    End Try
                Catch e1 As Exception
                    Row(9) = ""
                End Try
            Else
                objDispensableDrug = New Dib.DispensableDrug(objDispensableDrug.Id)
                Try
                    objGPIClassification = objDispensableDrug.GetGPIClassification
                    Row(8) = objGPIClassification.Description
                    Try
                        objGPIClassification = objGPIClassification.GetParent
                        Row(9) = objGPIClassification.Description
                        Try
                            objGPIClassification = objGPIClassification.GetParent
                            Row(12) = objGPIClassification.Description
                        Catch e3 As Exception
                            Row(12) = Row(9)
                            Row(9) = Row(8)
                        End Try
                    Catch e4 As Exception
                        Row(9) = ""
                        Row(12) = ""
                    End Try
                Catch e5 As Exception
                    Row(8) = ""
                    Row(9) = ""
                    Row(12) = ""
                End Try
            End If
            temp = Row(8).ToString.Replace("""", "^")
            temp = temp.Replace("'", "~")
            Row(8) = temp
            temp = Row(9).ToString.Replace("""", "^")
            temp = temp.Replace("'", "~")
            Row(9) = temp
            temp = Row(9).ToString.Replace("""", "^")
            temp = temp.Replace("'", "~")
            Row(9) = temp
            temp = Row(12).ToString.Replace("""", "^")
            temp = temp.Replace("'", "~")
            Row(12) = temp

            If objPd.Count > 0 Then
                Dim str As String = ""
                For x As Integer = 0 To objPd.Count - 1
                    str = str + "," + objPd.Item(x).Id
                Next
                Row(6) = str

                Row(14) = objPd.Item(0).NDC 'Single NDC
            End If
            Dim DP As Dib.DrugPrice
            Try
                DP = objPd.Item(0).GetPriceCurrent("02")
                Row(11) = DP.Price
            Catch
                Row(11) = 0
            End Try
            Try
                DP = objPd.Item(0).GetPriceCurrent("08")
                Row(10) = DP.Price
            Catch
                Row(10) = 0
            End Try
            dsdrug.Tables("Drugs").Rows.Add(Row)

        Catch ex As Exception
            Dim message As String = ""
            message = ex.Message
            TraceLogging.ErrorLogMethods.LogError(ex, "MedispanLibrary\MSDrugMethods.GetRxDrugNamesByDDID(ByVal ddId=" & ddId & " As Integer, ByVal dsdrug As DataSet)")
        End Try
        nav = Nothing
        Return dsdrug
    End Function

    Public Function GetSDrugName(ByVal ID As Integer, ByVal DrugConcept As String) As String
        Try
            Dim objDrugName As Dib.DrugName
            objDrugName = New Dib.DrugName(ID)
            Dim DrugName As String = objDrugName.Description
            Return DrugName
        Catch ex As Exception
            Throw New Exception(ex.Message & ":MedispanLibrary\MSDrugMethods.GetSDrugName(ByVal ID=" & ID & " As Integer, ByVal DrugConcept=" & DrugConcept & " As String)")
        End Try
    End Function

    Public Function GetDispDrugDetail(ByVal ID As Integer) As String()
        Dim DDArr(6) As String
        Try
            Dim objDispensableDrug As Dib.DispensableDrug
            objDispensableDrug = New Dib.DispensableDrug(ID)
            DDArr(0) = objDispensableDrug.Name
            DDArr(1) = objDispensableDrug.Route
            DDArr(2) = objDispensableDrug.Strength & " " & objDispensableDrug.StrengthUnit
            DDArr(3) = objDispensableDrug.DoseForm
            DDArr(4) = objDispensableDrug.DrugNameId.ToString
        Catch ex As Exception
            Throw New Exception(ex.Message & ":MedispanLibrary\MSDrugMethods.GetDispDrugDetail(ByVal ID=" & ID & " As Integer)")
        End Try
                Return DDArr
    End Function

    Public Function GetPatEducation(ByVal ID As Integer) As String
        Dim PatEd As String = ""
        Dim objDispensableDrug As Dib.DispensableDrug
        objDispensableDrug = New Dib.DispensableDrug(ID)
        Dim objMonograph As Dib.Monograph
        Try
            objMonograph = objDispensableDrug.GetPatientEd("MMW-CE")
            PatEd = objMonograph.GetFormattedText(Dib.DIBMonographFormat.MF_HTML)
        Catch e As Exception
            Try
                objMonograph = objDispensableDrug.GetPatientEd("MMW-TE")
                PatEd = objMonograph.GetFormattedText(Dib.DIBMonographFormat.MF_HTML)
            Catch e1 As Exception
                PatEd = "<br><br>No instructions available"
                TraceLogging.ErrorLogMethods.LogError(e1, "MedispanLibrary\MSDrugMethods.GetPatEducation(ByVal ID=" & ID & " As Integer)")
            End Try
        End Try
        Return PatEd
    End Function

    Public Function GetPackagedDrugsFromDispensableDrug(ByVal ddid As String) As DataSet
        Dim ds As DataSet = New DataSet
        Dim dr As DataRow
        Dim c1 As DataColumn
        Dim c2 As DataColumn
        Dim c3 As DataColumn
        Try
            Dim pd As Dib.PackagedDrugs
            Dim dd As Dib.DispensableDrug
            dd = New Dib.DispensableDrug(Integer.Parse(ddid))
            pd = dd.GetPackagedDrugs

            ds.Tables.Add("Drugs")
            c1 = New DataColumn("drug_id", System.Type.GetType("System.Int64"))
            ds.Tables(0).Columns.Add(c1)
            c2 = New DataColumn("drug_name", System.Type.GetType("System.String"))
            ds.Tables(0).Columns.Add(c2)
            c3 = New DataColumn("NDC", System.Type.GetType("System.String"))
            ds.Tables(0).Columns.Add(c3)
            For Each p As Dib.PackagedDrug In pd
                dr = ds.Tables(0).NewRow
                dr("drug_id") = p.Id
                dr("drug_name") = p.Description
                dr("NDC") = p.NDC
                ds.Tables(0).Rows.Add(dr)
            Next
        Catch ex As Exception
            Throw New Exception(ex.Message & ":MedispanLibrary\MSDrugMethods.GetPackagedDrugsFromDispensableDrug(ByVal ddid=" & ddid & " As String)")
        End Try
        Return ds
    End Function

    Public Function GetFullDrugName(ByVal ddid As String) As String
        Try
            Dim dd As Dib.DispensableDrug
            dd = New Dib.DispensableDrug(Integer.Parse(ddid))
            Dim drname As String = dd.Description
            Return drname

        Catch ex As Exception
            Throw New Exception(ex.Message & ":MedispanLibrary\MSDrugMethods.GetFullDrugName(ByVal ddid=" & ddid & " As String)")
        End Try
            End Function

    Public Function GetDosageRecomendations(ByVal agedays As Integer, ByVal DispDrugID As Integer, ByVal lConnectionString As String) As String
        Dim lRecommendation As String = ""
        Dim lTempString As String = ""
        Dim lSubString As String = "RECOMMENDED"
        Dim lIndex As Integer
        Dim DCArr(9) As String
        Dim objDispDrug As Dib.DispensableDrug

        Try
            Dim objScreenDrug As Dib.ScreenDrug
            Dim colScreenDrugs As Dib.ScreenDrugs = New Dib.ScreenDrugs()
            Dim objScreening As Dib.Screening = New Dib.Screening()
            Dim colDCScreenResults As Dib.DCScreenResults
            objDispDrug = New Dib.DispensableDrug(DispDrugID)
            objScreenDrug = New Dib.ScreenDrug(objDispDrug.Id.ToString, Dib.DIBDrugType.DT_DISPENSABLEDRUG)
            objScreenDrug.SetDose(CType(10000, Double), CType(10000, Double), 1)
            objScreenDrug.IsProspective = True
            colScreenDrugs.AddItem(objScreenDrug)
            colDCScreenResults = objScreening.DCScreen(colScreenDrugs, True, agedays)
            For Each colDCScreenResult As Dib.DCScreenResult In colDCScreenResults
                DCArr(0) = colDCScreenResult.DailyDoseComment
                DCArr(1) = colDCScreenResult.DailyDoseMessage
                DCArr(2) = colDCScreenResult.DurationMessage
                DCArr(3) = colDCScreenResult.SingleDoseComment
                DCArr(4) = colDCScreenResult.SingleDoseMessage
                DCArr(8) = ""
            Next
            If colDCScreenResults.Count > 0 Then
                lTempString = DCArr(1).ToUpper
                lIndex = lTempString.IndexOf(lSubString)
                If lIndex > 0 Then
                    lRecommendation = lTempString.Substring(lIndex)
                End If
                lTempString = DCArr(2).ToUpper
                lIndex = lTempString.IndexOf(lSubString)
                If lIndex > 0 Then
                    lRecommendation = lRecommendation & " <br><br> " & lTempString.Substring(lIndex)
                End If
                lTempString = DCArr(4).ToUpper
                lIndex = lTempString.IndexOf(lSubString)
                If lIndex > 0 Then
                    lRecommendation = lRecommendation & " <br><br> " & lTempString.Substring(lIndex)
                End If
            Else
                lRecommendation = "Recommendation Not Available"
            End If
        Catch ex As Exception
            lRecommendation = "Recommendation Not Available"
            TraceLogging.ErrorLogMethods.LogError(ex, "MedispanLibrary\MSDrugMethods.GetDosageRecomendations(ByVal agedays=" & agedays & " As Integer, ByVal DispDrugID=" & DispDrugID & " As Integer, ByVal lConnectionString=" & lConnectionString & " As String)")
        End Try
        Return lRecommendation
    End Function

    Public Function GetControlSubstanceID(ByVal ddid As Integer) As String
        Try
            Dim objDispensableDrug As Dib.DispensableDrug
            Dim cntrlsubId As String = ""
            Try
                objDispensableDrug = New Dib.DispensableDrug(ddid)
                cntrlsubId = CType(objDispensableDrug.ControlledSubstanceCode, String)
                Return cntrlsubId
            Catch ex1 As Dib.DIBValueNotFoundException
                Return ""
            End Try
        Catch ex As Exception
            Throw New Exception(ex.Message & ":MedispanLibrary\MSDrugMethods.GetControlSubstanceID(ByVal ddid=" & ddid & " As Integer)")
        End Try
            End Function

    Public Function GetControlSubstanceID(ByVal ndc As String) As String
        Try
            Dim objPackageDrug As Dib.PackagedDrug
            Dim objDispensableDrug As Dib.DispensableDrug
            Dim cntrlsubId As String
            Try
                objPackageDrug = New Dib.PackagedDrug(ndc)
                objDispensableDrug = New Dib.DispensableDrug(objPackageDrug.DispensableDrugId)
                cntrlsubId = CType(objDispensableDrug.ControlledSubstanceCode, String)
            Catch ex1 As Dib.DIBValueNotFoundException
                Return ""
            End Try
            Return cntrlsubId
        Catch ex As System.Exception
            TraceLogging.ErrorLogMethods.LogError(ex, "MedispanLibrary\MSDrudMethods.GetControlSubstanceID(ByVal ndc=" & ndc & " As String)")
            Return ""
            'Record Not Found for given Drug
        End Try
    End Function

    Public Function GetDosingUnit(ByVal ddid As String) As String
        Dim lDosingUnit As String
        Try
            Dim objDispensableDrug As Dib.DispensableDrug
            objDispensableDrug = New Dib.DispensableDrug(Integer.Parse(ddid))
            If objDispensableDrug.DosingUnit Is Nothing Then
                lDosingUnit = ""
            Else
                lDosingUnit = objDispensableDrug.DosingUnit
            End If
        Catch ex As Exception
            Throw New Exception(ex.Message & ":MedispanLibrary\MSDrugMethods.GetDosingUnit(ByVal ddid=" & ddid & " As String)")
        End Try
        Return lDosingUnit
    End Function

    ''Public Function CheckSchedule(ByVal searchstring As String) As String
    ''    Dim schedule As String = "0"
    ''    Dim conn As SqlConnection = New SqlConnection
    ''    Dim rdr As SqlDataReader
    ''    Dim Temp As String()
    ''    Dim sqlquery As String = ""
    ''    Try
    ''        conn.ConnectionString = ConfigurationManager.ConnectionStrings("connectionString").ConnectionString
    ''        Temp = searchstring.Split(" "c)
    ''        sqlquery = "Select Schedule FROM [Schedule Code] WHERE (Name LIKE '%" & Temp(0) & "%')"
    ''        Dim cmd As SqlCommand = New SqlCommand(sqlquery, conn)
    ''        cmd.CommandType = CommandType.Text
    ''        Try
    ''            conn.Open()
    ''            rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
    ''            While rdr.Read
    ''                schedule = rdr.GetString(0)
    ''            End While
    ''        Catch ex As Exception
    ''            Throw New Exception(ex.Message & ":MedispanLibrary\MSDrugMethods.CheckSchedule(ByVal searchstring As String)")
    ''        End Try
    ''    Catch ex As Exception
    ''        Throw New Exception(ex.Message & ":MedispanLibrary\MSDrugMethods.CheckSchedule(ByVal searchstring As String)")
    ''    End Try
    ''    Return schedule
    ''End Function

    ''Public Function CheckScheduleLevel(ByVal searchstring As String) As String
    ''    Dim temp As String = ""
    ''    Dim schedule As String = "0"
    ''    Dim conn As SqlConnection = New SqlConnection
    ''    Dim rdr As SqlDataReader
    ''    Dim Temp2 As String()
    ''    Dim sqlquery As String
    ''    Try
    ''        conn.ConnectionString = ConfigurationManager.ConnectionStrings("connectionString").ConnectionString
    ''        Temp2 = searchstring.Split(" "c)
    ''        Dim i As Integer = temp.Length
    ''        While i > 0
    ''            temp = ""
    ''            Dim j As Integer = 0
    ''            While j < i
    ''                temp &= Temp2(j) & " "c
    ''                System.Math.Min(System.Threading.Interlocked.Increment(j), j - 1)
    ''            End While
    ''            temp = temp.Trim
    ''            sqlquery = "Select ctrlsubstancecode FROM ScheduleDrugs WHERE (descdisplay LIKE '" & temp & "%') ORDER BY ctrlsubstancecode"
    ''            Dim cmd As SqlCommand = New SqlCommand(sqlquery, conn)
    ''            cmd.CommandType = CommandType.Text
    ''            Try
    ''                If Not (conn.State = ConnectionState.Open) Then
    ''                    conn.Open()
    ''                End If
    ''                rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
    ''                While rdr.Read
    ''                    schedule = rdr.GetString(0)
    ''                End While
    ''                rdr.Close()
    ''            Catch ex As Exception
    ''                Throw New Exception(ex.Message & ":MedispanLibrary\MSDrugMethods.CheckScheduleLevel(ByVal searchstring As String)")
    ''            End Try
    ''            If Not (schedule = "0") Then
    ''            End If
    ''            System.Math.Max(System.Threading.Interlocked.Decrement(i), i + 1)
    ''        End While
    ''    Catch ex As Exception
    ''        Throw New Exception(ex.Message & ":MedispanLibrary\MSDrugMethods.CheckScheduleLevel(ByVal searchstring As String)")
    ''    End Try

    ''    Return schedule
    ''End Function

    Public Function DisClaimer() As String
        Dim lDisclaimer As String = ""
        Try
            Dim nav As Dib.Navigation = New Dib.Navigation
            lDisclaimer = nav.DisclaimerLoad
            nav = Nothing
        Catch ex As Exception
            lDisclaimer = ""
            TraceLogging.ErrorLogMethods.LogError(ex, "MedispanLibrary\MSDrugMethods.DisClaimer()")
        End Try
        Return lDisclaimer
    End Function

    Public Function GetDrugAttributes(ByVal AttribName As String) As DataSet
        Dim MyDataSet As DataSet = New DataSet
        Dim MasterTable As DataTable = New DataTable
        MasterTable = MyDataSet.Tables.Add("Attribute")
        Dim Column1 As DataColumn
        Dim Column2 As DataColumn
        Dim Row As DataRow
        Try
            Column1 = New DataColumn("mkey", System.Type.GetType("System.Int64"))
            MasterTable.Columns.Add(Column1)
            Column2 = New DataColumn("description", System.Type.GetType("System.String"))
            MasterTable.Columns.Add(Column2)
            Row = MasterTable.NewRow
            Row(0) = 0
            Row(1) = "ALL"
            MasterTable.Rows.Add(Row)
            Dim nav As Dib.Navigation = New Dib.Navigation
            Dim NumRows As Integer = 0
            If AttribName.Equals("Form") Then
                Dim colDoseForms As Dib.DoseForms
                colDoseForms = nav.DoseFormsLoadAll
                For Each colDoseForm As Dib.DoseForm In colDoseForms
                    Row = MasterTable.NewRow
                    Row(0) = colDoseForm.Id
                    Row(1) = colDoseForm.Description
                    MasterTable.Rows.Add(Row)
                Next
            Else
                If AttribName.Equals("Color") Then
                    Dim colColors As Dib.ImprintColors
                    colColors = nav.ImprintColorsLoad
                    For Each colcolor As Dib.ImprintColor In colColors
                        Row = MasterTable.NewRow
                        Row(0) = colcolor.Id
                        Row(1) = colcolor.Description
                        MasterTable.Rows.Add(Row)
                    Next
                Else
                    If AttribName.Equals("Shape") Then
                        Dim colShapes As Dib.ImprintShapes
                        colShapes = nav.ImprintShapesLoad
                        For Each colShape As Dib.ImprintShape In colShapes
                            Row = MasterTable.NewRow
                            Row(0) = colShape.Id
                            Row(1) = colShape.Description
                            MasterTable.Rows.Add(Row)
                        Next
                    End If
                End If
            End If
        Catch ex As Exception
            Throw New Exception(ex.Message & ":MedispanLibrary\MSDrugMethods.GetDrugAttributes(ByVal AttribName=" & AttribName & " As String)")
        End Try
        Return MyDataSet
    End Function

    Public Function GetDrugAttribSet2(ByVal CodeType As Short) As DataSet
        Dim MyDataSet As DataSet = New DataSet
        Dim MasterTable As DataTable = New DataTable
        MasterTable = MyDataSet.Tables.Add("AttribSet2")
        Dim Column1 As DataColumn
        Dim Column2 As DataColumn
        Dim Row As DataRow
        Dim nav As Dib.Navigation = New Dib.Navigation
        Dim NumRows As Integer = 0
        Dim colSet As Dib.DIBCodes
        Try
            Column1 = New DataColumn("mkey", System.Type.GetType("System.String"))
            MasterTable.Columns.Add(Column1)
            Column2 = New DataColumn("description", System.Type.GetType("System.String"))
            MasterTable.Columns.Add(Column2)
            Row = MasterTable.NewRow
            Row(0) = "N/A"
            Row(1) = "ALL"
            MasterTable.Rows.Add(Row)
            colSet = nav.DIBCodesLoad(CodeType)
            For Each colSe As Dib.DIBCode In colSet
                Row = MasterTable.NewRow
                Row(0) = colSe.CodeValue
                Row(1) = colSe.Description
                MasterTable.Rows.Add(Row)
            Next
        Catch ex As Exception
            Throw New Exception(ex.Message & ":MedispanLibrary\MSDrugMethods.GetDrugAttribSet2(ByVal CodeType=" & CodeType & " As Short)")
        End Try
        Return MyDataSet
    End Function

    Public Function AllergySearch(ByVal SearchString As String) As DataSet
        Dim AllergyDataSet As DataSet = New DataSet
        Dim DrugsTable As DataTable = New DataTable
        Dim Column1, Column2 As DataColumn
        Dim Row As DataRow
        Try
            If SearchString = "" Then
                SearchString = "abc123"
            End If
            Dim objNavigation As Dib.Navigation = New Dib.Navigation
            Dim colAllergies As Dib.AllergyClasses
            colAllergies = objNavigation.AllergyClassSearch(SearchString, Dib.DIBSearchMethod.DIB_SM_SIMPLE, Dib.DIBPhoneticSearch.DIB_PS_NOPHONETIC)
            DrugsTable = AllergyDataSet.Tables.Add("AllergyList")
            Column1 = New DataColumn("Allergy_id", System.Type.GetType("System.Int32"))
            DrugsTable.Columns.Add(Column1)
            Column2 = New DataColumn("Allergy_name", System.Type.GetType("System.String"))
            DrugsTable.Columns.Add(Column2)
            For Each colAllergy As Dib.AllergyClass In colAllergies
                Row = AllergyDataSet.Tables("AllergyList").NewRow()
                Row(0) = colAllergy.Id
                Row(1) = colAllergy.Description
                AllergyDataSet.Tables("AllergyList").Rows.Add(Row)
            Next
        Catch ex As Exception
            Throw New Exception(ex.Message & ":MedispanLibrary\MSDrugMethods.AllergySearch(ByVal SearchString=" & SearchString & " As String)")
        End Try
        Return AllergyDataSet
    End Function

    'This function takes the DDID and returns all the related NDC
    Public Function GetAllNdc(ByVal DDI As String) As String
        Try
            Dim result As String = ""
            Dim objDispensableDrug As Dib.DispensableDrug
            Dim colPackagedDrugs As Dib.PackagedDrugs
            objDispensableDrug = New Dib.DispensableDrug(Convert.ToInt32(DDI))
            If (objDispensableDrug.HasPackagedDrugs) Then
                colPackagedDrugs = objDispensableDrug.GetPackagedDrugs()
                For index1 As Int32 = 0 To colPackagedDrugs.Count - 1
                    result = result & "," & colPackagedDrugs.Item(index1).Id
                Next
            End If
            Return result
        Catch ex As Exception
            TraceLogging.ErrorLogMethods.LogError(ex, "MedispanLbrary\MSDrugMethods.GetAllNdc(ByVal DDI=" & DDI & " As String)")
            Return ""
        End Try
    End Function


    'Author : Fareed 
    'Purpose : This function returns all the therapeutic alternatives
    'Modified : Faraz
    Public Function GetAlternativesDDIDbyGPI(ByVal pNDC As String) As Object
        Try
            Dim result As String = ""
            Dim objGPIClassification As Dib.GPIClassification
            ''Dim objAHFSClassification As Dib.AHFSClassification
            Dim objPackageDrug As Dib.PackagedDrug
            'Dim objDispensableDrug As Dib.DispensableDrug
            'Dim colDispensableDrugs As Dib.DispensableDrugs
            objPackageDrug = New Dib.PackagedDrug(pNDC)
            objGPIClassification = objPackageDrug.GetGPIClassification()
            ''objAHFSClassification = objPackageDrug.GetAHFSClassification()
            'objDispensableDrug = New Dib.DispensableDrug(objPackageDrug.DispensableDrugId)
            Return objGPIClassification.GetDispensableDrugs()
            'Return objAHFSClassification.GetDispensableDrugs()
            'Return objDispensableDrug.GetEquivalentItems(Dib.DIBDrugNameTypeFilter.DN_TF_ALL)
            'colDispensableDrugs = objGPIClassification.GetDispensableDrugs()
            'If (colDispensableDrugs.Count > 0) Then
            '    For index As Int32 = 0 To colDispensableDrugs.Count - 1
            '        result = result & "," & colDispensableDrugs.Item(index).Id
            '    Next
            'End If
            'Return result
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    'Author : Fareed 
    'Purpose : This function returns the name of drugs given the DDID
    'Modified : Faraz
    Public Function GetDrugNameByDDID(ByVal pDDID As String) As String
        Try
            Dim objDispensableDrug As Dib.DispensableDrug
            objDispensableDrug = New Dib.DispensableDrug(Convert.ToInt32(pDDID))
            Dim Name As String = objDispensableDrug.Description
            Return Name
        Catch ex As Exception
            TraceLogging.ErrorLogMethods.LogError(ex, "MedispanLbrary\MSDrugMethods.GetDrugNameByDDID(ByVal pDDID=" & pDDID & " As String)")
            Return "Not Found"
        End Try
    End Function


    ' This function gets the type thru code 
    Public Function GetNameTypeCode(ByVal pNDC As String) As String
        Try
            Dim objPackageDrug As Dib.PackagedDrug
            objPackageDrug = New Dib.PackagedDrug(pNDC)
            Dim NameTypeCode As String = objPackageDrug.NameTypeCode
            Return NameTypeCode
        Catch ex As Exception
            TraceLogging.ErrorLogMethods.LogError(ex, "MedispanLibrary\MSDrugMethods.GetNameTypeCode(ByVal pNDC=" & pNDC & " As String)")
            Return "Not Found"
        End Try
    End Function


    'This function tells whether the Drug is OTC or not 
    'Returns "P" or "O"
    Public Function GetOTC(ByVal pNDC As String) As String
        Try
            Dim objPackageDrug As Dib.PackagedDrug

            objPackageDrug = New Dib.PackagedDrug(pNDC)
            Dim lRxOtcCode As String = objPackageDrug.RxOtcCode

            'Change the return from O and R to O and P 
            Return IIf(lRxOtcCode.Equals("R"), "P", lRxOtcCode)

        Catch ex As Exception
            TraceLogging.ErrorLogMethods.LogError(ex, "MedispanLibrary\MSDrugMethods.GetOTC(ByVal pNDC=" & pNDC & " As String)")
            Return "Not Found"
        End Try
    End Function


    ' This tells whether its a Non-Drug
    ' Returns Y or N
    Public Function IsNonDrug(ByVal pNDC As String) As String
        Try

            Dim objPackageDrug As Dib.PackagedDrug
            objPackageDrug=new Dib.PackagedDrug(pNDC)
            Dim lType As String = objPackageDrug.IsMedicalDevice
            Return IIf(lType.ToUpper.Equals("TRUE"), "Y", "N")
        Catch ex As Exception
            TraceLogging.ErrorLogMethods.LogError(ex, "MedispanLibrary\MSDrugMethods.IsNonDrug(ByVal pNDC=" & pNDC & " As String)")
            Return "Not Found"
        End Try
    End Function

    'This function returns the drug name based on the NDC (Alternative to the first one which returns a dataset)    
    Public Function GetDrugName(ByVal pNDC As String) As String
        Try
            Dim objPackageDrug As Dib.PackagedDrug
            objPackageDrug = New Dib.PackagedDrug(pNDC)            
            Dim lDrugName As String = objPackageDrug.Name
            Return lDrugName

        Catch ex As Exception
            TraceLogging.ErrorLogMethods.LogError(ex, "MedispanLibrary\MSDrugMethods.GetDrugName(ByVal pNDC=" & pNDC & " As String)")
            Return "Not Found"
        End Try
    End Function

    Public Function SearchDrugs(ByVal pDrugName As String) As Dib.DispensableDrugs
        Dim lNavigation As Dib.Navigation = New Dib.Navigation
        Dim lDrugFilter As Dib.DrugFilter = New Dib.DrugFilter
        Dim lDispensableDrugsColl As Dib.DispensableDrugs

        Try
            lDrugFilter.SetIncludeDevices(True)
            lDrugFilter.SetNameType(Dib.DIBDrugNameTypeFilter.DN_TF_ALL)
            lDispensableDrugsColl = lNavigation.DispensableDrugSearch(pDrugName, Dib.DIBSearchMethod.DIB_SM_SIMPLE, Dib.DIBPhoneticSearch.DIB_PS_NOPHONETIC, lDrugFilter)
        Catch ex As Exception
            TraceLogging.ErrorLogMethods.LogError(ex, "MedispanLibrary\MSDrugMethods.SearchDrugs(ByVal pDrugName=" & pDrugName & " As String)")
            Return Nothing
        End Try
        Return lDispensableDrugsColl
    End Function

    Public Function GetDrugNameIDByDDID(ByVal pDDID As String) As String
        Try
            Dim objDispensableDrug As Dib.DispensableDrug
            objDispensableDrug = New Dib.DispensableDrug(Convert.ToInt32(pDDID))
            Dim DrugNameId As String = objDispensableDrug.DrugNameId
            Return DrugNameId
        Catch ex As Exception
            TraceLogging.ErrorLogMethods.LogError(ex, "MedispanLibrary\MSDrugMethods.GetDrugNameIDByDDID(ByVal pDDID=" & pDDID & " As String)")
            Return "0"
        End Try
    End Function
    'Author : Fareed 
    'Purpose : This function returns either medical device or not
    Public Function IsDeviceByDDID(ByVal pDDID As String) As Boolean
        Try
            Dim objDispensableDrug As Dib.DispensableDrug
            objDispensableDrug = New Dib.DispensableDrug(Convert.ToInt32(pDDID))
            Return objDispensableDrug.IsMedicalDevice
        Catch ex As Exception
            TraceLogging.ErrorLogMethods.LogError(ex, "MedispanLibrary\MSDrugMethods.IsDeviceByDDID(ByVal pDDID=" & pDDID & " as String)")
            Return False
        End Try
    End Function
    'Author : Fareed 
    'Purpose : This function returns type of drug
    '1 Prescription Required
    '2 Over the counter
    '3 Both
    Public Function DrugTypeByDDID(ByVal pDDID As String) As String
        Try
            Dim objDispensableDrug As Dib.DispensableDrug
            objDispensableDrug = New Dib.DispensableDrug(Convert.ToInt32(pDDID))
            Return objDispensableDrug.RxOtcCode
        Catch ex As Exception
            Throw New Exception(ex.Message & ":MedispanLibray\MSDrugMethods.DrugTypeByDDID(ByVal pDDID=" & pDDID & " As String)")
        End Try
    End Function
    'Author : Fareed 
    'Purpose : This function returns name type of drug
    '1 Trademarked Name
    '2 Branded Generic Name
    '3 Generic Name

    Public Function DrugNameTypeByDDID(ByVal pDDID As String) As String
        Try
            Dim objDispensableDrug As Dib.DispensableDrug
            objDispensableDrug = New Dib.DispensableDrug(Convert.ToInt32(pDDID))
            Return objDispensableDrug.NameTypeCode
        Catch ex As Exception
            Throw New Exception(ex.Message & ":MedispanLibray\MSDrugMethods.DrugNameTypeByDDID(ByVal pDDID=" & pDDID & " As String)")
        End Try
    End Function
    'Author : Fareed 
    'Purpose : This function returns DDID of Drug given NDC
    Public Function GetDDIDByNDC(ByVal pNDC As String) As String
        Try
            Dim objPackageDrug As Dib.PackagedDrug
            objPackageDrug = New Dib.PackagedDrug(pNDC)
            Dim lDDID As String = Convert.ToString(objPackageDrug.DispensableDrugId)
            Return lDDID
        Catch ex As Exception
            TraceLogging.ErrorLogMethods.LogError(ex, "MedispanLibrary\MSDrugMethods.GetDDIDByNDC(ByVal pNDC=" & pNDC & " As String)")
            Return "Not Found"
        End Try
    End Function

    'This function returns the comma separated ddid
    Public Function ReturnDDID(ByVal pDrugCollection As Object) As String
        Dim lDDID As String = "'"
        Try
            Dim lDrugCollection As Medispan.Dib.DispensableDrugs
            lDrugCollection = CType(pDrugCollection, Medispan.Dib.DispensableDrugs)
            For Each lDispensibleDrug As Medispan.Dib.DispensableDrug In lDrugCollection
                lDDID = lDDID & lDispensibleDrug.Id & "','"
            Next
            If lDDID.Length > 1 Then
                lDDID = lDDID.Substring(0, lDDID.Length - 2)
            End If
        Catch ex As Exception
            Throw New Exception(ex.Message & ":MedispanLibrary\MSDrugMethods.ReturnDDID(ByVal pDrugCollection As Object)")
        End Try
        Return lDDID
    End Function

    Public Function InsertInCollection(ByVal pDataSet As DataSet, ByVal pCollection As Object, ByVal pFormularyID As String) As DrugsColl
        Dim lDrugsColl As New DrugsColl
        Dim lOrderedDrugsColl As New DrugsColl
        Dim lDrug As Drug
        Try
            Dim lDrugCollection As Medispan.Dib.DispensableDrugs
            lDrugCollection = CType(pCollection, Medispan.Dib.DispensableDrugs)
            If pFormularyID.Equals("") Then
                For Each lDispensableDrug As Medispan.Dib.DispensableDrug In lDrugCollection
                    lDrug = New Drug
                    lDrug.DispensibleDrug = lDispensableDrug
                    lDrug.IsGeneric = IIf(DrugNameTypeByDDID(lDispensableDrug.Id).Equals("3"), "Y", "N")
                    lDrug.IsNonDrug = IIf(IsDeviceByDDID(lDispensableDrug.Id) = True, "Y", "N")
                    lDrug.OTC = IIf(DrugTypeByDDID(lDispensableDrug.Id).Equals("2") Or DrugTypeByDDID(lDispensableDrug.Id).Equals("3"), "O", "P")
                    lDrug.Status = "V"
                    ''And (lDispensableDrug.GenericCode = "Y" Or lDispensableDrug.GenericCode = "O")
                    If (lDispensableDrug.ObsoleteDate = "" And lDispensableDrug.NameSourceCode <> "0") Then
                        lDrugsColl.Add(lDrug)
                    End If
                Next
            Else
                If pDataSet IsNot Nothing Then
                    For Each lDispensableDrug As Medispan.Dib.DispensableDrug In lDrugCollection
                        lDrug = New Drug
                        lDrug.DispensibleDrug = lDispensableDrug
                        Dim lDataRow() As DataRow = pDataSet.Tables(0).Select("DDID = '" & lDispensableDrug.Id & "'")
                        If lDataRow.Length > 0 Then
                            If lDataRow(0)(3).Equals("0") Then
                                lDrug.IsGeneric = IIf(DrugNameTypeByDDID(lDispensableDrug.Id).Equals("3"), "Y", "N")
                                lDrug.IsNonDrug = IsDeviceByDDID(lDispensableDrug.Id)
                                lDrug.OTC = DrugTypeByDDID(lDispensableDrug.Id)
                                lDrug.Status = "0"
                            Else
                                lDrug.IsGeneric = lDataRow(0)(1)
                                lDrug.IsNonDrug = lDataRow(0)(3)
                                lDrug.OTC = lDataRow(0)(2)
                                lDrug.Status = lDataRow(0)(4)
                            End If
                        Else
                            lDrug.IsGeneric = IIf(DrugNameTypeByDDID(lDispensableDrug.Id).Equals("3"), "Y", "N")
                            lDrug.IsNonDrug = IIf(IsDeviceByDDID(lDispensableDrug.Id) = True, "Y", "N")
                            lDrug.OTC = IIf(DrugTypeByDDID(lDispensableDrug.Id).Equals("2") Or DrugTypeByDDID(lDispensableDrug.Id).Equals("3"), "O", "P")
                            lDrug.Status = ""
                        End If
                        ''And (lDispensableDrug.GenericCode = "Y" Or lDispensableDrug.GenericCode = "O")
                        If (lDispensableDrug.ObsoleteDate = "" And lDispensableDrug.NameSourceCode <> "0") Then
                            lDrugsColl.Add(lDrug)
                        End If
                    Next
                End If
            End If
        Catch ex As Exception
            Throw New Exception(ex.Message & ":MedispanLibrary\MSDrugMethods.InsertInCollection(ByVal pDataSet As DataSet, ByVal pCollection As Object, ByVal pFormularyID=" & pFormularyID & " As String)")
        End Try
        Return lDrugsColl
    End Function

    'Private Sub Swap(ByRef pCollection As DrugsColl, ByVal pOldNode As Integer, ByVal pNewNode As Integer)
    '    Dim lNode As Drug

    '    lNode = pCollection.Item(pOldNode)
    '    pCollection.Item(pOldNode) = pCollection.Item(pNewNode)
    '    pCollection.Item(pNewNode) = lNode

    'End Sub

    'This function tells whether the Drug is OTC or not 
    'Returns "P" or "O"

    Public Function GetDrugCharacteristics(ByVal pNDC As String) As String
        Try
            Dim objPackageDrug As Dib.PackagedDrug
            objPackageDrug = New Dib.PackagedDrug(pNDC)
            Dim lCharacteristics As String = ""
            lCharacteristics = objPackageDrug.RxOtcCode()
            'Change the return from O and R to O and P 

            lCharacteristics = IIf(lCharacteristics.Equals("R"), "P", lCharacteristics) & "|"

            lCharacteristics &= IIf(objPackageDrug.IsMedicalDevice.ToString.ToUpper.Equals("TRUE"), "Y", "N") & "|"

            lCharacteristics &= objPackageDrug.NameTypeCode & "|"

            Return lCharacteristics
        Catch ex As Exception
            TraceLogging.ErrorLogMethods.LogError(ex, "MedispanLibrary\MSDrugMethods.GetDrugCharacteristics(ByVal pNDC=" & pNDC & " As String)")
            Return "|||"
        End Try
    End Function
    'Author      : Fareed 
    'Purpose     : This function checks validity of drug specified by given DDID  on basis of obsolete date and name source code and return True/False
    'Create Date : 6 Oct 2008 
    Public Function IsValidDrug(ByVal pDDID As String) As Boolean
        Try
            Dim objDispensableDrug As Dib.DispensableDrug
            objDispensableDrug = New Dib.DispensableDrug(Convert.ToInt32(pDDID))
            If (objDispensableDrug.ObsoleteDate = "" And objDispensableDrug.NameSourceCode <> "0") Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            Throw New Exception(ex.Message & ":MedispanLibray\MSDrugMethods.IsValidDrug(ByVal pDDID=" & pDDID & " As String)")
        End Try
    End Function

    Public Function CheckSchedule(ByVal searchstring As String) As String
        Dim schedule As String = "0"
        Dim conn As SqlConnection = New SqlConnection
        conn.ConnectionString = ConfigurationManager.ConnectionStrings("connectionString").ConnectionString
        Dim rdr As SqlDataReader
        Dim Temp() As String = searchstring.Split(" ")
        Dim sqlquery As String
        sqlquery = "Select Schedule FROM [Schedule Code] WHERE (Name LIKE '%" + Temp(0) + "%')"
        Dim cmd As SqlCommand = New SqlCommand(sqlquery, conn)
        cmd.CommandType = CommandType.Text
        Try
            conn.Open()
            rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
            While (rdr.Read())
                schedule = rdr.GetString(0)
                Exit While
            End While
        Catch ex As Exception
            Throw New Exception(ex.Message & ":MedispanLibrary\MSDrugMethods.CheckSchedule(ByVal searchstring=" & searchstring & " As String)")
        End Try
        Return schedule

    End Function

    Public Function CheckScheduleLevel(ByVal searchstring As String) As String
        Dim lNavigation As Dib.Navigation = New Dib.Navigation
        Dim lMedispanConnectionString As String = lNavigation.Connection.ConnectString
        Dim schedule As String = "0"
        Dim conn As SqlConnection = New SqlConnection()
        conn.ConnectionString = lMedispanConnectionString ''ConfigurationManager.ConnectionStrings("connectionString").ConnectionString
        Dim rdr As SqlDataReader
        Dim sqlquery As String
        sqlquery = "Select ctrlsubstancecode FROM mmw_drug_disp WHERE (descdisplay LIKE '" + searchstring.Trim + "%') ORDER BY ctrlsubstancecode"
        Dim cmd As SqlCommand = New SqlCommand(sqlquery, conn)
        cmd.CommandType = CommandType.Text

        Try
            If (conn.State <> ConnectionState.Open) Then
                conn.Open()
            End If
            rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
            While (rdr.Read())
                schedule = rdr.GetString(0)
                Exit While
            End While
            rdr.Close()
        Catch ex As Exception
            Throw New Exception(ex.Message & ":MedispanLibrary\MSDrugMethods.CheckScheduleLevel(ByVal searchstring=" & searchstring & " As String)")
        End Try

        Return schedule

    End Function


    'Public Function InsertInCollection(ByVal pCollection As Object) As DrugsColl
    '    Dim lDrugsColl As New DrugsColl
    '    Dim lOrderedDrugsColl As New DrugsColl
    '    Dim lDrug As Drug
    '    Try
    '        Dim lDrugCollection As Medispan.Dib.DispensableDrugs
    '        lDrugCollection = CType(pCollection, Medispan.Dib.DispensableDrugs)

    '        For Each lDispensableDrug As Medispan.Dib.DispensableDrug In lDrugCollection
    '            lDrug = New Drug
    '            lDrug.DispensibleDrug = lDispensableDrug
    '            lDrug.IsGeneric = IIf(DrugNameTypeByDDID(lDispensableDrug.Id).Equals("3"), "Y", "N")
    '            lDrug.IsNonDrug = IIf(IsDeviceByDDID(lDispensableDrug.Id) = True, "Y", "N")
    '            lDrug.OTC = IIf(DrugTypeByDDID(lDispensableDrug.Id).Equals("2") Or DrugTypeByDDID(lDispensableDrug.Id).Equals("3"), "O", "P")
    '            lDrug.Status = "Unavailable"
    '            lDrug.StatusCode = -1
    '            ''And (lDispensableDrug.GenericCode = "Y" Or lDispensableDrug.GenericCode = "O")
    '            If (lDispensableDrug.ObsoleteDate = "" And lDispensableDrug.NameSourceCode <> "0") Then
    '                lDrugsColl.Add(lDrug)
    '            End If
    '        Next

    '    Catch ex As Exception
    '        Throw New Exception(ex.Message & ":MedispanLibrary\MSDrugMethods.InsertInCollection(ByVal pCollection As Object)")
    '    End Try
    '    Return lDrugsColl
    'End Function



End Class
