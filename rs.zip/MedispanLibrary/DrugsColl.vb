Imports Microsoft.VisualBasic
Imports system.Collections
Imports Medispan

Public Class Drug

    Private mDispensibleDrug As Medispan.Dib.DispensableDrug
    Private mStatus As String
    Private mSingleNDC As String
    Private mOTC As String
    Private mIsGeneric As String
    Private mIsNonDrug As String
    Private mStatusCode As Integer

    Private mCopayRules As String

    Public Property CopayRules() As String
        Get
            Return mCopayRules
        End Get
        Set(ByVal value As String)
            mCopayRules = value
        End Set
    End Property

    Public ReadOnly Property Name() As String
        Get
            Return mDispensibleDrug.Name
        End Get
    End Property

    Public ReadOnly Property ID() As Integer
        Get
            Return mDispensibleDrug.Id
        End Get
    End Property

    Public ReadOnly Property Route() As String
        Get
            Return mDispensibleDrug.Route
        End Get
    End Property

    Public ReadOnly Property Strength() As String
        Get
            Return mDispensibleDrug.Strength
        End Get
    End Property

    Public ReadOnly Property StrengthUnit() As String
        Get
            Return mDispensibleDrug.StrengthUnit
        End Get
    End Property

    Public ReadOnly Property DoseForm() As String
        Get
            Return mDispensibleDrug.DoseForm
        End Get
    End Property

    Public Property DispensibleDrug() As Dib.DispensableDrug
        Get
            Return mDispensibleDrug
        End Get
        Set(ByVal value As Dib.DispensableDrug)
            mDispensibleDrug = value
        End Set
    End Property

    Public Property StatusCode() As Integer
        Get
            Return mStatusCode
        End Get
        Set(ByVal value As Integer)
            mStatusCode = value
        End Set
    End Property

    Public Property Status() As String
        Get
            Return mStatus
        End Get
        Set(ByVal value As String)
            mStatus = value
        End Set
    End Property

    Public Property SingleNDC() As String
        Get
            Return mSingleNDC
        End Get
        Set(ByVal value As String)
            mSingleNDC = value
        End Set
    End Property
    Public Property OTC() As String
        Get
            If mOTC = "P" Then
                Return "N"
            Else
                Return "Y"
            End If
        End Get
        Set(ByVal value As String)
            mOTC = value
        End Set
    End Property
    Public Property IsGeneric() As String
        Get
            Return mIsGeneric
        End Get
        Set(ByVal value As String)
            mIsGeneric = value
        End Set
    End Property

    Public Property IsNonDrug() As String
        Get
            Return mIsNonDrug
        End Get
        Set(ByVal value As String)
            mIsNonDrug = value
        End Set
    End Property
End Class


Public Class DrugsColl
    Inherits CollectionBase

    Public Function Add(ByVal pDrug As Drug) As Integer
        Try
            Return List.Add(pDrug)
        Catch ex As Exception
            Throw New Exception(ex.Message & ":MedispanLibrary\DrugsColl.Add(ByVal pDrug As Drug)")
        End Try
    End Function

    Public Sub Remove(ByVal pDrug As Drug)
        Try
            List.Remove(pDrug)
        Catch ex As Exception
            Throw New Exception(ex.Message & ":MedispanLibrary\DrugsColl.Add(ByVal pDrug As Drug)")
        End Try
    End Sub

    Default Public Property Item(ByVal Index As Integer) As Drug

        Get
            Try
                Return CType(List.Item(Index), Drug)
            Catch ex As Exception
                Throw New Exception(ex.Message & ":MedispanLibrary\DrugsColl.Item(ByVal Index As Integer).Get")
            End Try
        End Get

        Set(ByVal Value As Drug)
            Try
                List.Item(Index) = Value
            Catch ex As Exception
                Throw New Exception(ex.Message & ":MedispanLibrary\DrugsColl.Item(ByVal Index As Integer).Set")
            End Try
        End Set

    End Property

    Public Shadows Function Count() As Integer
        Try
            Return List.Count
        Catch ex As Exception
            Throw New Exception(ex.Message & ":MedispanLibrary\DrugsColl.Add(ByVal pDrug As Drug)")
        End Try
    End Function
End Class







