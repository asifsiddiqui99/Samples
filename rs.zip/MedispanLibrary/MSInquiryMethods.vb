Imports Microsoft.VisualBasic
Imports System.Data
Imports Medispan
Imports System.Data.SqlClient

Public Class MSInquiryMethods


    Public Function GetTreatOpt(ByVal ID As Integer) As DataSet

        Dim MyDataSet As DataSet = New DataSet()
        Dim MCTable As DataTable = New DataTable()
        Dim Column1 As DataColumn, Column2 As DataColumn
        Dim Row As DataRow
        Try
            MCTable = MyDataSet.Tables.Add("MedTreatOpt")
            Column1 = New DataColumn("disp_med", System.Type.GetType("System.String"))
            Column2 = New DataColumn("microorganism", System.Type.GetType("System.String"))
            MCTable.Columns.Add(Column1)
            MCTable.Columns.Add(Column2)
            Dim objMedicalCondition As Dib.MedicalCondition = New Dib.MedicalCondition(ID)
            Dim objINDLookupResults As Dib.INDLookupResults
            objINDLookupResults = objMedicalCondition.GetDrugsToTreat(Dib.DIBDrugNameTypeFilter.DN_TF_ALL, Dib.DIBINDAcceptanceLevelFilter.IND_ALF_ALL, Dib.DIBINDOutcomeFilter.IND_OF_ALL)
            For Each objINDLookUpResult As Dib.INDLookupResult In objINDLookupResults
                Row = MyDataSet.Tables("MedTreatOpt").NewRow()
                Row(0) = objINDLookUpResult.DispensableDrugDescription
                Row(1) = objINDLookUpResult.MicroorganismName
                MyDataSet.Tables("MedTreatOpt").Rows.Add(Row)
            Next
        Catch ex As Exception
            Throw New Exception(ex.Message & ":MedispanLibrary\MSInquiryMethods.GetTreatOpt(ByVal ID As Integer)")
        End Try
        Return MyDataSet
    End Function

    Public Function GetMedInd(ByVal strSearch As String, ByVal SearchType As String) As DataSet
        Dim nav As Dib.Navigation = New Dib.Navigation
        Dim medColl As Dib.MedicalConditions
        Dim MyDataSet As DataSet = New DataSet
        Dim MCTable As DataTable = New DataTable
        Dim Column1 As DataColumn
        Dim Column2 As DataColumn
        Dim Row As DataRow
        Dim ind As Integer = 0
        Dim NumRows As Integer = 0

        Try
            If SearchType.Equals("Simple") Then
                medColl = nav.MedicalConditionsSearch(strSearch, Dib.DIBSearchMethod.DIB_SM_SIMPLE, Dib.DIBPhoneticSearch.DIB_PS_NOPHONETIC, Dib.DIBMedCondNameSearchType.MC_NST_PROFESSIONALONLY, False, False)
            Else
                If SearchType.Equals("Exhaustive") Then
                    medColl = nav.MedicalConditionsSearch(strSearch, Dib.DIBSearchMethod.DIB_SM_EXHAUSTIVE, Dib.DIBPhoneticSearch.DIB_PS_NOPHONETIC, Dib.DIBMedCondNameSearchType.MC_NST_BOTH, False, False)
                Else
                    medColl = nav.MedicalConditionsSearch(strSearch, Dib.DIBSearchMethod.DIB_SM_SIMPLE, Dib.DIBPhoneticSearch.DIB_PS_ONLY, Dib.DIBMedCondNameSearchType.MC_NST_BOTH, False, False)
                End If
            End If
            MCTable = MyDataSet.Tables.Add("MedCond")
            Column1 = New DataColumn("med_id", System.Type.GetType("System.Int64"))
            Column2 = New DataColumn("med_name", System.Type.GetType("System.String"))
            MCTable.Columns.Add(Column1)
            MCTable.Columns.Add(Column2)
            NumRows = medColl.Count
            For Each medcol As Dib.MedicalCondition In medColl
                Row = MyDataSet.Tables("MedCond").NewRow
                Row(0) = medcol.Id
                Row(1) = medcol.NameProfessional
                MyDataSet.Tables("MedCond").Rows.Add(Row)
                System.Math.Min(System.Threading.Interlocked.Increment(ind), ind - 1)
            Next
        Catch ex As Exception
            Throw New Exception(ex.Message & ":MedispanLibrary\MSInquiryMethods.GetMedInd(ByVal strSearch As String, ByVal SearchType As String)")
        End Try
        Return MyDataSet
    End Function

    Public Function GetDispDrugImage(ByVal ID As Integer) As DataSet
        Dim objDispensableDrug As Dib.DispensableDrug
        Dim MyDataSet As DataSet = New DataSet
        Dim DrugTable As DataTable = New DataTable
        Dim Column1 As DataColumn
        Dim Row As DataRow
        Dim LblNum As Integer
        Try
            DrugTable = MyDataSet.Tables.Add("DrugImage")
            Column1 = New DataColumn("drug_image", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(Column1)
            objDispensableDrug = New Dib.DispensableDrug(ID)
            Dim imgName As String = ""
            If objDispensableDrug.HasImages Then
                Dim drgColl As Dib.DispensableLabelers
                Dim drgImgColl As Dib.DispensableImages
                drgColl = objDispensableDrug.GetLabelers
                LblNum = drgColl.Count
                Dim temp As String = ""
                For Each drgcol As Dib.DispensableLabeler In drgColl
                    drgImgColl = drgcol.Images
                    For Each drgImgCol As Dib.DispensableImage In drgImgColl
                        temp = drgImgCol.ImageFileName
                        If imgName.IndexOf(temp) < 0 Then
                            imgName &= drgImgCol.ImageFileName & ":"
                            Row = MyDataSet.Tables("DrugImage").NewRow
                            Row(0) = drgImgCol.ImageFileName
                            MyDataSet.Tables("DrugImage").Rows.Add(Row)
                        End If
                    Next
                Next
            End If
        Catch ex As Exception
            Throw New Exception(ex.Message & ":MedispanLibrary\MSInquiryMethods.GetDispDrugImage(ByVal ID As Integer)")
        End Try
        Return MyDataSet
    End Function

    Public Function GetDispReactDrug(ByVal ID As Integer) As String()
        Dim DDArr(4) As String
        Dim objDispensableDrug As Dib.DispensableDrug
        'Dim objRoutedDrug As Dib.RoutedDrug
        Dim objDILookupResults As Dib.DILookupResults
        Dim drgColl As Dib.DILookupDrugs
        Try
            objDispensableDrug = New Dib.DispensableDrug(ID)
            DDArr(0) = objDispensableDrug.Name
            'Dim objDIBCode As Dib.DIBCode
            objDILookupResults = objDispensableDrug.GetDIInteractions(Dib.DIBDrugNameTypeFilter.DN_TF_ALL, Dib.DIBDISeverityFilter.DI_SF_NONE, Dib.DIBDIDocLevelFilter.DI_DLF_PROBABLE)
            drgColl = objDILookupResults.Item(1).Drugs
            DDArr(1) = drgColl.Item(1).Description
            DDArr(1) = objDILookupResults.Item(1).InteractionId
        Catch ex As Exception
            Throw New Exception(ex.Message & ":MedispanLibrary\MSInquiryMethods.GetDispReactDrug(ByVal ID As Integer)")
        End Try
        Return DDArr
    End Function

    Public Function GetImprintDrug(ByVal ImprintTxt As String, ByVal ColorID As Short, ByVal ShapeID As Short, ByVal FlavorID As String, ByVal FormID As String, ByVal CoatingID As String, ByVal ScoringID As String, ByVal ClarityID As String) As DataSet
        Dim MyDataSet As DataSet = New DataSet
        Dim ITable As DataTable = New DataTable
        Dim Column1 As DataColumn
        Dim Column2 As DataColumn
        Dim Column3 As DataColumn
        Dim Column4 As DataColumn
        Dim Column5 As DataColumn
        Dim Column6 As DataColumn
        Dim Column7 As DataColumn
        Dim Row As DataRow
       
        Dim objDispensableDrug As Dib.DispensableDrug
        Dim objImprintSearchResults As Dib.ImprintSearchResults
        Dim objImprintSearch As Dib.ImprintSearch = New Dib.ImprintSearch()

        Try

            ITable = MyDataSet.Tables.Add("Imprint")
            Column1 = New DataColumn("med_name", System.Type.GetType("System.String"))
            Column2 = New DataColumn("labeler_name", System.Type.GetType("System.String"))
            Column3 = New DataColumn("image_filenm", System.Type.GetType("System.String"))
            Column4 = New DataColumn("start_date", System.Type.GetType("System.String"))
            Column5 = New DataColumn("stop_date", System.Type.GetType("System.String"))
            Column6 = New DataColumn("imprint1", System.Type.GetType("System.String"))
            Column7 = New DataColumn("imprint2", System.Type.GetType("System.String"))
            ITable.Columns.Add(Column1)
            ITable.Columns.Add(Column2)
            ITable.Columns.Add(Column3)
            ITable.Columns.Add(Column4)
            ITable.Columns.Add(Column5)
            ITable.Columns.Add(Column6)
            ITable.Columns.Add(Column7)

            objImprintSearch.SetRepresentativeOnly(True)
            Dim crFlag As Boolean = False

            If ColorID > 0 Then
                objImprintSearch.Colors.AddItem(ColorID)
                crFlag = True
            End If

            If ShapeID > 0 Then
                objImprintSearch.SetShapeId(ShapeID)
                crFlag = True
            End If

            If Not FlavorID.Equals("N/A") Then
                objImprintSearch.SetFlavorCode(FlavorID)
                crFlag = True
            End If

            If Not ScoringID.Equals("N/A") Then
                objImprintSearch.SetScoringCode(ScoringID)
                crFlag = True
            End If

            If Not FormID.Equals("0") Then
                FormID = FixedCode(FormID)
                objImprintSearch.SetFormCode(FormID)
                crFlag = True
            End If

            If Not CoatingID.Equals("N/A") Then
                objImprintSearch.SetCoatingCode(CoatingID)
                crFlag = True
            End If

            If Not ImprintTxt.Trim.Equals("") Then
                objImprintSearch.SetImprintText(ImprintTxt.Trim)
                crFlag = True
            End If

            If Not crFlag Then
                objImprintSearch.SetImprintText("axvbch9*99")
            End If

            Dim nav As Dib.Navigation = New Dib.Navigation
            objImprintSearchResults = nav.ImprintSearch(objImprintSearch, 300)
            Dim timage As String = ""

            For Each objImprintSearchResult As Dib.ImprintSearchResult In objImprintSearchResults
                Row = MyDataSet.Tables("Imprint").NewRow
                Row(0) = objImprintSearchResult.Description
                Row(1) = objImprintSearchResult.LabelerName
                timage = objImprintSearchResult.ImageFileName
                If Not timage.Equals("") Then
                    Row(2) = "<a href='../../Images/DrugImages/" & timage & ".jpg' target='_blank'><img src=../images/gridimg.gif border=0 alt='View Image'></a>"
                Else
                    Row(2) = ""
                End If
                timage = objImprintSearchResult.Imprint.EffectiveDate
                If Not timage.Equals("") Then
                    Row(3) = timage.Substring(4, 2) & "/" & timage.Substring(6, 2) & "/" & timage.Substring(0, 4)
                Else
                    Row(3) = ""
                End If
                objDispensableDrug = New Dib.DispensableDrug(objImprintSearchResult.DispensableDrugId)
                timage = objDispensableDrug.ObsoleteDate
                If Not timage.Equals("") Then
                    Row(4) = timage.Substring(4, 2) & "/" & timage.Substring(6, 2) & "/" & timage.Substring(0, 4)
                Else
                    Row(4) = ""
                End If
                Row(5) = objImprintSearchResult.Imprint.Imprint1
                Row(6) = objImprintSearchResult.Imprint.Imprint2
                timage = objImprintSearchResult.Imprint.ClarityCode
                If Not ClarityID.Equals("N/A") Then
                    If timage.Equals(ClarityID) Then
                        MyDataSet.Tables("Imprint").Rows.Add(Row)
                    End If
                Else
                    MyDataSet.Tables("Imprint").Rows.Add(Row)
                End If
            Next
        Catch ex As Exception
            Throw New Exception(ex.Message & ":MedispanLibrary\MSInquiryMethods.GetImprintDrug(ByVal ImprintTxt As String, ByVal ColorID As Short, ByVal ShapeID As Short, ByVal FlavorID As String, ByVal FormID As String, ByVal CoatingID As String, ByVal ScoringID As String, ByVal ClarityID As String)")
        End Try
        Return MyDataSet
    End Function

    Private Function FixedCode(ByVal code As String) As String
        Dim i As Integer
        Try
            If code.Length < 4 Then
                i = 1
                While i <= (4 - code.Length)
                    code = "0" & code
                    System.Math.Min(System.Threading.Interlocked.Increment(i), i - 1)
                End While
            End If
        Catch ex As Exception
            Throw New Exception(ex.Message & ":MedispanLibrary\MSInquiryMethods.FixedCode(ByVal code As String)")
        End Try
        Return code
    End Function

    Public Function GetAdvEffect(ByVal ID As Integer) As DataSet
        Dim MyDataSet As DataSet = New DataSet
        Dim MCTable As DataTable = New DataTable
        Dim Column1 As DataColumn
        Dim Column2 As DataColumn
        Dim Row As DataRow
        Try
            MCTable = MyDataSet.Tables.Add("AdvEffect")
            Column1 = New DataColumn("effect_id", System.Type.GetType("System.String"))
            Column2 = New DataColumn("effect", System.Type.GetType("System.String"))
            MCTable.Columns.Add(Column1)
            MCTable.Columns.Add(Column2)
            Dim objDispensableDrug As Dib.DispensableDrug
            objDispensableDrug = New Dib.DispensableDrug(ID)
            Dim objADELookupResults As Dib.ADELookupResults
            objADELookupResults = objDispensableDrug.GetAdverseEffects(Dib.DIBADESeverityFilter.ADE_SF_MODERATE, Dib.DIBADEIncidenceFilter.ADE_IF_COMMON, Dib.DIBADEDocLevelFilter.ADE_DLF_PROBABLE)
            Dim NumRows As Integer = objADELookupResults.Count
            For Each objADELookupResult As Dib.ADELookupResult In objADELookupResults
                Row = MyDataSet.Tables("AdvEffect").NewRow
                Row(0) = objADELookupResult.MedCondId
                Row(1) = objADELookupResult.MedCondNameProf
                MyDataSet.Tables("AdvEffect").Rows.Add(Row)
            Next
        Catch ex As Exception
            Throw New Exception(ex.Message & ":MedispanLibrary\MSInquiryMethods.GetAdvEffect(ByVal ID As Integer)")
        End Try
        Return MyDataSet
    End Function
End Class
