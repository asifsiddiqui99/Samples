Imports Microsoft.VisualBasic
Imports Medispan
Imports System.Data.SqlClient
Imports ElixirLibrary
Imports System.Data

Public Class MSScreeningMethods


#Region "Fields"
    Private mConnection As Connection
    Private mConnectionString
#End Region

#Region "Property"
    Public ReadOnly Property Connection() As ElixirLibrary.Connection
        Get
            Return mConnection
        End Get
    End Property

    Public ReadOnly Property ConnectionString() As String
        Get
            Return mConnectionString
        End Get
    End Property
#End Region

#Region "Constructor"
    ''' <summary>
    ''' Creates new Conection Object based on Given Connection String 
    ''' </summary>
    ''' <param name="pConnectionString">
    ''' Contains Connection String 
    ''' </param>
    ''' <remarks>
    ''' Use when not using transaction
    ''' Must Specify Connection String other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnectionString As String)
        If pConnectionString = "" Then
            Throw New ArgumentException("ConnectionString can not be empty")
        End If

        mConnectionString = pConnectionString
        mConnection = New Connection(mConnectionString)

    End Sub

    ''' <summary>
    ''' Assign given connection to the current Object
    ''' </summary>
    ''' <param name="pConnection">
    ''' Contains refrence to the connection object
    ''' </param>
    ''' <remarks>
    ''' Use when  using Transaction
    ''' Must Specify Connection other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnection As Connection)
        If pConnection Is Nothing Then
            Throw New ArgumentException("Connection can not be empty")
        End If

        mConnection = pConnection
    End Sub
#End Region

    Public Function getPAR(ByVal DispDrugID As Integer, ByVal PatId As String) As String()
        Dim lQuery As String
        Dim lDs As DataSet
        Dim objDispDrug As Dib.DispensableDrug
        Dim PARArr(10) As String
        Dim colScreenAllergies As Dib.ScreenAllergies = New Dib.ScreenAllergies
        Dim objScreenDrug As Dib.ScreenDrug
        Dim colScreenDrugs As Dib.ScreenDrugs = New Dib.ScreenDrugs
        Dim objScreening As Dib.Screening = New Dib.Screening
        Dim colPARScreenResults As Dib.PARScreenResults
        Dim AllgDrugID As Integer = 0

        Try
            objDispDrug = New Dib.DispensableDrug(DispDrugID)
            objScreenDrug = New Dib.ScreenDrug(objDispDrug.Id.ToString, Dib.DIBDrugType.DT_DISPENSABLEDRUG)
            objScreenDrug.Description = objDispDrug.Description
            objScreenDrug.IsProspective = True
            colScreenDrugs.AddItem(objScreenDrug)


            lQuery = "SELECT distinct DrugId,AllergyName " _
                  & "FROM PatientAllergy " _
                  & "WHERE PatientID = " & PatId & " "
           

            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If

            If lDs.Tables.Count > 0 Then
                For Each lDr As DataRow In lDs.Tables(0).Rows
                    Dim objScreenAllergy As Dib.ScreenAllergy
                    Dim objDrugName As Dib.DrugName
                    AllgDrugID = Convert.ToInt32(lDr.Item(0).ToString())
                    objDrugName = New Dib.DrugName(AllgDrugID)
                    objScreenAllergy = New Dib.ScreenAllergy(objDrugName.Id.ToString, Dib.DIBAllergyType.AT_DRUGNAME)
                    objScreenAllergy.Description = objDrugName.Description
                    objScreenAllergy.CustomId = lDr.Item(1).ToString()
                    objScreenAllergy.IsProspective = False
                    colScreenAllergies.AddItem(objScreenAllergy)
                Next
            End If
            colPARScreenResults = objScreening.PARScreen(colScreenDrugs, colScreenAllergies, False)
            PARArr(0) = colPARScreenResults.Count
            If colPARScreenResults.Count > 0 Then
                Dim ind As Integer = 0
                For Each colPARScreenResult As Dib.PARScreenResult In colPARScreenResults
                    PARArr(0) = colPARScreenResults.Item(ind).AllergyDescription
                    PARArr(0) = colPARScreenResults.Item(ind).AllergyDescription
                    PARArr(1) = colPARScreenResults.Item(ind).DrugDescription
                    PARArr(2) = "<b>Interaction Class: </b>" & colPARScreenResults.Item(ind).AllergyClassDesc
                    PARArr(3) = "<b>Interaction Class: </b>" & colPARScreenResults.Item(ind).DrugClassDesc
                    PARArr(4) = colPARScreenResults.Item(ind).Ingredients
                    PARArr(4) = PARArr(4).Trim
                    If Not PARArr(4).Equals("") Then
                        PARArr(4) = "<br><b>Ingridients: </b>" & PARArr(4)
                    End If
                    PARArr(5) = colPARScreenResults.Item(ind).AllergyCustomId
                    Dim MgId As String = colPARScreenResults.Item(ind).MonographId
                    Dim objMonograph As Dib.Monograph
                    Try
                        objMonograph = New Dib.PARMonograph("MMW-PE", MgId)
                        Dim s As Integer = 2
                        While s < objMonograph.Sections.Count
                            Dim l As Integer = 0
                            While l < objMonograph.Sections.Item(s).Lines.Count
                                PARArr(s + 3) &= " " & objMonograph.Sections.Item(s).Lines.Item(l).Text
                                System.Math.Min(System.Threading.Interlocked.Increment(l), l - 1)
                            End While
                            Dim k As Integer = PARArr(s + 3).IndexOf(":", 0)
                            PARArr(s + 3) = PARArr(s + 3).ToString.Substring(k + 2)
                            System.Math.Min(System.Threading.Interlocked.Increment(s), s - 1)
                        End While
                    Catch e As Exception
                        PARArr(6) = ""
                        PARArr(7) = ""
                    End Try
                Next
            Else
                PARArr(0) = "success"
            End If
        Catch ex As Exception
            PARArr(0) = "Success"
            TraceLogging.ErrorLogMethods.LogError(ex, "MedispanLibrary\MSScreeningMethods.getPAR(ByVal DispDrugID As Integer, ByVal PatId As String) ")
        Finally
        End Try

        Return PARArr
    End Function

    Public Function getDFA(ByVal DispDrugID As Integer) As String()
        Dim objDispDrug As Dib.DispensableDrug
        Dim objScreenDrug As Dib.ScreenDrug
        Dim colScreenDrugs As Dib.ScreenDrugs = New Dib.ScreenDrugs
        Dim objScreening As Dib.Screening = New Dib.Screening
        Dim colDFAScreenResults As Dib.DFAScreenResults
        Dim objDIBCode As Dib.DIBCode
        Dim DFAArr(20) As String

        Try
            objDispDrug = New Dib.DispensableDrug(DispDrugID)
            objScreenDrug = New Dib.ScreenDrug(objDispDrug.Id.ToString, Dib.DIBDrugType.DT_DISPENSABLEDRUG)
            objScreenDrug.Description = objDispDrug.Name
            objScreenDrug.IsProspective = True
            colScreenDrugs.AddItem(objScreenDrug)
            colDFAScreenResults = objScreening.DFAScreen(colScreenDrugs, True, Dib.DIBDISeverityFilter.DI_SF_NONE, Dib.DIBDIDocLevelFilter.DI_DLF_ESTABLISHED, Dib.DIBDFAInteractionType.DFA_IT_BOTH)

            If colDFAScreenResults.Count > 0 Then
                For Each colDFAScreenResult As Dib.DFAScreenResult In colDFAScreenResults
                    Dim mgid As String = colDFAScreenResult.MonographId
                    DFAArr(0) = colDFAScreenResult.FoodClassDesc
                    DFAArr(1) = colDFAScreenResult.DrugClassDesc
                    objDIBCode = New Dib.DIBCode(9, colDFAScreenResult.OnsetCode)
                    DFAArr(2) = objDIBCode.Description
                    objDIBCode = New Dib.DIBCode(10, colDFAScreenResult.SeverityCode)
                    DFAArr(3) = objDIBCode.Description
                    objDIBCode = New Dib.DIBCode(11, colDFAScreenResult.DocLevelCode)
                    DFAArr(4) = objDIBCode.Description
                    Dim objMonograph As Dib.DFAMonograph
                    objMonograph = New Dib.DFAMonograph("MMW-PE", mgid, objDispDrug.Name)
                    Dim s As Integer = 2
                    While s < objMonograph.Sections.Count
                        Dim l As Integer = 0
                        While l < objMonograph.Sections.Item(s).Lines.Count
                            DFAArr(s + 2) &= " " & objMonograph.Sections.Item(s).Lines.Item(l).Text
                            System.Math.Min(System.Threading.Interlocked.Increment(l), l - 1)
                        End While
                        Dim k As Integer = DFAArr(s + 2).IndexOf(":", 0)
                        DFAArr(s + 2) = DFAArr(s + 2).ToString.Substring(k + 2)
                        System.Math.Min(System.Threading.Interlocked.Increment(s), s - 1)
                    End While
                Next
            Else
                DFAArr(0) = "success"
            End If
            

        Catch ex As Exception
            DFAArr(0) = "Success"
            TraceLogging.ErrorLogMethods.LogError(ex, "MedispanLibrary\MSScreeningMethods.getDFA(ByVal DispDrugID As Integer)")
        End Try

        Return DFAArr

    End Function

    Public Function getDCheck(ByVal DispDrugID As Integer, ByVal agedays As String, ByVal take As Double, ByVal frequency As Double, ByVal duration As Integer) As String()
        Dim DCArr(9) As String
        Dim objDispDrug As Dib.DispensableDrug
        Dim objScreenDrug As Dib.ScreenDrug
        Dim colScreenDrugs As Dib.ScreenDrugs = New Dib.ScreenDrugs
        Dim objScreening As Dib.Screening = New Dib.Screening
        Dim colDCScreenResults As Dib.DCScreenResults

        Try
            objDispDrug = New Dib.DispensableDrug(DispDrugID)
            objScreenDrug = New Dib.ScreenDrug(objDispDrug.Id.ToString, Dib.DIBDrugType.DT_DISPENSABLEDRUG)
            objScreenDrug.SetDose(CType(take, Double), frequency, duration)
            objScreenDrug.IsProspective = True
            colScreenDrugs.AddItem(objScreenDrug)
            colDCScreenResults = objScreening.DCScreen(colScreenDrugs, True, agedays)

            If colDCScreenResults.Count > 0 Then
                If Not (colDCScreenResults.Item(0).DailyDoseMessage = "") OrElse Not (colDCScreenResults.Item(0).DurationMessage = "") OrElse Not (colDCScreenResults.Item(0).SingleDoseMessage = "") Then
                    For Each colDCScreenResult As Dib.DCScreenResult In colDCScreenResults
                        DCArr(0) = colDCScreenResult.DailyDoseComment
                        DCArr(1) = colDCScreenResult.DailyDoseMessage
                        DCArr(2) = colDCScreenResult.DurationMessage
                        DCArr(3) = colDCScreenResult.SingleDoseComment
                        DCArr(4) = colDCScreenResult.SingleDoseMessage
                        DCArr(8) = ""

                        DCArr(5) = ""
                        DCArr(6) = ""
                        DCArr(7) = ""

                    Next
                Else
                    DCArr(8) = "success"
                End If
            Else
                DCArr(8) = "success"
            End If

        Catch ex As Exception
            DCArr(8) = "Success"
            TraceLogging.ErrorLogMethods.LogError(ex, "MedispanLibrary\MSScreeningMethods.getDCheck(ByVal DispDrugID As Integer, ByVal agedays As String, ByVal take As Double, ByVal frequency As Double, ByVal duration As Integer) ")
        End Try
        Return DCArr
    End Function

    Public Function getDTherapy(ByVal DispDrugID As Integer, ByVal PatId As String, ByVal start_dt As String) As String()
        Dim lQuery As String
        Dim lDs As DataSet

        Dim DTArr(5) As String
        Dim objDispDrug As Dib.DispensableDrug
        Dim objScreenDrug As Dib.ScreenDrug
        Dim colScreenDrugs As Dib.ScreenDrugs = New Dib.ScreenDrugs
        Dim objScreening As Dib.Screening = New Dib.Screening
        Dim colDTScreenResults As Dib.DTScreenResults
        Dim objDIBCode As Dib.DIBCode
        Dim DispDrgDesc As String

        Try
            objDispDrug = New Dib.DispensableDrug(DispDrugID)
            objScreenDrug = New Dib.ScreenDrug(objDispDrug.Id.ToString, Dib.DIBDrugType.DT_DISPENSABLEDRUG)
            DispDrgDesc = objDispDrug.Name
            objScreenDrug.Description = DispDrgDesc
            objScreenDrug.CustomId = start_dt
            objScreenDrug.IsProspective = True
            colScreenDrugs.AddItem(objScreenDrug)

            'AND DDID = " & DispDrugID 
            'Removed on fareed request

            lQuery = "SELECT DDID, DrugName, Take, TakeForm, FrequencyNumber, " _
                   & "convert(varchar(10),StartDate,101) as StartDate " _
                   & "FROM RxList " _
                   & "WHERE  PatientID = " & PatId & " " _
                   & " " _
                   & "AND ISDiscard = 'N' " _
                   & " union all " _
                   & " Select DDID,DrugName,Quantity,'','',LastFill As StartDate " _
                   & " from MedicationHistory Where PatientID=" & PatId & " And DDID <> 'Not Found' " _
                   & " Order by StartDate desc "


            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If
            For Each lDr As DataRow In lDs.Tables(0).Rows
                Dim objScreenDrug2 As Dib.ScreenDrug
                objScreenDrug2 = New Dib.ScreenDrug(lDr.Item(0).ToString(), Dib.DIBDrugType.DT_DISPENSABLEDRUG)
                objScreenDrug2.Description = lDr.Item(1).ToString() & " (" & lDr.Item(2).ToString() & " " & lDr.Item(3).ToString() & ")"
                objScreenDrug2.CustomId = lDr.Item(5).ToString()
                objScreenDrug2.IsProspective = False
                colScreenDrugs.AddItem(objScreenDrug2)
            Next

            colDTScreenResults = objScreening.DTScreen(colScreenDrugs, True, False, False)
            If colDTScreenResults.Count > 0 Then
                Dim [stop] As Boolean = False
                Dim temp As String
                For Each colDTScreenResult As Dib.DTScreenResult In colDTScreenResults
                    DTArr(0) = colDTScreenResult.ClassDescription
                    Dim colDTScreenDrugItem As Dib.DTScreenDrugItems = New Dib.DTScreenDrugItems
                    colDTScreenDrugItem = colDTScreenResult.DrugItems
                    DTArr(2) = ""
                    temp = ""
                    Dim d As Integer = 0
                    While d < colDTScreenDrugItem.Count
                        temp = colDTScreenDrugItem.Item(d).DrugDescription.ToString
                        DTArr(1) &= "<nobr>" & temp & "</nobr>:"
                        DTArr(2) &= colDTScreenDrugItem.Item(d).DrugCustomId & ":"
                        If Not [stop] Then
                            If DispDrgDesc.Equals(temp) Then
                                [stop] = True
                            End If
                        End If
                        System.Math.Min(System.Threading.Interlocked.Increment(d), d - 1)
                    End While
                    DTArr(3) = colDTScreenResult.Allowance.ToString
                    objDIBCode = New Dib.DIBCode(45, colDTScreenResult.PotentialAbuse)
                    DTArr(4) = objDIBCode.Description
                    If [stop] Then
                    End If
                Next
            Else
                DTArr(0) = "success"
            End If
        Catch ex As Exception
            DTArr(0) = "Success"
            TraceLogging.ErrorLogMethods.LogError(ex, "MedispanLibrary\MSScreeningMethods.getDTherapy(ByVal DispDrugID As Integer, ByVal PatId As String, ByVal start_dt As String) ")
        Finally
        End Try
        Return DTArr
    End Function

    Public Function getDI(ByVal DispDrugID As Integer, ByVal PatId As String, ByVal start_dt As String) As String()
        Dim lQuery As String
        Dim lDs As DataSet

        Dim objDispDrug As Dib.DispensableDrug
        Dim objScreenDrug As Dib.ScreenDrug
        Dim colScreenDrugs As Dib.ScreenDrugs = New Dib.ScreenDrugs
        Dim objScreening As Dib.Screening = New Dib.Screening
        Dim colDIScreenResults As Dib.DIScreenResults
        Dim objDIBCode As Dib.DIBCode
        Dim DIArr(14) As String

        Try
            objDispDrug = New Dib.DispensableDrug(DispDrugID)
            objScreenDrug = New Dib.ScreenDrug(objDispDrug.Id.ToString, Dib.DIBDrugType.DT_DISPENSABLEDRUG)
            objScreenDrug.Description = objDispDrug.Description
            objScreenDrug.CustomId = start_dt
            objScreenDrug.IsProspective = True
            colScreenDrugs.AddItem(objScreenDrug)

            'lQuery = "SELECT DDID, DrugName,Route, TakeForm, Size " _
            '       & "FROM RxList WHERE  PatientID = " & PatId & " AND ISDiscard = 'N' " _
            '       & "ORDER BY StartDate DESC "

            lQuery = "SELECT Convert(varchar(100),DDID) As DDID, DrugName,Route, TakeForm, Size, " _
           & "StartDate FROM RxList WHERE  PatientID = " & PatId & " AND ISDiscard = 'N' " _
           & "union all " _
           & "Select DDID,DrugName,'','','',LastFill As StartDate from MedicationHistory where DDID <> 'Not Found'" _
           & "Order by StartDate desc "



            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If
            Dim temp As String
            For Each lDr As DataRow In lDs.Tables(0).Rows
                Dim objScreenDrug2 As Dib.ScreenDrug
                objScreenDrug2 = New Dib.ScreenDrug(lDr.Item(0).ToString(), Dib.DIBDrugType.DT_DISPENSABLEDRUG)
                temp = ""
                Dim t As Integer = 1
                While t < 5
                    temp &= lDr.Item(t).ToString()
                    If Not lDr.Item(t).ToString().Equals("") Then
                        temp &= " "
                    End If
                    System.Math.Min(System.Threading.Interlocked.Increment(t), t - 1)
                End While
                objScreenDrug2.Description = temp
                objScreenDrug2.IsProspective = False
                colScreenDrugs.AddItem(objScreenDrug2)
            Next

            colDIScreenResults = objScreening.DIScreen(colScreenDrugs, True, Dib.DIBDISeverityFilter.DI_SF_MAJOR, Dib.DIBDIDocLevelFilter.DI_DLF_SUSPECTED)
            If colDIScreenResults.Count > 0 Then
                For Each colDIScreenResult As Dib.DIScreenResult In colDIScreenResults
                    Dim mgid As String = colDIScreenResult.MonographId
                    DIArr(0) = colDIScreenResult.Class1Desc
                    DIArr(0) &= "<br><b>Latency Period: </b>" & colDIScreenResult.Class1Duration & " days"
                    DIArr(1) = colDIScreenResult.Class2Desc
                    DIArr(1) &= "<br><b>Latency Period: </b>" & colDIScreenResult.Class2Duration & " days"
                    DIArr(2) = colDIScreenResult.Drug1Description
                    DIArr(3) = colDIScreenResult.Drug2Description
                    objDIBCode = New Dib.DIBCode(9, colDIScreenResult.OnsetCode)
                    DIArr(4) = objDIBCode.Description
                    objDIBCode = New Dib.DIBCode(10, colDIScreenResult.SeverityCode)
                    DIArr(5) = objDIBCode.Description
                    objDIBCode = New Dib.DIBCode(11, colDIScreenResult.DocLevelCode)
                    DIArr(6) = objDIBCode.Description
                    Dim objMonograph As Dib.DIMonograph
                    objMonograph = New Dib.DIMonograph("MMW-PE", mgid, colDIScreenResult.Drug1Description, colDIScreenResult.Drug2Description)
                    Dim s As Integer = 2
                    While s < objMonograph.Sections.Count
                        Dim l As Integer = 0
                        While l < objMonograph.Sections.Item(s).Lines.Count
                            DIArr(s + 4) &= " " & objMonograph.Sections.Item(s).Lines.Item(l).Text
                            System.Math.Min(System.Threading.Interlocked.Increment(l), l - 1)
                        End While
                        Dim k As Integer = DIArr(s + 4).IndexOf(":", 0)
                        DIArr(s + 4) = DIArr(s + 4).ToString.Substring(k + 2)
                        System.Math.Min(System.Threading.Interlocked.Increment(s), s - 1)
                    End While
                Next
            Else
                DIArr(0) = "success"
            End If
        Catch ex As Exception
            DIArr(0) = "Success"
            TraceLogging.ErrorLogMethods.LogError(ex, "MedispanLibrary\MSScreeningMethods.getDI(ByVal DispDrugID As Integer, ByVal PatId As String, ByVal start_dt As String) ")
        Finally
        End Try
        Return DIArr
    End Function
    ''' <summary>
    ''' Just to check any screening alert is available or not for selected Drug
    ''' </summary>
    ''' <param name="DispDrugID"></param>
    ''' <param name="PatId"></param>
    ''' <param name="start_dt"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>

    Public Function AggregateScreening(ByVal DispDrugID As Integer, ByVal PatId As String, ByVal start_dt As String, ByRef pIsDrugAllergy As Boolean, ByRef pIsDrugDrug As Boolean) As Boolean
        Dim lQuery As String
        Dim lDs As DataSet

        Dim objDispDrug As Dib.DispensableDrug
        Dim objScreenDrug As Dib.ScreenDrug
        Dim colScreenDrugs As Dib.ScreenDrugs = New Dib.ScreenDrugs
        Dim colScreenAllergies As Dib.ScreenAllergies = New Dib.ScreenAllergies
        Dim objScreening As Dib.Screening = New Dib.Screening
        Dim colDIScreenResults As Dib.DIScreenResults
        Dim colDTScreenResults As Dib.DTScreenResults
        Dim colDFAScreenResults As Dib.DFAScreenResults
        Dim colPARScreenResults As Dib.PARScreenResults


        '''''''''''################## Prior Adverse Reaction  ##############

        Dim colScreenDrugs2 As Dib.ScreenDrugs = New Dib.ScreenDrugs
        Try
            objDispDrug = New Dib.DispensableDrug(DispDrugID)
            objScreenDrug = New Dib.ScreenDrug(objDispDrug.Id.ToString, Dib.DIBDrugType.DT_DISPENSABLEDRUG)
            objScreenDrug.Description = objDispDrug.Description
            objScreenDrug.IsProspective = True
            colScreenDrugs2.AddItem(objScreenDrug)

            lQuery = "SELECT distinct DrugId,AllergyName " _
                  & "FROM PatientAllergy " _
                  & "WHERE PatientID = " & PatId & " "

            Dim AllgDrugID As Integer = 0

            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If


            If lDs.Tables.Count > 0 Then
                For Each lDr As DataRow In lDs.Tables(0).Rows
                    Dim objScreenAllergy As Dib.ScreenAllergy
                    Dim objDrugName As Dib.DrugName
                    AllgDrugID = Convert.ToInt32(lDr.Item(0).ToString())
                    objDrugName = New Dib.DrugName(AllgDrugID)
                    objScreenAllergy = New Dib.ScreenAllergy(objDrugName.Id.ToString, Dib.DIBAllergyType.AT_DRUGNAME)
                    objScreenAllergy.Description = objDrugName.Description
                    objScreenAllergy.CustomId = lDr.Item(1).ToString()
                    objScreenAllergy.IsProspective = False
                    colScreenAllergies.AddItem(objScreenAllergy)
                Next
            End If
            colPARScreenResults = objScreening.PARScreen(colScreenDrugs2, colScreenAllergies, False)

            If colPARScreenResults.Count > 0 Then
                pIsDrugAllergy = True
                'Return True
            Else
                pIsDrugAllergy = False
                'Return False
            End If
        Catch ex As Exception
            TraceLogging.ErrorLogMethods.LogError(ex, "RxEntry\MedispanLibrary\MSScreeningMethods.AggregateScreening(ByVal DispDrugID As Integer, ByVal PatId As String, ByVal start_dt As String) ")
            'Throw New Exception(ex.Message + " : MedispanLibrary\MSScreeningMethods.AggregateScreening(ByVal DispDrugID As Integer, ByVal PatId As String, ByVal start_dt As String) ")
        Finally
        End Try
        '''''''''''################## Prior Adverse Reaction  ##############

        Try
            objDispDrug = New Dib.DispensableDrug(DispDrugID)
            objScreenDrug = New Dib.ScreenDrug(objDispDrug.Id.ToString, Dib.DIBDrugType.DT_DISPENSABLEDRUG)
            objScreenDrug.Description = objDispDrug.Description
            objScreenDrug.CustomId = start_dt
            objScreenDrug.IsProspective = True
            colScreenDrugs.AddItem(objScreenDrug)

            lQuery = "SELECT DDID, DrugName,Route, TakeForm, Size " _
                   & "FROM RxList WHERE  PatientID = " & PatId & " " _
                   & "AND ISDiscard = 'N' " _
                   & "ORDER BY StartDate DESC "



            If Connection.IsTransactionAlive() Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If
            Dim temp As String
            For Each lDr As DataRow In lDs.Tables(0).Rows
                Dim objScreenDrug2 As Dib.ScreenDrug
                objScreenDrug2 = New Dib.ScreenDrug(lDr.Item(0).ToString(), Dib.DIBDrugType.DT_DISPENSABLEDRUG)
                temp = ""
                Dim t As Integer = 1
                While t < 5
                    temp &= lDr.Item(t).ToString()
                    If Not lDr.Item(t).ToString().Equals("") Then
                        temp &= " "
                    End If
                    System.Math.Min(System.Threading.Interlocked.Increment(t), t - 1)
                End While
                objScreenDrug2.Description = temp
                objScreenDrug2.IsProspective = False
                colScreenDrugs.AddItem(objScreenDrug2)
            Next

            '''''''''''################## Drug Drug Interaction check ##############
            colDIScreenResults = objScreening.DIScreen(colScreenDrugs, True, Dib.DIBDISeverityFilter.DI_SF_MAJOR, Dib.DIBDIDocLevelFilter.DI_DLF_SUSPECTED)

            If colDIScreenResults.Count > 0 Then
                pIsDrugDrug = True
                Return True
            End If
            If pIsDrugAllergy Then
                Return True
            End If
            '''''''''''################## Drug Drug Interaction check ##############

            '''''''''''################## Duplicate Therapy check ##############
            colDTScreenResults = objScreening.DTScreen(colScreenDrugs, True, False, False)

            If colDTScreenResults.Count > 0 Then
                Return True
            End If
            '''''''''''################## Duplicate Therapy check ##############

            '''''''''''################## Drug Food ##############
            colDFAScreenResults = objScreening.DFAScreen(colScreenDrugs, True, Dib.DIBDISeverityFilter.DI_SF_NONE, Dib.DIBDIDocLevelFilter.DI_DLF_ESTABLISHED, Dib.DIBDFAInteractionType.DFA_IT_BOTH)

            If colDFAScreenResults.Count > 0 Then
                Return True
            End If
            '''''''''''################## Drug Food ##############
        Catch ex As Exception
            TraceLogging.ErrorLogMethods.LogError(ex, "RxEntry\MedispanLibrary\MSScreeningMethods.AggregateScreening(ByVal DispDrugID As Integer, ByVal PatId As String, ByVal start_dt As String) ")
            'Throw New Exception(ex.Message + " : MedispanLibrary\MSScreeningMethods.AggregateScreening(ByVal DispDrugID As Integer, ByVal PatId As String, ByVal start_dt As String) ")
        Finally
        End Try



    End Function

End Class
