Public Class RefillRequestMessages
    
End Class
