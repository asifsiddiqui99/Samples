Namespace SureScripts.Admin


    Public Class AdminElementType

    End Class

    Public Class AdminMessageType
        Private mHeader As New HeaderType
        Private mBody As New BodyType

        Public Property Header() As HeaderType
            Get
                Return mHeader
            End Get
            Set(ByVal Value As HeaderType)
                mHeader = Value
            End Set
        End Property

        Public Property Body() As BodyType
            Get
                Return mBody
            End Get
            Set(ByVal Value As BodyType)
                mBody = Value
            End Set
        End Property
    End Class

    Public Class HeaderType
        Private mHeader As New SureScripts.HeaderType
        Private mAuthenticationType As New AuthenticationType
        Public Property Header() As SureScripts.HeaderType
            Get
                Return mHeader
            End Get
            Set(ByVal Value As SureScripts.HeaderType)
                mHeader = Value
            End Set
        End Property

        Public Property Authentication() As AuthenticationType
            Get
                Return mAuthenticationType
            End Get
            Set(ByVal Value As AuthenticationType)
                mAuthenticationType = Value
            End Set
        End Property
    End Class




    Public Class BodyType
        Private mStatus As New StatusType
        Private mError As New ErrorType
        Private mDirectoryDownloadFullPharmacy As DirectoryDownloadFullPharmacyType = New DirectoryDownloadFullPharmacyType
        Private mDirectoryDownloadNightlyPharmacy As DirectoryDownloadNightlyPharmacyType = New DirectoryDownloadNightlyPharmacyType
        Private mDirectoryDownloadFullPharmacyURL As DirectoryDownloadFullPharmacyURLType = New DirectoryDownloadFullPharmacyURLType
        Private mDirectoryDownloadNightlyPharmacyURL As DirectoryDownloadNightlyPharmacyURLType = New DirectoryDownloadNightlyPharmacyURLType
        Private mAddPrescriber As New AddPrescriberType
        Private mAddPrescriberResponse As New AddPrescriberResponseType
        Private mAddPrescriberLocation As New AddPrescriberLocationType
        Private mAddPrescriberLocationResponse As New AddPrescriberLocationResponseType
        Private mUpdatePrescriberLocation As New UpdatePrescriberLocationType

        Public Property Status() As StatusType
            Get
                Return mStatus
            End Get
            Set(ByVal Value As StatusType)
                mStatus = Value
            End Set
        End Property

        Public Property [Error]() As ErrorType
            Get
                Return mError
            End Get
            Set(ByVal Value As ErrorType)
                mError = Value
            End Set
        End Property

        Public Property DirectoryDownloadFullPharmacy() As DirectoryDownloadFullPharmacyType
            Get
                Return mDirectoryDownloadFullPharmacy
            End Get
            Set(ByVal Value As DirectoryDownloadFullPharmacyType)
                mDirectoryDownloadFullPharmacy = Value
            End Set
        End Property

        Public Property DirectoryDownloadNightlyPharmacy() As DirectoryDownloadNightlyPharmacyType
            Get
                Return mDirectoryDownloadNightlyPharmacy
            End Get
            Set(ByVal Value As DirectoryDownloadNightlyPharmacyType)
                mDirectoryDownloadNightlyPharmacy = Value
            End Set
        End Property

        Public Property DirectoryDownloadFullPharmacyURL() As DirectoryDownloadFullPharmacyURLType
            Get
                Return mDirectoryDownloadFullPharmacyURL
            End Get
            Set(ByVal Value As DirectoryDownloadFullPharmacyURLType)
                mDirectoryDownloadFullPharmacyURL = Value
            End Set
        End Property

        Public Property DirectoryDownloadNightlyPharmacyURL() As DirectoryDownloadNightlyPharmacyURLType
            Get
                Return mDirectoryDownloadNightlyPharmacyURL
            End Get
            Set(ByVal Value As DirectoryDownloadNightlyPharmacyURLType)
                mDirectoryDownloadNightlyPharmacyURL = Value
            End Set
        End Property

        Public Property AddPrescriber() As AddPrescriberType
            Get
                Return mAddPrescriber
            End Get
            Set(ByVal Value As AddPrescriberType)
                mAddPrescriber = Value
            End Set
        End Property

        Public Property AddPrescriberResponse() As AddPrescriberResponseType
            Get
                Return mAddPrescriberResponse
            End Get
            Set(ByVal Value As AddPrescriberResponseType)
                mAddPrescriberResponse = Value
            End Set
        End Property

        Public Property AddPrescriberLocation() As AddPrescriberLocationType
            Get
                Return mAddPrescriberLocation
            End Get
            Set(ByVal Value As AddPrescriberLocationType)
                mAddPrescriberLocation = Value
            End Set
        End Property

        Public Property AddPrescriberLocationResponse() As AddPrescriberLocationResponseType
            Get
                Return mAddPrescriberLocationResponse
            End Get
            Set(ByVal Value As AddPrescriberLocationResponseType)
                mAddPrescriberLocationResponse = Value
            End Set
        End Property

        Public Property UpdatePrescriberLocation() As UpdatePrescriberLocationType
            Get
                Return mUpdatePrescriberLocation
            End Get
            Set(ByVal Value As UpdatePrescriberLocationType)
                mUpdatePrescriberLocation = Value
            End Set
        End Property
    End Class


    Public Class DirectoryDownloadFullPharmacyType
        Private mPartnerAccountID As String = "157"
        Private mVersionID As String = "3"

        Public Property PartnerAccountID() As String
            Get
                Return mPartnerAccountID
            End Get
            Set(ByVal Value As String)
                mPartnerAccountID = Value
            End Set
        End Property

        Public Property VersionID() As String
            Get
                Return mVersionID
            End Get
            Set(ByVal Value As String)
                mVersionID = Value
            End Set
        End Property
    End Class

    Public Class DirectoryDownloadNightlyPharmacyType
        Private mPartnerAccountID As String = "157"
        Private mReportDate As New DateType
        Private mVersionID As String = "3"

        Public Property PartnerAccountID() As String
            Get
                Return mPartnerAccountID
            End Get
            Set(ByVal Value As String)
                mPartnerAccountID = Value
            End Set
        End Property

        Public Property ReportDate() As DateType
            Get
                Return mReportDate
            End Get
            Set(ByVal Value As DateType)
                mReportDate = Value
            End Set
        End Property

        Public Property VersionID() As String
            Get
                Return mVersionID
            End Get
            Set(ByVal Value As String)
                mVersionID = Value
            End Set
        End Property
    End Class

    Public Class DirectoryDownloadFullPharmacyURLType
        Private mPartnerAccountID As String = "157"
        Private mVersionID As String = "3"

        Public Property PartnerAccountID() As String
            Get
                Return mPartnerAccountID
            End Get
            Set(ByVal Value As String)
                mPartnerAccountID = Value
            End Set
        End Property

        Public Property VersionID() As String
            Get
                Return mVersionID
            End Get
            Set(ByVal Value As String)
                mVersionID = Value
            End Set
        End Property
    End Class

    Public Class DirectoryDownloadNightlyPharmacyURLType
        Private mPartnerAccountID As String = "157"
        Private mReportDate As New DateType
        Private mVersionID As String = "3"

        Public Property PartnerAccountID() As String
            Get
                Return mPartnerAccountID
            End Get
            Set(ByVal Value As String)
                mPartnerAccountID = Value
            End Set
        End Property

        Public Property ReportDate() As DateType
            Get
                Return mReportDate
            End Get
            Set(ByVal Value As DateType)
                mReportDate = Value
            End Set
        End Property

        Public Property VersionID() As String
            Get
                Return mVersionID
            End Get
            Set(ByVal Value As String)
                mVersionID = Value
            End Set
        End Property
    End Class

    Public Class DirectoryDownloadURLResponseType

        Private mURL As String = ""

        Public Property URL() As String
            Get
                Return mURL
            End Get
            Set(ByVal Value As String)
                mURL = Value
            End Set
        End Property
    End Class

    Public Class AddPrescriberType
        Private mDirectoryInformation As New DirectoryInformationType
        Private mPrescriber As New PrescriberType
        Public Property DirectoryInformation() As DirectoryInformationType
            Get
                Return mDirectoryInformation
            End Get
            Set(ByVal Value As DirectoryInformationType)
                mDirectoryInformation = Value
            End Set
        End Property
        Public Property Prescriber() As PrescriberType
            Get
                Return mPrescriber
            End Get
            Set(ByVal Value As PrescriberType)
                mPrescriber = Value
            End Set
        End Property
    End Class

    Public Class AddPrescriberResponseType
        Private mDirectoryInformation As New DirectoryInformationType
        Private mPrescriber As New PrescriberType
        Public Property DirectoryInformation() As DirectoryInformationType
            Get
                Return mDirectoryInformation
            End Get
            Set(ByVal Value As DirectoryInformationType)
                mDirectoryInformation = Value
            End Set
        End Property
        Public Property Prescriber() As PrescriberType
            Get
                Return mPrescriber
            End Get
            Set(ByVal Value As PrescriberType)
                mPrescriber = Value
            End Set
        End Property
    End Class

    Public Class AddPrescriberLocationType
        Private mDirectoryInformation As New DirectoryInformationType
        Private mPrescriber As New PrescriberType
        Public Property DirectoryInformation() As DirectoryInformationType
            Get
                Return mDirectoryInformation
            End Get
            Set(ByVal Value As DirectoryInformationType)
                mDirectoryInformation = Value
            End Set
        End Property
        Public Property Prescriber() As PrescriberType
            Get
                Return mPrescriber
            End Get
            Set(ByVal Value As PrescriberType)
                mPrescriber = Value
            End Set
        End Property
    End Class

    Public Class AddPrescriberLocationResponseType
        Private mDirectoryInformation As New DirectoryInformationType
        Private mPrescriber As New PrescriberType
        Public Property DirectoryInformation() As DirectoryInformationType
            Get
                Return mDirectoryInformation
            End Get
            Set(ByVal Value As DirectoryInformationType)
                mDirectoryInformation = Value
            End Set
        End Property
        Public Property Prescriber() As PrescriberType
            Get
                Return mPrescriber
            End Get
            Set(ByVal Value As PrescriberType)
                mPrescriber = Value
            End Set
        End Property
    End Class

    Public Class UpdatePrescriberLocationType
        Private mDirectoryInformation As New DirectoryInformationType
        Private mPrescriber As New PrescriberType
        Public Property DirectoryInformation() As DirectoryInformationType
            Get
                Return mDirectoryInformation
            End Get
            Set(ByVal Value As DirectoryInformationType)
                mDirectoryInformation = Value
            End Set
        End Property
        Public Property Prescriber() As PrescriberType
            Get
                Return mPrescriber
            End Get
            Set(ByVal Value As PrescriberType)
                mPrescriber = Value
            End Set
        End Property
    End Class


    Public Class DirectoryInformationType
        Private mPortalID As String = ""
        Private mAccountID As String = ""
        Private mServiceLevelCode As String = ""
        Private mActiveStartTime As UtcDateType = New UtcDateType
        Private mActiveEndTime As UtcDateType = New UtcDateType

        Public Property PortalID() As String
            Get
                Return mPortalID
            End Get
            Set(ByVal Value As String)
                mPortalID = Value
            End Set
        End Property

        Public Property AccountID() As String
            Get
                Return mAccountID
            End Get
            Set(ByVal Value As String)
                mAccountID = Value
            End Set
        End Property

        Public Property ServiceLevelCode() As String
            Get
                Return mServiceLevelCode
            End Get
            Set(ByVal Value As String)
                mServiceLevelCode = Value
            End Set
        End Property
        Public Property ActiveStartTime() As UtcDateType
            Get
                Return mActiveStartTime
            End Get
            Set(ByVal Value As UtcDateType)
                mActiveStartTime = Value
            End Set
        End Property
        Public Property ActiveEndTime() As UtcDateType
            Get
                Return mActiveEndTime
            End Get
            Set(ByVal Value As UtcDateType)
                mActiveEndTime = Value
            End Set
        End Property
    End Class

    Public Class PrescriberType
        Private mPrescriber As New SureScripts.PrescriberType
        Private mDEAAuthorizingName As String = ""

        Public Property Prescriber() As SureScripts.PrescriberType
            Get
                Return mPrescriber
            End Get
            Set(ByVal Value As SureScripts.PrescriberType)
                mPrescriber = Value
            End Set
        End Property
        Public Property DEAAuthorizingName() As String
            Get
                Return mDEAAuthorizingName
            End Get
            Set(ByVal Value As String)
                mDEAAuthorizingName = Value
            End Set
        End Property
    End Class

    Public Class AuthenticationType
        Private mLoginID As String = ""
        Private mPassword As String = ""

        Public Property LoginID() As String
            Get
                Return mLoginID
            End Get
            Set(ByVal Value As String)
                mLoginID = Value
            End Set
        End Property

        Public Property Password() As String
            Get
                Return mPassword
            End Get
            Set(ByVal Value As String)
                mPassword = Value
            End Set
        End Property
    End Class

End Namespace