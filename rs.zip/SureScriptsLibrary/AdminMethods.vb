Imports System.IO
Imports System.Text
Imports System.Xml
Namespace SureScripts.Admin
    Public Class AdminMethods

        Public Function WriteXMLForAddPrescriber(ByVal path As String, ByVal filename As String, ByVal adminmessage As AdminMessageType)
            Dim xmlw As XmlTextWriter
            Dim lResult As Boolean
            Try


                Dim di As DirectoryInfo
                di = New DirectoryInfo(path)
                If Not di.Exists Then
                    di.Create()
                End If

                xmlw = New XmlTextWriter(path & "\\" & filename, Nothing)
                xmlw.Formatting = Formatting.Indented
                'xmlw.WriteStartDocument()
                xmlw.WriteStartElement("AdminMessage")
                xmlw.WriteAttributeString("version", "1.0")
                xmlw.WriteAttributeString("xmlns", "http://www.surescripts.com/directories")
                '' Header complex type element
                xmlw.WriteStartElement("Header")

                xmlw.WriteStartElement("To")
                xmlw.WriteString("mailto:" & adminmessage.Header.Header.To.MailAddress & "@surescripts.com")
                'xmlw.WriteString(Me.Header.To.MailAddress)
                xmlw.WriteEndElement()

                xmlw.WriteStartElement("From")
                xmlw.WriteString("mailto:" & adminmessage.Header.Header.From.MailAddress & "@surescripts.com")
                'xmlw.WriteString(Me.Header.From.MailAddress)
                xmlw.WriteEndElement()

                xmlw.WriteStartElement("MessageID")
                xmlw.WriteString(adminmessage.Header.Header.MesssageID)
                xmlw.WriteEndElement()

                xmlw.WriteStartElement("SentTime")
                xmlw.WriteString(adminmessage.Header.Header.SentTime.UtcDate)
                xmlw.WriteEndElement()

                'xmlw.WriteStartElement("TestMessage")
                'xmlw.WriteString("")
                'xmlw.WriteEndElement()

                xmlw.WriteStartElement("Authentication")
                xmlw.WriteStartElement("LoginID")
                xmlw.WriteString(adminmessage.Header.Authentication.LoginID)
                xmlw.WriteEndElement()
                xmlw.WriteStartElement("Password")
                xmlw.WriteString(adminmessage.Header.Authentication.Password)
                xmlw.WriteEndElement()
                xmlw.WriteEndElement()

                xmlw.WriteEndElement()
                ''' End Header Complex type
                xmlw.WriteStartElement("Body")
                xmlw.WriteStartElement("AddPrescriber")
                xmlw.WriteStartElement("DirectoryInformation")
                If adminmessage.Body.AddPrescriber.DirectoryInformation.PortalID <> "" Then
                    xmlw.WriteStartElement("PortalID")
                    xmlw.WriteString(adminmessage.Body.AddPrescriber.DirectoryInformation.PortalID)
                    xmlw.WriteEndElement()
                End If
                If adminmessage.Body.AddPrescriber.DirectoryInformation.AccountID <> "" Then
                    xmlw.WriteStartElement("AccountID")
                    xmlw.WriteString(adminmessage.Body.AddPrescriber.DirectoryInformation.AccountID)
                    xmlw.WriteEndElement()
                End If
                If adminmessage.Body.AddPrescriber.DirectoryInformation.ServiceLevelCode <> "" Then
                    xmlw.WriteStartElement("ServiceLevel")
                    xmlw.WriteString(adminmessage.Body.AddPrescriber.DirectoryInformation.ServiceLevelCode)
                    xmlw.WriteEndElement()
                End If
                If adminmessage.Body.AddPrescriber.DirectoryInformation.ActiveStartTime.UtcDate <> "" Then
                    xmlw.WriteStartElement("ActiveStartTime")
                    xmlw.WriteString(adminmessage.Body.AddPrescriber.DirectoryInformation.ActiveStartTime.UtcDate)
                    xmlw.WriteEndElement()
                End If
                If adminmessage.Body.AddPrescriber.DirectoryInformation.ActiveEndTime.UtcDate <> "" Then
                    xmlw.WriteStartElement("ActiveEndTime")
                    xmlw.WriteString(adminmessage.Body.AddPrescriber.DirectoryInformation.ActiveEndTime.UtcDate)
                    xmlw.WriteEndElement()
                End If

                xmlw.WriteEndElement()
                '''End DirectoryInformation complex type
                xmlw.WriteStartElement("Prescriber")
                xmlw.WriteStartElement("Identification")
                If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Identification.SPI <> "" Then
                    ''' SPI simple type
                    xmlw.WriteStartElement("SPI")
                    xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Identification.SPI)
                    xmlw.WriteEndElement()
                    ''' End SPI simple type
                End If
                If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Identification.SocialSecurity <> "" Then
                    ''' SocialSecurity simple type
                    xmlw.WriteStartElement("SocialSecurity")
                    xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Identification.SocialSecurity)
                    xmlw.WriteEndElement()
                    ''' End SocialSecurity simple type
                End If

                If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Identification.DEANumber <> "" Then
                    ''' DEANumber simple type
                    xmlw.WriteStartElement("DEANumber")
                    xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Identification.DEANumber)
                    xmlw.WriteEndElement()
                    ''' End DEANumber simple type
                End If

                If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Identification.MedicaidNumber <> "" Then
                    ''' MedicaidNumber simple type
                    xmlw.WriteStartElement("MedicaidNumber")
                    xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Identification.MedicaidNumber)
                    xmlw.WriteEndElement()
                    ''' End MedicaidNumber simple type
                End If

                If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Identification.MedicareNumber <> "" Then
                    ''' MedicareNumber simple type
                    xmlw.WriteStartElement("MedicareNumber")
                    xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Identification.MedicareNumber)
                    xmlw.WriteEndElement()
                    ''' End MedicareNumber simple type
                End If
                If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Identification.UPIN <> "" Then
                    ''' UPIN simple type
                    xmlw.WriteStartElement("UPIN")
                    xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Identification.UPIN)
                    xmlw.WriteEndElement()
                    ''' End UPIN simple type
                End If


                '''''''''''
                xmlw.WriteEndElement()
                ''' End Identification complex type
                If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.ClinicName <> "" Then
                    ''' ClinicName simple type
                    xmlw.WriteStartElement("ClinicName")
                    xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.ClinicName)
                    xmlw.WriteEndElement()
                    ''' End ClinicName simple type
                End If
                If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Name.LastName <> "" Or adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Name.FirstName <> "" Or adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Name.MiddleName <> "" Then
                    ''' Name complex type
                    xmlw.WriteStartElement("Name")
                    If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Name.LastName <> "" Then
                        ''' LastName simple type
                        xmlw.WriteStartElement("LastName")
                        xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Name.LastName)
                        xmlw.WriteEndElement()
                        ''' End LastName simple type
                    End If
                    If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Name.FirstName <> "" Then
                        ''' FirstName simple type
                        xmlw.WriteStartElement("FirstName")
                        xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Name.FirstName)
                        xmlw.WriteEndElement()
                        ''' End FirstName simple type
                    End If
                    If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Name.MiddleName <> "" Then
                        ''' MiddleName simple type
                        xmlw.WriteStartElement("MiddleName")
                        xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Name.MiddleName)
                        xmlw.WriteEndElement()
                        ''' End MidleName simple type
                    End If
                    xmlw.WriteEndElement()
                    ''' End Name complex type
                End If
                '''' Specialty complex type
                'xmlw.WriteStartElement("Specialty")
                '''' Qualifier simple type
                'xmlw.WriteStartElement("Qualifier")
                'xmlw.WriteString(adminmessage.Body.AddPrescriber.prescriber.Prescriber.Specialty.Qualifier)
                'xmlw.WriteEndElement()
                '''' End Qualifier simple type
                '''' SpecialtyCode simple type
                'xmlw.WriteStartElement("SpecialtyCode")
                'xmlw.WriteString(adminmessage.Body.AddPrescriber.prescriber.Prescriber.Specialty.SpecialtyCode)
                'xmlw.WriteEndElement()
                '''' End SpecialtyCode simple type
                'xmlw.WriteEndElement()
                '''' End Specialty complex type
                '''' PrescriberAgent complex type
                'xmlw.WriteStartElement("PrescriberAgent")
                '''' LastName simple type
                'xmlw.WriteStartElement("LastName")
                'xmlw.WriteString(adminmessage.Body.AddPrescriber.prescriber.Prescriber.PrescriberAgent.LastName)
                'xmlw.WriteEndElement()
                '''' End LastName simple type
                '''' FirstName simple type
                'xmlw.WriteStartElement("FirstName")
                'xmlw.WriteString(adminmessage.Body.AddPrescriber.prescriber.Prescriber.PrescriberAgent.FirstName)
                'xmlw.WriteEndElement()
                '''' End FirstName simple type
                'xmlw.WriteEndElement()
                '''' End PrescriberAgent complex type
                If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.AddressLine1 <> "" Or adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.AddressLine2 <> "" Or adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.City <> "" Or adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.State <> "" Or adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.ZipCode <> "" Then
                    ''' Address complex type
                    xmlw.WriteStartElement("Address")
                    If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.AddressLine1 <> "" Then
                        ''' AddressLine1 simple type
                        xmlw.WriteStartElement("AddressLine1")
                        xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.AddressLine1)
                        xmlw.WriteEndElement()
                        ''' End AddressLine1 simple type
                    End If
                    If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.AddressLine2 <> "" Then
                        ''' AddressLine2 simple type
                        xmlw.WriteStartElement("AddressLine2")
                        xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.AddressLine2)
                        xmlw.WriteEndElement()
                        ''' End AddressLine2 simple type
                    End If
                    If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.City <> "" Then
                        ''' City simple type
                        xmlw.WriteStartElement("City")
                        xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.City)
                        xmlw.WriteEndElement()
                        ''' End City simple type
                    End If
                    If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.State <> "" Then
                        ''' State simple type
                        xmlw.WriteStartElement("State")
                        xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.State)
                        xmlw.WriteEndElement()
                        ''' End State simple type
                    End If
                    If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.ZipCode <> "" Then
                        ''' ZipCode simple type
                        xmlw.WriteStartElement("ZipCode")
                        xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.ZipCode)
                        xmlw.WriteEndElement()
                        ''' End ZipCode simple type
                    End If
                    xmlw.WriteEndElement()
                    ''' End Address complex type
                End If
                If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Email <> "" Then
                    ''' Email simple type
                    xmlw.WriteStartElement("Email")
                    xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Email)
                    xmlw.WriteEndElement()
                    ''' End Email simple type
                End If
                Dim a As Integer = 0
                If Not adminmessage.Body.AddPrescriber.Prescriber.Prescriber.PhoneNumbers.Phone Is Nothing Then
                    ''' PhoneNumbers complex type
                    xmlw.WriteStartElement("PhoneNumbers")
                    For a = 0 To adminmessage.Body.AddPrescriber.Prescriber.Prescriber.PhoneNumbers.Phone.Length - 1
                        If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.PhoneNumbers.Phone(a).Number <> "" Then
                            ''' Phone complex type
                            xmlw.WriteStartElement("Phone")
                            ''' Number simple type
                            xmlw.WriteStartElement("Number")
                            xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.PhoneNumbers.Phone(a).Number)
                            xmlw.WriteEndElement()
                            ''' End Number simple type
                            ''' Qualifier simple type
                            xmlw.WriteStartElement("Qualifier")
                            xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.PhoneNumbers.Phone(a).Qualifier)
                            xmlw.WriteEndElement()
                            ''' End Qualifier simple type
                            xmlw.WriteEndElement()
                            ''' End Phone complex type
                        End If
                    Next
                    xmlw.WriteEndElement()
                    ''' End PhoneNumbers complex type
                End If
                xmlw.WriteEndElement()
                '''End Prescriber complex type
                xmlw.WriteEndElement()
                '''End AddPrescriber complex type
                xmlw.WriteEndElement()
                '''End Body complex type
                xmlw.WriteEndElement()
                '''End AdminMessage complex type
            Catch ex As Exception
                Dim a As String
                a = ex.Message
            Finally
                If Not xmlw Is Nothing Then
                    xmlw.Flush()
                    xmlw.Close()
                End If
            End Try
        End Function

        Public Function WriteXMLForAddPrescriberLocation(ByVal path As String, ByVal filename As String, ByVal constr As String, ByVal lMessageId As String, ByVal adminmessage As AdminMessageType)
            Dim xmlw As XmlTextWriter
            Dim lResult As Boolean
            Try

                xmlw = New XmlTextWriter(path & "\\" & filename, Nothing)
                xmlw.Formatting = Formatting.Indented
                'xmlw.WriteStartDocument()
                xmlw.WriteStartElement("Message")
                xmlw.WriteAttributeString("xmlns", "http://www.surescripts.com/directories")
                xmlw.WriteAttributeString("version", "1.0")
                '' Header complex type element
                xmlw.WriteStartElement("Header")

                xmlw.WriteStartElement("To")
                xmlw.WriteString("mailto:" & adminmessage.Header.Header.To.MailAddress & "@surescripts.com")
                'xmlw.WriteString(Me.Header.To.MailAddress)
                xmlw.WriteEndElement()

                xmlw.WriteStartElement("From")
                xmlw.WriteString("mailto:" & adminmessage.Header.Header.From.MailAddress & "@surescripts.com")
                'xmlw.WriteString(Me.Header.From.MailAddress)
                xmlw.WriteEndElement()

                xmlw.WriteStartElement("MessageID")
                xmlw.WriteString(adminmessage.Header.Header.MesssageID)
                xmlw.WriteEndElement()

                xmlw.WriteStartElement("SentTime")
                xmlw.WriteString(adminmessage.Header.Header.SentTime.UtcDate)
                xmlw.WriteEndElement()

                'xmlw.WriteStartElement("TestMessage")
                'xmlw.WriteString("")
                'xmlw.WriteEndElement()

                xmlw.WriteStartElement("Authentication")
                xmlw.WriteStartElement("LoginID")
                xmlw.WriteString(adminmessage.Header.Authentication.LoginID)
                xmlw.WriteEndElement()
                xmlw.WriteStartElement("Password")
                xmlw.WriteString(adminmessage.Header.Authentication.Password)
                xmlw.WriteEndElement()
                xmlw.WriteEndElement()

                xmlw.WriteEndElement()
                ''' End Header Complex type
                xmlw.WriteStartElement("Body")
                xmlw.WriteStartElement("AddPrescriberLocation")
                xmlw.WriteStartElement("DirectoryInformation")
                xmlw.WriteStartElement("PortalID")
                xmlw.WriteEndElement()
                xmlw.WriteStartElement("AccountID")
                xmlw.WriteEndElement()
                xmlw.WriteStartElement("ServiceLevel")
                xmlw.WriteEndElement()
                xmlw.WriteStartElement("ActiveStartTime")
                xmlw.WriteEndElement()
                xmlw.WriteStartElement("ActiveEndTime")
                xmlw.WriteEndElement()

                xmlw.WriteEndElement()
                '''End DirectoryInformation complex type
                xmlw.WriteStartElement("Prescriber")
                xmlw.WriteStartElement("Identification")
                ''' SPI simple type
                xmlw.WriteStartElement("SPI")
                xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Identification.SPI)
                xmlw.WriteEndElement()
                ''' End SPI simple type
                If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Identification.SocialSecurity <> "" Then
                    ''' SocialSecurity simple type
                    xmlw.WriteStartElement("SocialSecurity")
                    xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Identification.SocialSecurity)
                    xmlw.WriteEndElement()
                    ''' End SocialSecurity simple type
                End If

                If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Identification.DEANumber <> "" Then
                    ''' DEANumber simple type
                    xmlw.WriteStartElement("DEANumber")
                    xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Identification.DEANumber)
                    xmlw.WriteEndElement()
                    ''' End DEANumber simple type
                End If

                If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Identification.MedicaidNumber <> "" Then
                    ''' MedicaidNumber simple type
                    xmlw.WriteStartElement("MedicaidNumber")
                    xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Identification.MedicaidNumber)
                    xmlw.WriteEndElement()
                    ''' End MedicaidNumber simple type
                End If

                If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Identification.MedicareNumber <> "" Then
                    ''' MedicareNumber simple type
                    xmlw.WriteStartElement("MedicareNumber")
                    xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Identification.MedicareNumber)
                    xmlw.WriteEndElement()
                    ''' End MedicareNumber simple type
                End If
                If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Identification.UPIN <> "" Then
                    ''' UPIN simple type
                    xmlw.WriteStartElement("UPIN")
                    xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Identification.UPIN)
                    xmlw.WriteEndElement()
                    ''' End UPIN simple type
                End If


                '''''''''''
                xmlw.WriteEndElement()
                ''' End Identification complex type
                If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.ClinicName <> "" Then
                    ''' ClinicName simple type
                    xmlw.WriteStartElement("ClinicName")
                    xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.ClinicName)
                    xmlw.WriteEndElement()
                    ''' End ClinicName simple type
                End If
                If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Name.LastName <> "" Or adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Name.FirstName <> "" Or adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Name.MiddleName <> "" Then
                    ''' Name complex type
                    xmlw.WriteStartElement("Name")
                    If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Name.LastName <> "" Then
                        ''' LastName simple type
                        xmlw.WriteStartElement("LastName")
                        xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Name.LastName)
                        xmlw.WriteEndElement()
                        ''' End LastName simple type
                    End If
                    If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Name.FirstName <> "" Then
                        ''' FirstName simple type
                        xmlw.WriteStartElement("FirstName")
                        xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Name.FirstName)
                        xmlw.WriteEndElement()
                        ''' End FirstName simple type
                    End If
                    If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Name.MiddleName <> "" Then
                        ''' MiddleName simple type
                        xmlw.WriteStartElement("MiddleName")
                        xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Name.MiddleName)
                        xmlw.WriteEndElement()
                        ''' End MidleName simple type
                    End If
                    xmlw.WriteEndElement()
                    ''' End Name complex type
                End If
                '''' Specialty complex type
                'xmlw.WriteStartElement("Specialty")
                '''' Qualifier simple type
                'xmlw.WriteStartElement("Qualifier")
                'xmlw.WriteString(adminmessage.Body.AddPrescriber.prescriber.Prescriber.Specialty.Qualifier)
                'xmlw.WriteEndElement()
                '''' End Qualifier simple type
                '''' SpecialtyCode simple type
                'xmlw.WriteStartElement("SpecialtyCode")
                'xmlw.WriteString(adminmessage.Body.AddPrescriber.prescriber.Prescriber.Specialty.SpecialtyCode)
                'xmlw.WriteEndElement()
                '''' End SpecialtyCode simple type
                'xmlw.WriteEndElement()
                '''' End Specialty complex type
                '''' PrescriberAgent complex type
                'xmlw.WriteStartElement("PrescriberAgent")
                '''' LastName simple type
                'xmlw.WriteStartElement("LastName")
                'xmlw.WriteString(adminmessage.Body.AddPrescriber.prescriber.Prescriber.PrescriberAgent.LastName)
                'xmlw.WriteEndElement()
                '''' End LastName simple type
                '''' FirstName simple type
                'xmlw.WriteStartElement("FirstName")
                'xmlw.WriteString(adminmessage.Body.AddPrescriber.prescriber.Prescriber.PrescriberAgent.FirstName)
                'xmlw.WriteEndElement()
                '''' End FirstName simple type
                'xmlw.WriteEndElement()
                '''' End PrescriberAgent complex type
                If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.AddressLine1 <> "" Or adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.AddressLine2 <> "" Or adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.City <> "" Or adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.State <> "" Or adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.ZipCode <> "" Then
                    ''' Address complex type
                    xmlw.WriteStartElement("Address")
                    If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.AddressLine1 <> "" Then
                        ''' AddressLine1 simple type
                        xmlw.WriteStartElement("AddressLine1")
                        xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.AddressLine1)
                        xmlw.WriteEndElement()
                        ''' End AddressLine1 simple type
                    End If
                    If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.AddressLine2 <> "" Then
                        ''' AddressLine2 simple type
                        xmlw.WriteStartElement("AddressLine2")
                        xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.AddressLine2)
                        xmlw.WriteEndElement()
                        ''' End AddressLine2 simple type
                    End If
                    If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.City <> "" Then
                        ''' City simple type
                        xmlw.WriteStartElement("City")
                        xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.City)
                        xmlw.WriteEndElement()
                        ''' End City simple type
                    End If
                    If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.State <> "" Then
                        ''' State simple type
                        xmlw.WriteStartElement("State")
                        xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.State)
                        xmlw.WriteEndElement()
                        ''' End State simple type
                    End If
                    If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.ZipCode <> "" Then
                        ''' ZipCode simple type
                        xmlw.WriteStartElement("ZipCode")
                        xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.ZipCode)
                        xmlw.WriteEndElement()
                        ''' End ZipCode simple type
                    End If
                    xmlw.WriteEndElement()
                    ''' End Address complex type
                End If
                If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Email <> "" Then
                    ''' Email simple type
                    xmlw.WriteStartElement("Email")
                    xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Email)
                    xmlw.WriteEndElement()
                    ''' End Email simple type
                End If
                Dim a As Integer = 0
                If Not adminmessage.Body.AddPrescriber.Prescriber.Prescriber.PhoneNumbers.Phone Is Nothing Then
                    ''' PhoneNumbers complex type
                    xmlw.WriteStartElement("PhoneNumbers")
                    For a = 0 To adminmessage.Body.AddPrescriber.Prescriber.Prescriber.PhoneNumbers.Phone.Length - 1
                        If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.PhoneNumbers.Phone(a).Number <> "" Then
                            ''' Phone complex type
                            xmlw.WriteStartElement("Phone")
                            ''' Number simple type
                            xmlw.WriteStartElement("Number")
                            xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.PhoneNumbers.Phone(a).Number)
                            xmlw.WriteEndElement()
                            ''' End Number simple type
                            ''' Qualifier simple type
                            xmlw.WriteStartElement("Qualifier")
                            xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.PhoneNumbers.Phone(a).Qualifier)
                            xmlw.WriteEndElement()
                            ''' End Qualifier simple type
                            xmlw.WriteEndElement()
                            ''' End Phone complex type
                        End If
                    Next
                    xmlw.WriteEndElement()
                    ''' End PhoneNumbers complex type
                End If
                xmlw.WriteEndElement()
                '''End Prescriber complex type
                xmlw.WriteEndElement()
                '''End AddPrescriber complex type
                xmlw.WriteEndElement()
                '''End Body complex type
                xmlw.WriteEndElement()
                '''End AdminMessage complex type
            Catch ex As Exception

            Finally

            End Try
        End Function

        Public Function WriteXMLForUpdatePrescriberLocation(ByVal path As String, ByVal filename As String, ByVal adminmessage As AdminMessageType)
            Dim xmlw As XmlTextWriter
            Dim lResult As Boolean
            Try

                xmlw = New XmlTextWriter(path & "\\" & filename, Nothing)
                xmlw.Formatting = Formatting.Indented
                'xmlw.WriteStartDocument()
                xmlw.WriteStartElement("AdminMessage")
                xmlw.WriteAttributeString("xmlns", "http://www.surescripts.com/directories")
                xmlw.WriteAttributeString("version", "1.0")
                '' Header complex type element
                xmlw.WriteStartElement("Header")

                xmlw.WriteStartElement("To")
                xmlw.WriteString("mailto:" & adminmessage.Header.Header.To.MailAddress & "@surescripts.com")
                'xmlw.WriteString(Me.Header.To.MailAddress)
                xmlw.WriteEndElement()

                xmlw.WriteStartElement("From")
                xmlw.WriteString("mailto:" & adminmessage.Header.Header.From.MailAddress & "@surescripts.com")
                'xmlw.WriteString(Me.Header.From.MailAddress)
                xmlw.WriteEndElement()

                xmlw.WriteStartElement("MessageID")
                xmlw.WriteString(adminmessage.Header.Header.MesssageID)
                xmlw.WriteEndElement()

                xmlw.WriteStartElement("SentTime")
                xmlw.WriteString(adminmessage.Header.Header.SentTime.UtcDate)
                xmlw.WriteEndElement()

                'xmlw.WriteStartElement("TestMessage")
                'xmlw.WriteString("")
                'xmlw.WriteEndElement()

                xmlw.WriteStartElement("Authentication")
                xmlw.WriteStartElement("LoginID")
                xmlw.WriteString(adminmessage.Header.Authentication.LoginID)
                xmlw.WriteEndElement()
                xmlw.WriteStartElement("Password")
                xmlw.WriteString(adminmessage.Header.Authentication.Password)
                xmlw.WriteEndElement()
                xmlw.WriteEndElement()

                xmlw.WriteEndElement()
                ''' End Header Complex type
                xmlw.WriteStartElement("Body")
                xmlw.WriteStartElement("UpdatePrescriberLocation")
                xmlw.WriteStartElement("DirectoryInformation")
                If adminmessage.Body.AddPrescriber.DirectoryInformation.PortalID <> "" Then
                    xmlw.WriteStartElement("PortalID")
                    xmlw.WriteString(adminmessage.Body.AddPrescriber.DirectoryInformation.PortalID)
                    xmlw.WriteEndElement()
                End If
                If adminmessage.Body.AddPrescriber.DirectoryInformation.AccountID <> "" Then
                    xmlw.WriteStartElement("AccountID")
                    xmlw.WriteString(adminmessage.Body.AddPrescriber.DirectoryInformation.AccountID)
                    xmlw.WriteEndElement()
                End If
                If adminmessage.Body.AddPrescriber.DirectoryInformation.ServiceLevelCode <> "" Then
                    xmlw.WriteStartElement("ServiceLevel")
                    xmlw.WriteString(adminmessage.Body.AddPrescriber.DirectoryInformation.ServiceLevelCode)
                    xmlw.WriteEndElement()
                End If
                If adminmessage.Body.AddPrescriber.DirectoryInformation.ActiveStartTime.UtcDate <> "" Then
                    xmlw.WriteStartElement("ActiveStartTime")
                    xmlw.WriteString(adminmessage.Body.AddPrescriber.DirectoryInformation.ActiveStartTime.UtcDate)
                    xmlw.WriteEndElement()
                End If
                If adminmessage.Body.AddPrescriber.DirectoryInformation.ActiveEndTime.UtcDate <> "" Then
                    xmlw.WriteStartElement("ActiveEndTime")
                    xmlw.WriteString(adminmessage.Body.AddPrescriber.DirectoryInformation.ActiveEndTime.UtcDate)
                    xmlw.WriteEndElement()
                End If

                xmlw.WriteEndElement()
                '''End DirectoryInformation complex type
                xmlw.WriteStartElement("Prescriber")
                xmlw.WriteStartElement("Identification")
                If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Identification.SPI <> "" Then
                    ''' SPI simple type
                    xmlw.WriteStartElement("SPI")
                    xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Identification.SPI)
                    xmlw.WriteEndElement()
                    ''' End SPI simple type
                End If
                If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Identification.SocialSecurity <> "" Then
                    ''' SocialSecurity simple type
                    xmlw.WriteStartElement("SocialSecurity")
                    xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Identification.SocialSecurity)
                    xmlw.WriteEndElement()
                    ''' End SocialSecurity simple type
                End If

                If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Identification.DEANumber <> "" Then
                    ''' DEANumber simple type
                    xmlw.WriteStartElement("DEANumber")
                    xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Identification.DEANumber)
                    xmlw.WriteEndElement()
                    ''' End DEANumber simple type
                End If

                If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Identification.MedicaidNumber <> "" Then
                    ''' MedicaidNumber simple type
                    xmlw.WriteStartElement("MedicaidNumber")
                    xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Identification.MedicaidNumber)
                    xmlw.WriteEndElement()
                    ''' End MedicaidNumber simple type
                End If

                If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Identification.MedicareNumber <> "" Then
                    ''' MedicareNumber simple type
                    xmlw.WriteStartElement("MedicareNumber")
                    xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Identification.MedicareNumber)
                    xmlw.WriteEndElement()
                    ''' End MedicareNumber simple type
                End If
                If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Identification.UPIN <> "" Then
                    ''' UPIN simple type
                    xmlw.WriteStartElement("UPIN")
                    xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Identification.UPIN)
                    xmlw.WriteEndElement()
                    ''' End UPIN simple type
                End If


                '''''''''''
                xmlw.WriteEndElement()
                ''' End Identification complex type
                If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.ClinicName <> "" Then
                    ''' ClinicName simple type
                    xmlw.WriteStartElement("ClinicName")
                    xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.ClinicName)
                    xmlw.WriteEndElement()
                    ''' End ClinicName simple type
                End If
                If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Name.LastName <> "" Or adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Name.FirstName <> "" Or adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Name.MiddleName <> "" Then
                    ''' Name complex type
                    xmlw.WriteStartElement("Name")
                    If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Name.LastName <> "" Then
                        ''' LastName simple type
                        xmlw.WriteStartElement("LastName")
                        xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Name.LastName)
                        xmlw.WriteEndElement()
                        ''' End LastName simple type
                    End If
                    If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Name.FirstName <> "" Then
                        ''' FirstName simple type
                        xmlw.WriteStartElement("FirstName")
                        xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Name.FirstName)
                        xmlw.WriteEndElement()
                        ''' End FirstName simple type
                    End If
                    If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Name.MiddleName <> "" Then
                        ''' MiddleName simple type
                        xmlw.WriteStartElement("MiddleName")
                        xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Name.MiddleName)
                        xmlw.WriteEndElement()
                        ''' End MidleName simple type
                    End If
                    xmlw.WriteEndElement()
                    ''' End Name complex type
                End If
                '''' Specialty complex type
                'xmlw.WriteStartElement("Specialty")
                '''' Qualifier simple type
                'xmlw.WriteStartElement("Qualifier")
                'xmlw.WriteString(adminmessage.Body.AddPrescriber.prescriber.Prescriber.Specialty.Qualifier)
                'xmlw.WriteEndElement()
                '''' End Qualifier simple type
                '''' SpecialtyCode simple type
                'xmlw.WriteStartElement("SpecialtyCode")
                'xmlw.WriteString(adminmessage.Body.AddPrescriber.prescriber.Prescriber.Specialty.SpecialtyCode)
                'xmlw.WriteEndElement()
                '''' End SpecialtyCode simple type
                'xmlw.WriteEndElement()
                '''' End Specialty complex type
                '''' PrescriberAgent complex type
                'xmlw.WriteStartElement("PrescriberAgent")
                '''' LastName simple type
                'xmlw.WriteStartElement("LastName")
                'xmlw.WriteString(adminmessage.Body.AddPrescriber.prescriber.Prescriber.PrescriberAgent.LastName)
                'xmlw.WriteEndElement()
                '''' End LastName simple type
                '''' FirstName simple type
                'xmlw.WriteStartElement("FirstName")
                'xmlw.WriteString(adminmessage.Body.AddPrescriber.prescriber.Prescriber.PrescriberAgent.FirstName)
                'xmlw.WriteEndElement()
                '''' End FirstName simple type
                'xmlw.WriteEndElement()
                '''' End PrescriberAgent complex type
                If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.AddressLine1 <> "" Or adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.AddressLine2 <> "" Or adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.City <> "" Or adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.State <> "" Or adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.ZipCode <> "" Then
                    ''' Address complex type
                    xmlw.WriteStartElement("Address")
                    If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.AddressLine1 <> "" Then
                        ''' AddressLine1 simple type
                        xmlw.WriteStartElement("AddressLine1")
                        xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.AddressLine1)
                        xmlw.WriteEndElement()
                        ''' End AddressLine1 simple type
                    End If
                    If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.AddressLine2 <> "" Then
                        ''' AddressLine2 simple type
                        xmlw.WriteStartElement("AddressLine2")
                        xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.AddressLine2)
                        xmlw.WriteEndElement()
                        ''' End AddressLine2 simple type
                    End If
                    If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.City <> "" Then
                        ''' City simple type
                        xmlw.WriteStartElement("City")
                        xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.City)
                        xmlw.WriteEndElement()
                        ''' End City simple type
                    End If
                    If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.State <> "" Then
                        ''' State simple type
                        xmlw.WriteStartElement("State")
                        xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.State)
                        xmlw.WriteEndElement()
                        ''' End State simple type
                    End If
                    If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.ZipCode <> "" Then
                        ''' ZipCode simple type
                        xmlw.WriteStartElement("ZipCode")
                        xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Address.ZipCode)
                        xmlw.WriteEndElement()
                        ''' End ZipCode simple type
                    End If
                    xmlw.WriteEndElement()
                    ''' End Address complex type
                End If
                If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Email <> "" Then
                    ''' Email simple type
                    xmlw.WriteStartElement("Email")
                    xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.Email)
                    xmlw.WriteEndElement()
                    ''' End Email simple type
                End If
                Dim a As Integer = 0
                If Not adminmessage.Body.AddPrescriber.Prescriber.Prescriber.PhoneNumbers.Phone Is Nothing Then
                    ''' PhoneNumbers complex type
                    xmlw.WriteStartElement("PhoneNumbers")
                    For a = 0 To adminmessage.Body.AddPrescriber.Prescriber.Prescriber.PhoneNumbers.Phone.Length - 1
                        If adminmessage.Body.AddPrescriber.Prescriber.Prescriber.PhoneNumbers.Phone(a).Number <> "" Then
                            ''' Phone complex type
                            xmlw.WriteStartElement("Phone")
                            ''' Number simple type
                            xmlw.WriteStartElement("Number")
                            xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.PhoneNumbers.Phone(a).Number)
                            xmlw.WriteEndElement()
                            ''' End Number simple type
                            ''' Qualifier simple type
                            xmlw.WriteStartElement("Qualifier")
                            xmlw.WriteString(adminmessage.Body.AddPrescriber.Prescriber.Prescriber.PhoneNumbers.Phone(a).Qualifier)
                            xmlw.WriteEndElement()
                            ''' End Qualifier simple type
                            xmlw.WriteEndElement()
                            ''' End Phone complex type
                        End If
                    Next
                    xmlw.WriteEndElement()
                    ''' End PhoneNumbers complex type
                End If
                xmlw.WriteEndElement()
                '''End Prescriber complex type
                xmlw.WriteEndElement()
                '''End AddPrescriber complex type
                xmlw.WriteEndElement()
                '''End Body complex type
                xmlw.WriteEndElement()
                '''End AdminMessage complex type
            Catch ex As Exception
                Dim a As String
                a = ex.Message
            Finally
                If Not xmlw Is Nothing Then
                    xmlw.Flush()
                    xmlw.Close()
                End If
            End Try
        End Function
    End Class
End Namespace