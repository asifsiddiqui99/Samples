Imports System.Xml
Namespace SureScripts
    Public Class ErrorMessage
#Region "Instance Variables"
        Private mHeader As HeaderType
        Private mError As ErrorType
#End Region


#Region "Properties"
        Public Property Header() As HeaderType
            Get
                Return mHeader
            End Get
            Set(ByVal Value As HeaderType)
                mHeader = Value
            End Set
        End Property
        Public Property [Error]() As ErrorType
            Get
                Return mError
            End Get
            Set(ByVal Value As ErrorType)
                mError = Value
            End Set
        End Property
#End Region


#Region "Methods"
        Public Function WriteXMLForNewPrescription(ByVal path As String, ByVal filename As String)
            Dim xmlw As XmlTextWriter
            Try


                xmlw = New XmlTextWriter(path + filename, Nothing)
                xmlw.Formatting = Formatting.Indented
                xmlw.WriteStartDocument()
                xmlw.WriteStartElement("Message")
                xmlw.WriteAttributeString("xmlns=", "http://www.surescripts.com/messaging")

                '' Header complex type element
                xmlw.WriteStartElement("Header")

                xmlw.WriteStartElement("To")
                xmlw.WriteString(Me.Header.To.MailAddress)
                xmlw.WriteEndElement()

                xmlw.WriteStartElement("From")
                xmlw.WriteString(Me.Header.From.MailAddress)
                xmlw.WriteEndElement()

                xmlw.WriteStartElement("MessageID")
                xmlw.WriteString(Me.Header.MesssageID)
                xmlw.WriteEndElement()

                xmlw.WriteStartElement("SentTime")
                xmlw.WriteString(Me.Header.SentTime.UtcDate)
                xmlw.WriteEndElement()

                xmlw.WriteStartElement("TestMessage")
                xmlw.WriteString("")
                xmlw.WriteEndElement()
                xmlw.WriteEndElement()
                ''' End Header Complex type
                ''' Body complex type
                xmlw.WriteStartElement("Body")
                ''' Error complex type
                xmlw.WriteStartElement("Error")
                ''' Code Simple type
                xmlw.WriteStartElement("Code")
                xmlw.WriteString(Me.Error.Code)
                xmlw.WriteEndElement()
                ''' End Code Simple type
                ''' DescriptionCode Simple type
                xmlw.WriteStartElement("DescriptionCode")
                xmlw.WriteString(Me.Error.DescriptionCode)
                xmlw.WriteEndElement()
                ''' End DescriptionCode Simple type
                ''' Description Simple type
                xmlw.WriteStartElement("Description")
                xmlw.WriteString(Me.Error.Description)
                xmlw.WriteEndElement()
                ''' End Description Simple type
                xmlw.WriteEndElement()
                ''' End Error complex type
                xmlw.WriteEndElement()
                ''' End Body complex type
                xmlw.WriteEndElement()
                ''' End Message complex type
                xmlw.WriteEndDocument()

            Catch ex As Exception
                Dim a As String
                a = ex.Message
            Finally
                xmlw.Flush()
                xmlw.Close()
            End Try
            Return ""
        End Function
#End Region

    End Class
End Namespace
