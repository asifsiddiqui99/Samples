Imports System.xml
Imports System.Data.SqlClient
Imports System.Configuration
Imports ElixirLibrary

Namespace SureScripts


Public Class Common
        Private Shared Function GetNode(ByVal tree As XmlNode) As String
            Dim lName As String = tree.Name

            Try
                Select Case lName.ToUpper
                    Case "NewRx".ToUpper
                        Return "NewRx"
                    Case "RefillRequest".ToUpper
                        Return "RefillRequest"
                    Case "RefillResponse".ToUpper
                        Return "RefillResponse"
                    Case "RxChangeRequest".ToUpper
                        Return "RxChangeRequest"
                    Case "RxChangeResponse".ToUpper
                        Return "RxChangeResponse"
                    Case "RxFill".ToUpper
                        Return "RxFill"
                    Case "Status".ToUpper
                        Return "Status"
                    Case "Error".ToUpper
                        Return "Error"
                    Case "Verify".ToUpper
                        Return "Verify"
                    Case Else
                        Return ""
                End Select

            Catch ex As Exception
                Throw New Exception(ex.Message + " : SurescriptsLibrary\Common.GetNode(ByVal tree As XmlNode)  ")
            End Try


        End Function

        Public Shared Function ParseTree(ByVal tree As XmlNode) As String
            Dim lMessage As String

            Try
                If Not (tree Is Nothing) Then
                    lMessage = GetNode(tree)
                End If
                If tree.HasChildNodes Then
                    tree = tree.FirstChild
                    While Not (tree Is Nothing)
                        If lMessage <> "" Then
                            Return lMessage
                        End If
                        lMessage = ParseTree(tree)
                        If lMessage <> "" Then
                            Exit While
                        End If
                        tree = tree.NextSibling
                    End While
                End If

            Catch ex As Exception
                Throw New Exception(ex.Message + " : SurescriptsLibrary\Common.ParseTree(ByVal tree As XmlNode) ")
            End Try

            Return lMessage
        End Function

        Public Shared Function GetMessageType(ByVal lMessageId As String) As String
            Dim lQuery As String
            Dim lDs As New DataSet
            Dim lConnection As New Connection()
            'Dim lConnectionString As String
            'lConnectionString = ConfigurationSettings.AppSettings("connectionString")
            
            Try

                lQuery = "Select MessageTypeId From MessageHdr " _
                        & "Where MessageId ='" & lMessageId & "' "

                'lDs = lConnection.ExecuteQuery(lQuery)
                'Dim lDa As New SqlClient.SqlDataAdapter(lQuery, lConnectionString)
                'lDa.Fill(lDs)
                If lConnection.IsTransactionAlive Then
                    lDs = lConnection.ExecuteTransactionQuery(lQuery)
                Else
                    lDs = lConnection.ExecuteQuery(lQuery)
                End If

                If lDs.Tables(0).Rows.Count > 0 Then
                    GetMessageType = lDs.Tables(0).Rows(0).Item("MessageTypeId")
                Else
                    GetMessageType = ""
                End If

            Catch ex As Exception
                TraceLogging.ErrorLogMethods.LogError(ex, "SurescriptsLibrary\Common.GetMessageType(ByVal lMessageId As String) ")
                GetMessageType = ""
            End Try

        End Function

        Public Shared Function ChangePhoneFormat(ByVal lPhoneNumber As String) As String
            Dim lIndex As Integer
            Dim lFormatedString As String = ""

            Try

                For lIndex = 0 To lPhoneNumber.Length - 1
                    If IsNumeric(lPhoneNumber.Substring(lIndex, 1)) Then
                        lFormatedString = lFormatedString & lPhoneNumber.Substring(lIndex, 1)
                    End If
                Next
                If lFormatedString.Length > 10 Then
                    lFormatedString = Right(lFormatedString, 10)
                End If
                ChangePhoneFormat = lFormatedString


            Catch ex As Exception
                Throw New Exception(ex.Message + " : SurescriptsLibrary\Common.ChangePhoneFormat(ByVal lPhoneNumber As String) ")
            End Try


        End Function

        Public Shared Function ChangeSSNFormat(ByVal lSSN As String) As String
            Dim lIndex As Integer
            Dim lFormatedString As String = ""


            Try
                If lSSN = Nothing Then
                    ChangeSSNFormat = ""
                End If
                If lSSN.Length = 0 Then
                    ChangeSSNFormat = ""
                End If

                For lIndex = 0 To lSSN.Length - 1
                    If IsNumeric(lSSN.Substring(lIndex, 1)) Then
                        lFormatedString = lFormatedString & lSSN.Substring(lIndex, 1)
                    End If
                Next

                ChangeSSNFormat = lFormatedString

            Catch ex As Exception
                Throw New Exception(ex.Message + " : SurescriptsLibrary\Common.ChangeSSNFormat(ByVal lSSN As String) ")
            End Try


        End Function


        Public Shared Function GetMessageID(ByVal constr As String) As String

            Dim lDs As DataSet
            Dim lMessageNo As Integer = 0
            Dim lQuery, lMsgID As String
            Dim lConnection As New Connection()
            'Dim lConnectionString As String


            Try
                'lConnectionString = ConfigurationSettings.AppSettings("connectionString")
                lQuery = "Select AdminMessageId+1 As MsgId from NumSeries "
                'lDs = DBClass.ExecuteQuery(lQuery, constr)
                lDs = lConnection.ExecuteQuery(lQuery)
                If lDs.Tables.Count > 0 Then
                    lMsgID = "Panace-Admin-" _
                           & CType(lDs.Tables(0).Rows(0)("MsgId"), String).PadLeft(10, "0")

                    lMessageNo = lDs.Tables(0).Rows(0)("MsgId")
                End If

                lQuery = "Update NumSeries Set AdminMessageId = " & lMessageNo
                lConnection.ExecuteCommand(lQuery)
                'DBClass.ExecuteUpdate(lQuery, constr)
                Return lMsgID

            Catch ex As Exception
                Throw New Exception(ex.Message + " : SurescriptsLibrary\Common.GetMessageID(ByVal constr As String) ")
            End Try

        End Function


        Public Shared Sub ParseResponseTree(ByVal pNode As XmlNode, ByVal pReceiveMessage As ReceivedMessage)
            Try
                If Not pNode Is Nothing Then
                    GetResponseNode(pNode, pReceiveMessage)
                End If
                If pNode.HasChildNodes Then
                    pNode = pNode.FirstChild
                    While Not pNode Is Nothing
                        ParseResponseTree(pNode, pReceiveMessage)
                        pNode = pNode.NextSibling
                    End While
                End If
            Catch ex As Exception
                Throw New Exception(ex.Message + " : SurescriptsLibrary\Common.ParseResponseTree(ByVal pNode As XmlNode, ByVal pReceiveMessage As ReceivedMessage) ")
            End Try
            
        End Sub

        Private Shared Sub GetResponseNode(ByVal pNode As XmlNode, ByVal pReceivedMessage As ReceivedMessage)
            Dim lName As String = pNode.Name


            Try
                Select Case lName.ToUpper
                    Case "TO"
                        pReceivedMessage.HeaderType.To.MailAddress = pNode.InnerText
                    Case "FROM"
                        pReceivedMessage.HeaderType.From.MailAddress = pNode.InnerText
                    Case "MESSAGEID"
                        pReceivedMessage.HeaderType.MesssageID = pNode.InnerText
                    Case "RELATESTOMESSAGEID"
                        pReceivedMessage.HeaderType.RelatesToMessageID = pNode.InnerText
                    Case "SENTTIME"
                        pReceivedMessage.HeaderType.SentTime.UtcDate = pNode.InnerText
                    Case "CODE"
                        If pReceivedMessage.MessageType.ToUpper() = "ERROR" Then
                            pReceivedMessage.ErrorType.Code = pNode.InnerText
                        End If
                        If pReceivedMessage.MessageType.ToUpper() = "STATUS" Then
                            pReceivedMessage.StatusType.Code = pNode.InnerText
                        End If
                    Case "DESCRIPTIONCODE"
                        pReceivedMessage.ErrorType.DescriptionCode = pNode.InnerText
                    Case "DESCRIPTION"
                        If pReceivedMessage.MessageType.ToUpper() = "ERROR" Then
                            pReceivedMessage.ErrorType.Description = pNode.InnerText
                        End If
                        If pReceivedMessage.MessageType.ToUpper() = "STATUS" Then
                            pReceivedMessage.ErrorType.Description = pNode.InnerText
                            pReceivedMessage.StatusType.Description = pNode.InnerText
                        End If
                    Case "ERROR"
                        pReceivedMessage.MessageType = "ERROR"
                    Case "STATUS"
                        pReceivedMessage.MessageType = "STATUS"
                End Select

            Catch ex As Exception
                Throw New Exception(ex.Message + " : SurescriptsLibrary\Common.GetResponseNode(ByVal pNode As XmlNode, ByVal pReceivedMessage As ReceivedMessage) ")
            End Try

        End Sub

    End Class

    Public Class MessageHeader
#Region "InstanceVariables"
        Private mMessageCode As String
        Private mMessageId As String
        Private mMessageTypeId As String
        Private mLastStatus As String
        Private mXMLPath As String
        Private mClinicId As String
        Private mUserId As String
        Private mPrescriberOrderNo As String
        Private mRxReferenceNo As String
        Private mRelatesToMessageId As String
        Private mDirection As String
        Private mXMLContents As String
        Private mConnectionString As String

#End Region

#Region "Properties"
        Public Property ConnectionString()
            Get
                Return mConnectionString
            End Get
            Set(ByVal Value)
                mConnectionString = Value
            End Set
        End Property
        Public Property XMLContents()
            Get
                Return mXMLContents
            End Get
            Set(ByVal Value)
                mXMLContents = Value
            End Set
        End Property
        Public Property Direction()
            Get
                Return mDirection
            End Get
            Set(ByVal Value)
                mDirection = Value
            End Set
        End Property
        Public Property RelatesToMessageId()
            Get
                Return mRelatesToMessageId
            End Get
            Set(ByVal Value)
                mRelatesToMessageId = Value
            End Set
        End Property
        Public Property RxReferenceNo()
            Get
                Return mRxReferenceNo
            End Get
            Set(ByVal Value)
                mRxReferenceNo = Value
            End Set
        End Property
        Public Property PrescriberOrderNo()
            Get
                Return mPrescriberOrderNo
            End Get
            Set(ByVal Value)
                mPrescriberOrderNo = Value
            End Set
        End Property

        Public Property UserId()
            Get
                Return mUserId
            End Get
            Set(ByVal Value)
                mUserId = Value
            End Set
        End Property
        Public Property ClinicId()
            Get
                Return mClinicId
            End Get
            Set(ByVal Value)
                mClinicId = Value
            End Set
        End Property
        Public Property XMLPath()
            Get
                Return mXMLPath
            End Get
            Set(ByVal Value)
                mXMLPath = Value
            End Set
        End Property
        Public Property LastStatus()
            Get
                Return mLastStatus
            End Get
            Set(ByVal Value)
                mLastStatus = Value
            End Set
        End Property
        Public Property MessageTypeId()
            Get
                Return mMessageTypeId
            End Get
            Set(ByVal Value)
                mMessageTypeId = Value
            End Set
        End Property
        Public Property MessageId()
            Get
                Return mMessageId
            End Get
            Set(ByVal Value)
                mMessageId = Value
            End Set
        End Property
        Public Property MessageCode()
            Get
                Return mMessageCode
            End Get
            Set(ByVal Value)
                mMessageCode = Value
            End Set
        End Property

#End Region
#Region "Methods"
        Public Function GetMessageHeaderInfoByMessageId(ByVal lMessageId As String, ByVal lPharmacyId As String) As Boolean
            Dim lQuery As String
            Dim lDs As New DataSet
            Dim lConnection As New Connection()

            'Dim lConnectionString As String
            'lConnectionString = ConfigurationSettings.AppSettings("connectionString")
            'If lConnectionString = "" Then
            '    lConnectionString = Me.ConnectionString
            'End If
            

            Try
                lQuery = "Select * From MessageHdr " _
                        & "Where MessageId ='" & lMessageId & "' "

                If lPharmacyId <> "" Then
                    lQuery = lQuery & "AND PharmacyCode ='" & lPharmacyId & "' "
                End If

                If lConnection.IsTransactionAlive Then
                    lDs = lConnection.ExecuteTransactionQuery(lQuery)
                Else
                    lDs = lConnection.ExecuteQuery(lQuery)
                End If


                If lDs.Tables(0).Rows.Count > 0 Then
                    Me.ClinicId = lDs.Tables(0).Rows(0).Item("ClinicId")

                    Me.MessageCode = lDs.Tables(0).Rows(0).Item("MessageCode") & ""
                    Me.MessageId = lDs.Tables(0).Rows(0).Item("MessageId") & ""
                    Me.MessageTypeId = lDs.Tables(0).Rows(0).Item("MessageTypeId") & ""
                    Me.LastStatus = lDs.Tables(0).Rows(0).Item("LastStatus") & ""
                    Me.XMLPath = lDs.Tables(0).Rows(0).Item("XMLPath") & ""
                    Me.ClinicId = lDs.Tables(0).Rows(0).Item("ClinicId") & ""
                    Me.UserId = lDs.Tables(0).Rows(0).Item("UserId") & ""
                    Me.PrescriberOrderNo = lDs.Tables(0).Rows(0).Item("PrescriberOrderNo") & ""
                    Me.RxReferenceNo = lDs.Tables(0).Rows(0).Item("RxReferenceNo") & ""
                    Me.RelatesToMessageId = lDs.Tables(0).Rows(0).Item("RelatesToMessageId") & ""
                    Me.Direction = lDs.Tables(0).Rows(0).Item("Direction") & ""
                    Me.XMLContents = lDs.Tables(0).Rows(0).Item("XMLContents") & ""
                End If

                GetMessageHeaderInfoByMessageId = True
            Catch ex As Exception
                TraceLogging.ErrorLogMethods.LogError(ex, "SurescriptsLibrary\ConnectionMaster.GetMessageHeaderInfoByMessageId(ByVal lMessageId As String, ByVal lPharmacyId As String) ")
                GetMessageHeaderInfoByMessageId = False
            End Try



        End Function

#End Region
    End Class
    Public Class ConnectionMaster

#Region "InstanceVariables"
        Private mClinicID As String
        Private mConnectionString As String
        Private mServerIPAdress As String
        Private mDatabaseName As String
        Private mUserName As String
        Private mPassword As String
        Private mServerPortNumber As String
        Private mDrCode As String
        Private mSPI As String
#End Region
#Region "Properties"


        Public Property ClinicID()
            Get
                Return mClinicID
            End Get
            Set(ByVal Value)
                mClinicID = Value
            End Set
        End Property

        Public Property ConnectionString()
            Get
                Return mConnectionString
            End Get
            Set(ByVal Value)
                mConnectionString = Value
            End Set
        End Property

        Public Property ServerIPAdress()
            Get
                Return mServerIPAdress
            End Get
            Set(ByVal Value)
                mServerIPAdress = Value
            End Set
        End Property

        Public Property DatabaseName()
            Get
                Return mDatabaseName
            End Get
            Set(ByVal Value)
                mDatabaseName = Value
            End Set
        End Property

        Public Property UserName()
            Get
                Return mUserName
            End Get
            Set(ByVal Value)
                mUserName = Value
            End Set
        End Property

        Public Property Password()
            Get
                Return mPassword
            End Get
            Set(ByVal Value)
                mPassword = Value
            End Set
        End Property

        Public Property ServerPortNumber()
            Get
                Return mServerPortNumber
            End Get
            Set(ByVal Value)
                mServerPortNumber = Value
            End Set
        End Property
        Public Property DrCode()
            Get
                Return mDrCode
            End Get
            Set(ByVal Value)
                mDrCode = Value
            End Set
        End Property
        Public Property SPI()
            Get
                Return mSPI
            End Get
            Set(ByVal Value)
                mSPI = Value
            End Set
        End Property
#End Region
#Region "Methods"
        Public Function Get_ConnectionInformation_By_SPI(ByVal lSPI As String) As Boolean
            Dim lQuery As String
            Dim lDs As New DataSet
            Dim lConnection As New Connection(ConfigurationSettings.AppSettings("ConnectionString"))
            'Dim lConnectionString As String
            'lConnectionString = ConfigurationSettings.AppSettings("connectionString")
            'If lConnectionString = "" Then
            '    lConnectionString = Me.ConnectionString
            'End If

            Try


                lQuery = "Select CM.ClinicCode, CM.ConnectionString, CM.ServerIPAddress," _
                       & "CM.DatabaseName, CM.LoginId, CM.Password, CM.ServerPortNumber, UM.EmployeeId " _
                       & "From UserMaster UM, ConnectionMaster CM  " _
                       & "Where UM.ClinicId = CM.ClinicCode " _
                       & "And UM.SPI ='" & lSPI & "'  "


                If lConnection.IsTransactionAlive Then
                    lDs = lConnection.ExecuteTransactionQuery(lQuery)
                Else
                    lDs = lConnection.ExecuteQuery(lQuery)
                End If

                If lDs.Tables(0).Rows.Count > 0 Then
                    Me.ClinicID = lDs.Tables(0).Rows(0).Item("ClinicCode")
                    Me.ConnectionString = lDs.Tables(0).Rows(0).Item("ConnectionString")
                    Me.ServerIPAdress = lDs.Tables(0).Rows(0).Item("ServerIPAddress")
                    Me.DatabaseName = lDs.Tables(0).Rows(0).Item("DatabaseName")
                    Me.UserName = lDs.Tables(0).Rows(0).Item("LoginId")
                    Me.Password = lDs.Tables(0).Rows(0).Item("Password")
                    Me.ServerPortNumber = lDs.Tables(0).Rows(0).Item("ServerPortNumber")
                    Me.DrCode = lDs.Tables(0).Rows(0).Item("EmployeeId")
                    Me.SPI = lSPI
                End If

                Get_ConnectionInformation_By_SPI = True
            Catch ex As Exception
                TraceLogging.ErrorLogMethods.LogError(ex, "SurescriptsLibrary\ConnectionMaster.Get_ConnectionInformation_By_SPI(ByVal lSPI As String) ")
                Get_ConnectionInformation_By_SPI = False
            End Try

        End Function

        Public Function Get_ConnectionInformation_By_DrCode(ByVal DrCode As String, ByVal lClinicCode As String) As Boolean
            Dim lQuery As String
            Dim lDs As New DataSet
            Dim lConnection As New Connection()
            'Dim lConnectionString As String
            'lConnectionString = ConfigurationSettings.AppSettings("connectionString")
            'If lConnectionString = "" Then
            '    lConnectionString = Me.ConnectionString
            'End If

            Try


                lQuery = "Select CM.ClinicCode, CM.ConnectionString, CM.ServerIPAddress, " _
                       & "CM.DatabaseName, CM.LoginId, CM.Password, CM.ServerPortNumber, " _
                       & "UM.EmployeeId As DrId, UM.SPI  " _
                       & "From UserMaster UM, ConnectionMaster CM  " _
                       & "Where(UM.ClinicId = CM.ClinicCode) " _
                       & "And UM.EmployeeId =" & DrCode & " " _
                       & "And CM.ClinicCode ='" & lClinicCode & "' "


                'Dim lDa As New SqlClient.SqlDataAdapter(lQuery, lConnectionString)
                'lDa.Fill(lDs)
                If lConnection.IsTransactionAlive Then
                    lDs = lConnection.ExecuteTransactionQuery(lQuery)
                Else
                    lDs = lConnection.ExecuteQuery(lQuery)
                End If

                If lDs.Tables(0).Rows.Count > 0 Then
                    Me.ClinicID = lDs.Tables(0).Rows(0).Item("ClinicCode")
                    Me.ConnectionString = lDs.Tables(0).Rows(0).Item("ConnectionString")
                    Me.ServerIPAdress = lDs.Tables(0).Rows(0).Item("ServerIPAddress")
                    Me.DatabaseName = lDs.Tables(0).Rows(0).Item("DatabaseName")
                    Me.UserName = lDs.Tables(0).Rows(0).Item("LoginId")
                    Me.Password = lDs.Tables(0).Rows(0).Item("Password")
                    Me.ServerPortNumber = lDs.Tables(0).Rows(0).Item("ServerPortNumber")
                    Me.SPI = lDs.Tables(0).Rows(0).Item("SPI")
                    Me.DrCode = lDs.Tables(0).Rows(0).Item("DrId")
                End If

                Get_ConnectionInformation_By_DrCode = True
            Catch ex As Exception
                TraceLogging.ErrorLogMethods.LogError(ex, "SurescriptsLibrary\ConnectionMaster.Get_ConnectionInformation_By_DrCode(ByVal DrCode As String, ByVal lClinicCode As String) ")
                Get_ConnectionInformation_By_DrCode = False
            End Try

        End Function


#End Region

    End Class
End Namespace