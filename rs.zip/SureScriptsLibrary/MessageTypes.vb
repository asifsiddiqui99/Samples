Public Class MessageTypes

End Class
