Imports System.Xml
Imports System.Net
Imports System.Text
Imports System.IO
Imports System.Data.SqlClient
Imports System.Configuration
Imports ElixirLibrary
Namespace SureScripts
    Public Class SureScriptsMethods
        Public Function SendToPharmacy(ByVal header As HeaderType, ByVal pharmacy As PharmacyType, ByVal prescriber As PrescriberType, ByVal patient As PatientType, ByVal medicationprescribed As NewRXMedicationType, ByVal constr As String)
            Dim np As New NewPrescription
            'np.WriteXMLForNewPrescription("e:\\surecscripts\\", "newprescription.xml", constr)
            'SendXML("e:\\surecscripts\\newprescription.xml")
        End Function


        Private Function MakeColumns() As DataSet
            Dim ds As New DataSet
            Dim dt As New DataTable
            Dim dc As DataColumn

            Try
                ds.Tables.Add(dt)
                dc = New DataColumn("ncpdpID", System.Type.GetType("System.String"))
                ds.Tables(0).Columns.Add(dc)
                dc = New DataColumn("name", System.Type.GetType("System.String"))
                ds.Tables(0).Columns.Add(dc)
                dc = New DataColumn("address1", System.Type.GetType("System.String"))
                ds.Tables(0).Columns.Add(dc)
                dc = New DataColumn("address2", System.Type.GetType("System.String"))
                ds.Tables(0).Columns.Add(dc)
                dc = New DataColumn("city", System.Type.GetType("System.String"))
                ds.Tables(0).Columns.Add(dc)
                dc = New DataColumn("state", System.Type.GetType("System.String"))
                ds.Tables(0).Columns.Add(dc)
                dc = New DataColumn("zip", System.Type.GetType("System.String"))
                ds.Tables(0).Columns.Add(dc)
                dc = New DataColumn("fax", System.Type.GetType("System.String"))
                ds.Tables(0).Columns.Add(dc)
                dc = New DataColumn("pharmacytype", System.Type.GetType("System.String"))
                ds.Tables(0).Columns.Add(dc)
                dc = New DataColumn("status", System.Type.GetType("System.String"))
                ds.Tables(0).Columns.Add(dc)
                dc = New DataColumn("touchdate", System.Type.GetType("System.String"))
                ds.Tables(0).Columns.Add(dc)
                dc = New DataColumn("phone", System.Type.GetType("System.String"))
                ds.Tables(0).Columns.Add(dc)


            Catch ex As Exception
                Throw New Exception(ex.Message + " : SurescriptsLibrary\SurescriptsMethods.MakeColumns() ")
            End Try


            Return ds
        End Function
        
        Public Function SearchActivePharmacy(ByVal postcode As String, ByVal phone As String, ByVal street As String, ByVal pharmacy As String, ByVal state As String, ByVal ncpdpid As String, Optional ByVal city As String = "") As DataSet
            'Dim ds As DataSet = MakeColumns()
            'Dim dr As DataRow
            Dim sqlReader As SqlDataReader
            Dim lDs As DataSet

            Dim lConnection As New Connection()
            'Dim sqlCon As New SqlConnection
            'sqlCon.ConnectionString = ConfigurationSettings.AppSettings("connectionString")

            Dim whereclause As String = " Where '" + Date.Now.Date.ToString("MMM dd yyyy") + "' " _
                                      + " Between Convert(datetime,Left(AtiveStartTime,10)) " _
                                      + " And Convert(DateTime, Left(ActiveEndTime, 10)) And Provider = 'S' "

            If postcode.Trim <> "" Then
                whereclause = whereclause & " And zip='" & postcode.Replace("'", "''") & "'"
            End If
            If phone.Trim <> "" Then
                whereclause = whereclause & " and primaryphone='" & postcode.Replace("'", "''") & "'"
            End If
            If street.Trim <> "" Then
                whereclause = whereclause & " and addressline1 LIKE'%" & street.Replace("'", "''") & "%'"
            End If
            If pharmacy.Trim <> "" Then
                whereclause = whereclause & " and storename LIKE'" & pharmacy.Replace("'", "''") & "%'"
            End If
            If state.Trim <> "" Then
                whereclause = whereclause & " and state='" & state.Replace("'", "''") & "'"
            End If
            If city.Trim <> "" Then
                whereclause = whereclause & " and City LIKE'" & city.Replace("'", "''") & "%'"
            End If
            If ncpdpid.Trim <> "" Then
                whereclause = whereclause & " and ncpdpid ='" & ncpdpid.Replace("'", "''") & "'"
            End If
            Dim sqlQuery As String = "SELECT NCPDPID,Replace(StoreName,'''','&#39') AS name,AddressLine1 as address1,AddressLine2 as address2,City,State,Zip,Fax,ServiceLevel as pharmacytype,PrimaryPhone As Phone FROM Pharmacy" & whereclause & " ORDER BY StoreName"
            Try
                lDs = lConnection.ExecuteQuery(sqlQuery)
                'Dim sqlCmd As SqlCommand = New SqlCommand(sqlQuery, sqlCon)
                'sqlCmd.CommandType = CommandType.Text
                'If (sqlCon.State <> ConnectionState.Open) Then
                '    sqlCon.Open()
                'End If
                'sqlReader = sqlCmd.ExecuteReader()
                'While (sqlReader.Read())
                '    dr = ds.Tables(0).NewRow
                '    dr("ncpdpid") = sqlReader.GetString(0)
                '    dr("name") = sqlReader.GetString(1)
                '    dr("address1") = sqlReader.GetString(2)
                '    dr("address2") = sqlReader.GetString(3)
                '    dr("city") = sqlReader.GetString(4)
                '    dr("state") = sqlReader.GetString(5)
                '    dr("zip") = sqlReader.GetString(6)
                '    dr("fax") = sqlReader.GetString(7)
                '    dr("pharmacytype") = sqlReader.GetString(8)
                '    dr("status") = "Active"
                '    dr("touchdate") = "None"
                '    dr("phone") = sqlReader.GetSqlString(9)
                '    ds.Tables(0).Rows.Add(dr)
                'End While

            Catch ex As Exception
                Throw New Exception(ex.Message + " : SurescriptsLibrary\SurescriptsMethods.SearchActivePharmacy(ByVal postcode As String, ByVal phone As String, ByVal street As String, ByVal pharmacy As String, ByVal state As String, ByVal ncpdpid As String, Optional ByVal city As String ) ")
                Return Nothing
            End Try

            Return lDs

        End Function

        Public Function SearchPharmacy(ByVal postcode As String, ByVal phone As String, ByVal street As String, ByVal pharmacy As String, ByVal state As String, ByVal ncpdpid As String) As DataSet
            Dim ds As New DataSet()
            Dim sql As String
            Dim lConnection As New Connection()
            Dim whereclause As String = ""

            Try
                If postcode.Trim <> "" Then

                    whereclause = " where zip='" & postcode.Replace("'", "''") & "'"
                End If
                If phone.Trim <> "" Then
                    If whereclause.Length > 0 Then
                        whereclause = " and primaryphone='" & postcode.Replace("'", "''") & "'"
                    Else
                        whereclause = " where primaryphone='" & phone.Replace("'", "''") & "'"
                    End If
                End If
                If street.Trim <> "" Then
                    If whereclause.Length > 0 Then
                        whereclause = " and addressline1='" & street.Replace("'", "''") & "'"
                    Else
                        whereclause = " where addressline1='" & street.Replace("'", "''") & "'"
                    End If
                End If
                If pharmacy.Trim <> "" Then
                    If whereclause.Length > 0 Then
                        whereclause = " and storename='" & pharmacy.Replace("'", "''") & "'"
                    Else
                        whereclause = " where storename='" & pharmacy.Replace("'", "''") & "'"
                    End If
                End If
                If state.Trim <> "" Then
                    If whereclause.Length > 0 Then
                        whereclause = " and state='" & state.Replace("'", "''") & "'"
                    Else
                        whereclause = " where state='" & state.Replace("'", "''") & "'"
                    End If
                End If
                If ncpdpid.Trim <> "" Then
                    If whereclause.Length > 0 Then
                        whereclause = " and ncpdpid='" & ncpdpid.Replace("'", "''") & "'"
                    Else
                        whereclause = " where ncpdpid='" & ncpdpid.Replace("'", "''") & "'"
                    End If
                End If
                sql = "SELECT PharmacyID, NCPDPID, StoreName AS name, AddressLine1 as address1, AddressLine2 as address2, City, State, Zip, Fax, LastModifiedDate AS touchdate, PrimaryPhone AS phone, Email FROM Pharmacy " & whereclause & " ORDER BY StoreName"
                ds = lConnection.ExecuteQuery(sql)




            Catch ex As Exception
                Throw New Exception(ex.Message + " : SurescriptsLibrary\SurescriptsMethods.SearchPharmacy(ByVal postcode As String, ByVal phone As String, ByVal street As String, ByVal pharmacy As String, ByVal state As String, ByVal ncpdpid As String) ")
            End Try


            Return ds
        End Function

       
    End Class
End Namespace

