Imports System.Xml
Imports System.Data.SqlClient
Imports System.Configuration
Namespace SureScripts
    Public Class NewPrescription
#Region "Instance Variables"
        Private mHeader As HeaderType = New HeaderType
        Private mNewRx As NewRxType = New NewRxType
        Private mLocaldb As LocalDBType = New LocalDBType
#End Region


#Region "Properties"
        Public Property Header() As HeaderType
            Get
                Return mHeader
            End Get
            Set(ByVal Value As HeaderType)
                mHeader = Value
            End Set
        End Property
        Public Property NewRx() As NewRxType
            Get
                Return mNewRx
            End Get
            Set(ByVal Value As NewRxType)
                mNewRx = Value
            End Set
        End Property
        Public Property LocalDB() As LocalDBType
            Get
                Return mLocaldb
            End Get
            Set(ByVal Value As LocalDBType)
                mLocaldb = Value
            End Set
        End Property
#End Region


#Region "Methods"


        Private Sub GetNode(ByVal tree As XmlNode, ByVal RecMessage As SureScriptsLibrary.SureScripts.ReceivedMessage)
            Dim lName As String = tree.Name
            Select Case lName.ToUpper
                Case "TO"
                    RecMessage.HeaderType.To.MailAddress = tree.InnerText
                Case "FROM"
                    RecMessage.HeaderType.From.MailAddress = tree.InnerText
                Case "MESSAGEID"
                    RecMessage.HeaderType.MesssageID = tree.InnerText
                Case "RELATESTOMESSAGEID"
                    RecMessage.HeaderType.RelatesToMessageID = tree.InnerText
                Case "SENTTIME"
                    RecMessage.HeaderType.SentTime.UtcDate = tree.InnerText
                Case "CODE"
                    RecMessage.ErrorType.Code = tree.InnerText
                    RecMessage.StatusType.Code = tree.InnerText
                Case "DESCRIPTIONCODE"
                    RecMessage.ErrorType.DescriptionCode = tree.InnerText
                Case "DESCRIPTION"
                    RecMessage.ErrorType.Description = tree.InnerText
                Case "ERROR"
                    RecMessage.MessageType = "ERROR"
                Case "STATUS"
                    RecMessage.MessageType = "STATUS"
            End Select
        End Sub

        Public Sub ParseTree(ByVal tree As XmlNode, ByVal RecMessage As SureScriptsLibrary.SureScripts.ReceivedMessage)
            If Not (tree Is Nothing) Then
                GetNode(tree, RecMessage)
            End If
            If tree.HasChildNodes Then
                tree = tree.FirstChild
                While Not (tree Is Nothing)
                    ParseTree(tree, RecMessage)
                    tree = tree.NextSibling
                End While
            End If
        End Sub

        Public Function SaveStatus(ByVal constr As String, ByVal RecMessage As ReceivedMessage) As Boolean
            Dim con As New SqlConnection(ConfigurationSettings.AppSettings("connectionString"))
            Dim lTransaction As SqlTransaction
            Dim lQuery As String
            Dim lDs As New DataSet
            Dim lMessageCode As Integer
            Dim lStatus As Boolean
            Dim lMessageType As Integer
            Dim lMessageStatus As String
            Dim lRetries As String
            Dim lCode As String
            Dim lHdrStatus As String

            Try
                con.Open()
                lTransaction = con.BeginTransaction



                lQuery = "Select * From MessageHdr " _
                       & "Where MessageId ='" & RecMessage.HeaderType.RelatesToMessageID & "' "

                lDs = DBClass.ExecuteQuery(lQuery, lTransaction)
                If lDs.Tables(0).Rows.Count > 0 Then
                    lMessageCode = CType(lDs.Tables(0).Rows(0)("MessageCode"), Integer)
                    lHdrStatus = lDs.Tables(0).Rows(0)("LastStatus")
                End If

                If RecMessage.MessageType = "ERROR" Then
                    lMessageType = 1
                    lCode = RecMessage.ErrorType.Code
                Else
                    lMessageType = 3
                    lCode = RecMessage.StatusType.Code
                End If

                If (lCode = "601" Or lCode = "900") And (lHdrStatus <> "Success" And lHdrStatus <> "Failure") Then
                    lMessageStatus = "Failure"

                    lQuery = "Update MessageDtl Set Status = 'Failure' " _
                           & "Where Direction = 'O' " _
                           & "And DetailMessageType = 4 " _
                           & "And MessageCode = " & lMessageCode & " "

                    lStatus = DBClass.ExecuteUpdate(lQuery, lTransaction)
                    If Not lStatus Then
                        Throw New Exception
                    End If

                    lQuery = "Update MessageHdr " _
                           & "Set LastStatus ='" & lMessageStatus & "' " _
                           & "Where MessageCode = " & lMessageCode & " "

                    lStatus = DBClass.ExecuteUpdate(lQuery, lTransaction)
                    If Not lStatus Then
                        Throw New Exception
                    End If


                ElseIf (lCode = "600" Or lCode = "602") And (lHdrStatus <> "Success" And lHdrStatus <> "Failure") Then
                    lMessageStatus = "Failure"

                    lQuery = "Select Count(*) Retries " _
                           & "From MessageDtl " _
                           & "Where MessageCode = " & lMessageCode & " " _
                           & "And Direction = 'O' " _
                           & "And DetailMessageType = 4 " _
                           & "And Status = 'Pending' "

                    lDs = DBClass.ExecuteQuery(lQuery, lTransaction)
                    If lDs.Tables(0).Rows.Count > 0 Then
                        lRetries = CType(lDs.Tables(0).Rows(0)("Retries"), Integer)
                    End If

                    If lRetries >= 4 Then

                        lQuery = "Update MessageDtl Set Status = 'Failure' " _
                               & "Where Direction = 'O' " _
                               & "And DetailMessageType = 4 " _
                               & "And MessageCode = " & lMessageCode & " "

                        lStatus = DBClass.ExecuteUpdate(lQuery, lTransaction)
                        If Not lStatus Then
                            Throw New Exception
                        End If

                        lQuery = "Update MessageHdr " _
                               & "Set LastStatus ='" & lMessageStatus & "' " _
                               & "Where MessageCode = " & lMessageCode & " "

                        lStatus = DBClass.ExecuteUpdate(lQuery, lTransaction)
                        If Not lStatus Then
                            Throw New Exception
                        End If
                    Else
                        lQuery = "Update MessageDtl Set Status = 'Pending' " _
                               & "Where Direction = 'O' " _
                               & "And DetailMessageType = 4 " _
                               & "And MessageCode = " & lMessageCode & " "

                        lStatus = DBClass.ExecuteUpdate(lQuery, lTransaction)
                        If Not lStatus Then
                            Throw New Exception
                        End If

                        lQuery = "Update MessageHdr " _
                               & "Set LastStatus ='Pending' " _
                               & "Where MessageCode = " & lMessageCode & " "

                        lStatus = DBClass.ExecuteUpdate(lQuery, lTransaction)
                        If Not lStatus Then
                            Throw New Exception
                        End If

                    End If

                ElseIf lCode = "000" And (lHdrStatus <> "Success" And lHdrStatus <> "Failure") Then
                    lMessageStatus = "Success"

                    lQuery = "Update MessageDtl Set Status = 'InProgress' " _
                           & "Where Direction = 'O' " _
                           & "And LineId = (Select Max(LineId)  " _
                           & "              From MessageDtl " _
                           & "              Where MessageCode = " & lMessageCode & "  " _
                           & "              And Direction = 'O' " _
                           & "              And DetailMessageType = 4) "

                    lStatus = DBClass.ExecuteUpdate(lQuery, lTransaction)
                    If Not lStatus Then
                        Throw New Exception
                    End If


                    lQuery = "Update MessageDtl Set Status = 'Failure' " _
                           & "Where Direction = 'O' " _
                           & "And LineId <> (Select Max(LineId)  " _
                           & "                    From MessageDtl " _
                           & "                    Where MessageCode = " & lMessageCode & "  " _
                           & "	                  And Direction = 'O' " _
                           & "	                  And DetailMessageType = 4) " _
                           & "And MessageCode = " & lMessageCode & "  "

                    lStatus = DBClass.ExecuteUpdate(lQuery, lTransaction)
                    If Not lStatus Then
                        Throw New Exception
                    End If

                    lQuery = "Update MessageHdr " _
                               & "Set LastStatus ='InProgress' " _
                               & "Where MessageCode = " & lMessageCode & " "

                    lStatus = DBClass.ExecuteUpdate(lQuery, lTransaction)
                    If Not lStatus Then
                        Throw New Exception
                    End If

                    'It Should Become "Failure" or "Success" On receiving Message from Ultimate Receiver
                    'Should Be handle by Message Receiving Form.

                ElseIf lCode = "010" And (lHdrStatus <> "Success" And lHdrStatus <> "Failure") Then

                    lMessageStatus = "Success"

                    lQuery = "Update MessageDtl Set Status = 'Success' " _
                           & "Where Direction = 'O' " _
                           & "And LineId = (Select Max(LineId)  " _
                           & "              From MessageDtl " _
                           & "              Where MessageCode = " & lMessageCode & "  " _
                           & "              And Direction = 'O' " _
                           & "              And DetailMessageType = 4) "

                    lStatus = DBClass.ExecuteUpdate(lQuery, lTransaction)
                    If Not lStatus Then
                        Throw New Exception
                    End If


                    lQuery = "Update MessageDtl Set Status = 'Failure' " _
                           & "Where Direction = 'O' " _
                           & "And LineId <> (Select Max(LineId)  " _
                           & "                    From MessageDtl " _
                           & "                    Where MessageCode = " & lMessageCode & "  " _
                           & "	                  And Direction = 'O' " _
                           & "	                  And DetailMessageType = 4) " _
                           & "And MessageCode = " & lMessageCode & "  "

                    lStatus = DBClass.ExecuteUpdate(lQuery, lTransaction)
                    If Not lStatus Then
                        Throw New Exception
                    End If


                    lQuery = "Update MessageHdr " _
                           & "Set LastStatus ='" & lMessageStatus & "' " _
                           & "Where MessageCode = " & lMessageCode & " "

                    lStatus = DBClass.ExecuteUpdate(lQuery, lTransaction)
                    If Not lStatus Then
                        Throw New Exception
                    End If
                Else
                    Throw New Exception
                End If


                'lQuery = "INSERT INTO MessageDtl(MessageCode, MessageTime, " _
                '       & "Status, Code, DescriptionCode, " _
                '       & "[Description],Direction,ReceivedMessageId,DetailMessageType) " _
                '       & "VALUES(" _
                '       & " " & lMessageCode & ", " _
                '       & "'" & Left(lNodes(4), 19) & "', " _
                '       & "'" & lMessageStatus & "'," _
                '       & "'" & lNodes(5) & "'," _
                '       & "'" & lNodes(6) & "'," _
                '       & "'" & lNodes(7) & " '," _
                '       & "'I'," _
                '       & "'" & lNodes(2) & "'," _
                '       & " " & lMessageType & ")"



                lQuery = "INSERT INTO MessageDtl(MessageCode, MessageTime, " _
                       & "Status, Code, DescriptionCode, " _
                       & "[Description],Direction,ReceivedMessageId,DetailMessageType) " _
                       & "VALUES(" _
                       & " " & lMessageCode & ", " _
                       & "'" & Left(RecMessage.HeaderType.SentTime.UtcDate, 19) & "', " _
                       & "'" & lMessageStatus & "'," _
                       & "'" & lCode & "'," _
                       & "'" & RecMessage.ErrorType.DescriptionCode & "'," _
                       & "'" & RecMessage.ErrorType.Description.Replace("'", "''") & " '," _
                       & "'I'," _
                       & "'" & RecMessage.HeaderType.MesssageID & "'," _
                       & " " & lMessageType & ")"

                lStatus = DBClass.ExecuteUpdate(lQuery, lTransaction)
                If Not lStatus Then
                    Throw New Exception
                End If


                'If ErrorCode = 601 or 900 Status = failure And All others are also Failure
                'If ErrorCode = 600 or 602 Status = failure And All others will be Pending if Out is Less then 4
                'If Code = 000 Then Status = "Success" And Last One  will be "InProgress" And All Others Will be Failure
                'If Code = 010 Then Status = "Success" And Last One will be "Success And All Others Will be Failure"




                lTransaction.Commit()
                SaveStatus = lStatus

            Catch ex As Exception

                lTransaction.Rollback()
                SaveStatus = False
            Finally
                If con.State <> ConnectionState.Closed Then
                    con.Close()
                End If
            End Try

        End Function

        Public Function WriteXMLForNewPrescription(ByVal path As String, ByVal filename As String, ByVal constr As String, ByVal lMessageId As String, ByVal lRxId As String)
            Dim xmlw As XmlTextWriter
            Dim lResult As Boolean
            Try

                lResult = AddMessage(filename, lMessageId, lRxId, constr)
                If lResult = False Then
                    Throw New Exception
                End If
                xmlw = New XmlTextWriter(path & "\\" & filename, Nothing)
                xmlw.Formatting = Formatting.Indented
                'xmlw.WriteStartDocument()
                xmlw.WriteStartElement("Message")
                xmlw.WriteAttributeString("xmlns", "http://www.surescripts.com/messaging")
                xmlw.WriteAttributeString("version", "1.0")

                '' Header complex type element
                xmlw.WriteStartElement("Header")

                xmlw.WriteStartElement("To")
                xmlw.WriteString(Me.Header.To.MailAddress)
                xmlw.WriteEndElement()

                xmlw.WriteStartElement("From")
                xmlw.WriteString(Me.Header.From.MailAddress)
                xmlw.WriteEndElement()

                xmlw.WriteStartElement("MessageID")
                xmlw.WriteString(Me.Header.MesssageID)
                xmlw.WriteEndElement()

                xmlw.WriteStartElement("SentTime")
                xmlw.WriteString(Me.Header.SentTime.UtcDate)
                xmlw.WriteEndElement()

                xmlw.WriteStartElement("TestMessage")
                xmlw.WriteString("")
                xmlw.WriteEndElement()
                xmlw.WriteEndElement()
                ''' End Header Complex type




                ''' Body complex type
                xmlw.WriteStartElement("Body")
                ''' NewRx complex type
                xmlw.WriteStartElement("NewRx")
                If Me.NewRx.RxReferenceNumber <> "" Then
                    ''' RxReferenceNumber Simple type
                    xmlw.WriteStartElement("RxReferenceNumber")
                    xmlw.WriteString(Me.NewRx.RxReferenceNumber)
                    xmlw.WriteEndElement()
                    ''' End RxReferenceNumber Simple type
                End If
                ''' Pharmacy complex type
                xmlw.WriteStartElement("Pharmacy")
                ''' Identification complex type
                xmlw.WriteStartElement("Identification")
                ''' NCPDPID simple type
                xmlw.WriteStartElement("NCPDPID")
                xmlw.WriteString(Me.NewRx.Pharmacy.Identification.NCPDPID)
                xmlw.WriteEndElement()
                ''' End NCPDPID simple type
                If Me.NewRx.Pharmacy.Identification.FileID <> "" Then
                    ''' FileID simple type
                    xmlw.WriteStartElement("FileID")
                    xmlw.WriteString(Me.NewRx.Pharmacy.Identification.FileID)
                    xmlw.WriteEndElement()
                    ''' End FileID simple type
                End If
                If Me.NewRx.Pharmacy.Identification.StateLicenseNumber <> "" Then
                    ''' StateLicenseNumber simple type
                    xmlw.WriteStartElement("StateLicenseNumber")
                    xmlw.WriteString(Me.NewRx.Pharmacy.Identification.StateLicenseNumber)
                    xmlw.WriteEndElement()
                    ''' End StateLicenseNumber simple type
                End If
                If Me.NewRx.Pharmacy.Identification.MedicareNumber <> "" Then
                    ''' MedicareNumber simple type
                    xmlw.WriteStartElement("MedicareNumber")
                    xmlw.WriteString(Me.NewRx.Pharmacy.Identification.MedicareNumber)
                    xmlw.WriteEndElement()
                    ''' End MedicareNumber simple type
                End If
                If Me.NewRx.Pharmacy.Identification.MediCaidNumber <> "" Then
                    ''' MediaciadNumber simple type
                    xmlw.WriteStartElement("MedicaidNumber")
                    xmlw.WriteString(Me.NewRx.Pharmacy.Identification.MediCaidNumber)
                    xmlw.WriteEndElement()
                    ''' End MedicaidNumber simple type
                End If
                If Me.NewRx.Pharmacy.Identification.PPONumber <> "" Then
                    ''' PPONumber simple type
                    xmlw.WriteStartElement("PPONumber")
                    xmlw.WriteString(Me.NewRx.Pharmacy.Identification.PPONumber)
                    xmlw.WriteEndElement()
                    ''' End PPONumber simple type
                End If
                If Me.NewRx.Pharmacy.Identification.PayerId <> "" Then
                    ''' PayerID simple type
                    xmlw.WriteStartElement("PayerID")
                    xmlw.WriteString(Me.NewRx.Pharmacy.Identification.PayerId)
                    xmlw.WriteEndElement()
                    ''' End PayerID simple type
                End If
                If Me.NewRx.Pharmacy.Identification.BINLocationNumber <> "" Then
                    ''' BINLocationNumber simple type
                    xmlw.WriteStartElement("BINLocationNumber")
                    xmlw.WriteString(Me.NewRx.Pharmacy.Identification.BINLocationNumber)
                    xmlw.WriteEndElement()
                    ''' End BinLocationNumber simple type
                End If
                If Me.NewRx.Pharmacy.Identification.DEANumber <> "" Then
                    ''' DEANumber simple type
                    xmlw.WriteStartElement("DEANumber")
                    xmlw.WriteString(Me.NewRx.Pharmacy.Identification.DEANumber)
                    xmlw.WriteEndElement()
                    ''' End DEANumber simple type
                End If
                If Me.NewRx.Pharmacy.Identification.HIN <> "" Then
                    ''' Hin simple type
                    xmlw.WriteStartElement("HIN")
                    xmlw.WriteString(Me.NewRx.Pharmacy.Identification.HIN)
                    xmlw.WriteEndElement()
                    ''' End HIN simple type
                End If
                If Me.NewRx.Pharmacy.Identification.SecondaryCoverage <> "" Then
                    ''' SecondaryCoverage simple type
                    xmlw.WriteStartElement("SecondaryCoverage")
                    xmlw.WriteString(Me.NewRx.Pharmacy.Identification.SecondaryCoverage)
                    xmlw.WriteEndElement()
                    ''' End SecondaryCoverage simple type
                End If
                If Me.NewRx.Pharmacy.Identification.NAICode <> "" Then
                    ''' NAICode simple type
                    xmlw.WriteStartElement("NAICode")
                    xmlw.WriteString(Me.NewRx.Pharmacy.Identification.NAICode)
                    xmlw.WriteEndElement()
                    ''' End NAICode simple type
                End If
                If Me.NewRx.Pharmacy.Identification.PromotionNumber <> "" Then
                    ''' NAICode simple type
                    xmlw.WriteStartElement("NAICode")
                    xmlw.WriteString(Me.NewRx.Pharmacy.Identification.NAICode)
                    xmlw.WriteEndElement()
                    ''' End NAICode simple type
                End If
                xmlw.WriteEndElement()
                ''' End Identification complex type
                If Me.NewRx.Pharmacy.StoreName <> "" Then
                    ''' StoreName simple type
                    xmlw.WriteStartElement("StoreName")
                    xmlw.WriteString(Me.NewRx.Pharmacy.StoreName)
                    xmlw.WriteEndElement()
                    ''' End StoreName simple type
                End If
                '''' Pharmacist complex type
                'xmlw.WriteStartElement("Pharmacist")
                '''' LastName simple type
                'xmlw.WriteStartElement("LastName")
                'xmlw.WriteString(Me.NewRx.Pharmacy.Pharmacist.LastName)
                'xmlw.WriteEndElement()
                '''' End LastName simple type
                '''' FirstName simple type
                'xmlw.WriteStartElement("FirstName")
                'xmlw.WriteString(Me.NewRx.Pharmacy.Pharmacist.FirstName)
                'xmlw.WriteEndElement()
                '''' End FirstName simple type
                'xmlw.WriteEndElement()
                '''' End Pharmacist complex type
                '''' PharmacistAgent complex type
                'xmlw.WriteStartElement("PharmacistAgent")
                '''' LastName simple type
                'xmlw.WriteStartElement("LastName")
                'xmlw.WriteString(Me.NewRx.Pharmacy.PharmacistAgent.LastName)
                'xmlw.WriteEndElement()
                '''' End LastName simple type
                '''' FirstName simple type
                'xmlw.WriteStartElement("FirstName")
                'xmlw.WriteString(Me.NewRx.Pharmacy.PharmacistAgent.FirstName)
                'xmlw.WriteEndElement()
                '''' End FirstName simple type
                'xmlw.WriteEndElement()
                '''' End PharmacistAgent complex type
                ''' Address complex type
                xmlw.WriteStartElement("Address")
                ''' AddressLine1 simple type
                If Me.NewRx.Pharmacy.Address.AddressLine1 <> "" Then
                    xmlw.WriteStartElement("AddressLine1")
                    xmlw.WriteString(Me.NewRx.Pharmacy.Address.AddressLine1)
                    xmlw.WriteEndElement()
                    ''' End AddressLine1 simple type
                End If
                If Me.NewRx.Pharmacy.Address.AddressLine2 <> "" Then
                    ''' AddressLine2 simple type
                    xmlw.WriteStartElement("AddressLine2")
                    xmlw.WriteString(Me.NewRx.Pharmacy.Address.AddressLine2)
                    xmlw.WriteEndElement()
                    ''' End AddressLine2 simple type
                End If
                If Me.NewRx.Pharmacy.Address.City <> "" Then
                    ''' City simple type
                    xmlw.WriteStartElement("City")
                    xmlw.WriteString(Me.NewRx.Pharmacy.Address.City)
                    xmlw.WriteEndElement()
                    ''' End City simple type
                End If
                If Me.NewRx.Pharmacy.Address.State <> "" Then
                    ''' State simple type
                    xmlw.WriteStartElement("State")
                    xmlw.WriteString(Me.NewRx.Pharmacy.Address.State)
                    xmlw.WriteEndElement()
                    ''' End State simple type
                End If
                If Me.NewRx.Pharmacy.Address.ZipCode <> "" Then
                    ''' ZipCode simple type
                    xmlw.WriteStartElement("ZipCode")
                    xmlw.WriteString(Me.NewRx.Pharmacy.Address.ZipCode)
                    xmlw.WriteEndElement()
                    ''' End ZipCode simple type
                End If
                xmlw.WriteEndElement()
                ''' End Address complex type
                If Me.NewRx.Pharmacy.Email <> "" Then
                    ''' Email simple type
                    xmlw.WriteStartElement("Email")
                    xmlw.WriteString(Me.NewRx.Pharmacy.Email)
                    xmlw.WriteEndElement()
                    ''' End Email simple type
                End If
                Dim a As Integer = 0
                If Not Me.NewRx.Pharmacy.PhoneNumbers.Phone Is Nothing Then
                    ''' PhoneNumbers complex type
                    xmlw.WriteStartElement("PhoneNumbers")
                    For a = 0 To Me.NewRx.Pharmacy.PhoneNumbers.Phone.Length - 1
                        ''' Phone complex type
                        xmlw.WriteStartElement("Phone")
                        ''' Number simple type
                        xmlw.WriteStartElement("Number")
                        xmlw.WriteString(Me.NewRx.Pharmacy.PhoneNumbers.Phone(a).Number)
                        xmlw.WriteEndElement()
                        ''' End Number simple type
                        ''' Qualifier simple type
                        xmlw.WriteStartElement("Qualifier")
                        xmlw.WriteString(Me.NewRx.Pharmacy.PhoneNumbers.Phone(a).Qualifier)
                        xmlw.WriteEndElement()
                        ''' End Qualifier simple type
                        xmlw.WriteEndElement()
                        ''' End Phone complex type
                    Next
                    xmlw.WriteEndElement()
                    ''' End PhoneNumbers complex type
                End If
                xmlw.WriteEndElement()
                ''' End Pharmacy complex type
                ''' Prescriber complex type
                xmlw.WriteStartElement("Prescriber")
                ''' Identification complex type
                xmlw.WriteStartElement("Identification")
                ''' SPI simple type
                xmlw.WriteStartElement("SPI")
                xmlw.WriteString(Me.NewRx.Prescriber.Identification.SPI)
                xmlw.WriteEndElement()
                ''' End SPI simple type
                If Me.NewRx.Prescriber.Identification.SocialSecurity <> "" Then
                    ''' SocialSecurity simple type
                    xmlw.WriteStartElement("SocialSecurity")
                    xmlw.WriteString(Me.NewRx.Prescriber.Identification.SocialSecurity)
                    xmlw.WriteEndElement()
                    ''' End SocialSecurity simple type
                End If
                xmlw.WriteEndElement()
                ''' End Identification complex type
                ''' ClinicName simple type
                xmlw.WriteStartElement("ClinicName")
                xmlw.WriteString(Me.NewRx.Prescriber.ClinicName)
                xmlw.WriteEndElement()
                ''' End ClinicName simple type
                ''' Name complex type
                xmlw.WriteStartElement("Name")
                If Me.NewRx.Prescriber.Name.LastName <> "" Then
                    ''' LastName simple type
                    xmlw.WriteStartElement("LastName")
                    xmlw.WriteString(Me.NewRx.Prescriber.Name.LastName)
                    xmlw.WriteEndElement()
                    ''' End LastName simple type
                End If
                If Me.NewRx.Prescriber.Name.FirstName <> "" Then
                    ''' FirstName simple type
                    xmlw.WriteStartElement("FirstName")
                    xmlw.WriteString(Me.NewRx.Prescriber.Name.FirstName)
                    xmlw.WriteEndElement()
                    ''' End FirstName simple type
                End If
                If Me.NewRx.Prescriber.Name.MiddleName <> "" Then
                    ''' MiddleName simple type
                    xmlw.WriteStartElement("MiddleName")
                    xmlw.WriteString(Me.NewRx.Prescriber.Name.MiddleName)
                    xmlw.WriteEndElement()
                    ''' End MidleName simple type
                End If
                xmlw.WriteEndElement()
                ''' End Name complex type
                '''' Specialty complex type
                'xmlw.WriteStartElement("Specialty")
                '''' Qualifier simple type
                'xmlw.WriteStartElement("Qualifier")
                'xmlw.WriteString(Me.NewRx.Prescriber.Specialty.Qualifier)
                'xmlw.WriteEndElement()
                '''' End Qualifier simple type
                '''' SpecialtyCode simple type
                'xmlw.WriteStartElement("SpecialtyCode")
                'xmlw.WriteString(Me.NewRx.Prescriber.Specialty.SpecialtyCode)
                'xmlw.WriteEndElement()
                '''' End SpecialtyCode simple type
                'xmlw.WriteEndElement()
                '''' End Specialty complex type
                '''' PrescriberAgent complex type
                'xmlw.WriteStartElement("PrescriberAgent")
                '''' LastName simple type
                'xmlw.WriteStartElement("LastName")
                'xmlw.WriteString(Me.NewRx.Prescriber.PrescriberAgent.LastName)
                'xmlw.WriteEndElement()
                '''' End LastName simple type
                '''' FirstName simple type
                'xmlw.WriteStartElement("FirstName")
                'xmlw.WriteString(Me.NewRx.Prescriber.PrescriberAgent.FirstName)
                'xmlw.WriteEndElement()
                '''' End FirstName simple type
                'xmlw.WriteEndElement()
                '''' End PrescriberAgent complex type
                ''' Address complex type
                xmlw.WriteStartElement("Address")
                If Me.NewRx.Prescriber.Address.AddressLine1 <> "" Then
                    ''' AddressLine1 simple type
                    xmlw.WriteStartElement("AddressLine1")
                    xmlw.WriteString(Me.NewRx.Prescriber.Address.AddressLine1)
                    xmlw.WriteEndElement()
                    ''' End AddressLine1 simple type
                End If
                If Me.NewRx.Prescriber.Address.City <> "" Then
                    ''' City simple type
                    xmlw.WriteStartElement("City")
                    xmlw.WriteString(Me.NewRx.Prescriber.Address.City)
                    xmlw.WriteEndElement()
                    ''' End City simple type
                End If
                If Me.NewRx.Prescriber.Address.State <> "" Then
                    ''' State simple type
                    xmlw.WriteStartElement("State")
                    xmlw.WriteString(Me.NewRx.Prescriber.Address.State)
                    xmlw.WriteEndElement()
                    ''' End State simple type
                End If
                If Me.NewRx.Prescriber.Address.ZipCode <> "" Then
                    ''' ZipCode simple type
                    xmlw.WriteStartElement("ZipCode")
                    xmlw.WriteString(Me.NewRx.Prescriber.Address.ZipCode)
                    xmlw.WriteEndElement()
                    ''' End ZipCode simple type
                End If
                xmlw.WriteEndElement()
                ''' End Address complex type
                If Me.NewRx.Prescriber.Email <> "" Then
                    ''' Email simple type
                    xmlw.WriteStartElement("Email")
                    xmlw.WriteString(Me.NewRx.Prescriber.Email)
                    xmlw.WriteEndElement()
                    ''' End Email simple type
                End If
                If Not Me.NewRx.Prescriber.PhoneNumbers.Phone Is Nothing Then
                    ''' PhoneNumbers complex type
                    xmlw.WriteStartElement("PhoneNumbers")
                    For a = 0 To Me.NewRx.Prescriber.PhoneNumbers.Phone.Length - 1
                        ''' Phone complex type
                        xmlw.WriteStartElement("Phone")
                        ''' Number simple type
                        xmlw.WriteStartElement("Number")
                        xmlw.WriteString(Me.NewRx.Prescriber.PhoneNumbers.Phone(a).Number)
                        xmlw.WriteEndElement()
                        ''' End Number simple type
                        ''' Qualifier simple type
                        xmlw.WriteStartElement("Qualifier")
                        xmlw.WriteString(Me.NewRx.Prescriber.PhoneNumbers.Phone(a).Qualifier)
                        xmlw.WriteEndElement()
                        ''' End Qualifier simple type
                        xmlw.WriteEndElement()
                        ''' End Phone complex type
                    Next
                    xmlw.WriteEndElement()
                    ''' End PhoneNumbers complex type
                End If
                xmlw.WriteEndElement()
                ''' End Prescriber complex type
                ''' Patient Complex type
                xmlw.WriteStartElement("Patient")
                If Me.NewRx.Patient.Identification.SocialSecurity <> "" Then
                    ''' Identification complex type
                    xmlw.WriteStartElement("Identification")
                    ''' SocialSecurity simple type
                    xmlw.WriteStartElement("SocialSecurity")
                    xmlw.WriteString(Me.NewRx.Patient.Identification.SocialSecurity)
                    xmlw.WriteEndElement()
                    ''' End SocialSecurity simple type
                    xmlw.WriteEndElement()
                    ''' End Identification complex type
                End If
                ''' Name complex type
                xmlw.WriteStartElement("Name")
                If Me.NewRx.Patient.Name.LastName <> "" Then
                    ''' LastName simple type
                    xmlw.WriteStartElement("LastName")
                    xmlw.WriteString(Me.NewRx.Patient.Name.LastName)
                    xmlw.WriteEndElement()
                    ''' End LastName simple type
                End If
                If Me.NewRx.Patient.Name.FirstName <> "" Then
                    ''' FirstName simple type
                    xmlw.WriteStartElement("FirstName")
                    xmlw.WriteString(Me.NewRx.Patient.Name.FirstName)
                    xmlw.WriteEndElement()
                    ''' End FirstName simple type
                End If
                If Me.NewRx.Patient.Name.MiddleName <> "" Then
                    ''' MiddleName simple type
                    xmlw.WriteStartElement("MiddleName")
                    xmlw.WriteString(Me.NewRx.Patient.Name.MiddleName)
                    xmlw.WriteEndElement()
                    ''' End MidleName simple type
                End If
                xmlw.WriteEndElement()
                ''' End Name complex type

                ''' Gender simple type
                xmlw.WriteStartElement("Gender")
                xmlw.WriteString(IIf(Me.NewRx.Patient.Gender = 1, "M", "F"))
                xmlw.WriteEndElement()
                ''' End Gender simple type

                If Me.NewRx.Patient.DateOfBirth.Date <> "" Then
                    ''' DateOfBirth simple type
                    xmlw.WriteStartElement("DateOfBirth")
                    xmlw.WriteString(Me.NewRx.Patient.DateOfBirth.Date)
                    xmlw.WriteEndElement()
                    ''' End DateOfBirth simple type
                End If
                ''' Address complex type
                xmlw.WriteStartElement("Address")
                If Me.NewRx.Patient.Address.AddressLine1 <> "" Then
                    ''' AddressLine1 simple type
                    xmlw.WriteStartElement("AddressLine1")
                    xmlw.WriteString(Me.NewRx.Patient.Address.AddressLine1)
                    xmlw.WriteEndElement()
                    ''' End AddressLine1 simple type
                End If
                If Me.NewRx.Patient.Address.City <> "" Then
                    ''' City simple type
                    xmlw.WriteStartElement("City")
                    xmlw.WriteString(Me.NewRx.Patient.Address.City)
                    xmlw.WriteEndElement()
                    ''' End City simple type
                End If
                If Me.NewRx.Patient.Address.State <> "" Then
                    ''' State simple type
                    xmlw.WriteStartElement("State")
                    xmlw.WriteString(Me.NewRx.Patient.Address.State)
                    xmlw.WriteEndElement()
                    ''' End State simple type
                End If
                If Me.NewRx.Patient.Address.ZipCode <> "" Then
                    ''' ZipCode simple type
                    xmlw.WriteStartElement("ZipCode")
                    xmlw.WriteString(Me.NewRx.Patient.Address.ZipCode)
                    xmlw.WriteEndElement()
                    ''' End ZipCode simple type
                End If
                xmlw.WriteEndElement()
                ''' End Address complex type
                If Me.NewRx.Patient.Email <> "" Then
                    ''' Email simple type
                    xmlw.WriteStartElement("Email")
                    xmlw.WriteString(Me.NewRx.Patient.Email)
                    xmlw.WriteEndElement()
                    ''' End Email simple type
                End If
                If Not Me.NewRx.Patient.PhoneNumbers.Phone Is Nothing Then
                    ''' PhoneNumbers complex type
                    xmlw.WriteStartElement("PhoneNumbers")
                    For a = 0 To Me.NewRx.Patient.PhoneNumbers.Phone.Length - 1
                        ''' Phone complex type
                        xmlw.WriteStartElement("Phone")
                        ''' Number simple type
                        xmlw.WriteStartElement("Number")
                        xmlw.WriteString(Me.NewRx.Patient.PhoneNumbers.Phone(a).Number)
                        xmlw.WriteEndElement()
                        ''' End Number simple type
                        ''' Qualifier simple type
                        xmlw.WriteStartElement("Qualifier")
                        xmlw.WriteString(Me.NewRx.Patient.PhoneNumbers.Phone(a).Qualifier)
                        xmlw.WriteEndElement()
                        ''' End Qualifier simple type
                        xmlw.WriteEndElement()
                        ''' End Phone complex type
                    Next
                    xmlw.WriteEndElement()
                    ''' End PhoneNumbers complex type
                End If
                xmlw.WriteEndElement()
                ''' End Patient complex type
                ''' MediacationPrescribed complex type
                xmlw.WriteStartElement("MedicationPrescribed")
                If Me.NewRx.MedicationPrescribed.DrugDescription <> "" Then
                    ''' DrugDescription simple type
                    xmlw.WriteStartElement("DrugDescription")
                    xmlw.WriteString(Me.NewRx.MedicationPrescribed.DrugDescription)
                    xmlw.WriteEndElement()
                    ''' End DrugDescription simple type
                End If
                '''' DrugCoded complex type
                'xmlw.WriteStartElement("DrugCoded")
                '''' ProductCode simple type
                'xmlw.WriteStartElement("ProductCode")
                'xmlw.WriteString(Me.NewRx.MedicationPrescribed.DrugCoded.ProductCode)
                'xmlw.WriteEndElement()
                '''' End ProductCode simple type
                '''' ProductCodeQualifier simple type
                'xmlw.WriteStartElement("ProductCodeQualifier")
                'xmlw.WriteString(Me.NewRx.MedicationPrescribed.DrugCoded.ProductCodeQualifier)
                'xmlw.WriteEndElement()
                '''' End ProductCodeQualifier simple type
                '''' DosageForm simple type
                'xmlw.WriteStartElement("DosageForm")
                'xmlw.WriteString(Me.NewRx.MedicationPrescribed.DrugCoded.DosageForm)
                'xmlw.WriteEndElement()
                '''' End DosageForm simple type
                '''' Strength simple type
                'xmlw.WriteStartElement("Strength")
                'xmlw.WriteString(Me.NewRx.MedicationPrescribed.DrugCoded.Strength)
                'xmlw.WriteEndElement()
                '''' End Strength simple type
                '''' StrengthUnits simple type
                'xmlw.WriteStartElement("StrengthUnits")
                'xmlw.WriteString(Me.NewRx.MedicationPrescribed.DrugCoded.StrengthUnits)
                'xmlw.WriteEndElement()
                '''' End StrengthUnits simple type
                '''' DrugDBCode simple type
                'xmlw.WriteStartElement("DrugDBCode")
                'xmlw.WriteString(Me.NewRx.MedicationPrescribed.DrugCoded.DrugDBCode)
                'xmlw.WriteEndElement()
                '''' End DrugDBCode simple type
                '''' DrugDBCodeQualifier simple type
                'xmlw.WriteStartElement("DrugDBCodeQualifier")
                'xmlw.WriteString(Me.NewRx.MedicationPrescribed.DrugCoded.DrugDBCodeQualifier)
                'xmlw.WriteEndElement()
                '''' End DrugDBCodeQualifier simple type
                'xmlw.WriteEndElement()
                '''' End DrugCoded complex type

                If Me.NewRx.MedicationPrescribed.Quantity.Value <> "" Then
                    ''' Quantity complex type
                    xmlw.WriteStartElement("Quantity")
                    ''' Qualifier simple type
                    xmlw.WriteStartElement("Qualifier")
                    xmlw.WriteString(Me.NewRx.MedicationPrescribed.Quantity.Qualifier)
                    xmlw.WriteEndElement()
                    ''' End Qualifier simple type
                    ''' Value simple type
                    xmlw.WriteStartElement("Value")
                    xmlw.WriteString(Me.NewRx.MedicationPrescribed.Quantity.Value)
                    xmlw.WriteEndElement()
                    ''' End Vlaue simple type
                    xmlw.WriteEndElement()
                    ''' End Quantity complex type
                End If

                If Me.NewRx.MedicationPrescribed.DaysSupply <> "" Then
                    ''' DaysSupply simple type
                    xmlw.WriteStartElement("DaysSupply")
                    xmlw.WriteString(Me.NewRx.MedicationPrescribed.DaysSupply)
                    xmlw.WriteEndElement()
                    ''' End DaysSupply simple type
                End If
                If Me.NewRx.MedicationPrescribed.Directions <> "" Then
                    ''' Directions simple type
                    xmlw.WriteStartElement("Directions")
                    xmlw.WriteString(Me.NewRx.MedicationPrescribed.Directions)
                    xmlw.WriteEndElement()
                    ''' End Directions simple type
                End If
                If Me.NewRx.MedicationPrescribed.Note <> "" Then
                    ''' Note simple type
                    xmlw.WriteStartElement("Note")
                    xmlw.WriteString(Me.NewRx.MedicationPrescribed.Note)
                    xmlw.WriteEndElement()
                    ''' End Note simple type
                End If
                If Me.NewRx.MedicationPrescribed.Refills.Quantity <> "" Then
                    ''' Refills complex type
                    xmlw.WriteStartElement("Refills")
                    ''' Qualifier simple type
                    xmlw.WriteStartElement("Qualifier")
                    xmlw.WriteString(Me.NewRx.MedicationPrescribed.Refills.Qualifier)
                    xmlw.WriteEndElement()
                    ''' End Qualifier simple type
                    ''' Quantity simple type
                    xmlw.WriteStartElement("Quantity")
                    xmlw.WriteString(Me.NewRx.MedicationPrescribed.Refills.Quantity)
                    xmlw.WriteEndElement()
                    ''' End Quantity simple type
                    xmlw.WriteEndElement()
                    ''' End Refills complex type
                End If
                If Me.NewRx.MedicationPrescribed.Substitutions <> "" Then
                    ''' Substitutions simple type
                    xmlw.WriteStartElement("Substitutions")
                    xmlw.WriteString(Me.NewRx.MedicationPrescribed.Substitutions)
                    xmlw.WriteEndElement()
                    ''' End Substitutions simple type
                End If
                If Me.NewRx.MedicationPrescribed.WrittenDate.Date <> "" Then
                    ''' WrittenDate simple type
                    xmlw.WriteStartElement("WrittenDate")
                    xmlw.WriteString(Me.NewRx.MedicationPrescribed.WrittenDate.Date)
                    xmlw.WriteEndElement()
                    ''' End WrittenDate simple type
                End If
                xmlw.WriteEndElement()
                ''' End MedicationPrescribed complex type
                xmlw.WriteEndElement()
                ''' End NewRx complex type
                xmlw.WriteEndElement()
                ''' End Body complex type
                xmlw.WriteEndElement()
                ''' End Message complex type
                xmlw.WriteEndDocument()

            Catch ex As Exception
                Dim a As String
                a = ex.Message
            Finally
                If Not xmlw Is Nothing Then
                    xmlw.Flush()
                    xmlw.Close()
                End If
            End Try

        End Function

        Public Function AddMessage(ByVal filename As String, ByVal lMsgId As String, ByVal lRxId As String, ByVal constr As String) As Boolean
            Dim flg As Boolean = False
            Dim con As New SqlConnection(ConfigurationSettings.AppSettings("connectionString"))
            Dim lQuery As String
            Dim lTransaction As SqlTransaction
            Dim id As Integer = 0
            Dim lPharmacyCode As String = ""
            Dim lIsFailure As Boolean
            Dim lResult As Boolean
            Dim lCode As Long
            Dim lIsExist As Boolean


            Try

                If lMsgId <> "" Then
                    lIsExist = True
                Else
                    lIsExist = False
                End If

                con.Open()
                lTransaction = con.BeginTransaction
                lCode = GetMessageID(lTransaction, lMsgId, lRxId)
                If lMsgId = "" Then
                    Throw New Exception
                End If
                'lCode = GetNewCode(lTransaction)
                'If lCode = 0 Then
                '    Throw New Exception
                'End If

                Me.Header.MesssageID = lMsgId
                Me.NewRx.PrescriberOrderNumber = "RxCure-PO-" & lRxId.PadLeft(9, "0")

                'lResult = CheckDuplicateMessage(lTransaction, lMessageId, lPharmacyCode, _
                '                                "O", lIsFailure, lCode)


                If lIsExist Then
                    lResult = AddMessageDtl(lTransaction, "O", lCode)
                    If Not lResult Then
                        Throw New Exception
                    End If
                Else

                    lResult = AddMessageHdr(lTransaction, "O", lCode, filename)
                    If Not lResult Then
                        Throw New Exception
                    End If
                    lResult = AddMessageDtl(lTransaction, "O", lCode)

                    If Not lResult Then
                        Throw New Exception
                    End If
                    lResult = UpdatePatCurrent(constr, lMsgId, lRxId)
                    If Not lResult Then
                        Throw New Exception
                    End If
                End If

                'If lResult = True And lIsFailure = False Then
                '    'If Identical MessageId & PharmacyCode & Same Direction 
                '    'with Status = "Success" then CheckDuplicateMessage Returns True 
                '    'And lIsFailure = False
                '    'In This Condition It will Ignore the Message Because It was previously Sent Successfully
                '    Throw New Exception

                'ElseIf lResult = False And lIsFailure = True Then
                '    'If Identical MessageId & PharmacyCode & Same Direction 
                '    'with Status = "Failure" then lIsFailure =  True 
                '    'and CheckDuplicateMessage = False
                '    'In Failure Condition It will only add in Detail Table Not is Header Table

                '    lResult = AddMessageDtl(lTransaction, "O", lCode)
                '    If Not lResult Then
                '        Throw New Exception
                '    End If

                'ElseIf lResult = False And lIsFailure = False Then
                '    'If MessageId Not Found Then Both Will be False
                '    lResult = AddMessageHdr(lTransaction, "O", lCode, filename)
                '    If Not lResult Then
                '        Throw New Exception
                '    End If
                '    lResult = AddMessageDtl(lTransaction, "O", lCode)

                '    If Not lResult Then
                '        Throw New Exception
                '    End If
                'End If

                lTransaction.Commit()
                flg = True
            Catch ex As Exception
                lTransaction.Rollback()
                flg = False
            Finally
                If con.State <> ConnectionState.Closed Then
                    con.Close()
                End If
            End Try
            Return flg
        End Function

        Private Function UpdatePatCurrent(ByVal lClinicConnectionString As String, ByVal lMessageId As String, ByVal lRxId As String) As Boolean

            Dim lConnection As New SqlConnection(lClinicConnectionString)
            Dim lCommand As New SqlCommand
            Dim lQuery As String

            Try
                lQuery = "Update Aps_Pat_Current " _
                       & "Set MessageId ='" & lMessageId & "', " _
                       & "Send_Count = Send_Count + 1 " _
                       & "Where Rx_Id =" & Val(Right(lRxId, 9)) & " "


                lConnection.Open()
                lCommand.CommandText = lQuery
                lCommand.Connection = lConnection
                lCommand.ExecuteNonQuery()
                lConnection.Close()
                UpdatePatCurrent = True
            Catch ex As Exception
                UpdatePatCurrent = False
            End Try

        End Function
        Public Function AddMessageHdr(ByVal lTransaction As SqlTransaction, _
                                      ByVal lDirection As String, _
                                      ByVal lCode As Long, _
                                      ByVal lFileName As String) As Boolean

            Dim lStatus As Boolean
            Dim lQuery As String

            lQuery = "Insert Into MessageHdr (" _
                   & "MessageCode, MessageId, MessageTypeId, LastStatus," _
                   & "XMLPath, ClinicId, UserId, " _
                   & "PrescriberOrderNo, RxReferenceNo, " _
                   & "RelatesToMessageId, Direction, XMLContents, PharmacyCode) " _
                   & "VALUES(" _
                   & lCode & ", " _
                   & "'" & Me.Header.MesssageID & "', " _
                   & "4," _
                   & "'Pending'," _
                   & "'" & lFileName & "'," _
                   & "'" & Me.LocalDB.ClinicCode & "'," _
                   & "'" & Me.NewRx.Prescriber.Identification.SPI & "'," _
                   & "'" & Me.NewRx.PrescriberOrderNumber & "'," _
                   & "'" & Me.NewRx.RxReferenceNumber & "'," _
                   & "''," _
                   & "'" & lDirection & "', " _
                   & "'', " _
                   & "'" & Me.NewRx.Pharmacy.Identification.NCPDPID & "')"


            lStatus = DBClass.ExecuteUpdate(lQuery, lTransaction)
            AddMessageHdr = lStatus

        End Function


        Public Function AddMessageDtl(ByVal lTransaction As SqlTransaction, _
                                      ByVal lDirection As String, _
                                      ByVal lCode As Long) As Boolean

            Dim lStatus As Boolean
            Dim lQuery As String

            lQuery = "INSERT INTO MessageDtl(MessageCode, MessageTime, " _
                   & "Status, Code, DescriptionCode, " _
                   & "[Description],Direction,ReceivedMessageId, DetailMessageType) " _
                   & "VALUES(" _
                   & " " & lCode & ", " _
                   & "'" & CDate(Me.Header.SentTime.UtcDate) & "', " _
                   & "'Pending'," _
                   & "''," _
                   & "''," _
                   & "''," _
                   & "'O'," _
                   & "'',4)"

            lStatus = DBClass.ExecuteUpdate(lQuery, lTransaction)
            AddMessageDtl = lStatus

        End Function

        'Public Function AddMessage(ByVal filename As String) As Boolean
        '    Dim flg As Boolean = False
        '    Dim con As New SqlConnection(ConfigurationSettings.AppSettings("connectionString"))
        '    Dim sql As String
        '    Dim tr As SqlTransaction
        '    Dim messageid As String = "0"
        '    Dim id As Integer = 0
        '    Try
        '        con.Open()
        '        tr = con.BeginTransaction
        '        id = GetMessageID(tr)
        '        messageid = id
        '        If messageid = "0" Then
        '            Throw New Exception
        '        End If
        '        messageid = FormatMessageID(messageid)
        '        Me.Header.MesssageID = messageid
        '        sql = "INSERT INTO MessageDetail  (ID,MessageID, MessageTypeID, SentTime, SentBy, FileName, ClinicID) VALUES     (" & id & ",'" & messageid & "'," & 4 & ",'" & CDate(Me.Header.SentTime.UtcDate) & "','" & Me.LocalDB.DoctorCode & "','" & filename & "','" & Me.LocalDB.ClinicCode & "')"
        '        If DBClass.ExecuteUpdate(sql, tr) = False Then
        '            Throw New Exception
        '        End If
        '        tr.Commit()
        '        flg = True
        '    Catch ex As Exception
        '        tr.Rollback()
        '        flg = False
        '    Finally
        '        If con.State <> ConnectionState.Closed Then
        '            con.Close()
        '        End If
        '    End Try
        '    Return flg
        'End Function
        Private Function CheckDuplicateMessage(ByVal lTransaction As SqlTransaction, _
                                               ByVal lMessageId As String, _
                                               ByVal lPharmacyCode As String, _
                                               ByVal lDirection As String, _
                                               ByRef lIsFailure As Boolean, _
                                               ByRef lCode As Long) As Boolean
            'Function Returns Following Values

            'If Identical MessageId & PharmacyCode & Same Direction 
            'with Status = "Success" then CheckDuplicateMessage Returns True 
            'And lIsFailure = False

            'If Identical MessageId & PharmacyCode & Same Direction 
            'with Status = "Failure" then lIsFailure =  True 
            'and CheckDuplicateMessage = False

            'If MessageId Not Found Then Both Will be False

            Dim lDs As DataSet
            Dim lStatus As Boolean
            Dim lQuery As String
            Dim lCond As String

            If lDirection = "O" Then
                lCond = "And Direction = 'O'"
            Else
                lCond = "And Direction = 'I'"
            End If

            lQuery = "Select * From MessageHdr " _
                   & "Where MessageId ='" & lMessageId & "' " _
                   & "And PharmacyCode ='" & Me.NewRx.Pharmacy.Identification.NCPDPID & "' " _
                   & lCond

            lDs = DBClass.ExecuteQuery(lQuery, lTransaction)
            If lDs.Tables(0).Rows.Count > 0 Then
                If CType(lDs.Tables(0).Rows(0)("LastStatus"), String) = "Success" Then
                    lCode = CType(lDs.Tables(0).Rows(0)("MessageCode"), Long)
                    CheckDuplicateMessage = True
                    lIsFailure = False
                ElseIf CType(lDs.Tables(0).Rows(0)("LastStatus"), String) = "Failure" Then
                    lCode = CType(lDs.Tables(0).Rows(0)("MessageCode"), Long)
                    CheckDuplicateMessage = False
                    lIsFailure = True
                End If
            Else
                CheckDuplicateMessage = False
                lIsFailure = False
            End If

        End Function

        'Public Function GetNewCode(ByVal lTransaction As SqlTransaction) As Long
        '    Dim lDs As DataSet
        '    Dim lCode As Long
        '    Dim lQuery As String


        '    lQuery = "Select IsNull(Max(MessageCode),0) + 1  AS MessageCode From MessageHdr "
        '    lDs = DBClass.ExecuteQuery(lQuery, lTransaction)
        '    If lDs.Tables.Count > 0 Then
        '        lCode = CType(lDs.Tables(0).Rows(0)("MessageCode"), String)
        '    End If
        '    GetNewCode = lCode

        'End Function

        Public Function GetMessageID(ByVal lTransaction As SqlTransaction, ByRef lMsgId As String, ByVal lRxId As String) As String

            Dim lDs As DataSet
            Dim lMessageCode As String = ""
            Dim lMessageNo As Integer = 0
            Dim lStatus As Boolean
            Dim lQuery As String

            lRxId = "RxCure-PO-" & lRxId.PadLeft(9, "0")

            If lMsgId <> "" Then

                lQuery = "Select * From MessageHdr Where MessageId ='" & lMsgId & "' " _
                       & "And PrescriberOrderNo ='" & lRxId & "' " _
                       & "And Direction = 'O' "

                lDs = DBClass.ExecuteQuery(lQuery, lTransaction)
                If lDs.Tables.Count > 0 Then
                    If lDs.Tables(0).Rows.Count > 0 Then
                        lMessageCode = lDs.Tables(0).Rows(0).Item("MessageCode")
                    End If
                End If

            Else

                lQuery = "Select MessageIdNumeric+1 As MsgId, Prefix from NumSeries "
                lDs = DBClass.ExecuteQuery(lQuery, lTransaction)
                If lDs.Tables.Count > 0 Then
                    lMsgId = CType(lDs.Tables(0).Rows(0)("Prefix"), String) & "-" _
                           & CType(lDs.Tables(0).Rows(0)("MsgId"), String).PadLeft(10, "0")

                    lMessageNo = lDs.Tables(0).Rows(0)("MsgId")
                End If

                lQuery = "Update NumSeries Set CurrentMessageId ='" & lMsgId & "', " _
                       & "MessageIdNumeric = " & lMessageNo & " "
                lStatus = DBClass.ExecuteUpdate(lQuery, lTransaction)

                lQuery = "Select IsNull(Max(MessageCode),0) + 1  AS MessageCode From MessageHdr "
                lDs = DBClass.ExecuteQuery(lQuery, lTransaction)
                If lDs.Tables.Count > 0 Then
                    lMessageCode = CType(lDs.Tables(0).Rows(0)("MessageCode"), String)
                End If

            End If

            GetMessageID = lMessageCode
        End Function

        'Public Function GetMessageID(ByVal tr As SqlTransaction) As String

        '    Dim ds As DataSet
        '    Dim messageid As Integer = 0
        '    Dim sql As String = "select isnull(max(ID),0)+1 as md from MessageDetail"
        '    ds = DBClass.ExecuteQuery(sql, tr)
        '    If ds.Tables.Count > 0 Then
        '        messageid = ds.Tables(0).Rows(0)("md")
        '    End If
        '    Return messageid
        'End Function

        Public Function FormatMessageID(ByVal messageid As String) As String
            Dim str As String
            str = "rxcure-" & messageid.ToString.PadLeft(9, "0")
            Return str
        End Function
#End Region

    End Class
    Public Class LocalDBType
        Private mDoctorCode As String = ""
        Private mPatientCode As String = ""
        Private mClinicCode As String = ""
        Private mDrugCode As String = "'"

        Public Property DoctorCode() As String
            Get
                Return mDoctorCode
            End Get
            Set(ByVal Value As String)
                mDoctorCode = Value
            End Set
        End Property
        Public Property PatientCode() As String
            Get
                Return mPatientCode
            End Get
            Set(ByVal Value As String)
                mPatientCode = Value
            End Set
        End Property
        Public Property ClinicCode() As String
            Get
                Return mClinicCode
            End Get
            Set(ByVal Value As String)
                mClinicCode = Value
            End Set
        End Property
        Public Property DrugCode() As String
            Get
                Return mDrugCode
            End Get
            Set(ByVal Value As String)
                mDrugCode = Value
            End Set
        End Property

        
    End Class
End Namespace

