Imports Microsoft.VisualBasic
Imports System.Xml
Imports System.Net.Mail
Imports System.IO
Imports System.Configuration

#Region "Credits"
'Created By:    SHAIKH ABDUL MAJID
'Dated:     Oct, 6 2006
#End Region


''' <summary>
''' It encapsulates ErrorLog Table in RxcureMaster.
''' </summary>
''' <remarks>It Encapsulates the error details which occurs in the application.</remarks>
Public Class ErrorLogDB
#Region "Fields"
    Private mSource As String = ""  'Source of the error.
    Private mMessage As String = "" 'Error Message.
    Private mQueryString As String = "" 'Querystring Presents If any at the time of error.
    Private mTargetSite As String = "" 'Targetsite of the error.
    Private mStackTrace As String = ""
    Private mReferer As String = "" ' The complete URL of the Errorneous Page.
    Private mClinicID As String = "" 'The logged in user's ClinicID.
    Private mUserID As Integer = 0 'The Loggedin user' UserID.
    Private mOccurTime As String = "" 'Date and Time of error.
#End Region

#Region "Properties"
    ''' <summary>
    ''' Source of the error.
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property Source() As String
        Get
            Return mSource
        End Get
        Set(ByVal value As String)
            mSource = value
        End Set
    End Property
    Public Property Message() As String
        Get
            Return mMessage
        End Get
        Set(ByVal value As String)
            mMessage = value
        End Set
    End Property
    ''' <summary>
    ''' Querystring Presents If any at the time of error.
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property QueryString() As String
        Get
            Return mQueryString
        End Get
        Set(ByVal value As String)
            mQueryString = value
        End Set
    End Property
    Public Property TargetSite() As String
        Get
            Return mTargetSite
        End Get
        Set(ByVal value As String)
            mTargetSite = value
        End Set
    End Property
    Public Property StackTrace() As String
        Get
            Return mStackTrace
        End Get
        Set(ByVal value As String)
            mStackTrace = value
        End Set
    End Property

    ''' <summary>
    ''' The complete URL of the Errorneous Page.
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property Referer() As String
        Get
            Return mReferer
        End Get
        Set(ByVal value As String)
            mReferer = value
        End Set
    End Property
    ''' <summary>
    ''' The logged in user's ClinicID.
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property ClinicID() As String
        Get
            Return mClinicID
        End Get
        Set(ByVal value As String)
            mClinicID = value
        End Set
    End Property
    ''' <summary>
    ''' The logged in user's UserID.
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property UserID() As Integer
        Get
            Return mUserID
        End Get
        Set(ByVal value As Integer)
            mUserID = value
        End Set
    End Property
    ''' <summary>
    ''' Date and Time Of Error
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property OccurTime() As String
        Get
            Return mOccurTime
        End Get
        Set(ByVal value As String)
            mOccurTime = value
        End Set
    End Property

#End Region



End Class


''' <summary>
''' It contains general methods of ErrorLog Entity
''' </summary>
''' <remarks></remarks>
Public Class ErrorLog

#Region "Fields"
    Private mConnectionString As String
    Private mConnection As ElixirLibrary.Connection
    Private mErrorLog As ErrorLogDB
#End Region

#Region "Properties"
    ''' <summary>
    ''' Connectionstring to the database
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property ConnectionString() As String
        Get
            Return mConnectionString
        End Get
        Set(ByVal value As String)
            mConnectionString = value
        End Set
    End Property
    Public Property Connection() As ElixirLibrary.Connection
        Get
            Return mConnection
        End Get
        Set(ByVal value As ElixirLibrary.Connection)
            mConnection = value
        End Set
    End Property
    ''' <summary>
    ''' Encapsulated Object of ErrorLogDB
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property ErrorLog() As ErrorLogDB
        Get
            Return mErrorLog
        End Get
        Set(ByVal value As ErrorLogDB)
            mErrorLog = value
        End Set
    End Property
#End Region

#Region "Constructor"
    ''' <summary>
    ''' Creates new Conection Object based on Given Connection String 
    ''' </summary>
    ''' <param name="pConnectionString">
    ''' Contains Connection String 
    ''' </param>
    ''' <remarks>
    ''' Use when not using transaction
    ''' Must Specify Connection String other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnectionString As String)
        If pConnectionString = "" Then
            Throw New ArgumentException("ConnectionString can not be empty")
        End If

        mConnectionString = pConnectionString
        mConnection = New ElixirLibrary.Connection(mConnectionString)

    End Sub

    ''' <summary>
    ''' Assign given connection to the current Object
    ''' </summary>
    ''' <param name="pConnection">
    ''' Contains refrence to the connection object
    ''' </param>
    ''' <remarks>
    ''' Use when  using Transaction
    ''' Must Specify Connection other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnection As ElixirLibrary.Connection)
        If pConnection Is Nothing Then
            Throw New ArgumentException("Connection can not be empty")
        End If

        mConnection = pConnection
    End Sub

    ''' <summary>
    ''' Uses Default Connection String 
    ''' </summary>
    ''' <remarks>
    ''' 
    ''' Created because ErrorLog Table is in RxCureMaster Database
    ''' </remarks>
    Sub New()
        mConnectionString = ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString()
        mConnection = New ElixirLibrary.Connection(mConnectionString)
    End Sub
#End Region

#Region "Methods"
    ''' <summary>
    ''' It Logs the error in the database as well as in the textfile
    ''' </summary>
    ''' <param name="ex">Exception Object</param>
    ''' <param name="u">Uer Object which is saved in session</param>
    ''' <param name="ErrorPageurl">The page complete URL on which the error occurs</param>
    ''' <remarks>It assumes you set these keys in web.config.
    ''' "LogErrors" value="true" (If you set it other than "true" than it will no longer log the errors).
    ''' "SendEmail" value="true" (if you set it other than "true" it will not send email).
    ''' "emailAddresses" value="SOME VALID EMAIL ADDRESS".
    ''' "smtpServer" value="SMTPSERVER".
    ''' "fromEmail" value="admin@rxcure.com".
    ''' "ErrorLogPath" value="[YOURDRIVE]:\rxcurelogs\errors\".
    '''</remarks>
    Public Sub HandleError(ByVal ex As Exception, ByVal u As Object, ByVal ErrorPageurl As String)

        Dim el As New ErrorLogDB

        If ErrorPageurl Is Nothing Then
            ErrorPageurl = String.Empty
        End If


        Dim dt1 As DateTime = Date.Now
        Dim data As String
        Try
            el.Source = ex.Source
            el.Message = ex.Message
            el.QueryString = "N/A"
            el.TargetSite = ex.TargetSite.ToString
            el.StackTrace = ex.StackTrace
            el.Referer = ErrorPageurl
            el.ClinicID = "5001" 'u.ClinicId
            el.UserID = 1 'u.UserId 
            el.OccurTime = dt1
            Me.ErrorLog = el
            Me.InsertRecord()
        Catch ex2 As Exception
            Dim a2 As String = ex2.Message
        Finally
        End Try
        data = "<b>Message</b> " & el.Message & ".<br><b>Stack Trace:</b> " & el.StackTrace & ".<br><b>Source:</b> " & el.Source & ".<br><b>Target Site:</b> " & el.TargetSite & ".<br><b>QueryString:</b> " & el.QueryString & ".<br><b>Referer:</b> " & el.Referer & "<br><br><br><b>UserID:</b> " & el.UserID & "<br><b>ClinicID:</b> " & el.ClinicID & "<br><b>Date:</b> " & el.OccurTime
        WriteInLogFile(ConfigurationManager.AppSettings("ErrorLogPath").ToString, ErrorLog)
        If ConfigurationManager.AppSettings("SendEmail").ToString <> "true" Then
            Exit Sub
        End If
        SendEmail(data)
    End Sub
    ''' <summary>
    ''' It sends email containing Error information. 
    ''' </summary>
    ''' <param name="body">Body of the email message (HTML formatted).</param>
    ''' <remarks></remarks>
    Private Sub SendEmail(ByVal body As String)
        Dim smtp As New SmtpClient
        Dim strEmails As String = System.Configuration.ConfigurationManager.AppSettings("emailAddresses").ToString

        If strEmails.Length > 0 Then
            Dim emails As String() = strEmails.Split(Convert.ToChar("|"))
            Dim msg As MailMessage = New MailMessage
            Dim fromAddress As New MailAddress(System.Configuration.ConfigurationManager.AppSettings("fromEmail").ToString, "Rxcure Admin")
            msg.IsBodyHtml = True
            msg.To.Add(emails(0))
            Dim i As Integer = 1
            While i < emails.Length
                msg.CC.Add(emails(i))
                System.Math.Min(System.Threading.Interlocked.Increment(i), i - 1)
            End While
            msg.From = fromAddress
            msg.Subject = "Rxcure Application error!"
            msg.Body = body
            smtp.Host = System.Configuration.ConfigurationManager.AppSettings("smtpServer").ToString
            smtp.Port = 25
            Try
                smtp.Send(msg)
            Catch excm As Exception
                Dim a As String = excm.Message
            End Try
        Else
            Return
        End If

    End Sub

    ''' <summary>
    ''' It wrties the error in the log file.
    ''' </summary>
    ''' <param name="path">Path of the file.</param>
    ''' <param name="pErrorlogDB">ErrorLogDB Object containing the error detail.</param>
    ''' <remarks>The name of the file is [current date].txt</remarks>
    Private Sub WriteInLogFile(ByVal path As String, ByVal pErrorlogDB As ErrorLogDB)
        Dim content As String = "Message " & pErrorlogDB.Message & ".<br>Stack Trace: " & pErrorlogDB.StackTrace & ".<br>Source: " & pErrorlogDB.Source & ".<br>Target Site: " & pErrorlogDB.TargetSite & ".<br>QueryString: " & pErrorlogDB.QueryString & ".<br>Referer: " & pErrorlogDB.Referer & "<br><br><br>UserID: " & pErrorlogDB.UserID & "<br>ClinicID: " & pErrorlogDB.ClinicID & "<br>Date: " & pErrorlogDB.OccurTime
        Dim lClinicId As String = ""
        Dim lPath As String = ""
        content = content.Replace("<br>", Microsoft.VisualBasic.vbCrLf)
        lClinicId = pErrorlogDB.ClinicID
        lPath = path
        Dim di As New DirectoryInfo(Left(lPath, lPath.Length - 1))
        If di.Exists = False Then
            di.Create()
        End If
        Dim tw As TextWriter = New StreamWriter(lPath & "\" & Date.Now.Date.ToString("ddMMyyyy") & ".txt", True)
        Try
            tw.WriteLine(content)
        Catch ex As Exception
        Finally
            tw.Close()
        End Try
    End Sub
    ''' <summary>
    ''' It inserts the error log in the database.
    ''' </summary>
    ''' <remarks>It creates XML and then call stored procedure.</remarks>
    Private Sub InsertRecord()
        Dim lXmlDocument As New XmlDocument
        Dim lXmlElement As XmlElement
        lXmlDocument.LoadXml("<ErrorLogs></ErrorLogs>")
        lXmlElement = lXmlDocument.CreateElement("ErrorLog")

        With lXmlElement
            .SetAttribute("Source", ErrorLog.Source)
            .SetAttribute("Message", ErrorLog.Message)
            .SetAttribute("Querystring", ErrorLog.QueryString)
            .SetAttribute("TargetSite", ErrorLog.TargetSite)
            .SetAttribute("StackTrace", ErrorLog.StackTrace)
            .SetAttribute("Referer", ErrorLog.Referer)
            .SetAttribute("ClinicID", ErrorLog.ClinicID)
            .SetAttribute("UserID", ErrorLog.UserID)
            .SetAttribute("OccurTime", ErrorLog.OccurTime)
        End With

        lXmlDocument.DocumentElement.AppendChild(lXmlElement.CloneNode(True))
        If Connection.IsTransactionAlive() Then
            Connection.ExecuteTransactionCommand("InsertErrorLog", lXmlDocument.InnerXml.ToString)
        Else
            Connection.ExecuteCommand("InsertErrorLog", lXmlDocument.InnerXml.ToString)
        End If
    End Sub
#End Region
End Class
