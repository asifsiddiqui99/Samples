Imports Microsoft.VisualBasic
Imports System
Imports System.Data
Imports ElixirLibrary
Imports System.Xml




Public Class TraceLoggingDB


#Region "Fields"

    Private mMessageID As String
    Private mMessageType As String
    Private mPrescriberID As String
    Private mRxHubMessageXML As String = ""
    Private mRxHubMessageEDI As String = ""
    Private mSureScriptXML As String
    Private mRelatesToMessageID As String
    Private mLoggingDate As String


#End Region

#Region "Properties"
 Public Property MessageID() As String
        Get
            Return mMessageID
        End Get
        Set(ByVal value As String)
            mMessageID = value
        End Set
    End Property
    Public Property MessageType() As String
        Get
            Return mMessageType
        End Get
        Set(ByVal value As String)
            mMessageType = value
        End Set
    End Property
    Public Property PrescriberID() As String
        Get
            Return mPrescriberID
        End Get
        Set(ByVal value As String)
            mPrescriberID = value
        End Set
    End Property

    Public Property RxHubMessageXML() As String
        Get
            Return mRxHubMessageXML
        End Get
        Set(ByVal value As String)
            mRxHubMessageXML = value
        End Set
    End Property

    Public Property RxHubMessageEDI() As String
        Get
            Return mRxHubMessageEDI
        End Get
        Set(ByVal value As String)
            mRxHubMessageEDI = value
        End Set
    End Property

    Public Property SureScriptXML() As String
        Get
            Return mSureScriptXML
        End Get
        Set(ByVal value As String)
            mSureScriptXML = value
        End Set
    End Property

    Public Property RelatesToMessageID() As String
        Get
            Return mRelatesToMessageID
        End Get
        Set(ByVal value As String)
            mRelatesToMessageID = value
        End Set

    End Property

     Public Property LoggingDate() As String
        Get
            Return mLoggingDate
        End Get
        Set(ByVal value As String)
            mLoggingDate = value
        End Set
    End Property



#End Region
End Class
Public Class TraceLogging

#Region "Fields"
    Private mConnection As Connection
    Private mConnectionString
    Private mTraceLogging As New TraceLoggingDB
#End Region

#Region "Property"
    Public ReadOnly Property Connection() As Connection
        Get
            Return mConnection
        End Get
    End Property

    Public ReadOnly Property ConnectionString() As String
        Get
            Return mConnectionString
        End Get
    End Property
    Public Property TraceLogging() As TraceLoggingDB
        Get
            Return mTraceLogging
        End Get
        Set(ByVal value As TraceLoggingDB)
            mTraceLogging = value
        End Set
    End Property
#End Region

#Region "Constructor"
    ''' <summary>
    ''' Creates new Conection Object based on Given Connection String 
    ''' </summary>
    ''' <param name="pConnectionString">
    ''' Contains Connection String 
    ''' </param>
    ''' <remarks>
    ''' Use when not using transaction
    ''' Must Specify Connection String other wise exception will be thrown
    ''' </remarks>
    ''' 

    Public Sub New()
        mConnection = New Connection
    End Sub

    Public Sub New(ByVal pConnectionString As String)
        If pConnectionString = "" Then
            Throw New ArgumentException("ConnectionString can not be empty")
        End If

        mConnectionString = pConnectionString
        mConnection = New Connection(mConnectionString)

    End Sub

    ''' <summary>
    ''' Assign given connection to the current Object
    ''' </summary>
    ''' <param name="pConnection">
    ''' Contains refrence to the connection object
    ''' </param>
    ''' <remarks>
    ''' Use when  using Transaction
    ''' Must Specify Connection other wise exception will be thrown
    ''' </remarks>
    Public Sub New(ByVal pConnection As Connection)
        If pConnection Is Nothing Then
            Throw New ArgumentException("Connection can not be empty")
        End If

        mConnection = pConnection
    End Sub
#End Region

Public Sub InsertRecord()
           Dim lQuery As String
         lQuery = "INSERT INTO SureScriptTraceLogging(MessageID, MessageType, " _
                   & "PrescriberID,SureScriptXML," _
                   & "RelatesToMessageID,LoggingDate) " _
                   & "VALUES(" _
                   & "'" & TraceLogging.MessageID & "', " _
                   & "'" & TraceLogging.MessageType & "', " _
                   & "'" & TraceLogging.PrescriberID & "'," _
                   & "'" & TraceLogging.SureScriptXML & " '," _
                   & "'" & TraceLogging.RelatesToMessageID & " '," _
                   & "'" & TraceLogging.LoggingDate & "')"

        If Connection.IsTransactionAlive Then
            Connection.ExecuteTransactionCommand(lQuery)
        Else
            Connection.ExecuteCommand(lQuery)
        End If


    End Sub



    Public Function InsertServiceHeader(ByVal pServerHeader As ServiceHeaderDB) As Integer

        Dim lQuery As String = String.Empty

        Try

            lQuery = "INSERT INTO ServiceLogHdr(LogDate, ClientID, " _
           & "SPI,TransactionType," _
           & "TransactionData,Direction) " _
           & "VALUES(" _
           & "'" & Date.Now & "', " _
           & "'" & pServerHeader.ClientID & "', " _
           & "'" & pServerHeader.SPI & "'," _
           & "'" & pServerHeader.TransactionType & " '," _
           & "'" & pServerHeader.TransactionData & " '," _
           & "'" & pServerHeader.Direction & "')   select @@identity "



            If Connection.IsTransactionAlive Then
                InsertServiceHeader = Connection.ExecuteTransactionScalarCommand(lQuery)
            Else
                InsertServiceHeader = Connection.ExecuteScalarCommand(lQuery)
            End If


        Catch ex As Exception
            InsertServiceHeader = 0
        End Try
    End Function


    Public Sub InsertServiceDetail(ByVal pServiceDetail As ServiceDetailDB)

        Dim lQuery As String = String.Empty

        Try

            lQuery = "INSERT INTO ServiceLogDtl(LogID, StatusCode, " _
           & "Description,MessageID," _
           & "LogTime) " _
           & "VALUES(" _
           & "'" & pServiceDetail.LogID & "', " _
           & "'" & pServiceDetail.StatusCode & "', " _
           & "'" & pServiceDetail.Description & "'," _
           & "'" & pServiceDetail.MessageID & " '," _
           & "'" & DateTime.Now & "')"



            If Connection.IsTransactionAlive Then
                Connection.ExecuteTransactionCommand(lQuery)
            Else
                Connection.ExecuteCommand(lQuery)
            End If


        Catch ex As Exception

        End Try
    End Sub

End Class



Public Class ServiceHeaderDB

    Private mLogID As Integer
    Private mLogDate As DateTime
    Private mClientID As String
    Private mSPI As String
    Private mTransactionType As String
    Private mTransactionData As String
    Private mDirection As String

    Public Property Direction As String
        Get
            Return mDirection
        End Get
        Set(ByVal value As String)
            mDirection = value
        End Set
    End Property

    Public Property TransactionData As String
        Get
            Return mTransactionData
        End Get
        Set(ByVal value As String)
            mTransactionData = value
        End Set
    End Property

    Public Property TransactionType As String
        Get
            Return mTransactionType
        End Get
        Set(ByVal value As String)
            mTransactionType = value
        End Set
    End Property

    Public Property SPI As String
        Get
            Return mSPI
        End Get
        Set(ByVal value As String)
            mSPI = value
        End Set
    End Property

    Public Property ClientID As String
        Get
            Return mClientID
        End Get
        Set(ByVal value As String)
            mClientID = value
        End Set
    End Property

    Public Property LogDate As DateTime
        Get
            Return mLogDate
        End Get
        Set(ByVal value As DateTime)
            mLogDate = value
        End Set
    End Property

End Class

Public Class ServiceDetailDB
    Private mLineID As Integer
    Private mLogID As Integer
    Private mStatusCode As String
    Private mDescription As String
    Private mMessageID As String
    Private mLogTime As DateTime


    Public Property LogID As Integer
        Get
            Return mLogID
        End Get
        Set(ByVal value As Integer)
            mLogID = value
        End Set
    End Property

    Public Property StatusCode As String
        Get
            Return mStatusCode
        End Get
        Set(ByVal value As String)
            mStatusCode = value
        End Set
    End Property

    Public Property Description As String
        Get
            Return mDescription
        End Get
        Set(ByVal value As String)
            mDescription = value
        End Set
    End Property

    Public Property MessageID As String
        Get
            Return mMessageID
        End Get
        Set(ByVal value As String)
            mMessageID = value
        End Set
    End Property

    Public Property LogTime As DateTime
        Get
            Return mLogTime
        End Get
        Set(ByVal value As DateTime)
            mLogTime = value
        End Set
    End Property


End Class