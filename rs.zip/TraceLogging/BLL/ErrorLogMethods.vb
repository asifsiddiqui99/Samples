Imports Microsoft.VisualBasic


Public Class ErrorLogMethods

    Public Shared Sub LogError(ByVal pEx As Exception, ByVal pPageUri As String)

        Dim lErrorLog As New ErrorLog
        'Dim lUser As User


        Try

            'lUser = CType(HttpContext.Current.Session("User"), User)
            lErrorLog.HandleError(pEx, New Object, pPageUri)
        Catch ex As Exception

        End Try

    End Sub

End Class

