Imports Microsoft.VisualBasic


'THIS USER OBJECT HAS BEEN REPLICATED HERE FROM RXCURE SO THAT THE SESSION USER CAN BE RETRIEVED
Public Class User

#Region "Fields"
    Private mUserId As Integer
    Private mLoginId As String
    Private mClinicId As String
    Private mConnectionString As String
    Private mLoginDateTime As String
    Private mTheme As String
    Private mIsDoctor As String
    Private mScreeningEnabled As Boolean

    'This was added by Faraz for the display name on the masterpage
    Private mFirstName As String
    Private mSecondName As String
    Private mLastName As String
#End Region

#Region "Property"

    Public Property LastName() As String
        Get
            Return mLastName
        End Get
        Set(ByVal value As String)
            mLastName = value
        End Set
    End Property

    Public Property SecondName() As String
        Get
            Return mSecondName
        End Get
        Set(ByVal value As String)
            mSecondName = value
        End Set
    End Property

    Public Property FirstName() As String
        Get
            Return mFirstName
        End Get
        Set(ByVal value As String)
            mFirstName = value
        End Set
    End Property


    Public Property UserId() As Integer
        Get
            Return mUserId
        End Get
        Set(ByVal value As Integer)
            mUserId = value
        End Set
    End Property

    Public Property LoginId() As String
        Get
            Return mLoginId
        End Get
        Set(ByVal value As String)
            mLoginId = value
        End Set
    End Property

    Public Property ClinicId() As String
        Get
            Return mClinicId
        End Get
        Set(ByVal value As String)
            mClinicId = value
        End Set
    End Property

    Public Property ConnectionString() As String
        Get
            Return mConnectionString
        End Get
        Set(ByVal value As String)
            mConnectionString = value
        End Set
    End Property

    Public Property LoginDateTime() As String
        Get
            Return mLoginDateTime
        End Get
        Set(ByVal value As String)
            mLoginDateTime = value
        End Set
    End Property

    Public Property Theme() As String
        Get
            Return mTheme
        End Get
        Set(ByVal value As String)
            mTheme = value
        End Set
    End Property

    Public Property IsDoctor() As String
        Get
            Return mIsDoctor
        End Get
        Set(ByVal value As String)
            mIsDoctor = value
        End Set
    End Property

    Public Property ScreeningEnabled() As Boolean
        Get
            Return mScreeningEnabled
        End Get
        Set(ByVal value As Boolean)
            mScreeningEnabled = value
        End Set
    End Property
#End Region


End Class


