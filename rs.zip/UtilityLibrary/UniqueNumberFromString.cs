﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UtilityLibrary
{
    public class UniqueNumberFromString
    {
        const int MUST_BE_LESS_THAN = 100000000; // 8 decimal digits

        public static int GetUniqueNumberFromString(string s)
        {
            uint hash = 0;
            int result = 0;
            // if you care this can be done much faster with unsafe 
            // using fixed char* reinterpreted as a byte*
            foreach (byte b in System.Text.Encoding.Unicode.GetBytes(s))
            {
                hash += b;
                hash += (hash << 10);
                hash ^= (hash >> 6);
            }
            // final avalanche
            hash += (hash << 3);
            hash ^= (hash >> 11);
            hash += (hash << 15);
            // helpfully we only want positive integer < MUST_BE_LESS_THAN
            // so simple truncate cast is ok if not perfect
            result = (int)(hash % MUST_BE_LESS_THAN);
            return result;
        }
    }
}
