Imports Microsoft.VisualBasic
Imports System
Imports System.Data
Imports System.Configuration
Imports System.Web
Imports System.Security.Cryptography
Imports System.IO
Imports System.Text
Imports System.Collections.Specialized

Public Class Encryption

#Region "Constants"

    Private Const QUERY_STRING_DELIMITER As Char = "&"c

#End Region

#Region "Members"

    Private Shared _cryptoProvider As RijndaelManaged

    Private Shared ReadOnly Key As Byte() = {3, 4, 5, 0, 0, 3, _
    5, 6, 3, 4, 4, 0, _
    2, 0, 2, 8}
    Private Shared ReadOnly IV As Byte() = {3, 4, 4, 0, 2, 0, _
    2, 8, 3, 4, 5, 0, _
    0, 3, 5, 6}

#End Region

#Region "Constructor"

    Shared Sub New()
        _cryptoProvider = New RijndaelManaged()
        _cryptoProvider.Mode = CipherMode.CBC
        _cryptoProvider.Padding = PaddingMode.PKCS7
    End Sub

#End Region

#Region "Methods"


    Public Shared Function Encrypt(ByVal unencryptedString As String) As String
        Dim bytIn As Byte() = ASCIIEncoding.ASCII.GetBytes(unencryptedString)


        Dim ms As New MemoryStream()


        Dim cs As New CryptoStream(ms, _cryptoProvider.CreateEncryptor(Key, IV), CryptoStreamMode.Write)


        cs.Write(bytIn, 0, bytIn.Length)
        cs.FlushFinalBlock()

        Dim bytOut As Byte() = ms.ToArray()
        Return Convert.ToBase64String(bytOut)
    End Function


    Public Shared Function Decrypt(ByVal encryptedString As String) As String
        If encryptedString.Trim().Length <> 0 Then

            Dim bytIn As Byte() = Convert.FromBase64String(encryptedString)


            Dim ms As New MemoryStream(bytIn, 0, bytIn.Length)


            Dim cs As New CryptoStream(ms, _cryptoProvider.CreateDecryptor(Key, IV), CryptoStreamMode.Read)


            Dim sr As New StreamReader(cs)

            Return sr.ReadToEnd()
        Else
            Return ""
        End If
    End Function

    


    
#End Region
End Class
