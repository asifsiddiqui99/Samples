Imports System.Data.SqlClient
Imports System.Configuration
Imports System.Data

#Region "Credits"
'Create By    : Asif Siddiqui
'Creation Date: 20-Jul-2006
#End Region


Public Enum CommandTypeEnum As Integer
    Text = 1
    StoredProcedure = 4
End Enum



Public Class Connection

#Region "Fields"
    Private mConnectionString As String
    Private mConnection As New SqlConnection
    Private mTransaction As SqlTransaction
#End Region


#Region "Constructors"

    Sub New()
        mConnectionString = ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString()
    End Sub

    Sub New(ByVal pConnectionString As String)
        If pConnectionString.Trim() = "" Then
            Throw New ArgumentException()
        End If
        mConnectionString = pConnectionString
    End Sub

#End Region

#Region "Property"

    Public ReadOnly Property ConnectionString() As String
        Get
            Return mConnectionString
        End Get
    End Property

    Private Property Connection() As SqlConnection
        Get
            Return mConnection
        End Get
        Set(ByVal value As SqlConnection)
            mConnection = value
        End Set
    End Property

    Private Property Transaction() As SqlTransaction
        Get
            Return mTransaction
        End Get
        Set(ByVal value As SqlTransaction)
            mTransaction = value
        End Set
    End Property
#End Region


#Region "Methods"


    Public Sub ExecuteTransactionCommand(ByVal pQuery As String)
        'Purpose: Method will execute Inline Query through Open Transaction

        Dim lCommand As New SqlCommand

        lCommand.Connection = Transaction.Connection
        lCommand.Transaction = Transaction
        lCommand.CommandText = pQuery
        lCommand.ExecuteNonQuery()


    End Sub

    Public Sub ExecuteTransactionCommand(ByVal pSpName As String, ByVal pParameterXML As String)
        'Purpose: Method will execute Stored Procedure through Open Transaction
        '         and takes Procedure Name and XML String as Parameter

        Dim lCommand As New SqlCommand
        Dim lSqlParameter As SqlParameter

        lCommand.Connection = Transaction.Connection
        lCommand.Transaction = Transaction

        lCommand.CommandText = pSpName
        lCommand.CommandType = CommandType.StoredProcedure
        lSqlParameter = New SqlParameter("@ParamXML", SqlDbType.NText)
        lSqlParameter.Value = pParameterXML
        lCommand.Parameters.Add(lSqlParameter)
        lCommand.ExecuteNonQuery()

    End Sub

    Public Sub ExecuteTransactionCommand(ByVal pSpName As String, ByVal pParameters As SpParameter())
        'Purpose: Method will execute Stored Procedure through Open Transaction
        '         and takes Procedure Name and SpParameter type array as Parameter 

        Dim lCommand As New SqlCommand
        Dim lSqlParameter As SqlParameter
        Dim lCounter As Integer

        lCommand.Connection = Transaction.Connection
        lCommand.Transaction = Transaction

        lCommand.CommandText = pSpName
        lCommand.CommandType = CommandType.StoredProcedure

        For lCounter = 0 To pParameters.Length() - 1
            If pParameters(lCounter).ParameterName <> "" Then
                lSqlParameter = New SqlParameter(pParameters(lCounter).ParameterName, pParameters(lCounter).ParameterType)
                lSqlParameter.Value = pParameters(lCounter).ParameterValue
                lCommand.Parameters.Add(lSqlParameter)
            End If
        Next
        lCommand.ExecuteNonQuery()

    End Sub

    'THIS IS CREATED BECAUSE I NEEDED TO PASS PARAMETERS TO INLINE QUERIES 
    Public Sub ExecuteTransactionCommand(ByVal pText As String, ByVal pParameters As SpParameter(), ByVal pType As CommandTypeEnum)
        'Purpose: Method will execute Stored Procedure through Open Transaction
        '         and takes Procedure Name and SpParameter type array as Parameter 

        Dim lCommand As New SqlCommand
        Dim lSqlParameter As SqlParameter
        Dim lCounter As Integer

        lCommand.Connection = Transaction.Connection
        lCommand.Transaction = Transaction

        lCommand.CommandText = pText
        lCommand.CommandType = pType

        For lCounter = 0 To pParameters.Length() - 1
            If pParameters(lCounter).ParameterName <> "" Then
                lSqlParameter = New SqlParameter(pParameters(lCounter).ParameterName, pParameters(lCounter).ParameterType)
                lSqlParameter.Value = pParameters(lCounter).ParameterValue
                lCommand.Parameters.Add(lSqlParameter)
            End If
        Next
        lCommand.ExecuteNonQuery()

    End Sub


    Public Function ExecuteReportQuery(ByVal pQuery As String, ByVal pTableName As String) As DataSet
        'Purpose: Method will execute Inline Query through Open Connection
        '         without Transaction and Return Dataset

        Dim lCommand As New SqlCommand
        Dim lAdapter As SqlDataAdapter
        Dim lDataSet As New DataSet()

        Try


            OpenConnection()
            lCommand.Connection = Connection
            lCommand.CommandText = pQuery

            lAdapter = New SqlDataAdapter(lCommand)
            lAdapter.Fill(lDataSet, pTableName)
        Catch ex As Exception
            Throw
        Finally
            CloseConnection()
        End Try

        Return lDataSet

    End Function


    Public Function ExecuteQuery(ByVal pSpName As String, ByVal pParameters As SpParameter(), ByVal pTableName As String) As DataSet
        'Purpose: Method will execute Stored Procedure through Open Connection
        '         and takes Procedure Name and SpParameter type array and Table Name as Parameter
        '         and Return Dataset
        '         Developed By Asif For Reporting Purpose

        Dim lCommand As New SqlCommand
        Dim lSqlParameter As SqlParameter
        Dim lAdapter As SqlDataAdapter
        Dim lDataSet As New DataSet
        Dim lCounter As Integer

        Try
            OpenConnection()
            lCommand.Connection = Connection

            lCommand.CommandText = pSpName
            lCommand.CommandType = CommandType.StoredProcedure

            For lCounter = 0 To pParameters.Length() - 1
                If pParameters(lCounter).ParameterName <> "" Then
                    lSqlParameter = New SqlParameter(pParameters(lCounter).ParameterName, pParameters(lCounter).ParameterType)
                    lSqlParameter.Value = pParameters(lCounter).ParameterValue
                    lCommand.Parameters.Add(lSqlParameter)
                End If
            Next

            lAdapter = New SqlDataAdapter(lCommand)
            lAdapter.Fill(lDataSet, pTableName)

        Catch ex As Exception
            Throw
        Finally
            CloseConnection()
        End Try

        Return lDataSet

    End Function

    Public Function ExecuteTransactionQuery(ByVal pSpName As String, ByVal pParameters As SpParameter(), ByVal pTableName As String) As DataSet
        'Purpose: Method will execute Stored Procedure through Open Transaction
        '         and takes Procedure Name and SpParameter type array and Table Name as Parameter 
        '         and Return Dataset
        '         Developed By Asif For Reporting Purpose

        Dim lCommand As New SqlCommand
        Dim lSqlParameter As SqlParameter
        Dim lAdapter As SqlDataAdapter
        Dim lDataSet As New DataSet
        Dim lCounter As Integer

        lCommand.Connection = Transaction.Connection
        lCommand.Transaction = Transaction

        lCommand.CommandText = pSpName
        lCommand.CommandType = CommandType.StoredProcedure

        For lCounter = 0 To pParameters.Length() - 1
            If pParameters(lCounter).ParameterName <> "" Then
                lSqlParameter = New SqlParameter(pParameters(lCounter).ParameterName, pParameters(lCounter).ParameterType)
                lSqlParameter.Value = pParameters(lCounter).ParameterValue
                lCommand.Parameters.Add(lSqlParameter)
            End If
        Next

        lAdapter = New SqlDataAdapter(lCommand)
        lAdapter.Fill(lDataSet, pTableName)

        Return lDataSet

    End Function



    '' By Fareed For Schedular Requirement
    Public Sub ExecuteTransactionCommand(ByVal pCommand As SqlCommand)
        'Purpose: Method will execute Stored Procedure through Open Transaction
        '         and takes Procedure Name and SpParameter type array as Parameter 

        ' Dim lCommand As New SqlCommand
        ' Dim lSqlParameter As SqlParameter
        'Dim lCounter As Integer

        pCommand.Connection = Transaction.Connection
        pCommand.Transaction = Transaction

        'lCommand.CommandText = pSpName
        'lCommand.CommandType = CommandType.StoredProcedure

        'For lCounter = 0 To pParameters.Length() - 1
        '    If pParameters(lCounter).ParameterName <> "" Then
        '        lSqlParameter = New SqlParameter(pParameters(lCounter).ParameterName, pParameters(lCounter).ParameterType)
        '        lSqlParameter.Value = pParameters(lCounter).ParameterValue
        '        lCommand.Parameters.Add(lSqlParameter)
        '    End If
        'Next
        pCommand.ExecuteNonQuery()

    End Sub

    Public Function ExecuteTransactionQuery(ByVal pQuery As String) As DataSet
        'Purpose: Method will execute Inline Query through Open Transaction
        '         and Return Dataset

        Dim lCommand As New SqlCommand
        Dim lAdapter As SqlDataAdapter
        Dim lDataSet As New DataSet()


        lCommand.Connection = Transaction.Connection
        lCommand.Transaction = Transaction

        lCommand.CommandText = pQuery

        lAdapter = New SqlDataAdapter(lCommand)
        lAdapter.Fill(lDataSet)

        Return lDataSet

    End Function

    Public Function ExecuteTransactionQuery(ByVal pSpName As String, ByVal pParameterXML As String) As DataSet
        'Purpose: Method will execute Stored Procedure through Open Transaction
        '         and takes Procedure Name and XML String as Parameter 
        '         and Return Dataset

        Dim lCommand As New SqlCommand
        Dim lAdapter As SqlDataAdapter
        Dim lSqlParameter As SqlParameter
        Dim lDataSet As New DataSet

        lCommand.Connection = Transaction.Connection
        lCommand.Transaction = Transaction

        lCommand.CommandText = pSpName
        lCommand.CommandType = CommandType.StoredProcedure

        lSqlParameter = New SqlParameter("@ParamXML", SqlDbType.NText)
        lSqlParameter.Value = pParameterXML
        lCommand.Parameters.Add(lSqlParameter)
        lAdapter = New SqlDataAdapter(lCommand)
        lAdapter.Fill(lDataSet)

        Return lDataSet

    End Function

    Public Function ExecuteTransactionQuery(ByVal pSpName As String, ByVal pParameters As SpParameter()) As DataSet
        'Purpose: Method will execute Stored Procedure through Open Transaction
        '         and takes Procedure Name and SpParameter type array as Parameter 
        '         and Return Dataset

        Dim lCommand As New SqlCommand
        Dim lSqlParameter As SqlParameter
        Dim lAdapter As SqlDataAdapter
        Dim lDataSet As New DataSet
        Dim lCounter As Integer

        lCommand.Connection = Transaction.Connection
        lCommand.Transaction = Transaction

        lCommand.CommandText = pSpName
        lCommand.CommandType = CommandType.StoredProcedure

        For lCounter = 0 To pParameters.Length() - 1
            If pParameters(lCounter).ParameterName <> "" Then
                lSqlParameter = New SqlParameter(pParameters(lCounter).ParameterName, pParameters(lCounter).ParameterType)
                lSqlParameter.Value = pParameters(lCounter).ParameterValue
                lCommand.Parameters.Add(lSqlParameter)
            End If
        Next

        lAdapter = New SqlDataAdapter(lCommand)
        lAdapter.Fill(lDataSet)

        Return lDataSet

    End Function
    '' By Fareed for Schedular Requirement
    Public Function ExecuteTransactionQuery(ByVal pCommand As SqlCommand) As DataSet
        'Purpose: Method will execute Stored Procedure through Open Transaction
        '         and takes SqlCommand as Parameter 
        '         and Return Dataset

        Dim lAdapter As SqlDataAdapter
        Dim lDataSet As New DataSet


        pCommand.Connection = Transaction.Connection
        pCommand.Transaction = Transaction



        lAdapter = New SqlDataAdapter(pCommand)
        lAdapter.Fill(lDataSet)

        Return lDataSet

    End Function

    'Public Function ExecuteTransactionScalarQuery(ByVal pSpName As String, ByVal pParameters As SpParameter())
    '    'Purpose: Method will execute Stored Procedure through Open Transaction
    '    '         and takes Procedure Name and SpParameter type array as Parameter and returns Output

    '    Dim lCommand As New SqlCommand
    '    Dim lSqlParameter As SqlParameter
    '    Dim lCounter As Integer

    '    lCommand.Connection = Transaction.Connection
    '    lCommand.Transaction = Transaction

    '    lCommand.CommandText = pSpName
    '    lCommand.CommandType = CommandType.StoredProcedure

    '    For lCounter = 0 To pParameters.Length() - 1
    '        If pParameters(lCounter).ParameterName <> "" Then
    '            lSqlParameter = New SqlParameter(pParameters(lCounter).ParameterName, pParameters(lCounter).ParameterType)
    '            lSqlParameter.Value = pParameters(lCounter).ParameterValue
    '            lCommand.Parameters.Add(lSqlParameter)
    '        End If
    '    Next
    '    Return lCommand.ExecuteScalar()

    'End Function

    Public Function ExecuteTransactionScalarCommand(ByVal pSpName As String, ByVal pParameterXML As String) As Object
        'Purpose: Method will execute Stored Procedure through Open Transaction
        '         and takes Procedure Name and XML String as Parameter

        Dim lCommand As New SqlCommand
        Dim lSqlParameter As SqlParameter
        Dim lReturnValue As Object

        lCommand.Connection = Transaction.Connection
        lCommand.Transaction = Transaction

        lCommand.CommandText = pSpName
        lCommand.CommandType = CommandType.StoredProcedure
        lSqlParameter = New SqlParameter("@ParamXML", SqlDbType.NText)
        lSqlParameter.Value = pParameterXML
        lCommand.Parameters.Add(lSqlParameter)

        lReturnValue = lCommand.ExecuteScalar()

        Return lReturnValue

    End Function

    Public Function ExecuteTransactionScalarCommand(ByVal pSpName As String, ByVal pParameters As SpParameter()) As Object
        Dim lCommand As New SqlCommand
        Dim lSqlParameter As SqlParameter
        Dim lCounter As Integer
        Dim lReturnValue As Object

        lCommand.Connection = Transaction.Connection
        lCommand.Transaction = Transaction

        lCommand.CommandText = pSpName
        lCommand.CommandType = CommandType.StoredProcedure

        For lCounter = 0 To pParameters.Length() - 1
            If pParameters(lCounter).ParameterName <> "" Then
                lSqlParameter = New SqlParameter(pParameters(lCounter).ParameterName, pParameters(lCounter).ParameterType)
                lSqlParameter.Value = pParameters(lCounter).ParameterValue
                lCommand.Parameters.Add(lSqlParameter)
            End If
        Next
        lReturnValue = lCommand.ExecuteScalar()

        Return lReturnValue

    End Function

    Public Function ExecuteTransactionScalarCommand(ByVal pQuery As String) As Object

        Dim lCommand As New SqlCommand
        Dim lReturnValue As Object

        lCommand.Connection = Transaction.Connection
        lCommand.Transaction = Transaction
        lCommand.CommandText = pQuery
        lCommand.ExecuteScalar()

        lReturnValue = lCommand.ExecuteScalar()

        Return lReturnValue

    End Function

    Public Sub ExecuteCommand(ByVal pQuery As String)
        'Purpose: Method will execute Inline Query through Open Connection
        '         without Transaction

        Dim lCommand As New SqlCommand

        Try
            OpenConnection()
            lCommand.Connection = Connection
            lCommand.CommandText = pQuery
            lCommand.ExecuteNonQuery()
        Catch ex As Exception
            Throw
        Finally
            CloseConnection()
        End Try

    End Sub

    Public Sub ExecuteCommand(ByVal pSpName As String, ByVal pParameterXML As String)
        'Purpose: Method will execute Stored Procedure through Open Connection
        '         and takes Procedure Name and XML String as Parameter

        Dim lCommand As New SqlCommand
        Dim lSqlParameter As SqlParameter

        Try
            OpenConnection()
            lCommand.Connection = Connection

            lCommand.CommandText = pSpName
            lCommand.CommandType = CommandType.StoredProcedure

            lSqlParameter = New SqlParameter("@ParamXML", SqlDbType.NText)
            lSqlParameter.Value = pParameterXML
            lCommand.Parameters.Add(lSqlParameter)
            lCommand.ExecuteNonQuery()
        Catch ex As Exception
            Throw
        Finally
            CloseConnection()
        End Try

    End Sub

    Public Sub ExecuteCommand(ByVal pSpName As String, ByVal pParameters As SpParameter())
        'Purpose: Method will execute Stored Procedure through Open Connection
        '         and takes Procedure Name and SpParameter type array as Parameter 


        Dim lCommand As New SqlCommand
        Dim lSqlParameter As SqlParameter
        Dim lCounter As Integer

        Try

            OpenConnection()
            lCommand.Connection = Connection

            lCommand.CommandText = pSpName
            lCommand.CommandType = CommandType.StoredProcedure

            For lCounter = 0 To pParameters.Length() - 1
                If pParameters(lCounter).ParameterName <> "" Then
                    lSqlParameter = New SqlParameter(pParameters(lCounter).ParameterName, pParameters(lCounter).ParameterType)
                    lSqlParameter.Value = pParameters(lCounter).ParameterValue
                    lCommand.Parameters.Add(lSqlParameter)
                End If
            Next
            lCommand.ExecuteNonQuery()

        Catch ex As Exception
            Throw
        Finally
            CloseConnection()
        End Try

    End Sub


    'CREATED BY: FARAZ
    'THE PURPOSE IS TO PROVIDE THE FLEXIBILITY OF COMMANDT TYPE AS I NEEDED TO PASS PARAMETERS TO A INLINE QUERY
    Public Sub ExecuteCommand(ByVal pText As String, ByVal pParameters As SpParameter(), ByVal pType As CommandTypeEnum)
        'Purpose: Method will execute Stored Procedure through Open Connection
        '         and takes Procedure Name and SpParameter type array as Parameter 


        Dim lCommand As New SqlCommand
        Dim lSqlParameter As SqlParameter
        Dim lCounter As Integer

        Try

            OpenConnection()
            lCommand.Connection = Connection

            lCommand.CommandText = pText
            lCommand.CommandType = pType

            For lCounter = 0 To pParameters.Length() - 1
                If pParameters(lCounter).ParameterName <> "" Then
                    lSqlParameter = New SqlParameter(pParameters(lCounter).ParameterName, pParameters(lCounter).ParameterType)
                    lSqlParameter.Value = pParameters(lCounter).ParameterValue
                    lCommand.Parameters.Add(lSqlParameter)
                End If
            Next
            lCommand.ExecuteNonQuery()

        Catch ex As Exception
            Throw
        Finally
            CloseConnection()
        End Try

    End Sub

    Public Function ExecuteScalarCommand(ByVal pSpName As String, ByVal pParameterXML As String) As Object
        Dim lCommand As New SqlCommand
        Dim lSqlParameter As SqlParameter
        Dim lReturnValue As Object

        Try
            OpenConnection()
            lCommand.Connection = Connection

            lCommand.CommandText = pSpName
            lCommand.CommandType = CommandType.StoredProcedure

            lSqlParameter = New SqlParameter("@ParamXML", SqlDbType.NText)
            lSqlParameter.Value = pParameterXML
            lCommand.Parameters.Add(lSqlParameter)
            lReturnValue = lCommand.ExecuteScalar()

        Catch ex As Exception
            Throw
        Finally
            CloseConnection()
        End Try
        Return lReturnValue

    End Function

    Public Function ExecuteScalarCommand(ByVal pSpName As String, ByVal pParameters As SpParameter()) As Object
        Dim lCommand As New SqlCommand
        Dim lSqlParameter As SqlParameter
        Dim lCounter As Integer
        Dim lReturnValue As Object

        Try

            OpenConnection()
            lCommand.Connection = Connection

            lCommand.CommandText = pSpName
            lCommand.CommandType = CommandType.StoredProcedure

            For lCounter = 0 To pParameters.Length() - 1
                If pParameters(lCounter).ParameterName <> "" Then
                    lSqlParameter = New SqlParameter(pParameters(lCounter).ParameterName, pParameters(lCounter).ParameterType)
                    lSqlParameter.Value = pParameters(lCounter).ParameterValue
                    lCommand.Parameters.Add(lSqlParameter)
                End If
            Next
            lReturnValue = lCommand.ExecuteScalar()

        Catch ex As Exception
            Throw
        Finally
            CloseConnection()
        End Try

        Return lReturnValue

    End Function

    Public Function ExecuteScalarCommand(ByVal pQuery As String) As Object
        Dim lCommand As New SqlCommand
        Dim lReturnValue As Object

        Try
            OpenConnection()
            lCommand.Connection = Connection
            lCommand.CommandText = pQuery
            lReturnValue = lCommand.ExecuteScalar()
        Catch ex As Exception
            Throw
        Finally
            CloseConnection()
        End Try

        Return lReturnValue

    End Function

    Public Function ExecuteQuery(ByVal pQuery As String) As DataSet
        'Purpose: Method will execute Inline Query through Open Connection
        '         without Transaction and Return Dataset

        Dim lCommand As New SqlCommand
        Dim lAdapter As SqlDataAdapter
        Dim lDataSet As New DataSet()

        Try


            OpenConnection()
            lCommand.CommandTimeout = 60
            lCommand.Connection = Connection

            lCommand.CommandText = pQuery

            lAdapter = New SqlDataAdapter(lCommand)
            lAdapter.Fill(lDataSet)
        Catch ex As Exception
            Throw
        Finally
            CloseConnection()
        End Try

        Return lDataSet

    End Function

    Public Function ExecuteQuery(ByVal pSpName As String, ByVal pParameterXML As String) As DataSet
        'Purpose: Method will execute Stored Procedure through Open Connection
        '         and takes Procedure Name and XML String as Parameter 
        '         and Return Dataset

        Dim lCommand As New SqlCommand
        Dim lAdapter As SqlDataAdapter
        Dim lSqlParameter As SqlParameter
        Dim lDataSet As New DataSet

        Try

            OpenConnection()
            lCommand.Connection = Connection

            lCommand.CommandText = pSpName
            lCommand.CommandType = CommandType.StoredProcedure

            lSqlParameter = New SqlParameter("@ParamXML", SqlDbType.NText)
            lSqlParameter.Value = pParameterXML
            lCommand.Parameters.Add(lSqlParameter)
            lAdapter = New SqlDataAdapter(lCommand)
            lAdapter.Fill(lDataSet)

        Catch ex As Exception
            Throw
        Finally
            CloseConnection()
        End Try

        Return lDataSet

    End Function
    ''By Fareed For Schedular Requirement
    Public Function ExecuteQuery(ByVal pCommand As SqlCommand) As DataSet
        'Purpose: Method will execute Inline Query through Open Connection
        '         without Transaction and Return Dataset

        Dim lCommand As New SqlCommand
        Dim lAdapter As SqlDataAdapter
        Dim lDataSet As New DataSet()

        Try


            OpenConnection()
            pCommand.Connection = Connection
            'lCommand.CommandText = pQuery

            lAdapter = New SqlDataAdapter(pCommand)
            lAdapter.Fill(lDataSet)
        Catch ex As Exception
            Throw
        Finally
            CloseConnection()
        End Try

        Return lDataSet

    End Function


    Public Function ExecuteQuery(ByVal pSpName As String, ByVal pParameters As SpParameter()) As DataSet
        'Purpose: Method will execute Stored Procedure through Open Connection
        '         and takes Procedure Name and SpParameter type array as Parameter 
        '         and Return Dataset

        Dim lCommand As New SqlCommand
        Dim lSqlParameter As SqlParameter
        Dim lAdapter As SqlDataAdapter
        Dim lDataSet As New DataSet
        Dim lCounter As Integer

        Try
            OpenConnection()
            lCommand.Connection = Connection

            lCommand.CommandText = pSpName
            lCommand.CommandType = CommandType.StoredProcedure

            For lCounter = 0 To pParameters.Length() - 1
                If pParameters(lCounter).ParameterName <> "" Then
                    lSqlParameter = New SqlParameter(pParameters(lCounter).ParameterName, pParameters(lCounter).ParameterType)
                    lSqlParameter.Value = pParameters(lCounter).ParameterValue
                    lCommand.Parameters.Add(lSqlParameter)
                End If
            Next

            lAdapter = New SqlDataAdapter(lCommand)
            lAdapter.Fill(lDataSet)

        Catch ex As Exception
            Throw
        Finally
            CloseConnection()
        End Try

        Return lDataSet

    End Function



    Public Function ExecuteScalarQuery(ByVal pSpName As String, ByVal pParameters As SpParameter())
        'Purpose: Method will execute Stored Procedure through Open Connection
        '         and takes Procedure Name and SpParameter type array as Parameter 


        Dim lCommand As New SqlCommand
        Dim lSqlParameter As SqlParameter
        Dim lCounter As Integer

        Try

            OpenConnection()
            lCommand.Connection = Connection

            lCommand.CommandText = pSpName
            lCommand.CommandType = CommandType.StoredProcedure

            For lCounter = 0 To pParameters.Length() - 1
                If pParameters(lCounter).ParameterName <> "" Then
                    lSqlParameter = New SqlParameter(pParameters(lCounter).ParameterName, pParameters(lCounter).ParameterType)
                    lSqlParameter.Value = pParameters(lCounter).ParameterValue
                    lCommand.Parameters.Add(lSqlParameter)
                End If
            Next
            Return lCommand.ExecuteScalar()

        Catch ex As Exception
            Throw
        Finally
            CloseConnection()
        End Try

    End Function


    Public Sub BeginTrans()
        'Purpose: Opens New Transaction

        OpenConnection()
        Transaction = Connection.BeginTransaction()

    End Sub

    Public Sub BeginTrans_ReadCommitted()
        'Purpose: Opens New Transaction

        OpenConnection()
        Transaction = Connection.BeginTransaction(IsolationLevel.ReadCommitted)


    End Sub

    Public Sub CommitTrans()
        'Purpose: Commits Transaction and Close opened Connection

        Transaction.Commit()
        CloseConnection()
        Transaction = Nothing

    End Sub

    Public Sub RollBackTrans()
        'Purpose: RollBack Transaction and Close opened Connection

        Transaction.Rollback()
        CloseConnection()
        Transaction = Nothing

    End Sub

    Public Function GetDatabaseName() As String
        Dim lDatabaseName As String

        OpenConnection()
        lDatabaseName = Connection.Database
        CloseConnection()

        Return lDatabaseName

    End Function

    Public Function IsTransactionAlive() As Boolean
        If Not Transaction Is Nothing Then
            Return True
        Else
            Return False
        End If
    End Function

    Private Sub OpenConnection()
        'Purpose: Private Function use to Open Connection internally
        '         function is made inorder to reduce code repetation

        Connection.ConnectionString = ConnectionString

        Connection.Open()

    End Sub

    Private Sub CloseConnection()
        'Purpose: Private Function use to Close Connection if opened previously 
        '         function is made inorder to reduce code repetation

        If Connection.State <> ConnectionState.Closed Then
            Connection.Close()
        End If

    End Sub



#End Region
End Class


