

#Region "Credits"
'Create By    : Asif Siddiqui
'Creation Date: 20-Jul-2006
#End Region

Public Enum ParameterType As Integer
    BigInt = 0
    [Char] = 3
    DateTime = 4
    Float = 6
    Int = 8
    NChar = 10
    NText = 11
    NVarchar = 12
    Real = 13
    SmallDateTime = 15
    SmallInt = 16
    Text = 18
    Varchar = 22
    [Variant] = 23
    Xml = 25
    Image = 7
End Enum

Public Structure SpParameter
    Private mParameterName As String
    Private mParameterType As ParameterType
    Private mParameterValue As Object


    Public Property ParameterName() As String
        Get
            Return mParameterName
        End Get
        Set(ByVal value As String)
            mParameterName = value
        End Set
    End Property

    Public Property ParameterType() As ParameterType
        Get
            Return mParameterType
        End Get
        Set(ByVal value As ParameterType)
            mParameterType = value
        End Set
    End Property

    Public Property ParameterValue() As Object
        Get
            Return mParameterValue
        End Get
        Set(ByVal value As Object)
            mParameterValue = value
        End Set
    End Property

End Structure
