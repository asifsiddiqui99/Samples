Imports System.Security.Cryptography
Imports System.Text

Public Class Hash

#Region "Methods"




    Public Shared Function GetHashedText(ByVal str As String) As String
        Dim ObjUEncode As New UnicodeEncoding()
        Dim HashValue As Byte()
        Dim strBytes As Byte() = ObjUEncode.GetBytes(str)

        Dim strHex As String = ""
        Dim objSHAHash As New SHA256Managed
        HashValue = objSHAHash.ComputeHash(strBytes)
        For Each b As Byte In HashValue
            strHex &= String.Format("{0:x2}", b)
        Next
        Return strHex
    End Function

    Public Shared Function CompareHash(ByVal pStr1 As String, ByVal pStr2 As String) As Boolean
        If GetHashedText(pStr1) = GetHashedText(pStr2) Then
            Return True
        Else
            Return False
        End If
    End Function



#End Region

End Class
