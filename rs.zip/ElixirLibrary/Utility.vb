Imports System.Web.UI.WebControls
Imports System.Text
Imports Telerik.WebControls
Imports System.IO
Imports System.Security.Cryptography

Public Class Utility

#Region "Credits"
    'Create By    : Asif Siddiqui
    'Creation Date: 20-Jul-2006
#End Region

#Region "Methods"
    ''' <summary>
    ''' It is  used to Adjust the Apostrophie.
    ''' </summary>
    ''' <param name="pText">It Takes String that contains apostrophie as argument</param>
    ''' <returns>Adjusted String</returns>
    ''' <remarks>
    ''' Function Replace any Apostrophie Character from given string 
    ''' with double Apostrophies
    ''' </remarks>
    Public Shared Function AdjustApostrophie(ByVal pText As String) As String

        Try
            pText = pText.Replace("'", "''")
            Return pText

        Catch ex As Exception
            Throw New Exception(ex.Message + " : ElixirLibrary\Utility.AdjustApostrophie(ByVal pText As String) ")
        End Try


    End Function

    ''' <summary>
    ''' It is  used to Adjust the Apostrophie.
    ''' </summary>
    ''' <param name="pControlColl">
    ''' It takes Controls Collection 
    ''' </param>
    ''' <remarks>
    ''' Function Replace any Apostrophie Character from given controls Collection 
    ''' with double Apostrophies
    ''' </remarks>
   

    ''' <summary>
    ''' Adds onChange Attribute on Each TextBox in given controls Collection, Which change the text in textbox to UpperCase 
    ''' </summary>
    ''' <param name="pControlColl">
    ''' It takes Controls Collection 
    ''' </param>
    ''' <remarks>
    ''' Should not use for pages that use Password field
    ''' </remarks>
   

    ''' <summary>
    ''' Set the Focus on given Control 
    ''' </summary>
    ''' <param name="pControl">
    ''' Control which is to be focused
    ''' </param>
    ''' <remarks></remarks>
   

    ''' <summary>
    ''' Clear All Fields in the given Collection
    ''' </summary>
    ''' <param name="pControlColl">
    ''' It takes Controls Collection 
    ''' </param>
    ''' <remarks></remarks>
    

    ''' <summary>
    ''' Used to Enable or Disable Fields
    ''' </summary>
    ''' <param name="pControlColl">
    '''  It takes Controls Collection 
    ''' </param>
    ''' <param name="pIsEnable">
    ''' Specify whether to Enable or Dessabe the Controls
    ''' </param>
    ''' <remarks>
    ''' True means Enable all Fields
    ''' False means Disable all Fields
    ''' </remarks>
   

    ''' <summary>
    ''' Select the given Item in the DropDown List
    ''' </summary>
    ''' <param name="pDdlDropDownList">
    ''' Dropdownlist of which item is to be selected
    ''' </param>
    ''' <param name="pValue">
    ''' value that is to be selected
    ''' </param>
    ''' <remarks></remarks>
    

    ''' <summary>
    ''' Select the given Item in the RadioButtonList List
    ''' </summary>
    ''' <param name="pRdlRadioButtonList">
    ''' RadioButtonList of which item is to be selected
    ''' </param>
    ''' <param name="pValue">
    ''' value that is to be selected
    ''' </param>
    ''' <remarks></remarks>
    

    ''' <summary>
    ''' Removes any Special Character from SSN
    ''' </summary>
    ''' <param name="pSSN">
    ''' String that Contains SSN
    ''' </param>
    ''' <returns>
    ''' Numeric SSN String 
    ''' </returns>
    ''' <remarks>
    ''' Used when sending prescription through SureScripts
    ''' </remarks>
    Public Shared Function ChangeSSNFormat(ByVal pSSN As String) As String

        Dim lIndex As Integer
        Dim lFormatedString As String = ""

        If pSSN = Nothing Then
            Return ""
        End If
        If pSSN.Length = 0 Then
            Return ""
        End If

        For lIndex = 0 To pSSN.Length - 1
            If IsNumeric(pSSN.Substring(lIndex, 1)) Then
                lFormatedString = lFormatedString & pSSN.Substring(lIndex, 1)
            End If
        Next

        Return lFormatedString

    End Function

    ''' <summary>
    ''' Removes any Special Character from Phone and Removes Country Code
    ''' </summary>
    ''' <param name="pPhoneNumber">
    ''' String that Contains Phone
    ''' </param>
    ''' <returns>
    ''' Numeric Phone String 
    ''' </returns>
    ''' <remarks>
    ''' Used when sending prescription through SureScripts
    ''' </remarks>
    Public Shared Function ChangePhoneFormat(ByVal pPhoneNumber As String) As String
        'Purpose: Function Removes any Special Character from Phone Number
        '         and also removes Country Code
        '         Used when sending prescription through SureScripts

        Dim lIndex As Integer
        Dim lFormatedString As String = ""


        For lIndex = 0 To pPhoneNumber.Length - 1
            If IsNumeric(pPhoneNumber.Substring(lIndex, 1)) Then
                lFormatedString = lFormatedString & pPhoneNumber.Substring(lIndex, 1)
            End If
        Next
        If lFormatedString.Length > 10 Then
            lFormatedString = Right(lFormatedString, 10)
        End If
        Return lFormatedString

    End Function

    ''' <summary>
    ''' Change the case of the text into pascal case
    ''' </summary>
    ''' <param name="pText">
    ''' String which is to be converted
    ''' </param>
    ''' <returns>
    ''' String in Pascal Case  
    ''' </returns>
    ''' <remarks>
    ''' Works on Server Side
    ''' </remarks>
    Public Shared Function ChangeCase(ByVal pText As String) As String

        Dim lWords() As String
        Dim lCounter As Integer
        Dim lPascalString As String = ""
        pText = pText.Trim()

        If pText.Length > 0 Then
            lWords = pText.Trim().Split(" ")
            For lCounter = 0 To lWords.Length() - 1
                If lWords(lCounter).Trim.Length > 0 Then
                    lPascalString += Left(lWords(lCounter), 1).ToUpper() & Right(lWords(lCounter), lWords(lCounter).Length - 1).ToLower() & " "
                End If
            Next
        End If

        Return lPascalString.Trim()

    End Function

    ''' <summary>
    ''' Function Returns Current Date in UTC format
    ''' </summary>
    ''' <returns>
    ''' Current Date in UTC format
    ''' </returns>
    ''' <remarks></remarks>
    Public Shared Function GetUTCDate() As String
        'Purpose: 

        Return DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fZ")

    End Function

    ''' <summary>
    ''' Converts Date into British Date Format
    ''' </summary>
    ''' <param name="pDate">
    ''' String Date which is to be converted
    ''' </param>
    ''' <param name="pSeprator">
    ''' Specify either - or /
    ''' </param>
    ''' <returns>
    ''' Converted Date 
    ''' </returns>
    ''' <remarks></remarks>
    Public Shared Function ToBritishDate(ByVal pDate As Date, ByVal pSeprator As String) As String

        Dim lBritishDate As String

        If Not (pSeprator = "/" Or pSeprator = "-" Or pSeprator = "") Then
            Throw New ArgumentException("Incorect Seprator")
        End If

        lBritishDate = pDate.ToString("dd" & pSeprator & "MM" & pSeprator & "yyyy")

        Return lBritishDate

    End Function

    ''' <summary>
    ''' Converts Date into US Date Format
    ''' </summary>
    ''' <param name="pDate">
    ''' String Date which is to be converted
    ''' </param>
    ''' <param name="pSeprator">
    ''' Specify either - or /
    ''' </param>
    ''' <returns>
    ''' Converted Date 
    ''' </returns>
    ''' <remarks></remarks>
    Public Shared Function ToUSDate(ByVal pDate As Date, ByVal pSeprator As String) As String

        Dim lUSDate As String

        If Not (pSeprator = "/" Or pSeprator = "-") Then
            Throw New ArgumentException("Incorect Seprator")
        End If

        lUSDate = pDate.ToString("MM" & pSeprator & "dd" & pSeprator & "yyyy")

        Return lUSDate

    End Function

    

    Public Shared Function CalculateAge(ByVal lDate1 As String) As Integer

        Dim lAge As Long

        Try
            lAge = DateDiff(DateInterval.Day, CType(lDate1, Date), Date.Now)
        Catch ex As Exception
            Throw New Exception(ex.Message + " : ElixirLibrary\Utility.CalculateAge(ByVal lDate1 As String) ")
        End Try


        Return lAge

    End Function

    

    'This function gets the text from an XML file
    Public Shared Function GetTextFromXMLFile(ByVal pFile As String) As String
        Dim lStreamReader As StreamReader = Nothing
        Dim lText As String = ""

        Try
            lStreamReader = New StreamReader(pFile)
            lText = lStreamReader.ReadToEnd()
        Catch ex As Exception
            Throw New Exception(ex.Message + " : Elixirlibrary\Utility.GetTextFromXMLFile(ByVal pFile As String) ")
        Finally
            If Not lStreamReader Is Nothing Then
                lStreamReader.Close()
            End If
        End Try
        Return lText

    End Function

    Public Shared Function GetUTF(ByVal pText As String) As String

        Dim lBytes As Byte()
        Dim lChars As String = pText
        Dim lUtf8 As UTF8Encoding = New UTF8Encoding
        Dim lResult As String
        Try
            lBytes = lUtf8.GetBytes(lChars)
            lResult = System.Convert.ToBase64String(lBytes)
        Catch ex As Exception
            Throw New Exception(ex.Message + " : Elixirlibrary\Utility.GetUTF(ByVal pText As String) ")
            lResult = ""
        End Try

        Return lResult

    End Function

    Public Shared Function CompadeData(ByVal lDs As DataSet, ByVal lArrayList As ArrayList) As ArrayList
        Dim lExcludeArray As New ArrayList()
        Dim lIndex As Integer

        For Each lDr As DataRow In lDs.Tables(0).Rows
            lIndex = lArrayList.IndexOf(lDr.Item("DDId"))
            If lIndex < 0 Then
                lExcludeArray.Add(lDr.Item("DDId"))
            Else
                lArrayList.RemoveAt(lIndex)
            End If
        Next

        Return lExcludeArray

    End Function

    
    Public Shared Function Encrypt(ByVal stringToEncrypt As String, _
            ByVal SEncryptionKey As String) As String
        Dim key() As Byte = {}
        Dim IV() As Byte = {&H12, &H34, &H56, &H78, &H90, &HAB, &HCD, &HEF}

        Try
            key = System.Text.Encoding.UTF8.GetBytes(Left(SEncryptionKey, 8))
            Dim des As New DESCryptoServiceProvider()
            Dim inputByteArray() As Byte = Encoding.UTF8.GetBytes( _
                stringToEncrypt)
            Dim ms As New MemoryStream()
            Dim cs As New CryptoStream(ms, des.CreateEncryptor(key, IV), _
                CryptoStreamMode.Write)
            cs.Write(inputByteArray, 0, inputByteArray.Length)
            cs.FlushFinalBlock()
            Return Convert.ToBase64String(ms.ToArray())
        Catch e As Exception
            Return "ERROR"
        End Try
    End Function


    Public Shared Function Decrypt(ByVal stringToDecrypt As String, _
        ByVal sEncryptionKey As String) As String
        Dim key() As Byte = {}
        Dim IV() As Byte = {&H12, &H34, &H56, &H78, &H90, &HAB, &HCD, &HEF}
        Dim inputByteArray(stringToDecrypt.Length) As Byte
        Try
            key = System.Text.Encoding.UTF8.GetBytes(Left(sEncryptionKey, 8))
            Dim des As New DESCryptoServiceProvider()
            inputByteArray = Convert.FromBase64String(stringToDecrypt)
            Dim ms As New MemoryStream()
            Dim cs As New CryptoStream(ms, des.CreateDecryptor(key, IV), _
                CryptoStreamMode.Write)
            cs.Write(inputByteArray, 0, inputByteArray.Length)
            cs.FlushFinalBlock()
            Dim encoding As System.Text.Encoding = System.Text.Encoding.UTF8
            Return encoding.GetString(ms.ToArray())
        Catch e As Exception
            Return "ERROR"
        End Try
    End Function
    Public Shared Function ConvertNumberToWords(ByVal pValue As String) As String

        'pValue = pValue.Replace(",", "").Replace("$", "")
        pValue = pValue.TrimStart("0")

        Dim decimalCount As Int32 = 0
        For x As Int32 = 0 To pValue.Length - 1
            If pValue(x).ToString = "." Then
                decimalCount += 1
                If decimalCount > 1 Then
                    Throw New ArgumentException("Only numeric Values are accepted")
                End If

            End If

            If Not (Char.IsDigit(pValue(x)) Or pValue(x).ToString = ".") And Not (x = 0 And pValue(x).ToString = "-") Then
                Throw New ArgumentException("Only numeric Values are accepted")
            End If
        Next

        Dim returnpValue As String = ""
        Dim parts() As String = pValue.Split(".")

        If parts.Length > 1 Then
            parts(1) = parts(1).Substring(0, 2).ToCharArray 'Truncates -- doesn't round.   
        End If

        Dim IsNegative As Boolean = parts(0).Contains("-")
        If parts(0).Replace("-", "").Length > 18 Then
            Throw New ArgumentException("Maximum pValue is 999,999,999,999,999,999.99")
        End If

        If IsNegative Then
            parts(0) = parts(0).Replace("-", "")
            returnpValue &= "Minus "
        End If

        
        If parts(0).Length > 15 Then
            returnpValue &= HundredsText(parts(0).PadLeft(18, "0").Substring(0, 3)) & "Quadrillion "
            returnpValue &= HundredsText(parts(0).PadLeft(18, "0").Substring(3, 3)) & "Trillion "
            returnpValue &= HundredsText(parts(0).PadLeft(18, "0").Substring(6, 3)) & "Billion "
            returnpValue &= HundredsText(parts(0).PadLeft(18, "0").Substring(9, 3)) & "Million "
            returnpValue &= HundredsText(parts(0).PadLeft(18, "0").Substring(12, 3)) & "Thousand "
        ElseIf parts(0).Length > 12 Then
            returnpValue &= HundredsText(parts(0).PadLeft(15, "0").Substring(0, 3)) & "Trillion "
            returnpValue &= HundredsText(parts(0).PadLeft(15, "0").Substring(3, 3)) & "Billion "
            returnpValue &= HundredsText(parts(0).PadLeft(15, "0").Substring(6, 3)) & "Million "
            returnpValue &= HundredsText(parts(0).PadLeft(15, "0").Substring(9, 3)) & "Thousand "
        ElseIf parts(0).Length > 9 Then
            returnpValue &= HundredsText(parts(0).PadLeft(12, "0").Substring(0, 3)) & "Billion "
            returnpValue &= HundredsText(parts(0).PadLeft(12, "0").Substring(3, 3)) & "Million "
            returnpValue &= HundredsText(parts(0).PadLeft(12, "0").Substring(6, 3)) & "Thousand "
        ElseIf parts(0).Length > 6 Then
            returnpValue &= HundredsText(parts(0).PadLeft(9, "0").Substring(0, 3)) & "Million "
            returnpValue &= HundredsText(parts(0).PadLeft(9, "0").Substring(3, 3)) & "Thousand "
        ElseIf parts(0).Length > 3 Then
            returnpValue &= HundredsText(parts(0).PadLeft(6, "0").Substring(0, 3)) & "Thousand "
        End If

        Dim hundreds As String = parts(0).PadLeft(3, "0")
        hundreds = hundreds.Substring(hundreds.Length - 3, 3)
        If CInt(hundreds) <> 0 Then
            If CInt(hundreds) < 100 AndAlso parts.Length > 1 Then returnpValue &= "and "
            returnpValue &= HundredsText(hundreds)
            If CInt(hundreds) <> 1 Then returnpValue &= ""
            If parts.Length > 1 AndAlso CInt(parts(1)) <> 0 Then returnpValue &= " and "
        Else
            returnpValue &= ""
            If parts.Length > 1 AndAlso CInt(parts(1)) <> 0 Then returnpValue &= " and "
        End If

        If parts.Length = 2 Then
            If CInt(parts(1)) <> 0 Then
                returnpValue &= HundredsText(parts(1).PadLeft(3, "0"))
                returnpValue &= ""
                If CInt(parts(1)) <> 1 Then returnpValue &= ""
            End If
        End If

        Return returnpValue.Trim

    End Function
    Private Shared Function HundredsText(ByVal pValue As String) As String

        Dim Tens As String() = {"Ten", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"}
        Dim Ones As String() = {"One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"}

        Dim returnpValue As String = ""
        Dim IsSingleDigit As Boolean = True

        If CInt(pValue(0).ToString) <> 0 Then
            returnpValue &= Ones(CInt(pValue(0).ToString) - 1) & " Hundred "
            IsSingleDigit = False
        End If

        If CInt(pValue(1).ToString) > 1 Then
            returnpValue &= Tens(CInt(pValue(1).ToString) - 1) & " "
            If CInt(pValue(2).ToString) <> 0 Then
                returnpValue &= Ones(CInt(pValue(2).ToString) - 1) & " "
            End If
        ElseIf CInt(pValue(1).ToString) = 1 Then
            returnpValue &= Ones(CInt(pValue(1).ToString & pValue(2).ToString) - 1) & " "
        Else
            If CInt(pValue(2).ToString) <> 0 Then
                If Not IsSingleDigit Then
                    returnpValue &= "and "
                End If
                returnpValue &= Ones(CInt(pValue(2).ToString) - 1) & " "
            End If
        End If

        Return returnpValue

    End Function

#End Region

End Class
