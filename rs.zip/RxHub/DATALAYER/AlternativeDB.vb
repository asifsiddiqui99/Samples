Imports System.Data.SqlClient
Imports ElixirLibrary
Imports System.Configuration

#Region "AlternativeDB"

Public Class AlternativeDB

End Class

#End Region




Public Class Alternative


    Public Function GetVendorAlternatives(ByVal pDDID As Integer) As DataSet

        Dim lParameters(0) As SpParameter
        Dim lDatabaseConnection As Connection = Nothing
        Dim lDataSet As DataSet = Nothing


        Try
            lDatabaseConnection = New Connection(ConfigurationManager.ConnectionStrings("RxHubConnectionString").ConnectionString())
            lDataSet = New DataSet

            lParameters(0) = New SpParameter
            With lParameters(0)
                .ParameterName = "@DDID"
                .ParameterType = ParameterType.BigInt
                .ParameterValue = pDDID
            End With


            lDataSet = lDatabaseConnection.ExecuteQuery("GetVendorAlternatives", lParameters)
            Return lDataSet

        Catch ex As Exception

            ErrorLogMethods.LogError(ex, " RxHubLibrary\DAL\AlternativeDB.GetAlternatives(ByVal pAlternativeID As String, ByVal pNDC As String, ByVal pPBM As String) ")
            Return Nothing

        End Try
    End Function


    Public Function GetAlternatives(ByVal pAlternativeID As String, ByVal pNDC As String, ByVal pPBM As String) As DataSet

        Dim lParameters(2) As SpParameter
        Dim lDatabaseConnection As Connection = Nothing
        Dim lDataSet As DataSet = Nothing


        Try
            lDatabaseConnection = New Connection(ConfigurationManager.ConnectionStrings("RxHubConnectionString").ConnectionString())
            lDataSet = New DataSet

            lParameters(0) = New SpParameter
            With lParameters(0)
                .ParameterName = "@NDC"
                .ParameterType = ParameterType.Varchar
                .ParameterValue = pNDC
            End With

            lParameters(1) = New SpParameter
            With lParameters(1)
                .ParameterName = "@PBM"
                .ParameterType = ParameterType.Varchar
                .ParameterValue = pPBM
            End With

            lParameters(2) = New SpParameter
            With lParameters(2)
                .ParameterName = "@AlternativeID"
                .ParameterType = ParameterType.Varchar
                .ParameterValue = pAlternativeID
            End With


            lDataSet = lDatabaseConnection.ExecuteQuery("usp_GetAlternativesForAllNDCs", lParameters)


        Catch ex As Exception

            ErrorLogMethods.LogError(ex, " RxHubLibrary\DAL\AlternativeDB.GetAlternatives(ByVal pAlternativeID As String, ByVal pNDC As String, ByVal pPBM As String) ")

        End Try

        Return lDataSet

    End Function
End Class
