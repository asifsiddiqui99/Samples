Imports ElixirLibrary

Public Class MedicationHistoryDB

    Private mConnection As Connection

    Public Sub New()
        mConnection = New Connection
    End Sub

    Public ReadOnly Property Connection()
        Get
            Return mConnection
        End Get
    End Property


    'This function returns the MessageId from the NumSeries table in RxCureMaster
    Public Function GetMessageID() As String

        Dim lDs As DataSet = Nothing
        Dim lMessageNo As Integer = 0
        Dim lQuery As String = String.Empty
        Dim lMessageID As String = String.Empty


        Try

            lQuery = "Select MessageIdNumeric+1 As MsgId, Prefix from NumSeries "

            If Connection.IsTransactionAlive Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If


            If lDs.Tables.Count > 0 Then
                lMessageID = CType(lDs.Tables(0).Rows(0)("Prefix"), String) & "-" _
                       & CType(lDs.Tables(0).Rows(0)("MsgId"), String).PadLeft(10, "0")

                lMessageNo = lDs.Tables(0).Rows(0)("MsgId")
            End If

            lQuery = "Update NumSeries Set CurrentMessageId ='" & lMessageID & "', " _
                   & "MessageIdNumeric = " & lMessageNo & " "

            If Connection.IsTransactionAlive Then
                Connection.ExecuteTransactionCommand(lQuery)
            Else
                Connection.ExecuteCommand(lQuery)
            End If

        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\DAL\MedicationHistoryDB.GetMessageID() ")
        End Try

        GetMessageID = lMessageID

    End Function

    ' This function inserts the request in the database
    Public Function InsertRequest(ByVal pSentMessage As String, _
                                  ByVal pRelatesToMessageID As String, _
                                  ByVal pMessageType As Integer, _
                                  ByVal pPrescriberID As String, _
                                  ByVal pClinicCode As String, _
                                  ByVal pPatientID As String, _
                                  ByVal pFileName As String, _
                                  ByVal pEDI As String, _
                                  ByVal pMessageID As String) As Integer

        Dim lSpParameter(8) As SpParameter
        Dim lResult As DataSet = Nothing
        Dim lDataBaseConnection As Connection = Nothing

        Try

            lDataBaseConnection = New Connection(System.Configuration.ConfigurationManager.ConnectionStrings("RxHubConnectionString").ConnectionString)

            lSpParameter(0).ParameterName = "@ParamXml"
            lSpParameter(0).ParameterType = ParameterType.NText
            lSpParameter(0).ParameterValue = pSentMessage

            lSpParameter(1).ParameterName = "@ClinicId"
            lSpParameter(1).ParameterType = ParameterType.Varchar
            lSpParameter(1).ParameterValue = pClinicCode

            lSpParameter(2).ParameterName = "@PatientId"
            lSpParameter(2).ParameterType = ParameterType.BigInt
            lSpParameter(2).ParameterValue = pPatientID

            lSpParameter(3).ParameterName = "@RequestFileName"
            lSpParameter(3).ParameterType = ParameterType.Varchar
            lSpParameter(3).ParameterValue = pFileName

            lSpParameter(4).ParameterName = "@EDI"
            lSpParameter(4).ParameterType = ParameterType.Varchar
            lSpParameter(4).ParameterValue = pEDI

            lSpParameter(5).ParameterName = "@PrescriberID"
            lSpParameter(5).ParameterType = ParameterType.Varchar
            lSpParameter(5).ParameterValue = pPrescriberID

            lSpParameter(6).ParameterName = "@RelatesToMessageID"
            lSpParameter(6).ParameterType = ParameterType.Varchar
            lSpParameter(6).ParameterValue = pRelatesToMessageID

            lSpParameter(7).ParameterName = "@MessageType"
            lSpParameter(7).ParameterType = ParameterType.Varchar
            lSpParameter(7).ParameterValue = pMessageType.ToString


            lSpParameter(8).ParameterName = "@MessageID"
            lSpParameter(8).ParameterType = ParameterType.Varchar
            lSpParameter(8).ParameterValue = pMessageID


            lDataBaseConnection.ExecuteCommand("sp_InsertRequest", lSpParameter)


            InsertRequest = 1

        Catch ex As Exception
            ErrorLogMethods.LogError(ex, " RxHubLibrary\DAL\MedicationHistoryDB.InsertRequest(ByVal pSentMessage As String,ByVal pRelatesToMessageID As String,ByVal pMessageType As Integer,ByVal pPrescriberID As String,ByVal pClinicCode As String,ByVal pPatientID As String,ByVal pFileName As String,ByVal pEDI As String) ")
            InsertRequest = 0
        End Try



    End Function

End Class
