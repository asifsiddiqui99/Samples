Imports System.Xml
Imports ElixirLibrary

Public Class NewRxDB

    Private mMessageId As String
    Private mMessageCode As String
    Private mPrescriberOrderNumber As String
    Private mSentTime As String
    Private mClinicCode As String
    Private mPrescriberIdentification As New sIdentification
    Private mPharmacyIdentification As New sIdentification


    Public Property ClinicCode() As String
        Get
            Return mClinicCode
        End Get
        Set(ByVal value As String)
            mClinicCode = value
        End Set
    End Property

    Public Property PharmacyIdentification() As String
        Get
            Return mPharmacyIdentification.IdentificationNumber
        End Get
        Set(ByVal value As String)
            mPharmacyIdentification.IdentificationNumber = value
        End Set
    End Property


    Public Property PrescriberIdentification() As String
        Get
            Return mPrescriberIdentification.IdentificationNumber
        End Get
        Set(ByVal value As String)
            mPrescriberIdentification.IdentificationNumber = value
        End Set
    End Property

    Public Property SentTime() As String
        Get
            Return mSentTime
        End Get
        Set(ByVal value As String)
            mSentTime = value
        End Set
    End Property


    Public Property MessageCode() As String
        Get
            Return mMessageCode
        End Get
        Set(ByVal value As String)
            mMessageCode = value
        End Set
    End Property


    Public Property MessageId() As String
        Get
            Return mMessageId
        End Get
        Set(ByVal value As String)
            mMessageId = value
        End Set
    End Property

    Public Property PrescriberOrderNumber() As String
        Get
            Return mPrescriberOrderNumber
        End Get
        Set(ByVal value As String)
            mPrescriberOrderNumber = value
        End Set
    End Property

End Class




Public Class NewRx

    Private mNewRxDB As NewRxDB



#Region "Constructor"

    Public Sub New(ByVal pClinicCode As String)

        mNewRxDB = New NewRxDB
        NewRxDB.ClinicCode = pClinicCode
    End Sub


#End Region


#Region "Properties"

    Public Property NewRxDB() As NewRxDB
        Get
            Return mNewRxDB
        End Get
        Set(ByVal value As NewRxDB)
            mNewRxDB = value
        End Set
    End Property

#End Region

    

   
    Public Function AddMessageHdr(ByRef pConnection As Connection, _
                                          ByVal lDirection As String, _
                                          ByVal lCode As Long, _
                                          ByVal lFileName As String, _
                                          ByVal pXmlContents As String) As Boolean

        Dim lQuery As String = String.Empty

        Try

            lQuery = "Insert Into RxHubMessageHdr (" _
                   & "MessageCode, MessageId, MessageTypeId, LastStatus," _
                   & "XMLPath, ClinicId, UserId, " _
                   & "PrescriberOrderNo, RxReferenceNo, " _
                   & "RelatesToMessageId, Direction, XMLContents, PharmacyCode) " _
                   & "VALUES(" _
                   & lCode & ", " _
                   & "'" & NewRxDB.MessageId & "', " _
                   & "4," _
                   & "'Pending'," _
                   & "'" & lFileName & "'," _
                   & "'" & Me.NewRxDB.ClinicCode & "'," _
                   & "'" & Me.NewRxDB.PrescriberIdentification & "'," _
                   & "'" & Me.NewRxDB.PrescriberOrderNumber & "'," _
                   & "''," _
                   & "''," _
                   & "'" & lDirection & "', " _
                   & "'" + "<Message>" & pXmlContents.Substring(pXmlContents.IndexOf("<Header")).Replace("'", "''") + "', " _
                   & "'" & Me.NewRxDB.PharmacyIdentification & "')"

            If pConnection.IsTransactionAlive Then
                pConnection.ExecuteTransactionCommand(lQuery)
            Else
                pConnection.ExecuteCommand(lQuery)
            End If

        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\DAL\NewRxDB.AddMessageHdr(ByRef pConnection As Connection,ByVal lDirection As String, ByVal lCode As Long,ByVal lFileName As String,ByVal pXmlContents As String) ")
        End Try

        AddMessageHdr = True

    End Function


    Public Function AddMessageDtl(ByRef pConnection As Connection, _
                                      ByVal pDirection As String, _
                                      ByVal pCode As Long) As Boolean


        Dim lQuery As String = String.Empty

        Try

            lQuery = "INSERT INTO RxHubMessageDtl(MessageCode, MessageTime, " _
                   & "Status, Code, DescriptionCode, " _
                   & "[Description],Direction,ReceivedMessageId, DetailMessageType) " _
                   & "VALUES(" _
                   & " " & pCode & ", " _
                   & "'" & Left(Me.NewRxDB.SentTime, 19) & "', " _
                   & "'Pending'," _
                   & "''," _
                   & "''," _
                   & "''," _
                   & "'O'," _
                   & "'',4)"

            If pConnection.IsTransactionAlive Then
                pConnection.ExecuteTransactionCommand(lQuery)
            Else
                pConnection.ExecuteCommand(lQuery)
            End If

        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\DAL\NewRxDB.AddMessageDtl(ByRef pConnection As Connection,ByVal pDirection As String,ByVal pCode As Long) ")
        End Try

        AddMessageDtl = True

    End Function



    Public Function AddMessage(ByVal pRxId As String, ByVal filename As String, ByVal lMsgId As String, _
                                ByVal lXml As String, ByVal pConnectionString As String) As String


        Dim lXmlDocument As New XmlDocument
        lXmlDocument.LoadXml(lXml)




        Dim id As Integer = 0
        Dim lPharmacyCode As String = ""
        Dim lResult As Boolean
        Dim lCode As Long
        Dim lIsExist As Boolean
       
        Dim lConnection As Connection = Nothing


        Try


            lConnection = New Connection()

            lConnection.BeginTrans()


            If lMsgId <> "" Then
                lIsExist = True
            Else
                lIsExist = False
            End If

            lCode = GetMessageID(lConnection, lMsgId, pRxId)

            

            Me.NewRxDB.MessageId = lMsgId
            Me.NewRxDB.PrescriberOrderNumber = "Panace-PO-" & pRxId.PadLeft(9, "0")

            lXmlDocument.DocumentElement.SelectSingleNode("//Header/MessageID").InnerText = Me.NewRxDB.MessageId
            lXmlDocument.DocumentElement.SelectSingleNode("//Body/NewRx/PrescriberOrderNumber").InnerText = Me.NewRxDB.PrescriberOrderNumber



            Me.NewRxDB.PharmacyIdentification = lXmlDocument.DocumentElement.SelectSingleNode("//Pharmacy/Identification/NCPDPID").InnerText
            Me.NewRxDB.PrescriberIdentification = lXmlDocument.DocumentElement.SelectSingleNode("//Prescriber/Identification[1]/IdentificationNumber").InnerText
            Me.NewRxDB.SentTime = lXmlDocument.DocumentElement.SelectSingleNode("//SentTime").InnerText.Substring(4, 2) & "/" & _
            lXmlDocument.DocumentElement.SelectSingleNode("//SentTime").InnerText.Substring(6, 2) & "/" & _
            lXmlDocument.DocumentElement.SelectSingleNode("//SentTime").InnerText.Substring(0, 4) & " " & _
            lXmlDocument.DocumentElement.SelectSingleNode("//SentTime").InnerText.Substring(9, 2) & ":" & _
            lXmlDocument.DocumentElement.SelectSingleNode("//SentTime").InnerText.Substring(11, 2) & ":" & _
            lXmlDocument.DocumentElement.SelectSingleNode("//SentTime").InnerText.Substring(13, 2)


            If lIsExist Then
                lResult = AddMessageDtl(lConnection, "O", lCode)
                If Not lResult Then
                    Throw New Exception
                End If
            Else

                lResult = AddMessageHdr(lConnection, "O", lCode, filename, lXml)
                If Not lResult Then
                    Throw New Exception
                End If
                lResult = AddMessageDtl(lConnection, "O", lCode)

                If Not lResult Then
                    Throw New Exception
                End If
                lResult = UpdatePatCurrent(lMsgId, pRxId, pConnectionString)
                If Not lResult Then
                    Throw New Exception
                End If

            End If

            lConnection.CommitTrans()

        Catch ex As Exception
            lConnection.RollBackTrans()
            Throw New Exception(ex.Message & " : RxHubLibrary\DAL\NewRxDB.AddMessage(ByVal pRxId As String, ByVal filename As String, ByVal lMsgId As String,ByVal lXml As String, ByVal pConnectionString As String) ")

        End Try

        AddMessage = lXmlDocument.DocumentElement.OuterXml.ToString
    End Function

    Private Function UpdatePatCurrent(ByVal pMessageId As String, ByVal pRxId As String, ByVal pConnectionString As String) As Boolean

        Dim lConnection As New Connection(pConnectionString)
        Dim lQuery As String = String.Empty

        Try
            lQuery = "Update RxList " _
                   & "Set MessageId ='" & pMessageId & "', " _
                   & "SendCount = SendCount + 1 " _
                   & "Where RxId =" & Val(Right(pRxId, 9)) & " "


            If lConnection.IsTransactionAlive Then
                lConnection.ExecuteTransactionCommand(lQuery)
            Else
                lConnection.ExecuteCommand(lQuery)
            End If

            UpdatePatCurrent = True
        Catch ex As Exception
            UpdatePatCurrent = False
            Throw New Exception(ex.Message & " : RxHubLibrary\DAL\NewRxDB.UpdatePatCurrent(ByVal pMessageId As String, ByVal pRxId As String, ByVal pConnectionString As String) ")
        End Try

    End Function


    Public Function GetMessageID(ByRef lConnection As Connection, ByRef lMsgId As String, ByVal lRxId As String) As String

        Dim lDs As DataSet
        Dim lMessageCode As String = ""
        Dim lMessageNo As Integer = 0        
        Dim lQuery As String = String.Empty


        Try

            lRxId = "Panace-PO-" & lRxId.PadLeft(9, "0")


            lQuery = "Select MessageIdNumeric+1 As MsgId, Prefix from NumSeries "

            If lConnection.IsTransactionAlive Then
                lDs = lConnection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = lConnection.ExecuteQuery(lQuery)
            End If


            If lDs.Tables.Count > 0 Then
                lMsgId = CType(lDs.Tables(0).Rows(0)("Prefix"), String) & "-" _
                       & CType(lDs.Tables(0).Rows(0)("MsgId"), String).PadLeft(10, "0")

                lMessageNo = lDs.Tables(0).Rows(0)("MsgId")
            End If

            lQuery = "Update NumSeries Set CurrentMessageId ='" & lMsgId & "', " _
                   & "MessageIdNumeric = " & lMessageNo & " "

            If lConnection.IsTransactionAlive Then
                lConnection.ExecuteTransactionCommand(lQuery)
            Else
                lConnection.ExecuteCommand(lQuery)
            End If


            lQuery = "Select IsNull(Max(MessageCode),0) + 1  AS MessageCode From RxHubMessageHdr "
            If lConnection.IsTransactionAlive Then
                lDs = lConnection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = lConnection.ExecuteQuery(lQuery)
            End If


            If lDs.Tables.Count > 0 Then
                lMessageCode = CType(lDs.Tables(0).Rows(0)("MessageCode"), String)
            End If


            Me.NewRxDB.MessageId = lMsgId
            Me.NewRxDB.MessageCode = lMessageCode


        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\DAL\NewRxDB.GetMessageID(ByRef lConnection As Connection, ByRef lMsgId As String, ByVal lRxId As String) ")
        End Try

        GetMessageID = lMessageCode
    End Function

    Public Function SaveFailureStatus(ByVal pRequestXml As String, ByVal pConnectionString As String) As Boolean

        Dim lConnection As Connection = Nothing
        Dim lDs As DataSet = Nothing
        Dim lXmlDocument As XmlDocument = Nothing

        Dim lStatus As Boolean = True

        Dim lMessageCode As Integer = 0
        Dim lMessageType As Integer = 0

        Dim lQuery As String = String.Empty
        Dim lMessageStatus As String = String.Empty
        Dim lCode As String = String.Empty
        Dim lHdrStatus As String = String.Empty
        Dim lPoNo As String = String.Empty
        Dim lSPI As String = String.Empty



        Try

            lConnection = New Connection()
            lXmlDocument = New XmlDocument
            lDs = New DataSet

            lXmlDocument.LoadXml(pRequestXml)

            lConnection.BeginTrans()

            lQuery = "Select *, Cast(Right(PrescriberOrderNo,9) AS BigInt) AS PONo From RxHubMessageHdr " _
                   & "Where MessageId ='" & lXmlDocument.DocumentElement.SelectSingleNode("//Header/MessageID").InnerText & "' "


            If lConnection.IsTransactionAlive Then
                lDs = lConnection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = lConnection.ExecuteQuery(lQuery)
            End If

            If lDs.Tables(0).Rows.Count > 0 Then
                lMessageCode = CType(lDs.Tables(0).Rows(0)("MessageCode"), Integer)
                lHdrStatus = lDs.Tables(0).Rows(0)("LastStatus")
                lPoNo = lDs.Tables(0).Rows(0)("PoNo")
                lSPI = lDs.Tables(0).Rows(0)("UserId")
            End If

            lMessageStatus = "Pending"
            lMessageType = 1
            lCode = "NR"


            lQuery = "Update RxHubMessageDtl Set Status = '" + lMessageStatus + "' " _
                   & "Where Direction = 'O' " _
                   & "And DetailMessageType = 4 " _
                   & "And MessageCode = " & lMessageCode & " "


            If lConnection.IsTransactionAlive Then
                lConnection.ExecuteTransactionCommand(lQuery)
            Else
                lConnection.ExecuteCommand(lQuery)
            End If


            lQuery = "Update RxHubMessageHdr " _
                   & "Set LastStatus ='" & lMessageStatus & "' " _
                   & "Where MessageCode = " & lMessageCode & " "


            If lConnection.IsTransactionAlive Then
                lConnection.ExecuteTransactionCommand(lQuery)
            Else
                lConnection.ExecuteCommand(lQuery)
            End If

            Dim lSentDate As String = Date.Now


            Dim lStatusDescription As String
            lStatusDescription = "Time Out"
            

            lQuery = "INSERT INTO RxHubMessageDtl(MessageCode, MessageTime, " _
                   & "Status, Code, DescriptionCode, " _
                   & "[Description],Direction,ReceivedMessageId,DetailMessageType) " _
                   & "VALUES(" _
                   & " " & lMessageCode & ", " _
                   & "'" & lSentDate & "', " _
                   & "'" & lMessageStatus & "'," _
                   & "'" & lCode & "'," _
                   & "''," _
                   & "'" & lStatusDescription & " '," _
                   & "'I'," _
                   & "'0'," _
                   & " " & lMessageType & ")"


            If lConnection.IsTransactionAlive Then
                lConnection.ExecuteTransactionCommand(lQuery)
            Else
                lConnection.ExecuteCommand(lQuery)
            End If

            '*****************To be UnComment LaterOn Nov 21 2006 ******************

            lStatus = UpdateRenewalRequestStatus(lPoNo, lSPI, lMessageStatus, pConnectionString)
        
            '*****************End To be UnComment LaterOn Nov 21 2006 ******************

            lConnection.CommitTrans()

            SaveFailureStatus = lStatus

        Catch ex As Exception
            lConnection.RollBackTrans()

            'FELT NO NEED FOR THIS VARIABLE BECAUSE WHEN AN EXCEPTION WOULD OCCUR, THE APPLICATION WOULD STOP WORKING. 
            'SaveFailureStatus = False
            Throw New Exception(ex.Message & " : RxHubLibrary\DAL\NewRxDB.SaveFailureStatus(ByVal pRequestXml As String, ByVal pConnectionString As String) ")

        End Try

    End Function


    Public Function SaveStatus(ByVal RecMessage As String, ByVal pConnectionString As String) As Boolean

        Dim lConnection As Connection = Nothing
        Dim lXmlDocument As XmlDocument = Nothing
        Dim lDs As DataSet = Nothing

        Dim lStatus As Boolean = True

        Dim lMessageCode As Integer = 0
        Dim lMessageType As Integer = 0

        Dim lQuery As String = String.Empty
        Dim lMessageStatus As String = String.Empty
        Dim lCode As String = String.Empty
        Dim lHdrStatus As String = String.Empty
        Dim lPoNo As String = String.Empty
        Dim lSPI As String = String.Empty



        Try

            lConnection = New Connection
            lXmlDocument = New XmlDocument
            lDs = New DataSet

            lXmlDocument.LoadXml(RecMessage)

            lConnection.BeginTrans()

            lQuery = "Select *, Cast(Right(PrescriberOrderNo,9) AS BigInt) AS PONo From RxHubMessageHdr " _
                   & "Where MessageId ='" & lXmlDocument.DocumentElement.SelectSingleNode("//DialogueReference/InitiatorControlReference").InnerText & "' "


            If lConnection.IsTransactionAlive Then
                lDs = lConnection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = lConnection.ExecuteQuery(lQuery)
            End If

            If lDs.Tables(0).Rows.Count > 0 Then
                lMessageCode = CType(lDs.Tables(0).Rows(0)("MessageCode"), Integer)
                lHdrStatus = lDs.Tables(0).Rows(0)("LastStatus")
                lPoNo = lDs.Tables(0).Rows(0)("PoNo")
                lSPI = lDs.Tables(0).Rows(0)("UserId")
            End If

            If lXmlDocument.DocumentElement.SelectSingleNode("//MessageType/MessageFunction").InnerText.ToString.Equals("ERROR") Then
                lMessageStatus = "Failure"
                lMessageType = 1
                lCode = lXmlDocument.DocumentElement.SelectSingleNode("//STS/StatusTypeCode").InnerText
            Else
                If lXmlDocument.DocumentElement.SelectSingleNode("//STS/StatusTypeCode").InnerText.Equals("010") Then
                    lMessageStatus = "Success"
                    lMessageType = 3
                    lCode = "010"
                Else
                    lMessageStatus = "InProgress"
                    lMessageType = 3
                    lCode = "000"
                End If


            End If


            lQuery = "Update RxHubMessageDtl Set Status = '" + lMessageStatus + "' " _
                   & "Where Direction = 'O' " _
                   & "And DetailMessageType = 4 " _
                   & "And MessageCode = " & lMessageCode & " "


            If lConnection.IsTransactionAlive Then
                lConnection.ExecuteTransactionCommand(lQuery)
            Else
                lConnection.ExecuteCommand(lQuery)
            End If


            lQuery = "Update RxHubMessageHdr " _
                   & "Set LastStatus ='" & lMessageStatus & "' " _
                   & "Where MessageCode = " & lMessageCode & " "


            If lConnection.IsTransactionAlive Then
                lConnection.ExecuteTransactionCommand(lQuery)
            Else
                lConnection.ExecuteCommand(lQuery)
            End If

            Dim lSentDate As String = lXmlDocument.DocumentElement.SelectSingleNode("//Month").InnerText.ToString.PadLeft(2, "0") _
            & "/" & lXmlDocument.DocumentElement.SelectSingleNode("//Day").InnerText.ToString.PadLeft(2, "0") _
            & "/" & lXmlDocument.DocumentElement.SelectSingleNode("//Year").InnerText.ToString.PadLeft(2, "0") _
            & " " & lXmlDocument.DocumentElement.SelectSingleNode("//Hours").InnerText.ToString _
            & ":" & lXmlDocument.DocumentElement.SelectSingleNode("//Minutes").InnerText.ToString.PadLeft(2, "0") _
            & ":" & lXmlDocument.DocumentElement.SelectSingleNode("//Seconds").InnerText.ToString.PadLeft(2, "0")


            Dim lStatusDescription As String
            Dim lStatusTypeCode As String = String.Empty
            Dim lMessageReferenceNumber As String = String.Empty

            If lXmlDocument.DocumentElement.SelectNodes("//STS/FreeText").Count > 0 Then
                lStatusDescription = lXmlDocument.DocumentElement.SelectSingleNode("//STS/FreeText").InnerText
            Else
                lStatusDescription = ""
            End If

            If lXmlDocument.DocumentElement.SelectNodes("//STS/StatusTypeCode").Count > 0 Then
                lStatusTypeCode = lXmlDocument.DocumentElement.SelectSingleNode("//STS/StatusTypeCode").InnerText
            Else
                lStatusTypeCode = String.Empty

            End If

            If lXmlDocument.DocumentElement.SelectNodes("//UIH/MessageReferenceNumber").Count > 0 Then
                lMessageReferenceNumber = lXmlDocument.DocumentElement.SelectSingleNode("//UIH/MessageReferenceNumber").InnerText
            Else
                lMessageReferenceNumber = String.Empty

            End If

            lQuery = "INSERT INTO RxHubMessageDtl(MessageCode, MessageTime, " _
                   & "Status, Code, DescriptionCode, " _
                   & "[Description],Direction,ReceivedMessageId,DetailMessageType) " _
                   & "VALUES(" _
                   & " " & lMessageCode & ", " _
                   & "'" & lSentDate & "', " _
                   & "'" & lMessageStatus & "'," _
                   & "'" & lCode & "'," _
                   & "'" & lStatusTypeCode & "'," _
                   & "'" & lStatusDescription & " '," _
                   & "'I'," _
                   & "'" & lMessageReferenceNumber & "'," _
                   & " " & lMessageType & ")"


            If lConnection.IsTransactionAlive Then
                lConnection.ExecuteTransactionCommand(lQuery)
            Else
                lConnection.ExecuteCommand(lQuery)
            End If

            '*****************To be UnComment LaterOn Nov 21 2006 ******************

            lStatus = UpdateRenewalRequestStatus(lPoNo, lSPI, lMessageStatus, pConnectionString)

            '*****************End To be UnComment LaterOn Nov 21 2006 ******************

            lConnection.CommitTrans()

            SaveStatus = lStatus

        Catch ex As Exception
            lConnection.RollBackTrans()
            'SaveStatus = False
            Throw New Exception(ex.Message & " : RxHubLibrary\DAL\NewRxDB.SaveStatus(ByVal RecMessage As String, ByVal pConnectionString As String) ")

        End Try

    End Function


    Private Function UpdateRenewalRequestStatus(ByVal lRxId As String, ByVal lSPI As String, ByVal lStatus As String, ByVal lConnectionString As String) As Boolean

        Dim lConnection As Connection = Nothing
        Dim lQuery As String = String.Empty

        Try

            If lStatus.Equals("Failure") Then
                lStatus = "Pending"
            ElseIf lStatus.Equals("InProgress") Then
                lStatus = "Success"
            End If

            lConnection = New Connection(lConnectionString)

            lQuery = "Update RenewalRequest " _
                    & "Set NewPrescriptionStatus = '" & lStatus & "' " _
                    & "Where RenewalRequestID = (Select Distinct RenewalRequestID " _
                    & "                         From RxList " _
                    & "                         Where RxId = " & lRxId & " " _
                    & "                         And RenewalRequestID <> 0) "



            If lConnection.IsTransactionAlive Then
                lConnection.ExecuteTransactionCommand(lQuery)
            Else
                lConnection.ExecuteCommand(lQuery)
            End If

            UpdateRenewalRequestStatus = True

        Catch ex As Exception            
            Throw New Exception(ex.Message & " : RxHubLibrary\DAL\NewRxDB.UpdateRenewalRequestStatus(ByVal lRxId As String, ByVal lSPI As String, ByVal lStatus As String, ByVal lConnectionString As String) ")
        End Try

    End Function

End Class
