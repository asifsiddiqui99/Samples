Imports Microsoft.VisualBasic
Imports ElixirLibrary
Imports System.Configuration




#Region "Prescriber"

Public Class Prescriber
    Private mIdentification() As sIdentification
    Private mClinic As sClinic
    Private mName As sName
    Private mSpeciality As sSpeciality
    Private mPrescriberAgent As sName
    Private mAddress As sAddress
    Private mEmail As String
    Private mPhone() As sPhone
    Private mSupportQualifier() As String

    Private mIdentificationCount As Integer
    Private mPhoneCount As Integer
    Private mSupportCount As Integer



#Region "Contructor"

    Public Sub New(ByVal pIdentificationCount As Integer, ByVal pPhoneCount As String, _
    ByVal pSupportCount As String)

        Dim lIdentification(pIdentificationCount) As sIdentification
        Dim lPhone(pPhoneCount) As sPhone
        Dim lSupport(pSupportCount) As String

        mIdentificationCount = pIdentificationCount
        mPhoneCount = pPhoneCount
        mSupportCount = pSupportCount


        For x As Integer = 0 To pIdentificationCount - 1
            lIdentification(x) = New sIdentification
        Next

        For x As Integer = 0 To pPhoneCount - 1
            lPhone(x) = New sPhone
        Next

        mIdentification = lIdentification
        mPhone = lPhone
        mSupportQualifier = lSupport

        mClinic = New sClinic
        mName = New sName
        mSpeciality = New sSpeciality
        mPrescriberAgent = New sName
        mAddress = New sAddress
        

    End Sub

#End Region
    

#Region "Properties"

    Public Property Identification(ByVal pIndex As Integer) As sIdentification
        Get
            Return mIdentification(pIndex)
        End Get
        Set(ByVal value As sIdentification)
            mIdentification(pIndex) = value
        End Set
    End Property

    Public Property Clinic() As sClinic
        Get
            Return mClinic
        End Get
        Set(ByVal value As sClinic)
            mClinic = value
        End Set
    End Property

    Public Property Name() As sName
        Get
            Return mName
        End Get
        Set(ByVal value As sName)
            mName = value
        End Set
    End Property

    Public Property Speciality() As sSpeciality
        Get
            Return mSpeciality
        End Get
        Set(ByVal value As sSpeciality)
            mSpeciality = value
        End Set
    End Property

    Public Property PrescriberAgent() As sName
        Get
            Return mPrescriberAgent
        End Get
        Set(ByVal value As sName)
            mPrescriberAgent = value
        End Set
    End Property


    Public Property Address() As sAddress
        Get
            Return mAddress
        End Get
        Set(ByVal value As sAddress)
            mAddress = value
        End Set
    End Property

    Public Property Email() As String
        Get
            Return mEmail
        End Get
        Set(ByVal value As String)
            mEmail = value
        End Set
    End Property

    Public Property Phone() As sPhone()
        Get
            Return mPhone
        End Get
        Set(ByVal value As sPhone())
            mPhone = value
        End Set
    End Property


    Public Property SupportQualifier(ByVal pIndex As Integer) As String
        Get
            Return mSupportQualifier(pIndex)
        End Get
        Set(ByVal value As String)
            mSupportQualifier(pIndex) = value
        End Set
    End Property

    Public ReadOnly Property IdentificationCount() As Integer
        Get
            Return mIdentificationCount
        End Get
    End Property

    Public ReadOnly Property PhoneCount() As Integer
        Get
            Return mPhoneCount
        End Get
    End Property


    Public ReadOnly Property SupportCount() As Integer
        Get
            Return mSupportCount
        End Get
    End Property

#End Region


End Class

#End Region


#Region "RequestDB"

Public Class RequestDB

    Private mInterchangeID As Integer
    Private mRequestXml As String
    Private mClinicCode As String
    Private mPatientId As Integer
    Private mRequestDate As String
    Private mFileName As String
    Private mRequestDuration As Integer 'Calculated Field Can be usefull

    Private mPrescriberID As String
    Private mEDI As String
    Private mRelatesToMessageID As String
    Private mMessageType As Integer
    Private mMessageID As String



    Public Property MessageType() As Integer
        Get
            Return mMessageType
        End Get
        Set(ByVal value As Integer)
            mMessageType = value
        End Set
    End Property

    Public Property RelatesToMessageID() As String
        Get
            Return mRelatesToMessageID
        End Get
        Set(ByVal value As String)
            mRelatesToMessageID = value
        End Set
    End Property

    Public Property EDI() As String
        Get
            Return mEDI
        End Get
        Set(ByVal value As String)
            mEDI = value
        End Set
    End Property

    Public Property PrescriberID() As String
        Get
            Return mPrescriberID
        End Get
        Set(ByVal value As String)
            mPrescriberID = value
        End Set
    End Property


    Public Property InterchangeID() As Integer
        Get
            Return InterchangeID
        End Get
        Set(ByVal value As Integer)
            mInterchangeID = value
        End Set
    End Property

    Public Property RequestXml() As String
        Get
            Return mRequestXml
        End Get
        Set(ByVal value As String)
            mRequestXml = value
        End Set
    End Property

    Public Property ClinicCode() As String
        Get
            Return mClinicCode
        End Get
        Set(ByVal value As String)
            mClinicCode = value
        End Set
    End Property

    Public Property PatientId() As Integer
        Get
            Return mPatientId
        End Get
        Set(ByVal value As Integer)
            mPatientId = value
        End Set
    End Property

    Public Property RequestDate() As String
        Get
            Return mRequestDate
        End Get
        Set(ByVal value As String)
            mRequestDate = value
        End Set
    End Property

    Public Property FileName() As String
        Get
            Return mFileName
        End Get
        Set(ByVal value As String)
            mFileName = value
        End Set
    End Property

    Public Property RequestDuration() As Integer
        Get
            Return mRequestDuration
        End Get
        Set(ByVal value As Integer)
            mRequestDuration = value
        End Set
    End Property

    Public Property MessageID() As String
        Get
            Return mMessageID
        End Get
        Set(ByVal value As String)
            mMessageID = value
        End Set
    End Property

End Class

#End Region



#Region "Request"

Public Class Request

    Private lDataBaseConnection As Connection
    Private lRequestDB As RequestDB



#Region "Constructor"


    Public Sub New()
        lDataBaseConnection = New Connection(ConfigurationManager.ConnectionStrings("RxHubConnectionString").ConnectionString())
        lRequestDB = New RequestDB
    End Sub
     Public Sub New(ByVal pRequestConnection As Connection)
        lDataBaseConnection = pRequestConnection
        lRequestDB = New RequestDB
    End Sub


#End Region



#Region "Properties"

    Public Property RequestDB() As RequestDB
        Get
            Return lRequestDB
        End Get
        Set(ByVal value As RequestDB)
            lRequestDB = value
        End Set
    End Property


#End Region

    ' This function inserts the request in the database
    Public Function InsertRequest() As Integer
        Dim lSpParameter(8) As SpParameter

        Try
            If lRequestDB Is Nothing Then
                Return 0
                Exit Function
            End If



            lSpParameter(0).ParameterName = "@ParamXml"
            lSpParameter(0).ParameterType = ParameterType.NText
            lSpParameter(0).ParameterValue = lRequestDB.RequestXml

            lSpParameter(1).ParameterName = "@ClinicId"
            lSpParameter(1).ParameterType = ParameterType.Varchar
            lSpParameter(1).ParameterValue = lRequestDB.ClinicCode

            lSpParameter(2).ParameterName = "@PatientId"
            lSpParameter(2).ParameterType = ParameterType.BigInt
            lSpParameter(2).ParameterValue = lRequestDB.PatientId

            lSpParameter(3).ParameterName = "@RequestFileName"
            lSpParameter(3).ParameterType = ParameterType.Varchar
            lSpParameter(3).ParameterValue = lRequestDB.FileName

            lSpParameter(4).ParameterName = "@EDI"
            lSpParameter(4).ParameterType = ParameterType.Varchar
            lSpParameter(4).ParameterValue = lRequestDB.EDI

            lSpParameter(5).ParameterName = "@PrescriberID"
            lSpParameter(5).ParameterType = ParameterType.Varchar
            lSpParameter(5).ParameterValue = lRequestDB.PrescriberID

            lSpParameter(6).ParameterName = "@RelatesToMessageID"
            lSpParameter(6).ParameterType = ParameterType.Varchar
            lSpParameter(6).ParameterValue = lRequestDB.RelatesToMessageID

            lSpParameter(7).ParameterName = "@MessageType"
            lSpParameter(7).ParameterType = ParameterType.Varchar
            lSpParameter(7).ParameterValue = lRequestDB.MessageType

            lSpParameter(8).ParameterName = "@MessageID"
            lSpParameter(8).ParameterType = ParameterType.Varchar
            lSpParameter(8).ParameterValue = lRequestDB.MessageID


            If lDataBaseConnection.IsTransactionAlive Then
                lDataBaseConnection.ExecuteTransactionCommand("sp_InsertRequest", lSpParameter)
            Else
                lDataBaseConnection.ExecuteCommand("sp_InsertRequest", lSpParameter)
            End If



        Catch ex As Exception
            'Throw New Exception(ex.Message & " : RxHubLibrary\DAL\RequestDB.InsertRequest() ")
            ErrorLogMethods.LogError(ex, " RxHubLibrary\DAL\RequestDB.InsertRequest() ")
        End Try
        Return 1
    End Function

    Public Function CheckRequestDuration() As System.Data.DataSet
        Dim lSpParameter(1) As SpParameter
        Dim lDs As DataSet = Nothing

        Try
            lDs = New DataSet

            lSpParameter(0).ParameterName = "@ClinicId"
            lSpParameter(0).ParameterType = ParameterType.Varchar
            lSpParameter(0).ParameterValue = lRequestDB.ClinicCode

            lSpParameter(1).ParameterName = "@PatientId"
            lSpParameter(1).ParameterType = ParameterType.Varchar
            lSpParameter(1).ParameterValue = lRequestDB.PatientId

            lDs = lDataBaseConnection.ExecuteQuery("sp_CheckRequestDuration", lSpParameter)


        Catch ex As Exception
            'Throw New Exception(ex.Message & " : RxHubLibrary\DAL\RequestDB.InsertRequest() ")
            ErrorLogMethods.LogError(ex, " RxHubLibrary\DAL\RequestDB.CheckRequestDuration() ")
        End Try

        Return lDs

    End Function




End Class

#End Region


