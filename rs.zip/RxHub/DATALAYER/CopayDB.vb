Imports System.Data.SqlClient
Imports ElixirLibrary
Imports System.Configuration

#Region "CopayDB"

Public Class CopayDB

    Private mProductType As String
    Private mPharmacyType As String
    Private mFlatCopayAmount As String
    Private mPercentCopayRate As String
    Private mFirstCopayTerm As String
    Private mMinimumCopay As String
    Private mMaximumCopay As String
    Private mDaysSupplyPerCopay As String
    Private mCopayTier As String
    Private mMaximumCopayTier As String
    Private mOutOfPocketRangeStart As String
    Private mOutOfPocketRangeEnd As String


#Region "Constructor"

    Public Sub New()
        mProductType = ""
        mPharmacyType = ""
        mFlatCopayAmount = ""
        mPercentCopayRate = ""
        mFirstCopayTerm = ""
        mMinimumCopay = ""
        mMaximumCopay = ""
        mDaysSupplyPerCopay = ""
        mCopayTier = ""
        mMaximumCopayTier = ""
        mOutOfPocketRangeStart = ""
        mOutOfPocketRangeEnd = ""
    End Sub

#End Region


#Region "Properties"

    Public Property OutOfPocketRangeEnd() As String
        Get
            Return mOutOfPocketRangeEnd
        End Get
        Set(ByVal value As String)
            mOutOfPocketRangeEnd = value
        End Set
    End Property
    Public Property OutOfPocketRangeStart() As String
        Get
            Return mOutOfPocketRangeStart
        End Get
        Set(ByVal value As String)
            mOutOfPocketRangeStart = value
        End Set
    End Property

    Public Property ProductType() As String
        Get
            Return mProductType
        End Get
        Set(ByVal value As String)
            mProductType = value
        End Set
    End Property
    Public Property MaximumCopayTier() As String
        Get
            Return mMaximumCopayTier
        End Get
        Set(ByVal value As String)
            mMaximumCopayTier = value
        End Set
    End Property

    Public Property CopayTier() As String
        Get
            Return mCopayTier
        End Get
        Set(ByVal value As String)
            mCopayTier = value
        End Set
    End Property

    Public Property DaysSupplyPerCopay() As String
        Get
            Return mDaysSupplyPerCopay
        End Get
        Set(ByVal value As String)
            mDaysSupplyPerCopay = value
        End Set
    End Property

    Public Property MaximumCopay() As String
        Get
            Return mMaximumCopay
        End Get
        Set(ByVal value As String)
            mMaximumCopay = value
        End Set
    End Property

    Public Property MinimumCopay() As String
        Get
            Return mMinimumCopay
        End Get
        Set(ByVal value As String)
            mMinimumCopay = value
        End Set
    End Property

    Public Property FirstCopayTerm() As String
        Get
            Return mFirstCopayTerm
        End Get
        Set(ByVal value As String)
            mFirstCopayTerm = value
        End Set
    End Property

    Public Property PercentCopayRate() As String
        Get
            Return mPercentCopayRate
        End Get
        Set(ByVal value As String)
            mPercentCopayRate = value
        End Set
    End Property

    Public Property FlatCopayAmount() As String
        Get
            Return mFlatCopayAmount
        End Get
        Set(ByVal value As String)
            mFlatCopayAmount = value
        End Set
    End Property


    Public Property PharmacyType() As String
        Get
            Return mPharmacyType
        End Get
        Set(ByVal value As String)
            mPharmacyType = value
        End Set
    End Property


    ''This function is created for the hashtable comparison test that are going to be used for the comparisons in copayDS get function 
    'Public Overridable Overloads Function Equals(ByVal pCopayDB As CopayDB) As Boolean
    '    If Me.CopayTier = pCopayDB.CopayTier And _
    '       Me.DaysSupplyPerCopay = pCopayDB.DaysSupplyPerCopay And _
    '       Me.FirstCopayTerm = pCopayDB.FirstCopayTerm And _
    '       Me.FlatCopayAmount = pCopayDB.FlatCopayAmount And _
    '       Me.MaximumCopay = pCopayDB.MaximumCopay And _
    '       Me.MaximumCopayTier = pCopayDB.MaximumCopayTier And _
    '       Me.MinimumCopay = pCopayDB.MinimumCopay And _
    '       Me.OutOfPocketRangeEnd = pCopayDB.OutOfPocketRangeEnd And _
    '       Me.OutOfPocketRangeStart = pCopayDB.OutOfPocketRangeStart And _
    '       Me.PercentCopayRate = pCopayDB.PercentCopayRate And _
    '       Me.PharmacyType = pCopayDB.PharmacyType And _
    '       Me.ProductType = pCopayDB.ProductType Then

    '        Return True

    '    Else : Return False


    '    End If

    'End Function


    'Public Overridable Overloads Function GetHashCode(ByVal pCopayDB As CopayDB) As Boolean
    '    If Me.CopayTier = pCopayDB.CopayTier And _
    '       Me.DaysSupplyPerCopay = pCopayDB.DaysSupplyPerCopay And _
    '       Me.FirstCopayTerm = pCopayDB.FirstCopayTerm And _
    '       Me.FlatCopayAmount = pCopayDB.FlatCopayAmount And _
    '       Me.MaximumCopay = pCopayDB.MaximumCopay And _
    '       Me.MaximumCopayTier = pCopayDB.MaximumCopayTier And _
    '       Me.MinimumCopay = pCopayDB.MinimumCopay And _
    '       Me.OutOfPocketRangeEnd = pCopayDB.OutOfPocketRangeEnd And _
    '       Me.OutOfPocketRangeStart = pCopayDB.OutOfPocketRangeStart And _
    '       Me.PercentCopayRate = pCopayDB.PercentCopayRate And _
    '       Me.PharmacyType = pCopayDB.PharmacyType And _
    '       Me.ProductType = pCopayDB.ProductType Then

    '        Return True

    '    Else : Return False


    '    End If
    'End Function


#End Region


End Class

#End Region


#Region "Copay"

'This class gets the basic copay information 
Public Class Copay

    Private mDatabaseConnection As Connection
    Public mCopayDS() As CopayDB
    Public mCopaySL() As CopayDB


    Private mCopayDBCount As Integer


    
#Region "Constructor"

    Public Sub New()
        mDatabaseConnection = New Connection(ConfigurationManager.ConnectionStrings("RxHubConnectionString").ConnectionString())
        mCopayDS = Nothing
        mCopaySL = Nothing
        mCopayDBCount = 0
    End Sub

#End Region

#Region "Properties"


    Public Property CopayDBCount() As Integer
        Get
            Return mCopayDBCount
        End Get
        Set(ByVal value As Integer)
            mCopayDBCount = value
        End Set
    End Property

#End Region


    Public Sub GetDSCopayByDDID(ByVal pCopayID As String, ByVal pDDID As String, ByVal pPBM As String)
        Dim lParameters(2) As SpParameter
        Dim lResult As DataSet = Nothing
        Dim lCopayTier As String = String.Empty


        Try


            lParameters(0) = New SpParameter
            With lParameters(0)
                .ParameterName = "@CopayID"
                .ParameterValue = pCopayID
                .ParameterType = ParameterType.Varchar
            End With

            lParameters(1) = New SpParameter
            With lParameters(1)
                .ParameterName = "@DDID"
                .ParameterValue = pDDID
                .ParameterType = ParameterType.Varchar
            End With

            lParameters(2) = New SpParameter
            With lParameters(2)
                .ParameterName = "@PBM"
                .ParameterValue = pPBM
                .ParameterType = ParameterType.Varchar
            End With


            lResult = mDatabaseConnection.ExecuteQuery("usp_GetDSCopayByDDID", lParameters)


            If lResult.Tables(0).Rows.Count < 1 Then

                Exit Sub
            End If

            Dim lCopayDS(lResult.Tables(0).Rows.Count - 1) As CopayDB

            Dim lHashTable As String = ""


            For x As Integer = 0 To lResult.Tables(0).Rows.Count - 1

                lCopayDS(x) = New CopayDB

                With lResult.Tables(0).Rows(x)
                    If Not lHashTable.Contains(.Item(0).ToString + "~" + .Item(1).ToString + "~" + .Item(2).ToString + "~" + .Item(3).ToString + "~" + .Item(4).ToString + "~" + .Item(5).ToString + "~" + .Item(6).ToString + "~" + .Item(7).ToString + "~" + .Item(8).ToString) AndAlso Not lCopayTier.Contains(.Item(0).ToString + "|" + .Item(7).ToString + "|" + .Item(8).ToString) Then

                        With lCopayDS(x)
                            .PharmacyType = lResult.Tables(0).Rows(x).Item(0).ToString
                            .FlatCopayAmount = lResult.Tables(0).Rows(x).Item(1).ToString
                            .PercentCopayRate = lResult.Tables(0).Rows(x).Item(2).ToString
                            .FirstCopayTerm = lResult.Tables(0).Rows(x).Item(3).ToString
                            .MinimumCopay = lResult.Tables(0).Rows(x).Item(4).ToString
                            .MaximumCopay = lResult.Tables(0).Rows(x).Item(5).ToString
                            .DaysSupplyPerCopay = lResult.Tables(0).Rows(x).Item(6).ToString
                            .CopayTier = lResult.Tables(0).Rows(x).Item(7).ToString
                            lCopayTier += IIf(lResult.Tables(0).Rows(x).Item(7).ToString.Equals(""), False, lResult.Tables(0).Rows(x).Item(0).ToString + "|" + lResult.Tables(0).Rows(x).Item(7).ToString + "|" + lResult.Tables(0).Rows(x).Item(8).ToString + "~") 'Additional Check
                            .MaximumCopayTier = lResult.Tables(0).Rows(x).Item(8).ToString
                        End With

                        lHashTable = lHashTable + "|" + .Item(0).ToString + "~" + .Item(1).ToString + "~" + .Item(2).ToString + "~" + .Item(3).ToString + "~" + .Item(4).ToString + "~" + .Item(5).ToString + "~" + .Item(6).ToString + "~" + .Item(7).ToString + "~" + .Item(8).ToString + "|"
                        mCopayDBCount += 1

                    Else
                        lCopayDS(x) = Nothing

                    End If
                End With

            Next



            mCopayDS = lCopayDS



        Catch ex As Exception

            Throw New Exception(ex.Message & " : RxHubLibrary\DAL\CopayDB.GetDSCopayByDDID(ByVal pCopayID As String, ByVal pDDID As String, ByVal pPBM As String) ")

        End Try
    End Sub


    'This sub gets the Drug Specific Copay
    Public Sub GetDSCopay(ByVal pCopayID As String, ByVal pNDC As String, ByVal pPBM As String)
        Dim lParameters(2) As SpParameter
        Dim lResult As DataSet = Nothing
        'Dim lCopayTier As Boolean = False
        Dim lCopayTier As String = String.Empty


        Try


            lParameters(0) = New SpParameter
            With lParameters(0)
                .ParameterName = "@CopayID"
                .ParameterValue = pCopayID
                .ParameterType = ParameterType.Varchar
            End With

            lParameters(1) = New SpParameter
            With lParameters(1)
                .ParameterName = "@NDC"
                .ParameterValue = pNDC
                .ParameterType = ParameterType.Varchar
            End With

            lParameters(2) = New SpParameter
            With lParameters(2)
                .ParameterName = "@PBM"
                .ParameterValue = pPBM
                .ParameterType = ParameterType.Varchar
            End With


            lResult = mDatabaseConnection.ExecuteQuery("usp_GetDSCopay", lParameters)


            If lResult.Tables(0).Rows.Count < 1 Then

                Exit Sub
            End If

            Dim lCopayDS(lResult.Tables(0).Rows.Count - 1) As CopayDB

            Dim lHashTable As String = ""


            For x As Integer = 0 To lResult.Tables(0).Rows.Count - 1

                lCopayDS(x) = New CopayDB

                With lResult.Tables(0).Rows(x)
                    If Not lHashTable.Contains(.Item(0).ToString & "~" & .Item(1).ToString & "~" & .Item(2).ToString & "~" & .Item(3).ToString & "~" & .Item(4).ToString & "~" & .Item(5).ToString & "~" & .Item(6).ToString & "~" & .Item(7).ToString & "~" & .Item(8).ToString) AndAlso Not lCopayTier.Contains(.Item(0).ToString & "|" & .Item(7).ToString & "|" & .Item(8).ToString) Then

                        With lCopayDS(x)
                            .PharmacyType = lResult.Tables(0).Rows(x).Item(0).ToString
                            .FlatCopayAmount = lResult.Tables(0).Rows(x).Item(1).ToString
                            .PercentCopayRate = lResult.Tables(0).Rows(x).Item(2).ToString
                            .FirstCopayTerm = lResult.Tables(0).Rows(x).Item(3).ToString
                            .MinimumCopay = lResult.Tables(0).Rows(x).Item(4).ToString
                            .MaximumCopay = lResult.Tables(0).Rows(x).Item(5).ToString
                            .DaysSupplyPerCopay = lResult.Tables(0).Rows(x).Item(6).ToString
                            .CopayTier = lResult.Tables(0).Rows(x).Item(7).ToString
                            lCopayTier &= IIf(lResult.Tables(0).Rows(x).Item(7).ToString.Equals(""), False, lResult.Tables(0).Rows(x).Item(0).ToString & "|" & lResult.Tables(0).Rows(x).Item(7).ToString & "|" & lResult.Tables(0).Rows(x).Item(8).ToString & "~") 'Additional Check
                            .MaximumCopayTier = lResult.Tables(0).Rows(x).Item(8).ToString
                        End With

                        lHashTable = lHashTable & "|" & .Item(0).ToString & "~" & .Item(1).ToString & "~" & .Item(2).ToString & "~" & .Item(3).ToString & "~" & .Item(4).ToString & "~" & .Item(5).ToString & "~" & .Item(6).ToString & "~" & .Item(7).ToString & "~" & .Item(8).ToString & "|"
                        mCopayDBCount += 1

                    Else
                        lCopayDS(x) = Nothing

                    End If
                End With

            Next

            

            mCopayDS = lCopayDS



        Catch ex As Exception

            Throw New Exception(ex.Message & " : RxHubLibrary\DAL\CopayDB.GetDSCopay(ByVal pCopayID As String, ByVal pNDC As String, ByVal pPBM As String) ")

        End Try
    End Sub

    'This sub gets the SL copay information
    Public Sub GetSLCopay(ByVal pCopayID As String, ByVal pPBM As String, ByVal pFormularyStatus As String, ByVal pDdid As String)
        Dim lParameters(3) As SpParameter
        Dim lResult As DataSet = Nothing



        Try


            lParameters(0) = New SpParameter
            With lParameters(0)
                .ParameterName = "@CopayID"
                .ParameterValue = pCopayID
                .ParameterType = ParameterType.Varchar
            End With

            lParameters(1) = New SpParameter
            With lParameters(1)
                .ParameterName = "@PBM"
                .ParameterValue = pPBM
                .ParameterType = ParameterType.Varchar
            End With

            lParameters(2) = New SpParameter
            With lParameters(2)
                .ParameterName = "@FormularyStatus"
                .ParameterValue = pFormularyStatus
                .ParameterType = ParameterType.Varchar
            End With

            lParameters(3) = New SpParameter
            With lParameters(3)
                .ParameterName = "@Ddid"
                .ParameterValue = pDdid
                .ParameterType = ParameterType.Varchar
            End With

            lResult = mDatabaseConnection.ExecuteQuery("usp_GetSLCopay", lParameters)


            If lResult.Tables(0).Rows.Count < 1 Then
                Exit Sub
            End If

            Dim lCopaySL(lResult.Tables(0).Rows.Count - 1) As CopayDB

            For x As Integer = 0 To lResult.Tables(0).Rows.Count - 1
                lCopaySL(x) = New CopayDB
                With lCopaySL(x)
                    .ProductType = lResult.Tables(0).Rows(x).Item(0).ToString
                    .PharmacyType = lResult.Tables(0).Rows(x).Item(1).ToString
                    .OutOfPocketRangeStart = lResult.Tables(0).Rows(x).Item(2).ToString
                    .OutOfPocketRangeEnd = lResult.Tables(0).Rows(x).Item(3).ToString
                    .FlatCopayAmount = lResult.Tables(0).Rows(x).Item(4).ToString
                    .PercentCopayRate = lResult.Tables(0).Rows(x).Item(5).ToString
                    .FirstCopayTerm = lResult.Tables(0).Rows(x).Item(6).ToString
                    .MinimumCopay = lResult.Tables(0).Rows(x).Item(7).ToString
                    .MaximumCopay = lResult.Tables(0).Rows(x).Item(8).ToString
                    .DaysSupplyPerCopay = lResult.Tables(0).Rows(x).Item(9).ToString
                    .CopayTier = lResult.Tables(0).Rows(x).Item(10).ToString
                    .MaximumCopayTier = lResult.Tables(0).Rows(x).Item(11).ToString
                End With

            Next

            mCopaySL = lCopaySL

        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\DAL\CopayDB.GetSLCopay(ByVal pCopayID As String, ByVal pPBM As String, ByVal pFormularyStatus As String) ")
        End Try
    End Sub

End Class

#End Region