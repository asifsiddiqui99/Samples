Imports System.Data.SqlClient
Imports ElixirLibrary
Imports MedispanLibrary
Imports System.Configuration

#Region "CoverageDB"


Public Class QuantityLimit

    Private mQuantity As String
    Private mQuantityQualifier As String
    Private mTimePeriodQualifier As String
    Private mTimePeriod As String
    Private mTimePeriodStartDate As String
    Private mTimePeriodEndDate As String


#Region "Properties"

    Public Property QuantityQualifier() As String
        Get
            Return mQuantityQualifier
        End Get
        Set(ByVal value As String)
            mQuantityQualifier = value
        End Set
    End Property

    Public Property Quantity() As String
        Get
            Return mQuantity
        End Get
        Set(ByVal value As String)
            mQuantity = value
        End Set
    End Property
    Public Property TimePeriodEndDate() As String
        Get
            Return mTimePeriodEndDate
        End Get
        Set(ByVal value As String)
            mTimePeriodEndDate = value
        End Set
    End Property
    Public Property TimePeriodStartDate() As String
        Get
            Return mTimePeriodStartDate
        End Get
        Set(ByVal value As String)
            mTimePeriodStartDate = value
        End Set
    End Property
    Public Property TimePeriod() As String
        Get
            Return mTimePeriod
        End Get
        Set(ByVal value As String)
            mTimePeriod = value
        End Set
    End Property
    Public Property TimePeriodQualifier() As String
        Get
            Return mTimePeriodQualifier
        End Get
        Set(ByVal value As String)
            mTimePeriodQualifier = value
        End Set
    End Property

#End Region


    
End Class


Public Class CoverageDB

    Private mGender As String
    Private mGenderLimitExists As Boolean

    Private mQuantityLimit() As QuantityLimit
    
    Private mQuantityLimitExists As Boolean
    Private mMaximumAge As String
    Private mMaximumAgeQualifier As String
    Private mMinimumAge As String
    Private mMinimumAgeQualifier As String
    Private mAgeLimitExists As Boolean
    Private mStepMedication() As String
    Private mStepOrder() As String
    Private mStepCount As Integer
    Private mStepMedicationExists As Boolean
    Private mTextMessage() As String    
    Private mTextMessageExists As Boolean
    Private mResourceLinkExists As Boolean
    Private mResourceLink() As String
    Private mResourceLinkType() As String
    Private mPriorAuthorization As Boolean
    Private mMedicalNecessity As Boolean
    Private mExcluded As Boolean
    Private mStepTherapy As Boolean    

    Private mSLResourceLinkExists As Boolean
    Private mDSResourceLinkExists As Boolean

#Region "Properties"

    Public Property DSResourceLinkExists() As Boolean
        Get
            Return mDSResourceLinkExists
        End Get
        Set(ByVal value As Boolean)
            mDSResourceLinkExists = value
        End Set
    End Property

    Public Property SLResourceLinkExists() As Boolean
        Get
            Return mSLResourceLinkExists
        End Get
        Set(ByVal value As Boolean)
            mSLResourceLinkExists = value
        End Set
    End Property
   
    Public Property QuantityLimit() As QuantityLimit()
        Get
            Return mQuantityLimit
        End Get
        Set(ByVal value As QuantityLimit())
            mQuantityLimit = value
        End Set
    End Property


    Public Property PriorAuthorization() As Boolean
        Get
            Return mPriorAuthorization
        End Get
        Set(ByVal value As Boolean)
            mPriorAuthorization = value
        End Set
    End Property
    Public Property Excluded() As Boolean
        Get
            Return mExcluded
        End Get
        Set(ByVal value As Boolean)
            mExcluded = value
        End Set
    End Property

    Public Property MedicalNecessity() As Boolean
        Get
            Return mMedicalNecessity
        End Get
        Set(ByVal value As Boolean)
            mMedicalNecessity = value
        End Set
    End Property

    Public Property StepTherapy() As Boolean
        Get
            Return mStepTherapy
        End Get
        Set(ByVal value As Boolean)
            mStepTherapy = value
        End Set
    End Property
    Public Property ResourceLinkType() As String()
        Get
            Return mResourceLinkType
        End Get
        Set(ByVal value As String())
            mResourceLinkType = value
        End Set
    End Property
    Public Property ResourceLink() As String()
        Get
            Return mResourceLink
        End Get
        Set(ByVal value As String())
            mResourceLink = value
        End Set
    End Property
    Public Property StepCount() As Integer
        Get
            Return mStepCount
        End Get
        Set(ByVal value As Integer)
            mStepCount = value
        End Set
    End Property
    Public Property StepMedicationExists() As Boolean
        Get
            Return mStepMedicationExists
        End Get
        Set(ByVal value As Boolean)
            mStepMedicationExists = value
        End Set
    End Property

    Public Property StepOrder() As String()
        Get
            Return mStepOrder
        End Get
        Set(ByVal value As String())
            mStepOrder = value
        End Set
    End Property


    Public Property StepMedication() As String()
        Get
            Return mStepMedication
        End Get
        Set(ByVal value As String())
            mStepMedication = value
        End Set
    End Property

    Public Property QuantityLimitExists() As Boolean
        Get
            Return mQuantityLimitExists
        End Get
        Set(ByVal value As Boolean)
            mQuantityLimitExists = value
        End Set
    End Property

    Public Property GenderLimitExists() As Boolean
        Get
            Return mGenderLimitExists
        End Get
        Set(ByVal value As Boolean)
            mGenderLimitExists = value
        End Set
    End Property
    Public Property AgeLimitExists() As Boolean
        Get
            Return mAgeLimitExists
        End Get
        Set(ByVal value As Boolean)
            mAgeLimitExists = value
        End Set
    End Property


    Public Property MinimumAgeQualifier() As String
        Get
            Return mMinimumAgeQualifier
        End Get
        Set(ByVal value As String)
            mMinimumAgeQualifier = value
        End Set
    End Property

    Public Property MinimumAge() As String
        Get
            Return mMinimumAge
        End Get
        Set(ByVal value As String)
            mMinimumAge = value
        End Set
    End Property

    Public Property MaximumAgeQualifier() As String
        Get
            Return mMaximumAgeQualifier
        End Get
        Set(ByVal value As String)
            mMaximumAgeQualifier = value
        End Set
    End Property

    Public Property MaximumAge() As String
        Get
            Return mMaximumAge
        End Get
        Set(ByVal value As String)
            mMaximumAge = value
        End Set
    End Property


    Public Property Gender() As String
        Get
            Return mGender
        End Get
        Set(ByVal value As String)
            mGender = value
        End Set
    End Property

    Public Property TextMessage() As String()
        Get
            Return mTextMessage
        End Get
        Set(ByVal value As String())
            mTextMessage = value
        End Set
    End Property

    Public Property TextMessageExists() As Boolean
        Get
            Return mTextMessageExists
        End Get
        Set(ByVal value As Boolean)
            mTextMessageExists = value
        End Set
    End Property

    Public Property ResourceLinkExists() As Boolean
        Get
            Return mResourceLinkExists
        End Get
        Set(ByVal value As Boolean)
            mResourceLinkExists = value
        End Set
    End Property
#End Region

#Region "Constructor"

    Public Sub New()
        mGender = Nothing      
        mMaximumAge = Nothing
        mMaximumAgeQualifier = Nothing
        mMinimumAge = Nothing
        mMinimumAgeQualifier = Nothing
        mResourceLinkType = Nothing
        mQuantityLimitExists = True
        mGenderLimitExists = True
        mAgeLimitExists = True
        mStepMedicationExists = True
        mTextMessageExists = True
        mResourceLinkExists = True
        mStepCount = 0
    End Sub

#End Region

End Class

#End Region


#Region "Coverage"

Public Class Coverage
    Private mCoverageDB As CoverageDB
    Private mDatabaseConnection As Connection

#Region "Property"

    Public ReadOnly Property CoverageDB() As CoverageDB
        Get
            Return mCoverageDB
        End Get
    End Property

#End Region
    
#Region "Constructor"

    Public Sub New()
        mCoverageDB = New CoverageDB
        mDatabaseConnection = New Connection(ConfigurationManager.ConnectionStrings("RxHubConnectionString").ConnectionString())
    End Sub

#End Region


    Public Sub GetStepTherapy(ByVal pCoverageID As String, ByVal pNDC As String, ByVal pPBM As String)
        Dim lParameters(2) As SpParameter
        Dim lResult As DataSet = Nothing        

        Try

            lParameters(0) = New SpParameter
            With lParameters(0)
                .ParameterName = "@CoverageID"
                .ParameterValue = pCoverageID
                .ParameterType = ParameterType.Varchar
            End With

            lParameters(1) = New SpParameter
            With lParameters(1)
                .ParameterName = "@NDC"
                .ParameterValue = pNDC
                .ParameterType = ParameterType.Varchar
            End With

            lParameters(2) = New SpParameter
            With lParameters(2)
                .ParameterName = "@PBM"
                .ParameterValue = pPBM
                .ParameterType = ParameterType.Varchar
            End With


            lResult = mDatabaseConnection.ExecuteQuery("usp_CheckStepTherapy", lParameters)

            If lResult.Tables(0).Rows.Count > 0 Then
                mCoverageDB.StepTherapy = True
            Else
                mCoverageDB.StepTherapy = False
            End If


        Catch ex As Exception            
            ErrorLogMethods.LogError(ex, " RxHubLibrary\DAL\CoverageDB.GetStepTherapy(ByVal pCoverageID As String, ByVal pNDC As String, ByVal pPBM As String)")
            mCoverageDB.StepTherapy = False
        End Try
    End Sub



    Public Sub GetMedicalNecessity(ByVal pCoverageID As String, ByVal pNDC As String, ByVal pPBM As String)

        Dim lParameters(2) As SpParameter
        Dim lResult As DataSet = Nothing


        Try



            lParameters(0) = New SpParameter
            With lParameters(0)
                .ParameterName = "@CoverageID"
                .ParameterValue = pCoverageID
                .ParameterType = ParameterType.Varchar
            End With

            lParameters(1) = New SpParameter
            With lParameters(1)
                .ParameterName = "@NDC"
                .ParameterValue = pNDC
                .ParameterType = ParameterType.Varchar
            End With

            lParameters(2) = New SpParameter
            With lParameters(2)
                .ParameterName = "@PBM"
                .ParameterValue = pPBM
                .ParameterType = ParameterType.Varchar
            End With

            lResult = mDatabaseConnection.ExecuteQuery("usp_CheckMedicalNecessity", lParameters)

            If lResult.Tables(0).Rows.Count > 0 Then
                mCoverageDB.MedicalNecessity = True
            Else
                mCoverageDB.MedicalNecessity = False
            End If


        Catch ex As Exception
            ErrorLogMethods.LogError(ex, " RxHubLibrary\DAL\CoverageDB.GetMedicalNecessity(ByVal pCoverageID As String, ByVal pNDC As String, ByVal pPBM As String)")
            mCoverageDB.MedicalNecessity = False
        End Try
    End Sub



    Public Sub GetPriorAuthorization(ByVal pCoverageID As String, ByVal pNDC As String, ByVal pPBM As String)

        Dim lParameters(2) As SpParameter
        Dim lResult As DataSet = Nothing


        Try

            lParameters(0) = New SpParameter
            With lParameters(0)
                .ParameterName = "@CoverageID"
                .ParameterValue = pCoverageID
                .ParameterType = ParameterType.Varchar
            End With

            lParameters(1) = New SpParameter
            With lParameters(1)
                .ParameterName = "@NDC"
                .ParameterValue = pNDC
                .ParameterType = ParameterType.Varchar
            End With

            lParameters(2) = New SpParameter
            With lParameters(2)
                .ParameterName = "@PBM"
                .ParameterValue = pPBM
                .ParameterType = ParameterType.Varchar
            End With

            lResult = mDatabaseConnection.ExecuteQuery("usp_CheckPriorAuthorization", lParameters)

            If lResult.Tables(0).Rows.Count > 0 Then
                mCoverageDB.PriorAuthorization = True
            Else
                mCoverageDB.PriorAuthorization = False
            End If


        Catch ex As Exception            
            ErrorLogMethods.LogError(ex, " RxHubLibrary\DAL\CoverageDB.GetPriorAuthorization(ByVal pCoverageID As String, ByVal pNDC As String, ByVal pPBM As String)")
            mCoverageDB.PriorAuthorization = False
        End Try
    End Sub




    Public Sub GetExcluded(ByVal pCoverageID As String, ByVal pNDC As String, ByVal pPBM As String)

        Dim lParameters(2) As SpParameter
        Dim lResult As DataSet = Nothing


        Try

            lParameters(0) = New SpParameter
            With lParameters(0)
                .ParameterName = "@CoverageID"
                .ParameterValue = pCoverageID
                .ParameterType = ParameterType.Varchar
            End With

            lParameters(1) = New SpParameter
            With lParameters(1)
                .ParameterName = "@NDC"
                .ParameterValue = pNDC
                .ParameterType = ParameterType.Varchar
            End With

            lParameters(2) = New SpParameter
            With lParameters(2)
                .ParameterName = "@PBM"
                .ParameterValue = pPBM
                .ParameterType = ParameterType.Varchar
            End With

            lResult = mDatabaseConnection.ExecuteQuery("usp_CheckExclusionList", lParameters)

            If lResult.Tables(0).Rows.Count > 0 Then
                mCoverageDB.Excluded = True
            Else
                mCoverageDB.Excluded = False
            End If


        Catch ex As Exception            
            ErrorLogMethods.LogError(ex, " RxHubLibrary\DAL\CoverageDB.GetExcluded(ByVal pCoverageID As String, ByVal pNDC As String, ByVal pPBM As String)")
            mCoverageDB.Excluded = False
        End Try
    End Sub


    'This gets the resource links for a specified NDC
    Public Sub GetResourceLinks(ByVal pCoverageID As String, ByVal pNDC As String, ByVal pPBM As String)

        Dim lParameters(2) As SpParameter
        Dim lResult As DataSet = Nothing

        mCoverageDB.ResourceLinkExists = False



        Try

            lParameters(0) = New SpParameter
            With lParameters(0)
                .ParameterName = "@CoverageID"
                .ParameterValue = pCoverageID
                .ParameterType = ParameterType.Varchar
            End With

            lParameters(1) = New SpParameter
            With lParameters(1)
                .ParameterName = "@NDC"
                .ParameterValue = pNDC
                .ParameterType = ParameterType.Varchar
            End With

            lParameters(2) = New SpParameter
            With lParameters(2)
                .ParameterName = "@PBM"
                .ParameterValue = pPBM
                .ParameterType = ParameterType.Varchar
            End With


            lResult = mDatabaseConnection.ExecuteQuery("usp_GetResourceLinks", lParameters)

            If lResult.Tables(0).Rows.Count > 0 Then

                Dim lResourceLink(lResult.Tables(0).Rows.Count - 1) As String
                Dim lResourceLinkType(lResult.Tables(0).Rows.Count - 1) As String

                For x As Integer = 0 To lResult.Tables(0).Rows.Count - 1
                    lResourceLink(x) = lResult.Tables(0).Rows(x).Item("URL")
                    lResourceLinkType(x) = GetDescription(lResult.Tables(0).Rows(x).Item("ResourceTypeLink"))
                Next


                If lResult.Tables(0).Select(" Type='DS'").Length > 0 Then
                    mCoverageDB.DSResourceLinkExists = True
                End If

                If lResult.Tables(0).Select(" Type='SL'").Length > 0 Then
                    mCoverageDB.SLResourceLinkExists = True
                End If


                mCoverageDB.ResourceLink = lResourceLink
                mCoverageDB.ResourceLinkType = lResourceLinkType

                mCoverageDB.ResourceLinkExists = True

            End If


        Catch ex As Exception            
            ErrorLogMethods.LogError(ex, " RxHubLibrary\DAL\CoverageDB.GetResourceLinks(ByVal pCoverageID As String, ByVal pNDC As String, ByVal pPBM As String)")
            mCoverageDB.ResourceLinkExists = False
        End Try
    End Sub


    Private Function GetDescription(ByVal pCode As String) As String

        Try

            Select Case pCode
                Case "AL" : GetDescription = "Age Limit"
                Case "DE" : GetDescription = "Product Coverage Exclusion"
                Case "GL" : GetDescription = "Gender Limit"
                Case "MN" : GetDescription = "Medical Necessity"
                Case "PA" : GetDescription = "Prior Authorization"
                Case "QL" : GetDescription = "Quantity Limit"
                Case "ST" : GetDescription = "Step Therapy"
                Case "GI" : GetDescription = "General Info"
                Case "CP" : GetDescription = "Copay"
                Case "FM" : GetDescription = "Formulary"
                Case Else : GetDescription = ""
            End Select

        Catch ex As Exception
            GetDescription = ""            
            ErrorLogMethods.LogError(ex, " : RxHubLibrary\DAL\CoverageDB.GetDescription(ByVal pCode As String)")
        End Try

    End Function


    'This sub gets the Coverage Text Messages
    Public Sub GetTextMessages(ByVal pCoverageID As String, ByVal pNDC As String, ByVal pPBM As String)

        Dim lParameters(2) As SpParameter
        Dim lResult As DataSet = Nothing


        Try

            lParameters(0) = New SpParameter
            With lParameters(0)
                .ParameterName = "@CoverageID"
                .ParameterValue = pCoverageID
                .ParameterType = ParameterType.Varchar
            End With

            lParameters(1) = New SpParameter
            With lParameters(1)
                .ParameterName = "@NDC"
                .ParameterValue = pNDC
                .ParameterType = ParameterType.Varchar
            End With

            lParameters(2) = New SpParameter
            With lParameters(2)
                .ParameterName = "@PBM"
                .ParameterValue = pPBM
                .ParameterType = ParameterType.Varchar
            End With


            lResult = mDatabaseConnection.ExecuteQuery("usp_GetTextMessages", lParameters)

            If lResult.Tables(0).Rows.Count > 0 Then

                Dim lTextMessage(lResult.Tables(0).Rows.Count - 1) As String

                For x As Integer = 0 To lResult.Tables(0).Rows.Count - 1
                    lTextMessage(x) = lResult.Tables(0).Rows(x).Item("ShortMessage").ToString + IIf(lResult.Tables(0).Rows(x).Item("LongMessage").ToString.Equals(""), ".", " <BR> [<B>Long Message:</B> <BR>" + lResult.Tables(0).Rows(x).Item("LongMessage").ToString + "]")
                    'lTextMessage(x) = IIf(lResult.Tables(0).Rows(x).Item("LongMessage").ToString.Equals(""), lResult.Tables(0).Rows(x).Item("ShortMessage").ToString, lResult.Tables(0).Rows(x).Item("LongMessage").ToString)
                    'CHANGE DESCRIPTION: UNCOMMENTED THE TEXT MESSAGE APPEND LINE AND COMMENTED THE OTHER ONE. THIS WAS TO SATISFY THE F10B SCENARIO.
                    'Note : You can also add the long message (if any)
                Next

                mCoverageDB.TextMessage = lTextMessage
            Else
                mCoverageDB.TextMessageExists = False
            End If

        Catch ex As Exception
            ErrorLogMethods.LogError(ex, " RxHubLibrary\DAL\CoverageDB.GetTextMessages(ByVal pCoverageID As String, ByVal pNDC As String, ByVal pPBM As String) ")
            mCoverageDB.TextMessageExists = False
        End Try
    End Sub



    'This procedure gets the step Medications for a drug
    Public Sub GetStepMedications(ByVal pCoverageID As String, ByVal pNDC As String, ByVal pPBM As String)

        Dim lParameters(2) As SpParameter
        Dim lResult As DataSet = Nothing
        Dim lMSDrugMethods As MSDrugMethods = Nothing

        Try

            lMSDrugMethods = New MSDrugMethods

            lParameters(0) = New SpParameter
            With lParameters(0)
                .ParameterName = "@CoverageID"
                .ParameterValue = pCoverageID
                .ParameterType = ParameterType.Varchar
            End With

            lParameters(1) = New SpParameter
            With lParameters(1)
                .ParameterName = "@NDC"
                .ParameterValue = pNDC
                .ParameterType = ParameterType.Varchar
            End With

            lParameters(2) = New SpParameter
            With lParameters(2)
                .ParameterName = "@PBM"
                .ParameterValue = pPBM
                .ParameterType = ParameterType.Varchar
            End With


            lResult = mDatabaseConnection.ExecuteQuery("usp_GetStepMedication", lParameters)

            If lResult.Tables(0).Rows.Count > 0 Then

                Dim lStepMedication(lResult.Tables(0).Rows.Count - 1) As String
                Dim lStepOrder(lResult.Tables(0).Rows.Count - 1) As String

                mCoverageDB.StepCount = lResult.Tables(0).Rows.Count
                Dim lDDID As String = ""
                Dim lDrugDDID As String
                Dim lDrugOrder As String

                For x As Integer = 0 To lResult.Tables(0).Rows.Count - 1
                    If lResult.Tables(0).Rows(x).Item("StepClassID").ToString.Equals("") Then
                        'Means that a step NDC is listed

                        lDrugDDID = lMSDrugMethods.GetDDIDByNDC(lResult.Tables(0).Rows(x).Item("StepProductID"))
                        lDrugOrder = lResult.Tables(0).Rows(x).Item("StepOrder")

                        If Not lDDID.Contains(lDrugDDID + "~" + lDrugOrder) Then
                            lDDID += "|" + lDrugDDID + "~" + lDrugOrder + "|"
                            lStepMedication(x) = lMSDrugMethods.GetDrugName(lResult.Tables(0).Rows(x).Item("StepProductID"))
                            lStepOrder(x) = lResult.Tables(0).Rows(x).Item("StepOrder")
                        End If



                    Else

                        lDrugDDID = lMSDrugMethods.GetDDIDByNDC(lResult.Tables(0).Rows(x).Item("ProductID"))

                        If Not lDDID.Contains(lDrugDDID) Then
                            lDDID += "|" + lDrugDDID + "|"
                            lStepMedication(x) = lMSDrugMethods.GetDrugName(lResult.Tables(0).Rows(x).Item("ProductID"))
                            lStepOrder(x) = lResult.Tables(0).Rows(x).Item("StepOrder")
                        End If

                    End If

                Next

                mCoverageDB.StepMedication = lStepMedication
                mCoverageDB.StepOrder = lStepOrder
                mCoverageDB.StepMedicationExists = True

            Else
                mCoverageDB.StepMedicationExists = False
            End If

        Catch ex As Exception            
            ErrorLogMethods.LogError(ex, " RxHubLibrary\DAL\CoverageDB.GetStepMedications(ByVal pCoverageID As String, ByVal pNDC As String, ByVal pPBM As String) ")
            mCoverageDB.StepMedicationExists = False
        End Try

    End Sub



    'This function gets the Gender Limits
    Public Sub GetGenderLimits(ByVal pCoverageID As String, ByVal pNDC As String, ByVal pPBM As String)

        Dim lParameters(2) As SpParameter
        Dim lResult As String = Nothing

        Try


            lParameters(0) = New SpParameter
            With lParameters(0)
                .ParameterName = "@CoverageID"
                .ParameterValue = pCoverageID
                .ParameterType = ParameterType.Varchar
            End With

            lParameters(1) = New SpParameter
            With lParameters(1)
                .ParameterName = "@NDC"
                .ParameterValue = pNDC
                .ParameterType = ParameterType.Varchar
            End With

            lParameters(2) = New SpParameter
            With lParameters(2)
                .ParameterName = "@PBM"
                .ParameterValue = pPBM
                .ParameterType = ParameterType.Varchar
            End With

            'This returns either "1" or "2" for male and female respectively
            lResult = mDatabaseConnection.ExecuteScalarQuery("usp_GetGenderLimit", lParameters)

            If lResult IsNot Nothing Then
                mCoverageDB.Gender = lResult
            Else
                mCoverageDB.GenderLimitExists = False
            End If

        Catch ex As Exception            
            ErrorLogMethods.LogError(ex, " RxHubLibrary\DAL\CoverageDB.GetGenderLimits(ByVal pCoverageID As String, ByVal pNDC As String, ByVal pPBM As String) ")
            mCoverageDB.GenderLimitExists = False
        End Try
    End Sub

    'This sub gets the Age Limits
    Public Sub GetAgeLimits(ByVal pCoverageID As String, ByVal pNDC As String, ByVal pPBM As String)
        Dim lParameters(2) As SpParameter
        Dim lResult As DataSet = Nothing

        Try

            lParameters(0) = New SpParameter
            With lParameters(0)
                .ParameterName = "@CoverageID"
                .ParameterValue = pCoverageID
                .ParameterType = ParameterType.Varchar
            End With

            lParameters(1) = New SpParameter
            With lParameters(1)
                .ParameterName = "@NDC"
                .ParameterValue = pNDC
                .ParameterType = ParameterType.Varchar
            End With

            lParameters(2) = New SpParameter
            With lParameters(2)
                .ParameterName = "@PBM"
                .ParameterValue = pPBM
                .ParameterType = ParameterType.Varchar
            End With


            lResult = mDatabaseConnection.ExecuteQuery("usp_GetAgeLimit", lParameters)

            If lResult.Tables(0).Rows.Count > 0 Then

                With mCoverageDB
                    .MinimumAge = lResult.Tables(0).Rows(0).Item("MinimumAge").ToString
                    .MinimumAgeQualifier = lResult.Tables(0).Rows(0).Item("MinimumAgeQual").ToString
                    .MaximumAge = lResult.Tables(0).Rows(0).Item("MaximumAge").ToString
                    .MaximumAgeQualifier = lResult.Tables(0).Rows(0).Item("MaximumAgeQual").ToString
                End With
            Else
                mCoverageDB.AgeLimitExists = False
            End If

        Catch ex As Exception            
            ErrorLogMethods.LogError(ex, " RxHubLibrary\DAL\CoverageDB.GetAgeLimits(ByVal pCoverageID As String, ByVal pNDC As String, ByVal pPBM As String) ")
            mCoverageDB.AgeLimitExists = False
        End Try
    End Sub

    'This sub gets the Quantity Limits
    Public Sub GetQuantityLimits(ByVal pCoverageID As String, ByVal pNDC As String, ByVal pPBM As String)

        Dim lParameters(2) As SpParameter
        Dim lResult As DataSet = Nothing


        Try

            lParameters(0) = New SpParameter
            With lParameters(0)
                .ParameterName = "@CoverageID"
                .ParameterValue = pCoverageID
                .ParameterType = ParameterType.Varchar
            End With

            lParameters(1) = New SpParameter
            With lParameters(1)
                .ParameterName = "@NDC"
                .ParameterValue = pNDC
                .ParameterType = ParameterType.Varchar
            End With

            lParameters(2) = New SpParameter
            With lParameters(2)
                .ParameterName = "@PBM"
                .ParameterValue = pPBM
                .ParameterType = ParameterType.Varchar
            End With


            lResult = mDatabaseConnection.ExecuteQuery("usp_GetQuantityLimit", lParameters)

            Dim lQuantityLimit(lResult.Tables(0).Rows.Count - 1) As QuantityLimit

            If lResult.Tables(0).Rows.Count > 0 Then
                For x As Integer = 0 To lResult.Tables(0).Rows.Count - 1
                    lQuantityLimit(x) = New QuantityLimit()
                    With lQuantityLimit(x)
                        .Quantity = lResult.Tables(0).Rows(x).Item("MaxAmount").ToString
                        .QuantityQualifier = lResult.Tables(0).Rows(x).Item("MaxAmountQual").ToString
                        .TimePeriodQualifier = lResult.Tables(0).Rows(x).Item("MaxAmountTime").ToString
                        .TimePeriod = lResult.Tables(0).Rows(x).Item("MaxAmountTimeUnits").ToString
                        .TimePeriodStartDate = lResult.Tables(0).Rows(x).Item("MaxAmountTimeStartDate").ToString
                        .TimePeriodEndDate = lResult.Tables(0).Rows(x).Item("MaxAmountTimeEndDate").ToString
                    End With
                Next

                mCoverageDB.QuantityLimit = lQuantityLimit
                mCoverageDB.QuantityLimitExists = True

            Else
                mCoverageDB.QuantityLimitExists = False
            End If

        Catch ex As Exception
            ErrorLogMethods.LogError(ex, " RxHubLibrary\DAL\CoverageDB.GetQuantityLimits(ByVal pCoverageID As String, ByVal pNDC As String, ByVal pPBM As String) ")
            mCoverageDB.QuantityLimitExists = False
        End Try
    End Sub

End Class

#End Region

