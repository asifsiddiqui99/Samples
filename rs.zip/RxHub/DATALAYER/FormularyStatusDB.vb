Imports System.Data.SqlClient
Imports ElixirLibrary
Imports System.Configuration
Imports MedispanLibrary


#Region "FormularyStatusDB"

Public Class FormularyStatusDB

End Class

#End Region


#Region "FormularyStatus"

Public Class FormularyStatus
    ' This function gets the status of the type of medicine
    Public Function GetTypeStatus(ByVal pFormularyListID As String, ByVal pType As String, ByVal pPbm As String) As String
        Dim lDatabaseConnection As Connection
        Dim lParameters(1) As SpParameter
        Dim lResult As DataSet
        Dim lStatus As String = ""

        Try

            lDatabaseConnection = New Connection(ConfigurationManager.ConnectionStrings("RxHubConnectionString").ConnectionString())

            lParameters(0) = New SpParameter
            With lParameters(0)
                .ParameterName = "@FormularyListID"
                .ParameterValue = pFormularyListID
                .ParameterType = ParameterType.Varchar
            End With


            lParameters(1) = New SpParameter
            With lParameters(1)
                .ParameterName = "@PBM"
                .ParameterValue = pPbm
                .ParameterType = ParameterType.Varchar
            End With


            lResult = lDatabaseConnection.ExecuteQuery("usp_CheckFormularyListExistance", lParameters)

            If lResult.Tables(0).Rows.Count = 0 Then
                Return ""
            End If

            Select Case pType
                Case "B"
                    lStatus = lResult.Tables(0).Rows(0).Item("PrescriptionBrand")
                Case "G"
                    lStatus = lResult.Tables(0).Rows(0).Item("PrescriptionGeneric")
                Case "T"
                    lStatus = lResult.Tables(0).Rows(0).Item("PrescriptionBrand")
            End Select

        Catch ex As Exception
            ErrorLogMethods.LogError(ex, " RxHubLibrary\DAL\FormularyStatusDB.GetTypeStatus(ByVal pFormularyListID As String, ByVal pType As String)")
            lStatus = ""
        End Try

        Return lStatus

    End Function

    ' This function is an overloaded version of above
    Public Function GetTypeStatus(ByVal pFormularyListID As String, ByVal pType As String, ByVal pOTC As String, ByVal pNonDrug As String, ByVal pPBM As String) As String
        Dim lDatabaseConnection As New Connection(ConfigurationManager.ConnectionStrings("RxHubConnectionString").ConnectionString())
        Dim lParameters(1) As SpParameter
        Dim lResult As DataSet
        Dim lStatus As String = ""

        Try



            lParameters(0) = New SpParameter
            With lParameters(0)
                .ParameterName = "@FormularyListID"
                .ParameterValue = pFormularyListID
                .ParameterType = ParameterType.Varchar
            End With


            lParameters(1) = New SpParameter
            With lParameters(1)
                .ParameterName = "@PBM"
                .ParameterValue = pPBM
                .ParameterType = ParameterType.Varchar
            End With

            lResult = lDatabaseConnection.ExecuteQuery("usp_CheckFormularyListExistance", lParameters)

            If lResult.Tables(0).Rows.Count = 0 Then
                Return ""
            End If

            'Checks if the drug is nonDrug then assigns the supplies status
            If pNonDrug.Equals("Y") Then
                lStatus = lResult.Tables(0).Rows(0).Item("Supplies")
                Return lStatus
                Exit Function
            End If

            Select Case pType
                Case "B"
                    If pOTC.Equals("O") Then
                        lStatus = lResult.Tables(0).Rows(0).Item("BrandOverCounter")
                    Else
                        lStatus = lResult.Tables(0).Rows(0).Item("PrescriptionBrand")
                    End If

                Case "G"
                    If pOTC.Equals("O") Then
                        lStatus = lResult.Tables(0).Rows(0).Item("GenericOverCounter")
                    Else
                        lStatus = lResult.Tables(0).Rows(0).Item("PrescriptionGeneric")
                    End If

                Case "T"
                    If pOTC.Equals("O") Then
                        lStatus = lResult.Tables(0).Rows(0).Item("BrandOverCounter")
                    Else
                        lStatus = lResult.Tables(0).Rows(0).Item("PrescriptionBrand")
                    End If
            End Select

        Catch ex As Exception
            'Throw New Exception(ex.Message & " : RxHubLibrary\DAL\FormularyStatusDB.GetTypeStatus(ByVal pFormularyListID As String, ByVal pType As String, ByVal pOTC As String, ByVal pNonDrug As String) ")
            ErrorLogMethods.LogError(ex, " RxHubLibrary\DAL\FormularyStatusDB.GetTypeStatus(ByVal pFormularyListID As String, ByVal pType As String, ByVal pOTC As String, ByVal pNonDrug As String) ")
            lStatus = ""
        End Try

        Return lStatus

    End Function
    Public Function CheckFormularyListExistance(ByVal pFormularyListID As String, ByVal pPBM As String) As Boolean

        Dim lDatabaseConnection As Connection = Nothing
        Dim lParameters(1) As SpParameter

        Dim lResult As Integer = 0

        Try

            lDatabaseConnection = New Connection(ConfigurationManager.ConnectionStrings("RxHubConnectionString").ConnectionString())

            lParameters(0) = New SpParameter
            With lParameters(0)
                .ParameterName = "@FormularyListID"
                .ParameterValue = pFormularyListID
                .ParameterType = ParameterType.Varchar
            End With

            lParameters(1) = New SpParameter
            With lParameters(1)
                .ParameterName = "@PBM"
                .ParameterValue = pPBM
                .ParameterType = ParameterType.Varchar
            End With

            lResult = lDatabaseConnection.ExecuteScalarQuery("usp_CheckFormularyListExistance", lParameters)

            If lResult = 0 Then
                'No data found
                Return False
            Else
                Return True
            End If

        Catch ex As Exception
            ErrorLogMethods.LogError(ex, " RxHubLibrary\DAL\FormularyStatusDB.CheckFormularyListExistance(ByVal pFormularyListID As String) ")
            Return False
        End Try

    End Function



    ' This function checks whether the drug is excluded from the coverage
    Public Function CheckExclusionList(ByVal pNDC As String, ByVal pCoverageID As String, ByVal pPbm As String) As Boolean
        Dim lDatabaseConnection As New Connection(ConfigurationManager.ConnectionStrings("RxHubConnectionString").ConnectionString())        
        Dim lResult As Integer
        Dim lParameters(2) As SpParameter


        Try


            lParameters(0) = New SpParameter
            With lParameters(0)
                .ParameterName = "@NDC"
                .ParameterValue = pNDC
                .ParameterType = ParameterType.Varchar
            End With

            lParameters(1) = New SpParameter
            With lParameters(1)
                .ParameterName = "@CoverageID"
                .ParameterValue = pCoverageID
                .ParameterType = ParameterType.Varchar
            End With

            lParameters(2) = New SpParameter
            With lParameters(2)
                .ParameterName = "@PBM"
                .ParameterValue = pPbm
                .ParameterType = ParameterType.Varchar
            End With

            lResult = lDatabaseConnection.ExecuteScalarQuery("usp_CheckExclusionList", lParameters)


            If lResult = 0 Then
                'Not found in the exclusion list
                Return False
            Else
                'Found in the exclusion list
                Return True
            End If

        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\DAL\FormularyStatusDB.CheckExclusionList(ByVal pNDC As String, ByVal pCoverageID As String, ByVal pPbm As String) ")
        End Try
    End Function

    'This returns all the instances of formulary or preferred levels
    ''Change Description '''''''''''''''''''''''''''''''''''''''''''''
    ''AUTHOR: FARAZ
    ''CHANGED THE pNDC TO pDDID
    ''DATE: 6TH MARCH 2012
    ''End Change '''''''''''''''''''''''''''''''''''''''''''''''''''''
    Public Function GetFormularyStatus(ByVal pFormularyListID As String, ByVal pDDID As String, ByVal pPBM As String) As DataSet

        Dim lDatabaseConnection As New Connection(ConfigurationManager.ConnectionStrings("RxHubConnectionString").ConnectionString())
        Dim ds As New DataSet
        Dim ds2 As New DataSet
        Dim dsResult As New DataSet
        Dim folderid As Integer = 0
        Dim sql As String = ""
        Dim internalformularyid As Integer = 0

        Try

            sql = "SELECT FolderID FROM FolderHdr where (ParticipantName = '" & pPBM & "')"
            ds = lDatabaseConnection.ExecuteQuery(sql)
            If ds.Tables(0).Rows.Count > 0 Then
                folderid = ds.Tables(0).Rows(0)("FolderID")
                sql = "SELECT internalformularyid FROM FormularyHdr where  FolderID = " & folderid & " and FormularyID ='" & pFormularyListID & "'"
                ds2 = lDatabaseConnection.ExecuteQuery(sql)
                If ds2.Tables(0).Rows.Count > 0 Then
                    internalformularyid = ds2.Tables(0).Rows(0)("InternalFormularyid")
                    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Change LOG'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    ''Faraz Ahmed
                    ''Returning all the NDCs
                    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''                    
                    sql = "SELECT Dtl.FormularyStatus, Dtl.ProductID FROM FormularyDtl AS Dtl where InternalFormularyID =" & internalformularyid & " and Dtl.DDID = '" & pDDID & " ' ORDER BY Dtl.FormularyStatus DESC"
                    dsResult = lDatabaseConnection.ExecuteQuery(sql)
                End If

            End If

        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\DAL\FormularyStatusDB.GetFormularyStatus(ByVal pFormularyListID As String, ByVal pNDC As String, ByVal pPBM As String) ")
        End Try

        Return dsResult
    End Function

    Public Function GetFormularyStatusWithNDCs(ByVal pFormularyListID As String, ByVal pNDC As String, ByVal pPBM As String) As DataSet

        Dim lDatabaseConnection As New Connection(ConfigurationManager.ConnectionStrings("RxHubConnectionString").ConnectionString())
        Dim ds As New DataSet
        Dim ds2 As New DataSet
        Dim dsResult As New DataSet
        Dim folderid As Integer = 0
        Dim sql As String = ""
        Dim lWhereClause As String = ""
        Dim internalformularyid As Integer = 0

        Try

            sql = "SELECT FolderID FROM FolderHdr where (ParticipantName = '" & pPBM & "')"
            ds = lDatabaseConnection.ExecuteQuery(sql)
            If ds.Tables(0).Rows.Count > 0 Then
                folderid = ds.Tables(0).Rows(0)("FolderID")
                sql = "SELECT internalformularyid FROM FormularyHdr where  FolderID = " & folderid & " and FormularyID ='" & pFormularyListID & "'"
                ds2 = lDatabaseConnection.ExecuteQuery(sql)
                If ds2.Tables(0).Rows.Count > 0 Then
                    internalformularyid = ds2.Tables(0).Rows(0)("InternalFormularyid")        
                    sql = "SELECT top(1) Dtl.MaxFormularyStatus,isotc,isgeneric,isnondrug FROM FormularyDtl AS Dtl where InternalFormularyID =" & internalformularyid & " and Dtl.ProductID IN (" & pNDC & ") ORDER BY Dtl.MaxFormularyStatus DESC"
                    dsResult = lDatabaseConnection.ExecuteQuery(sql)
                End If
            End If

        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\DAL\FormularyStatusDB.GetFormularyStatusWithNDCs(ByVal pFormularyListID As String, ByVal pNDC As String, ByVal pPBM As String) ")
        End Try

        Return dsResult
    End Function

    Public Function GetFullStatus(ByVal pDDID As String, ByVal pFormularyID As String, ByVal pCoverageID As String, ByVal pPBM As String) As DataSet

        Dim lDatabaseConnection As New Connection(ConfigurationManager.ConnectionStrings("RxHubConnectionString").ConnectionString())
        Dim lResult As DataSet = Nothing
        Dim lParameters(3) As SpParameter

        Try


            lParameters(0) = New SpParameter
            With lParameters(0)
                .ParameterName = "@DDID"
                .ParameterValue = pDDID
                .ParameterType = ParameterType.NVarchar
            End With

            lParameters(1) = New SpParameter
            With lParameters(1)
                .ParameterName = "@FormularyID"
                .ParameterValue = pFormularyID
                .ParameterType = ParameterType.NVarchar
            End With

            lParameters(2) = New SpParameter
            With lParameters(2)
                .ParameterName = "@PBM"
                .ParameterValue = pPBM
                .ParameterType = ParameterType.NVarchar
            End With


            lParameters(3) = New SpParameter
            With lParameters(3)
                .ParameterName = "@CoverageID"
                .ParameterValue = pCoverageID
                .ParameterType = ParameterType.NVarchar
            End With


            lResult = lDatabaseConnection.ExecuteQuery("usp_GetMaximumStatus", lParameters)




        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\DAL\FormularyStatusDB.GetFullStatus(ByVal pDDID As String, ByVal pFormularyID As String, ByVal pCoverageID As String, ByVal pPBM As String) ")
        End Try

        Return lResult

    End Function

    'Public Function GetFullStatusByQuery(ByVal pDDID As String, ByVal pFormularyID As String, ByVal pCoverageID As String, ByVal pPBM As String) As DataSet

    '    Dim lDatabaseConnection As New Connection(ConfigurationManager.ConnectionStrings("RxHubConnectionString").ConnectionString())
    '    Dim lResult As DataSet = Nothing
    '    Dim lSql As String = String.Empty
    '    Dim lNDC As String = String.Empty
    '    Dim lMSdrugmethods As New MSDrugMethods
    '    Dim lCoverage As New Coverage


    '    Try
    '        ''ADD LOG
    '        ''ADDED THE SINGLE QUOTATION DILEMMA
    '        ''DATE : 6TH AUGUST 2008

    '        ''IF THE STRING CONTAINS ONE QUOTATION THEN
    '        If Trim(pDDID).Length < 2 AndAlso pDDID.Contains("'") Then
    '            ''ADD ANOTHER QUOTE
    '            pDDID &= "'"
    '        End If


    '        lSql = "select rtrim(ltrim(FD.DDID)) as DDID,IsGeneric, IsOTC, IsNonDrug, MaxFormularyStatus = case when Dtl.ddid is null then MaxFormularyStatus when Dtl.ddid is not null And Cov.CoverageListType ='DE' then '0' when Dtl.ddid is not null And Cov.CoverageListType <> 'DE' then MaxFormularyStatus end  " & _
    '                "from FolderHdr Folder " & _
    '                "inner join FormularyHdr FH on Folder.FolderID = FH.FolderID " & _
    '                "inner join FormularyDtl FD on FH.internalFormularyID = FD.internalFormularyID " & _
    '                "left outer join DDTCoverageInfoDtl Dtl on Dtl.DDID = FD.DDID and Coalesce(Dtl.CoverageID,'" & pCoverageID & "') = '" & pCoverageID & "' " & _
    '                "left outer join CoverageInfoHdr Cov on Dtl.InternalcoverageID = Cov.InternalCoverageID " & _
    '                "where " & _
    '                "Folder.ParticipantName = '" & pPBM & "' and FH.FormularyID = '" & pFormularyID & "' and FD.DDID In ( " & pDDID & ")"


    '        lResult = lDatabaseConnection.ExecuteQuery(lSql)




    '    Catch ex As Exception
    '        Throw New Exception(ex.Message & " : RxHubLibrary\DAL\FormularyStatusDB.GetFullStatusByQuery(ByVal pDDID As String, ByVal pFormularyID As String, ByVal pCoverageID As String, ByVal pPBM As String) ")
    '    End Try

    '    Return lResult
    'End Function


    'THIS FUNCTION REPLACES THE ONE ABOVE DUE TO TIMEOUT ERROR
    Public Function GetFullStatusByQuery(ByVal pDDID As String, ByVal pFormularyID As String, ByVal pCoverageID As String, ByVal pPBM As String) As DataSet

        Dim lDatabaseConnection As New Connection(ConfigurationManager.ConnectionStrings("RxHubConnectionString").ConnectionString())
        Dim lResult As DataSet = Nothing
        Dim lParameters(3) As SpParameter

        Try


            lParameters(0) = New SpParameter
            With lParameters(0)
                .ParameterName = "@formularyID"
                .ParameterValue = pFormularyID
                .ParameterType = ParameterType.NVarchar
            End With

            lParameters(1) = New SpParameter
            With lParameters(1)
                .ParameterName = "@ParticipantName"
                .ParameterValue = pPBM
                .ParameterType = ParameterType.NVarchar
            End With

            lParameters(2) = New SpParameter
            With lParameters(2)
                .ParameterName = "@Text"
                .ParameterValue = pDDID
                .ParameterType = ParameterType.NVarchar
            End With


            lParameters(3) = New SpParameter
            With lParameters(3)
                .ParameterName = "@CoverageID"
                .ParameterValue = pCoverageID
                .ParameterType = ParameterType.NVarchar
            End With


            lResult = lDatabaseConnection.ExecuteQuery("GetFullStatusByQuery", lParameters)




        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\DAL\FormularyStatusDB.GetFullStatusByQuery(ByVal pDDID As String, ByVal pFormularyID As String, ByVal pCoverageID As String, ByVal pPBM As String) ")
        End Try

        Return lResult

    End Function





End Class

#End Region

