Public Class ActivityLogDB
    Private mPrescriberDEA As String
    Private mPrescriberNPI As String
    Private mPrescriberConfidentialIdentifier As String
    Private mPrescriptionDate As Date
    Private mPrescriberFirstName As String
    Private mPrescriberLastName As String
    Private mHealthPlanID As String
    Private mHealthPlanGroupID As String
    Private mPrescriptionID As String
    Private mFormularyStatus As String
    Private mAgeLimit As Char
    Private mExclusionStatus As Char
    Private mLimitStatus As Char
    Private mMedicalNecessity As Char
    Private mPriorAuthorization As Char
    Private mQuantityLimit As Char
    Private mDrugSpecificResourceLink As Char
    Private mSummaryResourceLink As Char
    Private mStepMedication As Char
    Private mStepTherapy As Char
    Private mTextMessage As Char
    Private mNDCCode As String
    Private mPrescriptionDeliveryMethod As Char

    Public Property PrescriberDEA() As String
        Get
            Return mPrescriberDEA
        End Get
        Set(ByVal value As String)
            mPrescriberDEA = value
        End Set
    End Property

    Public Property PrescriberNPI() As String
        Get
            Return mPrescriberNPI
        End Get
        Set(ByVal value As String)
            mPrescriberNPI = value
        End Set
    End Property

    Public Property PrescriberConfidentialIdentifier() As String
        Get
            Return mPrescriberConfidentialIdentifier
        End Get
        Set(ByVal value As String)
            mPrescriberConfidentialIdentifier = value
        End Set
    End Property

    Public Property PrescriptionDate() As Date
        Get
            Return mPrescriptionDate
        End Get
        Set(ByVal value As Date)
            mPrescriptionDate = value
        End Set
    End Property

    Public Property PrescriberLastName() As String
        Get
            Return mPrescriberLastName
        End Get
        Set(ByVal value As String)
            mPrescriberLastName = value
        End Set
    End Property

    Public Property PrescriberFirstName() As String
        Get
            Return mPrescriberFirstName
        End Get
        Set(ByVal value As String)
            mPrescriberFirstName = value
        End Set
    End Property

    Public Property HealthPlanID() As String
        Get
            Return mHealthPlanID
        End Get
        Set(ByVal value As String)
            mHealthPlanID = value
        End Set
    End Property

    Public Property HealthPlanGroupID() As String
        Get
            Return mHealthPlanGroupID
        End Get
        Set(ByVal value As String)
            mHealthPlanGroupID = value
        End Set
    End Property

    Public Property PrescriptionID() As String
        Get
            Return mPrescriptionID
        End Get
        Set(ByVal value As String)
            mPrescriptionID = value
        End Set
    End Property

    Public Property FormularyStatus() As String
        Get
            Return mFormularyStatus
        End Get
        Set(ByVal value As String)
            mFormularyStatus = value
        End Set
    End Property

    Public Property AgeLimit() As Char
        Get
            Return mAgeLimit
        End Get
        Set(ByVal value As Char)
            mAgeLimit = value
        End Set
    End Property

    Public Property ExclusionStatus() As Char
        Get
            Return mExclusionStatus
        End Get
        Set(ByVal value As Char)
            mExclusionStatus = value
        End Set
    End Property

    Public Property LimitStatus() As Char
        Get
            Return mLimitStatus
        End Get
        Set(ByVal value As Char)
            mLimitStatus = value
        End Set
    End Property

    Public Property MedicalNecessity() As Char
        Get
            Return mMedicalNecessity
        End Get
        Set(ByVal value As Char)
            mMedicalNecessity = value
        End Set
    End Property

    Public Property PriorAuthorization() As Char
        Get
            Return mPriorAuthorization
        End Get
        Set(ByVal value As Char)
            mPriorAuthorization = value
        End Set
    End Property

    Public Property QuantityLink() As Char
        Get
            Return mQuantityLimit
        End Get
        Set(ByVal value As Char)
            mQuantityLimit = value
        End Set
    End Property

    Public Property DrugSpecificResourceLink() As Char
        Get
            Return mDrugSpecificResourceLink
        End Get
        Set(ByVal value As Char)
            mDrugSpecificResourceLink = value
        End Set
    End Property

    Public Property SummaryResourceLink() As Char
        Get
            Return mSummaryResourceLink
        End Get
        Set(ByVal value As Char)
            mSummaryResourceLink = value
        End Set
    End Property

    Public Property StepMedication() As Char
        Get
            Return mStepMedication
        End Get
        Set(ByVal value As Char)
            mStepMedication = value
        End Set
    End Property

    Public Property StepTherapy() As Char
        Get
            Return mStepTherapy
        End Get
        Set(ByVal value As Char)
            mStepTherapy = value
        End Set
    End Property

    Public Property TextMessage() As Char
        Get
            Return mTextMessage
        End Get
        Set(ByVal value As Char)
            mTextMessage = value
        End Set
    End Property

    Public Property NDCCode() As String
        Get
            Return mNDCCode
        End Get
        Set(ByVal value As String)
            mNDCCode = value
        End Set
    End Property

    Public Property PrescriptionDeliveryMethod() As Char
        Get
            Return mPrescriptionDeliveryMethod
        End Get
        Set(ByVal value As Char)
            mPrescriptionDeliveryMethod = value
        End Set
    End Property


End Class
