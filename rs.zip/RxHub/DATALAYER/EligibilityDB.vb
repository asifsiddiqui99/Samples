Imports System.Data.SqlClient
Imports ElixirLibrary
Imports System.Configuration

Public Class EligibilityDB


#Region "Eligibility"
    Public Function UpdatePBMName(ByVal pPBMId As String, ByVal pPBMName As String) As Boolean
        Dim lDatabaseConnection As New Connection(ConfigurationManager.ConnectionStrings("RxHubConnectionString").ConnectionString())
        Dim lDs As New DataSet
        Dim lQuery As String
        Dim lPBMName As String = ""

        Try
            lQuery = "Update FolderHdr Set ParticipantName='" & pPBMName & "' Where ParticipantId ='" & pPBMId & "'"
            'lQuery = "Select ParticipantName From FolderHdr " _
            '       & "Where ParticipantId = '" & pPBMId & "' "

            lDs = lDatabaseConnection.ExecuteQuery(lQuery)
            'If lDs.Tables(0).Rows.Count > 0 Then
            '    lPBMName = lDs.Tables(0).Rows(0)("ParticipantName")
            'End If
            Return True
        Catch ex As Exception
            Return False
            Throw New Exception(ex.Message & " : RxHubLibrary\DAL\EligibilityDB.UpdatePBMName(ByVal pPBMId As String) As String ")
        End Try

        Return lPBMName
    End Function
    

#End Region

End Class
