Imports ElixirLibrary
Imports System.Xml



Public Class Refill

#Region "Fields"

    Private mRefillDB As RefillBL
    Private mConnection As Connection

#End Region


#Region "Constructor"

    Public Sub New()
        mConnection = New Connection
        mRefillDB = New RefillBL("")
    End Sub

#End Region


#Region "Properties"


    Public Property RefillDB() As RefillBL
        Get
            Return mRefillDB
        End Get
        Set(ByVal value As RefillBL)
            mRefillDB = value
        End Set
    End Property


    Public ReadOnly Property Connection() As Connection
        Get
            Return mConnection
        End Get
    End Property


#End Region


#Region "Functions"


    Public Function AddMessageHdr(ByRef pConnection As Connection, _
                                              ByVal lDirection As String, _
                                              ByVal lCode As Long, _
                                              ByVal lFileName As String, _
                                              ByVal pXmlContents As String, _
                                              ByVal pClinicCode As String, _
                                              ByVal pMessageType As Integer) As Boolean

        Dim lQuery As String = String.Empty

        Try


            lQuery = "Insert Into RxHubMessageHdr (" _
                   & "MessageCode, MessageId, MessageTypeId, LastStatus," _
                   & "XMLPath, ClinicId, UserId, " _
                   & "PrescriberOrderNo, RxReferenceNo, " _
                   & "RelatesToMessageId, Direction, XMLContents, PharmacyCode) " _
                   & "VALUES(" _
                   & lCode & ", " _
                   & "'" & RefillDB.MessageID & "', " _
                   & pMessageType.ToString & "," _
                   & "'Pending'," _
                   & "'" & lFileName & "'," _
                   & "'" & pClinicCode & "'," _
                   & "'" & Me.RefillDB.PrescriberIdentification.IdentificationNumber & "'," _
                   & "'" & Me.RefillDB.PrescriberOrderNumber & "'," _
                   & "'" & Me.RefillDB.RxReferenceNumber & "'," _
                   & "'" & Me.RefillDB.RelatesToMessageID & "'," _
                   & "'" & lDirection & "', " _
                   & "'" & pXmlContents & "', " _
                   & "'" & Me.RefillDB.Clinic.ClinicCode & "')"

            If pConnection.IsTransactionAlive Then
                pConnection.ExecuteTransactionCommand(lQuery)
            Else
                pConnection.ExecuteCommand(lQuery)
            End If

        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\DAL\RefillDB.AddMessageHdr(ByRef pConnection As Connection,ByVal lDirection As String, ByVal lCode As Long, ByVal lFileName As String,ByVal pXmlContents As String,ByVal pClinicCode As String,ByVal pMessageType As Integer) ")
        End Try

        AddMessageHdr = True

    End Function


    Public Function AddMessageDtl(ByRef pConnection As Connection, _
                                      ByVal pDirection As String, _
                                      ByVal pCode As Long, _
                                      ByVal pMessageType As Integer) As Boolean


        Dim lQuery As String = String.Empty

        Try

            lQuery = "INSERT INTO RxHubMessageDtl(MessageCode, MessageTime, " _
                   & "Status, Code, DescriptionCode, " _
                   & "[Description],Direction,ReceivedMessageId, DetailMessageType) " _
                   & "VALUES(" _
                   & " " & pCode & ", " _
                   & "'" & Me.RefillDB.SentTime & "', " _
                   & "'Pending'," _
                   & "''," _
                   & "''," _
                   & "''," _
                   & "'" & pDirection & "'," _
                   & "'','" & pMessageType & "')"

            If pConnection.IsTransactionAlive Then
                pConnection.ExecuteTransactionCommand(lQuery)
            Else
                pConnection.ExecuteCommand(lQuery)
            End If

        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\DAL\RefillDB.AddMessageDtl(ByRef pConnection As Connection,ByVal pDirection As String,ByVal pCode As Long,ByVal pMessageType As Integer) ")
        End Try

        AddMessageDtl = True

    End Function

    ''' <summary>
    ''' Adds the whole message to the database
    ''' </summary>
    ''' <param name="filename">Name of the physical file created on disk</param>
    ''' <param name="lMsgId">Message Id </param>
    ''' <param name="pClinicCode">Clinic Code</param>
    ''' <param name="pXml">The whole Xml contents </param>
    ''' <param name="pMessageType">Indicating the type of message</param>
    ''' <remarks></remarks>
    Public Sub AddMessage(ByVal filename As String, _
                          ByVal lMsgId As String, _
                          ByVal pClinicCode As String, _
                          ByVal pXml As String, _
                          ByVal pMessageType As Integer, _
                          ByVal pDirection As Char)



        Dim lResult As Boolean
        Dim lCode As String = ""
        Dim lConnection As Connection = Nothing


        Try


            lConnection = New Connection()

            lConnection.BeginTrans()

            lCode = GetMessageCode(lConnection)
            RefillDB.MessageCode = lCode
            lResult = AddMessageHdr(lConnection, pDirection, lCode, filename, pXml, pClinicCode, pMessageType)
            lResult = AddMessageDtl(lConnection, pDirection, lCode, pMessageType)



            lConnection.CommitTrans()

        Catch ex As Exception
            lConnection.RollBackTrans()
            Throw New Exception(ex.Message & " : RxHubLibrary\DAL\RefillDB.AddMessage(ByVal filename As String,ByVal lMsgId As String, ByVal pClinicCode As String,ByVal pXml As String,ByVal pMessageType As Integer,ByVal pDirection As Char) ")
        End Try

    End Sub

    ''' <summary>
    ''' This saves the status information
    ''' </summary>
    ''' <param name="RecMessage">This is the recieved/Sent message</param>
    ''' <param name="pPrescriberOrderNumber">prescriber order number</param>
    ''' <param name="pMessageCode">Message Code (primary key of RxHubMessageHdr)</param>
    ''' <param name="pMasterMessageType">Message Type of the transaction taking place</param>
    ''' <param name="pDirection">Direction of the Transaction</param>
    ''' <param name="pStatusDirection">Direction of the status</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function SaveStatus( _
       ByVal RecMessage As String, _
       ByVal pPrescriberOrderNumber As String, _
       ByVal pMessageCode As String, _
       ByVal pMasterMessageType As Integer, _
       ByVal pDirection As Char, _
       ByVal pStatusDirection As Char) _
       As Boolean



        Dim lConnection As Connection = Nothing

        Dim lQuery As String
        Dim lDs As New DataSet
        Dim lStatus As Boolean = True
        Dim lMessageType As Integer
        Dim lMessageStatus As String = ""
        Dim lCode As String = ""
        Dim lMessageCode As String
        Dim lDescriptionCode As String = ""
        Dim lDescription As String = ""
        Dim lCheckMessage As Boolean = True
        Dim lRelatesToMessageID As String

        Dim lXmlDocument As XmlDocument

        Try

            lConnection = New Connection()
            lXmlDocument = New XmlDocument

            Try
                lXmlDocument.LoadXml(RecMessage)
            Catch ex As Exception
                lCheckMessage = False
            End Try


            lConnection.BeginTrans()


            lMessageCode = pMessageCode

            If lCheckMessage = True Then

                Select Case lXmlDocument.DocumentElement.SelectSingleNode("//Body/Status/Code").InnerText.ToString
                    Case "601"
                        lMessageStatus = "Failure"
                        lMessageType = 1
                        lCode = lXmlDocument.DocumentElement.SelectSingleNode("//Body/Status/Code").InnerText.ToString
                        If lXmlDocument.DocumentElement.SelectNodes("//Body/Status/DescriptionCode").Count > 0 Then
                            lDescriptionCode = lXmlDocument.DocumentElement.SelectSingleNode("//Body/Status/DescriptionCode").InnerText
                        Else
                            lDescriptionCode = ""
                        End If

                        lDescription = GetStatusDescription(lCode, lDescriptionCode)

                    Case "900"
                        lMessageStatus = "Failure"
                        lMessageType = 1
                        lCode = lXmlDocument.DocumentElement.SelectSingleNode("//Body/Status/Code").InnerText.ToString
                        If lXmlDocument.DocumentElement.SelectNodes("//Body/Status/DescriptionCode").Count > 0 Then
                            lDescriptionCode = lXmlDocument.DocumentElement.SelectSingleNode("//Body/Status/DescriptionCode").InnerText
                        Else
                            lDescriptionCode = ""
                        End If

                        lDescription = GetStatusDescription(lCode, lDescriptionCode)

                    Case "602"
                        lMessageStatus = "Pending"
                        lMessageType = 1
                        lCode = lXmlDocument.DocumentElement.SelectSingleNode("//Body/Status/Code").InnerText.ToString
                        lDescriptionCode = ""


                        lDescription = GetStatusDescription(lCode, lDescriptionCode)

                    Case "600"
                        lMessageStatus = "Pending"
                        lMessageType = 1
                        lCode = lXmlDocument.DocumentElement.SelectSingleNode("//Body/Status/Code").InnerText.ToString
                        lDescriptionCode = ""


                        lDescription = GetStatusDescription(lCode, lDescriptionCode)

                    Case "000"

                        lMessageStatus = "InProgress"
                        lMessageType = 3
                        lCode = lXmlDocument.DocumentElement.SelectSingleNode("//Body/Status/Code").InnerText.ToString

                        lDescriptionCode = ""


                        lDescription = GetStatusDescription(lCode, lDescriptionCode)

                    Case "010"
                        lMessageStatus = "Success"
                        lMessageType = 3
                        lCode = lXmlDocument.DocumentElement.SelectSingleNode("//Body/Status/Code").InnerText.ToString
                        lDescriptionCode = ""


                        lDescription = GetStatusDescription(lCode, lDescriptionCode)


                End Select


                lRelatesToMessageID = lXmlDocument.DocumentElement.SelectSingleNode("//Header/RelatesToMessageID").InnerText

            Else
                lMessageStatus = "Failure"
                lMessageType = 1
                lCode = "601"
                lDescription = "Receiver unable to process"

                lRelatesToMessageID = "0"
            End If



            lQuery = "Update RxHubMessageDtl Set Status = '" + lMessageStatus + "' " _
                   & "Where Direction = '" & pDirection & "' " _
                   & "And DetailMessageType = " + pMasterMessageType.ToString _
                   & "And MessageCode = " & lMessageCode & " "


            If lConnection.IsTransactionAlive Then
                lConnection.ExecuteTransactionCommand(lQuery)
            Else
                lConnection.ExecuteCommand(lQuery)
            End If


            lQuery = "Update RxHubMessageHdr " _
                   & "Set LastStatus ='" & lMessageStatus & "' " _
                   & "Where MessageCode = " & lMessageCode & " "


            If lConnection.IsTransactionAlive Then
                lConnection.ExecuteTransactionCommand(lQuery)
            Else
                lConnection.ExecuteCommand(lQuery)
            End If

            Dim lSentDate As String = Date.Now



            lQuery = "INSERT INTO RxHubMessageDtl(MessageCode, MessageTime, " _
                   & "Status, Code, DescriptionCode, " _
                   & "[Description],Direction,ReceivedMessageId,DetailMessageType) " _
                   & "VALUES(" _
                   & " " & lMessageCode & ", " _
                   & "'" & lSentDate & "', " _
                   & "'" & lMessageStatus & "'," _
                   & "'" & lCode & "'," _
                   & "'" & lDescriptionCode & "'," _
                   & "'" & lDescription & "'," _
                   & "'" & pStatusDirection & "'," _
                   & "'" & lRelatesToMessageID & "'," _
                   & " " & lMessageType & ")"


            If lConnection.IsTransactionAlive Then
                lConnection.ExecuteTransactionCommand(lQuery)
            Else
                lConnection.ExecuteCommand(lQuery)
            End If

            lConnection.CommitTrans()

            SaveStatus = lStatus

        Catch ex As Exception
            lConnection.RollBackTrans()
            SaveStatus = False            
            ErrorLogMethods.LogError(ex, " RxHubLibrary\DAL\RefillDB.SaveStatus(ByVal RecMessage As String,ByVal pPrescriberOrderNumber As String,ByVal pMessageCode As String,ByVal pMasterMessageType As Integer,ByVal pDirection As Char,ByVal pStatusDirection As Char) ")
        End Try

    End Function

    Public Function GetMessageCode(ByVal lConnection As Connection) As String

        Dim lDs As DataSet
        Dim lMessageCode As String = ""
        Dim lMessageNo As Integer = 0
        Dim lQuery As String

        Try

            lQuery = "Select IsNull(Max(MessageCode),0) + 1  AS MessageCode From RxHubMessageHdr "
            lDs = lConnection.ExecuteTransactionQuery(lQuery)
            If lDs.Tables.Count > 0 Then
                lMessageCode = CType(lDs.Tables(0).Rows(0)("MessageCode"), String)
            End If
            GetMessageCode = lMessageCode

        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\DAL\RefillDB.GetMessageCode(ByVal lConnection As Connection) ")
        End Try

    End Function



    ''' <summary>
    '''This function gets the Refill Xml from the database 
    ''' </summary>
    ''' <param name="pMessageID">An identifier to get the xmlcontents</param>    
    ''' <returns>a string denoting Xml contents</returns>
    ''' <remarks></remarks>
    Public Function GetRefillXml(ByVal pMessageID As String, ByVal pNCPDPID As String) As String
        Dim lDs As DataSet
        Dim lQuery As String

        'This is the default connection that gives access to RxCure Master
        Dim lConnection As New Connection

        Try

            lQuery = "Select XMLContents AS Contents From RxHubMessageHdr where MessageId =  '" & pMessageID & "' And PharmacyCode = '" & pNCPDPID & "'"
            lDs = lConnection.ExecuteQuery(lQuery)
            If lDs.Tables.Count > 0 Then
                GetRefillXml = CType(lDs.Tables(0).Rows(0)("Contents"), String)
            Else
                GetRefillXml = ""
            End If

        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\DAL\RefillDB.GetRefillXml(ByVal pMessageID As String, ByVal pNCPDPID As String) ")
        End Try

    End Function


    'This function returns the MessageId from the NumSeries table in RxCureMaster
    Public Function GetMessageID() As String

        Dim lDs As DataSet
        Dim lMessageNo As Integer = 0
        Dim lQuery As String
        Dim lMessageID As String = ""


        Try


            lQuery = "Select MessageIdNumeric+1 As MsgId, Prefix from NumSeries "

            If Connection.IsTransactionAlive Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If


            If lDs.Tables.Count > 0 Then
                lMessageID = CType(lDs.Tables(0).Rows(0)("Prefix"), String) & "-" _
                       & CType(lDs.Tables(0).Rows(0)("MsgId"), String).PadLeft(10, "0")

                lMessageNo = lDs.Tables(0).Rows(0)("MsgId")
            End If

            lQuery = "Update NumSeries Set CurrentMessageId ='" & lMessageID & "', " _
                   & "MessageIdNumeric = " & lMessageNo & " "

            If Connection.IsTransactionAlive Then
                Connection.ExecuteTransactionCommand(lQuery)
            Else
                Connection.ExecuteCommand(lQuery)
            End If

        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\DAL\RefillDB.GetMessageID() ")
        End Try

        GetMessageID = lMessageID

    End Function

    ''' <summary>
    ''' This gets the Status Description
    ''' </summary>
    ''' <param name="pCode"></param>
    ''' <param name="pDescriptionCode"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetStatusDescription(ByVal pCode As String, ByVal pDescriptionCode As String) As String

        Dim lDs As DataSet = Nothing
        Dim lMessageNo As Integer = 0
        Dim lQuery As String = String.Empty


        Try


            lQuery = "Select Description from ReferenceCodes where Code = '" & pCode & "' And DescriptionCode = '" & pDescriptionCode & "'"

            If Connection.IsTransactionAlive Then
                lDs = Connection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = Connection.ExecuteQuery(lQuery)
            End If

        Catch ex As Exception
            'Throw New Exception(ex.Message & " : RxHubLibrary\DAL\RefillDB.GetStatusDescription(ByVal pCode As String, ByVal pDescriptionCode As String) ")
            ErrorLogMethods.LogError(ex, " : RxHubLibrary\DAL\RefillDB.GetStatusDescription(ByVal pCode As String, ByVal pDescriptionCode As String) ")
        End Try


        GetStatusDescription = CType(lDs.Tables(0).Rows(0)("Description"), String)

    End Function


    Public Function SaveFinalStatus(ByVal pRequestXml As String, ByVal pConnectionString As String) As String
        Dim lXmlDocument As XmlDataDocument
        Dim lCode As String = ""
        Dim lDescription As String = ""
        Dim lMessageStatus As String = ""
        Dim lRelatesToMessageID As String = ""
        Dim lMessageCode As String = ""
        Dim lSentTime As String = ""
        Dim lCurrentStatus As String = ""

        Dim lQuery As String = ""
        Dim lDs As DataSet = Nothing
        Dim lRxID As String = ""

        Dim lConnection As Connection = Nothing
        Dim lLocalConnection As Connection = Nothing

        Try

            lConnection = New Connection
            lLocalConnection = New Connection(pConnectionString)
            lXmlDocument = New XmlDataDocument


            pRequestXml = "<Message>" & pRequestXml.Substring(pRequestXml.IndexOf("<Header>"))


            lConnection.BeginTrans()
            lLocalConnection.BeginTrans()

            lXmlDocument.LoadXml(pRequestXml)

            lCode = lXmlDocument.DocumentElement.SelectSingleNode("//Body/Status/Code").InnerText
            If lXmlDocument.DocumentElement.SelectNodes("//Body/Status/Description").Count > 0 Then
                lDescription = lXmlDocument.DocumentElement.SelectSingleNode("//Body/Status/Description").InnerText
            End If

            If lXmlDocument.DocumentElement.SelectNodes("//Header/RelatesToMessageID").Count > 0 Then
                lRelatesToMessageID = lXmlDocument.DocumentElement.SelectSingleNode("//Header/RelatesToMessageID").InnerText
            End If

            If lXmlDocument.DocumentElement.SelectNodes("//Header/SentTime").Count > 0 Then
                lSentTime = lXmlDocument.DocumentElement.SelectSingleNode("//Header/SentTime").InnerText
            End If

            If lCode.Equals("600") Or lCode.Equals("601") Or lCode.Equals("602") Or lCode.Equals("900") Then
                lMessageStatus = "Failure"
            End If

            lQuery = "Select LastStatus,MessageCode from RxHubMessageHdr " _
                                           & "Where MessageId = '" & lRelatesToMessageID & "' "

            lDs = lConnection.ExecuteTransactionQuery(lQuery)

            lCurrentStatus = CType(lDs.Tables(0).Rows(0).Item("LastStatus"), String)
            lMessageCode = CType(lDs.Tables(0).Rows(0).Item("MessageCode"), String)


            If lCurrentStatus.Equals("InProgress") Then

                lQuery = "Update RxHubMessageHdr " _
                                               & "Set LastStatus ='" & lMessageStatus & "' " _
                                               & "Where MessageId = '" & lRelatesToMessageID & "' "

                lConnection.ExecuteTransactionCommand(lQuery)


                lQuery = "Update RxHubMessageDtl " _
                                   & "Set Status ='" & lMessageStatus & "' " _
                                   & "Where MessageCode = " & lMessageCode & " "

                lConnection.ExecuteTransactionCommand(lQuery)


                lQuery = "INSERT INTO RxHubMessageDtl(MessageCode, MessageTime, " _
                       & "Status, Code, DescriptionCode, " _
                       & "[Description],Direction,ReceivedMessageId,DetailMessageType) " _
                       & "VALUES(" _
                       & " " & lMessageCode & ", " _
                       & "'" & lSentTime & "', " _
                       & "'" & lMessageStatus & "'," _
                       & "'" & lCode & "'," _
                       & "''," _
                       & "'" & lDescription & "'," _
                       & "'I'," _
                       & "'" & lRelatesToMessageID & "'," _
                       & " 1 )"

                lConnection.ExecuteTransactionCommand(lQuery)



                lQuery = "Select *, Cast(Right(PrescriberOrderNo,9) AS BigInt) AS PONo From RxHubMessageHdr " _
                   & "Where MessageId ='" & lRelatesToMessageID & "' "


                If lConnection.IsTransactionAlive Then
                    lDs = lConnection.ExecuteTransactionQuery(lQuery)
                Else
                    lDs = lConnection.ExecuteQuery(lQuery)
                End If

                If lDs.Tables(0).Rows.Count > 0 Then
                    lMessageCode = CType(lDs.Tables(0).Rows(0)("MessageCode"), Integer)
                    lRxID = lDs.Tables(0).Rows(0)("PoNo")
                End If




                lQuery = "Update RenewalRequest " _
                                   & "Set NewPrescriptionStatus = 'Pending' " _
                                   & "Where RenewalRequestID = (Select Distinct RenewalRequestID " _
                                   & "                         From RxList " _
                                   & "                         Where RxId = " & lRxID & " " _
                                   & "                         And RenewalRequestID <> 0) "

                lLocalConnection.ExecuteTransactionCommand(lQuery)





            End If

            lLocalConnection.CommitTrans()
            lConnection.CommitTrans()


        Catch ex As Exception
            lConnection.RollBackTrans()
            lLocalConnection.RollBackTrans()
            Throw New Exception(ex.Message & " : RxHubLibrary\DAL\RefillDB.SaveFinalStatus(ByVal pRequestXml As String, ByVal pConnectionString As String) ")
        End Try

        SaveFinalStatus = lCode & " - " & lDescription

    End Function

    Public Function CheckDuplicateKeys(ByVal pMessageID As String, ByVal pPharmacyID As String) As String

        Dim lQuery As String = ""
        Dim lDS As DataSet = Nothing
        Dim lConnection As Connection = Nothing

        Try
            lConnection = New Connection

            lQuery = "Select MessageCode from RxHubMessageHdr " _
                                                       & "Where MessageId = '" & pMessageID & "' " _
                                                       & "And PharmacyCode = '" & pPharmacyID & "' "

            lDS = lConnection.ExecuteQuery(lQuery)

            CheckDuplicateKeys = CType(lDS.Tables(0).Rows(0).Item("MessageCode"), String)
        Catch ex As Exception
            CheckDuplicateKeys = ""            
            ErrorLogMethods.LogError(ex, " RxHubLibrary\DAL\RefillDB.CheckDuplicateKeys(ByVal pMessageID As String, ByVal pPharmacyID As String) ")
        End Try
    End Function

    Public Function UpdateRenewal(ByVal pRelatesToMessageId As String, ByVal pNCPDPID As String, ByVal pConnectionString As String) As Boolean

        Dim lQuery As String = ""
        Dim lConnection As Connection = Nothing

        Try

            lConnection = New Connection(pConnectionString)

            lConnection.BeginTrans()

            lQuery = "Update RenewalRequest " _
                                   & "Set IsSent ='Y' " _
                                   & "Where MessageId ='" & pRelatesToMessageId & "' " _
                                   & "And NCPDPID ='" & pNCPDPID & "' "

            lConnection.ExecuteTransactionCommand(lQuery)



            lQuery = "Update RenewalResponse " _
                       & "Set IsApproved ='Y' " _
                       & "Where RenewalResponseId = " _
                       & "  (Select Max(RenewalResponseId) From RenewalResponse RR, RenewalRequest Req  " _
                       & "   Where RR.RenewalRequestId = Req.RenewalRequestId " _
                       & "   And Req.MessageId ='" & pRelatesToMessageId & "' " _
                       & "   And Req.NCPDPID ='" & pNCPDPID & "') "


            lConnection.ExecuteTransactionCommand(lQuery)



            lQuery = "Update RenewalResponse " _
                                   & "Set IsSent = 'Y' " _
                                   & "Where RenewalRequestId = ( " _
                                   & "        Select RenewalRequestId From RenewalRequest " _
                                   & "        Where MessageId ='" & pRelatesToMessageId & "' " _
                                   & "        And NCPDPID ='" & pNCPDPID & "') " _
                                   & "And IsApproved = 'Y' "


            lConnection.ExecuteTransactionCommand(lQuery)
            lConnection.CommitTrans()

        Catch ex As Exception
            lConnection.RollBackTrans()
            Throw New Exception(ex.Message & " : RxHubLibrary\DAL\RefillDB.UpdateRenewal(ByVal pRelatesToMessageId As String, ByVal pNCPDPID As String, ByVal pConnectionString As String) ")
        End Try

        Return True
    End Function

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="pClinicCode"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetConnectionString(ByVal pClinicCode As String) As String
        Dim lQuery As String = ""
        Dim lDS As DataSet = Nothing

        Dim lConnection As Connection = Nothing

        Try
            lConnection = New Connection

            lQuery = "Select * from ConnectionMaster Where ClinicCode = '" & pClinicCode & "' "


            lDS = lConnection.ExecuteQuery(lQuery)

            GetConnectionString = CType(lDS.Tables(0).Rows(0).Item("ConnectionString"), String)
        Catch ex As Exception
            GetConnectionString = ""
            Throw New Exception(ex.Message & " : RxHubLibrary\DAL\RefillDB.GetConnectionString(ByVal pClinicCode As String) ")
        End Try
    End Function

#End Region



End Class
