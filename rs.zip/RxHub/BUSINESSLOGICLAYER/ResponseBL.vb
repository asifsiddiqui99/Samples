Imports MAPPERLib
Imports System.IO
Imports System.Xml
Imports System.net
Imports System.Text
Imports ElixirLibrary
Imports system.web.httpUtility

Imports EligibilityResponse


Public Class ResponseBL


    Private mECCPath As String
    Private mResponseEDIPath As String
    Private mResponseXMLPath As String
    Private mNameHandler As NameHandlerBL


#Region "Constructors"

    Public Sub New(ByVal pNameHandler As NameHandlerBL)
        mResponseEDIPath = pNameHandler.EDIName()
        mNameHandler = pNameHandler
    End Sub

    Public Sub New(ByVal pECC As String, ByVal pNameHandler As NameHandlerBL)
        mECCPath = pECC
        mResponseEDIPath = pNameHandler.EDIName()
        mResponseXMLPath = pNameHandler.XmlName()
        mNameHandler = pNameHandler
    End Sub

    'Overloaded Constructor made for Demo version where we do not require a Name Handler Class
    Public Sub New(ByVal pECC As String, ByVal pResponseEDIPath As String, ByVal pResponseXMLPath As String)
        mECCPath = pECC
        mResponseEDIPath = pResponseEDIPath
        mResponseXMLPath = pResponseXMLPath

    End Sub


    'Overloaded Constructor made for V4010 Conversion to V5010 where we do not require a Name Handler Class, ECC file
    Public Sub New(ByVal pResponseEDIPath As String, ByVal pResponseXMLPath As String)

        mResponseEDIPath = pResponseEDIPath
        mResponseXMLPath = pResponseXMLPath

    End Sub

#End Region

    ' This function Maps the File
    Private Function MapFile(ByVal pInputPath As String, ByVal pOutputPath As String) As Integer

        Dim lMapper As EncoreMapper

        Try

            lMapper = New EncoreMapper
            lMapper.LoadDefinition(mECCPath)
            lMapper.MapFiles(pInputPath, pOutputPath)


        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\ResponseBL.MapFile(ByVal pInputPath As String, ByVal pOutputPath As String) ")
        End Try
        Return 1
    End Function

    'This function reads data from the X12 source file 
    Private Function ReadDataFromFile(ByVal pFilePath As String) As String

        Dim X12Data As String = ""
        Dim lFileStream As FileStream = Nothing
        Dim lStreamReader As StreamReader = Nothing


        Try
            lFileStream = New FileStream(pFilePath, FileMode.Open, FileAccess.Read)
            lStreamReader = New StreamReader(lFileStream)

            If pFilePath Is Nothing Then
                Return "Error"
            End If

            X12Data = "request=" & lStreamReader.ReadToEnd

        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\ResponseBL.ReadDataFromFile(ByVal pFilePath As String) ")
        Finally
            lStreamReader.Close()
            lFileStream.Close()
        End Try


        Return X12Data

    End Function

    ''READ FUNCTION WITHOUT THE "REQUEST=" PART
    Private Function ReadDataFromFileSimple(ByVal pFilePath As String) As String
        Dim X12Data As String = ""
        Dim lFileStream As FileStream = Nothing
        Dim lStreamReader As StreamReader = Nothing


        Try
            lFileStream = New FileStream(pFilePath, FileMode.Open, FileAccess.Read)
            lStreamReader = New StreamReader(lFileStream)

            If pFilePath Is Nothing Then
                Return "Error"
            End If

            X12Data = lStreamReader.ReadToEnd

        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\ResponseBL.ReadDataFromFileSimple(ByVal pFilePath As String) ")
        Finally
            lStreamReader.Close()
            lFileStream.Close()
        End Try


        Return X12Data

    End Function

    ' This returns an object of response 
    Public Function ReturnResponseObject(ByVal pPrescriberIdentificationNumber As String, ByVal pMessageID As Integer) As EligibilityBL
        Dim lResponse As String
        Dim lEligibility As EligibilityBL = Nothing


        Try

            'IF SEND ELIGIBILITY IS FALSE THEN RETURN NOTHING
            If CType(System.Configuration.ConfigurationManager.AppSettings("SendEligibility"), Boolean) = False Then
                Return Nothing
            End If

            lResponse = ReadDataFromFileSimple(System.Configuration.ConfigurationManager.AppSettings("RxHubEligibilityResponsePath") + mNameHandler.EDIName(pPrescriberIdentificationNumber))
            UpdateResponseTrace(lResponse, pMessageID)

            Return ReadEligibilityResponseIntoObject(lResponse)


        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\ResponseBL.ReturnResponseObject(ByVal pPrescriberIdentificationNumber As String, ByVal pMessageID As Integer) ")
        End Try

    End Function


    Private Function UpdateResponseTrace(ByVal pXML As String, ByVal pMessageID As Integer, Optional ByVal IsEDIRequestOnly As Boolean = False) As Boolean
        Dim lQuery As String = String.Empty
        Dim lDataBaseConnection As Connection

        Try


            'FOR ELIMINATING THE UNPRINTABLE CHARACTERS
            Dim lRegex As New RegularExpressions.Regex("[\x01-\x1F]")
            If lRegex.IsMatch(pXML) Then
                pXML = lRegex.Replace(pXML, "")
            End If


            If pXML.Contains("request=") Then
                pXML = pXML.Remove(0, pXML.IndexOf("<"))
            End If

            lDataBaseConnection = New Connection(System.Configuration.ConfigurationManager.ConnectionStrings("RxHubConnectionString").ConnectionString())

            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''CHANGE LOG''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            'DESCRIPTION: PUT APOSTROPHES AROUND THE pMESSAGEID IN THE INLINE QUERY BELOW
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

            If IsEDIRequestOnly Then
                lQuery = "Update RequestTrace set EDI = '" & pXML & "' where RelatesToMessageID = '" & pMessageID.ToString & "' "
            Else
                lQuery = "Update RequestTrace set XML = '" & pXML & "' where RelatesToMessageID = '" & pMessageID.ToString & "' "
            End If

            lDataBaseConnection.ExecuteQuery(lQuery)

        Catch ex As Exception
            ErrorLogMethods.LogError(ex, "RxHubLibrary\BLL\ResponseBL.UpdateResponseTrace(ByVal pXML = (" & pXML & ") As String, ByVal pMessageID = (" & pMessageID & ") As Integer)")
        End Try

        Return True

    End Function


    'This function deals with the Medication history
    Public Function ReturnMedicationHistory(ByRef pMoreHistory() As MoreHistory, ByVal pMessageID As Integer) As MedicationHistoryBL

        Dim lResponse As String = String.Empty
        Dim ResponseString As String = String.Empty

        Dim lMedicationHistoryBL(pMoreHistory.Length - 1) As MedicationHistoryBL

        Try

            For x As Integer = 0 To pMoreHistory.Length - 1
                lResponse = ""
                If pMoreHistory(x).FillData Or (Not (pMoreHistory(x).MailOrderPrescription = False And pMoreHistory(x).PharmacyBenifit = False)) Then

                    'MapFile(System.Configuration.ConfigurationManager.AppSettings("RxHubHistoryResponsePath") + mNameHandler.EDIName(RxHubUtility.CleanString(pMoreHistory(x).CardHolderReferenceNumber)), System.Configuration.ConfigurationManager.AppSettings("RxHubHistoryResponsePath") + mNameHandler.XmlName(RxHubUtility.CleanString(pMoreHistory(x).CardHolderReferenceNumber)))

                    'Check if file has been created 
                    If File.Exists(System.Configuration.ConfigurationManager.AppSettings("RxHubHistoryResponsePath") + mNameHandler.EDIName(RxHubUtility.CleanString(pMoreHistory(x).CardHolderReferenceNumber))) Then
                        lResponse = ReadDataFromFile(System.Configuration.ConfigurationManager.AppSettings("RxHubHistoryResponsePath") + mNameHandler.EDIName(RxHubUtility.CleanString(pMoreHistory(x).CardHolderReferenceNumber)))

                        If lResponse.Contains("nak") Then
                            UpdateResponseTrace("<Error>nak</Error>", pMessageID, True)
                            Throw New Exception("<Error>nak</Error> : RxHubLibrary\BLL\ResponseBL.ReturnMedicationHistory(ByRef pMoreHistory() As MoreHistory, ByVal pMessageID As Integer) ")
                            Exit Function
                        End If

                        UpdateResponseTrace(lResponse, pMessageID, True)

                    End If


                    ResponseString = lResponse

                    If Not ResponseString.Equals("") Then
                        'lMedicationHistoryBL(x).MoreHistory = pMoreHistory(x)
                        lMedicationHistoryBL(x) = New MedicationHistoryBL(ResponseString, pMoreHistory(x))

                        'assigns the changes back to the more history
                        pMoreHistory(x) = lMedicationHistoryBL(x).MoreHistory
                    End If


                End If

            Next


            Dim lMedicationHistory As New MedicationHistoryBL


            'This should take care of the medication history dataset
            For x As Integer = 0 To lMedicationHistoryBL.Length - 1
                If pMoreHistory(x).FillData Or (Not (pMoreHistory(x).MailOrderPrescription = False And pMoreHistory(x).PharmacyBenifit = False)) Then
                    If lMedicationHistoryBL(x) IsNot Nothing AndAlso lMedicationHistoryBL(x).Exists Then
                        If lMedicationHistory.DrugList Is Nothing Then
                            lMedicationHistory.DrugList = lMedicationHistoryBL(x).DrugList
                        Else
                            lMedicationHistory.DrugList.Merge(lMedicationHistoryBL(x).DrugList)
                        End If
                    End If
                End If
            Next


            If lMedicationHistory.DrugList IsNot Nothing Then
                If lMedicationHistory.DrugList.Tables(0).Rows.Count > 0 Then 'Something Exists
                    lMedicationHistory.Exists = True
                End If
            Else
                lMedicationHistory.Exists = False
            End If

            'This should take care of the medication history status
            lMedicationHistory.Status = ""
            For x As Integer = 0 To lMedicationHistoryBL.Length - 1
                If lMedicationHistoryBL(x) IsNot Nothing Then
                    If Not lMedicationHistoryBL(x).Status.Contains("0 Record") Then
                        lMedicationHistory.Status = lMedicationHistoryBL(x).Status
                    Else
                        lMedicationHistory.Status += lMedicationHistoryBL(x).Status
                    End If
                End If
            Next

            'This is the drug count
            For x As Integer = 0 To lMedicationHistoryBL.Length - 1
                If lMedicationHistoryBL(x) IsNot Nothing AndAlso lMedicationHistoryBL(x).Count > 0 Then
                    lMedicationHistory.Count += lMedicationHistoryBL(x).Count
                End If
            Next

            For x As Integer = 0 To lMedicationHistoryBL.Length - 1
                If lMedicationHistoryBL(x) IsNot Nothing Then
                    If lMedicationHistoryBL(x).MoreDrugHistoryExists = True Then
                        lMedicationHistory.MoreDrugHistoryExists = True
                    End If
                End If
            Next

            Return lMedicationHistory

        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\ResponseBL.ReturnMedicationHistory(ByRef pMoreHistory() As MoreHistory, ByVal pMessageID As Integer) ")
        End Try

    End Function
    Public Function ReturnNewRxResponse( _
    ByVal pClinicCode As String, _
    ByVal pPrescriberIdentification As String, _
    ByVal pConnectionString As String) As String

        Dim lResponse As String = ""
        Dim lStatus As String = ""
        Dim lXmlDocument As XmlDocument
        Dim lNewRx As NewRx




        Try

            lXmlDocument = New XmlDocument
            lNewRx = New NewRx(pClinicCode)

            MapFile(System.Configuration.ConfigurationManager.AppSettings("RxHubNewRxResponsePath") + mNameHandler.EDIName(pPrescriberIdentification), System.Configuration.ConfigurationManager.AppSettings("RxHubNewRxResponsePath") + mNameHandler.XmlName(pPrescriberIdentification))




            'Check if file has been created 
            If File.Exists(System.Configuration.ConfigurationManager.AppSettings("RxHubNewRxResponsePath") + mNameHandler.XmlName(pPrescriberIdentification)) Then
                lResponse = ReadDataFromFile(System.Configuration.ConfigurationManager.AppSettings("RxHubNewRxResponsePath") + mNameHandler.XmlName(pPrescriberIdentification))
            Else
                Throw New Exception("Response File Not Found : RxHubLibrary\BLL\ResponseBL.ReturnNewRxResponse(ByVal pClinicCode As String,ByVal pPrescriberIdentification As String,ByVal pConnectionString As String) ")
            End If


            lResponse = lResponse.Substring(lResponse.IndexOf("<UIB>"))
            lResponse = lResponse.Remove(lResponse.IndexOf("</NewRxResponse>"))

            lResponse = "<NewRxResponse>" + lResponse + "</NewRxResponse>"

            lXmlDocument.LoadXml(lResponse)

            'Checks if there is an error
            If lXmlDocument.DocumentElement.SelectNodes("//STS").Count > 0 Then
                If lXmlDocument.DocumentElement.SelectNodes("//STS/FreeText").Count > 0 Then
                    lStatus = lXmlDocument.DocumentElement.SelectSingleNode("//STS/StatusTypeCode").InnerText & " - " & lXmlDocument.DocumentElement.SelectSingleNode("//STS/FreeText").InnerText
                Else

                    If lXmlDocument.DocumentElement.SelectSingleNode("//STS/StatusTypeCode").InnerText.Equals("602") Then
                        lStatus = "602 - Error from Receiver"
                    Else
                        If lXmlDocument.DocumentElement.SelectSingleNode("//STS/StatusTypeCode").InnerText.Equals("010") Then
                            lStatus = "010 - Transaction sent successfully"
                        ElseIf lXmlDocument.DocumentElement.SelectSingleNode("//STS/StatusTypeCode").InnerText.Equals("000") Then
                            lStatus = "000 - Transaction sent successfully"
                        End If
                    End If

                End If

            End If

            lNewRx.SaveStatus(lResponse, pConnectionString)


        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\ResponseBL.ReturnNewRxResponse(ByVal pClinicCode As String,ByVal pPrescriberIdentification As String,ByVal pConnectionString As String) ")
        End Try

        Return lStatus
    End Function


    Public Function ReturnRefillResponse(ByVal pPath As String) As Integer

        Try
            MapFile(pPath, "C:\ResponseText.txt")

            If System.Configuration.ConfigurationManager.AppSettings("UnderConstruction").Equals("false") Then
                Dim lResponse As String = SendData(System.Configuration.ConfigurationManager.AppSettings("RxHubURI"), ReadDataFromFile("C:\ResponseText.txt"))
                'WriteDataToFile(lResponse, System.Configuration.ConfigurationManager.AppSettings("RxHubNewRxResponsePath") + NameHandlerBL.EDIName)
            End If

        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\ResponseBL.ReturnRefillResponse(ByVal pPath As String) ")
        End Try
    End Function


    'This function sends the data to the specified URL
    Private Function SendData(ByVal Url As String, ByVal X12Data As String) As String

        If Url = "" OrElse X12Data = "" Then
            Return "Error"
        End If
        Dim headertext As String = ""
        Dim ResponseXML As String = String.Empty
        Dim str As String = "UlhIVUI6Tk9QQVNT"
        Dim hwRequest As HttpWebRequest
        Dim hwResponse As HttpWebResponse
        Dim myWriter As StreamWriter
        X12Data = X12Data.Replace(Chr(13), Chr(10))

        Try
            hwRequest = CType(HttpWebRequest.Create(Url), HttpWebRequest)
            headertext = "Authorization: Basic " + str
            hwRequest.Headers.Add(headertext)
            hwRequest.Method = "POST"
            hwRequest.ContentType = "application/x-www-form-urlencoded"
            Try
                ServicePointManager.CertificatePolicy = New CertificateValidation
                myWriter = New StreamWriter(hwRequest.GetRequestStream)
                myWriter.Write(X12Data)
                myWriter.Flush()
                myWriter.Close()
            Catch e1 As Exception
                Throw New WebException(e1.Message & " : RxHubLibrary\BLL\ResponseBL.SendData(ByVal Url As String, ByVal X12Data As String) ")
            End Try
            Try
                hwResponse = CType(hwRequest.GetResponse, HttpWebResponse)
                Dim stResponse As StreamReader = New StreamReader(hwResponse.GetResponseStream)
                ResponseXML = stResponse.ReadToEnd
            Catch ex As Exception
                Throw New WebException(ex.Message & " : RxHubLibrary\BLL\ResponseBL.SendData(ByVal Url As String, ByVal X12Data As String) ")
            End Try

        Catch NoResponse As WebException
            Throw NoResponse
        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\ResponseBL.SendData(ByVal Url As String, ByVal X12Data As String) ")
        End Try

        Return ResponseXML
    End Function


    Public Function CreateRefillXml(ByVal pMessageId As String, _
    ByVal pRenewalRequestId As String, _
    ByVal pNCPDPID As String, _
    ByVal pIsDenied As Boolean, _
    ByVal pResponseText As String, _
    ByVal pRefills As String, _
    ByVal pPRN As Boolean, _
    ByVal pDenyReason As String, _
    ByVal pDenyReasonCode As String, _
    ByVal pIsNewPrescriptionToFollow As Boolean, _
    ByVal pPharmacyProvider As String, _
    ByVal pRequestXml As String, _
    ByVal pIsPrescribingAgent As Boolean, _
    ByVal pPrescriberName As sName, _
    ByVal pPrescriberRoutingAddress As String _
    ) As String


        Dim lRefillDB As Refill

        Dim lXmlDocument As New XmlDocument
        Dim lNode As XmlElement = Nothing
        Dim lChildNode As XmlElement = Nothing
        Dim lGrandChildNode As XmlElement = Nothing
        Dim lGreatGrandChildNode As XmlElement = Nothing
        Dim lDescendant As XmlElement = Nothing
        Dim lGrandDescendant As XmlElement = Nothing

        Dim lString As String = ""
        Dim lCount As Integer = 0

        Try

            lRefillDB = New Refill

            pRequestXml = pRequestXml.Replace("<RefillRequest>", "<RefillResponse>")
            pRequestXml = pRequestXml.Replace("</RefillRequest>", "</RefillResponse>")
            pRequestXml = pRequestXml.Replace("<REQ>", "<RES>")
            pRequestXml = pRequestXml.Replace("</REQ>", "</RES>")
            pRequestXml = pRequestXml.Replace("<RxHubName>", "<RxHubParticipantID>")
            pRequestXml = pRequestXml.Replace("</RxHubName>", "</RxHubParticipantID>")

            lXmlDocument.LoadXml(pRequestXml)

            If lXmlDocument.DocumentElement.SelectNodes("//Body/RefillResponse/OBS").Count > 0 Then
                lCount -= 1
            End If

            If lXmlDocument.DocumentElement.SelectNodes("//Body/RefillResponse/COO").Count > 0 Then
                lCount -= 1
            End If

            If lXmlDocument.DocumentElement.SelectNodes("//Header/To").Count > 0 Then
                lXmlDocument.DocumentElement.SelectSingleNode("//Header/To").InnerText = pPrescriberRoutingAddress
            Else
                lNode = lXmlDocument.CreateElement("To")
                lNode.InnerText = pPrescriberRoutingAddress
                lXmlDocument.DocumentElement.SelectSingleNode("//Header").InsertBefore(lNode, lXmlDocument.DocumentElement.SelectSingleNode("//Header/From"))
            End If

            If lXmlDocument.DocumentElement.SelectNodes("//Header/RxHubParticipantID").Count > 0 Then
                lXmlDocument.DocumentElement.SelectSingleNode("//Header/RxHubParticipantID").InnerText = _
                System.Configuration.ConfigurationManager.AppSettings("RxHubParticipantID")
            End If

            lNode = lXmlDocument.CreateElement("RxHubPassword")
            lNode.InnerText = System.Configuration.ConfigurationManager.AppSettings("RxHubPassword")
            lXmlDocument.DocumentElement.SelectSingleNode("//Header").InsertBefore(lNode, lXmlDocument.DocumentElement.SelectSingleNode("//Header/MessageID"))

            If lXmlDocument.DocumentElement.SelectNodes("//Header/MessageID").Count > 0 Then
                lString = lXmlDocument.DocumentElement.SelectSingleNode("//Header/MessageID").InnerText
                lXmlDocument.DocumentElement.SelectSingleNode("//Header/MessageID").InnerText = lRefillDB.GetMessageID
            End If

            If lXmlDocument.DocumentElement.SelectNodes("//Header/RelatesToMessageID").Count > 0 Then
                lXmlDocument.DocumentElement.SelectSingleNode("//Header/RelatesToMessageID").InnerText = lString
            End If

            If lXmlDocument.DocumentElement.SelectNodes("//Header/SentTime").Count > 0 Then
                lXmlDocument.DocumentElement.SelectSingleNode("//Header/SentTime").InnerText = DateTime.Now.ToString("yyyyMMddhhmmss")
            End If



            lString = ""
            If lXmlDocument.DocumentElement.SelectNodes("//Body/RefillResponse/MedicationPrescribed/Refills/Quantity").Count > 0 Then
                lString = lXmlDocument.DocumentElement.SelectSingleNode("//Body/RefillResponse/MedicationPrescribed/Refills/Quantity").InnerText
            End If

            lNode = lXmlDocument.CreateElement("Note")
            lNode.InnerText = pResponseText
            lXmlDocument.DocumentElement.SelectSingleNode("//Body/RefillResponse/MedicationPrescribed").InsertBefore(lNode, lXmlDocument.DocumentElement.SelectSingleNode("//Body/RefillResponse/MedicationPrescribed/Refills"))

            If lXmlDocument.DocumentElement.SelectNodes("//Body/RefillResponse/RES").Count > 0 Then
                lNode = lXmlDocument.DocumentElement.SelectSingleNode("//Body/RefillResponse/RES")
                lNode.RemoveAll()


                lChildNode = lXmlDocument.CreateElement("MessageFunctionCoded")
                If pIsDenied = False Then
                    If lString.Equals(pRefills) Or lString.Equals("0") Or lString.Equals("") Then
                        lChildNode.InnerText = "A"
                        lNode.AppendChild(lChildNode.CloneNode(True))
                    Else
                        lChildNode.InnerText = "C"
                        lNode.AppendChild(lChildNode.CloneNode(True))
                    End If

                    lXmlDocument.DocumentElement.SelectSingleNode("//Body/RefillResponse/MedicationPrescribed/Refills/Quantity").InnerText = pRefills
                Else
                    lXmlDocument.DocumentElement.SelectSingleNode("//Body/RefillResponse/MedicationPrescribed/Refills/Quantity").InnerText = "0"
                    If pIsNewPrescriptionToFollow = True Then
                        lChildNode.InnerText = "N"
                        lNode.AppendChild(lChildNode.CloneNode(True))
                    Else
                        lChildNode.InnerText = "D"
                        lGrandChildNode = lXmlDocument.CreateElement("CodeListQualifier")
                        lGrandChildNode.InnerText = pDenyReasonCode

                        lNode.AppendChild(lChildNode.CloneNode(True))
                        lNode.AppendChild(lGrandChildNode.CloneNode(True))
                    End If
                End If

            Else   'Means that REQ segment was not sent in the REfill Request so have to make the RES segment 
                lNode = lXmlDocument.CreateElement("RES")
                lCount = 1 'increase the count

                lChildNode = lXmlDocument.CreateElement("MessageFunctionCoded")
                If pIsDenied = False Then
                    If lString.Equals(pRefills) Or lString.Equals("0") Or lString.Equals("") Then
                        lChildNode.InnerText = "A"
                        lNode.AppendChild(lChildNode.CloneNode(True))
                    Else
                        lChildNode.InnerText = "C"
                        lNode.AppendChild(lChildNode.CloneNode(True))
                    End If

                    lXmlDocument.DocumentElement.SelectSingleNode("//Body/RefillResponse/MedicationPrescribed/Refills/Quantity").InnerText = pRefills
                Else
                    lXmlDocument.DocumentElement.SelectSingleNode("//Body/RefillResponse/MedicationPrescribed/Refills/Quantity").InnerText = "0"
                    If pIsNewPrescriptionToFollow = True Then
                        lChildNode.InnerText = "N"
                        lNode.AppendChild(lChildNode.CloneNode(True))
                    Else
                        lChildNode.InnerText = "D"
                        lGrandChildNode = lXmlDocument.CreateElement("CodeListQualifier")
                        lGrandChildNode.InnerText = pDenyReasonCode

                        lNode.AppendChild(lChildNode.CloneNode(True))
                        lNode.AppendChild(lGrandChildNode.CloneNode(True))
                    End If
                End If

                lXmlDocument.DocumentElement.SelectSingleNode("//Body/RefillResponse").InsertBefore(lNode, lXmlDocument.DocumentElement.SelectSingleNode("//Body/RefillResponse/Pharmacy"))

            End If

            If lXmlDocument.DocumentElement.SelectNodes("//Header/SegmentCount").Count > 0 Then
                lXmlDocument.DocumentElement.SelectSingleNode("//Header/SegmentCount").InnerText += lCount
            Else
                'lNode = lXmlDocument.CreateElement("SegmentCount")
                'lNode.InnerText = (6 + lCount)

            End If

            If pIsPrescribingAgent Then
                lNode = lXmlDocument.CreateElement("PrescriberAgent")

                lChildNode = lXmlDocument.CreateElement("LastName")
                lChildNode.InnerText = pPrescriberName.LastName
                lNode.AppendChild(lChildNode.CloneNode(True))

                lChildNode = lXmlDocument.CreateElement("FirstName")
                lChildNode.InnerText = pPrescriberName.FirstName
                lNode.AppendChild(lChildNode.CloneNode(True))

                lChildNode = lXmlDocument.CreateElement("MiddleName")
                lChildNode.InnerText = pPrescriberName.MiddleName
                lNode.AppendChild(lChildNode.CloneNode(True))

                If lXmlDocument.DocumentElement.SelectNodes("//Body/RefillResponse/Prescriber/Address").Count > 0 Then
                    lXmlDocument.DocumentElement.SelectSingleNode("//Body/RefillResponse/Prescriber").InsertBefore(lNode, lXmlDocument.DocumentElement.SelectSingleNode("//Body/RefillResponse/Prescriber/Address"))
                Else
                    lXmlDocument.DocumentElement.SelectSingleNode("//Body/RefillResponse/Prescriber").InsertBefore(lNode, lXmlDocument.DocumentElement.SelectSingleNode("//Body/RefillResponse/Prescriber/PhoneNumbers"))
                End If




            End If


            lString = lXmlDocument.OuterXml.ToString.Replace("<Message>", "<Message xmlns=""http://www.RefillResponse.com"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xsi:schemaLocation=""http://www.RefillResponse.com RefillResponse.xsd"">")

            WriteDataToFile(lString, System.Configuration.ConfigurationManager.AppSettings("RxHubRefillResponsePath") & mNameHandler.XmlName(pRenewalRequestId))

            MapFile(System.Configuration.ConfigurationManager.AppSettings("RxHubRefillResponsePath") & mNameHandler.XmlName(pRenewalRequestId), System.Configuration.ConfigurationManager.AppSettings("RxHubRefillResponsePath") & mNameHandler.EDIName(pRenewalRequestId))

        Catch ex As Exception

            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\ResponseBL.CreateRefillXml(ByVal pMessageId As String,ByVal pRenewalRequestId As String, ByVal pNCPDPID As String,ByVal pIsDenied As Boolean, ByVal pResponseText As String,ByVal pRefills As String, ByVal pPRN As Boolean, ByVal pDenyReason As String,ByVal pDenyReasonCode As String,ByVal pIsNewPrescriptionToFollow As Boolean,ByVal pPharmacyProvider As String,ByVal pRequestXml As String,ByVal pIsPrescribingAgent As Boolean,ByVal pPrescriberName As sName,ByVal pPrescriberRoutingAddress As String ) ")

        End Try

        Return lXmlDocument.OuterXml.ToString

    End Function


    'This function sends the medication request
    Public Function SendRefillResponse( _
    ByVal pMessageId As String, _
    ByVal pRenewalRequestId As String, _
    ByVal pNCPDPID As String, _
    ByVal pIsDenied As Boolean, _
    ByVal pResponseText As String, _
    ByVal pRefills As String, _
    ByVal pPRN As Boolean, _
    ByVal pDenyReason As String, _
    ByVal pDenyReasonCode As String, _
    ByVal pIsNewPrescriptionToFollow As Boolean, _
    ByVal pPharmacyProvider As String, _
    ByVal pClinicCode As String, _
    ByVal pConnectionString As String, _
    ByVal pIsPrescribingAgent As Boolean, _
    ByVal pPrescriberName As sName, _
    ByVal pPrescriberRoutingAddress As String) As String


        Dim lResponseXml As String = ""
        Dim lRequestXml As String = "" ' This is for getting the information to build a response

        Dim lMessage As String = ""
        Dim lRefillDB As Refill = Nothing

        Dim lXmlDocument As New XmlDataDocument

        Dim lResponse As StringBuilder = New StringBuilder("")
        Dim lMessageReferenceNumber As String = ""

        Dim lFileStream As FileStream = Nothing
        Dim lStreamReader As StreamReader = Nothing

        Try

            lRefillDB = New Refill

            lRequestXml = lRefillDB.GetRefillXml(pMessageId, pNCPDPID)
            lRequestXml = lRequestXml.Substring(lRequestXml.IndexOf("<Header"), lRequestXml.Length - lRequestXml.IndexOf("<Header"))
            lRequestXml = "<Message>" & lRequestXml





            lResponseXml = CreateRefillXml(pMessageId, _
               pRenewalRequestId, _
               pNCPDPID, _
               pIsDenied, _
               pResponseText, _
               pRefills, _
               pPRN, _
               pDenyReason, _
               pDenyReasonCode, _
               pIsNewPrescriptionToFollow, _
               pPharmacyProvider, _
               lRequestXml, _
               pIsPrescribingAgent, _
               pPrescriberName, _
               pPrescriberRoutingAddress)


            lXmlDocument.LoadXml(lResponseXml)
            If lXmlDocument.DocumentElement.SelectNodes("//Body/RefillResponse/RxReferenceNumber").Count > 0 Then
                lRefillDB.RefillDB.RxReferenceNumber = lXmlDocument.DocumentElement.SelectSingleNode("//Body/RefillResponse/RxReferenceNumber").InnerText
            End If

            lXmlDocument.DocumentElement.SelectSingleNode("//Header/SentTime").InnerText = DateTime.Now.ToString("MM/dd/yyyy HH:mm:ss")
            lRefillDB.RefillDB.SentTime = DateTime.Now.ToString("MM/dd/yyyy HH:mm:ss")

            If lXmlDocument.DocumentElement.SelectNodes("//Body/RefillResponse/PrescriberOrderNumber").Count > 0 Then
                lRefillDB.RefillDB.RxReferenceNumber = lXmlDocument.DocumentElement.SelectSingleNode("//Body/RefillResponse/PrescriberOrderNumber").InnerText
            End If


            lRefillDB.RefillDB.Clinic.ClinicCode = pNCPDPID ' This is actually the pharmacy code
            lRefillDB.RefillDB.MessageID = lXmlDocument.DocumentElement.SelectSingleNode("//Header/MessageID").InnerText
            'lRefillDB.RefillDB.PrescriberIdentification.IdentificationNumber = lXmlDocument.DocumentElement.SelectSingleNode("//Header/MessageID").InnerText
            lRefillDB.RefillDB.RelatesToMessageID = lXmlDocument.DocumentElement.SelectSingleNode("//Header/RelatesToMessageID").InnerText

            If lXmlDocument.DocumentElement.SelectNodes("//Body/RefillResponse/Prescriber/Identification/PrescriberID").Count > 0 Then
                lRefillDB.RefillDB.PrescriberIdentification.IdentificationNumber = lXmlDocument.DocumentElement.SelectSingleNode("//Body/RefillResponse/Prescriber/Identification/PrescriberID").InnerText
            End If

            lRefillDB.AddMessage(mNameHandler.XmlName(pRenewalRequestId), "", pClinicCode, lResponseXml, 7, "O")

            ''CHANGED THIS FROM READDATAFROMFILE TO READDATAFROMFILESIMPLE SO THAT I COULD ENCODE THE PART EXCEPT THE "REQUEST=" STRING
            If (System.Configuration.ConfigurationManager.AppSettings("UnderConstruction").Equals("false") And System.Configuration.ConfigurationManager.AppSettings("Demo").ToUpper().Equals("FALSE")) Then
                lResponse.Append(SendData(System.Configuration.ConfigurationManager.AppSettings("RxHubURI"), "request=" & UrlEncode(ReadDataFromFileSimple(System.Configuration.ConfigurationManager.AppSettings("RxHubRefillResponsePath") & mNameHandler.EDIName(pRenewalRequestId)))))
                WriteDataToFile(lResponse.ToString, System.Configuration.ConfigurationManager.AppSettings("RxHubRefillStatusPath") & mNameHandler.EDIName(pRenewalRequestId))
                lRefillDB.UpdateRenewal(pMessageId, pNCPDPID, pConnectionString)
            End If

            If System.Configuration.ConfigurationManager.AppSettings("Demo").ToUpper().Equals("TRUE") Then
                Dim lResponse2 As StringBuilder = New StringBuilder("UNA.UIBUNOA0RELATESTOMESSAGEIDT00000000001000ZZZT00000000020089ZZZ47T1T0B79RUIHSCRIPT008001Status1234567STS010UIT12345673UIZ1")
                lResponse = lResponse2
                lResponse.Replace("RELATESTOMESSAGEID", pMessageId)
                WriteDataToFile(lResponse.ToString, System.Configuration.ConfigurationManager.AppSettings("RxHubRefillStatusPath") & mNameHandler.EDIName(pRenewalRequestId))
                lRefillDB.UpdateRenewal(pMessageId, pNCPDPID, pConnectionString)
            End If




            If Not lResponse.ToString.Equals("") Then
                Try

                    lResponse = lResponse.Remove(0, lResponse.Length)
                    mECCPath = System.Configuration.ConfigurationManager.AppSettings("RxHubRefillRecStatusECCPath")
                    MapFile(System.Configuration.ConfigurationManager.AppSettings("RxHubRefillStatusPath") & mNameHandler.EDIName(pRenewalRequestId), System.Configuration.ConfigurationManager.AppSettings("RxHubRefillStatusPath") & mNameHandler.XmlName(pRenewalRequestId))
                    lFileStream = New FileStream(System.Configuration.ConfigurationManager.AppSettings("RxHubRefillStatusPath") & mNameHandler.XmlName(pRenewalRequestId), FileMode.Open)
                    lStreamReader = New StreamReader(lFileStream)

                    lXmlDocument = New XmlDataDocument
                    lMessage = lStreamReader.ReadToEnd
                    lMessage = "<Message>" & lMessage.Substring(lMessage.IndexOf("<Header>"))
                    lXmlDocument.LoadXml(lMessage)
                    lResponse.Insert(0, lXmlDocument.DocumentElement.SelectSingleNode("//Body/Status/Code").InnerText)




                    If lXmlDocument.DocumentElement.SelectNodes("//Body/Status/Description").Count > 0 Then          
                        lResponse.Append(" - " & lXmlDocument.DocumentElement.SelectSingleNode("//Body/Status/Description").InnerText)
                    Else

                        Select Case lXmlDocument.DocumentElement.SelectSingleNode("//Body/Status/Code").InnerText

                            Case "000"
                                lResponse.Append(" - " & "Transaction Successful")
                            Case "010"
                                lResponse.Append(" - " & "Transaction Successful")
                            Case "602"
                                lResponse.Append(" - " & "Reciever System Error")
                            Case "900"
                                lResponse.Append(" - " & "Internal Error")
                            Case "600"
                                lResponse.Append(" - " & "Communication Problem")
                            Case "601"
                                lResponse.Append(" - " & "Reciever Unable to process")

                        End Select


                    End If



                    If lXmlDocument.DocumentElement.SelectNodes("//Body/Status/PrescriberOrderNumber").Count Then
                        lMessageReferenceNumber = lXmlDocument.DocumentElement.SelectSingleNode("//Body/Status/PrescriberOrderNumber").InnerText
                    End If

                Catch ex As Exception
                    Throw New Exception(ex.Message & " : RxHubLibrary\BLL\ResponseBL.SendRefillResponse(ByVal pMessageId As String,ByVal pRenewalRequestId As String,ByVal pNCPDPID As String, ByVal pIsDenied As Boolean,ByVal pResponseText As String, ByVal pRefills As String,ByVal pPRN As Boolean,ByVal pDenyReason As String,ByVal pDenyReasonCode As String,ByVal pIsNewPrescriptionToFollow As Boolean, ByVal pPharmacyProvider As String,ByVal pClinicCode As String, ByVal pConnectionString As String,ByVal pIsPrescribingAgent As Boolean,ByVal pPrescriberName As sName, ByVal pPrescriberRoutingAddress As String) ")
                Finally
                    lStreamReader.Close()
                    lFileStream.Close()
                End Try


            Else
                lResponse.Insert(0, "Status not recieved")
            End If


        Catch NoResponse As WebException
            Throw NoResponse
        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\ResponseBL.SendRefillResponse(ByVal pMessageId As String,ByVal pRenewalRequestId As String,ByVal pNCPDPID As String, ByVal pIsDenied As Boolean,ByVal pResponseText As String, ByVal pRefills As String,ByVal pPRN As Boolean,ByVal pDenyReason As String,ByVal pDenyReasonCode As String,ByVal pIsNewPrescriptionToFollow As Boolean, ByVal pPharmacyProvider As String,ByVal pClinicCode As String, ByVal pConnectionString As String,ByVal pIsPrescribingAgent As Boolean,ByVal pPrescriberName As sName, ByVal pPrescriberRoutingAddress As String) ")

        Finally
            lRefillDB.SaveStatus(lMessage, lMessageReferenceNumber, lRefillDB.RefillDB.MessageCode, 7, "O", "I")
        End Try

        Return lResponse.ToString

    End Function


    Private Function WriteDataToFile(ByVal ResponseData As String, ByVal pPath As String) As Integer

        Dim mFileStream As FileStream = Nothing
        Dim mStreamWriter As StreamWriter = Nothing

        Try
            mFileStream = New FileStream(pPath, FileMode.Create, FileAccess.Write)
            mStreamWriter = New StreamWriter(mFileStream)

            mStreamWriter.Write(ResponseData)


        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\ResponseBL.WriteDataToFile(ByVal ResponseData As String, ByVal pPath As String) ")
        Finally

            mStreamWriter.Flush()
            mStreamWriter.Close()
            mFileStream.Close()

        End Try

        Return 1

    End Function

   
    Private Function ReadEligibilityResponseIntoObject(ByVal pData As String) As EligibilityBL

        Dim lParser As New InputParser
        Dim lResponseEDI As String


        Dim lResponse271 As MsgInterchange
        Dim lEligibilityBL As EligibilityBL


        Try
            lEligibilityBL = New EligibilityBL

            lResponseEDI = pData

            If (lResponseEDI <> "") Then
                lResponse271 = lParser.Parse(lResponseEDI)
                lEligibilityBL.GetEligibilityFromDLLObject(lResponse271)
            End If

            Return lEligibilityBL

        Catch ex As Exception
            Return Nothing
        End Try

    End Function



    Public Function ReturnResponseObject(ByVal pPrescriberIdentificationNumber As String, ByVal pName As String) As EligibilityBL

        Dim lResponse As String = String.Empty
        Dim lEligibility As EligibilityBL = Nothing
        Dim lString As String = String.Empty

        Try

            lResponse = ReadDataFromFileSimple("C:\Test.edi")
            Return ReadEligibilityResponseIntoObject(lResponse)

            ''Check the existance of the file
            'If File.Exists(mResponseXMLPath + pName.ToUpper() + ".xml") Then
            '    'If it does exist then return the file contents in STRING format
            '    lResponse = ReadDataFromFileSimple(mResponseXMLPath + pName.ToUpper + ".xml")
            'Else
            '    ''changes made by talha...
            '    ''if the file of patient is not present.........
            '    lResponse = ReadDataFromFileSimple(mResponseXMLPath + "DefaultPatient" + ".xml")
            '    'Throw New Exception("Response Xml File Does not exist")
            'End If

            'Dim lRegex As New RegularExpressions.Regex("[\x01-\x1F]")

            'If lRegex.IsMatch(lResponse) Then
            '    lResponse = lRegex.Replace(lResponse, "")
            'End If

            ''UpdateResponseTrace(lResponse, 0)

            'lString = lResponse
            'lString = lString.Substring(lString.IndexOf("</ISA>") + 6)
            'lString = lString.Remove(lString.IndexOf("<IEA>"))

            'lEligibility = New EligibilityBL(lString)
            'lEligibility.GetEligibility()


        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\ResponseBL.ReturnResponseObject(ByVal pPrescriberIdentificationNumber As String, ByVal pName As String) ")
        End Try

        'Return lEligibility

    End Function


    'This is an overloaded function that is created for the Demo version
    Public Function ReturnMedicationHistory(ByRef pMoreHistory() As MoreHistory, ByVal pPatientName As String) As MedicationHistoryBL

        Dim lResponse As String = String.Empty
        Dim str As String = String.Empty
        Dim lMedicationHistoryBL(pMoreHistory.Length - 1) As MedicationHistoryBL


        Try

            For x As Integer = 0 To pMoreHistory.Length - 1

                If Not (pMoreHistory(x).MailOrderPrescription = False And pMoreHistory(x).PharmacyBenifit = False) Then

                    'Check if file has been created 
                    If File.Exists(System.Configuration.ConfigurationManager.AppSettings("DemoPathMedicationXML") + pPatientName.ToUpper + ".xml") Then
                        lResponse = ReadDataFromFile(System.Configuration.ConfigurationManager.AppSettings("DemoPathMedicationXML") + pPatientName.ToUpper + ".xml")
                    Else
                        ''Changes made by talha.........
                        ''if user selects any other patient whose xml file is not present......

                        lResponse = ReadDataFromFile(System.Configuration.ConfigurationManager.AppSettings("DemoPathMedicationXML") + "DefaultPatient" + ".xml")


                    End If


                    str = lResponse




                    str = str.Substring(str.IndexOf("<UIB"))
                    str = str.Remove(str.IndexOf("</MedicationHistoryRequest>"))



                    str = "<MedicationHistoryResponse>" & str & "</MedicationHistoryResponse>"

                    'lMedicationHistoryBL(x).MoreHistory = pMoreHistory(x)
                    lMedicationHistoryBL(x) = New MedicationHistoryBL(str, pMoreHistory(x))

                    'assigns the changes back to the more history
                    pMoreHistory(x) = lMedicationHistoryBL(x).MoreHistory

                End If

            Next


            Dim lMedicationHistory As New MedicationHistoryBL


            'This should take care of the medication history dataset
            For x As Integer = 0 To lMedicationHistoryBL.Length - 1
                If Not (pMoreHistory(x).MailOrderPrescription = False And pMoreHistory(x).PharmacyBenifit = False) Then
                    If lMedicationHistoryBL(x) IsNot Nothing And lMedicationHistoryBL(x).Exists Then
                        If lMedicationHistory.DrugList Is Nothing Then
                            lMedicationHistory.DrugList = lMedicationHistoryBL(x).DrugList
                        Else
                            'lMedicationHistory.DrugList.Merge(lMedicationHistoryBL(x).DrugList)
                        End If
                    End If
                End If
            Next


            If lMedicationHistory.DrugList IsNot Nothing Then
                If lMedicationHistory.DrugList.Tables(0).Rows.Count > 0 Then 'Something Exists
                    lMedicationHistory.Exists = True
                End If
            Else
                lMedicationHistory.Exists = False
            End If

            'This should take care of the medication history status
            lMedicationHistory.Status = ""
            For x As Integer = 0 To lMedicationHistoryBL.Length - 1
                If lMedicationHistoryBL(x) IsNot Nothing Then
                   
                        lMedicationHistory.Status += lMedicationHistoryBL(x).Status


                End If
            Next

            'This is the drug count
            For x As Integer = 0 To lMedicationHistoryBL.Length - 1
                If lMedicationHistoryBL(x) IsNot Nothing AndAlso lMedicationHistoryBL(x).Count > 0 Then
                    lMedicationHistory.Count += lMedicationHistoryBL(x).Count
                End If
            Next

            For x As Integer = 0 To lMedicationHistoryBL.Length - 1
                If lMedicationHistoryBL(x) IsNot Nothing Then
                    If lMedicationHistoryBL(x).MoreDrugHistoryExists = True Then
                        lMedicationHistory.MoreDrugHistoryExists = True
                    End If
                End If
            Next

            Return lMedicationHistory

        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\ResponseBL.ReturnMedicationHistory(ByRef pMoreHistory() As MoreHistory, ByVal pPatientName As String) ")
        End Try

    End Function

  'This returns the newRx response
    Public Function ReturnNewRxResponse( _
    ByVal pClinicCode As String, _
    ByVal pPrescriberIdentification As String, _
    ByVal pConnectionString As String, ByVal pPatientName As String) As String


        Dim lResponse As String = String.Empty
        Dim lStatus As String = String.Empty

        Dim lXmlDocument As XmlDocument = Nothing
        Dim lNewRx As NewRx = Nothing




        Try

            lXmlDocument = New XmlDocument
            lNewRx = New NewRx(pClinicCode)



            'Check if file has been created 
            If File.Exists(System.Configuration.ConfigurationManager.AppSettings("DemoPathNewRxXML") + pPatientName.ToString() + ".xml") Then
                lResponse = ReadDataFromFile(System.Configuration.ConfigurationManager.AppSettings("DemoPathNewRxXML") + pPatientName.ToString() + ".xml")
            Else
                Throw New Exception("Response File not found : RxHubLibrary\BLL\ResponseBL.ReturnNewRxResponse(ByVal pClinicCode As String,ByVal pPrescriberIdentification As String,ByVal pConnectionString As String, ByVal pPatientName As String) ")
            End If


            lResponse = lResponse.Substring(lResponse.IndexOf("<UIB>"))
            lResponse = lResponse.Remove(lResponse.IndexOf("</NewRxResponse>"))

            lResponse = "<NewRxResponse>" + lResponse + "</NewRxResponse>"


            lXmlDocument.LoadXml(lResponse)

            'Checks if there is an error
            If lXmlDocument.DocumentElement.SelectNodes("//STS").Count > 0 Then
                If lXmlDocument.DocumentElement.SelectNodes("//STS/FreeText").Count > 0 Then
                    lStatus = lXmlDocument.DocumentElement.SelectSingleNode("//STS/StatusTypeCode").InnerText & " - " & lXmlDocument.DocumentElement.SelectSingleNode("//STS/FreeText").InnerText
                Else

                    If lXmlDocument.DocumentElement.SelectSingleNode("//STS/StatusTypeCode").InnerText.Equals("602") Then
                        lStatus = "602 - Error from Receiver"
                    Else
                        If lXmlDocument.DocumentElement.SelectSingleNode("//STS/StatusTypeCode").InnerText.Equals("010") Then
                            lStatus = "010 - Transaction sent successfully"
                        ElseIf lXmlDocument.DocumentElement.SelectSingleNode("//STS/StatusTypeCode").InnerText.Equals("000") Then
                            lStatus = "000 - Transaction sent successfully"
                        End If
                    End If

                End If

            End If

            lNewRx.SaveStatus(lResponse, pConnectionString)


        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\ResponseBL.ReturnNewRxResponse(ByVal pClinicCode As String,ByVal pPrescriberIdentification As String,ByVal pConnectionString As String, ByVal pPatientName As String) ")
        End Try

        Return lStatus
    End Function

End Class
