Imports Microsoft.VisualBasic
Imports System.Xml
Imports System.IO
Imports MAPPERLib
Imports System.Net
Imports System.Text
Imports ElixirLibrary
Imports System.Configuration
Imports System.Web.httpUtility
Imports MedicationHistoryRequest
Imports MedicationHistoryResponse


Public Enum RelationShip
    Member = 1
    Spouse = 2
    ChildOrDependant = 3
    Other = 4
    Unknown = 5
End Enum





Public Class RequestBL
    Private mDatabaseConnection As Connection
    Private mXmlDocument As XmlDataDocument

    Private mECCPath As String
    Private mNameHandlerBL As NameHandlerBL
    Private mMoreHistory() As MoreHistory


    Dim mNewRx As NewRx


#Region "Constructors"

    Public Sub New()
        mDatabaseConnection = New Connection(ConfigurationManager.ConnectionStrings("RxHubConnectionString").ConnectionString())
    End Sub

    Public Sub New(ByVal pECC As String)
        mECCPath = pECC
        mDatabaseConnection = New Connection(ConfigurationManager.ConnectionStrings("RxHubConnectionString").ConnectionString())

    End Sub

    Public Sub New(ByVal pECC As String, ByVal pConnectionString As String, ByVal pClinicCode As String)
        mECCPath = pECC
        mDatabaseConnection = New Connection(ConfigurationManager.ConnectionStrings("RxHubConnectionString").ConnectionString())
        mNewRx = New NewRx(pClinicCode)

    End Sub


#End Region


#Region "Properties"


    Public Property NameHandlerBL() As NameHandlerBL
        Get
            Return mNameHandlerBL
        End Get
        Set(ByVal value As NameHandlerBL)
            mNameHandlerBL = value
        End Set
    End Property

    'This is only to be used for the medication history
    Public Property MoreHistory() As MoreHistory()
        Get
            Return mMoreHistory
        End Get
        Set(ByVal value As MoreHistory())
            mMoreHistory = value
        End Set
    End Property


#End Region


#Region "ENUM"

    Public Enum ActionCode As Integer

        '''''''''''''''''''''''''''''''''''''''''''''
        '' A zero is appended when this variable is returned
        ProviderUpdateAdd = 1
        ProviderUpdateUpdate = 2
        ProviderUpdateInactivate = 3
        '''''''''''''''''''''''''''''''''''''''''''''


        EligibilityRequest = 9
        EligibilityResponse = 10

        RequestDownloadPharmacy = 11
        ResponseDownloadPharmacy = 12

        Add = 13 '? 
        AddPrescriberResponse = 14

        Update = 15 '?
        UpdatePrescriberResponse = 16

        Inactivate = 17 '?
        InactivePrescriberResponse = 18

        MedicationHistoryRequest = 19
        MedicationHistoryResponse = 20


    End Enum

#End Region



    Private Function CreateRequest( _
    ByVal pPrescriberName As sName, _
    ByVal pPrescriberIdentification As sIdentification, _
    ByVal pPatientName As sName, _
    ByVal pPatientIdentification As sIdentification, _
    ByVal pPatientAddress As sAddress, _
    ByVal pPatientGender As Char, _
    ByVal pPatientDOB As String, _
    ByRef pMessageID As Integer) _
    As String


        Dim lNode As XmlElement
        Dim lChildNode As XmlElement
        Dim lGrandChildNode As XmlElement


        Try

            pMessageID = GetControlNumber()

            mXmlDocument = New XmlDataDocument
            mXmlDocument.LoadXml("<EligibilityRequest xmlns=""http://www.Request.com"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xsi:schemaLocation=""http://www.Request.com EligibilityRequest.xsd""></EligibilityRequest>")

            '''''''''''''''''''''''''''''ISA Started''''''''''''''''''''''''''''''''''''''

            lNode = mXmlDocument.CreateElement("ISA")

            lChildNode = mXmlDocument.CreateElement("AuthorizationInformationQualifier")
            lChildNode.InnerText = "00"
            lNode.AppendChild(lChildNode.CloneNode(True))

            'NO I02 BECAUSE 00 REPRESENTS NO MEANINGFUL INFORMATION

            lChildNode = mXmlDocument.CreateElement("PasswordInformationQualifier")
            lChildNode.InnerText = "01"
            lNode.AppendChild(lChildNode.CloneNode(True))

            lChildNode = mXmlDocument.CreateElement("Password")
            lChildNode.InnerText = System.Configuration.ConfigurationManager.AppSettings("RxHubPassword")
            lNode.AppendChild(lChildNode.CloneNode(True))

            lChildNode = mXmlDocument.CreateElement("SenderIDQualifier")
            lChildNode.InnerText = "ZZ"
            lNode.AppendChild(lChildNode.CloneNode(True))

            lChildNode = mXmlDocument.CreateElement("SenderID")
            lChildNode.InnerText = System.Configuration.ConfigurationManager.AppSettings("RxCureParticipantID")
            lNode.AppendChild(lChildNode.CloneNode(True))

            lChildNode = mXmlDocument.CreateElement("RecieverIDQualifier")
            lChildNode.InnerText = "ZZ"
            lNode.AppendChild(lChildNode.CloneNode(True))

            lChildNode = mXmlDocument.CreateElement("RecieverID")
            lChildNode.InnerText = System.Configuration.ConfigurationManager.AppSettings("SurescriptsParticipantID")
            lNode.AppendChild(lChildNode.CloneNode(True))

            lChildNode = mXmlDocument.CreateElement("RequestDate")
            lChildNode.InnerText = Format(Date.Now, "yyMMdd")
            lNode.AppendChild(lChildNode.CloneNode(True))

            lChildNode = mXmlDocument.CreateElement("RequestTime")
            lChildNode.InnerText = Format(Date.Now, "HHmm")
            lNode.AppendChild(lChildNode.CloneNode(True))

            lChildNode = mXmlDocument.CreateElement("RepititionSeparator")
            lChildNode.InnerText = "*" '    TODO: HAVE TO CHECK IF THIS REPITITION WORKS
            lNode.AppendChild(lChildNode.CloneNode(True))

            lChildNode = mXmlDocument.CreateElement("VersionNumber")
            lChildNode.InnerText = "00501"
            lNode.AppendChild(lChildNode.CloneNode(True))

            lChildNode = mXmlDocument.CreateElement("InterchangeControlNumber")
            lChildNode.InnerText = pMessageID
            lNode.AppendChild(lChildNode.CloneNode(True))

            lChildNode = mXmlDocument.CreateElement("AcknowledgementRequested")
            lChildNode.InnerText = System.Configuration.ConfigurationManager.AppSettings("AcknowledgementRequested")
            lNode.AppendChild(lChildNode.CloneNode(True))

            lChildNode = mXmlDocument.CreateElement("UsageIndicator")
            lChildNode.InnerText = IIf(System.Configuration.ConfigurationManager.AppSettings("IsTestEnvironment").Equals("1"), "T", "P")
            lNode.AppendChild(lChildNode.CloneNode(True))

            lChildNode = mXmlDocument.CreateElement("ComponentElementSeparator")
            lChildNode.InnerText = ":" 'TODO: VERIFY
            lNode.AppendChild(lChildNode.CloneNode(True))

            mXmlDocument.DocumentElement.AppendChild(lNode.CloneNode(True))

            ''''''''''''''''''''''''''''''ISA Created '''''''''''''''''''''''''''''''''''

            '''''''''''''''''''''''''Functional Group Started''''''''''''''''''''''''''''

            lNode = mXmlDocument.CreateElement("FunctionalGroup")

            '''''''''''''''''''''''''''''''GS Started''''''''''''''''''''''''''''''''''''

            lChildNode = mXmlDocument.CreateElement("GS")

            lGrandChildNode = mXmlDocument.CreateElement("FunctionalIdentifierCode")
            lGrandChildNode.InnerText = "HS"
            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

            lGrandChildNode = mXmlDocument.CreateElement("ApplicationSendersCode")
            lGrandChildNode.InnerText = System.Configuration.ConfigurationManager.AppSettings("RxCureParticipantID") '"T00000000020089"
            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

            lGrandChildNode = mXmlDocument.CreateElement("ApplicationRecieversCode")
            lGrandChildNode.InnerText = System.Configuration.ConfigurationManager.AppSettings("SurescriptsParticipantID") '"RXHUB" "S00000000000001" '
            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

            lGrandChildNode = mXmlDocument.CreateElement("RequestDate")
            lGrandChildNode.InnerText = Format(Date.Now, "yyyyMMdd")
            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

            lGrandChildNode = mXmlDocument.CreateElement("RequestTime")
            lGrandChildNode.InnerText = Format(Date.Now, "HHmm")
            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

            lGrandChildNode = mXmlDocument.CreateElement("GroupControlNumber")
            lGrandChildNode.InnerText = "000000001" 'This has to be unique only within this transaction set
            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

            lGrandChildNode = mXmlDocument.CreateElement("ResponsibleAgencyCode")
            lGrandChildNode.InnerText = "X"
            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

            lGrandChildNode = mXmlDocument.CreateElement("VersionIDCode")
            lGrandChildNode.InnerText = "005010X279A1"
            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

            lNode.AppendChild(lChildNode.CloneNode(True))

            '''''''''''''''''''''''''''''''''GS Ended'''''''''''''''''''''''''''''''''''''

            '''''''''''''''''''''''''''''Transactions Started'''''''''''''''''''''''''''''

            lChildNode = mXmlDocument.CreateElement("Transactions")

            ''''''''''''''''''''''''''''''''''ST Started'''''''''''''''''''''''''''''''''

            lGrandChildNode = mXmlDocument.CreateElement("ST")
            Dim lTempNode As XmlElement

            lTempNode = mXmlDocument.CreateElement("TransactionSetCode")
            lTempNode.InnerText = "270"
            lGrandChildNode.AppendChild(lTempNode.CloneNode(True))

            lTempNode = mXmlDocument.CreateElement("TransactionSetControlNumber")
            lTempNode.InnerText = "000000001" 'This number also has to be unique with in this transaction set
            lGrandChildNode.AppendChild(lTempNode.CloneNode(True))

            lTempNode = mXmlDocument.CreateElement("ImplementationConventionReference")
            lTempNode.InnerText = "005010X279A1"
            lGrandChildNode.AppendChild(lTempNode.CloneNode(True))

            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

            ''''''''''''''''''''''''''''''''''ST Ended'''''''''''''''''''''''''''''''''''

            ''''''''''''''''''''''''''''''''''BHT Started''''''''''''''''''''''''''''''''

            lGrandChildNode = mXmlDocument.CreateElement("BHT")

            lTempNode = mXmlDocument.CreateElement("HierarchialStructuralCode")
            lTempNode.InnerText = "0022"
            lGrandChildNode.AppendChild(lTempNode.CloneNode(True))

            lTempNode = mXmlDocument.CreateElement("PurposeCode")
            lTempNode.InnerText = "13"
            lGrandChildNode.AppendChild(lTempNode.CloneNode(True))

            lTempNode = mXmlDocument.CreateElement("ReferenceIdentification")
            lTempNode.InnerText = pMessageID 'We have assigned a unique number on Larry's Request despite us thinking that it is not the right thing
            lGrandChildNode.AppendChild(lTempNode.CloneNode(True))

            lTempNode = mXmlDocument.CreateElement("CurrentDate")
            lTempNode.InnerText = Format(Date.Now, "yyyyMMdd")
            lGrandChildNode.AppendChild(lTempNode.CloneNode(True))

            lTempNode = mXmlDocument.CreateElement("CurrentTime")            
            lTempNode.InnerText = Format(Date.Now, "hhmmssff")
            lGrandChildNode.AppendChild(lTempNode.CloneNode(True))

            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

            '''''''''''''''''''''''''''''''''End BHT'''''''''''''''''''''''''''''''''''

            '''''''''''''''''''''''''''''L2702000{0} Started '''''''''''''''''''''''''''''

            lGrandChildNode = mXmlDocument.CreateElement("L2702000")
            Dim lTempNode2 As XmlElement


            '''''''''''''''''''''''''''''''HL Started'''''''''''''''''''''''''''''''''
            lTempNode = mXmlDocument.CreateElement("HL")

            lTempNode2 = mXmlDocument.CreateElement("HierarchicalIdNumber")
            lTempNode2.InnerText = "1"
            lTempNode.AppendChild(lTempNode2.CloneNode(True))

            lTempNode2 = mXmlDocument.CreateElement("HierarchicalParentID")
            lTempNode2.InnerText = ""
            lTempNode.AppendChild(lTempNode2.CloneNode(True))

            lTempNode2 = mXmlDocument.CreateElement("HierarchicalLevelCode")
            lTempNode2.InnerText = "20"
            lTempNode.AppendChild(lTempNode2.CloneNode(True))

            lTempNode2 = mXmlDocument.CreateElement("HierarchicalChildCode")
            lTempNode2.InnerText = "1"
            lTempNode.AppendChild(lTempNode2.CloneNode(True))

            lGrandChildNode.AppendChild(lTempNode.CloneNode(True))

            '''''''''''''''''''''''''''''''End HL '''''''''''''''''''''''''''''''''''


            ''''''''''''''''''''''''''''''''Beginning L2702010''''''''''''''''''''''''

            lTempNode = mXmlDocument.CreateElement("L2702010")
            Dim lTempNode3 As XmlElement

            '''''''''''''''''''''''''''''''NM1 Started''''''''''''''''''''''''''''''''''

            lTempNode2 = mXmlDocument.CreateElement("NM1")

            lTempNode3 = mXmlDocument.CreateElement("EntityIdentifierCode")
            lTempNode3.InnerText = "2B"
            lTempNode2.AppendChild(lTempNode3.CloneNode(True))

            lTempNode3 = mXmlDocument.CreateElement("EntityTypeQualifier")
            lTempNode3.InnerText = "2"
            lTempNode2.AppendChild(lTempNode3.CloneNode(True))

            lTempNode3 = mXmlDocument.CreateElement("NameLastOrOrganisationName")
            lTempNode3.InnerText = System.Configuration.ConfigurationManager.AppSettings("SurescriptsName") '"RXHUB" "SURESCRIPTS LLC" '
            lTempNode2.AppendChild(lTempNode3.CloneNode(True))

            lTempNode3 = mXmlDocument.CreateElement("NameFirst")
            lTempNode3.InnerText = ""
            lTempNode2.AppendChild(lTempNode3.CloneNode(True))

            lTempNode3 = mXmlDocument.CreateElement("NameMiddle")
            lTempNode3.InnerText = ""
            lTempNode2.AppendChild(lTempNode3.CloneNode(True))

            lTempNode3 = mXmlDocument.CreateElement("NameSuffix")
            lTempNode3.InnerText = ""
            lTempNode2.AppendChild(lTempNode3.CloneNode(True))

            lTempNode3 = mXmlDocument.CreateElement("IdentificationCodeQualifier")
            lTempNode3.InnerText = "PI"
            lTempNode2.AppendChild(lTempNode3.CloneNode(True))

            lTempNode3 = mXmlDocument.CreateElement("IdentificationCode")
            lTempNode3.InnerText = System.Configuration.ConfigurationManager.AppSettings("SurescriptsParticipantID") ' "S00000000000001" '
            lTempNode2.AppendChild(lTempNode3.CloneNode(True))

            lTempNode.AppendChild(lTempNode2.CloneNode(True))

            ''''''''''''''''''''''''''''''''''End NM1'''''''''''''''''''''''''''''''''''''
            lGrandChildNode.AppendChild(lTempNode.CloneNode(True))
            ''''''''''''''''''''''''''''''''''End of L2702010'''''''''''''''''''''''''''''
            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))
            '''''''''''''''''''''''''''''''''End of L2702000{0}'''''''''''''''''''''''''''''



            '''''''''''''''''''''''''''''L2702000{1} Started '''''''''''''''''''''''''''''

            lGrandChildNode = mXmlDocument.CreateElement("L2702000")



            '''''''''''''''''''''''''''''''HL Started'''''''''''''''''''''''''''''''''
            lTempNode = mXmlDocument.CreateElement("HL")

            lTempNode2 = mXmlDocument.CreateElement("HierarchicalIdNumber")
            lTempNode2.InnerText = "2"
            lTempNode.AppendChild(lTempNode2.CloneNode(True))

            lTempNode2 = mXmlDocument.CreateElement("HierarchicalParentID")
            lTempNode2.InnerText = "1"
            lTempNode.AppendChild(lTempNode2.CloneNode(True))

            lTempNode2 = mXmlDocument.CreateElement("HierarchicalLevelCode")
            lTempNode2.InnerText = "21"
            lTempNode.AppendChild(lTempNode2.CloneNode(True))

            lTempNode2 = mXmlDocument.CreateElement("HierarchicalChildCode")
            lTempNode2.InnerText = "1"
            lTempNode.AppendChild(lTempNode2.CloneNode(True))

            lGrandChildNode.AppendChild(lTempNode.CloneNode(True))

            '''''''''''''''''''''''''''''''End HL '''''''''''''''''''''''''''''''''''


            ''''''''''''''''''''''''''''''''Beginning L2702010''''''''''''''''''''''''

            lTempNode = mXmlDocument.CreateElement("L2702010")


            '''''''''''''''''''''''''''''''NM1 Started''''''''''''''''''''''''''''''''''

            lTempNode2 = mXmlDocument.CreateElement("NM1")

            lTempNode3 = mXmlDocument.CreateElement("EntityIdentifierCode")
            lTempNode3.InnerText = "1P"
            lTempNode2.AppendChild(lTempNode3.CloneNode(True))

            lTempNode3 = mXmlDocument.CreateElement("EntityTypeQualifier")
            lTempNode3.InnerText = "1"
            lTempNode2.AppendChild(lTempNode3.CloneNode(True))

            lTempNode3 = mXmlDocument.CreateElement("NameLastOrOrganisationName")
            lTempNode3.InnerText = pPrescriberName.LastName '"JONES" 
            lTempNode2.AppendChild(lTempNode3.CloneNode(True))

            lTempNode3 = mXmlDocument.CreateElement("NameFirst")
            lTempNode3.InnerText = pPrescriberName.FirstName '"MARK" 
            lTempNode2.AppendChild(lTempNode3.CloneNode(True))

            lTempNode3 = mXmlDocument.CreateElement("NameMiddle")
            lTempNode3.InnerText = pPrescriberName.MiddleName '"" 
            lTempNode2.AppendChild(lTempNode3.CloneNode(True))

            lTempNode3 = mXmlDocument.CreateElement("NameSuffix")
            lTempNode3.InnerText = pPrescriberName.Suffix '"MD" 
            lTempNode2.AppendChild(lTempNode3.CloneNode(True))

            lTempNode3 = mXmlDocument.CreateElement("IdentificationCodeQualifier")
            lTempNode3.InnerText = pPrescriberIdentification.IdentificationQualifier '"SV" For DEA or "XX" for NPI
            lTempNode2.AppendChild(lTempNode3.CloneNode(True))

            lTempNode3 = mXmlDocument.CreateElement("IdentificationCode")
            lTempNode3.InnerText = pPrescriberIdentification.IdentificationNumber '"6666666"
            lTempNode2.AppendChild(lTempNode3.CloneNode(True))

            lTempNode.AppendChild(lTempNode2.CloneNode(True))

            ''''''''''''''''''''''''''''''''''End NM1'''''''''''''''''''''''''''''''''''''

            '''''''''''''''''''''''''''''''''Start REF''''''''''''''''''''''''''''''''''''
            lTempNode2 = mXmlDocument.CreateElement("REF")

            lTempNode3 = mXmlDocument.CreateElement("ReferenceIdentificationQualifier")
            lTempNode3.InnerText = "EO"
            lTempNode2.AppendChild(lTempNode3.CloneNode(True))

            lTempNode3 = mXmlDocument.CreateElement("ReferenceIdentification")
            lTempNode3.InnerText = System.Configuration.ConfigurationManager.AppSettings("RxCureParticipantID") '"T00000000020089"
            lTempNode2.AppendChild(lTempNode3.CloneNode(True))

            lTempNode.AppendChild(lTempNode2.CloneNode(True))

            '''''''''''''''''''''''''''''''''End REF''''''''''''''''''''''''''''''''''''''


            lGrandChildNode.AppendChild(lTempNode.CloneNode(True))
            ''''''''''''''''''''''''''''''''''End of L2702010'''''''''''''''''''''''''''''
            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))
            ''''''''''''''''''''''''''''''''''End of L2702000{1}'''''''''''''''''''''''''''''



            '''''''''''''''''''''''''''''L2702000{2} Started '''''''''''''''''''''''''''''

            lGrandChildNode = mXmlDocument.CreateElement("L2702000")



            '''''''''''''''''''''''''''''''HL Started'''''''''''''''''''''''''''''''''
            lTempNode = mXmlDocument.CreateElement("HL")

            lTempNode2 = mXmlDocument.CreateElement("HierarchicalIdNumber")
            lTempNode2.InnerText = "3"
            lTempNode.AppendChild(lTempNode2.CloneNode(True))

            lTempNode2 = mXmlDocument.CreateElement("HierarchicalParentID")
            lTempNode2.InnerText = "2"
            lTempNode.AppendChild(lTempNode2.CloneNode(True))

            lTempNode2 = mXmlDocument.CreateElement("HierarchicalLevelCode")
            lTempNode2.InnerText = "22"
            lTempNode.AppendChild(lTempNode2.CloneNode(True))

            lTempNode2 = mXmlDocument.CreateElement("HierarchicalChildCode")
            lTempNode2.InnerText = "0"
            lTempNode.AppendChild(lTempNode2.CloneNode(True))

            lGrandChildNode.AppendChild(lTempNode.CloneNode(True))

            '''''''''''''''''''''''''''''''End HL '''''''''''''''''''''''''''''''''''


            ''''''''''''''''''''''''''''''''Beginning L2702010''''''''''''''''''''''''

            lTempNode = mXmlDocument.CreateElement("L2702010")


            '''''''''''''''''''''''''''''''NM1 Started''''''''''''''''''''''''''''''''''

            lTempNode2 = mXmlDocument.CreateElement("NM1")

            lTempNode3 = mXmlDocument.CreateElement("EntityIdentifierCode")
            lTempNode3.InnerText = "IL"
            lTempNode2.AppendChild(lTempNode3.CloneNode(True))

            lTempNode3 = mXmlDocument.CreateElement("EntityTypeQualifier")
            lTempNode3.InnerText = "1"
            lTempNode2.AppendChild(lTempNode3.CloneNode(True))

            lTempNode3 = mXmlDocument.CreateElement("NameLastOrOrganisationName")
            lTempNode3.InnerText = pPatientName.LastName.ToUpper 'LastName.ToUpper
            lTempNode2.AppendChild(lTempNode3.CloneNode(True))

            lTempNode3 = mXmlDocument.CreateElement("NameFirst")
            lTempNode3.InnerText = pPatientName.FirstName.ToUpper 'FirstName.ToUpper
            lTempNode2.AppendChild(lTempNode3.CloneNode(True))

            lTempNode3 = mXmlDocument.CreateElement("NameMiddle")
            lTempNode3.InnerText = pPatientName.MiddleName.ToUpper 'MiddleName.ToUpper
            lTempNode2.AppendChild(lTempNode3.CloneNode(True))

            lTempNode3 = mXmlDocument.CreateElement("NameSuffix")
            lTempNode3.InnerText = pPatientName.Suffix.ToUpper 'Suffix
            lTempNode2.AppendChild(lTempNode3.CloneNode(True))


            lTempNode.AppendChild(lTempNode2.CloneNode(True))

            ''''''''''''''''''''''''''''''''''End NM1'''''''''''''''''''''''''''''''''''''

            ''''''''''''''''''''''''''''''''''Start N3''''''''''''''''''''''''''''''''''''
            lTempNode2 = mXmlDocument.CreateElement("N3")

            lTempNode3 = mXmlDocument.CreateElement("AddressLine1")
            lTempNode3.InnerText = pPatientAddress.AddressLine1 'Address.ToUpper
            lTempNode2.AppendChild(lTempNode3.CloneNode(True))

            lTempNode3 = mXmlDocument.CreateElement("AddressLine2")
            lTempNode3.InnerText = pPatientAddress.AddressLine2 '""    
            lTempNode2.AppendChild(lTempNode3.CloneNode(True))

            lTempNode.AppendChild(lTempNode2.CloneNode(True))
            ''''''''''''''''''''''''''''''''''''End N3''''''''''''''''''''''''''''''''''''

            '''''''''''''''''''''''''''''''''''Start N4'''''''''''''''''''''''''''''''''''
            lTempNode2 = mXmlDocument.CreateElement("N4")

            lTempNode3 = mXmlDocument.CreateElement("CityName")
            lTempNode3.InnerText = pPatientAddress.City 'City.ToUpper
            lTempNode2.AppendChild(lTempNode3.CloneNode(True))

            lTempNode3 = mXmlDocument.CreateElement("StateOrProvinceCode")
            lTempNode3.InnerText = pPatientAddress.State 'State.ToUpper
            lTempNode2.AppendChild(lTempNode3.CloneNode(True))

            lTempNode3 = mXmlDocument.CreateElement("PostalCode")
            lTempNode3.InnerText = pPatientAddress.ZipCode 'PostalCode
            lTempNode2.AppendChild(lTempNode3.CloneNode(True))

            'lTempNode3 = mXmlDocument.CreateElement("CountryCode")
            'lTempNode3.InnerText = "US"
            'lTempNode2.AppendChild(lTempNode3.CloneNode(True))

            lTempNode.AppendChild(lTempNode2.CloneNode(True))
            ''''''''''''''''''''''''''''''''''''End N4''''''''''''''''''''''''''''''''''''

            '''''''''''''''''''''''''''''''''''Start DMG''''''''''''''''''''''''''''''''''
            lTempNode2 = mXmlDocument.CreateElement("DMG")

            lTempNode3 = mXmlDocument.CreateElement("DateFormatQualifier")
            lTempNode3.InnerText = "D8"
            lTempNode2.AppendChild(lTempNode3.CloneNode(True))

            lTempNode3 = mXmlDocument.CreateElement("DOB")
            lTempNode3.InnerText = CType(pPatientDOB, Date).ToString("yyyyMMdd")
            lTempNode2.AppendChild(lTempNode3.CloneNode(True))

            lTempNode3 = mXmlDocument.CreateElement("GenderCode")
            lTempNode3.InnerText = pPatientGender
            lTempNode2.AppendChild(lTempNode3.CloneNode(True))


            lTempNode.AppendChild(lTempNode2.CloneNode(True))

            ''''''''''''''''''''''''''''''''''' End DMG ''''''''''''''''''''''''''''''''''

            ''''''''''''''''''''''''''''''''''''Start DTP ''''''''''''''''''''''''''''''''
            'CHANGE DESCRIPTION: CURRENTLY THIS SEGMENT USAGE HAS CHANGED. WE USED TO SEND SERVICE DATE IN THIS
            'BUT NOW THAT CODE HAS BEEN REMOVED. SO WE WOULD NOT REQUIRE THIS CURRENTLY 
            'CHANGED BY: FARAZ
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

            'lTempNode2 = mXmlDocument.CreateElement("DTP")

            'lTempNode3 = mXmlDocument.CreateElement("DateTimeQualifier")
            'lTempNode3.InnerText = "472"
            'lTempNode2.AppendChild(lTempNode3.CloneNode(True))

            'lTempNode3 = mXmlDocument.CreateElement("DateFormatQualifier")
            'lTempNode3.InnerText = "D8"
            'lTempNode2.AppendChild(lTempNode3.CloneNode(True))

            'lTempNode3 = mXmlDocument.CreateElement("DateOfService")
            'lTempNode3.InnerText = Format(Date.Now, "yyyyMMdd")
            'lTempNode2.AppendChild(lTempNode3.CloneNode(True))


            'lTempNode.AppendChild(lTempNode2.CloneNode(True))

            '''''''''''''''''''''''''''''''''''''End DTP''''''''''''''''''''''''''''''''''

            ''''''''''''''''''''''''''''''''''''Start L2702011{0}'''''''''''''''''''''''''''
            lTempNode2 = mXmlDocument.CreateElement("L2702011")
            Dim lTempNode4 As XmlElement
            '''''''''''''''''''''''''''''''''''''Start EQ''''''''''''''''''''''''''''''''
            lTempNode3 = mXmlDocument.CreateElement("EQ")

            lTempNode4 = mXmlDocument.CreateElement("ServiceTypeCode")
            lTempNode4.InnerText = "30"
            lTempNode3.AppendChild(lTempNode4.CloneNode(True))

            lTempNode2.AppendChild(lTempNode3.CloneNode(True))
            '''''''''''''''''''''''''''''''''''''End EQ'''''''''''''''''''''''''''''''''
            lTempNode.AppendChild(lTempNode2.CloneNode(True))
            '''''''''''''''''''''''''''''''''''''End L2702011{0}''''''''''''''''''''''''''''

            ' ''''''''''''''''''''''''''''''''''''Start L2702011{1}'''''''''''''''''''''''''''
            'lTempNode2 = mXmlDocument.CreateElement("L2702011")

            ' '''''''''''''''''''''''''''''''''''''Start EQ''''''''''''''''''''''''''''''''
            'lTempNode3 = mXmlDocument.CreateElement("EQ")

            'lTempNode4 = mXmlDocument.CreateElement("ServiceTypeCode")
            'lTempNode4.InnerText = "90"
            'lTempNode3.AppendChild(lTempNode4.CloneNode(True))

            'lTempNode2.AppendChild(lTempNode3.CloneNode(True))
            ' '''''''''''''''''''''''''''''''''''''End EQ'''''''''''''''''''''''''''''''''
            'lTempNode.AppendChild(lTempNode2.CloneNode(True))
            ' '''''''''''''''''''''''''''''''''''''End L2702011{1}''''''''''''''''''''''''''''

            lGrandChildNode.AppendChild(lTempNode.CloneNode(True))
            ''''''''''''''''''''''''''''''''''End of L2702010'''''''''''''''''''''''''''''
            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))
            ''''''''''''''''''''''''''''''''''End of L2702000{2}'''''''''''''''''''''''''''

            ''''''''''''''''''''''''''''''''''Start SE '''''''''''''''''''''''''''''
            lGrandChildNode = mXmlDocument.CreateElement("SE")

            lTempNode = mXmlDocument.CreateElement("SegmentCount")
            lTempNode.InnerText = "14"
            lGrandChildNode.AppendChild(lTempNode.CloneNode(True))

            lTempNode = mXmlDocument.CreateElement("TransactionSetControlNumber")
            lTempNode.InnerText = "000000001" 'This has to be unique with in this transaction set 
            lGrandChildNode.AppendChild(lTempNode.CloneNode(True))

            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))
            ''''''''''''''''''''''''''''''''''''End SE'''''''''''''''''''''''''''''''''''

            lNode.AppendChild(lChildNode.CloneNode(True))
            ''''''''''''''''''''''''''''''''''End Transactions'''''''''''''''''''''''''''''

            ''''''''''''''''''''''''''''''''''''Begin GE ''''''''''''''''''''''''''''''''''
            lChildNode = mXmlDocument.CreateElement("GE")

            lGrandChildNode = mXmlDocument.CreateElement("TransactionSetCount")
            lGrandChildNode.InnerText = "1"
            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

            lGrandChildNode = mXmlDocument.CreateElement("GroupControlNumber")
            lGrandChildNode.InnerText = "000000001" 'This has to be unique with in this transaction set 
            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

            lNode.AppendChild(lChildNode.CloneNode(True))

            '''''''''''''''''''''''''''''''''''''End GE''''''''''''''''''''''''''''''''''''
            mXmlDocument.DocumentElement.AppendChild(lNode.CloneNode(True))
            ''''''''''''''''''''''''''''''End Functional Group'''''''''''''''''''''''''''''

            '''''''''''''''''''''''''''''''''''Start IEA ''''''''''''''''''''''''''''''''''
            lNode = mXmlDocument.CreateElement("IEA")

            lChildNode = mXmlDocument.CreateElement("FunctionalGroupCount")
            lChildNode.InnerText = "1"
            lNode.AppendChild(lChildNode.CloneNode(True))

            lChildNode = mXmlDocument.CreateElement("InterchangeControlNumber")
            lChildNode.InnerText = GetControlNumber()
            lNode.AppendChild(lChildNode.CloneNode(True))

            mXmlDocument.DocumentElement.AppendChild(lNode.CloneNode(True))
            ''''''''''''''''''''''''''''''''''''End IEA'''''''''''''''''''''''''''''''''


            'This NameHandler is used to communicate the name of the 
            'two files created(xml and edi) to the Response Object
            'Please access this object through the property and pass it to the
            'Response object
            mNameHandlerBL = New NameHandlerBL()

            '''''''''''''''''''''''''''''''Writing to File''''''''''''''''''''''''''''''
            WriteToFile(System.Configuration.ConfigurationManager.AppSettings("RxHubEligibilityRequestPath") + mNameHandlerBL.XmlName(pPrescriberIdentification.IdentificationNumber), mXmlDocument.OuterXml.ToString)

            '''''''''''''''''''''''''''''''Mapping to File'''''''''''''''''''''''''''''
            MapFile(System.Configuration.ConfigurationManager.AppSettings("RxHubEligibilityRequestPath") + mNameHandlerBL.XmlName(pPrescriberIdentification.IdentificationNumber), System.Configuration.ConfigurationManager.AppSettings("RxHubEligibilityRequestPath") + mNameHandlerBL.EDIName(pPrescriberIdentification.IdentificationNumber))





        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\RequestBL.CreateRequest(ByVal pPrescriberName As sName,ByVal pPrescriberIdentification As sIdentification,ByVal pPatientName As sName,ByVal pPatientIdentification As sIdentification,ByVal pPatientAddress As sAddress,ByVal pPatientGender As Char,ByVal pPatientDOB As String,ByRef pMessageID As Integer) ")
        Finally


        End Try

        Return mXmlDocument.OuterXml.ToString

    End Function

    

    'This function will create the medication history Request

    Public Function CreateMedicationHistoryRequest(ByVal pMoreHistory As MoreHistory, _
    ByVal pPrescriber As Prescriber, ByVal pPatient As PatientType, ByVal pResend As Boolean, ByRef pMessageID As Integer, Optional ByVal pISA13 As String = "")

        Dim MHReq As MedicationHistoryRequest.MsgRXHREQ
        Try

            MHReq = New MedicationHistoryRequest.MsgRXHREQ
            pMessageID = GetControlNumber()

            '''''''''''''''''''''''''''''UNA Started''''''''''''''''''''''''''''''''''''''
            With MHReq.UNA
                .SegmentTerminator.Value = Chr(30)
                .ComponentDataElementSeparator.Value = Chr(29)
                .DataElementSeparator.Value = Chr(28)
                .DecimalNotation.Value = "."
                .RepetitionSeparator.Value = Chr(31)
                .ReleaseIndicator.Value = "/"
            End With
            ''''''''''''''''''''''''''''''UNA Ended/Created''''''''''''''''''''''''''''''''''

            '''''''''''''''''''''''''''''UIB Started''''''''''''''''''''''''''''''''''''''
            With MHReq.UIB
                '''''''''''''''''''''''''''''''Syntax Identifier'''''''''''''''''''''''''''''''''''''''
                .SyntaxIdentifier.SyntaxIdentifier.Value = "UNOA"
                .SyntaxIdentifier.SyntaxVersionNumber.Value = "0"
                '''''''''''''''''''''''''''''''''Syntax Identifier Ended''''''''''''''''''''''''''''''''

                '''''''''''''''''''''''''''''''Transaction Reference'''''''''''''''''''''''''''''''''''''''
                .TransactionReference.TransactionControlReference.Value = pMessageID
                .TransactionReference.InitiatorReferenceIdentifier.Value = pISA13
                '''''''''''''''''''''''''''''''''Transaction Reference Ended''''''''''''''''''''''''''''''''

                '''''''''''''''''''''''''''''''Interchange Sender'''''''''''''''''''''''''''''''''''''''
                .InterchangeSender.SenderIdentificationLevelOne.Value = System.Configuration.ConfigurationManager.AppSettings("RxCureParticipantID") 'Sender ID
                .InterchangeSender.LevelOneIdentificationCodeQualifier.Value = "ZZZ"
                .InterchangeSender.SenderIdentificationLevelTwo.Value = System.Configuration.ConfigurationManager.AppSettings("RxHubPassword") 'Sender Password
                .InterchangeSender.SenderIdentificationLevelThree.Value = ""
                '''''''''''''''''''''''''''''''''Interchange Sender Ended''''''''''''''''''''''''''''''''

                '''''''''''''''''''''''''''''''Interchange Recipient'''''''''''''''''''''''''''''''''''''''
                If pMoreHistory.FillData Then
                    .InterchangeRecipient.RecipientIdentificationLevelOne.Value = "S00000000000001" 'Fixed Value incase of Fill Data
                    .InterchangeRecipient.LevelOneIdentificationCodeQualifier.Value = "ZZZ"
                Else
                    .InterchangeRecipient.RecipientIdentificationLevelOne.Value = pMoreHistory.PBMId.Replace("%", "%25") 'Recipient ID
                    .InterchangeRecipient.LevelOneIdentificationCodeQualifier.Value = "ZZZ"
                End If
                '.InterchangeRecipient.RecipientIdentificationLevelTwo.Value = System.Configuration.ConfigurationManager.AppSettings("RxHubParticipantID")
                '''''''''''''''''''''''''''''''''Interchange Recipient Ended''''''''''''''''''''''''''''''''

                '''''''''''''''''''''''''''''''Date Of Initiation'''''''''''''''''''''''''''''''''''''''
                .DataOfInitiation.Date.Year.Value = Date.Now.Year.ToString()
                .DataOfInitiation.Date.Month.Value = Date.Now.Month.ToString().PadLeft(2, "0")
                .DataOfInitiation.Date.Day.Value = Date.Now.Day.ToString().PadLeft(2, "0")

                .DataOfInitiation.EventTime.Hours.Value = Date.Now.Hour.ToString().PadLeft(2, "0")
                .DataOfInitiation.EventTime.Minutes.Value = Date.Now.Minute.ToString().PadLeft(2, "0")
                .DataOfInitiation.EventTime.Seconds.Value = Date.Now.Second.ToString().PadLeft(2, "0")
                '''''''''''''''''''''''''''''''''Date Of Initiation Ended''''''''''''''''''''''''''''''''

                .TestIndicator.Value = System.Configuration.ConfigurationManager.AppSettings("IsTestEnvironment") '"1"

                If pMoreHistory.FillData Then
                    .TransactionReference.ControllingAgencyCoded.Value = "FIL"
                End If



            End With
            ''''''''''''''''''''''''''''''UIB Ended/Created''''''''''''''''''''''''''''''''''


            '''''''''''''''''''''''''''''UIH Started''''''''''''''''''''''''''''''''''''''
            With MHReq.UIH
                .MessageType.MessageType.Value = "SCRIPT"
                .MessageType.MessageVersionNumber.Value = "010"
                .MessageType.MessageReleaseNumber.Value = "006"
                .MessageType.MessageFunction.Value = "RXHREQ"
            End With
            ''''''''''''''''''''''''''''''UIH Ended/Created''''''''''''''''''''''''''''''''''



            '''''''''''''''''''''''''''''PVD Started''''''''''''''''''''''''''''''''''''''

            With MHReq.PVD
                Dim PVDpc As MedicationHistoryRequest.SegPVD
                PVDpc = .Append
                With PVDpc
                    .ProviderCoded.Value = "PC"

                    .ProviderName.PartyName.Value = pPrescriber.Name.LastName
                    .ProviderName.FirstName.Value = pPrescriber.Name.FirstName


                    For x As Integer = 0 To pPrescriber.IdentificationCount - 1
                        If Not String.IsNullOrEmpty(pPrescriber.Identification(x).IdentificationNumber) Then
                            Dim PrescriberRequest As MedicationHistoryRequest.FldI001
                            PrescriberRequest = .ReferenceNumber.Append
                            PrescriberRequest.ReferenceNumber.Value = pPrescriber.Identification(x).IdentificationNumber
                            PrescriberRequest.ReferenceQualifier.Value = pPrescriber.Identification(x).IdentificationQualifier
                        End If
                    Next


                    For x As Integer = 0 To pPrescriber.Phone.Length - 1
                        If pPrescriber.Phone(x) IsNot Nothing Then

                            Dim Phone As MedicationHistoryRequest.FldI016
                            Phone = .CommunicationNumber.Append
                            Phone.CodeListQualifier.Value = pPrescriber.Phone(x).PhoneNumberQualifier
                            Phone.CommunicationNumber.Value = pPrescriber.Phone(x).PhoneNumber

                        End If
                    Next

                End With
            End With

            ''''''''''''''''''''''''''''''PVD Ended/Created''''''''''''''''''''''''''''''''''

            '''''''''''''''''''''''''''''PTT Started''''''''''''''''''''''''''''''''''''''
            With MHReq.PTT
                .IndividualRelationshipCoded.Value = pPatient.RelationShipCode  'Values: 1=Member 2=Spouse 3=Child/Dependent 4=Other
                .DateOfBirth.Value = pPatient.DateOfBirth
                .Name.PartyName.Value = pPatient.Name.LastName 'Last Name
                .Name.FirstName.Value = pPatient.Name.FirstName
                .Name.MiddleName.Value = pPatient.Name.MiddleName
                .Address.AddressLine1.Value = ""
                .Address.City.Value = ""
                .Address.State.Value = ""
                .Address.ZipCode.Value = ""

                Select Case pPatient.Gender
                    Case GenderType.M
                        .GenderCoded.Value = "M"
                    Case GenderType.F
                        .GenderCoded.Value = "F"
                    Case GenderType.U
                        .GenderCoded.Value = "U"
                End Select
            End With
            ''''''''''''''''''''''''''''''PTT Ended/Created''''''''''''''''''''''''''''''''''


            '''''''''''''''''''''''''''''COO Started''''''''''''''''''''''''''''''''''''''
            Dim COO1 As MedicationHistoryRequest.SegCOO
            COO1 = MHReq.COO.Append
            With COO1

                If Not pMoreHistory.FillData Then
                    COO1.PayerReferenceNumber.ReferenceNumber.Value = pMoreHistory.PBMId.Replace("%", "%25")
                    COO1.PayerReferenceNumber.ReferenceQualifier.Value = "2U"
                    COO1.PayerPartyName.Value = pMoreHistory.PBMName 'pPBMName
                End If

                'This date is the range of history required and has been left out because we request the maximum history
                If pResend = True Then
                    Dim dt1 As MedicationHistoryRequest.FldI006
                    dt1 = .Date.Append
                    dt1.DateTimePeriodQualifier.Value = "07"
                    dt1.DataTimePeriod.Value = Date.Now.AddYears(-2).ToString("yyyyMMdd")
                    dt1.DateTimePeriodFormatQualifier.Value = "102"

                    Dim dt2 As MedicationHistoryRequest.FldI006
                    dt2 = .Date.Append
                    dt2.DateTimePeriodQualifier.Value = "36"
                    dt2.DataTimePeriod.Value = pMoreHistory.LastDate
                    dt2.DateTimePeriodFormatQualifier.Value = "102"
                End If

                'This part is subject to verification
                COO1.ResponseCoded.Value = System.Configuration.ConfigurationManager.AppSettings("PatientConsent") '"Y"

                If Not pMoreHistory.FillData Then
                    COO1.PatientIdentifier.Value = pMoreHistory.CardHolderReferenceNumber 'PBM Unique member ID
                End If

                COO1.CardholderID.Value = "" 'pMoreHistory.CardHolderReferenceNumber
                COO1.CardHolderName.PartyName.Value = pPatient.Name.LastName
                COO1.CardHolderName.FirstName.Value = pPatient.Name.FirstName


            End With


            'lChildNode = mXmlDocument.CreateElement("CardHolderReferenceNumber")
            'lChildNode.InnerText = "" 'pMoreHistory.CardHolderReferenceNumber 'pPatient.CardHolderReferenceNumber
            'lNode.AppendChild(lChildNode.CloneNode(True))

            'lChildNode = mXmlDocument.CreateElement("CardHolderName")
            'lChildNode.InnerText = Left(pPatient.Name.LastName, 17) & ", " & Left(pPatient.Name.FirstName, 16)
            'lNode.AppendChild(lChildNode.CloneNode(True))

            ''''''''''''''''''''''''''''''COO Ended/Created''''''''''''''''''''''''''''''''''


            '''''''''''''''''''''''''''''UIT Started''''''''''''''''''''''''''''''''''''''
            With MHReq.UIT
                .NumberofSegmentsInMessage.Value = 5

            End With

            ''''''''''''''''''''''''''''''UIT Ended/Created''''''''''''''''''''''''''''''''''


            '''''''''''''''''''''''''''''UIZ Started''''''''''''''''''''''''''''''''''''''

            With MHReq.UIZ
                .InterchangeControlCount.Value = 1
            End With

            ''''''''''''''''''''''''''''''UIZ Ended/Created''''''''''''''''''''''''''''''''''

            '''''''''''''''''''''''''''''''Writing to File''''''''''''''''''''''''''''''


            WriteToFile(System.Configuration.ConfigurationManager.AppSettings("RxHubHistoryRequestPath") + NameHandlerBL.EDIName(RxHubUtility.CleanString(pMoreHistory.CardHolderReferenceNumber)), MHReq.Parse())



            '''''''''''''''''''''''''''''''Mapping to File'''''''''''''''''''''''''''''
            'MapFile(System.Configuration.ConfigurationManager.AppSettings("RxHubHistoryRequestPath") + NameHandlerBL.XmlName(RxHubUtility.CleanString(pMoreHistory.CardHolderReferenceNumber)), System.Configuration.ConfigurationManager.AppSettings("RxHubHistoryRequestPath") + NameHandlerBL.EDIName(RxHubUtility.CleanString(pMoreHistory.CardHolderReferenceNumber)))

        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\RequestBL.CreateMedicationHistoryRequest(ByVal pMoreHistory As MoreHistory,ByVal pPrescriber As Prescriber, ByVal pPatient As PatientType, ByVal pResend As Boolean, ByRef pMessageID As Integer) ")
        End Try

        Return MHReq.Parse()
    End Function

    'This function creates the provider update request xml
    Private Function CreateProviderUpdateRequest( _
    ByVal pMessageID As String, _
    ByVal pPrescriber As Prescriber, _
    ByVal pActionCode As ActionCode)



        Dim lNode As XmlElement = Nothing
        Dim lChildNode As XmlElement = Nothing
        Dim lGrandChildNode As XmlElement = Nothing
        Dim lGreatGrandChildNode As XmlElement = Nothing
        Dim lTemp As XmlElement = Nothing

        Try

            mXmlDocument = New XmlDataDocument
            mXmlDocument.LoadXml("<Message xmlns=""http://www.ProviderUpdateRequest.com/messaging"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xsi:schemaLocation=""http://www.ProviderUpdateRequest.com/messaging PVDUPD.xsd""></Message>")

            '''''''''''''''''''''''''''''''''Start Header'''''''''''''''''''''''''''''''''''
            lNode = mXmlDocument.CreateElement("Header")

            lChildNode = mXmlDocument.CreateElement("To")
            lChildNode.InnerText = System.Configuration.ConfigurationManager.AppSettings("RxCureParticipantID")
            lNode.AppendChild(lChildNode.CloneNode(True))

            lChildNode = mXmlDocument.CreateElement("From")

            lGrandChildNode = mXmlDocument.CreateElement("PartyName")
            lGrandChildNode.InnerText = System.Configuration.ConfigurationManager.AppSettings("RxHubName")
            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

            lGrandChildNode = mXmlDocument.CreateElement("PartyPassword")
            lGrandChildNode.InnerText = System.Configuration.ConfigurationManager.AppSettings("RxHubPassword")
            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

            lNode.AppendChild(lChildNode.CloneNode(True))

            lChildNode = mXmlDocument.CreateElement("MessageID")
            lChildNode.InnerText = pMessageID
            lNode.AppendChild(lChildNode.CloneNode(True))

            lChildNode = mXmlDocument.CreateElement("RelatesToMessageID")
            lChildNode.InnerText = ""
            lNode.AppendChild(lChildNode.CloneNode(True))

            lChildNode = mXmlDocument.CreateElement("SentTime")
            lChildNode.InnerText = DateTime.Now.ToString("yyyyMMddThhmmss")
            lNode.AppendChild(lChildNode.CloneNode(True))

            lChildNode = mXmlDocument.CreateElement("SegmentCount")
            lChildNode.InnerText = "4"
            lNode.AppendChild(lChildNode.CloneNode(True))

            lChildNode = mXmlDocument.CreateElement("TestMessage")
            lChildNode.InnerText = System.Configuration.ConfigurationManager.AppSettings("IsTestMessage")
            lNode.AppendChild(lChildNode.CloneNode(True))

            mXmlDocument.DocumentElement.AppendChild(lNode.CloneNode(True))

            ''''''''''''''''''''''''''''''End Header '''''''''''''''''''''''''''''''''''''''

            ''''''''''''''''''''''''''''''Start Body''''''''''''''''''''''''''''''''''''''''
            lNode = mXmlDocument.CreateElement("Body")

            '''''''''''''''''''''''''''''''Start ProviderUpdate ''''''''''''''''''''''''''
            lChildNode = mXmlDocument.CreateElement("ProviderUpdate")

            lGrandChildNode = mXmlDocument.CreateElement("BroadcastQualifierCode")
            lGrandChildNode.InnerText = "PC"
            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

            lGrandChildNode = mXmlDocument.CreateElement("BroadcastAction")
            lGreatGrandChildNode = mXmlDocument.CreateElement("BroadcastType")
            lGreatGrandChildNode.InnerText = "U"
            lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))

            lGreatGrandChildNode = mXmlDocument.CreateElement("ActionCode")
            lGreatGrandChildNode.InnerText = "0" & pActionCode
            lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))
            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

            '''''''''''''''''''''''''''''''Start Prescriber '''''''''''''''''''''''''''''''''

            lGrandChildNode = mXmlDocument.CreateElement("Prescriber")


            For x As Integer = 0 To pPrescriber.IdentificationCount - 1

                lGreatGrandChildNode = mXmlDocument.CreateElement("Identification")
                lTemp = mXmlDocument.CreateElement("PrescriberID")
                lTemp.InnerText = pPrescriber.Identification(x).IdentificationNumber
                lGreatGrandChildNode.AppendChild(lTemp.CloneNode(True))

                lTemp = mXmlDocument.CreateElement("PrescriberIDQualifier")
                lTemp.InnerText = pPrescriber.Identification(x).IdentificationQualifier
                lGreatGrandChildNode.AppendChild(lTemp.CloneNode(True))

                lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))

            Next

            lGreatGrandChildNode = mXmlDocument.CreateElement("Clinic")
            lTemp = mXmlDocument.CreateElement("ClinicName")
            lTemp.InnerText = pPrescriber.Clinic.ClinicName
            lGreatGrandChildNode.AppendChild(lTemp.CloneNode(True))

            lTemp = mXmlDocument.CreateElement("ClinicCode")
            lTemp.InnerText = pPrescriber.Clinic.ClinicCode
            lGreatGrandChildNode.AppendChild(lTemp.CloneNode(True))


            lGreatGrandChildNode = mXmlDocument.CreateElement("Name")
            lTemp = mXmlDocument.CreateElement("LastName")
            lTemp.InnerText = pPrescriber.Name.LastName
            lGreatGrandChildNode.AppendChild(lTemp.CloneNode(True))

            lTemp = mXmlDocument.CreateElement("FirstName")
            lTemp.InnerText = pPrescriber.Name.FirstName
            lGreatGrandChildNode.AppendChild(lTemp.CloneNode(True))

            lTemp = mXmlDocument.CreateElement("MiddleName")
            lTemp.InnerText = pPrescriber.Name.MiddleName
            lGreatGrandChildNode.AppendChild(lTemp.CloneNode(True))

            lTemp = mXmlDocument.CreateElement("Suffix")
            lTemp.InnerText = pPrescriber.Name.Suffix
            lGreatGrandChildNode.AppendChild(lTemp.CloneNode(True))

            lTemp = mXmlDocument.CreateElement("Prefix")
            lTemp.InnerText = pPrescriber.Name.Prefix
            lGreatGrandChildNode.AppendChild(lTemp.CloneNode(True))

            lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))

            lGreatGrandChildNode = mXmlDocument.CreateElement("Speciality")
            lTemp = mXmlDocument.CreateElement("Qualifier")
            lTemp.InnerText = pPrescriber.Speciality.Qualifier
            lGreatGrandChildNode.AppendChild(lTemp.CloneNode(True))

            lTemp = mXmlDocument.CreateElement("SpecialityCode")
            lTemp.InnerText = pPrescriber.Speciality.SpecialityCode
            lGreatGrandChildNode.AppendChild(lTemp.CloneNode(True))

            lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))


            lGreatGrandChildNode = mXmlDocument.CreateElement("PrescriberAgent")
            lTemp = mXmlDocument.CreateElement("LastName")
            lTemp.InnerText = pPrescriber.PrescriberAgent.LastName
            lGreatGrandChildNode.AppendChild(lTemp.CloneNode(True))

            lTemp = mXmlDocument.CreateElement("FirstName")
            lTemp.InnerText = pPrescriber.PrescriberAgent.FirstName
            lGreatGrandChildNode.AppendChild(lTemp.CloneNode(True))

            lTemp = mXmlDocument.CreateElement("MiddleName")
            lTemp.InnerText = pPrescriber.PrescriberAgent.MiddleName
            lGreatGrandChildNode.AppendChild(lTemp.CloneNode(True))

            lTemp = mXmlDocument.CreateElement("Suffix")
            lTemp.InnerText = pPrescriber.PrescriberAgent.Suffix
            lGreatGrandChildNode.AppendChild(lTemp.CloneNode(True))

            lTemp = mXmlDocument.CreateElement("Prefix")
            lTemp.InnerText = pPrescriber.PrescriberAgent.Prefix
            lGreatGrandChildNode.AppendChild(lTemp.CloneNode(True))

            lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))

            lGreatGrandChildNode = mXmlDocument.CreateElement("Address")
            lTemp = mXmlDocument.CreateElement("AddressLine1")
            lTemp.InnerText = pPrescriber.Address.AddressLine1
            lGreatGrandChildNode.AppendChild(lTemp.CloneNode(True))

            lTemp = mXmlDocument.CreateElement("AddressLine2")
            lTemp.InnerText = pPrescriber.Address.AddressLine2
            lGreatGrandChildNode.AppendChild(lTemp.CloneNode(True))

            lTemp = mXmlDocument.CreateElement("City")
            lTemp.InnerText = pPrescriber.Address.City
            lGreatGrandChildNode.AppendChild(lTemp.CloneNode(True))

            lTemp = mXmlDocument.CreateElement("State")
            lTemp.InnerText = pPrescriber.Address.State
            lGreatGrandChildNode.AppendChild(lTemp.CloneNode(True))

            lTemp = mXmlDocument.CreateElement("ZipCode")
            lTemp.InnerText = pPrescriber.Address.ZipCode
            lGreatGrandChildNode.AppendChild(lTemp.CloneNode(True))

            lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))

            lGreatGrandChildNode = mXmlDocument.CreateElement("Email")
            lGreatGrandChildNode.InnerText = pPrescriber.Email
            lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))

            lGreatGrandChildNode = mXmlDocument.CreateElement("PhoneNumbers")

            For x As Integer = 0 To pPrescriber.PhoneCount - 1

                If pPrescriber.Phone(x) IsNot Nothing Then

                    lTemp = mXmlDocument.CreateElement("Phone")

                    Dim lTemp2 As XmlElement = mXmlDocument.CreateElement("Number")
                    lTemp2.InnerText = pPrescriber.Phone(x).PhoneNumber
                    lTemp.AppendChild(lTemp2.CloneNode(True))

                    lTemp2 = mXmlDocument.CreateElement("Qualifier")
                    lTemp2.InnerText = pPrescriber.Phone(x).PhoneNumberQualifier
                    lTemp.AppendChild(lTemp2.CloneNode(True))

                    lGreatGrandChildNode.AppendChild(lTemp.CloneNode(True))

                End If

            Next

            lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))
            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))


            '''''''''''''''''''''''''''''''''End Prescriber ''''''''''''''''''''''''''''''''''''


            '''''''''''''''''''''''''''''''''Start Supervisor''''''''''''''''''''''''''''''''
            lGrandChildNode = mXmlDocument.CreateElement("Supervisor")


            ''For x As Integer = 0 To pPrescriber.IdentificationCount - 1

            ''    lGreatGrandChildNode = mXmlDocument.CreateElement("Identification")
            ''    lTemp = mXmlDocument.CreateElement("PrescriberID")
            ''    lTemp.InnerText = "" 'pSupervisor.Identification(x).PrescriberID
            ''    lGreatGrandChildNode.AppendChild(lTemp.CloneNode(True))

            ''    lTemp = mXmlDocument.CreateElement("PrescriberIDQualifier")
            ''    lTemp.InnerText = "" 'pSupervisor.Identification(x).PrescriberIDQualifier
            ''    lGreatGrandChildNode.AppendChild(lTemp.CloneNode(True))

            ''    lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))

            ''Next

            ''lGreatGrandChildNode = mXmlDocument.CreateElement("Clinic")
            ''lTemp = mXmlDocument.CreateElement("ClinicName")
            ''lTemp.InnerText = pSupervisor.Clinic.ClinicName
            ''lGreatGrandChildNode.AppendChild(lTemp.CloneNode(True))

            ''lTemp = mXmlDocument.CreateElement("ClinicCode")
            ''lTemp.InnerText = pSupervisor.Clinic.ClinicCode
            ''lGreatGrandChildNode.AppendChild(lTemp.CloneNode(True))


            'lGreatGrandChildNode = mXmlDocument.CreateElement("Name")
            'lTemp = mXmlDocument.CreateElement("LastName")
            'lTemp.InnerText = pSupervisor.Name.LastName
            'lGreatGrandChildNode.AppendChild(lTemp.CloneNode(True))

            'lTemp = mXmlDocument.CreateElement("FirstName")
            'lTemp.InnerText = pSupervisor.Name.FirstName
            'lGreatGrandChildNode.AppendChild(lTemp.CloneNode(True))

            'lTemp = mXmlDocument.CreateElement("MiddleName")
            'lTemp.InnerText = pSupervisor.Name.MiddleName
            'lGreatGrandChildNode.AppendChild(lTemp.CloneNode(True))

            'lTemp = mXmlDocument.CreateElement("Suffix")
            'lTemp.InnerText = pSupervisor.Name.Suffix
            'lGreatGrandChildNode.AppendChild(lTemp.CloneNode(True))

            'lTemp = mXmlDocument.CreateElement("Prefix")
            'lTemp.InnerText = pSupervisor.Name.Prefix
            'lGreatGrandChildNode.AppendChild(lTemp.CloneNode(True))

            'lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))


            For x As Integer = 0 To pPrescriber.SupportCount - 1

                If pPrescriber.SupportQualifier(x) IsNot Nothing Then

                    lGreatGrandChildNode = mXmlDocument.CreateElement("SupportQualifier")
                    lGreatGrandChildNode.InnerText = pPrescriber.SupportQualifier(x)
                    lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))

                End If

            Next


            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))
            '''''''''''''''''''''''''''''End of Supervisor'''''''''''''''''''''''''''''''

            lNode.AppendChild(lChildNode.CloneNode(True))

            '''''''''''''''''''''''''''''End of Provider Update '''''''''''''''''''''''''''

            mXmlDocument.DocumentElement.AppendChild(lNode.CloneNode(True))


            '''''''''''''''''''''''''''''End of Body'''''''''''''''''''''''''''''''''''''''

            mNameHandlerBL = New NameHandlerBL()

            '''''''''''''''''''''''''''''''Writing to File''''''''''''''''''''''''''''''
            WriteToFile(System.Configuration.ConfigurationManager.AppSettings("ProviderUpdateRequestPath") + NameHandlerBL.XmlName, mXmlDocument.OuterXml.ToString)

            '''''''''''''''''''''''''''''''Mapping to File'''''''''''''''''''''''''''''
            MapFile(System.Configuration.ConfigurationManager.AppSettings("ProviderUpdateRequestPath") + NameHandlerBL.XmlName, System.Configuration.ConfigurationManager.AppSettings("ProviderUpdateRequestPath") + NameHandlerBL.EDIName)


        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\RequestBL.CreateProviderUpdateRequest(ByVal pMessageID As String,ByVal pPrescriber As Prescriber,ByVal pActionCode As ActionCode) ")
        End Try

        Return mXmlDocument.OuterXml.ToString

    End Function


    

    Private Function CreateNewRxRequest(ByVal pRxID As String, _
                                        ByVal pPharmacy As PharmacyType, _
                                        ByVal pPrescriber As Prescriber, _
                                        ByVal pPatient As PatientType, _
                                        ByVal pMedication As Medication, _
                                        ByVal pIsPrescribingAgent As Boolean, _
                                        ByVal pConnectionString As String, _
                                        ByVal pRxReferenceNumber As String, _
                                        ByVal pBIN As String, _
                                        ByVal pPBM As String)


        'There will have to be a user object passed to this function instead of 
        ' the connection string  and the clinicCode



        Dim lMessageId As String = Nothing
        Dim lXmlDocument As String = ""
        Dim lPBMID As String = String.Empty
        Dim lPBMName As String = String.Empty

        If Not pPBM.Equals("") Then
            lPBMID = pPBM.Split("|")(0)
            lPBMName = pPBM.Split("|")(1)
        End If


        Dim lNode As XmlElement = Nothing
        Dim lChildNode As XmlElement = Nothing
        Dim lGrandChildNode As XmlElement = Nothing
        Dim lGreatGrandChildNode As XmlElement = Nothing
        Dim lDescendant As XmlElement = Nothing
        Dim lGrandDescendant As XmlElement = Nothing

        Try

            mXmlDocument = New XmlDataDocument
            mXmlDocument.LoadXml("<Message xmlns=""http://www.RXHUB.com/NewRx"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xsi:schemaLocation=""http://www.RXHUB.com/NewRx RXHubSIG.xsd""></Message>")


            '''''''''''''''''''''''''''''''''Start Header'''''''''''''''''''''''''''''''''''
            lNode = mXmlDocument.CreateElement("Header")

            lChildNode = mXmlDocument.CreateElement("To")
            lChildNode.InnerText = System.Configuration.ConfigurationManager.AppSettings("RxHubName")
            lNode.AppendChild(lChildNode.CloneNode(True))

            lChildNode = mXmlDocument.CreateElement("From")
            lChildNode.InnerText = System.Configuration.ConfigurationManager.AppSettings("RxCureParticipantID")
            lNode.AppendChild(lChildNode.CloneNode(True))

            lChildNode = mXmlDocument.CreateElement("Password")
            lChildNode.InnerText = System.Configuration.ConfigurationManager.AppSettings("RxHubPassword")
            lNode.AppendChild(lChildNode.CloneNode(True))

            lChildNode = mXmlDocument.CreateElement("MessageID")
            lChildNode.InnerText = ""
            lNode.AppendChild(lChildNode.CloneNode(True))

            lChildNode = mXmlDocument.CreateElement("RelatesToMessageID")
            lChildNode.InnerText = ""
            lNode.AppendChild(lChildNode.CloneNode(True))

            lChildNode = mXmlDocument.CreateElement("SentTime")
            lChildNode.InnerText = Date.Now.ToString("yyyyMMddTHHmmss")
            lNode.AppendChild(lChildNode.CloneNode(True))

            lChildNode = mXmlDocument.CreateElement("SegmentCount")
            lChildNode.InnerText = IIf(pPatient.CardHolderReferenceNumber.Equals("") And pBIN.Equals("") And pPatient.CardHolderName.FirstName.Equals("") And pPatient.GroupID.Equals("") And lPBMName.Equals(""), "6", "7")
            lNode.AppendChild(lChildNode.CloneNode(True))

            lChildNode = mXmlDocument.CreateElement("TestMessage")
            lChildNode.InnerText = System.Configuration.ConfigurationManager.AppSettings("IsTestEnvironment")
            lNode.AppendChild(lChildNode.CloneNode(True))

            mXmlDocument.DocumentElement.AppendChild(lNode.CloneNode(True))

            ''''''''''''''''''''''''''''''End Header '''''''''''''''''''''''''''''''''''''''

            ''''''''''''''''''''''''''''''Start Body''''''''''''''''''''''''''''''''''''''''
            lNode = mXmlDocument.CreateElement("Body")

            '''''''''''''''''''''''''''''''Start NewRx'''''''''''''''''''''''''''''''''
            lChildNode = mXmlDocument.CreateElement("NewRx")

            'CHANGE LOG: THE ORDERING HAS BEEN CHANGED A`LA XSD
            If Not pRxReferenceNumber.Equals("") Then
                lGrandChildNode = mXmlDocument.CreateElement("RxReferenceNumber")
                lGrandChildNode.InnerText = pRxReferenceNumber
                lChildNode.AppendChild(lGrandChildNode.CloneNode(True))
            End If

            lGrandChildNode = mXmlDocument.CreateElement("PrescriberOrderNumber")
            lGrandChildNode.InnerText = ""
            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))


            ''''''''''''''''''''''''''''''Start Pharmacy''''''''''''''''''''''''''''''
            lGrandChildNode = mXmlDocument.CreateElement("Pharmacy")
            lGreatGrandChildNode = mXmlDocument.CreateElement("Identification")

            lDescendant = mXmlDocument.CreateElement("NCPDPID")
            lDescendant.InnerText = pPharmacy.Identification.IdentificationNumber
            lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

            lDescendant = mXmlDocument.CreateElement("IdentificationQualifier")
            lDescendant.InnerText = pPharmacy.Identification.IdentificationQualifier
            lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

            lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))

            lGreatGrandChildNode = mXmlDocument.CreateElement("StoreName")
            lGreatGrandChildNode.InnerText = pPharmacy.StoreName

            lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))

            ''THE 2 SKIPPED FIELDS HAVE NOT BEEN ADDED AFTER CONFIRMATION FROM SALMAN BHAE

            lGreatGrandChildNode = mXmlDocument.CreateElement("Address")

            lDescendant = mXmlDocument.CreateElement("AddressLine1")
            lDescendant.InnerText = pPharmacy.Address.AddressLine1
            lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

            lDescendant = mXmlDocument.CreateElement("City")
            lDescendant.InnerText = pPharmacy.Address.City
            lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

            lDescendant = mXmlDocument.CreateElement("State")
            lDescendant.InnerText = pPharmacy.Address.State
            lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

            lDescendant = mXmlDocument.CreateElement("ZipCode")
            lDescendant.InnerText = pPharmacy.Address.ZipCode
            lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

            lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))


            ''CHANGE LOG
            'lGreatGrandChildNode = mXmlDocument.CreateElement("Email")
            'lGreatGrandChildNode.InnerText = pPharmacy.Email
            'lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))


            lGreatGrandChildNode = mXmlDocument.CreateElement("PhoneNumbers")

            For x As Integer = 0 To pPharmacy.PhoneNumbers.Length - 1

                If pPharmacy.PhoneNumbers(x) IsNot Nothing AndAlso Not pPharmacy.PhoneNumbers(x).PhoneNumber.Trim.Equals("") Then

                    lDescendant = mXmlDocument.CreateElement("Phone")

                    lGrandDescendant = mXmlDocument.CreateElement("Number")
                    lGrandDescendant.InnerText = pPharmacy.PhoneNumbers(x).PhoneNumber.Replace(" ", "")
                    lDescendant.AppendChild(lGrandDescendant.CloneNode(True))

                    lGrandDescendant = mXmlDocument.CreateElement("Qualifier")
                    lGrandDescendant.InnerText = pPharmacy.PhoneNumbers(x).PhoneNumberQualifier
                    lDescendant.AppendChild(lGrandDescendant.CloneNode(True))
                    lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

                End If

            Next

            lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))

            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))
            '''''''''''''''''''''''''''''End of Pharmacy''''''''''''''''''''''''''''

            '''''''''''''''''''''''''''''Start of Prescriber''''''''''''''''''''''''''
            lGrandChildNode = mXmlDocument.CreateElement("Prescriber")

            For x As Integer = 0 To pPrescriber.IdentificationCount - 1
                If Not String.IsNullOrEmpty(pPrescriber.Identification(x).IdentificationNumber) Then
                    lGreatGrandChildNode = mXmlDocument.CreateElement("Identification")

                    lDescendant = mXmlDocument.CreateElement("IdentificationNumber")
                    lDescendant.InnerText = pPrescriber.Identification(x).IdentificationNumber
                    lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

                    lDescendant = mXmlDocument.CreateElement("IdentificationQualifier")
                    lDescendant.InnerText = pPrescriber.Identification(x).IdentificationQualifier
                    lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

                    lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))
                End If
            Next

            

            lGreatGrandChildNode = mXmlDocument.CreateElement("Name")
            lDescendant = mXmlDocument.CreateElement("LastName")
            lDescendant.InnerText = pPrescriber.Name.LastName
            lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

            lDescendant = mXmlDocument.CreateElement("FirstName")
            lDescendant.InnerText = pPrescriber.Name.FirstName
            lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

            lDescendant = mXmlDocument.CreateElement("MiddleName")
            lDescendant.InnerText = pPrescriber.Name.MiddleName
            lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

            lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))

            'SKIP THE SPECIALITY AS IT DOES NOT EXIST IN THE DB

            If pIsPrescribingAgent Then
                lGreatGrandChildNode = mXmlDocument.CreateElement("PrescriberAgent")

                lDescendant = mXmlDocument.CreateElement("LastName")
                lDescendant.InnerText = pPrescriber.PrescriberAgent.LastName
                lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

                lDescendant = mXmlDocument.CreateElement("FirstName")
                lDescendant.InnerText = pPrescriber.PrescriberAgent.FirstName
                lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

                lDescendant = mXmlDocument.CreateElement("MiddleName")
                lDescendant.InnerText = pPrescriber.PrescriberAgent.MiddleName
                lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

                lDescendant = mXmlDocument.CreateElement("Suffix")
                lDescendant.InnerText = pPrescriber.PrescriberAgent.Suffix
                lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

                lDescendant = mXmlDocument.CreateElement("Prefix")
                lDescendant.InnerText = pPrescriber.PrescriberAgent.Prefix
                lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

                lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))
            End If



            lGreatGrandChildNode = mXmlDocument.CreateElement("Address")

            lDescendant = mXmlDocument.CreateElement("AddressLine1")
            lDescendant.InnerText = pPrescriber.Address.AddressLine1
            lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

            lDescendant = mXmlDocument.CreateElement("AddressLine2")
            lDescendant.InnerText = pPrescriber.Address.AddressLine2
            lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

            lDescendant = mXmlDocument.CreateElement("City")
            lDescendant.InnerText = pPrescriber.Address.City
            lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

            lDescendant = mXmlDocument.CreateElement("State")
            lDescendant.InnerText = pPrescriber.Address.State
            lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

            lDescendant = mXmlDocument.CreateElement("ZipCode")
            lDescendant.InnerText = pPrescriber.Address.ZipCode
            lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

            lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))




            'THIS WAS ADDED LATER
            'DATE 27TH AUGUST 2008
            'MISSING OPTIONAL FIELDS FROM THE MESSAGE

            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            lGreatGrandChildNode = mXmlDocument.CreateElement("Email")
            lGreatGrandChildNode.InnerText = pPrescriber.Email
            lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))


            lGreatGrandChildNode = mXmlDocument.CreateElement("PhoneNumbers")

            For x As Integer = 0 To pPrescriber.Phone.Length - 1

                If pPrescriber.Phone(x) IsNot Nothing AndAlso Not pPrescriber.Phone(x).PhoneNumber.Trim.Equals("") Then

                    lDescendant = mXmlDocument.CreateElement("Phone")

                    lGrandDescendant = mXmlDocument.CreateElement("Number")
                    lGrandDescendant.InnerText = pPrescriber.Phone(x).PhoneNumber.Replace(" ", "")
                    lDescendant.AppendChild(lGrandDescendant.CloneNode(True))

                    lGrandDescendant = mXmlDocument.CreateElement("Qualifier")
                    lGrandDescendant.InnerText = pPrescriber.Phone(x).PhoneNumberQualifier
                    lDescendant.AppendChild(lGrandDescendant.CloneNode(True))

                    lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

                End If

            Next

            lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))

            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''


            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

            '''''''''''''''''''''''''End of Prescriber''''''''''''''''''''''''''''''''

            '''''''''''''''''''''''''''Start of Patient'''''''''''''''''''''''''''''''
            lGrandChildNode = mXmlDocument.CreateElement("Patient")

            lGreatGrandChildNode = mXmlDocument.CreateElement("Name")

            lDescendant = mXmlDocument.CreateElement("LastName")
            lDescendant.InnerText = pPatient.Name.LastName
            lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

            lDescendant = mXmlDocument.CreateElement("FirstName")
            lDescendant.InnerText = pPatient.Name.FirstName
            lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

            lDescendant = mXmlDocument.CreateElement("Suffix")
            lDescendant.InnerText = pPatient.Name.Suffix
            lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

            lDescendant = mXmlDocument.CreateElement("Prefix")
            lDescendant.InnerText = pPatient.Name.FirstName
            lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

            lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))




            lGreatGrandChildNode = mXmlDocument.CreateElement("Gender")
            lGreatGrandChildNode.InnerText = IIf(pPatient.Gender = GenderType.M, "M", "F")
            lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))

            lGreatGrandChildNode = mXmlDocument.CreateElement("DateOfBirth")
            lGreatGrandChildNode.InnerText = pPatient.DateOfBirth
            lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))


            lGreatGrandChildNode = mXmlDocument.CreateElement("Address")

            lDescendant = mXmlDocument.CreateElement("AddressLine1")
            lDescendant.InnerText = pPatient.Address.AddressLine1
            lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

            lDescendant = mXmlDocument.CreateElement("AddressLine2")
            lDescendant.InnerText = pPatient.Address.AddressLine2
            lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

            lDescendant = mXmlDocument.CreateElement("City")
            lDescendant.InnerText = pPatient.Address.City
            lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

            lDescendant = mXmlDocument.CreateElement("State")
            lDescendant.InnerText = pPatient.Address.State
            lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

            lDescendant = mXmlDocument.CreateElement("ZipCode")
            lDescendant.InnerText = pPatient.Address.ZipCode
            lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

            lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))


            'THIS WAS ADDED LATER
            'DATE 27TH AUGUST 2008
            'MISSING OPTIONAL FIELDS FROM THE MESSAGE

            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            lGreatGrandChildNode = mXmlDocument.CreateElement("Email")
            lGreatGrandChildNode.InnerText = pPatient.Email
            lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))


            lGreatGrandChildNode = mXmlDocument.CreateElement("PhoneNumbers")

            For x As Integer = 0 To pPatient.PhoneNumbers.Length - 1

                If pPatient.PhoneNumbers(x) IsNot Nothing AndAlso Not pPatient.PhoneNumbers(x).PhoneNumber.Trim.Equals("") Then

                    lDescendant = mXmlDocument.CreateElement("Phone")

                    lGrandDescendant = mXmlDocument.CreateElement("Number")
                    lGrandDescendant.InnerText = pPatient.PhoneNumbers(x).PhoneNumber.Replace(" ", "")
                    lDescendant.AppendChild(lGrandDescendant.CloneNode(True))

                    lGrandDescendant = mXmlDocument.CreateElement("Qualifier")
                    lGrandDescendant.InnerText = pPatient.PhoneNumbers(x).PhoneNumberQualifier
                    lDescendant.AppendChild(lGrandDescendant.CloneNode(True))

                    lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

                End If

            Next

            lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))

            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

            'CHECK IF PBMID EXISTS AS IN THE CASE OF NON-AVAILABILITY OF ELIGIBILITY, THERE WOULD NOT BE ANY ID
            If Not pPatient.UniqueMemberID.Equals("") Then

                lGreatGrandChildNode = mXmlDocument.CreateElement("Identification")

                lDescendant = mXmlDocument.CreateElement("FileID") 'This is supposed to be an alias for cardholder reference number
                If pPatient.UniqueMemberID.Length > 35 Then
                    lDescendant.InnerText = pPatient.UniqueMemberID.Substring(0, 34)
                Else
                    lDescendant.InnerText = pPatient.UniqueMemberID
                End If
                lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

                lDescendant = mXmlDocument.CreateElement("IdentificationQualifier")
                lDescendant.InnerText = "2U" 'Card holder reference Qualifier
                lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

                lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))


                ''SECOND LOOP IS USED WHEN THE ID IS GREATER THEN 35 CHARACTERS 
                If pPatient.UniqueMemberID.Length > 34 Then


                    lGreatGrandChildNode = mXmlDocument.CreateElement("Identification")

                    lDescendant = mXmlDocument.CreateElement("FileID") 'This is supposed to be an alias for cardholder reference number
                    lDescendant.InnerText = pPatient.UniqueMemberID.Substring(34)
                    lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

                    lDescendant = mXmlDocument.CreateElement("IdentificationQualifier")
                    lDescendant.InnerText = "2U" 'Card holder reference Qualifier
                    lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

                    lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))

                End If

            End If

            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

            ''''''''''''''''''''''''''''End of Patient''''''''''''''''''''''''''''''''

            '''''''''''''''''''''Start of MedicationPrescribed''''''''''''''''''''''''
            lGrandChildNode = mXmlDocument.CreateElement("MedicationPrescribed")

            If pMedication.DrugDescription.Length > 35 Then

                lGreatGrandChildNode = mXmlDocument.CreateElement("DrugDescription")
                lGreatGrandChildNode.InnerText = pMedication.DrugDescription.Substring(0, 35)
                lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))

                lGreatGrandChildNode = mXmlDocument.CreateElement("ExtraDrugDescriptionOne")
                lGreatGrandChildNode.InnerText = pMedication.DrugDescription.Substring(0, 35) ' pMedication.DrugDescription.Substring(35, IIf(pMedication.DrugDescription.Length > 70, 70, pMedication.DrugDescription.Length))
                lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))


                lGreatGrandChildNode = mXmlDocument.CreateElement("ExtraDrugDescriptionTwo")
                lGreatGrandChildNode.InnerText = pMedication.DrugDescription.Substring(35, IIf(pMedication.DrugDescription.Length > 70, 35, pMedication.DrugDescription.Length - 35))
                lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))

                If pMedication.DrugDescription.Length > 70 Then
                    lGreatGrandChildNode = mXmlDocument.CreateElement("ExtraDrugDescriptionThree")
                    lGreatGrandChildNode.InnerText = pMedication.DrugDescription.Substring(70, pMedication.DrugDescription.Length - 70)
                    lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))
                End If




            Else

                lGreatGrandChildNode = mXmlDocument.CreateElement("DrugDescription")
                lGreatGrandChildNode.InnerText = pMedication.DrugDescription
                lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))

            End If

            'LOG CHANGE: ADDED DRUG CODE
            ''''''''''''''
            lGreatGrandChildNode = mXmlDocument.CreateElement("DrugCoded")

            lDescendant = mXmlDocument.CreateElement("ProductCode")
            lDescendant.InnerText = pMedication.DrugCoded.ProductCode
            lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

            lDescendant = mXmlDocument.CreateElement("ProductCodeQualifier")
            lDescendant.InnerText = pMedication.DrugCoded.ProductCodeQualifier
            lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

            lDescendant = mXmlDocument.CreateElement("DosageForm")
            lDescendant.InnerText = pMedication.DrugCoded.DosageForm
            lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

            lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))
            '''''''''''''

            lGreatGrandChildNode = mXmlDocument.CreateElement("Quantity")

            lDescendant = mXmlDocument.CreateElement("QuantityQualifier")
            lDescendant.InnerText = pMedication.Quantity.QuantityQualifier
            lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

            lDescendant = mXmlDocument.CreateElement("Value")
            lDescendant.InnerText = pMedication.Quantity.Value
            lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

            lDescendant = mXmlDocument.CreateElement("CodeListQualifier")
            lDescendant.InnerText = pMedication.Quantity.CodeListQualifier
            lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

            lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))

            lGreatGrandChildNode = mXmlDocument.CreateElement("DaysSupply")
            lGreatGrandChildNode.InnerText = pMedication.DaysSupply
            lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))


            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''CHANGE LOG'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            ''BY :  FARAZ AHMED
            ''DESCRIPTION: TO INCORPORATE A LENGTH GREATER THEN 70 IN THE FIELDS

            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            'lGreatGrandChildNode = mXmlDocument.CreateElement("Directions")
            'lGreatGrandChildNode.InnerText = pMedication.Directions 'UrlEncode(pMedication.Directions)
            'lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))

            If pMedication.Directions.Length > 70 Then

                lGreatGrandChildNode = mXmlDocument.CreateElement("Directions")
                lGreatGrandChildNode.InnerText = pMedication.Directions.Substring(0, 70)
                lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))

                lGreatGrandChildNode = mXmlDocument.CreateElement("MoreDirections")
                lGreatGrandChildNode.InnerText = pMedication.Directions.Substring(70, IIf(pMedication.Directions.Length > 140, 140, pMedication.Directions.Length - 70))
                lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))


            Else

                lGreatGrandChildNode = mXmlDocument.CreateElement("Directions")
                lGreatGrandChildNode.InnerText = pMedication.Directions
                lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))

            End If



            lGreatGrandChildNode = mXmlDocument.CreateElement("Refills")
            lDescendant = mXmlDocument.CreateElement("Qualifier")
            lDescendant.InnerText = pMedication.Refills.Qualifier
            lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

            lDescendant = mXmlDocument.CreateElement("Quantity")
            lDescendant.InnerText = pMedication.Refills.Quantity
            lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

            lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))

            lGreatGrandChildNode = mXmlDocument.CreateElement("Substitutions")
            lGreatGrandChildNode.InnerText = pMedication.Substitutions
            lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))

            lGreatGrandChildNode = mXmlDocument.CreateElement("WrittenDate")
            lDescendant = mXmlDocument.CreateElement("DateValue")
            lDescendant.InnerText = pMedication.WrittenDate.DateValue
            lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

            lDescendant = mXmlDocument.CreateElement("DateTimePeriodQualifier")
            lDescendant.InnerText = pMedication.WrittenDate.DateTimePeriodQualifier
            lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

            lDescendant = mXmlDocument.CreateElement("DateTimePeriodFormatQualifier")
            lDescendant.InnerText = pMedication.WrittenDate.DateTimePeriodFormatQualifier
            lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

            lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))

            If Not pMedication.LastFillDate.DateValue Is Nothing Then
                lGreatGrandChildNode = mXmlDocument.CreateElement("LastFillDate")
                lDescendant = mXmlDocument.CreateElement("DateValue")
                lDescendant.InnerText = pMedication.LastFillDate.DateValue
                lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

                lDescendant = mXmlDocument.CreateElement("DateTimePeriodQualifier")
                lDescendant.InnerText = pMedication.LastFillDate.DateTimePeriodQualifier
                lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

                lDescendant = mXmlDocument.CreateElement("DateTimePeriodFormatQualifier")
                lDescendant.InnerText = pMedication.LastFillDate.DateTimePeriodFormatQualifier
                lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

                lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))
            End If



            If pMedication.Note.Length > 70 Then

                lGreatGrandChildNode = mXmlDocument.CreateElement("Comments")
                lGreatGrandChildNode.InnerText = pMedication.Note.Substring(0, 70)
                lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))

                If pMedication.Note.Length > 140 Then

                    lGreatGrandChildNode = mXmlDocument.CreateElement("Comments")
                    lGreatGrandChildNode.InnerText = pMedication.Note.Substring(70, 70)
                    lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))


                    lGreatGrandChildNode = mXmlDocument.CreateElement("Comments")
                    lGreatGrandChildNode.InnerText = pMedication.Note.Substring(140, IIf(pMedication.Note.Length > 210, 70, pMedication.Note.Length - 140))
                    lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))

                Else

                    lGreatGrandChildNode = mXmlDocument.CreateElement("Comments")
                    lGreatGrandChildNode.InnerText = pMedication.Note.Substring(70, pMedication.Note.Length - 70)
                    lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))

                End If


            Else

                lGreatGrandChildNode = mXmlDocument.CreateElement("Comments")
                lGreatGrandChildNode.InnerText = pMedication.Note
                lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))

            End If


            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

            '''''''''''''''''''''''End of MedicationPrescribed''''''''''''''''''''''''

            ''''''''''''''''''''''''''''''Start of COO''''''''''''''''''''''''''''''''
            lGrandChildNode = mXmlDocument.CreateElement("COO")

            If Not pBIN.Equals("") Then

                lGreatGrandChildNode = mXmlDocument.CreateElement("PayerReferenceNumber")
                lDescendant = mXmlDocument.CreateElement("ReferenceNumber")
                lDescendant.InnerText = pBIN
                lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

                lDescendant = mXmlDocument.CreateElement("ReferenceQualifier")
                lDescendant.InnerText = "BO" 'The qualifier for BIN number
                lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

                lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))
            End If

            If Not lPBMName.Equals("") Then
                lGreatGrandChildNode = mXmlDocument.CreateElement("PayerPartyName")
                lGreatGrandChildNode.InnerText = lPBMName
                lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))
            End If

            lGreatGrandChildNode = mXmlDocument.CreateElement("CardHolderReferenceNumber")
            lGreatGrandChildNode.InnerText = pPatient.CardHolderReferenceNumber
            lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))

            lGreatGrandChildNode = mXmlDocument.CreateElement("CardHolderName")
            lDescendant = mXmlDocument.CreateElement("FirstName")
            lDescendant.InnerText = pPatient.CardHolderName.FirstName
            lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

            'lDescendant = mXmlDocument.CreateElement("LastName")
            'lDescendant.InnerText = pPatient.CardHolderName.LastName
            'lGreatGrandChildNode.AppendChild(lDescendant.CloneNode(True))

            lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))

            lGreatGrandChildNode = mXmlDocument.CreateElement("GroupReferenceNumber")
            lGreatGrandChildNode.InnerText = pPatient.GroupID
            lGrandChildNode.AppendChild(lGreatGrandChildNode.CloneNode(True))





            '''''''''''''''''''''''''''''''End of COO'''''''''''''''''''''''''''''''''
            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))
            '''''''''''''''''''''''''''''''End NewRx''''''''''''''''''''''''''''''''''

            lNode.AppendChild(lChildNode.CloneNode(True))
            ''''''''''''''''''''''''''''''''''End Body'''''''''''''''''''''''''''''''
            mXmlDocument.DocumentElement.AppendChild(lNode.CloneNode(True))



            mNameHandlerBL = New NameHandlerBL()


            lXmlDocument = mNewRx.AddMessage(pRxID, mNameHandlerBL.XmlName, "", mXmlDocument.DocumentElement.OuterXml.ToString, pConnectionString)


            '''''''''''''''''''''''''''''''Writing to File''''''''''''''''''''''''''''''
            WriteToFile(System.Configuration.ConfigurationManager.AppSettings("RxHubNewRxRequestPath") + NameHandlerBL.XmlName(pPrescriber.Identification(1).IdentificationNumber), lXmlDocument)


            '''''''''''''''''''''''''''''''Mapping to File'''''''''''''''''''''''''''''
            MapFile(System.Configuration.ConfigurationManager.AppSettings("RxHubNewRxRequestPath") + NameHandlerBL.XmlName(pPrescriber.Identification(1).IdentificationNumber), System.Configuration.ConfigurationManager.AppSettings("RxHubNewRxRequestPath") + NameHandlerBL.EDIName(pPrescriber.Identification(1).IdentificationNumber))



        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\RequestBL.CreateNewRxRequest(ByVal pRxID As String, ByVal pPharmacy As PharmacyType,ByVal pPrescriber As Prescriber, ByVal pPatient As PatientType, ByVal pMedication As Medication,ByVal pIsPrescribingAgent As Boolean, ByVal pConnectionString As String, ByVal pRxReferenceNumber As String, ByVal pBIN As String, ByVal pPBM As String) ")
        End Try

        Return lXmlDocument

    End Function




    'This accesses the databaseaccess layer directly without going to DB layer
    Private Function GetControlNumber() As String

        Dim lReturnString As String = String.Empty

        Try

            lReturnString = mDatabaseConnection.ExecuteScalarCommand(" select isNull(max(InterchangeID),0) from RequestTrace")
            lReturnString = (Long.Parse(lReturnString) + 1).ToString
            lReturnString = lReturnString.PadLeft(9, "0")

        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\RequestBL.GetControlNumber() ")
        End Try

        Return lReturnString
    End Function

    ' This function writes the data to the specified file
    Private Function WriteToFile(ByVal pPath As String, ByVal pData As String) As Integer

        Dim lFileStream As FileStream = Nothing
        Dim lStreamWriter As StreamWriter = Nothing

        Try

            lFileStream = New FileStream(pPath, FileMode.Create, FileAccess.Write)
            lStreamWriter = New StreamWriter(lFileStream)

            lStreamWriter.Write(pData)
        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\RequestBL.WriteToFile(ByVal pPath As String, ByVal pData As String) ")
        Finally
            lStreamWriter.Dispose()
            lFileStream.Dispose()
        End Try
        Return 1

    End Function

    ' This function Maps the File
    Private Function MapFile(ByVal pInputPath As String, ByVal pOutputPath As String) As Integer

        Dim lMapper As EncoreMapper = Nothing

        Try

            lMapper = New EncoreMapper
            lMapper.LoadDefinition(mECCPath)
            lMapper.MapFiles(pInputPath, pOutputPath)


        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\RequestBL.MapFile(ByVal pInputPath As String, ByVal pOutputPath As String) ")
        End Try
        Return 1
    End Function


    'This function reads data from the X12 source file 
    Private Function ReadDataFromFile(ByVal pFilePath As String) As String

        Dim X12Data As String = String.Empty
        Dim mFileStream As FileStream = Nothing
        Dim mStreamReader As StreamReader = Nothing


        Try

            mFileStream = New FileStream(pFilePath, FileMode.Open, FileAccess.Read)
            mStreamReader = New StreamReader(mFileStream)

            If pFilePath Is Nothing Then
                Return "Error"
            End If

            X12Data = "request=" & mStreamReader.ReadToEnd

        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\RequestBL.ReadDataFromFile(ByVal pFilePath As String) ")
        Finally
            mStreamReader.Close()
            mFileStream.Close()
        End Try

        Return X12Data

    End Function

    'This function reads data from the X12 source file 
    Private Function ReadDataFromFileSimple(ByVal pFilePath As String) As String

        Dim X12Data As String = String.Empty
        Dim mFileStream As FileStream = Nothing
        Dim mStreamReader As StreamReader = Nothing


        Try

            mFileStream = New FileStream(pFilePath, FileMode.Open, FileAccess.Read)
            mStreamReader = New StreamReader(mFileStream)


            If pFilePath Is Nothing Then
                Return "Error"
            End If

            X12Data = mStreamReader.ReadToEnd

        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\RequestBL.ReadDataFromFileSimple(ByVal pFilePath As String) ")
        Finally
            mStreamReader.Close()
            mFileStream.Close()
        End Try

        'WriteDataToFile(X12Data)
        Return X12Data

    End Function

    'This function writes the Recieved response to a file
    Private Function WriteDataToFile(ByVal ResponseData As String, ByVal pPath As String) As Integer

        Dim mFileStream As FileStream = Nothing
        Dim mStreamWriter As StreamWriter = Nothing

        Try
            mFileStream = New FileStream(pPath, FileMode.Create, FileAccess.Write)
            mStreamWriter = New StreamWriter(mFileStream)

            mStreamWriter.Write(ResponseData)


        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\RequestBL.WriteDataToFile(ByVal ResponseData As String, ByVal pPath As String) ")
        Finally

            mStreamWriter.Flush()
            mStreamWriter.Close()
            mFileStream.Close()

        End Try

        Return 1

    End Function

    'This function was made by Majid bhaee for god-knows-what :D
    Private Function WriteDataToFile2(ByVal ResponseData As String) As Integer

        Dim mFileStream As New FileStream("C:\Mapping\Response\" & Date.Now.ToString("HHmmss") & ".txt", FileMode.Create, FileAccess.Write)
        Dim mStreamWriter As New StreamWriter(mFileStream)

        Try

            mStreamWriter.Write(ResponseData)

        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\RequestBL.WriteDataToFile2(ByVal ResponseData As String) ")
        Finally

            mStreamWriter.Flush()
            mStreamWriter.Close()
            mFileStream.Close()

        End Try

        Return 1

    End Function


    'This function sends the data to the specified URL
    Private Function SendData(ByVal Url As String, ByVal X12Data As String) As String

        If Url = "" OrElse X12Data = "" Then
            Return "Error"
        End If


        Dim headertext As String = String.Empty
        Dim ResponseXML As String = String.Empty
        Dim str As String = "UlhIVUI6Tk9QQVNT"
        Dim hwRequest As HttpWebRequest = Nothing
        Dim hwResponse As HttpWebResponse = Nothing
        Dim myWriter As StreamWriter = Nothing
        Dim lDemo As Boolean
        Dim lStatus As String = String.Empty

        X12Data = X12Data.Replace(Chr(13), Chr(10))

        lDemo = CType(System.Configuration.ConfigurationManager.AppSettings("Demo"), Boolean)

        Try


            hwRequest = CType(HttpWebRequest.Create(Url), HttpWebRequest)
            headertext = "Authorization: Basic " + str
            hwRequest.Headers.Add(headertext)
            hwRequest.Method = "POST"
            hwRequest.ContentType = "application/x-www-form-urlencoded"

            Try


                If (lDemo = True) Then 'If this is a demo version then read the static file from the given path in the web config
                    Dim lMessageID As String
                    lStatus = ReadDataFromFile(System.Configuration.ConfigurationManager.AppSettings("DemoStatus"))

                    'Find and remove the 'REQUEST=' from the X12 string. 
                    lStatus = lStatus.Substring(IIf(lStatus.IndexOf("request=") = -1, -8, lStatus.IndexOf("request=")) + 8)

                    lMessageID = X12Data.Substring(X12Data.IndexOf("Panace"), 17)
                    lStatus = lStatus.Replace("MESSAGEID", lMessageID)
                    ResponseXML = lStatus
                Else
                    ServicePointManager.CertificatePolicy = New CertificateValidation
                    myWriter = New StreamWriter(hwRequest.GetRequestStream)
                    myWriter.Write(X12Data)
                    myWriter.Flush()
                    myWriter.Close()
                End If

            Catch e1 As Exception
                Throw New WebException(e1.Message & " : RxHubLibrary\BLL\RequestBL.SendData(ByVal Url As String, ByVal X12Data As String) ")
            End Try




            Try

                If (lDemo = False) Then
                    hwResponse = CType(hwRequest.GetResponse, HttpWebResponse)
                    Dim stResponse As StreamReader = New StreamReader(hwResponse.GetResponseStream)
                    ResponseXML = stResponse.ReadToEnd
                End If

            Catch ex As Exception
                Throw New WebException(ex.Message & " : RxHubLibrary\BLL\RequestBL.SendData(ByVal Url As String, ByVal X12Data As String) ")
            End Try



        Catch ex As WebException
            Throw ex
        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\RequestBL.SendData(ByVal Url As String, ByVal X12Data As String) ")
        End Try

        Return ResponseXML
    End Function


    'This function converts the string into specified encoding
    Private Function GetUTF(ByVal str As String) As String

        Dim bytes As Byte()
        Dim chars As String = str
        Dim utf8 As UTF8Encoding

        Try
            utf8 = New UTF8Encoding
            bytes = utf8.GetBytes(chars)
        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\RequestBL.GetUTF(ByVal str As String) ")
        End Try

        Return System.Convert.ToBase64String(bytes)
    End Function


    Private Function CheckRequestDetail(ByVal pClinicId As String, ByVal pPatientId As String) As String

        Dim lRequestFileName As String = String.Empty
        Dim lDs As DataSet = Nothing
        Dim lRequest As Request = Nothing

        Try

            lDs = New DataSet
            lRequest = New Request

            lRequest.RequestDB.ClinicCode = pClinicId
            lRequest.RequestDB.PatientId = pPatientId
            lDs = lRequest.CheckRequestDuration()

            If (lDs IsNot Nothing) AndAlso (lDs.Tables(0).Rows.Count > 0) Then
                lRequestFileName = lDs.Tables(0).Rows(0)("RequestFileName")
            Else
                lRequestFileName = ""
            End If

        Catch ex As Exception
            'Throw New Exception(ex.Message & " : RxHubLibrary\BLL\RequestBL.CheckRequestDetail(ByVal pClinicId As String, ByVal pPatientId As String) ")
            ErrorLogMethods.LogError(ex, " RxHubLibrary\BLL\RequestBL.CheckRequestDetail(ByVal pClinicId As String, ByVal pPatientId As String) ")
        End Try

        Return lRequestFileName

    End Function


    Public Function SendEligibilityRequest(ByVal pPrescriberName As sName, _
    ByVal pPrescriberIdentification As sIdentification, _
    ByVal pPatientName As sName, _
    ByVal pPatientIdentification As sIdentification, _
    ByVal pPatientAddress As sAddress, _
    ByVal pPatientGender As Char, _
    ByVal pPatientDOB As String, ByVal pPatientId As String, ByVal pClinicCode As String) As Integer


        Dim lIsWithIn24Hrs As Boolean = False
        Dim lPreviousResponseFileName As String = String.Empty
        Dim stResponse As StreamReader = Nothing
        Dim lMessageID As Integer = 0
        Dim lResponse As String = String.Empty
        Dim lRequestXml As String = String.Empty

        Try

            lRequestXml = CreateRequest(pPrescriberName, _
                                        pPrescriberIdentification, _
                                        pPatientName, _
                                        pPatientIdentification, _
                                        pPatientAddress, _
                                        pPatientGender, _
                                        pPatientDOB, _
                                        lMessageID)

            lPreviousResponseFileName = CheckRequestDetail(pClinicCode, pPatientId)






            ''''''''''''''''''''''''''''''''''''''''''''''''Change Log ''''''''''''''''''''''''''''''''''''''''''''''''''''
            ''Name:       : Faraz Ahmed
            ''Description : The variable in the web.config has been changed from "UnderConstruction" to "SendEligibility"
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''




            If System.Configuration.ConfigurationManager.AppSettings("SendEligibility").Equals("true") Then

                If lPreviousResponseFileName <> "" Then
                    stResponse = New StreamReader(System.Configuration.ConfigurationManager.AppSettings("RxHubEligibilityResponsePath") + lPreviousResponseFileName)
                    Try
                        lResponse = stResponse.ReadToEnd()
                    Catch ex As Exception
                        Throw New Exception(ex.Message & " : RxHubLibrary\BLL\RequestBL.SendEligibilityRequest(ByVal pPrescriberName As sName,ByVal pPrescriberIdentification As sIdentification, ByVal pPatientName As sName,ByVal pPatientIdentification As sIdentification,ByVal pPatientAddress As sAddress,ByVal pPatientGender As Char,ByVal pPatientDOB As String, ByVal pPatientId As String, ByVal pClinicCode As String) ")
                    Finally
                        stResponse.Close()
                    End Try

                Else
                    'THIS WOULD ONLY ADD THE REQUEST TO THE TABLE REQUESTTRACE IN RXHUB
                    InsertRequest(lRequestXml, pPatientId, pClinicCode, NameHandlerBL.EDIName(pPrescriberIdentification.IdentificationNumber), ReadDataFromFileSimple(System.Configuration.ConfigurationManager.AppSettings("RxHubEligibilityRequestPath") + NameHandlerBL.EDIName(pPrescriberIdentification.IdentificationNumber)), pPrescriberIdentification.IdentificationNumber, "", ActionCode.EligibilityRequest, "")

                   ' lResponse = sendTransaction(System.Configuration.ConfigurationManager.AppSettings("RxHubURI"), _
                   '   ReadDataFromFileSimple(System.Configuration.ConfigurationManager.AppSettings("RxHubEligibilityRequestPath") + _
                   ' NameHandlerBL.EDIName(pPrescriberIdentification.IdentificationNumber)))

                    lResponse = SendData(System.Configuration.ConfigurationManager.AppSettings("RxHubURI"), _
                    "request=" & UrlEncode(ReadDataFromFileSimple(System.Configuration.ConfigurationManager.AppSettings("RxHubEligibilityRequestPath") + _
                    NameHandlerBL.EDIName(pPrescriberIdentification.IdentificationNumber))))
                End If

                WriteDataToFile(lResponse, System.Configuration.ConfigurationManager.AppSettings("RxHubEligibilityResponsePath") + NameHandlerBL.EDIName(pPrescriberIdentification.IdentificationNumber))
                'DESPITE ITS NAME, THIS WOULD ONLY ADD THE RESPONSE TO THE TABLE REQUESTTRACE IN RXHUB
                InsertRequest("", pPatientId, pClinicCode, NameHandlerBL.EDIName(pPrescriberIdentification.IdentificationNumber), lResponse, pPrescriberIdentification.IdentificationNumber, lMessageID, ActionCode.EligibilityResponse, "")
            End If

            Return lMessageID

        Catch ex As Exception            
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\RequestBL.SendEligibilityRequest(ByVal pPrescriberName As sName,ByVal pPrescriberIdentification As sIdentification, ByVal pPatientName As sName,ByVal pPatientIdentification As sIdentification,ByVal pPatientAddress As sAddress,ByVal pPatientGender As Char,ByVal pPatientDOB As String, ByVal pPatientId As String, ByVal pClinicCode As String) ")
        End Try

    End Function

    'This function sends the medication request
    Public Function SendMedicationRequest(ByVal pPrescriber As Prescriber, ByVal pPatient As PatientType, _
    ByVal pResend As Boolean, Optional ByVal pISA13 As String = "") _
    As Integer

        Dim lMedicationHistoryDB As MedicationHistoryDB = Nothing
        Dim lMessageID As Integer = 0

        Try

            lMedicationHistoryDB = New MedicationHistoryDB

            'This NameHandler is used to communicate the name of the 
            'two files created(xml and edi) to the Response Object
            'Please access this object through the property and pass it to the
            'Response object
            mNameHandlerBL = New NameHandlerBL()



            ''As there is no PBM name sent, we cannot proceed further
            If MoreHistory Is Nothing Then
                Return 0
            End If



            For x As Integer = 0 To MoreHistory.Length - 1

                If (pResend = False Or (pResend And MoreHistory(x).MoreDrugHistoryExists)) AndAlso (MoreHistory(x).FillData Or (Not (MoreHistory(x).MailOrderPrescription = False And MoreHistory(x).PharmacyBenifit = False))) Then

                    Dim lRequestEDI As String

                    lRequestEDI = CreateMedicationHistoryRequest(MoreHistory(x), pPrescriber, pPatient, pResend, lMessageID, pISA13)

                    'NOTE:ADD A LOOP HERE TO FIND THE CORRECT IDENTIFIER USING THE PRESCRIBER ID QUALIFIER
                    lMedicationHistoryDB.InsertRequest("", 0, ActionCode.MedicationHistoryRequest, pPrescriber.Identification(0).IdentificationNumber, pPrescriber.Clinic.ClinicCode, pPatient.PatientID, NameHandlerBL.EDIName(RxHubUtility.CleanString(MoreHistory(x).CardHolderReferenceNumber)), ReadDataFromFile(System.Configuration.ConfigurationManager.AppSettings("RxHubHistoryRequestPath") + NameHandlerBL.EDIName(RxHubUtility.CleanString(MoreHistory(x).CardHolderReferenceNumber)).Replace("request=", "")), lMessageID)


                    'IF IT IS NOT UNDER CONSTRUCTION THEN SEND MESSAGE AS USUAL
                    If System.Configuration.ConfigurationManager.AppSettings("UnderConstruction").Equals("false") Then
                        Dim lResponse As String = SendData(System.Configuration.ConfigurationManager.AppSettings("RxHubURI"), "request=" & UrlEncode(ReadDataFromFileSimple(System.Configuration.ConfigurationManager.AppSettings("RxHubHistoryRequestPath") + NameHandlerBL.EDIName(RxHubUtility.CleanString(MoreHistory(x).CardHolderReferenceNumber)))))
                        'Dim lResponse As String = sendTransaction(System.Configuration.ConfigurationManager.AppSettings("RxHubURI"), ReadDataFromFileSimple(System.Configuration.ConfigurationManager.AppSettings("RxHubHistoryRequestPath") + NameHandlerBL.EDIName(RxHubUtility.CleanString(MoreHistory(x).CardHolderReferenceNumber))))
                        lResponse.Replace("request=", "")
                        WriteDataToFile(lResponse, System.Configuration.ConfigurationManager.AppSettings("RxHubHistoryResponsePath") + NameHandlerBL.EDIName(RxHubUtility.CleanString(MoreHistory(x).CardHolderReferenceNumber)))
                        'ADD THE RESPONSE TO THE DATABASE
                        lMedicationHistoryDB.InsertRequest("", lMessageID, ActionCode.MedicationHistoryResponse, pPrescriber.Identification(0).IdentificationNumber, pPrescriber.Clinic.ClinicCode, pPatient.PatientID, NameHandlerBL.EDIName(RxHubUtility.CleanString(MoreHistory(x).CardHolderReferenceNumber)), lResponse, lMessageID)
                    End If
                End If


            Next


        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\RequestBL.SendMedicationRequest(ByVal pPrescriber As Prescriber, ByVal pPatient As PatientType,ByVal pResend As Boolean) ")
        End Try

        Return lMessageID
    End Function


    Public Shared Function sendTransaction(urlString As String, transaction As String) As String
        Try
            Dim encoding__1 As New ASCIIEncoding()
            Dim data As Byte() = encoding__1.GetBytes(transaction)
            Dim req As HttpWebRequest = DirectCast(WebRequest.Create(urlString), HttpWebRequest)
            req.Method = "POST"
            req.ContentLength = data.Length
            Dim newStream As Stream = req.GetRequestStream()
            newStream.Write(data, 0, data.Length)
            newStream.Close()
            Dim res As HttpWebResponse = DirectCast(req.GetResponse(), HttpWebResponse)
            Dim receiveStream As Stream = res.GetResponseStream()
            Dim readStream As New StreamReader(receiveStream, Encoding.UTF8)
            Dim response As String = readStream.ReadToEnd()
            res.Close()
            readStream.Close()
            Return response
        Catch ex As Exception
            Throw ex
        End Try
    End Function


    'This function sends the ProviderUpdate request
    'Public Function SendProviderUpdateRequest(ByVal pMessageID As String, _
    'ByVal pPrescriber As Prescriber, ByVal pSupervisor As Prescriber) As Integer

    Public Function SendProviderUpdateRequest( _
    ByVal pMessageID As String, _
    ByVal pPrescriber As Prescriber, _
    ByVal pActionCode As ActionCode, Optional ByVal pPrescriberID As String = "", Optional ByVal pRxHubConnection As Connection = Nothing) As String


        Dim lResponse As String = String.Empty
        Dim lRequestXml As String = String.Empty
        Dim lRequestEDI As String = String.Empty
        Dim lRequestEDIFileName As String = String.Empty
        Dim lResponseMessageID As String = String.Empty
        Dim lResponseEDIFileName As String = String.Empty
        SendProviderUpdateRequest = String.Empty

        pPrescriberID = "DOC-" & pPrescriber.Clinic.ClinicCode & "-" & pPrescriberID.PadLeft(5, "0")


        Try
            
            lRequestXml = CreateProviderUpdateRequest(pMessageID, pPrescriber, pActionCode)
            lRequestEDIFileName = System.Configuration.ConfigurationManager.AppSettings("ProviderUpdateRequestPath") + NameHandlerBL.EDIName
            lRequestEDI = ReadDataFromFileSimple(System.Configuration.ConfigurationManager.AppSettings("ProviderUpdateRequestPath") + NameHandlerBL.EDIName)


            ''Tracelogging function of request starts here...........
            InsertRequest(lRequestXml, 0, pPrescriber.Clinic.ClinicCode, lRequestEDIFileName, lRequestEDI, pPrescriberID, "", pActionCode, pMessageID, pRxHubConnection)


            If System.Configuration.ConfigurationManager.AppSettings("UnderConstruction").Equals("false") Then
                lResponse = SendData(System.Configuration.ConfigurationManager.AppSettings("RxHubURI"), "request=" & UrlEncode(ReadDataFromFileSimple(System.Configuration.ConfigurationManager.AppSettings("ProviderUpdateRequestPath") + NameHandlerBL.EDIName)))
                SendProviderUpdateRequest = lResponse
                WriteDataToFile(lResponse, System.Configuration.ConfigurationManager.AppSettings("ProviderUpdateResponsePath") + NameHandlerBL.EDIName)

                ''getting path of EDIFIleName of Response 
                lResponseEDIFileName = System.Configuration.ConfigurationManager.AppSettings("ProviderUpdateRequestPath") + NameHandlerBL.EDIName

                ''Tracelogging function of response starts here........... 
                Select Case pActionCode
                    Case 1
                        lResponseMessageID = IIf(lResponse.Length > 30, lResponse.Substring(21, 8), "")
                        InsertRequest("", 0, pPrescriber.Clinic.ClinicCode, lResponseEDIFileName, lResponse, pPrescriberID, pMessageID, ActionCode.AddPrescriberResponse, lResponseMessageID, pRxHubConnection)
                    Case 2
                        lResponseMessageID = IIf(lResponse.Length > 30, lResponse.Substring(21, 8), "")
                        InsertRequest("", 0, pPrescriber.Clinic.ClinicCode, lResponseEDIFileName, lResponse, pPrescriberID, pMessageID, ActionCode.UpdatePrescriberResponse, lResponseMessageID, pRxHubConnection)
                    Case 3
                        lResponseMessageID = IIf(lResponse.Length > 30, lResponse.Substring(21, 8), "")
                        InsertRequest("", 0, pPrescriber.Clinic.ClinicCode, lResponseEDIFileName, lResponse, pPrescriberID, pMessageID, ActionCode.InactivePrescriberResponse, lResponseMessageID, pRxHubConnection)

                End Select

            End If

        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\RequestBL.SendProviderUpdateRequest(ByVal pMessageID As String,ByVal pPrescriber As Prescriber,ByVal pActionCode As ActionCode, Optional ByVal pPrescriberID As String = "", Optional ByVal pRxHubConnection As Connection = Nothing) ")
        End Try

    End Function


    'This function sends the NewRx request
    Public Function SendNewRxRequest( _
       ByVal pRxID As String, _
       ByVal pPharmacy As PharmacyType, _
       ByVal pPrescriber As Prescriber, _
       ByVal pPatient As PatientType, _
       ByVal pMedication As Medication, _
       ByVal pConnectionString As String, _
       ByVal pIsPrescribingAgent As Boolean, _
       ByVal pRxReferenceNumber As String, _
       ByVal pBIN As String, _
       ByVal pPBM As String) _
       As Integer

        Dim lRequestXml As String = String.Empty


        Dim lDemo As Boolean = CType(System.Configuration.ConfigurationManager.AppSettings("Demo"), Boolean)


        Try



            lRequestXml = CreateNewRxRequest(pRxID, _
               pPharmacy, _
               pPrescriber, _
               pPatient, _
               pMedication, _
               pIsPrescribingAgent, _
               pConnectionString, _
               pRxReferenceNumber, _
               pBIN, _
               pPBM)




            If System.Configuration.ConfigurationManager.AppSettings("UnderConstruction").Equals("false") Then

                'CHANGED THIS TO URLENCODE TO INCLUDE THE AMPERSAND
                Dim lString As String = UrlEncode(ReadDataFromFileSimple(System.Configuration.ConfigurationManager.AppSettings("RxHubNewRxRequestPath") + NameHandlerBL.EDIName(pPrescriber.Identification(1).IdentificationNumber))) '.Replace("%", "%25")

                Dim lResponse As String = SendData(System.Configuration.ConfigurationManager.AppSettings("RxHubURI"), "request=" & lString)
                WriteDataToFile(lResponse, System.Configuration.ConfigurationManager.AppSettings("RxHubNewRxResponsePath") + NameHandlerBL.EDIName(pPrescriber.Identification(1).IdentificationNumber))


            Else
                Dim lNewRx As New NewRx("0010")
                lNewRx.SaveFailureStatus(lRequestXml, pConnectionString)
                'Add the code to enter the damn thing before it executes
            End If


        Catch ex As WebException
            Throw ex
        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\RequestBL.SendNewRxRequest(ByVal pRxID As String,ByVal pPharmacy As PharmacyType,ByVal pPrescriber As Prescriber,ByVal pPatient As PatientType,ByVal pMedication As Medication, ByVal pConnectionString As String,ByVal pIsPrescribingAgent As Boolean,ByVal pRxReferenceNumber As String,ByVal pBIN As String,ByVal pPBM As String) ")
        End Try
    End Function

    'This function stores the Request in the database for future reference
    Public Function InsertRequest(ByVal pParamXml As String, _
                                   ByVal pPatientId As Integer, _
                                   ByVal pClinicCode As String, _
                                   ByVal pFileName As String, _
                                   ByVal pEDI As String, _
                                   ByVal pPrescriberID As String, _
                                   ByVal pRelatesToMessageID As String, _
                                   ByVal pMessageType As Integer, ByVal pMessageID As String, Optional ByVal pRxHubConnection As Connection = Nothing) As Integer


        Dim lRequest As Request = Nothing

        Try

            If pRxHubConnection Is Nothing Then
                lRequest = New Request()
            Else
                lRequest = New Request(pRxHubConnection)
            End If


            With lRequest.RequestDB

                .RequestXml = pParamXml
                .ClinicCode = pClinicCode
                .FileName = pFileName
                .PatientId = pPatientId
                .EDI = pEDI
                .PrescriberID = pPrescriberID
                .RelatesToMessageID = pRelatesToMessageID
                .MessageType = pMessageType
                .MessageID = pMessageID

            End With



            lRequest.InsertRequest()

        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\RequestBL.InsertRequest(ByVal pParamXml As String,ByVal pPatientId As Integer,ByVal pClinicCode As String,ByVal pFileName As String,ByVal pEDI As String,ByVal pPrescriberID As String,ByVal pRelatesToMessageID As String,ByVal pMessageType As Integer, ByVal pMessageID As String, Optional ByVal pRxHubConnection As Connection = Nothing) ")
        End Try
    End Function

    'This function gets the refill request 
    Public Function GetRefillRequest( _
    ByVal lRequestText As String, _
    ByVal pNameHandler As NameHandlerBL, _
    ByVal pClinicCode As String, _
    ByVal pNCPDPID As String, _
    ByVal pMessageID As String) As RefillBL

        Dim lAcknowledgement As String = String.Empty
        Dim lRefillRequest As String = String.Empty
        Dim lErrorDescription As String = String.Empty
        Dim lRefillBL As RefillBL = Nothing
        Dim lRefill As Refill = Nothing




        Try

            lRefill = New Refill

            WriteDataToFile(lRequestText, _
                        System.Configuration.ConfigurationManager.AppSettings("RxHubRefillRequestPath") & pNameHandler.EDIName(pMessageID & pNCPDPID))
            lErrorDescription = MapRefillFile(System.Configuration.ConfigurationManager.AppSettings("RxHubRefillRequestPath") & pNameHandler.EDIName(pMessageID & pNCPDPID), System.Configuration.ConfigurationManager.AppSettings("RxHubRefillRequestPath") & pNameHandler.XmlName(pMessageID & pNCPDPID))
            lRefillBL = New RefillBL(System.Configuration.ConfigurationManager.AppSettings("RxHubRefillRequestPath") & pNameHandler.XmlName(pMessageID & pNCPDPID))
            lRefillRequest = lRefillBL.GetRefillRequest()




        Catch ex As Exception


            Try
                ParseFile(System.Configuration.ConfigurationManager.AppSettings("RxHubRefillRequestPath") & pNameHandler.EDIName(pMessageID & pNCPDPID), lRefillBL)
                lRefillBL.ErrorExists = True
                lRefillBL.ErrorDescription = lErrorDescription
                Throw New Exception(ex.Message & " : RxHubLibrary\BLL\RequestBL.GetRefillRequest(ByVal lRequestText As String,ByVal pNameHandler As NameHandlerBL,ByVal pClinicCode As String,ByVal pNCPDPID As String,ByVal pMessageID As String) ")
            Catch e As Exception
                Throw New Exception(ex.Message & " : RxHubLibrary\BLL\RequestBL.GetRefillRequest(ByVal lRequestText As String,ByVal pNameHandler As NameHandlerBL,ByVal pClinicCode As String,ByVal pNCPDPID As String,ByVal pMessageID As String) ")
            End Try



        Finally
            If lRefillBL.DuplicateKeys = False Then
                lRefill.RefillDB = lRefillBL
                lRefill.AddMessage(pNameHandler.XmlName, "", pClinicCode, lRefillRequest, 6, "I")
                lRefillBL = lRefill.RefillDB
            End If
        End Try


        Return lRefillBL
    End Function



    Private Function ParseFile(ByVal pPath As String, ByRef pRefillBL As RefillBL) As String


        Dim lFileStream As FileStream = Nothing
        Dim lStreamReader As StreamReader = Nothing

        Dim lMessage As String = String.Empty        
        Dim lReferenceNumber As String = String.Empty
        Dim lMessageID As String = String.Empty
        Dim lPrescriberOrderNumber As String = String.Empty ' This is the number that is echoed back in the UIH

        Dim lMessageSegments() As String

        Dim lDataElementSeperator As Char = ""
        Dim lSegmentSeperator As Char = ""



        Try

            lFileStream = New FileStream(pPath, FileMode.Open)
            lStreamReader = New StreamReader(lFileStream)

            lMessage = lStreamReader.ReadToEnd

            lDataElementSeperator = lMessage.Substring(3, 1)
            lSegmentSeperator = lMessage.Substring(4, 1)


            lReferenceNumber = lMessage.Remove(0, lMessage.IndexOf("REFREQ") + 7)
            lReferenceNumber = lReferenceNumber.Remove(lReferenceNumber.IndexOf(lSegmentSeperator), lReferenceNumber.Length - lReferenceNumber.IndexOf(lSegmentSeperator))

            pRefillBL.RxReferenceNumber = lReferenceNumber



            lMessage = lMessage.Substring(lMessage.IndexOf("UIB"), lMessage.IndexOf("UIH") - lMessage.IndexOf("UIB"))
            lMessage = lMessage.Substring(12, lMessage.Length - 12)


            For x As Integer = 0 To lMessage.Length - 1
                If lMessage(x).Equals(lSegmentSeperator) Then
                    Exit For
                ElseIf lMessage(x).Equals(lDataElementSeperator) Then
                    Dim y As Int16
                    y = x + 1
                    While Not lMessage(y).Equals(lSegmentSeperator)
                        lPrescriberOrderNumber = lPrescriberOrderNumber & lMessage(y)
                        y += 1
                    End While
                    Exit For
                Else
                    lMessageID = lMessageID & lMessage(x)
                End If

            Next

            lMessage = lMessage.Remove(0, lMessage.IndexOf(lSegmentSeperator))

            lMessageSegments = lMessage.Split(lSegmentSeperator)

            pRefillBL.PrescriberOrderNumber = lPrescriberOrderNumber
            pRefillBL.MessageID = lMessageID
            pRefillBL.Clinic.ClinicCode = (lMessageSegments(3).Split(lDataElementSeperator))(0).ToString
            pRefillBL.PharmacyParticipantID = (lMessageSegments(3).Split(lDataElementSeperator))(3).ToString
            pRefillBL.PrescriberIdentification.IdentificationNumber = (lMessageSegments(4).Split(lDataElementSeperator))(0).ToString



        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\RequestBL.ParseFile(ByVal pPath As String, ByRef pRefillBL As RefillBL) ")
        End Try
        Return lMessage
    End Function


    Public Function SendAcknowledgement(ByVal pNameHandler As NameHandlerBL, _
    ByVal pMessageID As String, ByVal pDoctorName As String, _
    ByVal pPharmacyID As String, ByVal pPharmacyParticipantID As String, ByVal pPrescriberID As String, _
    ByVal pPrescriberOrderNumber As String, ByVal pMessageCode As String, ByVal pDuplicateKeys As Boolean, _
    ByVal pErrorExists As Boolean, ByVal pErrorDescription As String) As String

        Dim lAcknowledgement As String = String.Empty


        Try
            If pErrorExists Then 'Not File.Exists(System.Configuration.ConfigurationManager.AppSettings("RxHubRefillRequestPath") & pNameHandler.XmlName(pDoctorName)) Then
                'That means the file has not been created due to an error                
                lAcknowledgement = CreateAcknowledgement(False, pMessageID, pPrescriberID, pPharmacyID, pPharmacyParticipantID, pPrescriberOrderNumber, pMessageCode, pDuplicateKeys, pErrorDescription) 'lRefillBL.MessageID)
            ElseIf pDuplicateKeys = True Then
                lAcknowledgement = CreateAcknowledgement(False, pMessageID, pPrescriberID, pPharmacyID, pPharmacyParticipantID, pPrescriberOrderNumber, pMessageCode, pDuplicateKeys, "") 'lRefillBL.MessageID)
            Else
                lAcknowledgement = CreateAcknowledgement(True, pMessageID, pPrescriberID, pPharmacyID, pPharmacyParticipantID, pPrescriberOrderNumber, pMessageCode, pDuplicateKeys, "") 'lRefillBL.MessageID)
            End If

            WriteDataToFile(lAcknowledgement, System.Configuration.ConfigurationManager.AppSettings("RxHubRefillStatusPath") & pNameHandler.XmlName(pDoctorName))
            mECCPath = System.Configuration.ConfigurationManager.AppSettings("RxHubRefillECCPath") & "Status.ecc" 'TODO: hard-conding
            MapFile(System.Configuration.ConfigurationManager.AppSettings("RxHubRefillStatusPath") & pNameHandler.XmlName(pDoctorName), System.Configuration.ConfigurationManager.AppSettings("RxHubRefillStatusPath") & pNameHandler.EDIName(pDoctorName))


        Catch ex As Exception
            lAcknowledgement = CreateAcknowledgement(False, pMessageID, pPrescriberID, pPharmacyID, pPharmacyParticipantID, pPrescriberOrderNumber, pMessageCode, False, "")
            WriteDataToFile(lAcknowledgement, System.Configuration.ConfigurationManager.AppSettings("RxHubRefillStatusPath") & pNameHandler.XmlName(pDoctorName))
            mECCPath = System.Configuration.ConfigurationManager.AppSettings("RxHubRefillECCPath") & "Status.ecc" 'TODO: hard-conding
            MapFile(System.Configuration.ConfigurationManager.AppSettings("RxHubRefillStatusPath") & pNameHandler.XmlName(pDoctorName), System.Configuration.ConfigurationManager.AppSettings("RxHubRefillStatusPath") & pNameHandler.EDIName(pDoctorName))
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\RequestBL.SendAcknowledgement(ByVal pNameHandler As NameHandlerBL,ByVal pMessageID As String, ByVal pDoctorName As String,ByVal pPharmacyID As String, ByVal pPharmacyParticipantID As String, ByVal pPrescriberID As String,ByVal pPrescriberOrderNumber As String, ByVal pMessageCode As String, ByVal pDuplicateKeys As Boolean,ByVal pErrorExists As Boolean, ByVal pErrorDescription As String) ")
        End Try

        Return lAcknowledgement

    End Function


    Public Function GetMessageID() As String

        Dim lDs As DataSet = Nothing
        Dim lConnection As Connection = Nothing

        Dim lMessageCode As String = String.Empty
        Dim lQuery As String = String.Empty
        Dim lMsgId As String = String.Empty

        Dim lMessageNo As Integer = 0
        



        Try

            lConnection = New Connection()

            lQuery = "Select AdminMessageID+1 As MsgId, Prefix from NumSeries "

            If lConnection.IsTransactionAlive Then
                lDs = lConnection.ExecuteTransactionQuery(lQuery)
            Else
                lDs = lConnection.ExecuteQuery(lQuery)
            End If


            If lDs.Tables.Count > 0 Then
                lMsgId = CType(lDs.Tables(0).Rows(0)("Prefix"), String) & "-" _
                       & CType(lDs.Tables(0).Rows(0)("MsgId"), String).PadLeft(10, "0")

                lMessageNo = lDs.Tables(0).Rows(0)("MsgId")
            End If

            lQuery = "Update NumSeries Set " _
                   & "AdminMessageID = " & lMessageNo & " "

            If lConnection.IsTransactionAlive Then
                lConnection.ExecuteTransactionCommand(lQuery)
            Else
                lConnection.ExecuteCommand(lQuery)
            End If

        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\RequestBL.GetMessageID() ")
        End Try

        GetMessageID = lMsgId

    End Function
    'This function creates an acknowledgement
    Public Function CreateAcknowledgement(ByVal pStatus As Boolean, _
    ByVal pRelatesToMessageID As String, ByVal pPrescriberID As String, _
    ByVal pPharmacyID As String, ByVal pPharmacyParticipantID As String, _
    ByVal pPrescriberOrderNumber As String, ByVal pMessageCode As String, _
    ByVal pDuplicateKeys As Boolean, _
    ByVal pErrorDescription As String) As String



        Dim lRefill As Refill = Nothing

        Dim lXmlDocument As XmlDocument = Nothing
        Dim lNode As XmlElement = Nothing
        Dim lChildNode As XmlElement = Nothing
        Dim lGrandChildNode As XmlElement = Nothing




        Try


            lXmlDocument = New XmlDocument
            lRefill = New Refill

            lXmlDocument.LoadXml("<Message xmlns=""http://www.RxHub.com/StatusMessage.xsd""></Message>")
            lNode = lXmlDocument.CreateElement("Header")

            lChildNode = lXmlDocument.CreateElement("To")
            lChildNode.InnerText = pPharmacyID
            lNode.AppendChild(lChildNode.CloneNode(True))

            lChildNode = lXmlDocument.CreateElement("From")
            lChildNode.InnerText = pPrescriberID
            lNode.AppendChild(lChildNode.CloneNode(True))

            lChildNode = lXmlDocument.CreateElement("Password")
            lChildNode.InnerText = "47T1T0B79R"
            lNode.AppendChild(lChildNode.CloneNode(True))

            lChildNode = lXmlDocument.CreateElement("MessageID")
            lChildNode.InnerText = "0"
            lNode.AppendChild(lChildNode.CloneNode(True))


            lChildNode = lXmlDocument.CreateElement("RelatesToMessageID")
            lChildNode.InnerText = pRelatesToMessageID
            lNode.AppendChild(lChildNode.CloneNode(True))

            lChildNode = lXmlDocument.CreateElement("SentTime")
            lChildNode.InnerText = Date.Now.ToString("yyyy-MM-ddTHHmmssZ")
            lNode.AppendChild(lChildNode.CloneNode(True))

            lChildNode = lXmlDocument.CreateElement("TraceNumber")
            lChildNode.InnerText = GetMessageID()
            lNode.AppendChild(lChildNode.CloneNode(True))

            lChildNode = lXmlDocument.CreateElement("MessageFunction")
            If pStatus = True Then
                lChildNode.InnerText = "STATUS"
            Else
                lChildNode.InnerText = "ERROR"
            End If
            lNode.AppendChild(lChildNode.CloneNode(True))

            lXmlDocument.DocumentElement.AppendChild(lNode.CloneNode(True))

            lNode = lXmlDocument.CreateElement("Body")

            lChildNode = lXmlDocument.CreateElement("Status")

            lGrandChildNode = lXmlDocument.CreateElement("Code")
            If pStatus = True Then
                lGrandChildNode.InnerText = "010" ' Success
            Else
                lGrandChildNode.InnerText = "900" ' Failure
            End If
            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

            lGrandChildNode = lXmlDocument.CreateElement("DescriptionCode")
            If pStatus = True Then
                lGrandChildNode.InnerText = "" ' Success
            ElseIf pDuplicateKeys = True Then
                lGrandChildNode.InnerText = "220" ' Failure
            Else
                lGrandChildNode.InnerText = "007"
            End If
            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

            lGrandChildNode = lXmlDocument.CreateElement("Description")
            If pStatus = True Then
                lGrandChildNode.InnerText = "Transaction Successful - Received By Ultimate Receiver" ' Success
            ElseIf pDuplicateKeys = True Then
                lGrandChildNode.InnerText = "Duplicate Message ID " ' Failure
            Else
                lGrandChildNode.InnerText = pErrorDescription.Substring(0, IIf(pErrorDescription.Length > 69, 70, pErrorDescription.Length)) '"Internal Error" ' Failure
            End If
            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

            lGrandChildNode = lXmlDocument.CreateElement("PharmacyID")
            lGrandChildNode.InnerText = pPharmacyParticipantID
            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))

            lGrandChildNode = lXmlDocument.CreateElement("PrescriberOrderNumber")
            lGrandChildNode.InnerText = pPrescriberOrderNumber
            lChildNode.AppendChild(lGrandChildNode.CloneNode(True))


            lNode.AppendChild(lChildNode.CloneNode(True))

            lXmlDocument.DocumentElement.AppendChild(lNode.CloneNode(True))

            If Not pDuplicateKeys = True Then
                lRefill.SaveStatus(lXmlDocument.OuterXml.ToString, pPrescriberOrderNumber, pMessageCode, 6, "I", "O")
            End If


        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\RequestBL.CreateAcknowledgement(ByVal pStatus As Boolean,ByVal pRelatesToMessageID As String, ByVal pPrescriberID As String,ByVal pPharmacyID As String, ByVal pPharmacyParticipantID As String,ByVal pPrescriberOrderNumber As String, ByVal pMessageCode As String,ByVal pDuplicateKeys As Boolean,ByVal pErrorDescription As String) ")
        End Try

        Return lXmlDocument.OuterXml
    End Function


    'This function accepts the final status message from the RxHub
    Public Function AcceptAcknowledgement(ByVal pStatusMessage As String, ByVal pClinicCode As String) As String

        'IO Fields 
        Dim lFileStream As FileStream = Nothing
        Dim lStreamReader As StreamReader = Nothing

        'Misc Fields
        Dim lXmlDocument As XmlDataDocument = Nothing
        Dim lRefillDB As Refill = Nothing

        Dim lSegmentSeperator As Char = ""
        Dim lMessageID As String = String.Empty


        Try

            lXmlDocument = New XmlDataDocument
            lRefillDB = New Refill

            lSegmentSeperator = pStatusMessage.Substring(4, 1)
            lMessageID = pStatusMessage.Substring(21, pStatusMessage.Substring(21).IndexOf(lSegmentSeperator))

            WriteToFile(System.Configuration.ConfigurationManager.AppSettings("RxHubRefillStatusPath") & mNameHandlerBL.EDIName(lMessageID), pStatusMessage)
            MapFile(System.Configuration.ConfigurationManager.AppSettings("RxHubRefillStatusPath") & mNameHandlerBL.EDIName(lMessageID), System.Configuration.ConfigurationManager.AppSettings("RxHubRefillStatusPath") & mNameHandlerBL.XmlName(lMessageID))

            lFileStream = New FileStream(System.Configuration.ConfigurationManager.AppSettings("RxHubRefillStatusPath") & mNameHandlerBL.XmlName(lMessageID), FileMode.Open)
            lStreamReader = New StreamReader(lFileStream)


            AcceptAcknowledgement = lRefillDB.SaveFinalStatus(lStreamReader.ReadToEnd, lRefillDB.GetConnectionString(pClinicCode))


        Catch ex As Exception
            AcceptAcknowledgement = "Mapping fault"
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\RequestBL.AcceptAcknowledgement(ByVal pStatusMessage As String, ByVal pClinicCode As String) ")
        End Try

    End Function


    Private Function MapRefillFile(ByVal pInputPath As String, ByVal pOutputPath As String) As String

        Dim lErrors As MAPPERLib.EncoreMapErrors = Nothing
        Dim lMapper As EncoreMapper = Nothing
        Dim lErrorMessage As String = ""


        Try

            lMapper = New EncoreMapper
            lMapper.LoadDefinition(mECCPath)
            lMapper.MapFiles(pInputPath, pOutputPath)


        Catch ex As Exception


            If File.Exists(pOutputPath) Then
                File.Delete(pOutputPath)
            End If

            lErrors = lMapper.GetErrors


            lErrorMessage = lErrors.Item(0).Description
            lErrorMessage = lErrorMessage & " - " & (lErrors.Item(0).Source)
            Throw New Exception(ex.Message & "[" & lErrorMessage & "] : RxHubLibrary\BLL\RequestBL.MapRefillFile(ByVal pInputPath As String, ByVal pOutputPath As String) ")
            'HAVE ADDED THE ERRORS FROM THE MAPPER

        End Try

        Return lErrorMessage
    End Function


    Private Sub TraceLogging(ByVal pMessageID As String, ByVal pMessageType As String, ByVal pPrescriberID As String, ByVal pRequestXML As String, ByVal pRequestEDI As String, ByVal pRelatestoMessageID As String)

        Dim lTraceLogging As TraceLogging.TraceLogging = Nothing
        Dim lTraceLoggingDB As TraceLogging.TraceLoggingDB = Nothing


        Try

            lTraceLogging = New TraceLogging.TraceLogging(ConfigurationManager.ConnectionStrings("ConnectionString").ToString())
            lTraceLoggingDB = New TraceLogging.TraceLoggingDB()

            With lTraceLoggingDB
                .MessageID = pMessageID
                .MessageType = pMessageType
                .PrescriberID = pPrescriberID
                .RxHubMessageXML = pRequestXML.ToString
                .RxHubMessageEDI = ReadDataFromFile(System.Configuration.ConfigurationManager.AppSettings("ProviderUpdateRequestPath") + NameHandlerBL.EDIName)
                .SureScriptXML = ""
                .RelatesToMessageID = pRelatestoMessageID
                .LoggingDate = Date.Now
            End With

            lTraceLogging.TraceLogging = lTraceLoggingDB
            lTraceLogging.InsertRecord()

        Catch ex As Exception
            ErrorLogMethods.LogError(ex, "RxHubLibrary\BLL\RequestBL.TraceLogging(ByVal pMessageID As String, ByVal pMessageType As String, ByVal pPrescriberID As String, ByVal pRequestXML As String, ByVal pRequestEDI As String, ByVal pRelatestoMessageID As String) ")
        End Try


    End Sub


End Class
