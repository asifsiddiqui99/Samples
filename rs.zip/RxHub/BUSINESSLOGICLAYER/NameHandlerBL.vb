Imports System.io

Public Class NameHandlerBL
    Private mXmlName As String
    Private mEDIName As String


#Region "Constructor"

    Public Sub New()
        Try
            GenerateName()
        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\NameHandlerBL.New() ")
        End Try
    End Sub

#End Region


#Region "Property"

    Public Property XmlName() As String
        Get
            Return mXmlName + ".xml"
        End Get
        Set(ByVal value As String)
            mXmlName = value
        End Set
    End Property

    Public Property XmlName(ByVal pName As String) As String
        Get
            Return mXmlName + pName + ".xml"
        End Get
        Set(ByVal value As String)
            mXmlName = value
        End Set
    End Property

    Public Property EDIName() As String
        Get
            Return mEDIName + ".txt"
        End Get
        Set(ByVal value As String)
            mEDIName = value
        End Set
    End Property

    Public Property EDIName(ByVal pName As String) As String
        Get
            Return mEDIName + pName + ".txt"
        End Get
        Set(ByVal value As String)
            mEDIName = value
        End Set
    End Property


#End Region


    'This function generates a unique name
    Private Function GenerateName() As String

        Dim lName As String = String.Empty

        Try

            lName = Date.Now.ToString("yyyyMMdd") + Date.Now.ToString("HHmmss")
            XmlName = lName + "Xml"
            EDIName = lName + "Edi"

        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\NameHandler.GenerateName() ")
        End Try

        Return lName
    End Function




End Class
