Imports System.Xml

Public Class MedicationHistoryBL

    Private mXml As String
    Private mDrugList As DataSet
    Private mExists As Boolean
    Private mDrugLoopCount As Integer
    Private mStatus As String
    Private mPatientName As String
    Private mDocterName As String
    Private mMoreHistory As MoreHistory
    Private mMoreDrugHistoryExists As Boolean


#Region "Constructor"

    Public Sub New(ByVal pXml As String, ByVal pMoreHistory As MoreHistory)
        mXml = pXml
        mExists = False
        mStatus = ""
        mDrugLoopCount = 0
        mMoreDrugHistoryExists = False
        mMoreHistory = pMoreHistory
        GetMedicationHistory()
    End Sub

    Public Sub New()
        mXml = ""
        mExists = False
        mStatus = ""
        mDrugLoopCount = 0
        mMoreDrugHistoryExists = False
        mDrugList = New DataSet
    End Sub

#End Region


#Region "Property"

    Public Property MoreHistory() As MoreHistory
        Get
            Return mMoreHistory
        End Get
        Set(ByVal value As MoreHistory)
            mMoreHistory = value
        End Set
    End Property


    Public ReadOnly Property DocterName() As String
        Get
            Return mDocterName
        End Get
    End Property
    Public ReadOnly Property PatientName() As String
        Get
            Return mPatientName
        End Get
    End Property

    Public Property Status() As String
        Get
            Return mStatus
        End Get
        Set(ByVal value As String)
            mStatus = value
        End Set
    End Property

    Public Property DrugList() As DataSet
        Get
            If mExists = True Then
                Return mDrugList
            Else : Return Nothing
            End If
        End Get
        Set(ByVal value As DataSet)
            mExists = True
            mDrugList = value
        End Set
    End Property

    Public Property MoreDrugHistoryExists() As Boolean
        Get
            Return mMoreDrugHistoryExists
        End Get
        Set(ByVal value As Boolean)
            mMoreDrugHistoryExists = value
        End Set
    End Property

    Public Property Exists() As Boolean
        Get
            Return mExists
        End Get
        Set(ByVal value As Boolean)
            mExists = value
        End Set
    End Property

    Public Property Count() As Integer
        Get
            If mExists = True Then
                Return mDrugLoopCount
            Else : Return 0
            End If
        End Get
        Set(ByVal value As Integer)
            mDrugLoopCount = value
            mExists = True
        End Set
    End Property


#End Region


    'Private Sub GetMedicationHistory()

    '    Dim lXmlDocument As XmlDocument = Nothing

    '    Try

    '        lXmlDocument = New XmlDocument

    '        lXmlDocument.LoadXml(mXml)


    '        'Checks if there is an error
    '        If lXmlDocument.DocumentElement.SelectNodes("//STS").Count > 0 Then ' there is an error
    '            If lXmlDocument.DocumentElement.SelectNodes("//STS/FreeText").Count > 0 Then
    '                mStatus = lXmlDocument.DocumentElement.SelectSingleNode("//STS/FreeText").InnerText

    '            Else 'there must be a more generic type of error
    '                mStatus = "Communication Error."
    '            End If
    '            mExists = False
    '            Exit Sub
    '        End If




    '        'Author : CPD from Fareed
    '        'This part created for the DataSet
    '        Dim lDS As DataSet = New DataSet
    '        Dim DrugTable As DataTable = New DataTable
    '        DrugTable = lDS.Tables.Add("DrugList")
    '        Dim Column1, Column2, Column3, Column4, Column5, Column6, Column7, Column8, Column9, Column10, Column11, Column12, Column13, Column14, column15 As DataColumn
    '        Dim Row As DataRow
    '        Column1 = New DataColumn("DrugName", System.Type.GetType("System.String"))
    '        DrugTable.Columns.Add(Column1)
    '        Column2 = New DataColumn("Quantity", System.Type.GetType("System.String"))
    '        DrugTable.Columns.Add(Column2)
    '        Column3 = New DataColumn("Status", System.Type.GetType("System.String"))
    '        DrugTable.Columns.Add(Column3)
    '        Column4 = New DataColumn("LastFill", System.Type.GetType("System.String"))
    '        DrugTable.Columns.Add(Column4)
    '        Column5 = New DataColumn("ExtraInformation", System.Type.GetType("System.String"))
    '        DrugTable.Columns.Add(Column5)
    '        Column6 = New DataColumn("PhysicianName", System.Type.GetType("System.String"))
    '        DrugTable.Columns.Add(Column6)
    '        Column7 = New DataColumn("PharmacyName", System.Type.GetType("System.String"))
    '        DrugTable.Columns.Add(Column7)
    '        Column8 = New DataColumn("PhysicianAddress", System.Type.GetType("System.String"))
    '        DrugTable.Columns.Add(Column8)
    '        Column9 = New DataColumn("PharmacyAddress", System.Type.GetType("System.String"))
    '        DrugTable.Columns.Add(Column9)
    '        Column10 = New DataColumn("PhysicianContact", System.Type.GetType("System.String"))
    '        DrugTable.Columns.Add(Column10)
    '        Column11 = New DataColumn("PharmacyContact", System.Type.GetType("System.String"))
    '        DrugTable.Columns.Add(Column11)
    '        Column12 = New DataColumn("DEA", System.Type.GetType("System.String"))
    '        DrugTable.Columns.Add(Column12)
    '        Column13 = New DataColumn("NCPDID", System.Type.GetType("System.String"))
    '        DrugTable.Columns.Add(Column13)
    '        Column14 = New DataColumn("Notes", System.Type.GetType("System.String"))
    '        DrugTable.Columns.Add(Column14)
    '        column15 = New DataColumn("NDC", System.Type.GetType("System.String"))
    '        DrugTable.Columns.Add(Column15)



    '        mCount = lXmlDocument.DocumentElement.SelectNodes("//DrugLoop").Count

    '        If lXmlDocument.DocumentElement.SelectNodes("//RES/FreeText").Count > 0 Then
    '            mStatus = lXmlDocument.DocumentElement.SelectSingleNode("//RES/FreeText").InnerText
    '            mMoreHistory.MoreDrugHistoryExists = True
    '            mMoreDrugHistoryExists = True
    '        End If

    '        mPatientName = lXmlDocument.DocumentElement.SelectSingleNode("//PTT/Name/FirstName").InnerText & " " & lXmlDocument.DocumentElement.SelectSingleNode("//PTT/Name/PartyName").InnerText
    '        mDocterName = lXmlDocument.DocumentElement.SelectSingleNode("//PVD/ProviderName/FirstName").InnerText & " " & lXmlDocument.DocumentElement.SelectSingleNode("//PVD/ProviderName/PartyName").InnerText

    '        If lXmlDocument.DocumentElement.SelectNodes("//DrugLoop").Count < 1 Then
    '            If mStatus.Trim.Equals("") Then
    '                mStatus = "0 Records"
    '            End If
    '            mExists = False
    '            Exit Sub
    '        Else : mExists = True
    '        End If



    '        For x As Integer = 0 To lXmlDocument.SelectNodes("//DrugLoop").Count - 1
    '            Row = lDS.Tables("DrugList").NewRow()
    '            Row(0) = lXmlDocument.SelectSingleNode("//DrugLoop[" & (x + 1) & "]/DRU/Drug/ItemDescription").InnerText
    '            Row(1) = lXmlDocument.SelectSingleNode("//DrugLoop[" & (x + 1) & "]/DRU/Quantity/Quantity").InnerText

    '            If (lXmlDocument.SelectNodes("//DrugLoop[" & (x + 1) & "]/DRU/Drug/CodeListResponseibilityAgency").Count > 0 AndAlso lXmlDocument.SelectSingleNode("//DrugLoop[" & (x + 1) & "]/DRU/Drug/CodeListResponseibilityAgency").InnerText = "ND") Then

    '                Row(14) = lXmlDocument.SelectSingleNode("//DrugLoop[" & (x + 1) & "]/DRU/Drug/ItemNumber").InnerText
    '            Else
    '                Row(14) = ""

    '            End If


    '            If lXmlDocument.SelectNodes("//DrugLoop[" & (x + 1) & "]/DRU/FreeText").Count > 0 Then
    '                Row(13) = lXmlDocument.SelectSingleNode("//DrugLoop[" & (x + 1) & "]/DRU/FreeText").InnerText
    '            Else
    '                Row(13) = ""
    '            End If
    '            Select Case lXmlDocument.SelectSingleNode("//DrugLoop[" & (x + 1) & "]/DRU/Quantity/CodeListQualifier").InnerText
    '                Case "38"
    '                    Row(2) = "Original Quantity "
    '                Case "40"
    '                    Row(2) = "Remaining Quantity "
    '                Case "87"
    '                    Row(2) = "Quantity Recieved"
    '            End Select

    '            'Row 4 will be added for extra information 
    '            Row(4) = ""

    '            For y As Integer = 1 To lXmlDocument.SelectNodes("//DrugLoop[" & (x + 1) & "]/DRU/DateTimePeriodQualifier").Count
    '                Select Case lXmlDocument.SelectSingleNode("//DrugLoop[" & (x + 1) & "]/DRU/DateTimePeriodQualifier[" & y & "]/DateTimePeriodQualifier").InnerText
    '                    Case "LD"
    '                        Row(3) = lXmlDocument.SelectSingleNode("//DrugLoop[" & (x + 1) & "]/DRU/DateTimePeriodQualifier[" & y & "]/DateTimePeriod").InnerText.Substring(4, 2) + "/" + lXmlDocument.SelectSingleNode("//DrugLoop[" & (x + 1) & "]/DRU/DateTimePeriodQualifier[" & y & "]/DateTimePeriod").InnerText.Substring(6, 2) + "/" + lXmlDocument.SelectSingleNode("//DrugLoop[" & (x + 1) & "]/DRU/DateTimePeriodQualifier[" & y & "]/DateTimePeriod").InnerText.Substring(0, 4)
    '                    Case "ZDS"
    '                        Row(4) = Row(4) & lXmlDocument.SelectSingleNode("//DrugLoop[" & (x + 1) & "]/DRU/DateTimePeriodQualifier[" & y & "]/DateTimePeriod").InnerText & " Days Supply. "
    '                    Case "PE"
    '                        Row(4) = Row(4) & lXmlDocument.SelectSingleNode("//DrugLoop[" & (x + 1) & "]/DRU/DateTimePeriodQualifier[" & y & "]/DateTimePeriod").InnerText & " Period End. "
    '                    Case "07"
    '                        Row(4) = Row(4) & " Effective Date of " & lXmlDocument.SelectSingleNode("//DrugLoop[" & (x + 1) & "]/DRU/DateTimePeriodQualifier[" & y & "]/DateTimePeriod").InnerText.Substring(4, 2) + "/" + lXmlDocument.SelectSingleNode("//DrugLoop[" & (x + 1) & "]/DRU/DateTimePeriodQualifier[" & y & "]/DateTimePeriod").InnerText.Substring(6, 2) + "/" + lXmlDocument.SelectSingleNode("//DrugLoop[" & (x + 1) & "]/DRU/DateTimePeriodQualifier[" & y & "]/DateTimePeriod").InnerText.Substring(0, 4) & ". "
    '                    Case "36"
    '                        Row(4) = Row(4) & " Expiration Date of " & lXmlDocument.SelectSingleNode("//DrugLoop[" & (x + 1) & "]/DRU/DateTimePeriodQualifier[" & y & "]/DateTimePeriod").InnerText.Substring(4, 2) + "/" + lXmlDocument.SelectSingleNode("//DrugLoop[" & (x + 1) & "]/DRU/DateTimePeriodQualifier[" & y & "]/DateTimePeriod").InnerText.Substring(6, 2) + "/" + lXmlDocument.SelectSingleNode("//DrugLoop[" & (x + 1) & "]/DRU/DateTimePeriodQualifier[" & y & "]/DateTimePeriod").InnerText.Substring(0, 4) & ". "
    '                    Case "85"
    '                        Row(4) = Row(4) & " Issue Date of " & lXmlDocument.SelectSingleNode("//DrugLoop[" & (x + 1) & "]/DRU/DateTimePeriodQualifier[" & y & "]/DateTimePeriod").InnerText.Substring(4, 2) + "/" + lXmlDocument.SelectSingleNode("//DrugLoop[" & (x + 1) & "]/DRU/DateTimePeriodQualifier[" & y & "]/DateTimePeriod").InnerText.Substring(6, 2) + "/" + lXmlDocument.SelectSingleNode("//DrugLoop[" & (x + 1) & "]/DRU/DateTimePeriodQualifier[" & y & "]/DateTimePeriod").InnerText.Substring(0, 4) & ". "
    '                End Select
    '            Next


    '            'If we have a case where we get only a physician or pharmacy PVD then I will include and if..else statement
    '            If lXmlDocument.SelectNodes("//DrugLoop[" & (x + 1) & "]/PVD").Count = 2 Then


    '                'Phycisian Part
    '                If lXmlDocument.SelectNodes("//DrugLoop[" & (x + 1) & "]/PVD[1]/ProviderName/FirstName").Count = 0 Then
    '                    Row(5) = ""
    '                ElseIf lXmlDocument.SelectNodes("//DrugLoop[" & (x + 1) & "]/PVD[1]/ProviderName/PartyName").Count = 0 Then
    '                    Row(5) = lXmlDocument.SelectSingleNode("//DrugLoop[" & (x + 1) & "]/PVD[1]/ProviderName/FirstName").InnerText
    '                Else
    '                    Row(5) = lXmlDocument.SelectSingleNode("//DrugLoop[" & (x + 1) & "]/PVD[1]/ProviderName/FirstName").InnerText & " " & lXmlDocument.SelectSingleNode("//DrugLoop[" & (x + 1) & "]/PVD[1]/ProviderName/PartyName").InnerText
    '                End If

    '                If lXmlDocument.SelectNodes("//DrugLoop[" & (x + 1) & "]/PVD[1]/Address/StreetNo").Count = 0 Then
    '                    Row(7) = ""
    '                ElseIf lXmlDocument.SelectNodes("//DrugLoop[" & (x + 1) & "]/PVD[1]/Address/City").Count = 0 Then
    '                    Row(7) = lXmlDocument.SelectSingleNode("//DrugLoop[" & (x + 1) & "]/PVD[1]/Address/StreetNo").InnerText
    '                Else
    '                    Row(7) = lXmlDocument.SelectSingleNode("//DrugLoop[" & (x + 1) & "]/PVD[1]/Address/StreetNo").InnerText & " " & lXmlDocument.SelectSingleNode("//DrugLoop[" & (x + 1) & "]/PVD[1]/Address/City").InnerText
    '                End If



    '                'Have to check the complete list for other types of communication numbers
    '                Row(9) = ""
    '                For z As Integer = 1 To lXmlDocument.SelectNodes("//DrugLoop[" & (x + 1) & "]/PVD[1]/CommunicationNumber").Count
    '                    Row(9) = Row(9) & " , " & lXmlDocument.SelectSingleNode("//DrugLoop[" & (x + 1) & "]/PVD[1]/CommunicationNumber[" & z & "]/CommunicationNumber").InnerText
    '                Next
    '                Row(9) = Row(9).ToString.TrimStart(",")



    '                If lXmlDocument.SelectNodes("//DrugLoop[" & (x + 1) & "]/PVD[1]/ReferenceNumber/ReferenceNumber").Count = 0 Then
    '                    Row(11) = ""
    '                Else
    '                    Row(11) = lXmlDocument.SelectSingleNode("//DrugLoop[" & (x + 1) & "]/PVD[1]/ReferenceNumber/ReferenceNumber").InnerText
    '                End If

    '                'Pharmacy Part

    '                If lXmlDocument.SelectNodes("//DrugLoop[" & (x + 1) & "]/PVD[2]/PartyName").Count = 0 Then
    '                    Row(6) = 0
    '                Else
    '                    Row(6) = lXmlDocument.SelectSingleNode("//DrugLoop[" & (x + 1) & "]/PVD[2]/PartyName").InnerText
    '                End If



    '                If lXmlDocument.SelectNodes("//DrugLoop[" & (x + 1) & "]/PVD[2]/Address/StreetNo").Count = 0 Then
    '                    Row(8) = ""
    '                ElseIf lXmlDocument.SelectNodes("//DrugLoop[" & (x + 1) & "]/PVD[2]/Address/City").Count = 0 Then
    '                    Row(8) = lXmlDocument.SelectSingleNode("//DrugLoop[" & (x + 1) & "]/PVD[2]/Address/StreetNo").InnerText
    '                Else
    '                    Row(8) = lXmlDocument.SelectSingleNode("//DrugLoop[" & (x + 1) & "]/PVD[2]/Address/StreetNo").InnerText & " , " & lXmlDocument.SelectSingleNode("//DrugLoop[" & (x + 1) & "]/PVD[2]/Address/City").InnerText
    '                End If


    '                If lXmlDocument.SelectNodes("//DrugLoop[" & (x + 1) & "]/PVD[2]/ReferenceNumber/ReferenceNumber").Count = 0 Then
    '                    Row(12) = ""
    '                Else
    '                    Row(12) = lXmlDocument.SelectSingleNode("//DrugLoop[" & (x + 1) & "]/PVD[2]/ReferenceNumber/ReferenceNumber").InnerText
    '                End If


    '                'Have to check the complete list for other types of communication numbers
    '                Row(10) = ""
    '                'If lXmlDocument.SelectNodes("//DrugLoop[" & (x + 1) & "]/PVD[2]/CommunicationNumber").Count <> 0 Then
    '                For z As Integer = 1 To lXmlDocument.SelectNodes("//DrugLoop[" & (x + 1) & "]/PVD[2]/CommunicationNumber").Count
    '                    Row(10) = Row(10) & " , " & lXmlDocument.SelectSingleNode("//DrugLoop[" & (x + 1) & "]/PVD[2]/CommunicationNumber/CommunicationNumber[" & z & "]").InnerText
    '                Next
    '                Row(10) = Row(10).ToString.TrimStart(",", " ")
    '                '                End If




    '            ElseIf lXmlDocument.SelectNodes("//DrugLoop[" & (x + 1) & "]/PVD").Count = 1 Then
    '                'Either it is a phycisian or prescriber 
    '                'Check the providor coded 
    '                'Take appropriate action
    '            End If




    '            lDS.Tables("DrugList").Rows.Add(Row)

    '        Next

    '        'This part picks the last date from the DRUG
    '        'The last date is actually the last fill date
    '        For y As Integer = 1 To lXmlDocument.SelectNodes("//DrugLoop[" & lXmlDocument.SelectNodes("//DrugLoop").Count & "]/DRU/DateTimePeriodQualifier").Count
    '            Select Case lXmlDocument.SelectSingleNode("//DrugLoop[" & lXmlDocument.SelectNodes("//DrugLoop").Count & "]/DRU/DateTimePeriodQualifier[" & y & "]/DateTimePeriodQualifier").InnerText
    '                Case "LD"
    '                    mMoreHistory.LastDate = lXmlDocument.SelectSingleNode("//DrugLoop[" & lXmlDocument.SelectNodes("//DrugLoop").Count & "]/DRU/DateTimePeriodQualifier[" & y & "]/DateTimePeriod").InnerText
    '            End Select
    '        Next




    '        mDrugList = lDS


    '    Catch ex As Exception
    '        Throw New Exception(ex.Message & " : RxHubLibrary\BLL\MedicatioHistoryBL.GetMedicationHistory() ")
    '    End Try
    'End Sub

    Private Sub GetMedicationHistory()


        Try
            mXml = mXml.Replace("request=", "")
            Dim InputMsgRes As New MedicationHistoryResponse.InputParser
            Dim Response As New MedicationHistoryResponse.MsgRXHRES
            Response = InputMsgRes.Parse(mXml)

            'Checks if there is an error
         

            If Response.STS.Code.Count > 0 AndAlso Response.STS.Code.Item(0).Value <> "" Then ' there is an error
                If Response.STS.FreeText.Value <> "" Then
                    mStatus = Response.STS.FreeText.Value

                Else 'there must be a more generic type of error
                    mStatus = "Communication Error."
                End If
                mExists = False
                Exit Sub
            End If

            'Author : CPD from Fareed
            'This part created for the DataSet
            Dim lDS As DataSet = New DataSet
            Dim DrugTable As DataTable = New DataTable
            DrugTable = lDS.Tables.Add("DrugList")
            Dim Column1, Column2, Column3, Column4, Column5, Column6, Column7, Column8, Column9, Column10, Column11, Column12, Column13, Column14, column15, column16, column17, column18, column19, column20, column21, column22, column23, column24, column25, column26, column27 As DataColumn
            Dim Row As DataRow
            Column1 = New DataColumn("DrugName", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(Column1)
            Column2 = New DataColumn("Quantity", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(Column2)
            Column3 = New DataColumn("Status", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(Column3)
            Column4 = New DataColumn("LastFill", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(Column4)
            Column5 = New DataColumn("ExtraInformation", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(Column5)
            Column6 = New DataColumn("PhysicianName", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(Column6)
            Column7 = New DataColumn("PharmacyName", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(Column7)
            Column8 = New DataColumn("PhysicianAddress", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(Column8)
            Column9 = New DataColumn("PharmacyAddress", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(Column9)
            Column10 = New DataColumn("PhysicianContact", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(Column10)
            Column11 = New DataColumn("PharmacyContact", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(Column11)
            Column12 = New DataColumn("DEA", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(Column12)
            Column13 = New DataColumn("NCPDID", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(Column13)
            Column14 = New DataColumn("Notes", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(Column14)
            column15 = New DataColumn("NDC", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(column15)
            column16 = New DataColumn("StructuredSig", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(column16)
            column17 = New DataColumn("SourceType", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(column17)
            column18 = New DataColumn("SourceDescription", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(column18)
            column19 = New DataColumn("RefillQuantity", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(column19)
            column20 = New DataColumn("RefillType", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(column20)
            column21 = New DataColumn("PrescriptionNumber", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(column21)
            column22 = New DataColumn("DiagnosisQualifier", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(column22)
            column23 = New DataColumn("DiagnosisCode", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(column23)
            column24 = New DataColumn("PriorAuthorizationStatus", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(column24)
            column25 = New DataColumn("HistorySource", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(column25)
            column26 = New DataColumn("DEASchedule", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(column26)
            column27 = New DataColumn("DaysSupply", System.Type.GetType("System.String"))
            DrugTable.Columns.Add(column27)


            mDrugLoopCount = Response.DrugLoop.Count

            'If denied then free text
            If Response.RES.ResponseTypeCoded.Value = "D" AndAlso Response.RES.FreeText.Value <> "" Then
                mStatus = "Denied by Payer (" & Response.RES.FreeText.Value & ")"
            ElseIf Response.RES.FreeText.Value <> "" Then
                mStatus = Response.RES.FreeText.Value
            End If

            If Response.RES.CodeListQualifier.Value <> "" Then
                ' mStatus = Response.RES.FreeText.Value
                If Response.RES.CodeListQualifier.Value.Equals("AQ") Then
                    mMoreHistory.MoreDrugHistoryExists = True
                    mMoreDrugHistoryExists = True
                End If

            End If

            mPatientName = Response.PTT.Name.FirstName.Value & " " & Response.PTT.Name.PartyName.Value
            mDocterName = Response.PVD.Name.FirstName.Value & " " & Response.PVD.Name.PartyName.Value

            If mDrugLoopCount < 1 Then
                If mStatus.Trim.Equals("") Then
                    mStatus = "0 Records"
                End If
                mExists = False
                Exit Sub
            Else : mExists = True
            End If


            For x As Integer = 0 To mDrugLoopCount - 1
                Row = lDS.Tables("DrugList").NewRow()
                Dim LongDrugName = Response.DrugLoop.Item(x).DRU.Drug.ItemDescription.Value

                If Not LongDrugName.contains(Response.DrugLoop.Item(x).DRU.Drug.ItemDescription1.Value) Then
                    LongDrugName = LongDrugName & " " & Response.DrugLoop.Item(x).DRU.Drug.ItemDescription1.Value
                End If


                If Not LongDrugName.contains(Response.DrugLoop.Item(x).DRU.Drug.ItemDescription2.Value) Then
                    LongDrugName = LongDrugName & " " & Response.DrugLoop.Item(x).DRU.Drug.ItemDescription2.Value
                End If

                If Not LongDrugName.contains(Response.DrugLoop.Item(x).DRU.Drug.ItemDescription3.Value) Then
                    LongDrugName = LongDrugName & " " & Response.DrugLoop.Item(x).DRU.Drug.ItemDescription3.Value
                End If
                Row(0) = LongDrugName
                Row(1) = Response.DrugLoop.Item(x).DRU.Quantity.Item(0).Quantity.Value

                If (Response.DrugLoop.Item(x).DRU.Drug.CodeListResponsibilityAgency.Value <> "" AndAlso Response.DrugLoop.Item(x).DRU.Drug.CodeListResponsibilityAgency.Value = "ND") Then

                    Row(14) = Response.DrugLoop.Item(x).DRU.Drug.ItemNumber.Value
                Else
                    Row(14) = ""

                End If



                If Response.DrugLoop.Item(x).DRU.FreeText.Count > 0 Then
                    Dim FreeText As MedicationHistoryResponse.RepFldBasicST = Response.DrugLoop.Item(x).DRU.FreeText
                    For index As Integer = 0 To FreeText.Count - 1
                        Dim ftxt As MedicationHistoryResponse.FldBasicST = FreeText.Item(index)
                        Row(13) = Row(13) & ftxt.Value
                    Next
                End If
                Select Case Response.DrugLoop.Item(x).DRU.Quantity.Item(0).CodeListQualifier.Value
                    Case "38"
                        Row(2) = "Original Quantity "
                    Case "40"
                        Row(2) = "Remaining Quantity "
                    Case "87"
                        Row(2) = "Quantity Received"
                End Select

                'Row 4 will be added for extra information 
                Row(4) = ""

                For y As Integer = 0 To Response.DrugLoop.Item(x).DRU.Date.Count - 1
                    Dim dateSeg As MedicationHistoryResponse.FldI006 = Response.DrugLoop.Item(x).DRU.Date.Item(y)
                    Select Case dateSeg.DateTimePeriodQualifier.Value
                        Case "LD"
                            Row(3) = dateSeg.DataTimePeriod.Value.Substring(4, 2) + "/" + dateSeg.DataTimePeriod.Value.Substring(6, 2) + "/" + dateSeg.DataTimePeriod.Value.Substring(0, 4)
                        Case "ZDS"
                            Row(4) = Row(4) & dateSeg.DataTimePeriod.Value & " Days Supply. "
                            Row(26) = dateSeg.DataTimePeriod.Value
                        Case "PE"
                            Row(4) = Row(4) & dateSeg.DataTimePeriod.Value & " Period End. "
                        Case "07"
                            Row(4) = Row(4) & " Effective Date of " & dateSeg.DataTimePeriod.Value.Substring(4, 2) + "/" + dateSeg.DataTimePeriod.Value.Substring(6, 2) + "/" + dateSeg.DataTimePeriod.Value.Substring(0, 4) & ". "
                        Case "36"
                            Row(4) = Row(4) & " Expiration Date of " & dateSeg.DataTimePeriod.Value.Substring(4, 2) + "/" + dateSeg.DataTimePeriod.Value.Substring(6, 2) + "/" + dateSeg.DataTimePeriod.Value.Substring(0, 4) & ". "
                        Case "85"
                            Row(4) = Row(4) & " Issue Date of " & dateSeg.DataTimePeriod.Value.Substring(4, 2) + "/" + dateSeg.DataTimePeriod.Value.Substring(6, 2) + "/" + dateSeg.DataTimePeriod.Value.Substring(0, 4) & ". "
                    End Select
                Next

                Dim PVDSeg As MedicationHistoryResponse.RepSegPVD = Response.DrugLoop.Item(x).PVD
                'If we have a case where we get only a physician or pharmacy PVD then I will include and if..else statement
                If PVDSeg.Count = 2 Then


                    'Phycisian Part
                    If PVDSeg.Item(0).Name.FirstName.Value = "" Then
                        Row(5) = ""
                    ElseIf PVDSeg.Item(0).Name.PartyName.Value = "" Then
                        Row(5) = PVDSeg.Item(0).Name.FirstName.Value
                    Else
                        Row(5) = PVDSeg.Item(0).Name.FirstName.Value & " " & PVDSeg.Item(0).Name.PartyName.Value
                    End If

                    If PVDSeg.Item(0).Address.AddressLine1.Value = "" Then
                        Row(7) = ""
                    ElseIf PVDSeg.Item(0).Address.City.Value = "" Then
                        Row(7) = PVDSeg.Item(0).Address.AddressLine1.Value
                    Else
                        Row(7) = PVDSeg.Item(0).Address.AddressLine1.Value & " " & PVDSeg.Item(0).Address.City.Value
                    End If

                    'Have to check the complete list for other types of communication numbers
                    Row(9) = ""
                    For z As Integer = 0 To PVDSeg.Item(0).CommunicationNumber.Count - 1
                        Row(9) = Row(9) & " , " & PVDSeg.Item(0).CommunicationNumber.Item(z).CommunicationNumber.Value
                    Next
                    Row(9) = Row(9).ToString.TrimStart(",")

                    If PVDSeg.Item(0).ReferenceNumber.Count = 0 Then
                        Row(11) = ""
                    Else
                        Row(11) = PVDSeg.Item(0).ReferenceNumber.Item(0).ReferenceNumber.Value
                    End If

                    'Pharmacy Part

                    If PVDSeg.Item(1).PartyName.Value = "" Then
                        Row(6) = ""
                    Else
                        Row(6) = PVDSeg.Item(1).PartyName.Value
                    End If



                    If PVDSeg.Item(1).Address.AddressLine1.Value = "" Then
                        Row(8) = ""
                    ElseIf PVDSeg.Item(1).Address.City.Value = "" Then
                        Row(8) = PVDSeg.Item(1).Address.AddressLine1.Value
                    Else
                        Row(8) = PVDSeg.Item(1).Address.AddressLine1.Value & " , " & PVDSeg.Item(1).Address.City.Value
                    End If


                    If PVDSeg.Item(1).ReferenceNumber.Count = 0 Then
                        Row(12) = ""
                    Else
                        Row(12) = PVDSeg.Item(1).ReferenceNumber.Item(0).ReferenceNumber.Value
                    End If


                    'Have to check the complete list for other types of communication numbers
                    Row(10) = ""
                    'If lXmlDocument.SelectNodes("//DrugLoop[" & (x + 1) & "]/PVD[2]/CommunicationNumber").Count <> 0 Then
                    For z As Integer = 0 To PVDSeg.Item(1).CommunicationNumber.Count - 1
                        Row(10) = Row(10) & " , " & PVDSeg.Item(1).CommunicationNumber.Item(z).CommunicationNumber.Value
                    Next
                    Row(10) = Row(10).ToString.TrimStart(",", " ")
                    '                End If




                ElseIf PVDSeg.Count = 1 Then
                    'Either it is a phycisian or prescriber 
                    'Check the providor coded 
                    'Take appropriate action
                End If

                Dim SigSegRep As MedicationHistoryResponse.RepSegSIG = Response.DrugLoop.Item(x).SIG
                For index As Integer = 0 To SigSegRep.Count - 1
                    Dim sigSeg As MedicationHistoryResponse.SegSIG = SigSegRep.Item(index)
                    If Not Row(15).ToString.Trim.Contains(sigSeg.FreeText.SigFreeText.Value.Trim) Then
                        Row(15) = Row(15) & " " & sigSeg.FreeText.SigFreeText.Value
                    End If

                Next

                Dim SRCSegRep As MedicationHistoryResponse.SegSRC = Response.DrugLoop.Item(x).SRC

                If SRCSegRep.Source.SourceQualifier.Value = "P2" Then
                    Row(16) = "Pharmacy"
                    Row(6) = SRCSegRep.Source.SourceDescription.Value
                ElseIf SRCSegRep.Source.SourceQualifier.Value = "PY" Then
                    Row(16) = "Payer"
                End If

                Row(17) = SRCSegRep.Source.SourceDescription.Value

                If Response.DrugLoop.Item(x).DRU.RefillQuantity.Count > 0 Then
                    ' Row(18) = Response.DrugLoop.Item(x).DRU.RefillQuantity.Item(0).Quantity.Value
                    If Response.DrugLoop.Item(x).DRU.RefillQuantity.Item(0).QuantityQualifier.Value <> "PRN" Then
                        Row(18) = Response.DrugLoop.Item(x).DRU.RefillQuantity.Item(0).Quantity.Value
                    Else
                        Row(18) = "PRN"
                    End If

                    Row(19) = Response.DrugLoop.Item(x).DRU.RefillQuantity.Item(0).QuantityQualifier.Value
                End If
                If Not Response.DrugLoop.Item(x).DRU.ReferenceNumber.ReferenceQualifier.Value.Equals("") Then
                    Row(20) = Response.DrugLoop.Item(x).DRU.ReferenceNumber.ReferenceNumber.Value
                End If

                If Response.DrugLoop.Item(x).DRU.Diagnosis.Count > 0 Then

                    Select Case Response.DrugLoop.Item(x).DRU.Diagnosis.Item(0).PrimaryCodeListQualifier.Value
                        Case "M"
                            Row(21) = "Medi-Span"
                        Case "F"
                            Row(21) = "First DataBank"
                        Case "E"
                            Row(21) = "Medical Economics"
                        Case "DX"
                            Row(21) = "ICD9"
                        Case "ABF"
                            Row(21) = " ICD10"

                    End Select

                    Row(22) = Response.DrugLoop.Item(x).DRU.Diagnosis.Item(0).ClinicalInfomationPrimary.Value
                End If

                If Response.DrugLoop.Item(x).DRU.PriorAuthorizationStatus.Count > 0 Then

                    Select Case Response.DrugLoop.Item(x).DRU.PriorAuthorizationStatus.Item(0).Value
                        Case "A"
                            Row(23) = "Approved"
                        Case "D"
                            Row(23) = "Denied"
                        Case "F"
                            Row(23) = "Deferred"
                        Case "N"
                            Row(23) = "Not Required"
                        Case "R"
                            Row(23) = "Requested"
                        Case Else
                            Row(23) = ""
                    End Select

                End If

                If Response.UIB.TransactionReference.ControllingAgencyCoded.Value = "FIL" Then
                    Row(24) = "Pharmacy"
                Else
                    Row(24) = "PBM"
                End If

                Select Case Response.DrugLoop.Item(x).DRU.Drug.DEASchedule.Value
                    Case "C48672"
                        Row(25) = "Schedule I"
                    Case "C48675"
                        Row(25) = "Schedule II"
                    Case "C48676"
                        Row(25) = "Schedule III"
                    Case "C48677"
                        Row(25) = "Schedule IV"
                    Case "C48679"
                        Row(25) = " Schedule V"

                End Select


                lDS.Tables("DrugList").Rows.Add(Row)

            Next



            'This part picks the last date from the DRUG
            'The last date is actually the last fill date
            For y As Integer = 0 To Response.DrugLoop.Item(Response.DrugLoop.Count - 1).DRU.Date.Count - 1
                Select Case Response.DrugLoop.Item(Response.DrugLoop.Count - 1).DRU.Date.Item(y).DateTimePeriodQualifier.Value
                    Case "LD"
                        mMoreHistory.LastDate = Response.DrugLoop.Item(Response.DrugLoop.Count - 1).DRU.Date.Item(y).DataTimePeriod.Value
                End Select
            Next




            mDrugList = lDS


        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\MedicatioHistoryBL.GetMedicationHistory() ")
        End Try
    End Sub

End Class




Public Class MoreHistory
    Private mPBMId As String
    Private mPBMName As String
    Private mCardHolderReferenceNumber As String
    Private mLastDate As String
    Private mMoreDrugHistoryExists As Boolean
    Private mMailOrderPrescription As Boolean
    Private mPharmacyBenifit As Boolean
    Private mFillData As Boolean


#Region "Property"


    Public Property PBMName() As String
        Get
            Return mPBMName
        End Get
        Set(ByVal value As String)
            mPBMName = value
        End Set
    End Property

    Public Property CardHolderReferenceNumber() As String
        Get
            Return mCardHolderReferenceNumber
        End Get
        Set(ByVal value As String)
            mCardHolderReferenceNumber = value
        End Set
    End Property
    Public Property PBMId() As String
        Get
            Return mPBMId
        End Get
        Set(ByVal value As String)
            mPBMId = value
        End Set
    End Property

    Public Property LastDate() As String
        Get
            Return mLastDate
        End Get
        Set(ByVal value As String)
            mLastDate = value
        End Set
    End Property

    Public Property MoreDrugHistoryExists() As Boolean
        Get
            Return mMoreDrugHistoryExists
        End Get
        Set(ByVal value As Boolean)
            mMoreDrugHistoryExists = value
        End Set
    End Property

    Public Property MailOrderPrescription() As Boolean
        Get
            Return mMailOrderPrescription
        End Get
        Set(ByVal value As Boolean)
            mMailOrderPrescription = value
        End Set
    End Property

    Public Property PharmacyBenifit() As Boolean
        Get
            Return mPharmacyBenifit
        End Get
        Set(ByVal value As Boolean)
            mPharmacyBenifit = value
        End Set
    End Property

    Public Property FillData() As Boolean
        Get
            Return mFillData
        End Get
        Set(ByVal value As Boolean)
            mFillData = value
        End Set
    End Property
#End Region

End Class

Public Class DrugHistoryObject
    Private mDrugName As String
    Public Property DrugName() As String
        Get
            Return mDrugName
        End Get
        Set(ByVal value As String)
            mDrugName = value
        End Set
    End Property

    Private mQuantity As String
    Public Property Quantity() As String
        Get
            Return mQuantity
        End Get
        Set(ByVal value As String)
            mQuantity = value
        End Set
    End Property

    Private mStatus As String
    Public Property Status() As String
        Get
            Return mStatus
        End Get
        Set(ByVal value As String)
            mStatus = value
        End Set
    End Property

    Private mLastFill As String
    Public Property LastFill() As String
        Get
            Return mLastFill
        End Get
        Set(ByVal value As String)
            mLastFill = value
        End Set
    End Property

    Private mPhysician As String
    Public Property Physician() As String
        Get
            Return mPhysician
        End Get
        Set(ByVal value As String)
            mPhysician = value
        End Set
    End Property

    Private mPharmacy As String
    Public Property Pharmacy() As String
        Get
            Return mPharmacy
        End Get
        Set(ByVal value As String)
            mPharmacy = value
        End Set
    End Property

    Private mNotes As String
    Public Property Notes() As String
        Get
            Return mNotes
        End Get
        Set(ByVal value As String)
            mNotes = value
        End Set
    End Property

    Private mNDC As String
    Public Property NDC() As String
        Get
            Return mNDC
        End Get
        Set(ByVal value As String)
            mNDC = value
        End Set
    End Property

    Private mStructuredSig As String
    Public Property StructuredSig() As String
        Get
            Return mStructuredSig
        End Get
        Set(ByVal value As String)
            mStructuredSig = value
        End Set
    End Property

    Private mRefillQuantity As String
    Public Property RefillQuantity() As String
        Get
            Return mRefillQuantity
        End Get
        Set(ByVal value As String)
            mRefillQuantity = value
        End Set
    End Property

    Private mDiagnosisCode As String
    Public Property DiagnosisCode() As String
        Get
            Return mDiagnosisCode
        End Get
        Set(ByVal value As String)
            mDiagnosisCode = value
        End Set
    End Property

    Private mPriorAuthorizationStatus As String
    Public Property PriorAuthorizationStatus() As String
        Get
            Return mPriorAuthorizationStatus
        End Get
        Set(ByVal value As String)
            mPriorAuthorizationStatus = value
        End Set
    End Property

    Private mPrescriptionNumber As String
    Public Property PrescriptionNumber() As String
        Get
            Return mPrescriptionNumber
        End Get
        Set(ByVal value As String)
            mPrescriptionNumber = value
        End Set
    End Property

    Private mDEASchedule As String
    Public Property DEASchedule() As String
        Get
            Return mDEASchedule
        End Get
        Set(ByVal value As String)
            mDEASchedule = value
        End Set
    End Property

    Private mHistorySource As String
    Public Property HistorySource() As String
        Get
            Return mHistorySource
        End Get
        Set(ByVal value As String)
            mHistorySource = value
        End Set
    End Property

    Private mDaysSupply As String
    Public Property DaysSupply() As String
        Get
            Return mDaysSupply
        End Get
        Set(ByVal value As String)
            mDaysSupply = value
        End Set
    End Property

    Private mDiagnosisQualifier As String
    Public Property DiagnosisQualifier() As String
        Get
            Return mDiagnosisQualifier
        End Get
        Set(ByVal value As String)
            mDiagnosisQualifier = value
        End Set
    End Property


End Class
