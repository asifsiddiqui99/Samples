Imports System.Xml
Imports TraceLogging
Imports EligibilityResponse
Imports System.Configuration

''' <summary>
''' 
''' </summary>
''' <remarks></remarks>
''' 

Public Class EligibilityBL


    Private mPBM() As String
    Private mPBMID() As String
    Private mMailOrderPrescription() As Nullable(Of Boolean)
    Private mPharmacyBenefit() As Nullable(Of Boolean)
    Private mFormularyID() As String
    Private mCoverageListID() As String
    Private mAlternativeID() As String
    Private mCopayID() As String
    Private mClassificationID() As String
    Private mHealthPlan() As String
    Private mHealthPlanID() As String
    Private mChangeFlag() As Nullable(Of Boolean)

    Private mCovered As Boolean ' Indicated whether patient is covered


    Private mPBMCount As Integer
    Private mResponseXml As String

    Private mSuffix() As String
    Private mFirstName() As String
    Private mMiddleName() As String
    Private mLastName() As String
    Private mDOB() As String
    Private mGender() As String
    Private mRelationShip() As RelationShip
    Private mAddress() As String
    Private mAddressLine2() As String
    Private mCity() As String
    Private mState() As String
    Private mZipCode() As String
    Private mPatientIdentifier() As String
    Private mCardHolderID() As String
    Private mBIN() As String
    Private mGroupID() As String
    Private mCardHolderName() As String
    Private mUniqueMemberID() As String
    Private mFamilyUnitNumber() As String
    Private mIdentityCardNumber() As String

    Private mGroupName() As String

    Private mErrorDescription() As String
    Private mAAA As Boolean 'This informs the front end whether there is a triple A segment inside
    Private mMedicationHistoryCardHolderID() As String

    Private mLTC() As Nullable(Of Boolean)
    Private mSpeciality() As Nullable(Of Boolean)

    Private mLTCDescription() As String
    Private mSpecialityDescription() As String
    Public Property InterchangeControlNumber As String
    Public Property IsPatientNotFound As Boolean



#Region "Constructor"

    Public Sub New()
        mPBMCount = 0
        mCovered = True
    End Sub


    Public Sub New(ByVal pParamXml As String)
        mResponseXml = pParamXml
        mCovered = True

    End Sub


#End Region


#Region "Properties"

    Public Property LTCDescription(ByVal pIndex As Integer) As String
        Get
            Return mLTCDescription(pIndex)
        End Get
        Set(ByVal value As String)
            mLTCDescription(pIndex) = value
        End Set
    End Property

    Public Property SpecialityDescription(ByVal pIndex As Integer) As String
        Get
            Return mSpecialityDescription(pIndex)
        End Get
        Set(ByVal value As String)
            mSpecialityDescription(pIndex) = value
        End Set
    End Property

    Public Property LTC(ByVal pIndex As Integer) As Nullable(Of Boolean)
        Get
            Return mLTC(pIndex)
        End Get
        Set(ByVal value As Nullable(Of Boolean))
            mLTC(pIndex) = value
        End Set
    End Property

    Public Property Speciality(ByVal pIndex As Integer) As Nullable(Of Boolean)
        Get
            Return mSpeciality(pIndex)
        End Get
        Set(ByVal value As Nullable(Of Boolean))
            mSpeciality(pIndex) = value
        End Set
    End Property


    Public Property GroupName(ByVal pIndex As Integer) As String
        Get
            Return mGroupName(pIndex)
        End Get
        Set(ByVal value As String)
            mGroupName(pIndex) = value
        End Set
    End Property

    Public Property FamilyUnitNumber(ByVal pIndex As Integer) As String
        Get
            Return FamilyUnitNumber(pIndex)
        End Get
        Set(ByVal value As String)
            FamilyUnitNumber(pIndex) = value
        End Set
    End Property

    Public Property IdentityCardNumber(ByVal pIndex As Integer) As String
        Get
            Return IdentityCardNumber(pIndex)
        End Get
        Set(ByVal value As String)
            IdentityCardNumber(pIndex) = value
        End Set
    End Property

    Public Property UniqueMemberID(ByVal pIndex As Integer) As String
        Get
            Return mUniqueMemberID(pIndex)
        End Get
        Set(ByVal value As String)
            mUniqueMemberID(pIndex) = value
        End Set
    End Property

    Public Property CardHolderName(ByVal pIndex As Integer) As String
        Get
            Return mCardHolderName(pIndex)
        End Get
        Set(ByVal value As String)
            mCardHolderName(pIndex) = value
        End Set
    End Property

    Public Property MedicationHistoryCardHolderID(ByVal pIndex As Integer) As String
        Get
            Return mMedicationHistoryCardHolderID(pIndex)
        End Get
        Set(ByVal value As String)
            mMedicationHistoryCardHolderID(pIndex) = value
        End Set
    End Property

    Public Property AAA() As Boolean
        Get
            Return mAAA
        End Get
        Set(ByVal value As Boolean)
            mAAA = value
        End Set
    End Property

    Public Property ErrorDescription(ByVal pIndex As Integer) As String
        Get
            Return mErrorDescription(pIndex)
        End Get
        Set(ByVal value As String)
            mErrorDescription(pIndex) = value
        End Set
    End Property


    Public Property ZipCode(ByVal pIndex As Integer) As String
        Get
            Return mZipCode(pIndex)
        End Get
        Set(ByVal value As String)
            mZipCode(pIndex) = value
        End Set
    End Property

    Public Property Address(ByVal pIndex As Integer) As String
        Get
            Return mAddress(pIndex)
        End Get
        Set(ByVal value As String)
            mAddress(pIndex) = value
        End Set
    End Property


    Public Property AddressLine2(ByVal pIndex As Integer) As String
        Get
            Return mAddressLine2(pIndex)
        End Get
        Set(ByVal value As String)
            mAddressLine2(pIndex) = value
        End Set
    End Property

    Public Property City(ByVal pIndex As Integer) As String
        Get
            Return mCity(pIndex)
        End Get
        Set(ByVal value As String)
            mCity(pIndex) = value
        End Set
    End Property

    Public Property State(ByVal pIndex) As String
        Get
            Return mState(pIndex)
        End Get
        Set(ByVal value As String)
            mState(pIndex) = value
        End Set
    End Property

    Public Property Suffix(ByVal pIndex As Integer) As String
        Get
            Return mSuffix(pIndex)
        End Get
        Set(ByVal value As String)
            mSuffix(pIndex) = value
        End Set
    End Property

    Public Property ChangeFlag(ByVal pIndex As Integer) As Nullable(Of Boolean)
        Get
            Return mChangeFlag(pIndex)
        End Get
        Set(ByVal value As Nullable(Of Boolean))
            mChangeFlag(pIndex) = value
        End Set
    End Property

    Public Property HealthPlanID(ByVal pIndex As Integer) As String
        Get
            Return mHealthPlanID(pIndex)
        End Get
        Set(ByVal value As String)
            mHealthPlanID(pIndex) = value
        End Set
    End Property

    Public Property HealthPlan(ByVal pIndex As Integer) As String
        Get
            Return mHealthPlan(pIndex)
        End Get
        Set(ByVal value As String)
            mHealthPlan(pIndex) = value
        End Set
    End Property


    Public ReadOnly Property Length() As String
        Get
            Return mPBM.Length
        End Get
    End Property

    Public Property Gender(ByVal pIndex As Integer) As String
        Get
            Return mGender(pIndex)
        End Get
        Set(ByVal value As String)
            mGender(pIndex) = value
        End Set
    End Property

    Public Property FirstName(ByVal pIndex As Integer) As String
        Get
            Return mFirstName(pIndex)
        End Get
        Set(ByVal value As String)
            mFirstName(pIndex) = value
        End Set
    End Property

    Public Property MiddleName(ByVal pIndex As Integer) As String
        Get
            Return mMiddleName(pIndex)
        End Get
        Set(ByVal value As String)
            mMiddleName(pIndex) = value
        End Set
    End Property

    Public Property LastName(ByVal pIndex As Integer) As String
        Get
            Return mLastName(pIndex)
        End Get
        Set(ByVal value As String)
            mLastName(pIndex) = value
        End Set
    End Property

    Public Property DOB(ByVal pIndex As Integer) As String
        Get
            Return mDOB(pIndex)
        End Get
        Set(ByVal value As String)
            mDOB(pIndex) = value
        End Set
    End Property

    Public Property RelationShip(ByVal pIndex As Integer) As RelationShip
        Get
            Return mRelationShip(pIndex)
        End Get
        Set(ByVal value As RelationShip)
            mRelationShip(pIndex) = value
        End Set
    End Property


    Public Property CardHolderID(ByVal pIndex As Integer) As String
        Get
            Return mCardHolderID(pIndex)
        End Get
        Set(ByVal value As String)
            mCardHolderID(pIndex) = value
        End Set
    End Property

    Public Property BIN(ByVal pIndex As Integer) As String
        Get
            Return mBIN(pIndex)
        End Get
        Set(ByVal value As String)
            mBIN(pIndex) = value
        End Set
    End Property

    Public Property PatientIdentifier(ByVal pIndex As Integer) As String
        Get
            Return mPatientIdentifier(pIndex)
        End Get
        Set(ByVal value As String)
            mPatientIdentifier(pIndex) = value
        End Set
    End Property


    Public Property PBM(ByVal pIndex As Integer) As String
        Get
            Return mPBM(pIndex)
        End Get
        Set(ByVal value As String)
            mPBM(pIndex) = value
        End Set
    End Property


    Public Property PBMID(ByVal pIndex As Integer) As String
        Get
            Return mPBMID(pIndex)
        End Get
        Set(ByVal value As String)
            mPBMID(pIndex) = value
        End Set
    End Property


    Public Property ClassificationID(ByVal pIndex As Integer) As String
        Get
            Return mClassificationID(pIndex)
        End Get
        Set(ByVal value As String)
            mClassificationID(pIndex) = value
        End Set
    End Property

    Public Property CopayID(ByVal pIndex As Integer) As String
        Get
            Return mCopayID(pIndex)
        End Get
        Set(ByVal value As String)
            mCopayID(pIndex) = value
        End Set
    End Property

    Public Property AlternativeID(ByVal pIndex As Integer) As String
        Get
            Return mAlternativeID(pIndex)
        End Get
        Set(ByVal value As String)
            mAlternativeID(pIndex) = value
        End Set
    End Property

    Public Property CoverageListID(ByVal pIndex As Integer) As String
        Get
            Return mCoverageListID(pIndex)
        End Get
        Set(ByVal value As String)
            mCoverageListID(pIndex) = value
        End Set
    End Property

    Public Property MailOrderPrescription(ByVal pIndex As Integer) As Nullable(Of Boolean)
        Get
            Return mMailOrderPrescription(pIndex)
        End Get
        Set(ByVal value As Nullable(Of Boolean))
            mMailOrderPrescription(pIndex) = value
        End Set
    End Property

    Public Property PharmacyBenefit(ByVal pIndex As Integer) As Nullable(Of Boolean)
        Get
            Return mPharmacyBenefit(pIndex)
        End Get
        Set(ByVal value As Nullable(Of Boolean))
            mPharmacyBenefit(pIndex) = value
        End Set
    End Property

    Public Property FormularyID(ByVal pIndex As Integer) As String
        Get
            Return mFormularyID(pIndex)
        End Get
        Set(ByVal value As String)
            mFormularyID(pIndex) = value
        End Set
    End Property

    Public ReadOnly Property Covered() As Boolean
        Get
            Return mCovered
        End Get
    End Property

    Public Property GroupID(ByVal pIndex As Integer) As String
        Get
            Return mGroupID(pIndex)
        End Get
        Set(ByVal value As String)
            mGroupID(pIndex) = value
        End Set
    End Property

#End Region


    Public Sub GetEligibility()
        Dim lXmlDocument As New XmlDocument
        Dim lNodeList As XmlNodeList
        Dim lCountLoops As String


        Try

            lXmlDocument.LoadXml(mResponseXml)
            lNodeList = lXmlDocument.DocumentElement.SelectNodes("//Transactions")


            Dim lCount As Integer = lXmlDocument.DocumentElement.SelectNodes("//Transactions").Count

            'Define all the local variables 
            Dim lPBM(lCount - 1) As String
            Dim lPBMID(lCount - 1) As String
            Dim lMailOrderPrescription(lCount - 1) As Nullable(Of Boolean)
            Dim lPharmacyBenefit(lCount - 1) As Nullable(Of Boolean)
            Dim lFormularyID(lCount - 1) As String
            Dim lCoverageListID(lCount - 1) As String
            Dim lAlternativeID(lCount - 1) As String
            Dim lCopayID(lCount - 1) As String
            Dim lClassificationID(lCount - 1) As String
            Dim lHealthPlan(lCount - 1) As String
            Dim lHealthPlanID(lCount - 1) As String
            Dim lChangeFlag(lCount - 1) As Nullable(Of Boolean)


            Dim lSuffix(lCount - 1) As String
            Dim lFirstName(lCount - 1) As String
            Dim lMiddleName(lCount - 1) As String
            Dim lLastName(lCount - 1) As String
            Dim lDOB(lCount - 1) As String
            Dim lGender(lCount - 1) As String
            Dim lRelationShip(lCount - 1) As RelationShip
            Dim lAddress(lCount - 1) As String
            Dim lAddressLine2(lCount - 1) As String
            Dim lZipCode(lCount - 1) As String
            Dim lCity(lCount - 1) As String
            Dim lState(lCount - 1) As String
            Dim lPatientIdentifier(lCount - 1) As String
            Dim lCardHolderID(lCount - 1) As String
            Dim lBIN(lCount - 1) As String
            Dim lGroupID(lCount - 1) As String
            Dim lCardHolderName(lCount - 1) As String
            Dim lUniqueMemberID(lCount - 1) As String
            'End of the definations

            Dim lErrorDescription(lCount - 1) As String
            Dim lMedicationHistoryCardHolderID(lCount - 1) As String


            Dim lAAA As Boolean ''Indicates that a AAA exists in the message
            Dim lAAAIndividual As Boolean
            Dim lNode As New XmlDocument


            lAAAIndividual = False
            lAAA = False

            Dim lIndex As Integer = 0



            For x As Integer = 0 To lCount - 1


                lCountLoops = lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000").Count.ToString




                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Change Log''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                ''Description: Adding the ChangeFlag stuff for AAA message

                ''AAA 41 (found after NM1)
                If lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[1]/L271201000[1]/AAA").Count > 0 Then
                    lAAAIndividual = True
                    'lChangeFlag(x) = Nothing
                    'lErrorDescription(x) = lXmlDocument.DocumentElement.SelectSingleNode("//Transactions[" & (x + 1) & "]/L271200000[1]/L271201000[1]/AAA/RejectReasonCode").InnerText
                End If


                ''AAA 42 (found after HL1)
                If lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[1]/AAA").Count > 0 Then
                    lAAAIndividual = True
                    'lChangeFlag(x) = Nothing
                    'lErrorDescription(x) = lXmlDocument.DocumentElement.SelectSingleNode("//Transactions[" & (x + 1) & "]/L271200000[1]/AAA/RejectReasonCode").InnerText
                End If

                ''AAA 67 (found after NM1)
                If lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[3]/L271201000[1]/AAA").Count > 0 Then
                    lAAAIndividual = True
                    'lChangeFlag(x) = Nothing
                    'lErrorDescription(x) = lXmlDocument.DocumentElement.SelectSingleNode("//Transactions[" & (x + 1) & "]/L271200000[3]/L271201000[1]/AAA/RejectReasonCode").InnerText
                End If


                ''For Generic AAA messages

                lNode.LoadXml(lXmlDocument.DocumentElement.SelectSingleNode("//Transactions[" & (x + 1) & "]").OuterXml)

                If lNode.SelectNodes("//AAA").Count > 0 Then
                    lAAAIndividual = True
                    'lChangeFlag(x) = Nothing
                    'lErrorDescription(x) = lNode.SelectSingleNode("//AAA/RejectReasonCode").InnerText
                End If


                If lAAAIndividual = True Then  ' Means if there is only one record and that too contains AAA
                    'lChangeFlag(x) = Nothing
                    If lCount = 1 Then
                        lAAA = True
                    End If
                End If


                'NOTE : HAVE TO CHANGE THE CHECKS ABOVE

                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

                If Not lAAAIndividual Then


                    lChangeFlag(lIndex) = False



                    ''''This is what i changed to get all the things

                    If lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/NM1/NameFirst").Count = 0 Then
                        lFirstName(lIndex) = ""
                    Else
                        lFirstName(lIndex) = lXmlDocument.DocumentElement.SelectSingleNode("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/NM1/NameFirst").InnerText.ToString
                    End If

                    If lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/NM1/NameSuffix").Count = 0 Then
                        lSuffix(lIndex) = ""
                    Else
                        lSuffix(lIndex) = lXmlDocument.DocumentElement.SelectSingleNode("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/NM1/NameFirst").InnerText.ToString
                    End If

                    If lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/NM1/NameMiddle").Count = 0 Then
                        lMiddleName(lIndex) = ""
                    Else
                        lMiddleName(lIndex) = lXmlDocument.DocumentElement.SelectSingleNode("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/NM1/NameMiddle").InnerText.ToString
                    End If

                    If lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/NM1/NameLastOrOrganisationName").Count = 0 Then
                        lLastName(lIndex) = ""
                    Else
                        lLastName(lIndex) = lXmlDocument.DocumentElement.SelectSingleNode("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/NM1/NameLastOrOrganisationName").InnerText.ToString
                    End If


                    If lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/DMG/DOB").Count = 0 Then
                        lDOB(lIndex) = ""
                    Else
                        lDOB(lIndex) = lXmlDocument.DocumentElement.SelectSingleNode("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/DMG/DOB").InnerText.ToString
                    End If

                    If lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/DMG/GenderCode").Count = 0 Then
                        lGender(lIndex) = ""
                    Else
                        lGender(lIndex) = lXmlDocument.DocumentElement.SelectSingleNode("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/DMG/GenderCode").InnerText.ToString
                    End If

                    If lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/N3/AddressLine1").Count = 0 Then
                        lAddress(lIndex) = ""
                    Else
                        lAddress(lIndex) = lXmlDocument.DocumentElement.SelectSingleNode("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/N3/AddressLine1").InnerText.ToString
                    End If

                    If lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/N3/AddressLine2").Count = 0 Then
                        lAddressLine2(lIndex) = ""
                    Else
                        lAddressLine2(lIndex) = lXmlDocument.DocumentElement.SelectSingleNode("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/N3/AddressLine2").InnerText.ToString
                    End If

                    If lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/N4/CityName").Count = 0 Then
                        lCity(lIndex) = ""
                    Else
                        lCity(lIndex) = lXmlDocument.DocumentElement.SelectSingleNode("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/N4/CityName").InnerText.ToString
                    End If

                    If lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/N4/StateOrProvinceCode").Count = 0 Then
                        lState(lIndex) = ""
                    Else
                        lState(lIndex) = lXmlDocument.DocumentElement.SelectSingleNode("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/N4/StateOrProvinceCode").InnerText.ToString
                    End If

                    If lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/N4/PostalCode").Count = 0 Then
                        lZipCode(lIndex) = ""
                    Else
                        lZipCode(lIndex) = lXmlDocument.DocumentElement.SelectSingleNode("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/N4/PostalCode").InnerText.ToString
                    End If


                    'THIS IS THE PBM PAYER UNIQUE ID THAT WAS SUPPOSED TO BE FROM THE SUBSCRIBER INSTEAD OF THE DEPENDENT (IN CASE THERE IS A 4TH LOOP). THE COUNT LOOP WAS GETTING THE VALUE OF 4 WHERE AS IT WAS SUPPOSED TO FROM 3
                    'If lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/NM1/IdentificationCode").Count = 0 Then
                    If lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[3]/L271201000[1]/NM1/IdentificationCode").Count = 0 Then
                        lUniqueMemberID(lIndex) = ""
                    Else
                        lUniqueMemberID(lIndex) = lXmlDocument.DocumentElement.SelectSingleNode("//Transactions[" & (x + 1) & "]/L271200000[3]/L271201000[1]/NM1/IdentificationCode").InnerText.ToString
                    End If
                    'End of this  part




                    If lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[1]/L271201000/NM1/NameLastOrOrganisationName").Count > 0 Then
                        lPBM(lIndex) = lXmlDocument.DocumentElement.SelectSingleNode("//Transactions[" & (x + 1) & "]/L271200000[1]/L271201000/NM1/NameLastOrOrganisationName").InnerText
                    Else
                        lPBM(lIndex) = ""
                    End If

                    If lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[1]/L271201000/NM1/IdentificationCode").Count > 0 Then
                        lPBMID(lIndex) = lXmlDocument.DocumentElement.SelectSingleNode("//Transactions[" & (x + 1) & "]/L271200000[1]/L271201000/NM1/IdentificationCode").InnerText
                    Else
                        lPBMID(lIndex) = ""
                    End If


                    If lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[3]/L271201000/NM1/IdentificationCode").Count = 0 Then
                        lPatientIdentifier(lIndex) = ""
                    Else
                        lPatientIdentifier(lIndex) = lXmlDocument.DocumentElement.SelectSingleNode("//Transactions[" & (x + 1) & "]/L271200000[3]/L271201000/NM1/IdentificationCode").InnerText
                    End If


                    If lCountLoops = 3 Then
                        lRelationShip(lIndex) = RxHub.RelationShip.Member

                        If Not lAAAIndividual Then
                            If lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/INS/MaintenanceTypeCode").Count > 0 _
                             And lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/INS/MaintenanceReasonCode").Count > 0 Then

                                If lXmlDocument.DocumentElement.SelectSingleNode("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/INS/MaintenanceTypeCode").InnerText.Equals("001") _
                                And lXmlDocument.DocumentElement.SelectSingleNode("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/INS/MaintenanceReasonCode").InnerText.Equals("25") Then
                                    lChangeFlag(lIndex) = True
                                Else
                                    lChangeFlag(lIndex) = False
                                End If
                            Else
                                lChangeFlag(lIndex) = False
                            End If
                        End If

                    ElseIf lCountLoops = 4 Then
                        If lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/INS/IndividualRelationshipCode").Count = 0 Then
                            lRelationShip(lIndex) = RxHub.RelationShip.Other
                        Else

                            Select Case lXmlDocument.DocumentElement.SelectSingleNode("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/INS/IndividualRelationshipCode").InnerText.ToString
                                Case "01" 'Spouse
                                    lRelationShip(lIndex) = RxHub.RelationShip.Spouse
                                Case "18" 'Self
                                    lRelationShip(lIndex) = RxHub.RelationShip.Member
                                Case "19" 'Child
                                    lRelationShip(lIndex) = RxHub.RelationShip.ChildOrDependant
                                Case "21" 'Unknown
                                    lRelationShip(lIndex) = RxHub.RelationShip.Unknown
                                Case "34" 'Other
                                    lRelationShip(lIndex) = RxHub.RelationShip.Other
                            End Select

                        End If





                        If lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/INS/MaintenanceTypeCode").Count > 0 _
                         And lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/INS/MaintenanceReasonCode").Count > 0 Then

                            If lXmlDocument.DocumentElement.SelectSingleNode("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/INS/MaintenanceTypeCode").InnerText.Equals("001") _
                            And lXmlDocument.DocumentElement.SelectSingleNode("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/INS/MaintenanceReasonCode").InnerText.Equals("25") Then
                                lChangeFlag(lIndex) = True
                            Else
                                lChangeFlag(lIndex) = False
                            End If
                        Else
                            lChangeFlag(lIndex) = False
                        End If

                    End If







                    'This part finds out whether the patient is covered or not
                    If lPBM(0).Equals("RXHUB") Then
                        'Patient is not covered
                        'No use checking everything
                        mFirstName = lFirstName
                        mMiddleName = lMiddleName
                        mLastName = lLastName
                        mDOB = lDOB
                        mRelationShip = lRelationShip
                        mPatientIdentifier = lPatientIdentifier
                        mCardHolderID = lCardHolderID
                        mBIN = lBIN
                        mGroupID = lGroupID
                        mCardHolderName = lCardHolderName
                        mUniqueMemberID = lUniqueMemberID
                        mGender = lGender

                        mSuffix = lSuffix
                        mAddress = lAddress
                        mAddressLine2 = lAddressLine2
                        mCity = lCity
                        mState = lState
                        mZipCode = lZipCode


                        mCovered = False
                        mChangeFlag = lChangeFlag
                        Exit Sub
                    End If


                    If lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/L270201100[1]/EB/EligibilityOrBenefitInformation").Count > 0 Then

                        Select Case lXmlDocument.DocumentElement.SelectSingleNode("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/L270201100[1]/EB/EligibilityOrBenefitInformation").InnerText

                            Case "1"
                                lPharmacyBenefit(lIndex) = True
                            Case "6"
                                lPharmacyBenefit(lIndex) = False
                            Case "V"
                                lPharmacyBenefit(lIndex) = Nothing
                            Case Else
                                lPharmacyBenefit(lIndex) = Nothing

                        End Select

                    Else
                        lPharmacyBenefit(lIndex) = False
                    End If



                    If lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/L270201100[2]/EB/EligibilityOrBenefitInformation").Count > 0 Then

                        Select Case lXmlDocument.DocumentElement.SelectSingleNode("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/L270201100[2]/EB/EligibilityOrBenefitInformation").InnerText

                            Case "1"
                                lMailOrderPrescription(lIndex) = True
                            Case "6"
                                lMailOrderPrescription(lIndex) = False

                            Case "V"
                                lMailOrderPrescription(lIndex) = Nothing
                            Case Else
                                lMailOrderPrescription(lIndex) = Nothing

                        End Select

                    Else
                        lMailOrderPrescription(lIndex) = False
                    End If





                    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Change Log''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    ''Faraz Ahmed
                    ' We were sending the wrong Card ID 

                    ''Second time changed to incorpprate medication History Card holder ID

                    'This is the cardholder Id
                    If lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[3]/L271201000[1]/NM1/IdentificationCode").Count > 0 Then
                        lMedicationHistoryCardHolderID(lIndex) = lXmlDocument.DocumentElement.SelectSingleNode("//Transactions[" & (x + 1) & "]/L271200000[3]/L271201000[1]/NM1/IdentificationCode").InnerText
                    End If

                    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''




                    For z As Integer = 0 To lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/REF").Count - 1

                        Select Case lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/REF/ReferenceIdentificationQualifier")(z).InnerText
                            Case "IF"
                                lFormularyID(lIndex) = lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/REF/ReferenceIdentification")(z).InnerText
                                If Not lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/REF[" & z + 1 & "]/Description").Count = 0 Then
                                    lAlternativeID(lIndex) = lXmlDocument.DocumentElement.SelectSingleNode("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/REF[" & z + 1 & "]/Description").InnerText
                                End If

                            Case "IG"
                                'lCopayID(x) = lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/REF/ReferenceIdentification")(z).InnerText
                                'lCopayID(lIndex) = lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/REF/ReferenceIdentification")(z).NextSibling.InnerText

                                'CHANGED THIS TO INCLUDE THE IF...ELSE CHECK BECAUSE THE XML WAS AT TIMES RETURNING THE COPAY ID AFTER REFERENCEIDENTIFICATION NODE AND SOMETIMES IN THE REFRENCEIDENTIFICATION NODE

                                If lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/REF/ReferenceIdentification")(z).NextSibling Is Nothing Then
                                    lCopayID(lIndex) = lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/REF/ReferenceIdentification")(z).InnerText
                                Else
                                    lCopayID(lIndex) = lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/REF/ReferenceIdentification")(z).NextSibling.InnerText
                                End If

                            Case "1L"
                                'lCoverageListID(x) = lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/REF/ReferenceIdentification")(z).InnerText

                                If lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/REF/ReferenceIdentification")(z).NextSibling Is Nothing Then
                                    lCoverageListID(lIndex) = lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/REF/ReferenceIdentification")(z).InnerText
                                Else
                                    lCoverageListID(lIndex) = lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/REF/ReferenceIdentification")(z).NextSibling.InnerText
                                End If

                            Case "18" 'indicates HealthPlan
                                lHealthPlanID(lIndex) = lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/REF/ReferenceIdentification")(z).InnerText

                                If Not lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/REF[" & z + 1 & "]/Description").Count = 0 Then
                                    lHealthPlan(lIndex) = lXmlDocument.DocumentElement.SelectSingleNode("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/REF[" & z + 1 & "]/Description").InnerText
                                End If


                            Case "1W"   'This is the cardholder Id (From code 1W)
                                lCardHolderID(lIndex) = lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/REF/ReferenceIdentification")(z).InnerText

                                If Not lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/REF[" & z + 1 & "]/Description").Count = 0 Then
                                    lCardHolderName(lIndex) = lXmlDocument.DocumentElement.SelectSingleNode("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/REF[" & z + 1 & "]/Description").InnerText
                                End If


                            Case "N6"   'This is the BIN location number to be used in the NEW Rx
                                lBIN(lIndex) = lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/REF/ReferenceIdentification")(z).InnerText
                            Case "6P"
                                lGroupID(lIndex) = lXmlDocument.DocumentElement.SelectNodes("//Transactions[" & (x + 1) & "]/L271200000[" & lCountLoops & "]/L271201000[1]/REF/ReferenceIdentification")(z).InnerText

                        End Select
                    Next

                    lIndex += 1

                End If


                lAAAIndividual = False ' Reset the value to ensure the next loop does not get affected
            Next


            'Now assign all the local variable to the global ones
            mPBM = lPBM
            mPBMID = lPBMID
            mMailOrderPrescription = lMailOrderPrescription
            mPharmacyBenefit = lPharmacyBenefit
            mFormularyID = lFormularyID
            mCoverageListID = lCoverageListID
            mAlternativeID = lAlternativeID
            mCopayID = lCopayID
            mClassificationID = lClassificationID
            mHealthPlan = lHealthPlan
            mHealthPlanID = lHealthPlanID
            mChangeFlag = lChangeFlag


            mFirstName = lFirstName
            mMiddleName = lMiddleName
            mLastName = lLastName
            mDOB = lDOB
            mRelationShip = lRelationShip
            mPatientIdentifier = lPatientIdentifier
            mCardHolderID = lCardHolderID
            mGender = lGender
            mBIN = lBIN
            mGroupID = lGroupID
            mCardHolderName = lCardHolderName
            mUniqueMemberID = lUniqueMemberID

            mSuffix = lSuffix
            mAddress = lAddress
            mAddressLine2 = lAddressLine2
            mCity = lCity
            mState = lState
            mZipCode = lZipCode

            mErrorDescription = lErrorDescription
            mAAA = lAAA
            mMedicationHistoryCardHolderID = lMedicationHistoryCardHolderID

        Catch ex As Exception
            mCovered = False
            ErrorLogMethods.LogError(ex, "RxHubLibrary\BLL\EligibilityBL.GetEligibility()")
        End Try

    End Sub


    Public Sub GetEligibilityFromDLLObject(ByVal pEligibilityResponse As MsgInterchange)


        Dim lFG As GrpInterchangeFunctionalGroup
        Dim lEligibilityDB As New EligibilityDB
        Dim lPBMName As String = ""

        Try



            If pEligibilityResponse.FunctionalGroup.Count = 0 Then
                mCovered = False
                Exit Sub
            End If

            InterchangeControlNumber = pEligibilityResponse.ISA.InterchangeControlNumber.Value

            For i As Int32 = 0 To pEligibilityResponse.FunctionalGroup.Count - 1
                lFG = pEligibilityResponse.FunctionalGroup.Item(i)

                Dim lCount As Integer = lFG.transactions.Count

                If lCount = 0 Then
                    mCovered = False
                    Exit Sub
                End If

                'Define all the local variables 
                Dim lPBM(lCount - 1) As String
                Dim lPBMID(lCount - 1) As String
                Dim lMailOrderPrescription(lCount - 1) As Nullable(Of Boolean)
                Dim lPharmacyBenefit(lCount - 1) As Nullable(Of Boolean)
                Dim lFormularyID(lCount - 1) As String
                Dim lCoverageListID(lCount - 1) As String
                Dim lAlternativeID(lCount - 1) As String
                Dim lCopayID(lCount - 1) As String
                Dim lClassificationID(lCount - 1) As String
                Dim lHealthPlan(lCount - 1) As String
                Dim lHealthPlanID(lCount - 1) As String
                Dim lChangeFlag(lCount - 1) As Nullable(Of Boolean)


                Dim lSuffix(lCount - 1) As String
                Dim lFirstName(lCount - 1) As String
                Dim lMiddleName(lCount - 1) As String
                Dim lLastName(lCount - 1) As String
                Dim lDOB(lCount - 1) As String
                Dim lGender(lCount - 1) As String
                Dim lRelationShip(lCount - 1) As RelationShip
                Dim lAddress(lCount - 1) As String
                Dim lAddressLine2(lCount - 1) As String
                Dim lZipCode(lCount - 1) As String
                Dim lCity(lCount - 1) As String
                Dim lState(lCount - 1) As String
                Dim lPatientIdentifier(lCount - 1) As String
                Dim lCardHolderID(lCount - 1) As String
                Dim lBIN(lCount - 1) As String
                Dim lGroupID(lCount - 1) As String
                Dim lCardHolderName(lCount - 1) As String
                Dim lUniqueMemberID(lCount - 1) As String

                'ADDITIONAL FIELDS 5010
                Dim lFamilyUnitNumber(lCount - 1) As String
                Dim lIdentityCardNumber(lCount - 1) As String
                Dim lGroupName(lCount - 1) As String
                Dim lLTC(lCount - 1) As Nullable(Of Boolean)
                Dim lSpeciality(lCount - 1) As Nullable(Of Boolean)

                Dim lLTCDescription(lCount - 1) As String
                Dim lSpecialityDescription(lCount - 1) As String
                'END ADDITIONAL FIELDS

                'End of the definations

                Dim lErrorDescription(lCount - 1) As String
                Dim lMedicationHistoryCardHolderID(lCount - 1) As String


                Dim lAAA As Boolean ''Indicates that a AAA exists in the message
                Dim lAAAIndividual As Boolean


                lAAAIndividual = False
                lAAA = False

                Dim lIndex As Integer = 0


                Dim L2000A As RepGrp271L2000A_271
                Dim L2000B As RepGrp271L2000B_271
                Dim L2000C As RepGrp271L2000C_271
                Dim L2000D As RepGrp271L2000D_271

                Dim lSubscriberNM1 As SegNM1
                Dim lSubscriberN3 As SegN3
                Dim lSubscriberN4 As SegN4
                Dim lSubscriberDMG As SegDMG


                For j As Int32 = 0 To lCount - 1 'THESE ARE THE TRANSACTIONS

                    Dim lGeneric As IMessage = lFG.transactions.Item(j)
                    Dim lSegmentName As String = lGeneric.GetName
                    Dim lMSG271 As Msg271

                    If Not lSegmentName.Equals("271") Then
                        Return
                    End If


                    lMSG271 = lGeneric


                    ''AAA 41 (found after NM1 2100A)
                    If Not lMSG271.L2000A_271.Item(0).L2100A_271.AAA.IsEmpty Then
                        lAAAIndividual = True
                    End If


                    ''AAA 42 (found after HL1 2000A)
                    If Not lMSG271.L2000A_271.Item(0).AAA.IsEmpty Then
                        lAAAIndividual = True
                    End If

                    ''AAA 67 (found after NM1)
                    If Not lMSG271.L2000A_271.Item(0).L2000B_271.Item(0).L2000C_271.Item(0).L2000D_271.IsEmpty Then
                        If Not lMSG271.L2000A_271.Item(0).L2000B_271.Item(0).L2000C_271.Item(0).L2000D_271.Item(0).L2100D_271.AAA.IsEmpty Then
                            lAAAIndividual = True
                        End If
                    End If



                    '' For Patient Not Found
                    Dim lRejectReasonCode As String
                    If Not lMSG271.L2000A_271.Item(0).L2000B_271.Item(0).L2000C_271.IsEmpty Then
                        If Not lMSG271.L2000A_271.Item(0).L2000B_271.Item(0).L2000C_271.Item(0).L2100C_271.AAA.IsEmpty Then
                            lRejectReasonCode = lMSG271.L2000A_271.Item(0).L2000B_271.Item(0).L2000C_271.Item(0).L2100C_271.AAA.Item(0).RejectReasonCode.Value
                            If lRejectReasonCode = "75" Or lRejectReasonCode = "67" Then
                                IsPatientNotFound = True
                            End If
                        End If
                    End If
                    '' End Patient NotFound

                    ''For Generic AAA messages

                    'lNode.LoadXml(lXmlDocument.DocumentElement.SelectSingleNode("//Transactions[" & (x + 1) & "]").OuterXml)

                    'If lMSG271.L2000A_271.Item(0).AAA Then
                    '    lAAAIndividual = True
                    '    'lChangeFlag(x) = Nothing
                    '    'lErrorDescription(x) = lNode.SelectSingleNode("//AAA/RejectReasonCode").InnerText
                    'End If


                    If lAAAIndividual = True Then  ' Means if there is only one record and that too contains AAA
                        lChangeFlag(j) = Nothing
                        If lCount = 1 Then
                            lAAA = True
                        End If
                    End If



                    If Not lAAAIndividual Then

                        lChangeFlag(lIndex) = False


                        L2000A = lMSG271.L2000A_271
                        L2000B = L2000A.Item(0).L2000B_271
                        L2000C = L2000B.Item(0).L2000C_271
                        L2000D = L2000C.Item(0).L2000D_271

                        If L2000D.IsEmpty Then
                            lSubscriberNM1 = L2000C.Item(0).L2100C_271.NM1
                            lSubscriberN3 = L2000C.Item(0).L2100C_271.N3
                            lSubscriberN4 = L2000C.Item(0).L2100C_271.N4
                            lSubscriberDMG = L2000C.Item(0).L2100C_271.DMG
                        Else
                            lSubscriberNM1 = L2000D.Item(0).L2100D_271.NM1
                            lSubscriberN3 = L2000D.Item(0).L2100D_271.N3
                            lSubscriberN4 = L2000D.Item(0).L2100D_271.N4
                            lSubscriberDMG = L2000D.Item(0).L2100D_271.DMG
                        End If

                        'Card Holder ID 

                        Try
                            If L2000C.Item(0).L2100C_271.REF.Item(0).ReferenceIdentificationQualifier IsNot Nothing AndAlso L2000C.Item(0).L2100C_271.REF.Item(0).ReferenceIdentificationQualifier.Value = "HJ" Then
                                lCardHolderID(lIndex) = L2000C.Item(0).L2100C_271.REF.Item(0).ReferenceIdentification.Value
                            End If
                        Catch ex As Exception

                        End Try
                        

                        'End CardHolder Id 






                        lFirstName(lIndex) = lSubscriberNM1.NameFirst.Value
                        lSuffix(lIndex) = lSubscriberNM1.NameSuffix.Value
                        lMiddleName(lIndex) = lSubscriberNM1.NameMiddle.Value
                        lLastName(lIndex) = lSubscriberNM1.NameLastOrOrganizationName.Value
                        lDOB(lIndex) = lSubscriberDMG.DateTimePeriod.Value
                        lGender(lIndex) = lSubscriberDMG.GenderCode.Value
                        lAddress(lIndex) = lSubscriberN3.AddressInformation.Value
                        lAddressLine2(lIndex) = lSubscriberN3.AddressInformation2.Value
                        lCity(lIndex) = lSubscriberN4.CityName.Value
                        lState(lIndex) = lSubscriberN4.StateOrProvinceCode.Value
                        lZipCode(lIndex) = lSubscriberN4.PostalCode.Value

                        'NOTE:THIS IS THE PBM PAYER UNIQUE ID THAT WAS SUPPOSED TO BE FROM THE SUBSCRIBER INSTEAD OF THE DEPENDENT (IN CASE THERE IS A 4TH LOOP). THE COUNT LOOP WAS GETTING THE VALUE OF 4 WHERE AS IT WAS SUPPOSED TO FROM 3
                        lUniqueMemberID(lIndex) = L2000C.Item(0).L2100C_271.NM1.IdentificationCode.Value

                        If ConfigurationManager.AppSettings("PBMJugar").ToUpper = "TRUE" Then
                            lEligibilityDB.UpdatePBMName(L2000A.Item(0).L2100A_271.NM1.IdentificationCode.Value, L2000A.Item(0).L2100A_271.NM1.NameLastOrOrganizationName.Value)
                        End If
                        'lPBMName = lEligibilityDB.GetPBMName(L2000A.Item(0).L2100A_271.NM1.IdentificationCode.Value)    'Get PBM Name From Database 
                        'If lPBMName <> "" Then
                        'lPBM(lIndex) = lPBMName
                        'Else
                        lPBM(lIndex) = L2000A.Item(0).L2100A_271.NM1.NameLastOrOrganizationName.Value
                        'End If

                        lPBMID(lIndex) = L2000A.Item(0).L2100A_271.NM1.IdentificationCode.Value

                        'NOTE: IS THERE A DIFFERENCE BETWEEN PATIENTIDENTIFIER AND UNIQUE MEMBER ID
                        lPatientIdentifier(lIndex) = L2000C.Item(0).L2100C_271.NM1.IdentificationCode.Value



                        'NOTE:CHECK IF THIS IS EQUAL TO LCOUNTLOOPS
                        If L2000D.IsEmpty Then
                            lRelationShip(lIndex) = RxHub.RelationShip.Member

                            If Not lAAAIndividual Then
                                If Not L2000C.Item(0).L2100C_271.INS.IsEmpty Then

                                    If L2000C.Item(0).L2100C_271.INS.MaintenanceTypeCode.Value.Equals("001") And L2000C.Item(0).L2100C_271.INS.MaintenanceReasonCode.Value.Equals("25") Then
                                        lChangeFlag(lIndex) = True
                                    Else
                                        lChangeFlag(lIndex) = False
                                    End If
                                Else
                                    lChangeFlag(lIndex) = False
                                End If
                            End If


                        Else
                            If L2000D.Item(0).L2100D_271.INS.IndividualRelationshipCode.IsEmpty Then
                                lRelationShip(lIndex) = RxHub.RelationShip.Other
                            Else

                                Select Case L2000D.Item(0).L2100D_271.INS.IndividualRelationshipCode.Value
                                    Case "01" 'Spouse
                                        lRelationShip(lIndex) = RxHub.RelationShip.Spouse
                                    Case "18" 'Self
                                        lRelationShip(lIndex) = RxHub.RelationShip.Member
                                    Case "19" 'Child
                                        lRelationShip(lIndex) = RxHub.RelationShip.ChildOrDependant
                                    Case "21" 'Unknown
                                        lRelationShip(lIndex) = RxHub.RelationShip.Unknown
                                    Case "34" 'Other
                                        lRelationShip(lIndex) = RxHub.RelationShip.Other
                                End Select

                            End If


                            If Not L2000D.Item(0).L2100D_271.INS.IsEmpty Then

                                If L2000D.Item(0).L2100D_271.INS.MaintenanceTypeCode.Value.Equals("001") And L2000D.Item(0).L2100D_271.INS.MaintenanceReasonCode.Value.Equals("25") Then
                                    lChangeFlag(lIndex) = True
                                Else
                                    lChangeFlag(lIndex) = False
                                End If
                            Else
                                lChangeFlag(lIndex) = False
                            End If

                        End If



                        'This part finds out whether the patient is covered or not
                        If lPBM(0).Equals("SURESCRIPTS LLC") Then
                            'Patient is not covered
                            'No use checking everything
                            mFirstName = lFirstName
                            mMiddleName = lMiddleName
                            mLastName = lLastName
                            mDOB = lDOB
                            mRelationShip = lRelationShip
                            mPatientIdentifier = lPatientIdentifier
                            mCardHolderID = lCardHolderID
                            mBIN = lBIN
                            mGroupID = lGroupID
                            mCardHolderName = lCardHolderName
                            mUniqueMemberID = lUniqueMemberID
                            mGender = lGender

                            mSuffix = lSuffix
                            mAddress = lAddress
                            mAddressLine2 = lAddressLine2
                            mCity = lCity
                            mState = lState
                            mZipCode = lZipCode

                            mIdentityCardNumber = lIdentityCardNumber
                            mFamilyUnitNumber = lFamilyUnitNumber
                            mGroupName = lGroupName

                            mLTC = lLTC
                            mSpeciality = lSpeciality
                            mLTCDescription = lLTCDescription
                            mSpecialityDescription = lLTCDescription


                            mCovered = False
                            mChangeFlag = lChangeFlag
                            Exit Sub
                        End If



                        If L2000D.IsEmpty Then 'MEANS NO DEPENDANT LOOP SO PICK THE ELIGIBILITY FROM THE SUBSCRIBER LOOP

                            If L2000C.Item(0).L2100C_271.AAA.IsEmpty Then

                                If Not L2000C.Item(0).L2100C_271.L2110C_271.Item(0).EB.IsEmpty Then

                                    For x As Integer = 0 To L2000C.Item(0).L2100C_271.L2110C_271.Count - 1

                                        If L2000C.Item(0).L2100C_271.L2110C_271.Item(x).EB.ServiceTypeCode.Count = 0 Then
                                            Dim lTempResult As Nullable(Of Boolean) = False


                                            Select Case L2000C.Item(0).L2100C_271.L2110C_271.Item(x).EB.EligibilityOrBenefitInformationCode.Value

                                                Case "1"
                                                    lTempResult = True
                                                Case "6"
                                                    lTempResult = False
                                                Case "I"
                                                    lTempResult = False
                                                Case "V"
                                                    lTempResult = Nothing
                                                Case Else
                                                    'lPharmacyBenefit(lIndex) = Nothing

                                            End Select


                                            Select Case L2000C.Item(0).L2100C_271.L2110C_271.Item(x).MSG.Item(0).FreeFormMessageText.Value
                                                Case "LTC"
                                                    lLTC(lIndex) = lTempResult
                                                    lLTCDescription(lIndex) = L2000C.Item(0).L2100C_271.L2110C_271.Item(x).EB.PlanCoverageDescription.Value
                                                Case "SPECIALTY PHARMACY"
                                                    lSpeciality(lIndex) = lTempResult
                                                    lSpecialityDescription(lIndex) = L2000C.Item(0).L2100C_271.L2110C_271.Item(x).EB.PlanCoverageDescription.Value
                                                Case Else

                                            End Select


                                            Continue For
                                        End If


                                        If L2000C.Item(0).L2100C_271.L2110C_271.Item(x).EB.ServiceTypeCode.Item(0).Value.Equals("30") Then
                                            lHealthPlan(lIndex) = L2000C.Item(0).L2100C_271.L2110C_271.Item(x).EB.PlanCoverageDescription.Value
                                        End If

                                    
                                        For eb As Integer = 0 To L2000C.Item(0).L2100C_271.L2110C_271.Item(x).EB.ServiceTypeCode.Count - 1

                                            If L2000C.Item(0).L2100C_271.L2110C_271.Item(x).EB.ServiceTypeCode.Item(eb).Value.Equals("88") Then
                                                Select Case L2000C.Item(0).L2100C_271.L2110C_271.Item(x).EB.EligibilityOrBenefitInformationCode.Value

                                                    Case "1"
                                                        lPharmacyBenefit(lIndex) = True
                                                    Case "6"
                                                        lPharmacyBenefit(lIndex) = False
                                                    Case "I"
                                                        lPharmacyBenefit(lIndex) = False
                                                    Case "V"
                                                        lPharmacyBenefit(lIndex) = Nothing
                                                    Case Else
                                                        'lPharmacyBenefit(lIndex) = Nothing

                                                End Select

                                            End If

                                            If L2000C.Item(0).L2100C_271.L2110C_271.Item(x).EB.ServiceTypeCode.Item(eb).Value.Equals("90") Then
                                                Select Case L2000C.Item(0).L2100C_271.L2110C_271.Item(x).EB.EligibilityOrBenefitInformationCode.Value

                                                    Case "1"
                                                        lMailOrderPrescription(lIndex) = True
                                                    Case "6"
                                                        lMailOrderPrescription(lIndex) = False
                                                    Case "I"
                                                        lMailOrderPrescription(lIndex) = False
                                                    Case "V"
                                                        lMailOrderPrescription(lIndex) = Nothing
                                                    Case Else
                                                        'lMailOrderPrescription(lIndex) = Nothing

                                                End Select

                                            End If

                                        Next


                                    Next

                                End If


                            Else

                                lErrorDescription(lIndex) = "Error"
                                lAAAIndividual = True

                            End If


                        Else
                            If L2000D.Item(0).L2100D_271.AAA.IsEmpty Then

                                If Not L2000D.Item(0).L2100D_271.L2110D_271.Item(0).EB.IsEmpty Then
                                    For x As Integer = 0 To L2000D.Item(0).L2100D_271.L2110D_271.Count - 1


                                        If L2000D.Item(0).L2100D_271.L2110D_271.Item(x).EB.ServiceTypeCode.Count = 0 Then
                                            Dim lTempResult As Nullable(Of Boolean) = False



                                            Select Case L2000D.Item(0).L2100D_271.L2110D_271.Item(x).EB.EligibilityOrBenefitInformationCode.Value

                                                Case "1"
                                                    lTempResult = True
                                                Case "6"
                                                    lTempResult = False
                                                Case "I"
                                                    lTempResult = False
                                                Case "V"
                                                    lTempResult = Nothing
                                                Case Else
                                                    'lPharmacyBenefit(lIndex) = Nothing

                                            End Select



                                            Select Case L2000D.Item(0).L2100D_271.L2110D_271.Item(x).MSG.Item(0).FreeFormMessageText.Value
                                                Case "LTC"
                                                    lLTC(lIndex) = lTempResult
                                                    lLTCDescription(lIndex) = L2000D.Item(0).L2100D_271.L2110D_271.Item(x).EB.PlanCoverageDescription.Value
                                                Case "SPECIALTY PHARMACY"
                                                    lSpeciality(lIndex) = lTempResult
                                                    lSpecialityDescription(lIndex) = L2000D.Item(0).L2100D_271.L2110D_271.Item(x).EB.PlanCoverageDescription.Value
                                                Case Else

                                            End Select




                                            Continue For
                                        End If

                                        If L2000D.Item(0).L2100D_271.L2110D_271.Item(x).EB.ServiceTypeCode.Item(0).Value.Equals("30") Then
                                            lHealthPlan(lIndex) = L2000D.Item(0).L2100D_271.L2110D_271.Item(x).EB.PlanCoverageDescription.Value
                                        End If

                                        For eb As Integer = 0 To L2000D.Item(0).L2100D_271.L2110D_271.Item(x).EB.ServiceTypeCode.Count - 1
                                            If L2000D.Item(0).L2100D_271.L2110D_271.Item(x).EB.ServiceTypeCode.Item(eb).Value.Equals("88") Then
                                                Select Case L2000D.Item(0).L2100D_271.L2110D_271.Item(x).EB.EligibilityOrBenefitInformationCode.Value

                                                    Case "1"
                                                        lPharmacyBenefit(lIndex) = True
                                                    Case "6"
                                                        lPharmacyBenefit(lIndex) = False
                                                    Case "I"
                                                        lPharmacyBenefit(lIndex) = False
                                                    Case "V"
                                                        lPharmacyBenefit(lIndex) = Nothing
                                                    Case Else
                                                        'lPharmacyBenefit(lIndex) = Nothing

                                                End Select

                                            End If


                                            If L2000D.Item(0).L2100D_271.L2110D_271.Item(x).EB.ServiceTypeCode.Item(eb).Value.Equals("90") Then
                                                Select Case L2000D.Item(0).L2100D_271.L2110D_271.Item(x).EB.EligibilityOrBenefitInformationCode.Value

                                                    Case "1"
                                                        lMailOrderPrescription(lIndex) = True
                                                    Case "6"
                                                        lMailOrderPrescription(lIndex) = False
                                                    Case "I"
                                                        lMailOrderPrescription(lIndex) = False
                                                    Case "V"
                                                        lMailOrderPrescription(lIndex) = Nothing
                                                    Case Else
                                                        ' lMailOrderPrescription(lIndex) = Nothing

                                                End Select

                                            End If
                                        Next




                                    Next
                                End If

                            Else


                                lErrorDescription(lIndex) = "Error"
                                lAAAIndividual = True

                            End If
                        End If


                        'NOTE: THIS IS ALSO SAME AS UNIQUE MEMBER ID
                        lMedicationHistoryCardHolderID(lIndex) = L2000C.Item(0).L2100C_271.NM1.IdentificationCode.Value

                        If lAAAIndividual = True Then
                            Continue For
                        End If


                        Dim lRef As RepSegREF
                        Dim lRefCount As Integer = 0

                        'AM REPEATING THE PBM AND PBMID BECAUSE THERE IS A CHECK THAT OUTLINES WHO THE SENDER IS AND EXITS THE FUNCTION
                        If L2000D.IsEmpty Then
                            lRef = L2000C.Item(0).L2100C_271.L2110C_271.Item(0).REF
                            lRefCount = L2000C.Item(0).L2100C_271.L2110C_271.Item(0).REF.Count

                        Else
                            lRef = L2000D.Item(0).L2100D_271.L2110D_271.Item(0).REF
                            lRefCount = L2000D.Item(0).L2100D_271.L2110D_271.Item(0).REF.Count

                        End If


                        For z As Integer = 0 To lRefCount - 1

                            Select Case lRef.Item(z).ReferenceIdentificationQualifier.Value
                                Case "FO"
                                    lFormularyID(lIndex) = lRef.Item(z).ReferenceIdentification.Value
                                Case "ALS"
                                    lAlternativeID(lIndex) = lRef.Item(z).ReferenceIdentification.Value
                                Case "IG"
                                    lCopayID(lIndex) = lRef.Item(z).ReferenceIdentification.Value
                                Case "CLI"
                                    lCoverageListID(lIndex) = lRef.Item(z).ReferenceIdentification.Value
                                Case "18" 'indicates HealthPlan
                                    lHealthPlanID(lIndex) = lRef.Item(z).ReferenceIdentification.Value

                                    If Not lRef.Item(z).Description.Value.Equals("") Then
                                        lHealthPlan(lIndex) = lRef.Item(z).Description.Value
                                    End If

                                Case "1W"
                                    lCardHolderID(lIndex) = lRef.Item(z).ReferenceIdentification.Value

                                    If Not lRef.Item(z).Description.Value.Equals("") Then
                                        lCardHolderName(lIndex) = lRef.Item(z).Description.Value
                                    End If

                                Case "N6"
                                    lBIN(lIndex) = lRef.Item(z).ReferenceIdentification.Value
                                Case "6P"
                                    lGroupID(lIndex) = lRef.Item(z).ReferenceIdentification.Value

                                    If Not lRef.Item(z).Description.IsEmpty Then
                                        lGroupName(lIndex) = lRef.Item(z).Description.Value
                                    End If

                                Case "HJ"
                                    lIdentityCardNumber(lIndex) = lRef.Item(z).ReferenceIdentification.Value
                                Case "49"
                                    lFamilyUnitNumber(lIndex) = lRef.Item(z).ReferenceIdentification.Value

                            End Select
                        Next

                        lIndex += 1

                    End If

                    lAAAIndividual = False ' Reset the value to ensure the next loop does not get affected
                Next


                'Now assign all the local variable to the global ones
                mPBM = lPBM
                mPBMID = lPBMID
                mMailOrderPrescription = lMailOrderPrescription
                mPharmacyBenefit = lPharmacyBenefit
                mFormularyID = lFormularyID
                mCoverageListID = lCoverageListID
                mAlternativeID = lAlternativeID
                mCopayID = lCopayID
                mClassificationID = lClassificationID
                mHealthPlan = lHealthPlan
                mHealthPlanID = lHealthPlanID
                mChangeFlag = lChangeFlag

                mFirstName = lFirstName
                mMiddleName = lMiddleName
                mLastName = lLastName
                mDOB = lDOB
                mRelationShip = lRelationShip
                mPatientIdentifier = lPatientIdentifier
                mCardHolderID = lCardHolderID
                mGender = lGender
                mBIN = lBIN
                mGroupID = lGroupID
                mCardHolderName = lCardHolderName
                mUniqueMemberID = lUniqueMemberID

                mSuffix = lSuffix
                mAddress = lAddress
                mAddressLine2 = lAddressLine2
                mCity = lCity
                mState = lState
                mZipCode = lZipCode

                mIdentityCardNumber = lIdentityCardNumber
                mFamilyUnitNumber = lFamilyUnitNumber
                mGroupName = lGroupName

                mLTC = lLTC
                mSpeciality = lSpeciality
                mLTCDescription = lLTCDescription
                mSpecialityDescription = lSpecialityDescription


                mErrorDescription = lErrorDescription
                mAAA = lAAA
                mMedicationHistoryCardHolderID = lMedicationHistoryCardHolderID

            Next 'FOR FUNCTIONAL GROUP


        Catch ex As Exception
            mCovered = False
            ErrorLogMethods.LogError(ex, "RxHubLibrary\BLL\EligibilityBL.GetEligibilityForObject()")
        End Try

    End Sub

End Class