Imports MedispanLibrary

Public Class FormularyStatusBL
    Private mFormularyStatus As FormularyStatus
    Private mNonReimbursible As Boolean
    Private mListExists As Boolean
    Private mNDC As String
    Private mStatus As String
    Private mStatusInt As String
    Private mCount As Integer
    Private mExists As Boolean
    Private mOTC As String
    Private mNonDrug As String
    Private mType As String

    Private mExcluded As Boolean

    Private mMaxFormularyNDCList As String ' This is for returning whole lists of maximum formulary NDCs

#Region "Contructor"

    Public Sub New()
        mFormularyStatus = New FormularyStatus
        mNonReimbursible = False
        mCount = 0
        mListExists = True
        mExists = True

        mMaxFormularyNDCList = Nothing
    End Sub

#End Region


#Region "Properties"

    Public ReadOnly Property Excluded() As Boolean
        Get
            Return mExcluded
        End Get
    End Property

    Public Property MaxFormularyNDCList() As String
        Get
            Return mMaxFormularyNDCList
        End Get
        Set(ByVal value As String)
            mMaxFormularyNDCList = value
        End Set
    End Property

    'This tell whether an NDC Exists or not 
    Public ReadOnly Property Exists() As Boolean
        Get
            Return mExists
        End Get
    End Property


    'This tells whether the list exists or not 
    Public ReadOnly Property ListExists() As Boolean
        Get
            Return mListExists
        End Get
    End Property

    'This gives the count of the ndcs and statuses available
    Public ReadOnly Property Count() As Integer
        Get
            Return mCount
        End Get
    End Property

    'This tell whether the drug is reimbursible or not 
    Public ReadOnly Property NonReimbursible() As Boolean
        Get
            Return mNonReimbursible

        End Get
    End Property

    'This returns the NDC
    Public ReadOnly Property NDC() As String
        Get
            Return mNDC
        End Get
    End Property

    'This returns the Status
    Public ReadOnly Property Status() As String
        Get
            Return mStatus
        End Get
    End Property

    'This returns the Status
    Public ReadOnly Property StatusInt() As String
        Get
            Return mStatusInt
        End Get
    End Property


    Public ReadOnly Property OTC() As String
        Get
            Return mOTC
        End Get
    End Property


    Public ReadOnly Property NonDrug() As String
        Get
            Return mNonDrug
        End Get
    End Property

    'This tell whether the Drug is "Branded"\"Generic"
    Public ReadOnly Property Type() As String
        Get
            Return mType
        End Get
    End Property

#End Region



    'This function gets the formulary status as a string
    Public Sub GetFormulary(ByVal pFormularyID As String, ByVal pNDC As String, ByVal pCoverageID As String, ByVal pPBM As String, ByVal pDDID As String)

        Dim lMedispanBL As MedispanBL = Nothing
        Dim lDataSet As DataSet = Nothing

        Dim lResult As Boolean

        Dim lType As String = String.Empty
        Dim lOTC As String = String.Empty
        Dim lNonDrug As String = String.Empty

        Try

            lMedispanBL = New MedispanBL
            lDataSet = New DataSet

            lResult = mFormularyStatus.CheckFormularyListExistance(pFormularyID, pPBM)
            If lResult = False Then
                'List not found
                'Exit the procedure
                'This part assigns the characterstics if no NDC is found
                'Uses the DDID
                If Not pDDID.Equals("") Then
                    mOTC = lMedispanBL.GetOTCByDDID(pDDID)
                    mNonDrug = lMedispanBL.IsNonDrugByDDID(pDDID)
                    mType = lMedispanBL.GetNameTypeCodeByDDID(pDDID)
                End If
                mListExists = False
                Exit Sub
            End If
            If pNDC.Length < 2 Then
                mExists = False

                'This part assigns the characterstics if no NDC is found
                'Uses the DDID
                If Not pDDID.Equals("") Then
                    mOTC = lMedispanBL.GetOTCByDDID(pDDID)
                    mNonDrug = lMedispanBL.IsNonDrugByDDID(pDDID)
                    mType = lMedispanBL.GetNameTypeCodeByDDID(pDDID)
                End If

                Exit Sub ' because no NDC found

            End If
            pNDC = pNDC.Replace(",", "','")
            mCount = pNDC.Split(",").Length - 1
            pNDC = pNDC.Substring(2) & "'"


            lDataSet = mFormularyStatus.GetFormularyStatus(pFormularyID, pDDID, pPBM)

            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Change Log'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            ''Faraz Ahmed
            ''Returning the whole dataSet of maximum formulary NDCs

            mMaxFormularyNDCList = pNDC
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''


            lResult = mFormularyStatus.CheckExclusionList(pNDC, pCoverageID, pPBM)
            If lResult = True Then
                mNDC = pNDC
                mNonReimbursible = True
                mExcluded = True
                Exit Sub
            End If

            'Check all the NDCs
            If (lDataSet.Tables.Count > 0) AndAlso (lDataSet.Tables(0).Rows.Count > 0) Then
                mStatus = lDataSet.Tables(0).Rows(0)("FormularyStatus")
                mStatusInt = IIf(mStatus = "U", -1, mStatus)
                mNDC = lDataSet.Tables(0).Rows(0)("PRoductID")

                lType = lMedispanBL.GetNameTypeCode(mNDC)
                If Not lType.Equals("Not Found") Then
                    lOTC = lMedispanBL.GetOTC(mNDC)
                    lNonDrug = lMedispanBL.IsNonDrug(mNDC)
                    mOTC = IIf(lOTC = "O", "OTC Drug", "Prescription Required")
                    mNonDrug = IIf(lNonDrug = "Y", "Non-Drug", "Drug")
                    mType = IIf(lType = "G", "Generic", "Branded")
                Else
                    mType = lType
                End If
            Else
                pNDC = pNDC.Substring(1, 11)
                lType = lMedispanBL.GetNameTypeCode(pNDC)
                mNDC = pNDC

                If Not lType.Equals("Not Found") Then
                    lOTC = lMedispanBL.GetOTC(pNDC)
                    lNonDrug = lMedispanBL.IsNonDrug(pNDC)
                    mStatus = mFormularyStatus.GetTypeStatus(pFormularyID, lType, lOTC, lNonDrug, pPBM)
                    mStatusInt = IIf(mStatus = "U", -1, mStatus)
                    mNDC = pNDC
                    mOTC = IIf(lOTC = "O", "OTC Drug", "Prescription Required")
                    mNonDrug = IIf(lNonDrug = "Y", "Non-Drug", "Drug")
                    mType = IIf(lType = "G", "Generic", "Branded")
                Else
                    lOTC = lMedispanBL.GetOTC(pNDC)
                    lNonDrug = lMedispanBL.IsNonDrug(pNDC)
                    mOTC = IIf(lOTC = "O", "OTC Drug", "Prescription Required")
                    mNonDrug = IIf(lNonDrug = "Y", "Non-Drug", "Drug")
                    'mType = IIf(lType = "G", "Generic", "Branded")
                    mType = lType
                    mListExists = False
                    Exit Sub
                End If
            End If

            'This part makes the status verbose
            Select Case mStatus
                Case "U"
                    mStatus = "Unknown"
                Case "0"
                    mStatus = "Non Reimbursible"
                Case "1"
                    mStatus = "Non Formulary"
                Case "2"
                    mStatus = "On Formulary (Not preferred)"
                Case Else
                    mStatus = "Preferred Level " & (Int32.Parse(mStatus) - 2).ToString

            End Select

        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\FormularyStatusBL.GetFormulary(ByVal pFormularyID As String, ByVal pNDC As String, ByVal pCoverageID As String, ByVal pPBM As String, ByVal pDDID As String) ")
        End Try

    End Sub

    'This function gets the formulary status as a string

    ''' <summary>
    ''' This Method,
    ''' checks for formulary list existence. 
    ''' If it is found go further.
    ''' If it is not found it makes a flag to flase and exit but before exit we should populate formulary status field (to be discussed)
    ''' Checks in the exclusion list for the list of NDCs, if even a single NDC is found in exclusion list then it chage the formulary status field to  'Non Reimbursable' and exit.
    ''' Checks in the formulary list, if found in the list it changes formulary status to the highest formulary status found in the formulary list for entire ndc list.
    ''' If it is not found in the list, then it checks in the header table for formulary status using drug attributes e.g. OTC etc.
    ''' If it is found then it changes formulary status field to the value present in the header table.
    ''' If it is not found (to be discussed).
    ''' </summary>
    ''' <param name="pFormularyID"></param>
    ''' <param name="pNDC"></param>
    ''' <param name="pCoverageID"></param>
    ''' <param name="pPBM"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetFormularyWithNDCs(ByVal pFormularyID As String, ByVal pNDC As String, ByVal pCoverageID As String, ByVal pPBM As String) As DataSet

        Dim lMedispanBL As MedispanBL = Nothing
        Dim lDataSet As DataSet = Nothing

        Dim lResult As Boolean

        Dim lType As String = String.Empty
        Dim lOTC As String = String.Empty
        Dim lNonDrug As String = String.Empty

        Try

            lMedispanBL = New MedispanBL
            lDataSet = New DataSet

            lResult = mFormularyStatus.CheckFormularyListExistance(pFormularyID, pPBM)
            If lResult = False Then
                'List not found
                'Exit the procedure
                mListExists = False
                Return Nothing
            End If
            If pNDC.Length < 2 Then
                mExists = False
                Return Nothing ' because no NDC found
                'status = unknown
            End If
            pNDC = pNDC.Replace(",", "','")
            mCount = pNDC.Split(",").Length - 1
            pNDC = pNDC.Substring(2) & "'"
            If Not pCoverageID.Equals("") Then
                lResult = mFormularyStatus.CheckExclusionList(pNDC, pCoverageID, pPBM)
                If lResult = True Then
                    mExcluded = True
                    mNonReimbursible = True
                    mStatus = "Non Reimbursible (After Drug Exclusion Applied)"
                    mStatusInt = 0
                    Return Nothing
                End If
            End If

            lDataSet = mFormularyStatus.GetFormularyStatusWithNDCs(pFormularyID, pNDC, pPBM)

            'Check all the NDCs
            If lDataSet.Tables(0).Rows.Count > 0 Then
                mStatus = lDataSet.Tables(0).Rows(0)("MaxFormularyStatus")
                mStatusInt = IIf(mStatus = "U", -1, mStatus)
                mOTC = IIf(lDataSet.Tables(0).Rows(0)("ISOTC") = "O", "OTC Drug", "Prescription Required")
                mNonDrug = IIf(lDataSet.Tables(0).Rows(0)("ISNONDRUG") = "Y", "Non-Drug", "Drug")
                mType = IIf(lDataSet.Tables(0).Rows(0)("ISGENERIC") = "Y", "Generic", "Branded")
            Else
                pNDC = pNDC.Substring(1, 11)
                lType = lMedispanBL.GetNameTypeCode(pNDC)
                lOTC = lMedispanBL.GetOTC(pNDC)
                lNonDrug = lMedispanBL.IsNonDrug(pNDC)
                mOTC = IIf(lOTC = "O", "OTC Drug", "Prescription Required")
                mNonDrug = IIf(lNonDrug = "Y", "Non-Drug", "Drug")
                If Not lType.Equals("Not Found") Then
                    mStatus = mFormularyStatus.GetTypeStatus(pFormularyID, lType, lOTC, lNonDrug, pPBM)
                    mStatusInt = IIf(mStatus = "U", -1, mStatus)
                    mType = IIf(lType = "G", "Generic", "Branded")
                Else
                    mType = lType
                    mListExists = False
                    Return lDataSet
                End If
            End If

            'This part makes the status verbose
            Select Case mStatus
                Case "U"
                    mStatus = "Unknown"
                Case "0"
                    mStatus = "Non Reimbursible"
                Case "1"
                    mStatus = "Non Formulary"
                Case "2"
                    mStatus = "On Formulary (Not preferred)"
                Case Else
                    mStatus = "Preferred Level " & (Int32.Parse(mStatus) - 2).ToString

            End Select
            Return lDataSet
        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\FormularyStatusBL.GetFormularyWithNDCs(ByVal pFormularyID As String, ByVal pNDC As String, ByVal pCoverageID As String, ByVal pPBM As String) ")
        End Try

    End Function


   
    Public Function GetMaxFormulary(ByVal pDrugCollection As Object, ByVal pFormularyID As String, ByVal pCoverageID As String, ByVal pPBM As String, ByVal pCopayID As String) As DrugsColl

        Dim lDDID As String = String.Empty

        Dim lMSDrugMethods As MSDrugMethods = Nothing
        Dim lFormularyStatus As FormularyStatus = Nothing
        Dim lDataSet As DataSet = Nothing
        Dim lDrugsCollection As DrugsColl = Nothing
        Dim lCopayBL As CopayBL = Nothing


        Dim lStatusFoundInHeader As Boolean = False

        Try

            lMSDrugMethods = New MSDrugMethods
            lFormularyStatus = New FormularyStatus
            lCopayBL = New CopayBL

            lDDID = lMSDrugMethods.ReturnDDID(pDrugCollection).Replace("'", "")

            If Not pFormularyID.Equals("") Then
                lDataSet = lFormularyStatus.GetFullStatusByQuery(lDDID, pFormularyID, pCoverageID, pPBM)
            End If



            lDrugsCollection = lMSDrugMethods.InsertInCollection(lDataSet, pDrugCollection, pFormularyID)


            For Each lDrug As Drug In lDrugsCollection
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Change Log''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                ''Faraz Ahmed
                ''Description: adding the Drug Specific Copay for the druglist
                If (Not pCopayID.Equals("")) And (Not lDrug.Status.Equals("0")) Then
                    lDrug.CopayRules = lCopayBL.GetCopayDSorSLForGrid(pCopayID, lDrug.DispensibleDrug.Id, pPBM, lDrug.Status)
                End If
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

                If lDrug.Status.Equals("") Then
                    lDrug.Status = mFormularyStatus.GetTypeStatus(pFormularyID, IIf(lDrug.IsGeneric.Equals("Y"), "G", "B"), IIf(lDrug.OTC.Equals("Y"), "O", "P"), lDrug.IsNonDrug, pPBM)
                    lStatusFoundInHeader = True
                End If
                If lDrug.Status.Equals("") Then
                    lDrug.Status = "V"
                End If




                If lDrug.Status.Contains("U") Then
                    lDrug.Status = "Unknown"
                    lDrug.StatusCode = -2

                ElseIf lDrug.Status.Contains("V") Then
                    lDrug.Status = "Unavailable"
                    lDrug.StatusCode = -1

                Else

                    Select Case Int32.Parse(lDrug.Status)

                        Case -1
                            
                            lDrug.Status = "Non Reimbursible (After Drug Exclusion Applied)"
                            lDrug.StatusCode = 0
                        Case 0
                            'If lStatusFoundInHeader Then
                            lDrug.Status = "Non Reimbursible"
                            'Else
                            '    lDrug.Status = "Non Reimbursible (After Drug Exclusion Applied)"
                            'End If

                            lDrug.StatusCode = 0
                        Case 1
                            lDrug.Status = "Non Formulary"
                            lDrug.StatusCode = 1
                        Case 2
                            lDrug.Status = "On Formulary (Not preferred)"
                            lDrug.StatusCode = 2
                        Case Else
                            lDrug.StatusCode = lDrug.Status
                            lDrug.Status = "Preferred Level " & (Int32.Parse(lDrug.Status) - 2).ToString
                    End Select

                End If

                lStatusFoundInHeader = False
            Next


        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\FormularyStatusBL.GetMaxFormulary(ByVal pDrugCollection As Object, ByVal pFormularyID As String, ByVal pCoverageID As String, ByVal pPBM As String, ByVal pCopayID As String) ")
        End Try


        Return lDrugsCollection

    End Function



End Class
