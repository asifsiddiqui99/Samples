Imports System.Data
Imports MedispanLibrary

Public Class MedispanBL
    Private mExists As Boolean
    Private mCount As Integer
    Private mDrugs As DataSet

#Region "Constructor"

    Public Sub New()
        mExists = False
        mCount = 0
    End Sub

#End Region


#Region "Properties"

    Public ReadOnly Property Count() As Integer
        Get
            Return mCount
        End Get
    End Property

    Public ReadOnly Property Exists() As Boolean
        Get
            Return mExists
        End Get
    End Property

    Public ReadOnly Property Drugs() As DataSet
        Get
            Return mDrugs
        End Get
    End Property


#End Region

    


    'Author  : Faraz Ahmed 
    'Purpose : This function searches the drug based on the Option (Exhaustive =1, Simple = 0)
    Public Sub SearchDrugs(ByVal pDrugName As String, ByVal pOption As Integer)

        Dim lMSDrugMethods As MSDrugMethods = Nothing

        Try
            lMSDrugMethods = New MSDrugMethods

            If pOption = 0 Then
                mDrugs = lMSDrugMethods.GetRxDrugNames(pDrugName, "Simple")
            ElseIf pOption = 1 Then
                mDrugs = lMSDrugMethods.GetRxDrugNames(pDrugName, "Exhaustive")
            End If


            If (mDrugs.Tables.Count > 0) Then
                If (mDrugs.Tables("Drugs").DefaultView.Count > 0) Then
                    mExists = True
                    mCount = mDrugs.Tables("Drugs").Rows.Count
                End If
            End If


        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\MedispanBL.SearchDrugs(ByVal pDrugName=" & pDrugName & " As String, ByVal pOption=" & pOption & " As Integer) ")
        End Try
    End Sub

    'Author  : Faraz Ahmed 
    'This function returns the NDCs for a specified drug
    Public Overloads Function GetNDC(ByVal pDrugName As String, ByVal pOption As Integer, ByVal pIndex As Integer) As String

        Dim lMSDrugMethods As MSDrugMethods = Nothing
        Dim lDataset As DataSet = Nothing

        Try
            lMSDrugMethods = New MSDrugMethods

            lDataset = lMSDrugMethods.GetRxDrugNames(pDrugName, "Simple")

        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\MedispanBL.GetNDC(ByVal pDrugName=" & pDrugName & " As String, ByVal pOption=" & pOption & " As Integer, ByVal pIndex=" & pIndex & " As Integer) ")
        End Try

        Return lDataset.Tables("Drugs").Rows(pIndex).Item(6).ToString.Replace("-", "")
    End Function

    'Author  : Faraz Ahmed 
    'This function returns the NDCs for a specified drug
    Public Overloads Function GetNDC(ByVal pDDID As String) As String

        Dim lMSDrugMethods As MSDrugMethods = Nothing

        Try
            lMSDrugMethods = New MSDrugMethods

            Return lMSDrugMethods.GetAllNdc(pDDID)

        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\MedispanBL.GetNDC(ByVal pDDID=" & pDDID & " As String) ")
        End Try

    End Function
    
    'Author  : Faraz Ahmed 
    'This function gets all the therapeutic alternatives
    Public Function GetTherapeuticAlternatives(ByVal pNDC As String) As Object

        Dim lMSDrugMethods As MSDrugMethods = Nothing
        Dim lAlternatives As Object = Nothing

        Try

            lMSDrugMethods = New MSDrugMethods

            If Not pNDC.Equals("") AndAlso pNDC.Length > 11 Then
                pNDC = pNDC.Substring(1, 11)
            End If

            lAlternatives = lMSDrugMethods.GetAlternativesDDIDbyGPI(pNDC)

        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\MedispanBL.GetTherapeuticAlternatives(ByVal pNDC=" & pNDC & " As String) ")
        End Try
        Return lAlternatives
    End Function

    'This funntion delegates to the DrugName getting (New)
    Public Function GetDrugNamesByDDID(ByVal pDDID As String) As String

        Dim lMSDrugMethods As MSDrugMethods = Nothing

        Try

            lMSDrugMethods = New MSDrugMethods

            Return lMSDrugMethods.GetDrugNameByDDID(pDDID)

        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\MedispanBL.GetDrugNamesByDDID(ByVal pDDID=" & pDDID & " As String) ")
        End Try
    End Function

    'This function returns whther the Drug is OTC 
    Public Function GetOTC(ByVal pNDC As String) As String

        Dim lMSDrugMethods As MSDrugMethods = Nothing

        Try

            lMSDrugMethods = New MSDrugMethods

            Return lMSDrugMethods.GetOTC(pNDC)

        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\MedispanBL.GetOTC(ByVal pNDC=" & pNDC & " As String) ")
        End Try
    End Function

    'This function tell whteher a drug is a drug or non-drug
    Public Function IsNonDrug(ByVal pNDC As String) As String

        Dim lMSDrugMethods As MSDrugMethods = Nothing

        Try

            lMSDrugMethods = New MSDrugMethods

            Return lMSDrugMethods.IsNonDrug(pNDC)

        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\MedispanBL.IsNonDrug(ByVal pNDC=" & pNDC & " As String) ")
        End Try
    End Function

    'This function tell whteher a drug is a drug or non-drug
    Public Function GetNameTypeCode(ByVal pNDC As String) As String

        Dim lMSDrugMethods As MSDrugMethods = Nothing

        Try

            lMSDrugMethods = New MSDrugMethods

            Return lMSDrugMethods.GetNameTypeCode(pNDC)

        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\MedispanBL.GetNameTypeCode(ByVal pNDC=" & pNDC & " As String) ")
        End Try
    End Function

    'This function tells whether a drug is OTC or not and takes DDID as parameter
    Public Function GetOTCByDDID(ByVal pDDID As String) As String

        Dim lMSDrugMethods As MSDrugMethods = Nothing

        Try

            lMSDrugMethods = New MSDrugMethods

            Select Case lMSDrugMethods.DrugTypeByDDID(pDDID)
                Case "1"
                    Return "Prescription Required"
                Case "2"
                    Return "OTC Drug"
                Case "3"
                    Return "Both"
                Case Else
                    Throw New Exception
            End Select

        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\MedispanBL.GetOTCByDDID(ByVal pDDID=" & pDDID & " As String) ")
        End Try
    End Function

    'Thid function tells whether a drug is branded, generic, trademark
    Public Function GetNameTypeCodeByDDID(ByVal pDDID As String) As String

        Dim lMSDrugMethods As MSDrugMethods = Nothing

        Try
            lMSDrugMethods = New MSDrugMethods

            Return IIf(lMSDrugMethods.DrugNameTypeByDDID(pDDID) = "3", "Generic", "Branded")
        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\MedispanBL.GetNameTypeCodeByDDID(ByVal pDDID=" & pDDID & " As String) ")
        End Try
    End Function

    Public Function IsNonDrugByDDID(ByVal pDDID As String) As String

        Dim lMSDrugMethods As MSDrugMethods = Nothing

        Try
            lMSDrugMethods = New MSDrugMethods

            Return IIf(lMSDrugMethods.IsDeviceByDDID(pDDID) = True, "Non-Drug", "Drug")
        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\MedispanBL.IsNonDrugByDDID(ByVal pDDID=" & pDDID & " As String) ")
        End Try
    End Function

End Class
