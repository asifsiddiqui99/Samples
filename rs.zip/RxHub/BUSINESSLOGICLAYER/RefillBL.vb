Imports System.io
Imports System.Xml



#Region "Enumerations"

'A = Approved 
'D = Denied 
'N = Denied, New Rx to follow
'C = Approved with changes
Public Enum ResponseType
    A
    D
    N
    C
End Enum

#End Region


Public Class RefillBL


#Region "Fields"

    Private mPath As String
    Private mMessageID As String
    Private mPharmacyParticpantID As String
    Private mPrescriberOrderNumber As String
    Private mSentTime As String
    Private mMessageCode As String
    Private mRxReferenceNumber As String
    Private mRelatesToMessageID As String
    Private mDuplicateKeys As Boolean
    Private mErrorExists As Boolean
    Private mErrorDescription As String

    Private mClinic As sClinic
    Private mClinicPhone As sPhone
    Private mPrescriberIdentification As sIdentification
    Private mPrescriberName As sName
    Private mPatientIdentification As sIdentification
    Private mPatientName As sName
    Private mPatientDOB As String
    Private mPatientGender As String
    Private mMedicationPrescribed As Medication
    Private mMedicationDispensed As Medication
    Private mSubstitutions As String
    Private mExists As Boolean

#End Region



#Region "Constructor"
    Public Sub New(ByVal lPath As String)
        mPath = lPath
        mClinic = New sClinic
        mClinicPhone = New sPhone
        mPrescriberIdentification = New sIdentification
        mPrescriberName = New sName
        mPatientIdentification = New sIdentification
        mPatientName = New sName
        mPatientGender = String.Empty
        mPatientDOB = String.Empty
        mMedicationPrescribed = New Medication
        mMedicationPrescribed.DaysSupply = "-1"
        mMedicationDispensed = New Medication
        mExists = True
        mDuplicateKeys = False
        mErrorExists = False
        mErrorDescription = ""
    End Sub
#End Region

    

#Region "Property"

    Public Property Substitutions() As String
        Get
            Return mSubstitutions
        End Get
        Set(ByVal value As String)
            mSubstitutions = value
        End Set
    End Property

    Public Property ErrorDescription() As String
        Get
            Return mErrorDescription
        End Get
        Set(ByVal value As String)
            mErrorDescription = value
        End Set
    End Property

    Public Property ErrorExists() As Boolean
        Get
            Return mErrorExists
        End Get
        Set(ByVal value As Boolean)
            mErrorExists = value
        End Set
    End Property

    Public Property RelatesToMessageID() As String
        Get
            Return mRelatesToMessageID
        End Get
        Set(ByVal value As String)
            mRelatesToMessageID = value
        End Set
    End Property

    Public Property RxReferenceNumber() As String
        Get
            Return mRxReferenceNumber
        End Get
        Set(ByVal value As String)
            mRxReferenceNumber = value
        End Set
    End Property

    Public Property MessageCode() As String
        Get
            Return mMessageCode
        End Get
        Set(ByVal value As String)
            mMessageCode = value
        End Set
    End Property

    Public Property SentTime() As String
        Get
            Return mSentTime
        End Get
        Set(ByVal value As String)
            mSentTime = value
        End Set
    End Property
    Public Property PrescriberOrderNumber() As String
        Get
            Return mPrescriberOrderNumber
        End Get
        Set(ByVal value As String)
            mPrescriberOrderNumber = value
        End Set
    End Property

    Public Property PharmacyParticipantID() As String
        Get
            Return mPharmacyParticpantID
        End Get
        Set(ByVal value As String)
            mPharmacyParticpantID = value
        End Set
    End Property

    Public Property MessageID() As String
        Get
            Return mMessageID
        End Get
        Set(ByVal value As String)
            mMessageID = value
        End Set
    End Property

    Public Property Clinic() As sClinic
        Get
            Return mClinic
        End Get
        Set(ByVal value As sClinic)
            mClinic = value
        End Set
    End Property

    Public Property ClinicPhone() As sPhone
        Get
            Return mClinicPhone
        End Get
        Set(ByVal value As sPhone)
            mClinicPhone = value
        End Set
    End Property

    Public Property PrescriberIdentification() As sIdentification
        Get
            Return mPrescriberIdentification
        End Get
        Set(ByVal value As sIdentification)
            mPrescriberIdentification = value
        End Set
    End Property

    Public Property PrescriberName() As sName
        Get
            Return mPrescriberName
        End Get
        Set(ByVal value As sName)
            mPrescriberName = value
        End Set
    End Property

    Public Property PatientIdentification() As sIdentification
        Get
            Return mPatientIdentification
        End Get
        Set(ByVal value As sIdentification)
            mPatientIdentification = value
        End Set
    End Property

    Public Property PatientName() As sName
        Get
            Return mPatientName
        End Get
        Set(ByVal value As sName)
            mPatientName = value
        End Set
    End Property

    Public Property PatientDOB() As String
        Get
            Return mPatientDOB
        End Get
        Set(ByVal value As String)
            mPatientDOB = value
        End Set
    End Property

    Public Property PatientGender() As String
        Get
            Return mPatientGender
        End Get
        Set(ByVal value As String)
            mPatientGender = value
        End Set
    End Property

    Public Property MedicationPrescribed() As Medication
        Get
            Return mMedicationPrescribed
        End Get
        Set(ByVal value As Medication)
            mMedicationPrescribed = value
        End Set
    End Property

    Public Property MedicationDispensed() As Medication
        Get
            Return mMedicationDispensed
        End Get
        Set(ByVal value As Medication)
            mMedicationDispensed = value
        End Set
    End Property

    Public Property Exists() As Boolean
        Get
            Return mExists
        End Get
        Set(ByVal value As Boolean)
            mExists = value
        End Set
    End Property

    Public Property DuplicateKeys() As Boolean
        Get
            Return mDuplicateKeys
        End Get
        Set(ByVal value As Boolean)
            mDuplicateKeys = value
        End Set
    End Property
#End Region


    
    Public Function GetRefillRequest() As String

        Dim lFileStream As FileStream = Nothing
        Dim lStreamReader As StreamReader = Nothing
        Dim lRefillDB As Refill = Nothing
        Dim lXmlDocument As XmlDocument = Nothing

        Dim lRequest As String = String.Empty


        Try

            lFileStream = New FileStream(mPath, FileMode.Open)
            lStreamReader = New StreamReader(lFileStream)
            lRefillDB = New Refill
            lXmlDocument = New XmlDocument

            lRequest = lStreamReader.ReadToEnd
            lRequest = lRequest.Substring(lRequest.IndexOf("<Header>"))
            lRequest = lRequest.Remove(lRequest.IndexOf("</Message>"))

            lRequest = "<Message>" + lRequest + "</Message>"

            lXmlDocument.LoadXml(lRequest)

            'This will pick up the messageID
            MessageID = lXmlDocument.SelectSingleNode("//Header/MessageID").InnerText
            SentTime = DateTime.Now.ToString("MM/dd/yyyy HH:mm:ss")

            If lXmlDocument.SelectNodes("//Pharmacy/ParticipantID").Count > 0 Then
                PharmacyParticipantID = lXmlDocument.SelectSingleNode("//Pharmacy/ParticipantID").InnerText
            End If

            If lXmlDocument.SelectNodes("//RefillRequest/PrescriberOrderNumber").Count > 0 Then
                PrescriberOrderNumber = lXmlDocument.SelectSingleNode("//RefillRequest/PrescriberOrderNumber").InnerText
            End If

            If lXmlDocument.SelectNodes("//RefillRequest/RxReferenceNumber").Count > 0 Then
                RxReferenceNumber = lXmlDocument.SelectSingleNode("//RefillRequest/RxReferenceNumber").InnerText
            End If

            If lXmlDocument.SelectNodes("//Pharmacy/Identification").Count > 0 Then
                Clinic.ClinicCode = lXmlDocument.DocumentElement.SelectSingleNode("//Pharmacy/Identification/ReferenceNumber").InnerText
            End If

            If lXmlDocument.SelectNodes("//Pharmacy/StoreName").Count > 0 Then
                Clinic.ClinicName = lXmlDocument.DocumentElement.SelectSingleNode("//Pharmacy/StoreName").InnerText
            End If

            If lXmlDocument.SelectNodes("//Pharmacy/PhoneNumbers/Phone").Count > 0 Then
                ClinicPhone.PhoneNumber = lXmlDocument.DocumentElement.SelectSingleNode("//Pharmacy/PhoneNumbers/Phone/Number").InnerText
                ClinicPhone.PhoneNumberQualifier = lXmlDocument.DocumentElement.SelectSingleNode("//Pharmacy/PhoneNumbers/Phone/Qualifier").InnerText
            End If

            If lXmlDocument.SelectNodes("//Prescriber/Identification").Count > 0 Then
                PrescriberIdentification.IdentificationQualifier = lXmlDocument.DocumentElement.SelectSingleNode("//Prescriber/Identification/PrescriberQualifier").InnerText
                PrescriberIdentification.IdentificationNumber = lXmlDocument.DocumentElement.SelectSingleNode("//Prescriber/Identification/PrescriberID").InnerText
            End If

            If lXmlDocument.SelectNodes("//Prescriber/Name").Count > 0 Then
                PrescriberName.FirstName = lXmlDocument.DocumentElement.SelectSingleNode("//Prescriber/Name/FirstName").InnerText
                PrescriberName.LastName = lXmlDocument.DocumentElement.SelectSingleNode("//Prescriber/Name/LastName").InnerText
            End If



            If lXmlDocument.SelectNodes("//Patient/Identification").Count > 0 Then
                PatientIdentification.IdentificationQualifier = lXmlDocument.DocumentElement.SelectSingleNode("//Patient/Identification/IdentificationQualifier").InnerText
                PatientIdentification.IdentificationQualifier = lXmlDocument.DocumentElement.SelectSingleNode("//Patient/Identification/SocialSecurity").InnerText
            End If

            If lXmlDocument.SelectNodes("//Patient/Name").Count > 0 Then
                PatientName.FirstName = lXmlDocument.DocumentElement.SelectSingleNode("//Patient/Name/FirstName").InnerText
                PatientName.LastName = lXmlDocument.DocumentElement.SelectSingleNode("//Patient/Name/LastName").InnerText
            End If

            If lXmlDocument.SelectNodes("//Patient/Gender").Count > 0 Then
                PatientGender = lXmlDocument.DocumentElement.SelectSingleNode("//Patient/Gender").InnerText
            End If

            If lXmlDocument.SelectNodes("//Patient/DateOfBirth").Count > 0 Then
                PatientDOB = lXmlDocument.DocumentElement.SelectSingleNode("//Patient/DateOfBirth").InnerText
            End If

            If lXmlDocument.SelectNodes("//MedicationPrescribed/Drug/ItemDescription").Count > 0 Then
                MedicationPrescribed.DrugDescription = lXmlDocument.DocumentElement.SelectSingleNode("//MedicationPrescribed/Drug/ItemDescription").InnerText
            End If


            For x As Integer = 0 To lXmlDocument.SelectNodes("//MedicationPrescribed/DateTimePeriodQualifier").Count - 1
                If lXmlDocument.SelectSingleNode("//MedicationPrescribed/DateTimePeriodQualifier[" & x + 1 & "]/DateTimePeriodQualifier").InnerText.Equals("ZDS") Then
                    MedicationPrescribed.DaysSupply = lXmlDocument.SelectSingleNode("//MedicationPrescribed/DateTimePeriodQualifier[" & x + 1 & "]/DateTimePeriod").InnerText

                ElseIf lXmlDocument.SelectSingleNode("//MedicationPrescribed/DateTimePeriodQualifier[" & x + 1 & "]/DateTimePeriodQualifier").InnerText.Equals("LD") Then
                    MedicationPrescribed.LastFillDate.DateValue = lXmlDocument.SelectSingleNode("//MedicationPrescribed/DateTimePeriodQualifier[" & x + 1 & "]/DateTimePeriod").InnerText
                ElseIf lXmlDocument.SelectSingleNode("//MedicationPrescribed/DateTimePeriodQualifier[" & x + 1 & "]/DateTimePeriodQualifier").InnerText.Equals("85") Then
                    MedicationPrescribed.WrittenDate.DateValue = lXmlDocument.SelectSingleNode("//MedicationPrescribed/DateTimePeriodQualifier[" & x + 1 & "]/DateTimePeriod").InnerText
                End If
            Next

            If lXmlDocument.SelectNodes("//MedicationPrescribed/Refills").Count > 0 Then
                MedicationPrescribed.Refills.Qualifier = lXmlDocument.DocumentElement.SelectSingleNode("//MedicationPrescribed/Refills/Qualifier").InnerText
                MedicationPrescribed.Refills.Quantity = lXmlDocument.DocumentElement.SelectSingleNode("//MedicationPrescribed/Refills/Quantity").InnerText
            End If

            If lXmlDocument.SelectNodes("//MedicationPrescribed/Substitutions").Count > 0 Then
                MedicationPrescribed.Substitutions = lXmlDocument.DocumentElement.SelectSingleNode("//MedicationPrescribed/Substitutions").InnerText
            End If


            'If lXmlDocument.SelectNodes("//MedicationPrescribed/WrittenDate").Count > 0 Then
            '    MedicationPrescribed.WrittenDate.DateValue = lXmlDocument.DocumentElement.SelectSingleNode("//MedicationPrescribed/WrittenDate").InnerText
            'End If

            If lXmlDocument.SelectNodes("//MedicationPrescribed/Quantity").Count > 0 Then
                MedicationPrescribed.Quantity.QuantityQualifier = lXmlDocument.DocumentElement.SelectSingleNode("//MedicationPrescribed/Quantity/Qualifier").InnerText
                MedicationPrescribed.Quantity.Value = lXmlDocument.DocumentElement.SelectSingleNode("//MedicationPrescribed/Quantity/Value").InnerText
            End If

            If lXmlDocument.SelectNodes("//MedicationPrescribed/Note").Count > 0 Then
                MedicationPrescribed.Note = lXmlDocument.DocumentElement.SelectSingleNode("//MedicationPrescribed/Note").InnerText
            End If

            If lXmlDocument.SelectNodes("//MedicationDispensed/Drug/ItemDescription").Count > 0 Then
                MedicationDispensed.DrugDescription = lXmlDocument.DocumentElement.SelectSingleNode("//MedicationDispensed/Drug/ItemDescription").InnerText
            End If

            If lXmlDocument.SelectNodes("//MedicationPrescribed/DrugCoded").Count > 0 Then
                MedicationPrescribed.DrugCoded.ProductCode = lXmlDocument.DocumentElement.SelectSingleNode("//MedicationPrescribed/DrugCoded/ProductCode").InnerText
            End If

            If lXmlDocument.SelectNodes("//MedicationDispensed/Note").Count > 0 Then
                MedicationDispensed.Note = lXmlDocument.DocumentElement.SelectSingleNode("//MedicationDispensed/Note").InnerText
            End If

            If lXmlDocument.SelectNodes("//MedicationDispensed/Directions/DosageOne").Count > 0 Then
                MedicationDispensed.Directions = lXmlDocument.DocumentElement.SelectSingleNode("//MedicationDispensed/Directions/DosageOne").InnerText & "--"


                If lXmlDocument.SelectNodes("//MedicationDispensed/Directions/DosageTwo").Count > 0 Then
                    MedicationDispensed.Directions &= lXmlDocument.DocumentElement.SelectSingleNode("//MedicationDispensed/Directions/DosageTwo").InnerText
                End If

            End If

            If lXmlDocument.SelectNodes("//MedicationDispensed/Quantity").Count > 0 Then
                MedicationDispensed.Quantity.QuantityQualifier = lXmlDocument.DocumentElement.SelectSingleNode("//MedicationDispensed/Quantity/Qualifier").InnerText
                MedicationDispensed.Quantity.Value = lXmlDocument.DocumentElement.SelectSingleNode("//MedicationDispensed/Quantity/Value").InnerText
            End If

            Dim lMessageCode As String = lRefillDB.CheckDuplicateKeys(MessageID, Clinic.ClinicCode)

            If Not lMessageCode.Equals("") Then
                DuplicateKeys = True
                MessageCode = lMessageCode
            End If

        Catch ex As Exception

            'Exists = False 
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\RefillBL.GetRefillRequest() ")

        Finally
            lStreamReader.Close()
            lFileStream.Close()
        End Try

        Return lXmlDocument.OuterXml.ToString

    End Function



End Class
