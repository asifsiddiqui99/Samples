Imports System.Data.SqlClient
Imports ElixirLibrary

Public Class PharmacyBL

    Public Shared Function SearchActivePharmacy(ByVal postcode As String, ByVal phone As String, ByVal street As String, ByVal pharmacy As String, ByVal state As String, ByVal ncpdpid As String, Optional ByVal city As String = "") As DataSet



        Dim lDs As DataSet = Nothing
        Dim lConnection As Connection = Nothing

        Dim lQuery As String = String.Empty
        Dim whereclause As String = String.Empty




        whereclause = " Where '" + Date.Now.Date.ToString("MMM dd yyyy") + "' " _
                                  + " Between Convert(datetime,Left(AtiveStartTime,10)) " _
                                  + " And Convert(DateTime, Left(ActiveEndTime, 10)) " _
                                  + " And Provider = 'R' "


        If postcode.Trim <> "" Then
            whereclause = whereclause & " And zip='" & postcode.Replace("'", "''") & "'"
        End If
        If phone.Trim <> "" Then
            whereclause = whereclause & " and primaryphone='" & postcode.Replace("'", "''") & "'"
        End If
        If street.Trim <> "" Then
            whereclause = whereclause & " and addressline1 LIKE'%" & street.Replace("'", "''") & "%'"
        End If
        If pharmacy.Trim <> "" Then
            whereclause = whereclause & " and storename LIKE'" & pharmacy.Replace("'", "''") & "%'"
        End If
        If state.Trim <> "" Then
            whereclause = whereclause & " and state='" & state.Replace("'", "''") & "'"
        End If
        If city.Trim <> "" Then
            whereclause = whereclause & " and City LIKE'" & city.Replace("'", "''") & "%'"
        End If
        If ncpdpid.Trim <> "" Then
            whereclause = whereclause & " and ncpdpid ='" & ncpdpid.Replace("'", "''") & "'"
        End If

        lQuery = "SELECT NCPDPID,Replace(StoreName,'''','&#39') AS name,AddressLine1 as address1,AddressLine2 as address2,City,State,Zip,Fax,Email,ServiceLevel as pharmacytype,PrimaryPhone As Phone FROM Pharmacy" & whereclause & " ORDER BY StoreName"



        Try
            lConnection = New Connection

            lDs = lConnection.ExecuteQuery(lQuery)

        Catch ex As Exception
            ErrorLogMethods.LogError(ex, " RxHubLibrary\BLL\PharmacyBL.SearchActivePharmacy(ByVal postcode As String, ByVal phone As String, ByVal street As String, ByVal pharmacy As String, ByVal state As String, ByVal ncpdpid As String, Optional ByVal city As String = '') ")            
        End Try

        Return lDs

    End Function
End Class
