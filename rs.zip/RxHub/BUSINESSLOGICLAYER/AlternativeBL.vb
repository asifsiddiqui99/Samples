Imports System.Data
Imports MedispanLibrary

Public Class AlternativeBL
    Private mPayerAlternatives As DataSet
    Private mTherapeuticAlternatives As DataSet
    Private mCount As Integer
    Private mExists As Boolean
    Private mOnFormularyCount As Integer
    Private mAlternativeList() As String


#Region "Constructor"

    Public Sub New()
        mExists = False
        mOnFormularyCount = 0
    End Sub

#End Region
    

#Region "Properties"


    Public ReadOnly Property OnFormularyCount() As Integer
        Get
            Return mOnFormularyCount
        End Get
    End Property

    Public ReadOnly Property PayerAlternatives() As DataSet
        Get
            Return mPayerAlternatives
        End Get
    End Property

    Public ReadOnly Property TherapeuticAlternatives() As DataSet
        Get
            Return mTherapeuticAlternatives
        End Get
    End Property

    Public ReadOnly Property Exists() As Boolean
        Get
            Return mExists
        End Get
    End Property

    Public ReadOnly Property Count() As Integer
        Get
            Return mCount
        End Get
    End Property

#End Region
    

    'This gets the Payer-Specified Alternatives(if any) 
    Public Sub GetAlternatives(ByVal pNDC As String, ByVal pPBM As String, ByVal pAlternativeListID As String, ByVal pFormularyID As String, ByVal pCoverageID As String, ByVal pCopayID As String)

        Dim lAlternative As Alternative = Nothing
        Dim lDataSet As DataSet = Nothing
        Dim lMSDrugMethods As MSDrugMethods = Nothing
        Dim lFormularyStatusBL As FormularyStatusBL = Nothing
        Dim lCopayBL As CopayBL = Nothing

        Dim lVendorSpecificAlternatives As String = String.Empty
        Dim lVendorAlternativeRow As DataRow
        Dim lVendorAlternativesCollection As DataSet
        Dim lDrugName As String = String.Empty
        Dim lPayerSpecifiedAlternativeNDC As String = String.Empty
        Dim lDDID As String = String.Empty
        Dim lAlreadyAddedDDIDList As List(Of String)


        Dim lTempDataSet As DataSet
        Dim lTempDataRow As DataRow

        Try

            lAlternative = New Alternative
            lDataSet = New DataSet
            lMSDrugMethods = New MSDrugMethods
            lFormularyStatusBL = New FormularyStatusBL
            lCopayBL = New CopayBL

            lAlreadyAddedDDIDList = New List(Of String)

            lDataSet = lAlternative.GetAlternatives(pAlternativeListID, pNDC, pPBM)

            lTempDataSet = lDataSet.Clone
          
            If (lDataSet Is Nothing) OrElse (lDataSet.Tables(0).Rows.Count = 0) Then
                Exit Sub
            Else

                mCount = lDataSet.Tables(0).Rows.Count

                For x As Integer = 0 To mCount - 1
                    lDDID = lMSDrugMethods.GetDDIDByNDC(lDataSet.Tables(0).Rows(x)(0))

                    If Not lAlreadyAddedDDIDList.Contains(lDDID) Then

                        lTempDataRow = lTempDataSet.Tables(0).NewRow
                        lTempDataRow(0) = lDataSet.Tables(0).Rows(x)(0)
                        lTempDataRow(1) = lDataSet.Tables(0).Rows(x)(1)
                        lTempDataRow(2) = lDDID

                        lTempDataSet.Tables(0).Rows.Add(lTempDataRow)
                        'lTempDataSet.Tables(0).Rows.Add(lDataSet.Tables(0).Rows(x))
                        lAlreadyAddedDDIDList.Add(lDDID)
                    End If
                Next


                lDataSet = lTempDataSet
                mCount = lTempDataSet.Tables(0).Rows.Count

                lAlreadyAddedDDIDList.Clear()

                For x As Integer = 0 To mCount - 1

                    lPayerSpecifiedAlternativeNDC = lDataSet.Tables(0).Rows(x)(0)

                    lDDID = lMSDrugMethods.GetDDIDByNDC(lPayerSpecifiedAlternativeNDC)

                    'If lAlreadyAddedDDIDList.Contains(lDDID) Then
                    '    lDataSet.Tables(0).Rows.RemoveAt(x)
                    '    Continue For
                    'End If


                    If Not lDDID.ToUpper.Equals("NOT FOUND") Then 'SOME NDCs WERE NOT FOUND IN MEDISPAN SO WE SKIP THEM
                        lVendorAlternativesCollection = GetVendorSpecificAlternatives(lDDID)
                        lAlreadyAddedDDIDList.Add(lDDID) 'ADD THE CURRENT DDID
                    Else
                        Continue For
                    End If


                    For y As Integer = 0 To lVendorAlternativesCollection.Tables(0).Rows.Count - 1

                        lDDID = lVendorAlternativesCollection.Tables(0).Rows(y)(0)

                        lVendorSpecificAlternatives = lMSDrugMethods.GetAllNdc(lDDID)

                        If _
                        lVendorSpecificAlternatives.Contains(lPayerSpecifiedAlternativeNDC) Or _
                        lVendorSpecificAlternatives.Contains(pNDC) Or _
                        lAlreadyAddedDDIDList.Contains(lDDID) Then  'CHECK IF WE ARE DUPLICATING THE PAYER ALTERNATIVE
                            Continue For
                        End If



                        lVendorAlternativeRow = lDataSet.Tables(0).NewRow
                        lVendorAlternativeRow(0) = lVendorSpecificAlternatives.TrimStart(",")

                        ' lFormularyStatusBL.GetFormularyWithNDCs(pFormularyID, lVendorSpecificAlternatives, pCoverageID, pPBM)
                        lVendorAlternativeRow(1) = lDataSet.Tables(0).Rows(x)(1) 'lFormularyStatusBL.StatusInt
                        lVendorAlternativeRow(2) = lDDID
                        lDataSet.Tables(0).Rows.Add(lVendorAlternativeRow)

                        lAlreadyAddedDDIDList.Add(lVendorAlternativesCollection.Tables(0).Rows(y)(0))

                    Next

                Next


                mCount = lDataSet.Tables(0).Rows.Count 'NEW COUNT, AFTER ADDING OUR ALTERNATIVES
                mExists = True
            End If







            'Author : CPD from Fareed
            'This part created for the DataSet
            Dim lDS As DataSet = New DataSet


            Dim lcheck As Integer = 0
            For x As Integer = 0 To mCount - 1



                lFormularyStatusBL.GetFormulary(pFormularyID, "," & lDataSet.Tables(0).Rows(x).Item(0).ToString, pCoverageID, pPBM, lDataSet.Tables(0).Rows(x).Item(2).ToString)


                If lDataSet.Tables(0).Rows(x).Item(0).ToString.Split(",").Length > 0 Then
                    lDS = lMSDrugMethods.GetRxDrugNamesByNDC(lDataSet.Tables(0).Rows(x).Item(0).ToString.Split(",")(0), lDS)
                Else
                    lDS = lMSDrugMethods.GetRxDrugNamesByNDC(lDataSet.Tables(0).Rows(x).Item(0).ToString, lDS)
                End If





                'lDS = lMSDrugMethods.GetRxDrugNamesByNDC("", lDS)

                If lFormularyStatusBL.Status IsNot Nothing Then
                    If lDS IsNot Nothing AndAlso lDS.Tables.Count > 0 Then
                        lDS.Tables("Drugs").Rows(lDS.Tables("Drugs").Rows.Count - 1)("DIN") = lDataSet.Tables(0).Rows(x).Item("PreferenceLevel").ToString
                        lDS.Tables("Drugs").Rows(lDS.Tables("Drugs").Rows.Count - 1)("Status") = lFormularyStatusBL.Status
                        lDS.Tables("Drugs").Rows(lDS.Tables("Drugs").Rows.Count - 1)("StatusCode") = lFormularyStatusBL.StatusInt
                        lDS.Tables("Drugs").Rows(lDS.Tables("Drugs").Rows.Count - 1)("CopayRules") = IIf(pCopayID.Equals("") Or lFormularyStatusBL.StatusInt = 0, "", lCopayBL.GetCopayDSorSLForGrid(pCopayID, lDS.Tables("Drugs").Rows(lDS.Tables("Drugs").Rows.Count - 1)("DrugID"), pPBM, lFormularyStatusBL.StatusInt))
                        lcheck = lcheck + 1
                    End If
                End If

            Next

            If lDS.Tables.Count = 0 Then
                Dim DrugTable As DataTable = New DataTable
                DrugTable = lDS.Tables.Add("Drugs")
            End If

            mPayerAlternatives = lDS

        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\AlternativeBL.GetAlternatives(ByVal pNDC As String, ByVal pPBM As String, ByVal pAlternativeListID As String, ByVal pFormularyID As String, ByVal pCoverageID As String, ByVal pCopayID As String) ")
        End Try
    End Sub

    

    'This function gets the therapeutic alternatives
    Public Function GetTherapeuticAlternatives(ByVal pNDC As String, ByVal pFormularyID As String, ByVal pPBM As String, ByVal pCoverageID As String, ByVal pCopayId As String) As DrugsColl

        Dim lMedispanBL As MedispanBL = Nothing
        Dim lAlternativeFormularyStatus As FormularyStatusBL = Nothing
        Dim lMSDrugMethods As MSDrugMethods = Nothing
        Dim lDrugsCollection As DrugsColl = Nothing
        Dim lAlternative As Object = Nothing

        Dim lDDID As String = String.Empty
        

        Try
            lMedispanBL = New MedispanBL
            lAlternativeFormularyStatus = New FormularyStatusBL
            lMSDrugMethods = New MSDrugMethods

            lAlternative = lMedispanBL.GetTherapeuticAlternatives(pNDC)
            lDrugsCollection = lAlternativeFormularyStatus.GetMaxFormulary(lAlternative, pFormularyID, pCoverageID, pPBM, pCopayId)

            lDDID = lMSDrugMethods.GetDDIDByNDC(pNDC)

            If Not lDDID.ToUpper.Equals("NOT FOUND") Then

                For Each lDrug As Drug In lDrugsCollection
                    If lDrug.ID = lDDID Then
                        lDrugsCollection.Remove(lDrug)
                        Exit For
                    End If
                Next
            End If

        Catch ex As Exception
            Throw New Exception(ex.Message & " : RxHubLibrary\BLL\AlternativeBL.GetTherapeuticAlternatives(ByVal pNDC As String, ByVal pFormularyID As String, ByVal pPBM As String, ByVal pCoverageID As String, ByVal pCopayId As String) ")
        End Try

        Return lDrugsCollection

    End Function


    'GETS ALTERNATIVES OF VARYING STRENGTHS/FORMS AS PER PAYER ALTERNATIVES RECIEVED FROM RXHUB
    Private Function GetVendorSpecificAlternatives(ByVal pDDID As Integer) As DataSet

        Dim lAlternative As Alternative

        Try

            lAlternative = New Alternative
            Return lAlternative.GetVendorAlternatives(pDDID)

        Catch ex As Exception
            Return Nothing
        End Try

    End Function



End Class
