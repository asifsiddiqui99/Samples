Imports System
Imports System.Net
Imports System.Security.Cryptography.X509Certificates


'This class overrides the SSL certification 
'So if SSL is expired, the application will still work
Public Class CertificateValidation
    Implements ICertificatePolicy

    Public Function CheckValidationResult(ByVal srvPoint As ServicePoint, _
    ByVal cert As X509Certificate, ByVal request As WebRequest, ByVal problem As Integer) As Boolean Implements ICertificatePolicy.CheckValidationResult
        'Return true to specify that certificate is always validated
        Return True
    End Function
End Class


