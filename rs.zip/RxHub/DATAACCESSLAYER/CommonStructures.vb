
Public Class sIdentification
    Private mIdentificationNumber As String
    Private mIdentificationQualifier As String

    Public Sub New()
        mIdentificationNumber = ""
        mIdentificationQualifier = ""
    End Sub

    Public Property IdentificationNumber() As String
        Get
            Return mIdentificationNumber
        End Get
        Set(ByVal value As String)
            mIdentificationNumber = value
        End Set
    End Property

    Public Property IdentificationQualifier() As String
        Get
            Return mIdentificationQualifier
        End Get
        Set(ByVal value As String)
            mIdentificationQualifier = value
        End Set
    End Property
End Class

Public Class sClinic
    Private mClinicName As String
    Private mClinicCode As String

    Public Sub New()
        ClinicName = ""
        ClinicCode = ""
    End Sub

    Public Property ClinicName() As String
        Get
            Return mClinicName
        End Get
        Set(ByVal value As String)
            mClinicName = value
        End Set
    End Property

    Public Property ClinicCode() As String
        Get
            Return mClinicCode
        End Get
        Set(ByVal value As String)
            mClinicCode = value
        End Set
    End Property
End Class

Public Class sName
    Private mFirstName As String
    Private mMiddleName As String
    Private mLastName As String
    Private mPrefix As String
    Private mSuffix As String

    Public Sub New()
        mFirstName = ""
        mMiddleName = ""
        mLastName = ""
        mPrefix = ""
        mSuffix = ""
    End Sub

    Public Property FirstName() As String
        Get
            Return mFirstName
        End Get
        Set(ByVal value As String)
            mFirstName = value
        End Set
    End Property

    Public Property MiddleName() As String
        Get
            Return mMiddleName
        End Get
        Set(ByVal value As String)
            mMiddleName = value
        End Set
    End Property

    Public Property LastName() As String
        Get
            Return mLastName
        End Get
        Set(ByVal value As String)
            mLastName = value
        End Set
    End Property

    Public Property Prefix() As String
        Get
            Return mPrefix
        End Get
        Set(ByVal value As String)
            mPrefix = value
        End Set
    End Property

    Public Property Suffix() As String
        Get
            Return mSuffix
        End Get
        Set(ByVal value As String)
            mSuffix = value
        End Set
    End Property
End Class

Public Class sSpeciality
    Private mQualifier As String
    Private mSpecialityCode As String

    Public Sub New()
        mQualifier = ""
        mSpecialityCode = ""
    End Sub

    Public Property Qualifier() As String
        Get
            Return mQualifier
        End Get
        Set(ByVal value As String)
            mQualifier = value
        End Set
    End Property

    Public Property SpecialityCode()
        Get
            Return mSpecialityCode
        End Get
        Set(ByVal value)
            mSpecialityCode = value
        End Set
    End Property
End Class

Public Class sAddress
    Private mAddressLine1 As String
    Private mAddressLine2 As String
    Private mCity As String
    Private mState As String
    Private mZipCode As String


    Public Sub New()
        mAddressLine1 = ""
        mAddressLine2 = ""
        mCity = ""
        mState = ""
        mZipCode = ""
    End Sub

    Public Property AddressLine1() As String
        Get
            Return mAddressLine1
        End Get
        Set(ByVal value As String)
            mAddressLine1 = value
        End Set
    End Property

    Public Property AddressLine2() As String
        Get
            Return mAddressLine2
        End Get
        Set(ByVal value As String)
            mAddressLine2 = value
        End Set
    End Property

    Public Property City() As String
        Get
            Return mCity
        End Get
        Set(ByVal value As String)
            mCity = value
        End Set
    End Property

    Public Property State() As String
        Get
            Return mState
        End Get
        Set(ByVal value As String)
            mState = value
        End Set
    End Property

    Public Property ZipCode() As String
        Get
            Return mZipCode
        End Get
        Set(ByVal value As String)
            mZipCode = value
        End Set
    End Property
End Class

Public Class sPhone
    Private mPhoneNumber As String
    Private mPhoneNumberQualifier As String


    Public Sub New()
        mPhoneNumber = ""
        mPhoneNumberQualifier = ""
    End Sub

    Public Property PhoneNumber() As String
        Get
            Return mPhoneNumber
        End Get
        Set(ByVal value As String)
            mPhoneNumber = value
        End Set
    End Property

    Public Property PhoneNumberQualifier() As String
        Get
            Return mPhoneNumberQualifier
        End Get
        Set(ByVal value As String)
            mPhoneNumberQualifier = value
        End Set
    End Property
End Class

Public Class sQuantity
    Private mValue As String
    Private mQuantityQualifier As String
    Private mCodeListQualifier As String


    Public Sub New()
        mValue = ""
        mQuantityQualifier = ""
        mCodeListQualifier = ""
    End Sub

    Public Property Value() As String
        Get
            Return mValue
        End Get
        Set(ByVal value As String)
            mValue = value
        End Set
    End Property

    Public Property QuantityQualifier() As String
        Get
            Return mQuantityQualifier
        End Get
        Set(ByVal value As String)
            mQuantityQualifier = value
        End Set
    End Property

    Public Property CodeListQualifier() As String
        Get
            Return mCodeListQualifier
        End Get
        Set(ByVal value As String)
            mCodeListQualifier = value
        End Set
    End Property
End Class


Public Class sDate
    Private mDateValue As String
    Private mDateTimePeriodQualifier As String
    Private mDateTimePeriodFormatQualifier As String

    Public Sub New()
        mDateValue = ""
        mDateTimePeriodQualifier = ""
        mDateTimePeriodFormatQualifier = ""
    End Sub

    Public Property DateValue() As String
        Get
            Return mDateValue
        End Get
        Set(ByVal value As String)
            mDateValue = value
        End Set
    End Property

    Public Property DateTimePeriodQualifier() As String
        Get
            Return mDateTimePeriodQualifier
        End Get
        Set(ByVal value As String)
            mDateTimePeriodQualifier = value
        End Set
    End Property

    Public Property DateTimePeriodFormatQualifier() As String
        Get
            Return mDateTimePeriodFormatQualifier
        End Get
        Set(ByVal value As String)
            mDateTimePeriodFormatQualifier = value
        End Set
    End Property

End Class


Public Class sRefills
    Private mQualifier As String
    Private mQuantity As String

    Public Sub New()
        mQualifier = ""
        mQuantity = ""
    End Sub

    Public Property Qualifier() As String
        Get
            Return mQualifier
        End Get
        Set(ByVal value As String)
            mQualifier = value
        End Set
    End Property

    Public Property Quantity() As String
        Get
            Return mQuantity
        End Get
        Set(ByVal value As String)
            mQuantity = value
        End Set
    End Property
End Class



Public Class Medication

    Private mDrugDescription As String
    Private mDrugCoded As DrugCodedType
    Private mQuantity As sQuantity
    Private mDaysSupply As String
    Private mDirections As String
    Private mNote As String
    Private mRefills As sRefills
    Private mSubstitutions As String
    Private mWrittenDate As sDate
    Private mLastFillDate As sDate

    Public Sub New()
        mDrugDescription = ""
        mDrugCoded = New DrugCodedType
        mQuantity = New sQuantity
        mDaysSupply = ""
        mDirections = ""
        mNote = ""
        mRefills = New sRefills
        mSubstitutions = ""
        mWrittenDate = New sDate
        mLastFillDate = New sDate
    End Sub


    Public Property DrugDescription() As String
        Get
            Return mDrugDescription
        End Get
        Set(ByVal Value As String)
            mDrugDescription = Value
        End Set
    End Property
    Public Property DrugCoded() As DrugCodedType
        Get
            Return mDrugCoded
        End Get
        Set(ByVal Value As DrugCodedType)
            mDrugCoded = Value
        End Set
    End Property
    Public Property Quantity() As sQuantity
        Get
            Return mQuantity
        End Get
        Set(ByVal Value As sQuantity)
            mQuantity = Value
        End Set
    End Property
    Public Property DaysSupply() As String
        Get
            Return mDaysSupply
        End Get
        Set(ByVal Value As String)
            mDaysSupply = Value
        End Set
    End Property
    Public Property Directions() As String
        Get
            Return mDirections
        End Get
        Set(ByVal Value As String)
            mDirections = Value
        End Set
    End Property
    Public Property Note() As String
        Get
            Return mNote
        End Get
        Set(ByVal Value As String)
            mNote = Value
        End Set
    End Property
    Public Property Refills() As sRefills
        Get
            Return mRefills
        End Get
        Set(ByVal Value As sRefills)
            mRefills = Value
        End Set
    End Property
    Public Property Substitutions() As String
        Get
            Return mSubstitutions
        End Get
        Set(ByVal Value As String)
            mSubstitutions = Value
        End Set
    End Property
    Public Property WrittenDate() As sDate
        Get
            Return mWrittenDate
        End Get
        Set(ByVal Value As sDate)
            mWrittenDate = Value
        End Set
    End Property
    Public Property LastFillDate() As sDate
        Get
            Return mLastFillDate
        End Get
        Set(ByVal Value As sDate)
            mLastFillDate = Value
        End Set
    End Property
End Class


Public Class DrugCodedType
    Private mProductCode As String
    Private mProductCodeQualifier As String
    Private mDosageForm As String
    Private mStrength As String
    Private mStrengthUnits As String
    Private mDrugDBCode As String
    Private mDrugDBCodeQualifier As String


    Public Sub New()
        mProductCode = ""
        mProductCodeQualifier = ""
        mDosageForm = ""
        mStrength = ""
        mStrengthUnits = ""
        mDrugDBCode = ""
        mDrugDBCodeQualifier = ""
    End Sub

    Public Property ProductCode() As String
        Get
            Return mProductCode
        End Get
        Set(ByVal Value As String)
            mProductCode = Value
        End Set
    End Property
    Public Property ProductCodeQualifier() As String
        Get
            Return mProductCodeQualifier
        End Get
        Set(ByVal Value As String)
            mProductCodeQualifier = Value
        End Set
    End Property
    Public Property DosageForm() As String
        Get
            Return mDosageForm
        End Get
        Set(ByVal Value As String)
            mDosageForm = Value
        End Set
    End Property
    Public Property Strength() As String
        Get
            Return mStrength
        End Get
        Set(ByVal Value As String)
            mStrength = Value
        End Set
    End Property
    Public Property StrengthUnits() As String
        Get
            Return mStrengthUnits
        End Get
        Set(ByVal Value As String)
            mStrengthUnits = Value
        End Set
    End Property
    Public Property DrugDBCode() As String
        Get
            Return mDrugDBCode
        End Get
        Set(ByVal Value As String)
            mDrugDBCode = Value
        End Set
    End Property
    Public Property DrugDBCodeQualifier() As String
        Get
            Return mDrugDBCodeQualifier
        End Get
        Set(ByVal Value As String)
            mDrugDBCodeQualifier = Value
        End Set
    End Property
End Class



Public Class PatientType
    Private mPatientID As String ' THIS IS THE PATIENT SYSTEM ID
    Private mIdentification As sIdentification
    Private mName As sName
    Private mGender As GenderType
    Private mDateOfBirth As String
    Private mAddress As sAddress
    Private mEmail As String
    Private mPhoneNumbers As sPhone()
    Private mCardHolderName As sName
    Private mCardHolderReferenceNumber As String
    Private mRelationShipCode As RelationShip
    Private mGroupID As String
    Private mUniqueMemberID As String

    Public Property PatientID() As String
        Get
            Return mPatientID
        End Get
        Set(ByVal value As String)
            mPatientID = value
        End Set
    End Property

    Public Sub New()
        mIdentification = New sIdentification
        mName = New sName
        mGender = GenderType.M
        mDateOfBirth = ""
        mAddress = New sAddress
        mEmail = ""
        mCardHolderName = New sName
        mCardHolderReferenceNumber = ""
        mRelationShipCode = RelationShip.Member
        mGroupID = String.Empty
        mUniqueMemberID = String.Empty
    End Sub

    Public Property UniqueMemberID() As String
        Get
            Return mUniqueMemberID
        End Get
        Set(ByVal value As String)
            mUniqueMemberID = value
        End Set
    End Property

    Public Property GroupID() As String
        Get
            Return mGroupID
        End Get
        Set(ByVal value As String)
            mGroupID = value
        End Set
    End Property


    Public Property CardHolderReferenceNumber() As String
        Get
            Return mCardHolderReferenceNumber
        End Get
        Set(ByVal value As String)
            mCardHolderReferenceNumber = value
        End Set
    End Property


    Public Property RelationShipCode() As RelationShip
        Get
            Return mRelationShipCode
        End Get
        Set(ByVal value As RelationShip)
            mRelationShipCode = value
        End Set
    End Property

    Public Property CardHolderName() As sName
        Get
            Return mCardHolderName
        End Get
        Set(ByVal value As sName)
            mCardHolderName = value
        End Set
    End Property

    Public Property Identification() As sIdentification
        Get
            Return mIdentification
        End Get
        Set(ByVal Value As sIdentification)
            mIdentification = Value
        End Set
    End Property
    Public Property Name() As sName
        Get
            Return mName
        End Get
        Set(ByVal Value As sName)
            mName = Value
        End Set
    End Property
    Public Property Gender() As GenderType
        Get
            Return mGender
        End Get
        Set(ByVal Value As GenderType)
            mGender = Value
        End Set
    End Property
    Public Property DateOfBirth() As String
        Get
            Return mDateOfBirth
        End Get
        Set(ByVal Value As String)
            mDateOfBirth = Value
        End Set
    End Property
    Public Property Address() As sAddress
        Get
            Return mAddress
        End Get
        Set(ByVal Value As sAddress)
            mAddress = Value
        End Set
    End Property
    Public Property Email() As String
        Get
            Return mEmail
        End Get
        Set(ByVal Value As String)
            mEmail = Value
        End Set
    End Property
    Public Property PhoneNumbers() As sPhone()
        Get
            Return mPhoneNumbers
        End Get
        Set(ByVal Value As sPhone())
            mPhoneNumbers = Value
        End Set
    End Property
End Class


Public Enum GenderType
    M = 1
    F = 2
    U = 3
End Enum



Public Class PharmacyType
    Private mIdentification As sIdentification
    Private mStoreName As String
    Private mPharmacist As sName
    Private mPharmacistAgent As sName
    Private mAddress As sAddress
    Private mEmail As String
    Private mPhoneNumbers As sPhone()


    Public Sub New()
        mIdentification = New sIdentification
        mStoreName = ""
        mPharmacist = New sName
        mPharmacistAgent = New sName
        mAddress = New sAddress
        mEmail = ""
        'mPhoneNumbers = New sPhone
    End Sub

    Public Property Identification() As sIdentification
        Get
            Return mIdentification
        End Get
        Set(ByVal Value As sIdentification)
            mIdentification = Value
        End Set
    End Property
    Public Property StoreName() As String
        Get
            Return mStoreName
        End Get
        Set(ByVal Value As String)
            mStoreName = Value
        End Set
    End Property
    Public Property Pharmacist() As sName
        Get
            Return mPharmacist
        End Get
        Set(ByVal Value As sName)
            mPharmacist = Value
        End Set
    End Property
    Public Property PharmacistAgent() As sName
        Get
            Return mPharmacistAgent
        End Get
        Set(ByVal Value As sName)
            mPharmacistAgent = Value
        End Set
    End Property
    Public Property Address() As sAddress
        Get
            Return mAddress
        End Get
        Set(ByVal Value As sAddress)
            mAddress = Value
        End Set
    End Property
    Public Property Email() As String
        Get
            Return mEmail
        End Get
        Set(ByVal Value As String)
            mEmail = Value
        End Set
    End Property
    Public Property PhoneNumbers() As sPhone()
        Get
            Return mPhoneNumbers
        End Get
        Set(ByVal Value As sPhone())
            mPhoneNumbers = Value
        End Set
    End Property
End Class