﻿Public Class RxHubUtility

    'REMOVES ANY ILLEGAL CHARACTERS FROM A STRING
    Public Shared Function CleanString(ByVal pUncleanString As String) As String

        Dim lCleanString As String

        Try

            lCleanString = System.Text.RegularExpressions.Regex.Replace(pUncleanString, "[^a-zA-Z 0-9'.@]", String.Empty).Trim()

            Return lCleanString

        Catch ex As Exception
            Return String.Empty
        End Try
    End Function



End Class
