﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Vidley2.DTO
{
    public class MembershipTypeDto
    {
        public byte Id { get; set; }
        public string Name { get; set; }
    }
}