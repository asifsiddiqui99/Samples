﻿namespace Vidley2.DTO
{
    public class GenreDto
    {
        public byte Id { get; set; }
        public string Name { get; set; }
    }
}