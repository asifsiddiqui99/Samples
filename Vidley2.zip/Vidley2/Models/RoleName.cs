﻿namespace Vidley2.Models
{
    public static class RoleName
    {
        public const string CanManageMovies = "CanManageMovies";
    }
}