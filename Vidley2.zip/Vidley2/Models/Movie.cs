﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Vidley2.Models
{
    public class Movie
    {
        public int Id { get; set; }
        [Required]
        public string Name { get; set; }

        [Required]
        [Display(Name = "Release Date")]
        public DateTime ReleaseDate { get; set; }

        [Required]
        [Display(Name = "Date Added")]
        public DateTime DateAdded { get; set; }

        [Required]
        [Display(Name = "Number In Stock")]
        [Range(1, 20, ErrorMessage = "Stock value must be between 1 and 20.")]
        public short NumberInStock { get; set; }

        [Required]
        [Display(Name = "Genre")]
        public byte GenreId { get; set; }


        public Genre Genre { get; set; }

        public short NumberAvailable { get; set; }

    }
}