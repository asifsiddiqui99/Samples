namespace Vidley2.Migrations
{
    using System.Data.Entity.Migrations;

    public partial class SeedUsers : DbMigration
    {
        public override void Up()
        {
            Sql(
                @"INSERT INTO [dbo].[AspNetUsers] ([Id], [Email], [EmailConfirmed], [PasswordHash], [SecurityStamp], [PhoneNumber], [PhoneNumberConfirmed], [TwoFactorEnabled], [LockoutEndDateUtc], [LockoutEnabled], [AccessFailedCount], [UserName]) VALUES (N'98d19255-9fe4-4ec5-9707-385a03d0192b', N'admin@vidley.com', 0, N'AMX37VxolKz0TF2Lermv4/sxkoYcKBH1XKJK4oDqVxKltPVyqG2gPHDLQEObWODcXw==', N'160fbff0-ed58-45fc-9361-1d595ebb87e5', NULL, 0, 0, NULL, 1, 0, N'admin@vidley.com')
                  INSERT INTO[dbo].[AspNetUsers]([Id], [Email], [EmailConfirmed], [PasswordHash], [SecurityStamp], [PhoneNumber], [PhoneNumberConfirmed], [TwoFactorEnabled], [LockoutEndDateUtc], [LockoutEnabled], [AccessFailedCount], [UserName]) VALUES(N'b5818096-a2d1-45f1-ac57-be05c119ce27', N'guest@vidley.com', 0, N'AFQT8vXUFGFxhYPHPXBDkDvbaaKIkLsUqzuuSoG4FriqKVzsDTHo+jCHhCUtIvdmRw==', N'ada5d0d5-a228-453b-9024-6cfc73e225bb', NULL, 0, 0, NULL, 1, 0, N'guest@vidley.com')
                  INSERT INTO [dbo].[AspNetRoles] ([Id], [Name]) VALUES (N'74a23e8b-4e2c-430e-b497-e1c4eb29f055', N'CanManageMovies')
                  INSERT INTO [dbo].[AspNetUserRoles] ([UserId], [RoleId]) VALUES (N'98d19255-9fe4-4ec5-9707-385a03d0192b', N'74a23e8b-4e2c-430e-b497-e1c4eb29f055')
                ");
        }

        public override void Down()
        {
        }
    }
}
